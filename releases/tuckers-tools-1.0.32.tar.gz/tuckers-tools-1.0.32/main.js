var __defProp = Object.defineProperty;
var __defProps = Object.defineProperties;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getOwnPropSymbols = Object.getOwnPropertySymbols;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __propIsEnum = Object.prototype.propertyIsEnumerable;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __spreadValues = (a, b) => {
  for (var prop in b || (b = {}))
    if (__hasOwnProp.call(b, prop))
      __defNormalProp(a, prop, b[prop]);
  if (__getOwnPropSymbols)
    for (var prop of __getOwnPropSymbols(b)) {
      if (__propIsEnum.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    }
  return a;
};
var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __async = (__this, __arguments, generator) => {
  return new Promise((resolve, reject) => {
    var fulfilled = (value) => {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    };
    var rejected = (value) => {
      try {
        step(generator.throw(value));
      } catch (e) {
        reject(e);
      }
    };
    var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
    step((generator = generator.apply(__this, __arguments)).next());
  });
};

// main.ts
var main_exports = {};
__export(main_exports, {
  default: () => TuckersToolsPlugin
});
module.exports = __toCommonJS(main_exports);
var import_obsidian9 = require("obsidian");

// settings.ts
var import_obsidian = require("obsidian");

// utils.ts
function slugify(text) {
  return text.toLowerCase().trim().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9\s-]/g, "").replace(/[\s-]+/g, "-").replace(/^-+|-+$/g, "");
}
function validateDate(dateString) {
  const regex = /^\d{4}-\d{2}-\d{2}$/;
  if (!dateString.match(regex))
    return false;
  const date = new Date(dateString);
  const timestamp = date.getTime();
  if (typeof timestamp !== "number" || isNaN(timestamp))
    return false;
  return dateString === date.toISOString().split("T")[0];
}

// settings.ts
var DEFAULT_SETTINGS = {
  baseDirectory: "/",
  semesterStartDate: new Date().toISOString().split("T")[0],
  semesterEndDate: new Date(new Date().setMonth(new Date().getMonth() + 4)).toISOString().split("T")[0],
  schoolName: "University",
  schoolAbbreviation: "U",
  templateFolder: "Tuckers Tools",
  useEnhancedMetadata: false,
  dataviewJsPath: "/Supporting/dataview-functions"
};
var TuckersToolsSettingTab = class extends import_obsidian.PluginSettingTab {
  constructor(app, plugin) {
    super(app, plugin);
    this.plugin = plugin;
  }
  display() {
    const { containerEl } = this;
    containerEl.empty();
    containerEl.createEl("h2", { text: "Tuckers Tools Settings" });
    new import_obsidian.Setting(containerEl).setName("Base Directory").setDesc("Root directory for course content organization").addText((text) => text.setPlaceholder("/").setValue(this.plugin.settings.baseDirectory).onChange((value) => __async(this, null, function* () {
      this.plugin.settings.baseDirectory = value;
      yield this.plugin.saveSettings();
    })));
    const startDateSetting = new import_obsidian.Setting(containerEl).setName("Semester Start Date").setDesc("Start date for the current semester").addText((text) => text.setPlaceholder("YYYY-MM-DD").setValue(this.plugin.settings.semesterStartDate).onChange((value) => __async(this, null, function* () {
      if (value && !validateDate(value)) {
        startDateSetting.setDesc("Start date for the current semester (Invalid date format)");
      } else {
        startDateSetting.setDesc("Start date for the current semester");
      }
      this.plugin.settings.semesterStartDate = value;
      yield this.plugin.saveSettings();
    })));
    const endDateSetting = new import_obsidian.Setting(containerEl).setName("Semester End Date").setDesc("End date for the current semester").addText((text) => text.setPlaceholder("YYYY-MM-DD").setValue(this.plugin.settings.semesterEndDate).onChange((value) => __async(this, null, function* () {
      if (value && !validateDate(value)) {
        endDateSetting.setDesc("End date for the current semester (Invalid date format)");
      } else {
        endDateSetting.setDesc("End date for the current semester");
      }
      this.plugin.settings.semesterEndDate = value;
      yield this.plugin.saveSettings();
    })));
    new import_obsidian.Setting(containerEl).setName("School Name").setDesc("Name of your institution").addText((text) => text.setPlaceholder("University").setValue(this.plugin.settings.schoolName).onChange((value) => __async(this, null, function* () {
      this.plugin.settings.schoolName = value;
      yield this.plugin.saveSettings();
    })));
    new import_obsidian.Setting(containerEl).setName("School Abbreviation").setDesc("Abbreviation for your institution").addText((text) => text.setPlaceholder("U").setValue(this.plugin.settings.schoolAbbreviation).onChange((value) => __async(this, null, function* () {
      this.plugin.settings.schoolAbbreviation = value;
      yield this.plugin.saveSettings();
    })));
    new import_obsidian.Setting(containerEl).setName("Template Folder").setDesc("Subfolder within your Templater template folder for Tuckers Tools templates").addText((text) => text.setPlaceholder("Tuckers Tools").setValue(this.plugin.settings.templateFolder).onChange((value) => __async(this, null, function* () {
      this.plugin.settings.templateFolder = value;
      yield this.plugin.saveSettings();
    })));
    new import_obsidian.Setting(containerEl).setName("Use Enhanced Metadata").setDesc("Enable enhanced metadata fields for new notes (existing notes remain unchanged)").addToggle((toggle) => toggle.setValue(this.plugin.settings.useEnhancedMetadata).onChange((value) => __async(this, null, function* () {
      this.plugin.settings.useEnhancedMetadata = value;
      yield this.plugin.saveSettings();
    })));
    new import_obsidian.Setting(containerEl).setName("Dataview Functions Path").setDesc("Path to the dataview functions file (without extension)").addText((text) => text.setPlaceholder("/Supporting/dataview-functions").setValue(this.plugin.settings.dataviewJsPath).onChange((value) => __async(this, null, function* () {
      this.plugin.settings.dataviewJsPath = value;
      yield this.plugin.saveSettings();
    })));
  }
};

// templateManager.ts
var import_obsidian2 = require("obsidian");
var TemplateManager = class {
  constructor(app, settings) {
    this.app = app;
    this.settings = settings;
    this.manifest = {
      version: "1.0.0",
      templates: {
        "Courses/Create Course Homepage.md": "1.0.0",
        "Courses/Course Index.md": "1.0.0",
        "Modules/Create Module.md": "1.0.0",
        "Chapters/Create Chapter.md": "1.0.0",
        "Assignments/Create Assignment.md": "1.0.0",
        "Daily/Daily Note.md": "1.0.0",
        "Utilities/Vocabulary Entry.md": "1.0.0",
        "Utilities/Due Date Entry.md": "1.0.0"
      },
      plugin_version: "1.0.0",
      release_notes: "Initial release of Tuckers Tools templates"
    };
  }
  installTemplates() {
    return __async(this, null, function* () {
      try {
        const templaterPlugin = this.getTemplaterPlugin();
        if (!templaterPlugin) {
          new import_obsidian2.Notice(
            "Templater plugin not found. Please install and enable the Templater plugin first."
          );
          console.error(
            "Templater plugin not found. Please install and enable the Templater plugin first."
          );
          return;
        }
        const templateFolderPath = this.getTemplateFolderPath(templaterPlugin);
        if (!templateFolderPath) {
          new import_obsidian2.Notice(
            "Template folder not configured in Templater settings. Please configure it in Templater settings first."
          );
          console.error(
            "Template folder not configured in Templater settings. Please configure it in Templater settings first."
          );
          return;
        }
        const fullTemplatePath = `${templateFolderPath}/${this.settings.templateFolder}`;
        try {
          yield this.app.vault.createFolder(fullTemplatePath);
          console.log(`Created template folder: ${fullTemplatePath}`);
        } catch (e) {
          console.log(
            `Template folder already exists or created: ${fullTemplatePath}`
          );
        }
        const subdirs = [
          "Courses",
          "Modules",
          "Chapters",
          "Assignments",
          "Daily",
          "Utilities"
        ];
        for (const subdir of subdirs) {
          try {
            const subPath = `${fullTemplatePath}/${subdir}`;
            yield this.app.vault.createFolder(subPath);
            console.log(`Created subdirectory: ${subPath}`);
          } catch (e) {
            console.log(
              `Subdirectory already exists: ${fullTemplatePath}/${subdir}`
            );
          }
        }
        yield this.installCourseTemplates(fullTemplatePath);
        yield this.installModuleTemplates(fullTemplatePath);
        yield this.installChapterTemplates(fullTemplatePath);
        yield this.installAssignmentTemplates(fullTemplatePath);
        yield this.installDailyTemplates(fullTemplatePath);
        yield this.installUtilityTemplates(fullTemplatePath);
        yield this.createREADME(fullTemplatePath);
        yield this.createTemplateManifest(fullTemplatePath);
        new import_obsidian2.Notice("Tuckers Tools templates installed successfully!");
        console.log("Tuckers Tools templates installed successfully");
      } catch (error) {
        console.error("Error installing templates:", error);
        new import_obsidian2.Notice("Error installing templates. Check console for details.");
      }
    });
  }
  getTemplaterPlugin() {
    const possiblePaths = [
      this.app.plugins.plugins["templater-obsidian"],
      this.app.plugins.plugins["templater"],
      this.app.plugins.getPlugin("templater-obsidian"),
      this.app.plugins.getPlugin("templater")
    ];
    for (const path of possiblePaths) {
      if (path) {
        return path;
      }
    }
    return null;
  }
  getTemplateFolderPath(templaterPlugin) {
    const settings = templaterPlugin.settings;
    if (!settings) {
      console.error("Templater plugin has no settings");
      return null;
    }
    const possiblePaths = [
      settings.templates_folder,
      // Changed from template_folder to match actual setting
      settings.template_folder,
      settings.templateFolder,
      settings.templateFolderPath,
      settings.folder
    ];
    for (const path of possiblePaths) {
      if (path && typeof path === "string") {
        return path;
      }
    }
    console.error(
      "Template folder not found in Templater settings. Available settings:",
      Object.keys(settings)
    );
    return null;
  }
  createTemplateManifest(basePath) {
    return __async(this, null, function* () {
      const manifestPath = `${basePath}/template-manifest.json`;
      const manifestContent = JSON.stringify(this.manifest, null, 2);
      try {
        const existingManifest = this.app.vault.getAbstractFileByPath(manifestPath);
        if (existingManifest) {
          const file = existingManifest;
          yield this.app.vault.modify(file, manifestContent);
          console.log(`Updated template manifest: ${manifestPath}`);
          return;
        }
        yield this.app.vault.create(manifestPath, manifestContent);
        console.log(`Created template manifest: ${manifestPath}`);
      } catch (e) {
        new import_obsidian2.Notice(`Error creating template manifest ${manifestPath}`);
        console.error(`Error creating template manifest ${manifestPath}:`, e);
      }
    });
  }
  checkForTemplateUpdates() {
    return __async(this, null, function* () {
      console.log("Checking for template updates");
      return false;
    });
  }
  updateTemplates() {
    return __async(this, null, function* () {
      try {
        console.log("Updating templates");
        const templaterPlugin = this.getTemplaterPlugin();
        if (!templaterPlugin) {
          new import_obsidian2.Notice(
            "Templater plugin not found. Please install and enable the Templater plugin first."
          );
          console.error(
            "Templater plugin not found. Please install and enable the Templater plugin first."
          );
          return;
        }
        const templateFolderPath = this.getTemplateFolderPath(templaterPlugin);
        if (!templateFolderPath) {
          new import_obsidian2.Notice(
            "Template folder not configured in Templater settings. Please configure it in Templater settings first."
          );
          console.error(
            "Template folder not configured in Templater settings. Please configure it in Templater settings first."
          );
          return;
        }
        const fullTemplatePath = `${templateFolderPath}/${this.settings.templateFolder}`;
        yield this.installCourseTemplates(fullTemplatePath);
        yield this.installModuleTemplates(fullTemplatePath);
        yield this.installChapterTemplates(fullTemplatePath);
        yield this.installAssignmentTemplates(fullTemplatePath);
        yield this.installDailyTemplates(fullTemplatePath);
        yield this.installUtilityTemplates(fullTemplatePath);
        yield this.createREADME(fullTemplatePath);
        yield this.createTemplateManifest(fullTemplatePath);
        new import_obsidian2.Notice("Tuckers Tools templates updated successfully!");
        console.log("Tuckers Tools templates updated successfully");
      } catch (error) {
        console.error("Error updating templates:", error);
        new import_obsidian2.Notice("Error updating templates. Check console for details.");
      }
    });
  }
  installCourseTemplates(basePath) {
    return __async(this, null, function* () {
      const coursePath = `${basePath}/Courses`;
      const courseHomepageTemplate = this.generateCourseHomepageTemplate();
      yield this.writeTemplateFile(
        `${coursePath}/Create Course Homepage.md`,
        courseHomepageTemplate
      );
      const courseIndexTemplate = this.generateCourseIndexTemplate();
      yield this.writeTemplateFile(
        `${coursePath}/Course Index.md`,
        courseIndexTemplate
      );
    });
  }
  installModuleTemplates(basePath) {
    return __async(this, null, function* () {
      const modulePath = `${basePath}/Modules`;
      const moduleTemplate = this.generateModuleTemplate();
      yield this.writeTemplateFile(
        `${modulePath}/Create Module.md`,
        moduleTemplate
      );
    });
  }
  installChapterTemplates(basePath) {
    return __async(this, null, function* () {
      const chapterPath = `${basePath}/Chapters`;
      const chapterTemplate = this.generateChapterTemplate();
      yield this.writeTemplateFile(
        `${chapterPath}/Create Chapter.md`,
        chapterTemplate
      );
    });
  }
  installAssignmentTemplates(basePath) {
    return __async(this, null, function* () {
      const assignmentPath = `${basePath}/Assignments`;
      const assignmentTemplate = this.generateAssignmentTemplate();
      yield this.writeTemplateFile(
        `${assignmentPath}/Create Assignment.md`,
        assignmentTemplate
      );
    });
  }
  installDailyTemplates(basePath) {
    return __async(this, null, function* () {
      const dailyPath = `${basePath}/Daily`;
      const dailyNoteTemplate = this.generateDailyNoteTemplate();
      yield this.writeTemplateFile(
        `${dailyPath}/Daily Note.md`,
        dailyNoteTemplate
      );
    });
  }
  installUtilityTemplates(basePath) {
    return __async(this, null, function* () {
      const utilityPath = `${basePath}/Utilities`;
      const vocabTemplate = this.generateVocabularyTemplate();
      yield this.writeTemplateFile(
        `${utilityPath}/Vocabulary Entry.md`,
        vocabTemplate
      );
      const dueDateTemplate = this.generateDueDateTemplate();
      yield this.writeTemplateFile(
        `${utilityPath}/Due Date Entry.md`,
        dueDateTemplate
      );
    });
  }
  writeTemplateFile(path, content) {
    return __async(this, null, function* () {
      try {
        const existingFile = this.app.vault.getAbstractFileByPath(path);
        if (existingFile) {
          console.log(`Updating existing template file: ${path}`);
          const file = existingFile;
          yield this.app.vault.modify(file, content);
          return;
        }
        yield this.app.vault.create(path, content);
        console.log(`Created template file: ${path}`);
      } catch (e) {
        new import_obsidian2.Notice(`Error creating template file ${path}`);
        console.error(`Error creating template file ${path}:`, e);
      }
    });
  }
  generateCourseHomepageTemplate() {
    const enhancedMetadata = this.settings.useEnhancedMetadata;
    if (enhancedMetadata) {
      return `---
course_id: <% courseId %>
course_season: <% courseSeason %>
course_year: <% courseYear %>
created: <% tp.date.now("YYYY-MM-DD[T]HH:mm:ssZ") %>
tags: 
  - <% courseId %>
  - ${this.settings.schoolAbbreviation}/<% courseYear %>/<% courseSeason %>/<% courseId %>/
  - course_home
  - education
  - ${this.settings.schoolName.replace(/\s+/g, "_")}
banner:
cssclasses:
  - whiteboard-course
---

<%*
// Tuckers Tools Course Creation
// For best experience, use the plugin command: Command Palette \u2192 'Create New Course'

let courseName = "New Course";
let courseSeason = "Fall"; 
let courseYear = new Date().getFullYear().toString();
let courseId = "COURSE_ID";

// Try to use system prompts, with graceful fallback
try {
  if (tp && tp.system && tp.system.prompt) {
    courseName = await tp.system.prompt("Course Name (e.g. SWO-250 - Course Title)") || courseName;
    courseId = courseName.split(' - ')[0] || courseName.replace(/[^a-zA-Z0-9]/g, "_");
    courseSeason = await tp.system.suggester(["Fall","Winter","Spring","Summer"],["Fall","Winter","Spring","Summer"], "Season") || courseSeason;
    courseYear = await tp.system.prompt("Year") || courseYear;
  } else {
    console.log("System prompts not available, use the plugin command instead");
  }
} catch (e) {
  console.error("Error with system prompts:", e.message);
  console.log("Use the plugin command: Command Palette \u2192 'Create New Course'");
}

// Move file to appropriate location
await tp.file.move(\`/\${courseYear}/\${courseSeason}/\${courseName}/\${courseName}\`);

// Create attachments folder
try {
  await app.vault.createFolder(\`/\${courseYear}/\${courseSeason}/\${courseName}/Attachments\`);
} catch (e) {
  // Folder might already exist
}
%>

# <% courseName %>

## Course Information
**Course**: <% courseName %>
**Course ID**: <% courseId %>
**Term**: <% courseSeason %> <% courseYear %>
**School**: ${this.settings.schoolName}

## Instructor
**Name**: \`INPUT[text:instructor_name]\`
**Email**: \`INPUT[text:instructor_email]\`
**Office Hours**: \`INPUT[text:instructor_office_hours]\`
**Office Location**: \`INPUT[text:instructor_office_location]\`

## Course Description
\`INPUT[multiline(10x50):course_description]\`

## Learning Objectives
\`INPUT[multiline(10x50):learning_objectives]\`

## Required Texts
\`\`\`meta-bind-js-view
{texts} as texts
---
const availableTexts = app.vault.getFiles().filter(file => file.extension == 'pdf').map(f => f?.name)
const escapeRegex = /[,\`'()]/g;
options = availableTexts.map(t => \`option([[\${t.replace(escapeRegex,$1)}]], \${t.replace(escapeRegex,$1)})\` )
const str = \\\`INPUT[inlineListSuggester(\${options.join(", ")}):texts]\\\`
return engine.markdown.create(str)
\`\`\`

## Course Schedule
\`INPUT[multiline(20x50):course_schedule]\`

## Assignments
\`INPUT[multiline(15x50):assignments]\`

## Resources
\`INPUT[multiline(10x50):resources]\`

## Vocabulary
\`\`\`dataviewjs
const {processCourseVocabulary} = require("${this.settings.dataviewJsPath || "/Supporting/dataview-functions"}");
processCourseVocabulary(dv, '<% courseId %>');
\`\`\`

## Due Dates
\`\`\`dataviewjs
const {processDueDates} = require("${this.settings.dataviewJsPath || "/Supporting/dataview-functions"}");
processDueDates(dv,'#<% courseId %>');
\`\`\`

## Class Materials
\`INPUT[multiline(10x50):class_materials]\`

## Classmates
\`INPUT[multiline(15x50):classmates]\``;
    } else {
      return `---
course_id: <% courseId %>
course_name: <% courseName %>
course_season: <% courseSeason %>
course_year: <% courseYear %>
created: <% tp.date.now("YYYY-MM-DD[T]HH:mm:ssZ") %>
tags:
  - <% courseId %>
  - course_home
  - education
---

<%*
// Tuckers Tools Course Creation
// For best experience, use the plugin command: Command Palette \u2192 'Create New Course'

let courseName = "New Course";
let courseSeason = "Fall"; 
let courseYear = new Date().getFullYear().toString();
let courseId = "COURSE_ID";

// Try to use system prompts, with graceful fallback
try {
  if (tp && tp.system && tp.system.prompt) {
    courseName = await tp.system.prompt("Course Name (e.g. SWO-250 - Course Title)") || courseName;
    courseId = courseName.split(' - ')[0] || courseName.replace(/[^a-zA-Z0-9]/g, "_");
    courseSeason = await tp.system.suggester(["Fall","Winter","Spring","Summer"],["Fall","Winter","Spring","Summer"], "Season") || courseSeason;
    courseYear = await tp.system.prompt("Year") || courseYear;
  } else {
    console.log("System prompts not available, use the plugin command instead");
  }
} catch (e) {
  console.error("Error with system prompts:", e.message);
  console.log("Use the plugin command: Command Palette \u2192 'Create New Course'");
}

// Move file to appropriate location
await tp.file.move(\`/\${courseYear}/\${courseSeason}/\${courseName}/\${courseName}\`);

// Create attachments folder
try {
  await app.vault.createFolder(\`/\${courseYear}/\${courseSeason}/\${courseName}/Attachments\`);
} catch (e) {
  // Folder might already exist
}
%>

# <% courseName %>

## Course Information
**Course ID**: <% courseId %>
**Term**: <% courseSeason %> <% courseYear %>
**School**: ${this.settings.schoolName}

## Instructor
**Name**: \`INPUT[text:instructor_name]\`
**Email**: \`INPUT[text:instructor_email]\`
**Office Hours**: \`INPUT[text:instructor_office_hours]\`
**Office Location**: \`INPUT[text:instructor_office_location]\`

## Course Description
\`INPUT[multiline(10x50):course_description]\`

## Learning Objectives
\`INPUT[multiline(10x50):learning_objectives]\`

## Required Texts
\`\`\`meta-bind-js-view
{texts} as texts
---
const availableTexts = app.vault.getFiles().filter(file => file.extension == 'pdf').map(f => f?.name)
const escapeRegex = /[,\`'()]/g;
options = availableTexts.map(t => \`option([[\${t.replace(escapeRegex,$1)}]], \${t.replace(escapeRegex,$1)})\` )
const str = \\\`INPUT[inlineListSuggester(\${options.join(", ")}):texts]\\\`
return engine.markdown.create(str)
\`\`\`

## Schedule
\`INPUT[multiline(15x50):course_schedule]\`

## Assignments
\`INPUT[multiline(10x50):assignments]\`

## Resources
\`INPUT[multiline(10x50):resources]\`

## Vocabulary
\`\`\`dataviewjs
const {processCourseVocabulary} = require("${this.settings.dataviewJsPath || "/Supporting/dataview-functions"}");
processCourseVocabulary(dv, '<% courseId %>');
\`\`\`

## Due Dates
\`\`\`dataviewjs
const {processDueDates} = require("${this.settings.dataviewJsPath || "/Supporting/dataview-functions"}");
processDueDates(dv,'#<% courseId %>');
\`\`\``;
    }
  }
  generateCourseIndexTemplate() {
    return `---
content_type: course_index
tags:
  - index
---

# Course Index

## Modules

## Chapters

## Assignments

## Resources

## Vocabulary

## Due Dates`;
  }
  generateModuleTemplate() {
    return `---
${this.settings.useEnhancedMetadata ? `course_id: <% courseId %>
module_number: <% moduleNumber %>
week_number: <% weekNumber %>
class_day: <% dayOfWeek %>
content_type: module
parent_course: "[[<% course %>]]"` : `course_id: <% courseId %>
module_number: <% moduleNumber %>
week_number: <% weekNumber %>
class_day: <% dayOfWeek %>`}
created: <% tp.date.now("YYYY-MM-DD[T]HH:mm:ssZ") %>
tags:
  - education
  - <% courseId %>
  - module
---

<%*
const { season, moduleNumber, weekNumber, course, courseId, discipline, dayOfWeek } = await tp.user.new_module(app, tp, "2025");
let title = courseId
if (moduleNumber && weekNumber) { title = \`M\${moduleNumber}/W\${weekNumber}\`}
else if (moduleNumber) { title = \`M\${moduleNumber}\` } 
else if (weekNumber) { title = \`W\${weekNumber}\`}
%>

# [[<% course %>]] - <% title %> - <% dayOfWeek %>

## Due Dates
| Date | Assignment |
| ---- | ---------- |
|      |            |
|      |            |
|      |            |

\`\`\`dataviewjs
const {processDueDates} = require("${this.settings.dataviewJsPath || "/Supporting/dataview-functions"}");
processDueDates(dv,'#<% courseId %>');
\`\`\`

## Learning Objectives

## Reading Assignment

## Lecture Notes

## Discussion Questions

## Vocabulary

\`\`\`dataviewjs
const {processCourseVocabulary} = require("${this.settings.dataviewJsPath || "/Supporting/dataview-functions"}");
processCourseVocabulary(dv, '<% courseId %>');
\`\`\`

## Additional Resources`;
  }
  generateChapterTemplate() {
    return `---
${this.settings.useEnhancedMetadata ? `course_id: <% courseId %>
chapter_number: <% chapterNumber %>
content_type: chapter
parent_course: "[[<% course %>]]"
text_reference: "[[<% text %>]]"` : `course_id: <% courseId %>
chapter_number: <% chapterNumber %>`}
created: <% tp.date.now("YYYY-MM-DD[T]HH:mm:ssZ") %>
tags:
  - education
  - <% courseId %>
  - chapter
---

<%*
const { chapterNumber, course, courseId, discipline, text} = await tp.user.new_chapter(tp);
%>

# [[<% text %>]] - Chapter <% chapterNumber %>

## Reading Assignment
- **Textbook**: [[<% text %>]]
- **Chapter**: <% chapterNumber %>
- **Pages**: 

## Summary

## Key Concepts

## Vocabulary
- 

## Notes

## Discussion Questions

## Further Reading`;
  }
  generateAssignmentTemplate() {
    return `---
${this.settings.useEnhancedMetadata ? `course_id: <% courseId %>
assignment_type: <% assignmentType %>
due_date: <% dueDate %>
points: <% points %>
content_type: assignment
parent_course: "[[<% course %>]]"` : `course_id: <% courseId %>
assignment_type: <% assignmentType %>
due_date: <% dueDate %>`}
created: <% tp.date.now("YYYY-MM-DD[T]HH:mm:ssZ") %>
status: pending
tags:
  - education
  - <% courseId %>
  - assignment
---

# <% assignmentName %> - <% courseId %>

## Description

## Instructions

## Due Date
**Assigned**: <% tp.date.now("YYYY-MM-DD") %>
**Due**: <% dueDate %>

## Submission

## Grading Criteria

## Resources

# Due Dates
| <% dueDate %> | <% assignmentName %> | pending |
`;
  }
  generateDailyNoteTemplate() {
    return `---
content_type: daily_note
date: <% tp.date.now("YYYY-MM-DD") %>
tags:
  - daily
  - <% tp.date.now("YYYY") %>
  - <% tp.date.now("MM") %>
  - <% tp.date.now("DD") %>
---

# <% tp.date.now("YYYY-MM-DD - dddd") %>

<< [[<% tp.date.yesterday("YYYY-MM-DD") %>]] | [[<% tp.date.tomorrow("YYYY-MM-DD") %>]] >>

## Today's Focus

## Courses Worked On
- 

## Tasks Completed
- [ ] 

## Vocabulary Reviewed
- 

## Assignments Due
- 

## Learning Achievements

## Challenges

## Tomorrow's Plan

## Reflection`;
  }
  generateVocabularyTemplate() {
    return `## <% term %>
**Term**: <% term %>
**Part of Speech**: 
**Definition**: 
**Context**: 
**Examples**: 
**Related Terms**: 
**See Also**:`;
  }
  generateDueDateTemplate() {
    return `| <% dueDate %> | <% assignment %> | <% status %> |`;
  }
  createREADME(basePath) {
    return __async(this, null, function* () {
      const readmeContent = `# Tuckers Tools Templates

This directory contains templates for the Tuckers Tools Obsidian plugin.

## Template Categories

- **Courses**: Templates for creating and organizing courses
- **Modules**: Templates for course modules
- **Chapters**: Templates for chapter notes
- **Assignments**: Templates for assignments
- **Daily**: Templates for daily notes
- **Utilities**: Helper templates

## Usage

These templates are designed to work with the Tuckers Tools plugin. To use them:

1. Install the Tuckers Tools plugin
2. Configure your settings in the plugin settings tab
3. Use the "Insert Template" command to apply these templates to new notes

## Customization

Feel free to customize these templates to suit your needs. The plugin will not overwrite your changes when updating templates.`;
      yield this.writeTemplateFile(`${basePath}/README.md`, readmeContent);
    });
  }
};

// courseWizard.ts
var import_obsidian4 = require("obsidian");

// inputModal.ts
var import_obsidian3 = require("obsidian");
var InputModal = class extends import_obsidian3.Modal {
  constructor(app, onSubmit) {
    super(app);
    this.onSubmit = onSubmit;
  }
  onOpen() {
    const { contentEl } = this;
    contentEl.createEl("h2", { text: "Enter Value" });
    new import_obsidian3.Setting(contentEl).setName("Value").addText(
      (text) => text.onChange((value) => {
        this.result = value;
      }).inputEl.focus()
    );
    new import_obsidian3.Setting(contentEl).addButton(
      (btn) => btn.setButtonText("Submit").setCta().onClick(() => {
        this.close();
        this.onSubmit(this.result || "");
      })
    ).addButton(
      (btn) => btn.setButtonText("Cancel").onClick(() => {
        this.close();
        this.onSubmit(null);
      })
    );
  }
  onClose() {
    const { contentEl } = this;
    contentEl.empty();
  }
};
var SuggesterModal = class extends import_obsidian3.Modal {
  constructor(app, options, onSubmit) {
    super(app);
    this.onSubmit = onSubmit;
    const dropdownOptions = {};
    options.forEach((option) => {
      dropdownOptions[option] = option;
    });
    this.createDropdown(dropdownOptions);
  }
  createDropdown(options) {
    const { contentEl } = this;
    contentEl.createEl("h2", { text: "Select Option" });
    let selectedValue = Object.keys(options)[0] || null;
    const dropdown = contentEl.createEl("select");
    Object.entries(options).forEach(([key, value]) => {
      const option = dropdown.createEl("option", {
        value: key,
        text: value
      });
      if (key === selectedValue) {
        option.selected = true;
      }
    });
    dropdown.addEventListener("change", (event) => {
      selectedValue = event.target.value;
      this.result = selectedValue;
    });
    new import_obsidian3.Setting(contentEl).addButton(
      (btn) => btn.setButtonText("Submit").setCta().onClick(() => {
        this.close();
        this.onSubmit(selectedValue);
      })
    ).addButton(
      (btn) => btn.setButtonText("Cancel").onClick(() => {
        this.close();
        this.onSubmit(null);
      })
    );
  }
  onOpen() {
  }
  onClose() {
    const { contentEl } = this;
    contentEl.empty();
  }
};

// courseWizard.ts
var CourseCreationWizard = class {
  constructor(app, settings) {
    this.app = app;
    this.settings = settings;
  }
  createCourseHomepage() {
    return __async(this, null, function* () {
      try {
        const courseDetails = yield this.promptCourseDetails();
        if (!courseDetails) {
          return false;
        }
        const folderPath = yield this.createCourseFolderStructure(courseDetails);
        yield this.createCourseHomepageNote(courseDetails, folderPath);
        yield this.createAttachmentsFolder(folderPath);
        new import_obsidian4.Notice(`Course "${courseDetails.courseName}" created successfully!`);
        console.log(
          `Course created: ${courseDetails.courseName} at ${folderPath}`
        );
        return true;
      } catch (error) {
        console.error("Error creating course:", error);
        new import_obsidian4.Notice(`Error creating course: ${error.message}`);
        return false;
      }
    });
  }
  promptCourseDetails() {
    return __async(this, null, function* () {
      var _a;
      try {
        const courseName = yield this.promptWithValidation(
          "Course Name",
          "Enter course name (e.g., PSI-101 - Intro to Psychology)",
          (value) => value.trim().length > 0,
          "Course name is required"
        );
        if (!courseName)
          return null;
        const courseSeason = yield this.promptWithOptions(
          "Season",
          "Select semester/season",
          ["Fall", "Winter", "Spring", "Summer"]
        );
        if (!courseSeason)
          return null;
        const courseYear = yield this.promptWithValidation(
          "Year",
          "Enter academic year (e.g., 2025)",
          (value) => /^\d{4}$/.test(value.trim()),
          "Please enter a valid 4-digit year"
        );
        if (!courseYear)
          return null;
        const courseId = ((_a = courseName.split(" - ")[0]) == null ? void 0 : _a.trim()) || slugify(courseName);
        return {
          courseName,
          courseSeason,
          courseYear,
          courseId
        };
      } catch (error) {
        console.error("Error prompting for course details:", error);
        return null;
      }
    });
  }
  promptWithValidation(title, message, validator, errorMessage) {
    return __async(this, null, function* () {
      return new Promise((resolve) => {
        const modal = new InputModal(this.app, (result) => {
          if (result === null) {
            resolve(null);
            return;
          }
          if (!validator(result)) {
            new import_obsidian4.Notice(errorMessage);
            this.promptWithValidation(title, message, validator, errorMessage).then(resolve);
            return;
          }
          resolve(result.trim());
        });
        modal.titleEl.setText(title);
        const messageEl = modal.contentEl.createDiv();
        messageEl.setText(message);
        modal.open();
      });
    });
  }
  promptWithOptions(title, message, options) {
    return __async(this, null, function* () {
      return new Promise((resolve) => {
        const modal = new SuggesterModal(this.app, options, (result) => {
          if (result === null) {
            resolve(null);
            return;
          }
          if (options.includes(result)) {
            resolve(result);
          } else {
            new import_obsidian4.Notice(`Please select one of: ${options.join(", ")}`);
            this.promptWithOptions(title, message, options).then(resolve);
          }
        });
        modal.titleEl.setText(title);
        const messageEl = modal.contentEl.createDiv();
        messageEl.setText(message);
        modal.open();
      });
    });
  }
  createCourseFolderStructure(courseDetails) {
    return __async(this, null, function* () {
      const folderPath = `${courseDetails.courseYear}/${courseDetails.courseSeason}/${courseDetails.courseName}`;
      try {
        yield this.app.vault.createFolder(folderPath);
        console.log(`Created course folder: ${folderPath}`);
        return folderPath;
      } catch (error) {
        console.log(`Course folder already exists or created: ${folderPath}`);
        return folderPath;
      }
    });
  }
  createCourseHomepageNote(courseDetails, folderPath) {
    return __async(this, null, function* () {
      const notePath = `${folderPath}/${courseDetails.courseName}.md`;
      const content = this.generateCourseHomepageContent(courseDetails);
      try {
        yield this.app.vault.create(notePath, content);
        console.log(`Created course homepage: ${notePath}`);
      } catch (error) {
        console.error(`Error creating course homepage: ${error}`);
        throw error;
      }
    });
  }
  createAttachmentsFolder(folderPath) {
    return __async(this, null, function* () {
      const attachmentsPath = `${folderPath}/Attachments`;
      try {
        yield this.app.vault.createFolder(attachmentsPath);
        console.log(`Created attachments folder: ${attachmentsPath}`);
      } catch (error) {
        console.log(`Attachments folder already exists: ${attachmentsPath}`);
      }
    });
  }
  generateCourseHomepageContent(courseDetails) {
    const templateManager = new TemplateManager(this.app, this.settings);
    const templateContent = templateManager.generateCourseHomepageTemplate();
    return templateContent.replace("<% courseName %>", courseDetails.courseName).replace("<% courseSeason %>", courseDetails.courseSeason).replace("<% courseYear %>", courseDetails.courseYear).replace("<% courseId %>", courseDetails.courseId).replace('<% tp.date.now("YYYY-MM-DD[T]HH:mm:ssZ") %>', new Date().toISOString()).replace(/<% tp\.date\.now\("YYYY-MM-DD\[T\]hh:mm:SSSSZZ"\) %>/g, new Date().toISOString());
  }
};

// vocabulary.ts
var import_obsidian5 = require("obsidian");
var VocabularyExtractor = class {
  constructor(app) {
    this.app = app;
  }
  extractVocabularyFromNote(content) {
    const vocabRegex = /^#+ Vocabulary.*\n((?:.*?\n)*?)(?=^\s*#\s|$)/m;
    const vocabMatches = content == null ? void 0 : content.match(vocabRegex);
    if (vocabMatches) {
      const vocabData = vocabMatches[1].trim();
      const cleanedVocab = vocabData.replace(/\[\[.*?\]\]/g, "").replace(/^\s*-\s*/gm, "").split("\n").map((term) => term.trim()).filter((term) => term.length > 0);
      return cleanedVocab;
    }
    return [];
  }
  extractVocabularyFromCourse(courseId) {
    return __async(this, null, function* () {
      console.log(`Extracting vocabulary for course: ${courseId}`);
      try {
        const courseNotes = yield this.findCourseNotes(courseId);
        if (courseNotes.length === 0) {
          console.log(`No notes found for course: ${courseId}`);
          return {};
        }
        const vocabularyData = {};
        for (const note of courseNotes) {
          try {
            const content = yield this.app.vault.read(note);
            const vocabulary = this.extractVocabularyFromNote(content);
            if (vocabulary.length > 0) {
              vocabularyData[note.basename] = vocabulary;
            }
          } catch (error) {
            console.error(`Error reading note ${note.path}:`, error);
          }
        }
        console.log(
          `Extracted vocabulary from ${Object.keys(vocabularyData).length} notes for course: ${courseId}`
        );
        return vocabularyData;
      } catch (error) {
        console.error(
          `Error extracting vocabulary for course ${courseId}:`,
          error
        );
        return {};
      }
    });
  }
  findCourseNotes(courseId) {
    return __async(this, null, function* () {
      const notes = [];
      const files = this.app.vault.getMarkdownFiles();
      for (const file of files) {
        if (file.path.includes(courseId) || (yield this.noteBelongsToCourse(file, courseId))) {
          notes.push(file);
        }
      }
      return notes;
    });
  }
  noteBelongsToCourse(file, courseId) {
    return __async(this, null, function* () {
      try {
        const content = yield this.app.vault.read(file);
        const frontmatterMatch = content.match(/^---\n([\s\S]*?)\n---/);
        if (frontmatterMatch) {
          const frontmatter = frontmatterMatch[1];
          return frontmatter.includes(`course_id: ${courseId}`) || frontmatter.includes(`course_id:${courseId}`);
        }
        return false;
      } catch (error) {
        console.error(
          `Error checking if note ${file.path} belongs to course ${courseId}:`,
          error
        );
        return false;
      }
    });
  }
  generateVocabularyIndex(courseId, vocabularyData) {
    return __async(this, null, function* () {
      const allTerms = [];
      const termSources = {};
      for (const [noteName, terms] of Object.entries(vocabularyData)) {
        for (const term of terms) {
          if (!allTerms.includes(term)) {
            allTerms.push(term);
            termSources[term] = [];
          }
          termSources[term].push(noteName);
        }
      }
      allTerms.sort();
      let content = `# Vocabulary Index - ${courseId}

`;
      content += `Total unique terms: ${allTerms.length}

`;
      for (const term of allTerms) {
        content += `## ${term}
`;
        content += `**Sources:** ${termSources[term].join(", ")}

`;
        content += `**Definition:**

`;
        content += `**Context:**

`;
        content += `**Examples:**

`;
        content += `---

`;
      }
      return content;
    });
  }
  createVocabularyIndexFile(courseId) {
    return __async(this, null, function* () {
      try {
        const vocabularyData = yield this.extractVocabularyFromCourse(courseId);
        if (Object.keys(vocabularyData).length === 0) {
          console.log(`No vocabulary found for course: ${courseId}`);
          return;
        }
        const indexContent = yield this.generateVocabularyIndex(
          courseId,
          vocabularyData
        );
        const fileName = `${courseId} - Vocabulary Index.md`;
        const filePath = `Courses/${courseId}/${fileName}`;
        try {
          yield this.app.vault.create(filePath, indexContent);
          console.log(`Created vocabulary index file: ${filePath}`);
        } catch (error) {
          const existingFile = this.app.vault.getAbstractFileByPath(filePath);
          if (existingFile && existingFile instanceof import_obsidian5.TFile) {
            yield this.app.vault.modify(existingFile, indexContent);
            console.log(`Updated vocabulary index file: ${filePath}`);
          }
        }
      } catch (error) {
        console.error(
          `Error creating vocabulary index for course ${courseId}:`,
          error
        );
        throw error;
      }
    });
  }
};

// dueDates.ts
var import_obsidian6 = require("obsidian");
var DueDatesParser = class {
  constructor(app) {
    this.app = app;
  }
  parseDueDatesFromNote(content) {
    const dueDatesRegex = /# Due Dates[\s\S]*?(?=\n#|$)/;
    const matches = content == null ? void 0 : content.match(dueDatesRegex);
    if (!matches) {
      return [];
    }
    const dueDatesSection = matches[0];
    const dueDates = [];
    const tableRegex = /\|[\s\S]*?\n/g;
    const tableMatches = dueDatesSection.match(tableRegex);
    if (tableMatches) {
      for (const table of tableMatches) {
        const rows = table.trim().split("\n").filter((row) => row.startsWith("|"));
        const parsedRows = this.parseTableRows(rows);
        dueDates.push(...parsedRows);
      }
    }
    return dueDates;
  }
  parseTableRows(rows) {
    if (rows.length < 2)
      return [];
    const dueDates = [];
    for (let i = 1; i < rows.length; i++) {
      const row = rows[i];
      const columns = row.split("|").map((col) => col.trim()).filter((col) => col);
      if (columns.length >= 2) {
        const [date, assignment, status = "pending"] = columns;
        if (date && assignment && this.isValidDate(date)) {
          dueDates.push({ date, assignment, status });
        }
      }
    }
    return dueDates;
  }
  isValidDate(dateString) {
    const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
    return dateRegex.test(dateString) && !isNaN(Date.parse(dateString));
  }
  parseDueDatesFromCourse(courseId, startDate, endDate) {
    return __async(this, null, function* () {
      console.log(`Parsing due dates for course: ${courseId}`);
      try {
        const courseNotes = yield this.findCourseNotes(courseId);
        if (courseNotes.length === 0) {
          console.log(`No notes found for course: ${courseId}`);
          return [];
        }
        const allDueDates = [];
        for (const note of courseNotes) {
          try {
            const content = yield this.app.vault.read(note);
            const dueDates = this.parseDueDatesFromNote(content);
            const dueDatesWithSource = dueDates.map((dueDate) => __spreadProps(__spreadValues({}, dueDate), {
              source: note.basename
            }));
            allDueDates.push(...dueDatesWithSource);
          } catch (error) {
            console.error(`Error reading note ${note.path}:`, error);
          }
        }
        let filteredDueDates = allDueDates;
        if (startDate || endDate) {
          filteredDueDates = this.filterByDateRange(
            allDueDates,
            startDate,
            endDate
          );
        }
        filteredDueDates.sort(
          (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()
        );
        console.log(
          `Found ${filteredDueDates.length} due dates for course: ${courseId}`
        );
        return filteredDueDates;
      } catch (error) {
        console.error(`Error parsing due dates for course ${courseId}:`, error);
        return [];
      }
    });
  }
  findCourseNotes(courseId) {
    return __async(this, null, function* () {
      const notes = [];
      const files = this.app.vault.getMarkdownFiles();
      for (const file of files) {
        if (file.path.includes(courseId) || (yield this.noteBelongsToCourse(file, courseId))) {
          notes.push(file);
        }
      }
      return notes;
    });
  }
  noteBelongsToCourse(file, courseId) {
    return __async(this, null, function* () {
      try {
        const content = yield this.app.vault.read(file);
        const frontmatterMatch = content.match(/^---\n([\s\S]*?)\n---/);
        if (frontmatterMatch) {
          const frontmatter = frontmatterMatch[1];
          return frontmatter.includes(`course_id: ${courseId}`) || frontmatter.includes(`course_id:${courseId}`);
        }
        return false;
      } catch (error) {
        console.error(
          `Error checking if note ${file.path} belongs to course ${courseId}:`,
          error
        );
        return false;
      }
    });
  }
  filterByDateRange(dueDates, startDate, endDate) {
    return dueDates.filter((dueDate) => {
      const dueDateTime = new Date(dueDate.date).getTime();
      if (startDate && dueDateTime < new Date(startDate).getTime()) {
        return false;
      }
      if (endDate && dueDateTime > new Date(endDate).getTime()) {
        return false;
      }
      return true;
    });
  }
  generateDueDatesSummary(courseId, dueDates) {
    return __async(this, null, function* () {
      if (dueDates.length === 0) {
        return `# Due Dates Summary - ${courseId}

No due dates found.
`;
      }
      const byStatus = dueDates.reduce((acc, dueDate) => {
        if (!acc[dueDate.status]) {
          acc[dueDate.status] = [];
        }
        acc[dueDate.status].push(dueDate);
        return acc;
      }, {});
      let content = `# Due Dates Summary - ${courseId}

`;
      content += `Total assignments: ${dueDates.length}

`;
      for (const [status, items] of Object.entries(byStatus)) {
        content += `## ${status.charAt(0).toUpperCase() + status.slice(1)} (${items.length})

`;
        content += `| Date | Assignment | Source |
`;
        content += `| ---- | ---------- | ------ |
`;
        for (const item of items) {
          content += `| ${item.date} | ${item.assignment} | ${item.source} |
`;
        }
        content += `
`;
      }
      return content;
    });
  }
  createDueDatesSummaryFile(courseId, startDate, endDate) {
    return __async(this, null, function* () {
      try {
        const dueDates = yield this.parseDueDatesFromCourse(
          courseId,
          startDate,
          endDate
        );
        const summaryContent = yield this.generateDueDatesSummary(
          courseId,
          dueDates
        );
        const fileName = `${courseId} - Due Dates Summary.md`;
        const filePath = `Courses/${courseId}/${fileName}`;
        try {
          yield this.app.vault.create(filePath, summaryContent);
          console.log(`Created due dates summary file: ${filePath}`);
        } catch (error) {
          const existingFile = this.app.vault.getAbstractFileByPath(filePath);
          if (existingFile && existingFile instanceof import_obsidian6.TFile) {
            yield this.app.vault.modify(existingFile, summaryContent);
            console.log(`Updated due dates summary file: ${filePath}`);
          }
        }
      } catch (error) {
        console.error(
          `Error creating due dates summary for course ${courseId}:`,
          error
        );
        throw error;
      }
    });
  }
};

// dailyNotes.ts
var import_obsidian7 = require("obsidian");
var DailyNotesIntegration = class {
  constructor(app) {
    this.app = app;
  }
  getTodaysActivities() {
    return __async(this, null, function* () {
      console.log("Getting today's academic activities");
      try {
        const today = new Date();
        const todayString = today.toISOString().split("T")[0];
        const files = this.app.vault.getMarkdownFiles();
        const todaysFiles = [];
        for (const file of files) {
          const fileDate = this.extractDateFromPath(file.path);
          if (fileDate === todayString) {
            todaysFiles.push(file);
          }
        }
        const activities = [];
        for (const file of todaysFiles) {
          const activity = yield this.analyzeFileActivity(file);
          if (activity) {
            activities.push(activity);
          }
        }
        console.log(`Found ${activities.length} academic activities for today`);
        return activities;
      } catch (error) {
        console.error("Error getting today's activities:", error);
        return [];
      }
    });
  }
  getCourseActivityForDate(courseId, date) {
    return __async(this, null, function* () {
      console.log(`Getting activity for course ${courseId} on date ${date}`);
      try {
        const courseFiles = yield this.findCourseFilesForDate(courseId, date);
        const activities = [];
        for (const file of courseFiles) {
          const content = yield this.app.vault.read(file);
          const fileType = this.determineFileType(file, content);
          activities.push({
            file: file.basename,
            type: fileType
          });
        }
        console.log(
          `Found ${activities.length} activities for course ${courseId} on ${date}`
        );
        return activities;
      } catch (error) {
        console.error(
          `Error getting course activity for ${courseId} on ${date}:`,
          error
        );
        return [];
      }
    });
  }
  extractDateFromPath(filePath) {
    const dateRegex = /(\d{4}-\d{2}-\d{2})/g;
    const matches = filePath.match(dateRegex);
    return matches ? matches[matches.length - 1] : null;
  }
  analyzeFileActivity(file) {
    return __async(this, null, function* () {
      try {
        const content = yield this.app.vault.read(file);
        const fileType = this.determineFileType(file, content);
        const courseId = this.extractCourseIdFromContent(content) || this.extractCourseIdFromPath(file.path);
        return {
          file: file.basename,
          type: fileType,
          course: courseId || void 0
        };
      } catch (error) {
        console.error(`Error analyzing file ${file.path}:`, error);
        return null;
      }
    });
  }
  determineFileType(file, content) {
    const path = file.path.toLowerCase();
    if (path.includes("daily") || content.includes("content_type: daily_note")) {
      return "daily_note";
    }
    if (path.includes("courses") || content.includes("course_id:")) {
      if (content.includes("content_type: course_homepage")) {
        return "course_homepage";
      }
      if (content.includes("content_type: module")) {
        return "module";
      }
      if (content.includes("content_type: chapter")) {
        return "chapter";
      }
      if (content.includes("content_type: assignment")) {
        return "assignment";
      }
      return "course_note";
    }
    if (content.includes("## ") && content.match(/^\*\*Term\*\*:/m)) {
      return "vocabulary_entry";
    }
    return "other";
  }
  extractCourseIdFromContent(content) {
    const courseIdRegex = /course_id:\s*([A-Z]{2,4}-\d{3})/;
    const match = content.match(courseIdRegex);
    return match ? match[1] : null;
  }
  extractCourseIdFromPath(filePath) {
    const courseIdRegex = /([A-Z]{2,4}-\d{3})/g;
    const matches = filePath.match(courseIdRegex);
    return matches ? matches[matches.length - 1] : null;
  }
  findCourseFilesForDate(courseId, date) {
    return __async(this, null, function* () {
      const files = [];
      const allFiles = this.app.vault.getMarkdownFiles();
      for (const file of allFiles) {
        if (file.path.includes(courseId) || (yield this.fileBelongsToCourse(file, courseId))) {
          const fileDate = this.extractDateFromPath(file.path);
          if (fileDate === date) {
            files.push(file);
          }
        }
      }
      return files;
    });
  }
  fileBelongsToCourse(file, courseId) {
    return __async(this, null, function* () {
      try {
        const content = yield this.app.vault.read(file);
        return this.extractCourseIdFromContent(content) === courseId;
      } catch (error) {
        console.error(
          `Error checking if file ${file.path} belongs to course ${courseId}:`,
          error
        );
        return false;
      }
    });
  }
  generateDailySummary(date) {
    return __async(this, null, function* () {
      const targetDate = date || new Date().toISOString().split("T")[0];
      const activities = yield this.getCourseActivityForDate("", targetDate);
      if (activities.length === 0) {
        return `# Academic Activities - ${targetDate}

No academic activities recorded for this date.
`;
      }
      const byCourse = {};
      const noCourse = [];
      for (const activity of activities) {
        if (activity.file.includes("Courses/")) {
          const pathParts = activity.file.split("/");
          const courseIndex = pathParts.findIndex((part) => part.includes("-"));
          if (courseIndex >= 0) {
            const courseId = pathParts[courseIndex];
            if (!byCourse[courseId]) {
              byCourse[courseId] = [];
            }
            byCourse[courseId].push(activity);
          } else {
            noCourse.push(activity);
          }
        } else {
          noCourse.push(activity);
        }
      }
      let content = `# Academic Activities - ${targetDate}

`;
      content += `Total activities: ${activities.length}

`;
      for (const [courseId, courseActivities] of Object.entries(byCourse)) {
        content += `## ${courseId}

`;
        content += `| File | Type |
`;
        content += `| ---- | ---- |
`;
        for (const activity of courseActivities) {
          content += `| ${activity.file} | ${activity.type} |
`;
        }
        content += `
`;
      }
      if (noCourse.length > 0) {
        content += `## Other Activities

`;
        content += `| File | Type |
`;
        content += `| ---- | ---- |
`;
        for (const activity of noCourse) {
          content += `| ${activity.file} | ${activity.type} |
`;
        }
        content += `
`;
      }
      return content;
    });
  }
  createDailySummaryFile(date) {
    return __async(this, null, function* () {
      try {
        const targetDate = date || new Date().toISOString().split("T")[0];
        const summaryContent = yield this.generateDailySummary(targetDate);
        const fileName = `${targetDate} - Academic Summary.md`;
        const filePath = `Daily/${fileName}`;
        try {
          yield this.app.vault.create(filePath, summaryContent);
          console.log(`Created daily summary file: ${filePath}`);
        } catch (error) {
          const existingFile = this.app.vault.getAbstractFileByPath(filePath);
          if (existingFile && existingFile instanceof import_obsidian7.TFile) {
            yield this.app.vault.modify(existingFile, summaryContent);
            console.log(`Updated daily summary file: ${filePath}`);
          }
        }
      } catch (error) {
        console.error(`Error creating daily summary for ${date}:`, error);
        throw error;
      }
    });
  }
};

// assignmentsModal.ts
var import_obsidian8 = require("obsidian");
var AssignmentsModal = class extends import_obsidian8.Modal {
  constructor(app, courseName, courseId, onSubmit) {
    super(app);
    this.assignments = [{ name: "", dueDate: "", type: "", points: "", description: "" }];
    this.courseName = courseName;
    this.courseId = courseId;
    this.onSubmit = onSubmit;
  }
  onOpen() {
    const { contentEl } = this;
    contentEl.empty();
    contentEl.addClass("tuckers-tools-assignments-modal");
    contentEl.createEl("h2", { text: "Create Multiple Assignments" });
    new import_obsidian8.Setting(contentEl).setName("Course").setDesc(`${this.courseName} (${this.courseId})`).setDisabled(true);
    const assignmentsContainer = contentEl.createDiv({ cls: "assignments-container" });
    this.addAssignmentSection(assignmentsContainer, 0);
    new import_obsidian8.Setting(contentEl).addButton(
      (btn) => btn.setButtonText("Add Assignment").setCta().onClick(() => {
        const newIndex = this.assignments.length;
        this.assignments.push({ name: "", dueDate: "", type: "", points: "", description: "" });
        this.addAssignmentSection(assignmentsContainer, newIndex);
      })
    );
    new import_obsidian8.Setting(contentEl).addButton(
      (btn) => btn.setButtonText("Create Assignments").setCta().onClick(() => {
        const validAssignments = this.assignments.filter(
          (a) => a.name.trim() !== "" || a.dueDate.trim() !== ""
        );
        this.onSubmit(validAssignments, this.courseName, this.courseId);
        this.close();
      })
    );
  }
  addAssignmentSection(container, index) {
    const section = container.createDiv({ cls: "assignment-section" });
    section.createEl("h3", { text: `Assignment #${index + 1}` });
    new import_obsidian8.Setting(section).setName("Assignment Name").addText(
      (text) => text.setPlaceholder("Enter assignment name").setValue(this.assignments[index].name).onChange((value) => {
        this.assignments[index].name = value;
      })
    );
    new import_obsidian8.Setting(section).setName("Due Date").setDesc("Format: YYYY-MM-DD").addText(
      (text) => text.setPlaceholder("2024-01-15").setValue(this.assignments[index].dueDate).onChange((value) => {
        this.assignments[index].dueDate = value;
      })
    );
    new import_obsidian8.Setting(section).setName("Assignment Type").addText(
      (text) => text.setPlaceholder("e.g., Homework, Quiz, Exam").setValue(this.assignments[index].type).onChange((value) => {
        this.assignments[index].type = value;
      })
    );
    new import_obsidian8.Setting(section).setName("Points").addText(
      (text) => text.setPlaceholder("e.g., 100").setValue(this.assignments[index].points).onChange((value) => {
        this.assignments[index].points = value;
      })
    );
    new import_obsidian8.Setting(section).setName("Description").addTextArea(
      (text) => text.setPlaceholder("Enter assignment description").setValue(this.assignments[index].description).onChange((value) => {
        this.assignments[index].description = value;
      })
    );
    if (this.assignments.length > 1) {
      new import_obsidian8.Setting(section).addButton(
        (btn) => btn.setButtonText("Remove").onClick(() => {
          this.assignments.splice(index, 1);
          section.remove();
          this.renumberAssignments();
        })
      );
    }
  }
  renumberAssignments() {
    const sections = this.contentEl.querySelectorAll(".assignment-section");
    sections.forEach((section, index) => {
      const header = section.querySelector("h3");
      if (header) {
        header.textContent = `Assignment #${index + 1}`;
      }
    });
  }
  onClose() {
    const { contentEl } = this;
    contentEl.empty();
  }
};

// main.ts
var TuckersToolsPlugin = class extends import_obsidian9.Plugin {
  onload() {
    return __async(this, null, function* () {
      console.log("Loading Tuckers Tools plugin");
      yield this.loadSettings();
      this.templateManager = new TemplateManager(this.app, this.settings);
      this.courseWizard = new CourseCreationWizard(this.app, this.settings);
      this.vocabularyExtractor = new VocabularyExtractor(this.app);
      this.dueDatesParser = new DueDatesParser(this.app);
      this.dailyNotesIntegration = new DailyNotesIntegration(this.app);
      this.addSettingTab(new TuckersToolsSettingTab(this.app, this));
      this.initializeTemplaterFunctions();
      this.addCommand({
        id: "install-templates",
        name: "Install/Update Tuckers Tools Templates",
        callback: () => {
          this.templateManager.installTemplates();
        }
      });
      this.addCommand({
        id: "update-templates",
        name: "Update Tuckers Tools Templates",
        callback: () => {
          this.templateManager.updateTemplates();
        }
      });
      this.addCommand({
        id: "create-course",
        name: "Create New Course",
        callback: () => {
          this.courseWizard.createCourseHomepage();
        }
      });
      this.addCommand({
        id: "create-multiple-assignments",
        name: "Create Multiple Assignments for Course",
        callback: () => __async(this, null, function* () {
          const currentFile = this.app.workspace.getActiveFile();
          let courseId = "";
          let courseName = "";
          if (currentFile) {
            const cache = this.app.metadataCache.getFileCache(currentFile);
            if (cache && cache.frontmatter) {
              courseId = cache.frontmatter.course_id || "";
              courseName = cache.frontmatter.course_name || cache.frontmatter.title || currentFile.basename;
            }
          }
          if (!courseId) {
            const promptedCourseId = yield this.promptForCourseId("Enter course ID for assignments");
            if (!promptedCourseId)
              return;
            courseId = promptedCourseId;
            courseName = courseId;
          }
          new AssignmentsModal(
            this.app,
            courseName,
            courseId,
            (assignments, courseName2, courseId2) => __async(this, null, function* () {
              for (const assignment of assignments) {
                if (assignment.name.trim() === "")
                  continue;
                const assignmentContent = this.generateAssignmentFileContent(
                  assignment,
                  courseName2,
                  courseId2
                );
                const fileName = `${courseId2} - ${assignment.name.replace(/[<>:"/\\|?*]/g, "_")}.md`;
                const filePath = `${courseId2}/${fileName}`;
                try {
                  yield this.app.vault.create(filePath, assignmentContent);
                  console.log(`Created assignment file: ${filePath}`);
                } catch (error) {
                  console.error(`Error creating assignment file ${filePath}:`, error);
                }
              }
            })
          ).open();
        })
      });
      this.addCommand({
        id: "extract-vocabulary",
        name: "Extract Course Vocabulary",
        callback: () => __async(this, null, function* () {
          const courseId = yield this.promptForCourseId(
            "Enter course ID to extract vocabulary from"
          );
          if (courseId) {
            yield this.vocabularyExtractor.createVocabularyIndexFile(courseId);
          }
        })
      });
      this.addCommand({
        id: "generate-due-dates-summary",
        name: "Generate Due Dates Summary",
        callback: () => __async(this, null, function* () {
          const courseId = yield this.promptForCourseId(
            "Enter course ID to generate due dates summary for"
          );
          if (courseId) {
            yield this.dueDatesParser.createDueDatesSummaryFile(courseId);
          }
        })
      });
      this.addCommand({
        id: "generate-daily-summary",
        name: "Generate Daily Academic Summary",
        callback: () => __async(this, null, function* () {
          const date = yield this.promptForDate(
            "Enter date (YYYY-MM-DD) or leave empty for today"
          );
          yield this.dailyNotesIntegration.createDailySummaryFile(
            date || void 0
          );
        })
      });
      this.addStatusBarItem().setText("Tuckers Tools");
    });
  }
  promptForCourseId(message) {
    return __async(this, null, function* () {
      const courseId = prompt(message + "\n\nExample: PSI-101");
      return courseId ? courseId.trim() : null;
    });
  }
  promptForDate(message) {
    return __async(this, null, function* () {
      const date = prompt(
        message + "\n\nExample: 2025-01-15 or leave empty for today"
      );
      return date ? date.trim() : null;
    });
  }
  generateAssignmentFileContent(assignment, courseName, courseId) {
    return `---
course_id: ${courseId}
assignment_type: ${assignment.type || "Assignment"}
due_date: ${assignment.dueDate}
points: ${assignment.points || ""}
content_type: assignment
created: ${new Date().toISOString()}
status: pending
tags:
  - education
  - ${courseId}
  - assignment
---

# ${assignment.name} - ${courseId}

## Description
${assignment.description}

## Instructions


## Due Date
**Assigned**: ${new Date().toISOString().split("T")[0]}
**Due**: ${assignment.dueDate}

## Submission


## Grading Criteria


## Resources


# Due Dates
| ${assignment.dueDate} | ${assignment.name} | pending |
`;
  }
  onunload() {
    console.log("Unloading Tuckers Tools plugin");
  }
  initializeTemplaterFunctions() {
    return __async(this, null, function* () {
      const templaterPlugin = this.app.plugins.getPlugin("templater-obsidian");
      if (!templaterPlugin) {
        console.log("Templater plugin not found. Course templates will not work properly.");
        return;
      }
      try {
        if (templaterPlugin && templaterPlugin.templater) {
          if (!templaterPlugin.templater.functions) {
            templaterPlugin.templater.functions = {};
          }
          templaterPlugin.templater.functions["new_module"] = (app, tp, year) => __async(this, null, function* () {
            return this.newModuleFunction(app, tp, year);
          });
          templaterPlugin.templater.functions["new_chapter"] = (tp) => __async(this, null, function* () {
            return this.newChapterFunction(tp);
          });
          console.log("Tuckers Tools templater functions registered successfully");
        } else {
          console.error("Could not register templater functions - templater object not found");
        }
      } catch (e) {
        console.error("Error registering templater functions:", e);
      }
    });
  }
  newModuleFunction(app, tp, year) {
    return __async(this, null, function* () {
      var _a;
      let moduleNumber = "";
      let weekNumber = "";
      let course = "";
      let courseId = "";
      let discipline = "GEN";
      let dayOfWeek = "";
      try {
        if (tp && tp.system && tp.system.prompt) {
          const tempModuleNumber = yield tp.system.prompt("Module Number (optional)", "");
          moduleNumber = tempModuleNumber ? tempModuleNumber : null;
          const tempWeekNumber = yield tp.system.prompt("Week Number (optional)", "");
          weekNumber = tempWeekNumber ? tempWeekNumber : null;
          course = yield tp.system.suggester(
            () => app.vault.getMarkdownFiles().filter((f) => f.path.includes("Courses")).map((f) => f.basename),
            app.vault.getMarkdownFiles().filter((f) => f.path.includes("Courses"))
          );
          dayOfWeek = yield tp.system.suggester(
            ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
            ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
            "Day of Week"
          );
        } else {
          moduleNumber = null;
          weekNumber = null;
          course = "New Course";
          dayOfWeek = "Monday";
        }
      } catch (e) {
        console.error("Error in new_module prompts:", e);
        moduleNumber = null;
        weekNumber = null;
        course = "New Course";
        dayOfWeek = "Monday";
      }
      courseId = course ? course.split(" - ")[0] || course : "";
      discipline = course ? ((_a = course.split(" - ")[0]) == null ? void 0 : _a.substring(0, 3)) || "GEN" : "GEN";
      return {
        season: "Fall",
        // This would normally be dynamically determined
        moduleNumber,
        weekNumber,
        course,
        courseId,
        discipline,
        dayOfWeek
      };
    });
  }
  newChapterFunction(tp) {
    return __async(this, null, function* () {
      var _a;
      let chapterNumber = "";
      let course = "";
      let courseId = "";
      let discipline = "GEN";
      let text = "";
      try {
        if (tp && tp.system && tp.system.prompt) {
          chapterNumber = (yield tp.system.prompt("Chapter Number", "")) || "";
          course = yield tp.system.suggester(
            () => tp.app.vault.getMarkdownFiles().filter((f) => f.path.includes("Courses")).map((f) => f.basename),
            tp.app.vault.getMarkdownFiles().filter((f) => f.path.includes("Courses"))
          );
          const textOptions = tp.app.vault.getFiles().filter((f) => f.extension === "pdf").map((f) => f.basename);
          text = yield tp.system.suggester(textOptions, textOptions, "Textbook");
        } else {
          chapterNumber = "";
          course = "New Course";
          text = "New Textbook";
        }
      } catch (e) {
        console.error("Error in new_chapter prompts:", e);
        chapterNumber = "";
        course = "New Course";
        text = "New Textbook";
      }
      courseId = course ? course.split(" - ")[0] || course : "";
      discipline = course ? ((_a = course.split(" - ")[0]) == null ? void 0 : _a.substring(0, 3)) || "GEN" : "GEN";
      return {
        chapterNumber,
        course,
        courseId,
        discipline,
        text
      };
    });
  }
  loadSettings() {
    return __async(this, null, function* () {
      this.settings = Object.assign({}, DEFAULT_SETTINGS, yield this.loadData());
    });
  }
  saveSettings() {
    return __async(this, null, function* () {
      yield this.saveData(this.settings);
    });
  }
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsibWFpbi50cyIsICJzZXR0aW5ncy50cyIsICJ1dGlscy50cyIsICJ0ZW1wbGF0ZU1hbmFnZXIudHMiLCAiY291cnNlV2l6YXJkLnRzIiwgImlucHV0TW9kYWwudHMiLCAidm9jYWJ1bGFyeS50cyIsICJkdWVEYXRlcy50cyIsICJkYWlseU5vdGVzLnRzIiwgImFzc2lnbm1lbnRzTW9kYWwudHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbImltcG9ydCB7IFBsdWdpbiB9IGZyb20gXCJvYnNpZGlhblwiXG5pbXBvcnQge1xuICBUdWNrZXJzVG9vbHNTZXR0aW5ncyxcbiAgREVGQVVMVF9TRVRUSU5HUyxcbiAgVHVja2Vyc1Rvb2xzU2V0dGluZ1RhYlxufSBmcm9tIFwiLi9zZXR0aW5nc1wiXG5pbXBvcnQgeyBUZW1wbGF0ZU1hbmFnZXIgfSBmcm9tIFwiLi90ZW1wbGF0ZU1hbmFnZXJcIlxuaW1wb3J0IHsgQ291cnNlQ3JlYXRpb25XaXphcmQgfSBmcm9tIFwiLi9jb3Vyc2VXaXphcmRcIlxuaW1wb3J0IHsgVm9jYWJ1bGFyeUV4dHJhY3RvciB9IGZyb20gXCIuL3ZvY2FidWxhcnlcIlxuaW1wb3J0IHsgRHVlRGF0ZXNQYXJzZXIgfSBmcm9tIFwiLi9kdWVEYXRlc1wiXG5pbXBvcnQgeyBEYWlseU5vdGVzSW50ZWdyYXRpb24gfSBmcm9tIFwiLi9kYWlseU5vdGVzXCJcbmltcG9ydCB7IEFzc2lnbm1lbnRzTW9kYWwgfSBmcm9tIFwiLi9hc3NpZ25tZW50c01vZGFsXCJcblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgVHVja2Vyc1Rvb2xzUGx1Z2luIGV4dGVuZHMgUGx1Z2luIHtcbiAgc2V0dGluZ3M6IFR1Y2tlcnNUb29sc1NldHRpbmdzXG4gIHRlbXBsYXRlTWFuYWdlcjogVGVtcGxhdGVNYW5hZ2VyXG4gIGNvdXJzZVdpemFyZDogQ291cnNlQ3JlYXRpb25XaXphcmRcbiAgdm9jYWJ1bGFyeUV4dHJhY3RvcjogVm9jYWJ1bGFyeUV4dHJhY3RvclxuICBkdWVEYXRlc1BhcnNlcjogRHVlRGF0ZXNQYXJzZXJcbiAgZGFpbHlOb3Rlc0ludGVncmF0aW9uOiBEYWlseU5vdGVzSW50ZWdyYXRpb25cblxuICBhc3luYyBvbmxvYWQoKSB7XG4gICAgY29uc29sZS5sb2coXCJMb2FkaW5nIFR1Y2tlcnMgVG9vbHMgcGx1Z2luXCIpXG5cbiAgICAvLyBMb2FkIHNldHRpbmdzXG4gICAgYXdhaXQgdGhpcy5sb2FkU2V0dGluZ3MoKVxuXG4gICAgLy8gSW5pdGlhbGl6ZSBjb21wb25lbnRzXG4gICAgdGhpcy50ZW1wbGF0ZU1hbmFnZXIgPSBuZXcgVGVtcGxhdGVNYW5hZ2VyKHRoaXMuYXBwLCB0aGlzLnNldHRpbmdzKVxuICAgIHRoaXMuY291cnNlV2l6YXJkID0gbmV3IENvdXJzZUNyZWF0aW9uV2l6YXJkKHRoaXMuYXBwLCB0aGlzLnNldHRpbmdzKVxuICAgIHRoaXMudm9jYWJ1bGFyeUV4dHJhY3RvciA9IG5ldyBWb2NhYnVsYXJ5RXh0cmFjdG9yKHRoaXMuYXBwKVxuICAgIHRoaXMuZHVlRGF0ZXNQYXJzZXIgPSBuZXcgRHVlRGF0ZXNQYXJzZXIodGhpcy5hcHApXG4gICAgdGhpcy5kYWlseU5vdGVzSW50ZWdyYXRpb24gPSBuZXcgRGFpbHlOb3Rlc0ludGVncmF0aW9uKHRoaXMuYXBwKVxuXG4gICAgLy8gQWRkIHNldHRpbmdzIHRhYlxuICAgIHRoaXMuYWRkU2V0dGluZ1RhYihuZXcgVHVja2Vyc1Rvb2xzU2V0dGluZ1RhYih0aGlzLmFwcCwgdGhpcykpXG5cbiAgICAvLyBJbml0aWFsaXplIHRlbXBsYXRlciBmdW5jdGlvbnMgaWYgdGVtcGxhdGVyIGlzIGF2YWlsYWJsZVxuICAgIHRoaXMuaW5pdGlhbGl6ZVRlbXBsYXRlckZ1bmN0aW9ucygpXG5cbiAgICAvLyBBZGQgY29tbWFuZHNcbiAgICB0aGlzLmFkZENvbW1hbmQoe1xuICAgICAgaWQ6IFwiaW5zdGFsbC10ZW1wbGF0ZXNcIixcbiAgICAgIG5hbWU6IFwiSW5zdGFsbC9VcGRhdGUgVHVja2VycyBUb29scyBUZW1wbGF0ZXNcIixcbiAgICAgIGNhbGxiYWNrOiAoKSA9PiB7XG4gICAgICAgIHRoaXMudGVtcGxhdGVNYW5hZ2VyLmluc3RhbGxUZW1wbGF0ZXMoKVxuICAgICAgfVxuICAgIH0pXG5cbiAgICB0aGlzLmFkZENvbW1hbmQoe1xuICAgICAgaWQ6IFwidXBkYXRlLXRlbXBsYXRlc1wiLFxuICAgICAgbmFtZTogXCJVcGRhdGUgVHVja2VycyBUb29scyBUZW1wbGF0ZXNcIixcbiAgICAgIGNhbGxiYWNrOiAoKSA9PiB7XG4gICAgICAgIHRoaXMudGVtcGxhdGVNYW5hZ2VyLnVwZGF0ZVRlbXBsYXRlcygpXG4gICAgICB9XG4gICAgfSlcblxuICAgIHRoaXMuYWRkQ29tbWFuZCh7XG4gICAgICBpZDogXCJjcmVhdGUtY291cnNlXCIsXG4gICAgICBuYW1lOiBcIkNyZWF0ZSBOZXcgQ291cnNlXCIsXG4gICAgICBjYWxsYmFjazogKCkgPT4ge1xuICAgICAgICB0aGlzLmNvdXJzZVdpemFyZC5jcmVhdGVDb3Vyc2VIb21lcGFnZSgpXG4gICAgICB9XG4gICAgfSlcblxuICAgIHRoaXMuYWRkQ29tbWFuZCh7XG4gICAgICBpZDogXCJjcmVhdGUtbXVsdGlwbGUtYXNzaWdubWVudHNcIixcbiAgICAgIG5hbWU6IFwiQ3JlYXRlIE11bHRpcGxlIEFzc2lnbm1lbnRzIGZvciBDb3Vyc2VcIixcbiAgICAgIGNhbGxiYWNrOiBhc3luYyAoKSA9PiB7XG4gICAgICAgIC8vIEdldCB0aGUgY3VycmVudCBjb3Vyc2UgY29udGV4dCBvciBwcm9tcHQgZm9yIGl0XG4gICAgICAgIGNvbnN0IGN1cnJlbnRGaWxlID0gdGhpcy5hcHAud29ya3NwYWNlLmdldEFjdGl2ZUZpbGUoKTtcbiAgICAgICAgbGV0IGNvdXJzZUlkID0gXCJcIjtcbiAgICAgICAgbGV0IGNvdXJzZU5hbWUgPSBcIlwiO1xuXG4gICAgICAgIC8vIFRyeSB0byBkZXRlcm1pbmUgdGhlIGNvdXJzZSBmcm9tIHRoZSBjdXJyZW50IGZpbGVcbiAgICAgICAgaWYgKGN1cnJlbnRGaWxlKSB7XG4gICAgICAgICAgY29uc3QgY2FjaGUgPSB0aGlzLmFwcC5tZXRhZGF0YUNhY2hlLmdldEZpbGVDYWNoZShjdXJyZW50RmlsZSk7XG4gICAgICAgICAgaWYgKGNhY2hlICYmIGNhY2hlLmZyb250bWF0dGVyKSB7XG4gICAgICAgICAgICBjb3Vyc2VJZCA9IGNhY2hlLmZyb250bWF0dGVyLmNvdXJzZV9pZCB8fCBcIlwiO1xuICAgICAgICAgICAgY291cnNlTmFtZSA9IGNhY2hlLmZyb250bWF0dGVyLmNvdXJzZV9uYW1lIHx8IGNhY2hlLmZyb250bWF0dGVyLnRpdGxlIHx8IGN1cnJlbnRGaWxlLmJhc2VuYW1lO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIC8vIElmIHdlIGNvdWxkbid0IGRldGVybWluZSB0aGUgY291cnNlLCBwcm9tcHQgZm9yIGl0XG4gICAgICAgIGlmICghY291cnNlSWQpIHtcbiAgICAgICAgICBjb25zdCBwcm9tcHRlZENvdXJzZUlkID0gYXdhaXQgdGhpcy5wcm9tcHRGb3JDb3Vyc2VJZChcIkVudGVyIGNvdXJzZSBJRCBmb3IgYXNzaWdubWVudHNcIik7XG4gICAgICAgICAgaWYgKCFwcm9tcHRlZENvdXJzZUlkKSByZXR1cm47XG4gICAgICAgICAgY291cnNlSWQgPSBwcm9tcHRlZENvdXJzZUlkO1xuICAgICAgICAgIGNvdXJzZU5hbWUgPSBjb3Vyc2VJZDsgLy8gRmFsbGJhY2sgaWYgd2UgZG9uJ3QgaGF2ZSBhIGJldHRlciBuYW1lXG4gICAgICAgIH1cblxuICAgICAgICAvLyBTaG93IHRoZSBhc3NpZ25tZW50cyBtb2RhbFxuICAgICAgICBuZXcgQXNzaWdubWVudHNNb2RhbChcbiAgICAgICAgICB0aGlzLmFwcCxcbiAgICAgICAgICBjb3Vyc2VOYW1lLFxuICAgICAgICAgIGNvdXJzZUlkLFxuICAgICAgICAgIGFzeW5jIChhc3NpZ25tZW50cywgY291cnNlTmFtZSwgY291cnNlSWQpID0+IHtcbiAgICAgICAgICAgIC8vIFByb2Nlc3MgdGhlIGFzc2lnbm1lbnRzIC0gZm9yIG5vdywgd2UnbGwgY3JlYXRlIGluZGl2aWR1YWwgYXNzaWdubWVudCBmaWxlc1xuICAgICAgICAgICAgZm9yIChjb25zdCBhc3NpZ25tZW50IG9mIGFzc2lnbm1lbnRzKSB7XG4gICAgICAgICAgICAgIGlmIChhc3NpZ25tZW50Lm5hbWUudHJpbSgpID09PSBcIlwiKSBjb250aW51ZTsgLy8gU2tpcCBlbXB0eSBhc3NpZ25tZW50c1xuXG4gICAgICAgICAgICAgIC8vIENyZWF0ZSBhbiBhc3NpZ25tZW50IGZpbGVcbiAgICAgICAgICAgICAgY29uc3QgYXNzaWdubWVudENvbnRlbnQgPSB0aGlzLmdlbmVyYXRlQXNzaWdubWVudEZpbGVDb250ZW50KFxuICAgICAgICAgICAgICAgIGFzc2lnbm1lbnQsXG4gICAgICAgICAgICAgICAgY291cnNlTmFtZSxcbiAgICAgICAgICAgICAgICBjb3Vyc2VJZFxuICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICBjb25zdCBmaWxlTmFtZSA9IGAke2NvdXJzZUlkfSAtICR7YXNzaWdubWVudC5uYW1lLnJlcGxhY2UoL1s8PjpcIi9cXFxcfD8qXS9nLCBcIl9cIil9Lm1kYDtcbiAgICAgICAgICAgICAgY29uc3QgZmlsZVBhdGggPSBgJHtjb3Vyc2VJZH0vJHtmaWxlTmFtZX1gO1xuXG4gICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgYXdhaXQgdGhpcy5hcHAudmF1bHQuY3JlYXRlKGZpbGVQYXRoLCBhc3NpZ25tZW50Q29udGVudCk7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coYENyZWF0ZWQgYXNzaWdubWVudCBmaWxlOiAke2ZpbGVQYXRofWApO1xuICAgICAgICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIGNyZWF0aW5nIGFzc2lnbm1lbnQgZmlsZSAke2ZpbGVQYXRofTpgLCBlcnJvcik7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICkub3BlbigpO1xuICAgICAgfVxuICAgIH0pXG5cbiAgICB0aGlzLmFkZENvbW1hbmQoe1xuICAgICAgaWQ6IFwiZXh0cmFjdC12b2NhYnVsYXJ5XCIsXG4gICAgICBuYW1lOiBcIkV4dHJhY3QgQ291cnNlIFZvY2FidWxhcnlcIixcbiAgICAgIGNhbGxiYWNrOiBhc3luYyAoKSA9PiB7XG4gICAgICAgIGNvbnN0IGNvdXJzZUlkID0gYXdhaXQgdGhpcy5wcm9tcHRGb3JDb3Vyc2VJZChcbiAgICAgICAgICBcIkVudGVyIGNvdXJzZSBJRCB0byBleHRyYWN0IHZvY2FidWxhcnkgZnJvbVwiXG4gICAgICAgIClcbiAgICAgICAgaWYgKGNvdXJzZUlkKSB7XG4gICAgICAgICAgYXdhaXQgdGhpcy52b2NhYnVsYXJ5RXh0cmFjdG9yLmNyZWF0ZVZvY2FidWxhcnlJbmRleEZpbGUoY291cnNlSWQpXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9KVxuXG4gICAgdGhpcy5hZGRDb21tYW5kKHtcbiAgICAgIGlkOiBcImdlbmVyYXRlLWR1ZS1kYXRlcy1zdW1tYXJ5XCIsXG4gICAgICBuYW1lOiBcIkdlbmVyYXRlIER1ZSBEYXRlcyBTdW1tYXJ5XCIsXG4gICAgICBjYWxsYmFjazogYXN5bmMgKCkgPT4ge1xuICAgICAgICBjb25zdCBjb3Vyc2VJZCA9IGF3YWl0IHRoaXMucHJvbXB0Rm9yQ291cnNlSWQoXG4gICAgICAgICAgXCJFbnRlciBjb3Vyc2UgSUQgdG8gZ2VuZXJhdGUgZHVlIGRhdGVzIHN1bW1hcnkgZm9yXCJcbiAgICAgICAgKVxuICAgICAgICBpZiAoY291cnNlSWQpIHtcbiAgICAgICAgICBhd2FpdCB0aGlzLmR1ZURhdGVzUGFyc2VyLmNyZWF0ZUR1ZURhdGVzU3VtbWFyeUZpbGUoY291cnNlSWQpXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9KVxuXG4gICAgdGhpcy5hZGRDb21tYW5kKHtcbiAgICAgIGlkOiBcImdlbmVyYXRlLWRhaWx5LXN1bW1hcnlcIixcbiAgICAgIG5hbWU6IFwiR2VuZXJhdGUgRGFpbHkgQWNhZGVtaWMgU3VtbWFyeVwiLFxuICAgICAgY2FsbGJhY2s6IGFzeW5jICgpID0+IHtcbiAgICAgICAgY29uc3QgZGF0ZSA9IGF3YWl0IHRoaXMucHJvbXB0Rm9yRGF0ZShcbiAgICAgICAgICBcIkVudGVyIGRhdGUgKFlZWVktTU0tREQpIG9yIGxlYXZlIGVtcHR5IGZvciB0b2RheVwiXG4gICAgICAgIClcbiAgICAgICAgYXdhaXQgdGhpcy5kYWlseU5vdGVzSW50ZWdyYXRpb24uY3JlYXRlRGFpbHlTdW1tYXJ5RmlsZShcbiAgICAgICAgICBkYXRlIHx8IHVuZGVmaW5lZFxuICAgICAgICApXG4gICAgICB9XG4gICAgfSlcblxuICAgIC8vIEFkZCBzdGF0dXMgYmFyIGl0ZW1cbiAgICB0aGlzLmFkZFN0YXR1c0Jhckl0ZW0oKS5zZXRUZXh0KFwiVHVja2VycyBUb29sc1wiKVxuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBwcm9tcHRGb3JDb3Vyc2VJZChtZXNzYWdlOiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZyB8IG51bGw+IHtcbiAgICBjb25zdCBjb3Vyc2VJZCA9IHByb21wdChtZXNzYWdlICsgXCJcXG5cXG5FeGFtcGxlOiBQU0ktMTAxXCIpXG4gICAgcmV0dXJuIGNvdXJzZUlkID8gY291cnNlSWQudHJpbSgpIDogbnVsbFxuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBwcm9tcHRGb3JEYXRlKG1lc3NhZ2U6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nIHwgbnVsbD4ge1xuICAgIGNvbnN0IGRhdGUgPSBwcm9tcHQoXG4gICAgICBtZXNzYWdlICsgXCJcXG5cXG5FeGFtcGxlOiAyMDI1LTAxLTE1IG9yIGxlYXZlIGVtcHR5IGZvciB0b2RheVwiXG4gICAgKVxuICAgIHJldHVybiBkYXRlID8gZGF0ZS50cmltKCkgOiBudWxsXG4gIH1cblxuICBnZW5lcmF0ZUFzc2lnbm1lbnRGaWxlQ29udGVudChhc3NpZ25tZW50OiBhbnksIGNvdXJzZU5hbWU6IHN0cmluZywgY291cnNlSWQ6IHN0cmluZyk6IHN0cmluZyB7XG4gICAgLy8gQ3JlYXRlIHRoZSBhc3NpZ25tZW50IGZpbGUgY29udGVudCB1c2luZyB0aGUgYXNzaWdubWVudCB0ZW1wbGF0ZSBzdHJ1Y3R1cmVcbiAgICByZXR1cm4gYC0tLVxuY291cnNlX2lkOiAke2NvdXJzZUlkfVxuYXNzaWdubWVudF90eXBlOiAke2Fzc2lnbm1lbnQudHlwZSB8fCBcIkFzc2lnbm1lbnRcIn1cbmR1ZV9kYXRlOiAke2Fzc2lnbm1lbnQuZHVlRGF0ZX1cbnBvaW50czogJHthc3NpZ25tZW50LnBvaW50cyB8fCBcIlwifVxuY29udGVudF90eXBlOiBhc3NpZ25tZW50XG5jcmVhdGVkOiAke25ldyBEYXRlKCkudG9JU09TdHJpbmcoKX1cbnN0YXR1czogcGVuZGluZ1xudGFnczpcbiAgLSBlZHVjYXRpb25cbiAgLSAke2NvdXJzZUlkfVxuICAtIGFzc2lnbm1lbnRcbi0tLVxuXG4jICR7YXNzaWdubWVudC5uYW1lfSAtICR7Y291cnNlSWR9XG5cbiMjIERlc2NyaXB0aW9uXG4ke2Fzc2lnbm1lbnQuZGVzY3JpcHRpb259XG5cbiMjIEluc3RydWN0aW9uc1xuXG5cbiMjIER1ZSBEYXRlXG4qKkFzc2lnbmVkKio6ICR7bmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNwbGl0KCdUJylbMF19XG4qKkR1ZSoqOiAke2Fzc2lnbm1lbnQuZHVlRGF0ZX1cblxuIyMgU3VibWlzc2lvblxuXG5cbiMjIEdyYWRpbmcgQ3JpdGVyaWFcblxuXG4jIyBSZXNvdXJjZXNcblxuXG4jIER1ZSBEYXRlc1xufCAke2Fzc2lnbm1lbnQuZHVlRGF0ZX0gfCAke2Fzc2lnbm1lbnQubmFtZX0gfCBwZW5kaW5nIHxcbmA7XG4gIH1cblxuICBvbnVubG9hZCgpIHtcbiAgICBjb25zb2xlLmxvZyhcIlVubG9hZGluZyBUdWNrZXJzIFRvb2xzIHBsdWdpblwiKVxuICB9XG5cbiAgYXN5bmMgaW5pdGlhbGl6ZVRlbXBsYXRlckZ1bmN0aW9ucygpIHtcbiAgICAvLyBDaGVjayBpZiBUZW1wbGF0ZXIgcGx1Z2luIGlzIGF2YWlsYWJsZVxuICAgIGNvbnN0IHRlbXBsYXRlclBsdWdpbiA9ICh0aGlzLmFwcCBhcyBhbnkpLnBsdWdpbnMuZ2V0UGx1Z2luKFwidGVtcGxhdGVyLW9ic2lkaWFuXCIpO1xuICAgIGlmICghdGVtcGxhdGVyUGx1Z2luKSB7XG4gICAgICBjb25zb2xlLmxvZyhcIlRlbXBsYXRlciBwbHVnaW4gbm90IGZvdW5kLiBDb3Vyc2UgdGVtcGxhdGVzIHdpbGwgbm90IHdvcmsgcHJvcGVybHkuXCIpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIC8vIFJlZ2lzdGVyIHVzZXIgZnVuY3Rpb25zIHdpdGggVGVtcGxhdGVyXG4gICAgdHJ5IHtcbiAgICAgIC8vIFRyeSB0byBhZGQgZnVuY3Rpb25zIHZpYSBkaWZmZXJlbnQgbWV0aG9kcyBkZXBlbmRpbmcgb24gdGhlIFRlbXBsYXRlciB2ZXJzaW9uXG4gICAgICBpZiAodGVtcGxhdGVyUGx1Z2luICYmIHRlbXBsYXRlclBsdWdpbi50ZW1wbGF0ZXIpIHtcbiAgICAgICAgLy8gQ3JlYXRlIGEgdXNlciBmdW5jdGlvbiBtYW5hZ2VyIG9iamVjdCBpZiBpdCBkb2Vzbid0IGV4aXN0XG4gICAgICAgIGlmICghdGVtcGxhdGVyUGx1Z2luLnRlbXBsYXRlci5mdW5jdGlvbnMpIHtcbiAgICAgICAgICB0ZW1wbGF0ZXJQbHVnaW4udGVtcGxhdGVyLmZ1bmN0aW9ucyA9IHt9O1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gQWRkIG91ciBjdXN0b20gZnVuY3Rpb25zIGRpcmVjdGx5IHRvIHRoZSB0ZW1wbGF0ZXIgZnVuY3Rpb25zIG9iamVjdFxuICAgICAgICB0ZW1wbGF0ZXJQbHVnaW4udGVtcGxhdGVyLmZ1bmN0aW9uc1tcIm5ld19tb2R1bGVcIl0gPSBhc3luYyAoYXBwOiBhbnksIHRwOiBhbnksIHllYXI6IGFueSkgPT4ge1xuICAgICAgICAgIHJldHVybiB0aGlzLm5ld01vZHVsZUZ1bmN0aW9uKGFwcCwgdHAsIHllYXIpO1xuICAgICAgICB9O1xuXG4gICAgICAgIHRlbXBsYXRlclBsdWdpbi50ZW1wbGF0ZXIuZnVuY3Rpb25zW1wibmV3X2NoYXB0ZXJcIl0gPSBhc3luYyAodHA6IGFueSkgPT4ge1xuICAgICAgICAgIHJldHVybiB0aGlzLm5ld0NoYXB0ZXJGdW5jdGlvbih0cCk7XG4gICAgICAgIH07XG5cbiAgICAgICAgY29uc29sZS5sb2coXCJUdWNrZXJzIFRvb2xzIHRlbXBsYXRlciBmdW5jdGlvbnMgcmVnaXN0ZXJlZCBzdWNjZXNzZnVsbHlcIik7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjb25zb2xlLmVycm9yKFwiQ291bGQgbm90IHJlZ2lzdGVyIHRlbXBsYXRlciBmdW5jdGlvbnMgLSB0ZW1wbGF0ZXIgb2JqZWN0IG5vdCBmb3VuZFwiKTtcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgcmVnaXN0ZXJpbmcgdGVtcGxhdGVyIGZ1bmN0aW9uczpcIiwgZSk7XG4gICAgfVxuICB9XG5cbiAgYXN5bmMgbmV3TW9kdWxlRnVuY3Rpb24oYXBwOiBhbnksIHRwOiBhbnksIHllYXI6IHN0cmluZykge1xuICAgIC8vIFByb21wdCB1c2VyIGZvciBtb2R1bGUgZGV0YWlsc1xuICAgIGxldCBtb2R1bGVOdW1iZXI6IHN0cmluZyB8IG51bGwgPSBcIlwiO1xuICAgIGxldCB3ZWVrTnVtYmVyOiBzdHJpbmcgfCBudWxsID0gXCJcIjtcbiAgICBsZXQgY291cnNlID0gXCJcIjtcbiAgICBsZXQgY291cnNlSWQgPSBcIlwiO1xuICAgIGxldCBkaXNjaXBsaW5lID0gXCJHRU5cIjtcbiAgICBsZXQgZGF5T2ZXZWVrID0gXCJcIjtcblxuICAgIHRyeSB7XG4gICAgICAvLyBBdHRlbXB0IHByb21wdHMgd2l0aCBmYWxsYmFja1xuICAgICAgaWYgKHRwICYmIHRwLnN5c3RlbSAmJiB0cC5zeXN0ZW0ucHJvbXB0KSB7XG4gICAgICAgIGNvbnN0IHRlbXBNb2R1bGVOdW1iZXIgPSBhd2FpdCB0cC5zeXN0ZW0ucHJvbXB0KFwiTW9kdWxlIE51bWJlciAob3B0aW9uYWwpXCIsIFwiXCIpO1xuICAgICAgICBtb2R1bGVOdW1iZXIgPSB0ZW1wTW9kdWxlTnVtYmVyID8gdGVtcE1vZHVsZU51bWJlciA6IG51bGw7XG4gICAgICAgIFxuICAgICAgICBjb25zdCB0ZW1wV2Vla051bWJlciA9IGF3YWl0IHRwLnN5c3RlbS5wcm9tcHQoXCJXZWVrIE51bWJlciAob3B0aW9uYWwpXCIsIFwiXCIpO1xuICAgICAgICB3ZWVrTnVtYmVyID0gdGVtcFdlZWtOdW1iZXIgPyB0ZW1wV2Vla051bWJlciA6IG51bGw7XG4gICAgICAgIFxuICAgICAgICBjb3Vyc2UgPSBhd2FpdCB0cC5zeXN0ZW0uc3VnZ2VzdGVyKFxuICAgICAgICAgICgpID0+IGFwcC52YXVsdC5nZXRNYXJrZG93bkZpbGVzKCkuZmlsdGVyKChmOiBhbnkpID0+IGYucGF0aC5pbmNsdWRlcyhcIkNvdXJzZXNcIikpLm1hcCgoZjogYW55KSA9PiBmLmJhc2VuYW1lKSxcbiAgICAgICAgICBhcHAudmF1bHQuZ2V0TWFya2Rvd25GaWxlcygpLmZpbHRlcigoZjogYW55KSA9PiBmLnBhdGguaW5jbHVkZXMoXCJDb3Vyc2VzXCIpKVxuICAgICAgICApO1xuICAgICAgICBcbiAgICAgICAgZGF5T2ZXZWVrID0gYXdhaXQgdHAuc3lzdGVtLnN1Z2dlc3RlcihcbiAgICAgICAgICBbXCJNb25kYXlcIiwgXCJUdWVzZGF5XCIsIFwiV2VkbmVzZGF5XCIsIFwiVGh1cnNkYXlcIiwgXCJGcmlkYXlcIiwgXCJTYXR1cmRheVwiLCBcIlN1bmRheVwiXSxcbiAgICAgICAgICBbXCJNb25kYXlcIiwgXCJUdWVzZGF5XCIsIFwiV2VkbmVzZGF5XCIsIFwiVGh1cnNkYXlcIiwgXCJGcmlkYXlcIiwgXCJTYXR1cmRheVwiLCBcIlN1bmRheVwiXSxcbiAgICAgICAgICBcIkRheSBvZiBXZWVrXCJcbiAgICAgICAgKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIC8vIEZhbGxiYWNrIHZhbHVlc1xuICAgICAgICBtb2R1bGVOdW1iZXIgPSBudWxsO1xuICAgICAgICB3ZWVrTnVtYmVyID0gbnVsbDtcbiAgICAgICAgY291cnNlID0gXCJOZXcgQ291cnNlXCI7XG4gICAgICAgIGRheU9mV2VlayA9IFwiTW9uZGF5XCI7XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGluIG5ld19tb2R1bGUgcHJvbXB0czpcIiwgZSk7XG4gICAgICAvLyBEZWZhdWx0IHZhbHVlcyBvbiBlcnJvclxuICAgICAgbW9kdWxlTnVtYmVyID0gbnVsbDtcbiAgICAgIHdlZWtOdW1iZXIgPSBudWxsO1xuICAgICAgY291cnNlID0gXCJOZXcgQ291cnNlXCI7XG4gICAgICBkYXlPZldlZWsgPSBcIk1vbmRheVwiO1xuICAgIH1cblxuICAgIC8vIENhbGN1bGF0ZSBkZXJpdmVkIHZhbHVlc1xuICAgIGNvdXJzZUlkID0gY291cnNlID8gY291cnNlLnNwbGl0KFwiIC0gXCIpWzBdIHx8IGNvdXJzZSA6IFwiXCI7XG4gICAgZGlzY2lwbGluZSA9IGNvdXJzZSA/IChjb3Vyc2Uuc3BsaXQoXCIgLSBcIilbMF0/LnN1YnN0cmluZygwLCAzKSB8fCBcIkdFTlwiKSA6IFwiR0VOXCI7XG5cbiAgICByZXR1cm4ge1xuICAgICAgc2Vhc29uOiBcIkZhbGxcIiwgLy8gVGhpcyB3b3VsZCBub3JtYWxseSBiZSBkeW5hbWljYWxseSBkZXRlcm1pbmVkXG4gICAgICBtb2R1bGVOdW1iZXI6IG1vZHVsZU51bWJlcixcbiAgICAgIHdlZWtOdW1iZXI6IHdlZWtOdW1iZXIsXG4gICAgICBjb3Vyc2UsXG4gICAgICBjb3Vyc2VJZCxcbiAgICAgIGRpc2NpcGxpbmUsXG4gICAgICBkYXlPZldlZWtcbiAgICB9O1xuICB9XG5cbiAgYXN5bmMgbmV3Q2hhcHRlckZ1bmN0aW9uKHRwOiBhbnkpIHtcbiAgICBsZXQgY2hhcHRlck51bWJlciA9IFwiXCI7XG4gICAgbGV0IGNvdXJzZSA9IFwiXCI7XG4gICAgbGV0IGNvdXJzZUlkID0gXCJcIjtcbiAgICBsZXQgZGlzY2lwbGluZSA9IFwiR0VOXCI7XG4gICAgbGV0IHRleHQgPSBcIlwiO1xuXG4gICAgdHJ5IHtcbiAgICAgIGlmICh0cCAmJiB0cC5zeXN0ZW0gJiYgdHAuc3lzdGVtLnByb21wdCkge1xuICAgICAgICBjaGFwdGVyTnVtYmVyID0gYXdhaXQgdHAuc3lzdGVtLnByb21wdChcIkNoYXB0ZXIgTnVtYmVyXCIsIFwiXCIpIHx8IFwiXCI7XG4gICAgICAgIGNvdXJzZSA9IGF3YWl0IHRwLnN5c3RlbS5zdWdnZXN0ZXIoXG4gICAgICAgICAgKCkgPT4gdHAuYXBwLnZhdWx0LmdldE1hcmtkb3duRmlsZXMoKS5maWx0ZXIoKGY6IGFueSkgPT4gZi5wYXRoLmluY2x1ZGVzKFwiQ291cnNlc1wiKSkubWFwKChmOiBhbnkpID0+IGYuYmFzZW5hbWUpLFxuICAgICAgICAgIHRwLmFwcC52YXVsdC5nZXRNYXJrZG93bkZpbGVzKCkuZmlsdGVyKChmOiBhbnkpID0+IGYucGF0aC5pbmNsdWRlcyhcIkNvdXJzZXNcIikpXG4gICAgICAgICk7XG4gICAgICAgIGNvbnN0IHRleHRPcHRpb25zID0gdHAuYXBwLnZhdWx0LmdldEZpbGVzKCkuZmlsdGVyKChmOiBhbnkpID0+IGYuZXh0ZW5zaW9uID09PSBcInBkZlwiKS5tYXAoKGY6IGFueSkgPT4gZi5iYXNlbmFtZSk7XG4gICAgICAgIHRleHQgPSBhd2FpdCB0cC5zeXN0ZW0uc3VnZ2VzdGVyKHRleHRPcHRpb25zLCB0ZXh0T3B0aW9ucywgXCJUZXh0Ym9va1wiKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIC8vIEZhbGxiYWNrIHZhbHVlc1xuICAgICAgICBjaGFwdGVyTnVtYmVyID0gXCJcIjtcbiAgICAgICAgY291cnNlID0gXCJOZXcgQ291cnNlXCI7XG4gICAgICAgIHRleHQgPSBcIk5ldyBUZXh0Ym9va1wiO1xuICAgICAgfVxuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBpbiBuZXdfY2hhcHRlciBwcm9tcHRzOlwiLCBlKTtcbiAgICAgIC8vIERlZmF1bHQgdmFsdWVzIG9uIGVycm9yXG4gICAgICBjaGFwdGVyTnVtYmVyID0gXCJcIjtcbiAgICAgIGNvdXJzZSA9IFwiTmV3IENvdXJzZVwiO1xuICAgICAgdGV4dCA9IFwiTmV3IFRleHRib29rXCI7XG4gICAgfVxuXG4gICAgLy8gQ2FsY3VsYXRlIGRlcml2ZWQgdmFsdWVzXG4gICAgY291cnNlSWQgPSBjb3Vyc2UgPyBjb3Vyc2Uuc3BsaXQoXCIgLSBcIilbMF0gfHwgY291cnNlIDogXCJcIjtcbiAgICBkaXNjaXBsaW5lID0gY291cnNlID8gKGNvdXJzZS5zcGxpdChcIiAtIFwiKVswXT8uc3Vic3RyaW5nKDAsIDMpIHx8IFwiR0VOXCIpIDogXCJHRU5cIjtcblxuICAgIHJldHVybiB7XG4gICAgICBjaGFwdGVyTnVtYmVyLFxuICAgICAgY291cnNlLFxuICAgICAgY291cnNlSWQsXG4gICAgICBkaXNjaXBsaW5lLFxuICAgICAgdGV4dFxuICAgIH07XG4gIH1cblxuICBhc3luYyBsb2FkU2V0dGluZ3MoKSB7XG4gICAgdGhpcy5zZXR0aW5ncyA9IE9iamVjdC5hc3NpZ24oe30sIERFRkFVTFRfU0VUVElOR1MsIGF3YWl0IHRoaXMubG9hZERhdGEoKSlcbiAgfVxuXG4gIGFzeW5jIHNhdmVTZXR0aW5ncygpIHtcbiAgICBhd2FpdCB0aGlzLnNhdmVEYXRhKHRoaXMuc2V0dGluZ3MpXG4gIH1cbn1cbiIsICJpbXBvcnQgeyBBcHAsIFBsdWdpblNldHRpbmdUYWIsIFNldHRpbmcgfSBmcm9tICdvYnNpZGlhbic7XG5pbXBvcnQgVHVja2Vyc1Rvb2xzUGx1Z2luIGZyb20gJy4vbWFpbic7XG5pbXBvcnQgeyB2YWxpZGF0ZURhdGUgfSBmcm9tICcuL3V0aWxzJztcblxuZXhwb3J0IGludGVyZmFjZSBUdWNrZXJzVG9vbHNTZXR0aW5ncyB7XG4gIGJhc2VEaXJlY3Rvcnk6IHN0cmluZztcbiAgc2VtZXN0ZXJTdGFydERhdGU6IHN0cmluZztcbiAgc2VtZXN0ZXJFbmREYXRlOiBzdHJpbmc7XG4gIHNjaG9vbE5hbWU6IHN0cmluZztcbiAgc2Nob29sQWJicmV2aWF0aW9uOiBzdHJpbmc7XG4gIHRlbXBsYXRlRm9sZGVyOiBzdHJpbmc7XG4gIHVzZUVuaGFuY2VkTWV0YWRhdGE6IGJvb2xlYW47XG4gIGRhdGF2aWV3SnNQYXRoOiBzdHJpbmc7XG59XG5cbmV4cG9ydCBjb25zdCBERUZBVUxUX1NFVFRJTkdTOiBUdWNrZXJzVG9vbHNTZXR0aW5ncyA9IHtcbiAgYmFzZURpcmVjdG9yeTogJy8nLFxuICBzZW1lc3RlclN0YXJ0RGF0ZTogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNwbGl0KCdUJylbMF0sXG4gIHNlbWVzdGVyRW5kRGF0ZTogbmV3IERhdGUobmV3IERhdGUoKS5zZXRNb250aChuZXcgRGF0ZSgpLmdldE1vbnRoKCkgKyA0KSkudG9JU09TdHJpbmcoKS5zcGxpdCgnVCcpWzBdLFxuICBzY2hvb2xOYW1lOiAnVW5pdmVyc2l0eScsXG4gIHNjaG9vbEFiYnJldmlhdGlvbjogJ1UnLFxuICB0ZW1wbGF0ZUZvbGRlcjogJ1R1Y2tlcnMgVG9vbHMnLFxuICB1c2VFbmhhbmNlZE1ldGFkYXRhOiBmYWxzZSxcbiAgZGF0YXZpZXdKc1BhdGg6ICcvU3VwcG9ydGluZy9kYXRhdmlldy1mdW5jdGlvbnMnXG59XG5cbmV4cG9ydCBjbGFzcyBUdWNrZXJzVG9vbHNTZXR0aW5nVGFiIGV4dGVuZHMgUGx1Z2luU2V0dGluZ1RhYiB7XG4gIHBsdWdpbjogVHVja2Vyc1Rvb2xzUGx1Z2luO1xuXG4gIGNvbnN0cnVjdG9yKGFwcDogQXBwLCBwbHVnaW46IFR1Y2tlcnNUb29sc1BsdWdpbikge1xuICAgIHN1cGVyKGFwcCwgcGx1Z2luKTtcbiAgICB0aGlzLnBsdWdpbiA9IHBsdWdpbjtcbiAgfVxuXG4gIGRpc3BsYXkoKTogdm9pZCB7XG4gICAgY29uc3QgeyBjb250YWluZXJFbCB9ID0gdGhpcztcblxuICAgIGNvbnRhaW5lckVsLmVtcHR5KCk7XG5cbiAgICBjb250YWluZXJFbC5jcmVhdGVFbCgnaDInLCB7IHRleHQ6ICdUdWNrZXJzIFRvb2xzIFNldHRpbmdzJyB9KTtcblxuICAgIG5ldyBTZXR0aW5nKGNvbnRhaW5lckVsKVxuICAgICAgLnNldE5hbWUoJ0Jhc2UgRGlyZWN0b3J5JylcbiAgICAgIC5zZXREZXNjKCdSb290IGRpcmVjdG9yeSBmb3IgY291cnNlIGNvbnRlbnQgb3JnYW5pemF0aW9uJylcbiAgICAgIC5hZGRUZXh0KHRleHQgPT4gdGV4dFxuICAgICAgICAuc2V0UGxhY2Vob2xkZXIoJy8nKVxuICAgICAgICAuc2V0VmFsdWUodGhpcy5wbHVnaW4uc2V0dGluZ3MuYmFzZURpcmVjdG9yeSlcbiAgICAgICAgLm9uQ2hhbmdlKGFzeW5jICh2YWx1ZSkgPT4ge1xuICAgICAgICAgIHRoaXMucGx1Z2luLnNldHRpbmdzLmJhc2VEaXJlY3RvcnkgPSB2YWx1ZTtcbiAgICAgICAgICBhd2FpdCB0aGlzLnBsdWdpbi5zYXZlU2V0dGluZ3MoKTtcbiAgICAgICAgfSkpO1xuXG4gICAgY29uc3Qgc3RhcnREYXRlU2V0dGluZyA9IG5ldyBTZXR0aW5nKGNvbnRhaW5lckVsKVxuICAgICAgLnNldE5hbWUoJ1NlbWVzdGVyIFN0YXJ0IERhdGUnKVxuICAgICAgLnNldERlc2MoJ1N0YXJ0IGRhdGUgZm9yIHRoZSBjdXJyZW50IHNlbWVzdGVyJylcbiAgICAgIC5hZGRUZXh0KHRleHQgPT4gdGV4dFxuICAgICAgICAuc2V0UGxhY2Vob2xkZXIoJ1lZWVktTU0tREQnKVxuICAgICAgICAuc2V0VmFsdWUodGhpcy5wbHVnaW4uc2V0dGluZ3Muc2VtZXN0ZXJTdGFydERhdGUpXG4gICAgICAgIC5vbkNoYW5nZShhc3luYyAodmFsdWUpID0+IHtcbiAgICAgICAgICBpZiAodmFsdWUgJiYgIXZhbGlkYXRlRGF0ZSh2YWx1ZSkpIHtcbiAgICAgICAgICAgIHN0YXJ0RGF0ZVNldHRpbmcuc2V0RGVzYygnU3RhcnQgZGF0ZSBmb3IgdGhlIGN1cnJlbnQgc2VtZXN0ZXIgKEludmFsaWQgZGF0ZSBmb3JtYXQpJyk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHN0YXJ0RGF0ZVNldHRpbmcuc2V0RGVzYygnU3RhcnQgZGF0ZSBmb3IgdGhlIGN1cnJlbnQgc2VtZXN0ZXInKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgdGhpcy5wbHVnaW4uc2V0dGluZ3Muc2VtZXN0ZXJTdGFydERhdGUgPSB2YWx1ZTtcbiAgICAgICAgICBhd2FpdCB0aGlzLnBsdWdpbi5zYXZlU2V0dGluZ3MoKTtcbiAgICAgICAgfSkpO1xuXG4gICAgY29uc3QgZW5kRGF0ZVNldHRpbmcgPSBuZXcgU2V0dGluZyhjb250YWluZXJFbClcbiAgICAgIC5zZXROYW1lKCdTZW1lc3RlciBFbmQgRGF0ZScpXG4gICAgICAuc2V0RGVzYygnRW5kIGRhdGUgZm9yIHRoZSBjdXJyZW50IHNlbWVzdGVyJylcbiAgICAgIC5hZGRUZXh0KHRleHQgPT4gdGV4dFxuICAgICAgICAuc2V0UGxhY2Vob2xkZXIoJ1lZWVktTU0tREQnKVxuICAgICAgICAuc2V0VmFsdWUodGhpcy5wbHVnaW4uc2V0dGluZ3Muc2VtZXN0ZXJFbmREYXRlKVxuICAgICAgICAub25DaGFuZ2UoYXN5bmMgKHZhbHVlKSA9PiB7XG4gICAgICAgICAgaWYgKHZhbHVlICYmICF2YWxpZGF0ZURhdGUodmFsdWUpKSB7XG4gICAgICAgICAgICBlbmREYXRlU2V0dGluZy5zZXREZXNjKCdFbmQgZGF0ZSBmb3IgdGhlIGN1cnJlbnQgc2VtZXN0ZXIgKEludmFsaWQgZGF0ZSBmb3JtYXQpJyk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGVuZERhdGVTZXR0aW5nLnNldERlc2MoJ0VuZCBkYXRlIGZvciB0aGUgY3VycmVudCBzZW1lc3RlcicpO1xuICAgICAgICAgIH1cbiAgICAgICAgICB0aGlzLnBsdWdpbi5zZXR0aW5ncy5zZW1lc3RlckVuZERhdGUgPSB2YWx1ZTtcbiAgICAgICAgICBhd2FpdCB0aGlzLnBsdWdpbi5zYXZlU2V0dGluZ3MoKTtcbiAgICAgICAgfSkpO1xuXG4gICAgbmV3IFNldHRpbmcoY29udGFpbmVyRWwpXG4gICAgICAuc2V0TmFtZSgnU2Nob29sIE5hbWUnKVxuICAgICAgLnNldERlc2MoJ05hbWUgb2YgeW91ciBpbnN0aXR1dGlvbicpXG4gICAgICAuYWRkVGV4dCh0ZXh0ID0+IHRleHRcbiAgICAgICAgLnNldFBsYWNlaG9sZGVyKCdVbml2ZXJzaXR5JylcbiAgICAgICAgLnNldFZhbHVlKHRoaXMucGx1Z2luLnNldHRpbmdzLnNjaG9vbE5hbWUpXG4gICAgICAgIC5vbkNoYW5nZShhc3luYyAodmFsdWUpID0+IHtcbiAgICAgICAgICB0aGlzLnBsdWdpbi5zZXR0aW5ncy5zY2hvb2xOYW1lID0gdmFsdWU7XG4gICAgICAgICAgYXdhaXQgdGhpcy5wbHVnaW4uc2F2ZVNldHRpbmdzKCk7XG4gICAgICAgIH0pKTtcblxuICAgIG5ldyBTZXR0aW5nKGNvbnRhaW5lckVsKVxuICAgICAgLnNldE5hbWUoJ1NjaG9vbCBBYmJyZXZpYXRpb24nKVxuICAgICAgLnNldERlc2MoJ0FiYnJldmlhdGlvbiBmb3IgeW91ciBpbnN0aXR1dGlvbicpXG4gICAgICAuYWRkVGV4dCh0ZXh0ID0+IHRleHRcbiAgICAgICAgLnNldFBsYWNlaG9sZGVyKCdVJylcbiAgICAgICAgLnNldFZhbHVlKHRoaXMucGx1Z2luLnNldHRpbmdzLnNjaG9vbEFiYnJldmlhdGlvbilcbiAgICAgICAgLm9uQ2hhbmdlKGFzeW5jICh2YWx1ZSkgPT4ge1xuICAgICAgICAgIHRoaXMucGx1Z2luLnNldHRpbmdzLnNjaG9vbEFiYnJldmlhdGlvbiA9IHZhbHVlO1xuICAgICAgICAgIGF3YWl0IHRoaXMucGx1Z2luLnNhdmVTZXR0aW5ncygpO1xuICAgICAgICB9KSk7XG5cbiAgICBuZXcgU2V0dGluZyhjb250YWluZXJFbClcbiAgICAgIC5zZXROYW1lKCdUZW1wbGF0ZSBGb2xkZXInKVxuICAgICAgLnNldERlc2MoJ1N1YmZvbGRlciB3aXRoaW4geW91ciBUZW1wbGF0ZXIgdGVtcGxhdGUgZm9sZGVyIGZvciBUdWNrZXJzIFRvb2xzIHRlbXBsYXRlcycpXG4gICAgICAuYWRkVGV4dCh0ZXh0ID0+IHRleHRcbiAgICAgICAgLnNldFBsYWNlaG9sZGVyKCdUdWNrZXJzIFRvb2xzJylcbiAgICAgICAgLnNldFZhbHVlKHRoaXMucGx1Z2luLnNldHRpbmdzLnRlbXBsYXRlRm9sZGVyKVxuICAgICAgICAub25DaGFuZ2UoYXN5bmMgKHZhbHVlKSA9PiB7XG4gICAgICAgICAgdGhpcy5wbHVnaW4uc2V0dGluZ3MudGVtcGxhdGVGb2xkZXIgPSB2YWx1ZTtcbiAgICAgICAgICBhd2FpdCB0aGlzLnBsdWdpbi5zYXZlU2V0dGluZ3MoKTtcbiAgICAgICAgfSkpO1xuXG4gICAgbmV3IFNldHRpbmcoY29udGFpbmVyRWwpXG4gICAgICAuc2V0TmFtZSgnVXNlIEVuaGFuY2VkIE1ldGFkYXRhJylcbiAgICAgIC5zZXREZXNjKCdFbmFibGUgZW5oYW5jZWQgbWV0YWRhdGEgZmllbGRzIGZvciBuZXcgbm90ZXMgKGV4aXN0aW5nIG5vdGVzIHJlbWFpbiB1bmNoYW5nZWQpJylcbiAgICAgIC5hZGRUb2dnbGUodG9nZ2xlID0+IHRvZ2dsZVxuICAgICAgICAuc2V0VmFsdWUodGhpcy5wbHVnaW4uc2V0dGluZ3MudXNlRW5oYW5jZWRNZXRhZGF0YSlcbiAgICAgICAgLm9uQ2hhbmdlKGFzeW5jICh2YWx1ZSkgPT4ge1xuICAgICAgICAgIHRoaXMucGx1Z2luLnNldHRpbmdzLnVzZUVuaGFuY2VkTWV0YWRhdGEgPSB2YWx1ZTtcbiAgICAgICAgICBhd2FpdCB0aGlzLnBsdWdpbi5zYXZlU2V0dGluZ3MoKTtcbiAgICAgICAgfSkpO1xuXG4gICAgbmV3IFNldHRpbmcoY29udGFpbmVyRWwpXG4gICAgICAuc2V0TmFtZSgnRGF0YXZpZXcgRnVuY3Rpb25zIFBhdGgnKVxuICAgICAgLnNldERlc2MoJ1BhdGggdG8gdGhlIGRhdGF2aWV3IGZ1bmN0aW9ucyBmaWxlICh3aXRob3V0IGV4dGVuc2lvbiknKVxuICAgICAgLmFkZFRleHQodGV4dCA9PiB0ZXh0XG4gICAgICAgIC5zZXRQbGFjZWhvbGRlcignL1N1cHBvcnRpbmcvZGF0YXZpZXctZnVuY3Rpb25zJylcbiAgICAgICAgLnNldFZhbHVlKHRoaXMucGx1Z2luLnNldHRpbmdzLmRhdGF2aWV3SnNQYXRoKVxuICAgICAgICAub25DaGFuZ2UoYXN5bmMgKHZhbHVlKSA9PiB7XG4gICAgICAgICAgdGhpcy5wbHVnaW4uc2V0dGluZ3MuZGF0YXZpZXdKc1BhdGggPSB2YWx1ZTtcbiAgICAgICAgICBhd2FpdCB0aGlzLnBsdWdpbi5zYXZlU2V0dGluZ3MoKTtcbiAgICAgICAgfSkpO1xuICB9XG59IiwgIi8vIFV0aWxpdHkgZnVuY3Rpb25zIGZvciBUdWNrZXJzIFRvb2xzIHBsdWdpblxuXG5leHBvcnQgZnVuY3Rpb24gZm9ybWF0RGF0ZShkYXRlOiBEYXRlKTogc3RyaW5nIHtcbiAgcmV0dXJuIGRhdGUudG9JU09TdHJpbmcoKS5zcGxpdChcIlRcIilbMF1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGFkZERheXMoZGF0ZTogRGF0ZSwgZGF5czogbnVtYmVyKTogRGF0ZSB7XG4gIGNvbnN0IHJlc3VsdCA9IG5ldyBEYXRlKGRhdGUpXG4gIHJlc3VsdC5zZXREYXRlKHJlc3VsdC5nZXREYXRlKCkgKyBkYXlzKVxuICByZXR1cm4gcmVzdWx0XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBpc0JldHdlZW4oZGF0ZTogRGF0ZSwgc3RhcnQ6IERhdGUsIGVuZDogRGF0ZSk6IGJvb2xlYW4ge1xuICByZXR1cm4gZGF0ZSA+PSBzdGFydCAmJiBkYXRlIDw9IGVuZFxufVxuXG5leHBvcnQgZnVuY3Rpb24gc2x1Z2lmeSh0ZXh0OiBzdHJpbmcpOiBzdHJpbmcge1xuICByZXR1cm4gdGV4dFxuICAgIC50b0xvd2VyQ2FzZSgpXG4gICAgLnRyaW0oKVxuICAgIC5ub3JtYWxpemUoXCJORkRcIilcbiAgICAucmVwbGFjZSgvW1xcdTAzMDAtXFx1MDM2Zl0vZywgXCJcIilcbiAgICAucmVwbGFjZSgvW15hLXowLTlcXHMtXS9nLCBcIlwiKVxuICAgIC5yZXBsYWNlKC9bXFxzLV0rL2csIFwiLVwiKVxuICAgIC5yZXBsYWNlKC9eLSt8LSskL2csIFwiXCIpXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBnZXRDb3Vyc2VJZEZyb21QYXRoKHBhdGg6IHN0cmluZyk6IHN0cmluZyB8IG51bGwge1xuICAvLyBFeHRyYWN0IGNvdXJzZSBJRCBmcm9tIHBhdGggbGlrZSBcIjIwMjUvRmFsbC9QU0ktMTAxLy4uLlwiIG9yIGZpbGVuYW1lIFwiUFNJLTEwMSAtIEludHJvIHRvIFBzeWNoLm1kXCJcbiAgY29uc3QgcGFydHMgPSBwYXRoLnNwbGl0KFwiL1wiKVxuICBmb3IgKGNvbnN0IHBhcnQgb2YgcGFydHMpIHtcbiAgICAvLyBMb29rIGZvciBjb3Vyc2UgSUQgcGF0dGVybiBpbiBlYWNoIHBhdGggc2VnbWVudFxuICAgIGNvbnN0IG1hdGNoID0gcGFydC5tYXRjaCgvKFtBLVpdezIsNH0tXFxkezN9KS8pXG4gICAgaWYgKG1hdGNoKSB7XG4gICAgICByZXR1cm4gbWF0Y2hbMV1cbiAgICB9XG4gIH1cbiAgcmV0dXJuIG51bGxcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHZhbGlkYXRlRGF0ZShkYXRlU3RyaW5nOiBzdHJpbmcpOiBib29sZWFuIHtcbiAgY29uc3QgcmVnZXggPSAvXlxcZHs0fS1cXGR7Mn0tXFxkezJ9JC9cbiAgaWYgKCFkYXRlU3RyaW5nLm1hdGNoKHJlZ2V4KSkgcmV0dXJuIGZhbHNlXG5cbiAgY29uc3QgZGF0ZSA9IG5ldyBEYXRlKGRhdGVTdHJpbmcpXG4gIGNvbnN0IHRpbWVzdGFtcCA9IGRhdGUuZ2V0VGltZSgpXG5cbiAgaWYgKHR5cGVvZiB0aW1lc3RhbXAgIT09IFwibnVtYmVyXCIgfHwgaXNOYU4odGltZXN0YW1wKSkgcmV0dXJuIGZhbHNlXG5cbiAgcmV0dXJuIGRhdGVTdHJpbmcgPT09IGRhdGUudG9JU09TdHJpbmcoKS5zcGxpdChcIlRcIilbMF1cbn1cbiIsICJpbXBvcnQgeyBBcHAsIE5vdGljZSB9IGZyb20gXCJvYnNpZGlhblwiXG5pbXBvcnQgeyBUdWNrZXJzVG9vbHNTZXR0aW5ncyB9IGZyb20gXCIuL3NldHRpbmdzXCJcblxuaW50ZXJmYWNlIFRlbXBsYXRlTWFuaWZlc3Qge1xuICB2ZXJzaW9uOiBzdHJpbmdcbiAgdGVtcGxhdGVzOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+XG4gIHBsdWdpbl92ZXJzaW9uOiBzdHJpbmdcbiAgcmVsZWFzZV9ub3Rlczogc3RyaW5nXG59XG5cbmV4cG9ydCBjbGFzcyBUZW1wbGF0ZU1hbmFnZXIge1xuICBhcHA6IEFwcFxuICBzZXR0aW5nczogVHVja2Vyc1Rvb2xzU2V0dGluZ3NcbiAgbWFuaWZlc3Q6IFRlbXBsYXRlTWFuaWZlc3RcblxuICBjb25zdHJ1Y3RvcihhcHA6IEFwcCwgc2V0dGluZ3M6IFR1Y2tlcnNUb29sc1NldHRpbmdzKSB7XG4gICAgdGhpcy5hcHAgPSBhcHBcbiAgICB0aGlzLnNldHRpbmdzID0gc2V0dGluZ3NcbiAgICB0aGlzLm1hbmlmZXN0ID0ge1xuICAgICAgdmVyc2lvbjogXCIxLjAuMFwiLFxuICAgICAgdGVtcGxhdGVzOiB7XG4gICAgICAgIFwiQ291cnNlcy9DcmVhdGUgQ291cnNlIEhvbWVwYWdlLm1kXCI6IFwiMS4wLjBcIixcbiAgICAgICAgXCJDb3Vyc2VzL0NvdXJzZSBJbmRleC5tZFwiOiBcIjEuMC4wXCIsXG4gICAgICAgIFwiTW9kdWxlcy9DcmVhdGUgTW9kdWxlLm1kXCI6IFwiMS4wLjBcIixcbiAgICAgICAgXCJDaGFwdGVycy9DcmVhdGUgQ2hhcHRlci5tZFwiOiBcIjEuMC4wXCIsXG4gICAgICAgIFwiQXNzaWdubWVudHMvQ3JlYXRlIEFzc2lnbm1lbnQubWRcIjogXCIxLjAuMFwiLFxuICAgICAgICBcIkRhaWx5L0RhaWx5IE5vdGUubWRcIjogXCIxLjAuMFwiLFxuICAgICAgICBcIlV0aWxpdGllcy9Wb2NhYnVsYXJ5IEVudHJ5Lm1kXCI6IFwiMS4wLjBcIixcbiAgICAgICAgXCJVdGlsaXRpZXMvRHVlIERhdGUgRW50cnkubWRcIjogXCIxLjAuMFwiXG4gICAgICB9LFxuICAgICAgcGx1Z2luX3ZlcnNpb246IFwiMS4wLjBcIixcbiAgICAgIHJlbGVhc2Vfbm90ZXM6IFwiSW5pdGlhbCByZWxlYXNlIG9mIFR1Y2tlcnMgVG9vbHMgdGVtcGxhdGVzXCJcbiAgICB9XG4gIH1cblxuICBhc3luYyBpbnN0YWxsVGVtcGxhdGVzKCkge1xuICAgIHRyeSB7XG4gICAgICAvLyBHZXQgVGVtcGxhdGVyIHBsdWdpbiBzZXR0aW5ncyB0byBmaW5kIHRlbXBsYXRlIGZvbGRlclxuICAgICAgY29uc3QgdGVtcGxhdGVyUGx1Z2luID0gdGhpcy5nZXRUZW1wbGF0ZXJQbHVnaW4oKVxuICAgICAgaWYgKCF0ZW1wbGF0ZXJQbHVnaW4pIHtcbiAgICAgICAgbmV3IE5vdGljZShcbiAgICAgICAgICBcIlRlbXBsYXRlciBwbHVnaW4gbm90IGZvdW5kLiBQbGVhc2UgaW5zdGFsbCBhbmQgZW5hYmxlIHRoZSBUZW1wbGF0ZXIgcGx1Z2luIGZpcnN0LlwiXG4gICAgICAgIClcbiAgICAgICAgY29uc29sZS5lcnJvcihcbiAgICAgICAgICBcIlRlbXBsYXRlciBwbHVnaW4gbm90IGZvdW5kLiBQbGVhc2UgaW5zdGFsbCBhbmQgZW5hYmxlIHRoZSBUZW1wbGF0ZXIgcGx1Z2luIGZpcnN0LlwiXG4gICAgICAgIClcbiAgICAgICAgcmV0dXJuXG4gICAgICB9XG5cbiAgICAgIGNvbnN0IHRlbXBsYXRlRm9sZGVyUGF0aCA9IHRoaXMuZ2V0VGVtcGxhdGVGb2xkZXJQYXRoKHRlbXBsYXRlclBsdWdpbilcbiAgICAgIGlmICghdGVtcGxhdGVGb2xkZXJQYXRoKSB7XG4gICAgICAgIG5ldyBOb3RpY2UoXG4gICAgICAgICAgXCJUZW1wbGF0ZSBmb2xkZXIgbm90IGNvbmZpZ3VyZWQgaW4gVGVtcGxhdGVyIHNldHRpbmdzLiBQbGVhc2UgY29uZmlndXJlIGl0IGluIFRlbXBsYXRlciBzZXR0aW5ncyBmaXJzdC5cIlxuICAgICAgICApXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXG4gICAgICAgICAgXCJUZW1wbGF0ZSBmb2xkZXIgbm90IGNvbmZpZ3VyZWQgaW4gVGVtcGxhdGVyIHNldHRpbmdzLiBQbGVhc2UgY29uZmlndXJlIGl0IGluIFRlbXBsYXRlciBzZXR0aW5ncyBmaXJzdC5cIlxuICAgICAgICApXG4gICAgICAgIHJldHVyblxuICAgICAgfVxuXG4gICAgICBjb25zdCBmdWxsVGVtcGxhdGVQYXRoID0gYCR7dGVtcGxhdGVGb2xkZXJQYXRofS8ke3RoaXMuc2V0dGluZ3MudGVtcGxhdGVGb2xkZXJ9YFxuXG4gICAgICAvLyBDcmVhdGUgdGhlIG1haW4gdGVtcGxhdGUgZm9sZGVyIGlmIGl0IGRvZXNuJ3QgZXhpc3RcbiAgICAgIHRyeSB7XG4gICAgICAgIGF3YWl0IHRoaXMuYXBwLnZhdWx0LmNyZWF0ZUZvbGRlcihmdWxsVGVtcGxhdGVQYXRoKVxuICAgICAgICBjb25zb2xlLmxvZyhgQ3JlYXRlZCB0ZW1wbGF0ZSBmb2xkZXI6ICR7ZnVsbFRlbXBsYXRlUGF0aH1gKVxuICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAvLyBGb2xkZXIgbWlnaHQgYWxyZWFkeSBleGlzdCwgd2hpY2ggaXMgZmluZVxuICAgICAgICBjb25zb2xlLmxvZyhcbiAgICAgICAgICBgVGVtcGxhdGUgZm9sZGVyIGFscmVhZHkgZXhpc3RzIG9yIGNyZWF0ZWQ6ICR7ZnVsbFRlbXBsYXRlUGF0aH1gXG4gICAgICAgIClcbiAgICAgIH1cblxuICAgICAgLy8gQ3JlYXRlIHN1YmRpcmVjdG9yaWVzXG4gICAgICBjb25zdCBzdWJkaXJzID0gW1xuICAgICAgICBcIkNvdXJzZXNcIixcbiAgICAgICAgXCJNb2R1bGVzXCIsXG4gICAgICAgIFwiQ2hhcHRlcnNcIixcbiAgICAgICAgXCJBc3NpZ25tZW50c1wiLFxuICAgICAgICBcIkRhaWx5XCIsXG4gICAgICAgIFwiVXRpbGl0aWVzXCJcbiAgICAgIF1cbiAgICAgIGZvciAoY29uc3Qgc3ViZGlyIG9mIHN1YmRpcnMpIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBjb25zdCBzdWJQYXRoID0gYCR7ZnVsbFRlbXBsYXRlUGF0aH0vJHtzdWJkaXJ9YFxuICAgICAgICAgIGF3YWl0IHRoaXMuYXBwLnZhdWx0LmNyZWF0ZUZvbGRlcihzdWJQYXRoKVxuICAgICAgICAgIGNvbnNvbGUubG9nKGBDcmVhdGVkIHN1YmRpcmVjdG9yeTogJHtzdWJQYXRofWApXG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAvLyBGb2xkZXIgbWlnaHQgYWxyZWFkeSBleGlzdCwgd2hpY2ggaXMgZmluZVxuICAgICAgICAgIGNvbnNvbGUubG9nKFxuICAgICAgICAgICAgYFN1YmRpcmVjdG9yeSBhbHJlYWR5IGV4aXN0czogJHtmdWxsVGVtcGxhdGVQYXRofS8ke3N1YmRpcn1gXG4gICAgICAgICAgKVxuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIC8vIEluc3RhbGwgdGVtcGxhdGVzXG4gICAgICBhd2FpdCB0aGlzLmluc3RhbGxDb3Vyc2VUZW1wbGF0ZXMoZnVsbFRlbXBsYXRlUGF0aClcbiAgICAgIGF3YWl0IHRoaXMuaW5zdGFsbE1vZHVsZVRlbXBsYXRlcyhmdWxsVGVtcGxhdGVQYXRoKVxuICAgICAgYXdhaXQgdGhpcy5pbnN0YWxsQ2hhcHRlclRlbXBsYXRlcyhmdWxsVGVtcGxhdGVQYXRoKVxuICAgICAgYXdhaXQgdGhpcy5pbnN0YWxsQXNzaWdubWVudFRlbXBsYXRlcyhmdWxsVGVtcGxhdGVQYXRoKVxuICAgICAgYXdhaXQgdGhpcy5pbnN0YWxsRGFpbHlUZW1wbGF0ZXMoZnVsbFRlbXBsYXRlUGF0aClcbiAgICAgIGF3YWl0IHRoaXMuaW5zdGFsbFV0aWxpdHlUZW1wbGF0ZXMoZnVsbFRlbXBsYXRlUGF0aClcblxuICAgICAgLy8gQ3JlYXRlIFJFQURNRVxuICAgICAgYXdhaXQgdGhpcy5jcmVhdGVSRUFETUUoZnVsbFRlbXBsYXRlUGF0aClcblxuICAgICAgLy8gQ3JlYXRlIHRlbXBsYXRlIG1hbmlmZXN0XG4gICAgICBhd2FpdCB0aGlzLmNyZWF0ZVRlbXBsYXRlTWFuaWZlc3QoZnVsbFRlbXBsYXRlUGF0aClcblxuICAgICAgbmV3IE5vdGljZShcIlR1Y2tlcnMgVG9vbHMgdGVtcGxhdGVzIGluc3RhbGxlZCBzdWNjZXNzZnVsbHkhXCIpXG4gICAgICBjb25zb2xlLmxvZyhcIlR1Y2tlcnMgVG9vbHMgdGVtcGxhdGVzIGluc3RhbGxlZCBzdWNjZXNzZnVsbHlcIilcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGluc3RhbGxpbmcgdGVtcGxhdGVzOlwiLCBlcnJvcilcbiAgICAgIG5ldyBOb3RpY2UoXCJFcnJvciBpbnN0YWxsaW5nIHRlbXBsYXRlcy4gQ2hlY2sgY29uc29sZSBmb3IgZGV0YWlscy5cIilcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGdldFRlbXBsYXRlclBsdWdpbigpOiBhbnkge1xuICAgIC8vIFRyeSBtdWx0aXBsZSB3YXlzIHRvIGFjY2VzcyB0aGUgVGVtcGxhdGVyIHBsdWdpblxuICAgIGNvbnN0IHBvc3NpYmxlUGF0aHMgPSBbXG4gICAgICAodGhpcy5hcHAgYXMgYW55KS5wbHVnaW5zLnBsdWdpbnNbXCJ0ZW1wbGF0ZXItb2JzaWRpYW5cIl0sXG4gICAgICAodGhpcy5hcHAgYXMgYW55KS5wbHVnaW5zLnBsdWdpbnNbXCJ0ZW1wbGF0ZXJcIl0sXG4gICAgICAodGhpcy5hcHAgYXMgYW55KS5wbHVnaW5zLmdldFBsdWdpbihcInRlbXBsYXRlci1vYnNpZGlhblwiKSxcbiAgICAgICh0aGlzLmFwcCBhcyBhbnkpLnBsdWdpbnMuZ2V0UGx1Z2luKFwidGVtcGxhdGVyXCIpXG4gICAgXVxuXG4gICAgZm9yIChjb25zdCBwYXRoIG9mIHBvc3NpYmxlUGF0aHMpIHtcbiAgICAgIGlmIChwYXRoKSB7XG4gICAgICAgIHJldHVybiBwYXRoXG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIG51bGxcbiAgfVxuXG4gIHByaXZhdGUgZ2V0VGVtcGxhdGVGb2xkZXJQYXRoKHRlbXBsYXRlclBsdWdpbjogYW55KTogc3RyaW5nIHwgbnVsbCB7XG4gICAgY29uc3Qgc2V0dGluZ3MgPSB0ZW1wbGF0ZXJQbHVnaW4uc2V0dGluZ3NcblxuICAgIGlmICghc2V0dGluZ3MpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJUZW1wbGF0ZXIgcGx1Z2luIGhhcyBubyBzZXR0aW5nc1wiKVxuICAgICAgcmV0dXJuIG51bGxcbiAgICB9XG5cbiAgICAvLyBUcnkgZGlmZmVyZW50IHBvc3NpYmxlIHByb3BlcnR5IG5hbWVzIGZvciB0ZW1wbGF0ZSBmb2xkZXJcbiAgICBjb25zdCBwb3NzaWJsZVBhdGhzID0gW1xuICAgICAgc2V0dGluZ3MudGVtcGxhdGVzX2ZvbGRlciwgIC8vIENoYW5nZWQgZnJvbSB0ZW1wbGF0ZV9mb2xkZXIgdG8gbWF0Y2ggYWN0dWFsIHNldHRpbmdcbiAgICAgIHNldHRpbmdzLnRlbXBsYXRlX2ZvbGRlcixcbiAgICAgIHNldHRpbmdzLnRlbXBsYXRlRm9sZGVyLFxuICAgICAgc2V0dGluZ3MudGVtcGxhdGVGb2xkZXJQYXRoLFxuICAgICAgc2V0dGluZ3MuZm9sZGVyXG4gICAgXVxuXG4gICAgZm9yIChjb25zdCBwYXRoIG9mIHBvc3NpYmxlUGF0aHMpIHtcbiAgICAgIGlmIChwYXRoICYmIHR5cGVvZiBwYXRoID09PSBcInN0cmluZ1wiKSB7XG4gICAgICAgIHJldHVybiBwYXRoXG4gICAgICB9XG4gICAgfVxuXG4gICAgY29uc29sZS5lcnJvcihcbiAgICAgIFwiVGVtcGxhdGUgZm9sZGVyIG5vdCBmb3VuZCBpbiBUZW1wbGF0ZXIgc2V0dGluZ3MuIEF2YWlsYWJsZSBzZXR0aW5nczpcIixcbiAgICAgIE9iamVjdC5rZXlzKHNldHRpbmdzKVxuICAgIClcbiAgICByZXR1cm4gbnVsbFxuICB9XG5cbiAgYXN5bmMgY3JlYXRlVGVtcGxhdGVNYW5pZmVzdChiYXNlUGF0aDogc3RyaW5nKSB7XG4gICAgY29uc3QgbWFuaWZlc3RQYXRoID0gYCR7YmFzZVBhdGh9L3RlbXBsYXRlLW1hbmlmZXN0Lmpzb25gXG4gICAgY29uc3QgbWFuaWZlc3RDb250ZW50ID0gSlNPTi5zdHJpbmdpZnkodGhpcy5tYW5pZmVzdCwgbnVsbCwgMilcblxuICAgIHRyeSB7XG4gICAgICAvLyBDaGVjayBpZiBtYW5pZmVzdCBhbHJlYWR5IGV4aXN0c1xuICAgICAgY29uc3QgZXhpc3RpbmdNYW5pZmVzdCA9XG4gICAgICAgIHRoaXMuYXBwLnZhdWx0LmdldEFic3RyYWN0RmlsZUJ5UGF0aChtYW5pZmVzdFBhdGgpXG4gICAgICBpZiAoZXhpc3RpbmdNYW5pZmVzdCkge1xuICAgICAgICAvLyBVcGRhdGUgdGhlIGV4aXN0aW5nIG1hbmlmZXN0XG4gICAgICAgIGNvbnN0IGZpbGUgPSBleGlzdGluZ01hbmlmZXN0IGFzIGltcG9ydChcIm9ic2lkaWFuXCIpLlRGaWxlXG4gICAgICAgIGF3YWl0IHRoaXMuYXBwLnZhdWx0Lm1vZGlmeShmaWxlLCBtYW5pZmVzdENvbnRlbnQpXG4gICAgICAgIGNvbnNvbGUubG9nKGBVcGRhdGVkIHRlbXBsYXRlIG1hbmlmZXN0OiAke21hbmlmZXN0UGF0aH1gKVxuICAgICAgICByZXR1cm5cbiAgICAgIH1cblxuICAgICAgLy8gQ3JlYXRlIHRoZSBtYW5pZmVzdCBmaWxlXG4gICAgICBhd2FpdCB0aGlzLmFwcC52YXVsdC5jcmVhdGUobWFuaWZlc3RQYXRoLCBtYW5pZmVzdENvbnRlbnQpXG4gICAgICBjb25zb2xlLmxvZyhgQ3JlYXRlZCB0ZW1wbGF0ZSBtYW5pZmVzdDogJHttYW5pZmVzdFBhdGh9YClcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBuZXcgTm90aWNlKGBFcnJvciBjcmVhdGluZyB0ZW1wbGF0ZSBtYW5pZmVzdCAke21hbmlmZXN0UGF0aH1gKVxuICAgICAgY29uc29sZS5lcnJvcihgRXJyb3IgY3JlYXRpbmcgdGVtcGxhdGUgbWFuaWZlc3QgJHttYW5pZmVzdFBhdGh9OmAsIGUpXG4gICAgfVxuICB9XG5cbiAgYXN5bmMgY2hlY2tGb3JUZW1wbGF0ZVVwZGF0ZXMoKTogUHJvbWlzZTxib29sZWFuPiB7XG4gICAgLy8gVGhpcyB3b3VsZCBjaGVjayBpZiB0ZW1wbGF0ZXMgbmVlZCB0byBiZSB1cGRhdGVkXG4gICAgLy8gRm9yIG5vdywgd2UnbGwganVzdCByZXR1cm4gZmFsc2VcbiAgICBjb25zb2xlLmxvZyhcIkNoZWNraW5nIGZvciB0ZW1wbGF0ZSB1cGRhdGVzXCIpXG4gICAgcmV0dXJuIGZhbHNlXG4gIH1cblxuICBhc3luYyB1cGRhdGVUZW1wbGF0ZXMoKSB7XG4gICAgdHJ5IHtcbiAgICAgIC8vIFRoaXMgd291bGQgdXBkYXRlIGV4aXN0aW5nIHRlbXBsYXRlc1xuICAgICAgY29uc29sZS5sb2coXCJVcGRhdGluZyB0ZW1wbGF0ZXNcIilcblxuICAgICAgLy8gR2V0IFRlbXBsYXRlciBwbHVnaW4gc2V0dGluZ3MgdG8gZmluZCB0ZW1wbGF0ZSBmb2xkZXJcbiAgICAgIGNvbnN0IHRlbXBsYXRlclBsdWdpbiA9IHRoaXMuZ2V0VGVtcGxhdGVyUGx1Z2luKClcbiAgICAgIGlmICghdGVtcGxhdGVyUGx1Z2luKSB7XG4gICAgICAgIG5ldyBOb3RpY2UoXG4gICAgICAgICAgXCJUZW1wbGF0ZXIgcGx1Z2luIG5vdCBmb3VuZC4gUGxlYXNlIGluc3RhbGwgYW5kIGVuYWJsZSB0aGUgVGVtcGxhdGVyIHBsdWdpbiBmaXJzdC5cIlxuICAgICAgICApXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXG4gICAgICAgICAgXCJUZW1wbGF0ZXIgcGx1Z2luIG5vdCBmb3VuZC4gUGxlYXNlIGluc3RhbGwgYW5kIGVuYWJsZSB0aGUgVGVtcGxhdGVyIHBsdWdpbiBmaXJzdC5cIlxuICAgICAgICApXG4gICAgICAgIHJldHVyblxuICAgICAgfVxuXG4gICAgICBjb25zdCB0ZW1wbGF0ZUZvbGRlclBhdGggPSB0aGlzLmdldFRlbXBsYXRlRm9sZGVyUGF0aCh0ZW1wbGF0ZXJQbHVnaW4pXG4gICAgICBpZiAoIXRlbXBsYXRlRm9sZGVyUGF0aCkge1xuICAgICAgICBuZXcgTm90aWNlKFxuICAgICAgICAgIFwiVGVtcGxhdGUgZm9sZGVyIG5vdCBjb25maWd1cmVkIGluIFRlbXBsYXRlciBzZXR0aW5ncy4gUGxlYXNlIGNvbmZpZ3VyZSBpdCBpbiBUZW1wbGF0ZXIgc2V0dGluZ3MgZmlyc3QuXCJcbiAgICAgICAgKVxuICAgICAgICBjb25zb2xlLmVycm9yKFxuICAgICAgICAgIFwiVGVtcGxhdGUgZm9sZGVyIG5vdCBjb25maWd1cmVkIGluIFRlbXBsYXRlciBzZXR0aW5ncy4gUGxlYXNlIGNvbmZpZ3VyZSBpdCBpbiBUZW1wbGF0ZXIgc2V0dGluZ3MgZmlyc3QuXCJcbiAgICAgICAgKVxuICAgICAgICByZXR1cm5cbiAgICAgIH1cblxuICAgICAgY29uc3QgZnVsbFRlbXBsYXRlUGF0aCA9IGAke3RlbXBsYXRlRm9sZGVyUGF0aH0vJHt0aGlzLnNldHRpbmdzLnRlbXBsYXRlRm9sZGVyfWBcblxuICAgICAgLy8gVXBkYXRlIHRlbXBsYXRlcyAodGhpcyB3aWxsIG92ZXJ3cml0ZSBleGlzdGluZyBvbmVzKVxuICAgICAgYXdhaXQgdGhpcy5pbnN0YWxsQ291cnNlVGVtcGxhdGVzKGZ1bGxUZW1wbGF0ZVBhdGgpXG4gICAgICBhd2FpdCB0aGlzLmluc3RhbGxNb2R1bGVUZW1wbGF0ZXMoZnVsbFRlbXBsYXRlUGF0aClcbiAgICAgIGF3YWl0IHRoaXMuaW5zdGFsbENoYXB0ZXJUZW1wbGF0ZXMoZnVsbFRlbXBsYXRlUGF0aClcbiAgICAgIGF3YWl0IHRoaXMuaW5zdGFsbEFzc2lnbm1lbnRUZW1wbGF0ZXMoZnVsbFRlbXBsYXRlUGF0aClcbiAgICAgIGF3YWl0IHRoaXMuaW5zdGFsbERhaWx5VGVtcGxhdGVzKGZ1bGxUZW1wbGF0ZVBhdGgpXG4gICAgICBhd2FpdCB0aGlzLmluc3RhbGxVdGlsaXR5VGVtcGxhdGVzKGZ1bGxUZW1wbGF0ZVBhdGgpXG5cbiAgICAgIC8vIFVwZGF0ZSBSRUFETUVcbiAgICAgIGF3YWl0IHRoaXMuY3JlYXRlUkVBRE1FKGZ1bGxUZW1wbGF0ZVBhdGgpXG5cbiAgICAgIC8vIFVwZGF0ZSB0ZW1wbGF0ZSBtYW5pZmVzdFxuICAgICAgYXdhaXQgdGhpcy5jcmVhdGVUZW1wbGF0ZU1hbmlmZXN0KGZ1bGxUZW1wbGF0ZVBhdGgpXG5cbiAgICAgIG5ldyBOb3RpY2UoXCJUdWNrZXJzIFRvb2xzIHRlbXBsYXRlcyB1cGRhdGVkIHN1Y2Nlc3NmdWxseSFcIilcbiAgICAgIGNvbnNvbGUubG9nKFwiVHVja2VycyBUb29scyB0ZW1wbGF0ZXMgdXBkYXRlZCBzdWNjZXNzZnVsbHlcIilcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHVwZGF0aW5nIHRlbXBsYXRlczpcIiwgZXJyb3IpXG4gICAgICBuZXcgTm90aWNlKFwiRXJyb3IgdXBkYXRpbmcgdGVtcGxhdGVzLiBDaGVjayBjb25zb2xlIGZvciBkZXRhaWxzLlwiKVxuICAgIH1cbiAgfVxuXG4gIGFzeW5jIGluc3RhbGxDb3Vyc2VUZW1wbGF0ZXMoYmFzZVBhdGg6IHN0cmluZykge1xuICAgIGNvbnN0IGNvdXJzZVBhdGggPSBgJHtiYXNlUGF0aH0vQ291cnNlc2BcblxuICAgIC8vIENyZWF0ZSBDb3Vyc2UgSG9tZXBhZ2UgdGVtcGxhdGVcbiAgICBjb25zdCBjb3Vyc2VIb21lcGFnZVRlbXBsYXRlID0gdGhpcy5nZW5lcmF0ZUNvdXJzZUhvbWVwYWdlVGVtcGxhdGUoKVxuICAgIGF3YWl0IHRoaXMud3JpdGVUZW1wbGF0ZUZpbGUoXG4gICAgICBgJHtjb3Vyc2VQYXRofS9DcmVhdGUgQ291cnNlIEhvbWVwYWdlLm1kYCxcbiAgICAgIGNvdXJzZUhvbWVwYWdlVGVtcGxhdGVcbiAgICApXG5cbiAgICAvLyBDcmVhdGUgQ291cnNlIEluZGV4IHRlbXBsYXRlXG4gICAgY29uc3QgY291cnNlSW5kZXhUZW1wbGF0ZSA9IHRoaXMuZ2VuZXJhdGVDb3Vyc2VJbmRleFRlbXBsYXRlKClcbiAgICBhd2FpdCB0aGlzLndyaXRlVGVtcGxhdGVGaWxlKFxuICAgICAgYCR7Y291cnNlUGF0aH0vQ291cnNlIEluZGV4Lm1kYCxcbiAgICAgIGNvdXJzZUluZGV4VGVtcGxhdGVcbiAgICApXG4gIH1cblxuICBhc3luYyBpbnN0YWxsTW9kdWxlVGVtcGxhdGVzKGJhc2VQYXRoOiBzdHJpbmcpIHtcbiAgICBjb25zdCBtb2R1bGVQYXRoID0gYCR7YmFzZVBhdGh9L01vZHVsZXNgXG5cbiAgICAvLyBDcmVhdGUgTW9kdWxlIHRlbXBsYXRlXG4gICAgY29uc3QgbW9kdWxlVGVtcGxhdGUgPSB0aGlzLmdlbmVyYXRlTW9kdWxlVGVtcGxhdGUoKVxuICAgIGF3YWl0IHRoaXMud3JpdGVUZW1wbGF0ZUZpbGUoXG4gICAgICBgJHttb2R1bGVQYXRofS9DcmVhdGUgTW9kdWxlLm1kYCxcbiAgICAgIG1vZHVsZVRlbXBsYXRlXG4gICAgKVxuICB9XG5cbiAgYXN5bmMgaW5zdGFsbENoYXB0ZXJUZW1wbGF0ZXMoYmFzZVBhdGg6IHN0cmluZykge1xuICAgIGNvbnN0IGNoYXB0ZXJQYXRoID0gYCR7YmFzZVBhdGh9L0NoYXB0ZXJzYFxuXG4gICAgLy8gQ3JlYXRlIENoYXB0ZXIgdGVtcGxhdGVcbiAgICBjb25zdCBjaGFwdGVyVGVtcGxhdGUgPSB0aGlzLmdlbmVyYXRlQ2hhcHRlclRlbXBsYXRlKClcbiAgICBhd2FpdCB0aGlzLndyaXRlVGVtcGxhdGVGaWxlKFxuICAgICAgYCR7Y2hhcHRlclBhdGh9L0NyZWF0ZSBDaGFwdGVyLm1kYCxcbiAgICAgIGNoYXB0ZXJUZW1wbGF0ZVxuICAgIClcbiAgfVxuXG4gIGFzeW5jIGluc3RhbGxBc3NpZ25tZW50VGVtcGxhdGVzKGJhc2VQYXRoOiBzdHJpbmcpIHtcbiAgICBjb25zdCBhc3NpZ25tZW50UGF0aCA9IGAke2Jhc2VQYXRofS9Bc3NpZ25tZW50c2BcblxuICAgIC8vIENyZWF0ZSBBc3NpZ25tZW50IHRlbXBsYXRlXG4gICAgY29uc3QgYXNzaWdubWVudFRlbXBsYXRlID0gdGhpcy5nZW5lcmF0ZUFzc2lnbm1lbnRUZW1wbGF0ZSgpXG4gICAgYXdhaXQgdGhpcy53cml0ZVRlbXBsYXRlRmlsZShcbiAgICAgIGAke2Fzc2lnbm1lbnRQYXRofS9DcmVhdGUgQXNzaWdubWVudC5tZGAsXG4gICAgICBhc3NpZ25tZW50VGVtcGxhdGVcbiAgICApXG4gIH1cblxuICBhc3luYyBpbnN0YWxsRGFpbHlUZW1wbGF0ZXMoYmFzZVBhdGg6IHN0cmluZykge1xuICAgIGNvbnN0IGRhaWx5UGF0aCA9IGAke2Jhc2VQYXRofS9EYWlseWBcblxuICAgIC8vIENyZWF0ZSBEYWlseSBOb3RlIHRlbXBsYXRlXG4gICAgY29uc3QgZGFpbHlOb3RlVGVtcGxhdGUgPSB0aGlzLmdlbmVyYXRlRGFpbHlOb3RlVGVtcGxhdGUoKVxuICAgIGF3YWl0IHRoaXMud3JpdGVUZW1wbGF0ZUZpbGUoXG4gICAgICBgJHtkYWlseVBhdGh9L0RhaWx5IE5vdGUubWRgLFxuICAgICAgZGFpbHlOb3RlVGVtcGxhdGVcbiAgICApXG4gIH1cblxuICBhc3luYyBpbnN0YWxsVXRpbGl0eVRlbXBsYXRlcyhiYXNlUGF0aDogc3RyaW5nKSB7XG4gICAgY29uc3QgdXRpbGl0eVBhdGggPSBgJHtiYXNlUGF0aH0vVXRpbGl0aWVzYFxuXG4gICAgLy8gQ3JlYXRlIFZvY2FidWxhcnkgRW50cnkgdGVtcGxhdGVcbiAgICBjb25zdCB2b2NhYlRlbXBsYXRlID0gdGhpcy5nZW5lcmF0ZVZvY2FidWxhcnlUZW1wbGF0ZSgpXG4gICAgYXdhaXQgdGhpcy53cml0ZVRlbXBsYXRlRmlsZShcbiAgICAgIGAke3V0aWxpdHlQYXRofS9Wb2NhYnVsYXJ5IEVudHJ5Lm1kYCxcbiAgICAgIHZvY2FiVGVtcGxhdGVcbiAgICApXG5cbiAgICAvLyBDcmVhdGUgRHVlIERhdGUgRW50cnkgdGVtcGxhdGVcbiAgICBjb25zdCBkdWVEYXRlVGVtcGxhdGUgPSB0aGlzLmdlbmVyYXRlRHVlRGF0ZVRlbXBsYXRlKClcbiAgICBhd2FpdCB0aGlzLndyaXRlVGVtcGxhdGVGaWxlKFxuICAgICAgYCR7dXRpbGl0eVBhdGh9L0R1ZSBEYXRlIEVudHJ5Lm1kYCxcbiAgICAgIGR1ZURhdGVUZW1wbGF0ZVxuICAgIClcbiAgfVxuXG4gIGFzeW5jIHdyaXRlVGVtcGxhdGVGaWxlKHBhdGg6IHN0cmluZywgY29udGVudDogc3RyaW5nKSB7XG4gICAgdHJ5IHtcbiAgICAgIC8vIENoZWNrIGlmIGZpbGUgYWxyZWFkeSBleGlzdHNcbiAgICAgIGNvbnN0IGV4aXN0aW5nRmlsZSA9IHRoaXMuYXBwLnZhdWx0LmdldEFic3RyYWN0RmlsZUJ5UGF0aChwYXRoKVxuICAgICAgaWYgKGV4aXN0aW5nRmlsZSkge1xuICAgICAgICAvLyBGb3Igbm93LCB3ZSdsbCB1cGRhdGUgZXhpc3RpbmcgdGVtcGxhdGVzXG4gICAgICAgIC8vIEluIGEgcmVhbCBpbXBsZW1lbnRhdGlvbiwgd2UnZCBjaGVjayB2ZXJzaW9ucyBhbmQgb2ZmZXIgdG8gdXBkYXRlXG4gICAgICAgIGNvbnNvbGUubG9nKGBVcGRhdGluZyBleGlzdGluZyB0ZW1wbGF0ZSBmaWxlOiAke3BhdGh9YClcbiAgICAgICAgY29uc3QgZmlsZSA9IGV4aXN0aW5nRmlsZSBhcyBpbXBvcnQoXCJvYnNpZGlhblwiKS5URmlsZVxuICAgICAgICBhd2FpdCB0aGlzLmFwcC52YXVsdC5tb2RpZnkoZmlsZSwgY29udGVudClcbiAgICAgICAgcmV0dXJuXG4gICAgICB9XG5cbiAgICAgIC8vIENyZWF0ZSB0aGUgZmlsZVxuICAgICAgYXdhaXQgdGhpcy5hcHAudmF1bHQuY3JlYXRlKHBhdGgsIGNvbnRlbnQpXG4gICAgICBjb25zb2xlLmxvZyhgQ3JlYXRlZCB0ZW1wbGF0ZSBmaWxlOiAke3BhdGh9YClcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBuZXcgTm90aWNlKGBFcnJvciBjcmVhdGluZyB0ZW1wbGF0ZSBmaWxlICR7cGF0aH1gKVxuICAgICAgY29uc29sZS5lcnJvcihgRXJyb3IgY3JlYXRpbmcgdGVtcGxhdGUgZmlsZSAke3BhdGh9OmAsIGUpXG4gICAgfVxuICB9XG5cbiAgZ2VuZXJhdGVDb3Vyc2VIb21lcGFnZVRlbXBsYXRlKCk6IHN0cmluZyB7XG4gICAgY29uc3QgZW5oYW5jZWRNZXRhZGF0YSA9IHRoaXMuc2V0dGluZ3MudXNlRW5oYW5jZWRNZXRhZGF0YTtcbiAgICBcbiAgICBpZiAoZW5oYW5jZWRNZXRhZGF0YSkge1xuICAgICAgcmV0dXJuIGAtLS1cbmNvdXJzZV9pZDogPCUgY291cnNlSWQgJT5cbmNvdXJzZV9zZWFzb246IDwlIGNvdXJzZVNlYXNvbiAlPlxuY291cnNlX3llYXI6IDwlIGNvdXJzZVllYXIgJT5cbmNyZWF0ZWQ6IDwlIHRwLmRhdGUubm93KFwiWVlZWS1NTS1ERFtUXUhIOm1tOnNzWlwiKSAlPlxudGFnczogXG4gIC0gPCUgY291cnNlSWQgJT5cbiAgLSAke3RoaXMuc2V0dGluZ3Muc2Nob29sQWJicmV2aWF0aW9ufS88JSBjb3Vyc2VZZWFyICU+LzwlIGNvdXJzZVNlYXNvbiAlPi88JSBjb3Vyc2VJZCAlPi9cbiAgLSBjb3Vyc2VfaG9tZVxuICAtIGVkdWNhdGlvblxuICAtICR7dGhpcy5zZXR0aW5ncy5zY2hvb2xOYW1lLnJlcGxhY2UoL1xccysvZywgJ18nKX1cbmJhbm5lcjpcbmNzc2NsYXNzZXM6XG4gIC0gd2hpdGVib2FyZC1jb3Vyc2Vcbi0tLVxuXG48JSpcbi8vIFR1Y2tlcnMgVG9vbHMgQ291cnNlIENyZWF0aW9uXG4vLyBGb3IgYmVzdCBleHBlcmllbmNlLCB1c2UgdGhlIHBsdWdpbiBjb21tYW5kOiBDb21tYW5kIFBhbGV0dGUgXHUyMTkyICdDcmVhdGUgTmV3IENvdXJzZSdcblxubGV0IGNvdXJzZU5hbWUgPSBcIk5ldyBDb3Vyc2VcIjtcbmxldCBjb3Vyc2VTZWFzb24gPSBcIkZhbGxcIjsgXG5sZXQgY291cnNlWWVhciA9IG5ldyBEYXRlKCkuZ2V0RnVsbFllYXIoKS50b1N0cmluZygpO1xubGV0IGNvdXJzZUlkID0gXCJDT1VSU0VfSURcIjtcblxuLy8gVHJ5IHRvIHVzZSBzeXN0ZW0gcHJvbXB0cywgd2l0aCBncmFjZWZ1bCBmYWxsYmFja1xudHJ5IHtcbiAgaWYgKHRwICYmIHRwLnN5c3RlbSAmJiB0cC5zeXN0ZW0ucHJvbXB0KSB7XG4gICAgY291cnNlTmFtZSA9IGF3YWl0IHRwLnN5c3RlbS5wcm9tcHQoXCJDb3Vyc2UgTmFtZSAoZS5nLiBTV08tMjUwIC0gQ291cnNlIFRpdGxlKVwiKSB8fCBjb3Vyc2VOYW1lO1xuICAgIGNvdXJzZUlkID0gY291cnNlTmFtZS5zcGxpdCgnIC0gJylbMF0gfHwgY291cnNlTmFtZS5yZXBsYWNlKC9bXmEtekEtWjAtOV0vZywgXCJfXCIpO1xuICAgIGNvdXJzZVNlYXNvbiA9IGF3YWl0IHRwLnN5c3RlbS5zdWdnZXN0ZXIoW1wiRmFsbFwiLFwiV2ludGVyXCIsXCJTcHJpbmdcIixcIlN1bW1lclwiXSxbXCJGYWxsXCIsXCJXaW50ZXJcIixcIlNwcmluZ1wiLFwiU3VtbWVyXCJdLCBcIlNlYXNvblwiKSB8fCBjb3Vyc2VTZWFzb247XG4gICAgY291cnNlWWVhciA9IGF3YWl0IHRwLnN5c3RlbS5wcm9tcHQoXCJZZWFyXCIpIHx8IGNvdXJzZVllYXI7XG4gIH0gZWxzZSB7XG4gICAgY29uc29sZS5sb2coXCJTeXN0ZW0gcHJvbXB0cyBub3QgYXZhaWxhYmxlLCB1c2UgdGhlIHBsdWdpbiBjb21tYW5kIGluc3RlYWRcIik7XG4gIH1cbn0gY2F0Y2ggKGUpIHtcbiAgY29uc29sZS5lcnJvcihcIkVycm9yIHdpdGggc3lzdGVtIHByb21wdHM6XCIsIGUubWVzc2FnZSk7XG4gIGNvbnNvbGUubG9nKFwiVXNlIHRoZSBwbHVnaW4gY29tbWFuZDogQ29tbWFuZCBQYWxldHRlIFx1MjE5MiAnQ3JlYXRlIE5ldyBDb3Vyc2UnXCIpO1xufVxuXG4vLyBNb3ZlIGZpbGUgdG8gYXBwcm9wcmlhdGUgbG9jYXRpb25cbmF3YWl0IHRwLmZpbGUubW92ZShcXGAvXFwke2NvdXJzZVllYXJ9L1xcJHtjb3Vyc2VTZWFzb259L1xcJHtjb3Vyc2VOYW1lfS9cXCR7Y291cnNlTmFtZX1cXGApO1xuXG4vLyBDcmVhdGUgYXR0YWNobWVudHMgZm9sZGVyXG50cnkge1xuICBhd2FpdCBhcHAudmF1bHQuY3JlYXRlRm9sZGVyKFxcYC9cXCR7Y291cnNlWWVhcn0vXFwke2NvdXJzZVNlYXNvbn0vXFwke2NvdXJzZU5hbWV9L0F0dGFjaG1lbnRzXFxgKTtcbn0gY2F0Y2ggKGUpIHtcbiAgLy8gRm9sZGVyIG1pZ2h0IGFscmVhZHkgZXhpc3Rcbn1cbiU+XG5cbiMgPCUgY291cnNlTmFtZSAlPlxuXG4jIyBDb3Vyc2UgSW5mb3JtYXRpb25cbioqQ291cnNlKio6IDwlIGNvdXJzZU5hbWUgJT5cbioqQ291cnNlIElEKio6IDwlIGNvdXJzZUlkICU+XG4qKlRlcm0qKjogPCUgY291cnNlU2Vhc29uICU+IDwlIGNvdXJzZVllYXIgJT5cbioqU2Nob29sKio6ICR7dGhpcy5zZXR0aW5ncy5zY2hvb2xOYW1lfVxuXG4jIyBJbnN0cnVjdG9yXG4qKk5hbWUqKjogXFxgSU5QVVRbdGV4dDppbnN0cnVjdG9yX25hbWVdXFxgXG4qKkVtYWlsKio6IFxcYElOUFVUW3RleHQ6aW5zdHJ1Y3Rvcl9lbWFpbF1cXGBcbioqT2ZmaWNlIEhvdXJzKio6IFxcYElOUFVUW3RleHQ6aW5zdHJ1Y3Rvcl9vZmZpY2VfaG91cnNdXFxgXG4qKk9mZmljZSBMb2NhdGlvbioqOiBcXGBJTlBVVFt0ZXh0Omluc3RydWN0b3Jfb2ZmaWNlX2xvY2F0aW9uXVxcYFxuXG4jIyBDb3Vyc2UgRGVzY3JpcHRpb25cblxcYElOUFVUW211bHRpbGluZSgxMHg1MCk6Y291cnNlX2Rlc2NyaXB0aW9uXVxcYFxuXG4jIyBMZWFybmluZyBPYmplY3RpdmVzXG5cXGBJTlBVVFttdWx0aWxpbmUoMTB4NTApOmxlYXJuaW5nX29iamVjdGl2ZXNdXFxgXG5cbiMjIFJlcXVpcmVkIFRleHRzXG5cXGBcXGBcXGBtZXRhLWJpbmQtanMtdmlld1xue3RleHRzfSBhcyB0ZXh0c1xuLS0tXG5jb25zdCBhdmFpbGFibGVUZXh0cyA9IGFwcC52YXVsdC5nZXRGaWxlcygpLmZpbHRlcihmaWxlID0+IGZpbGUuZXh0ZW5zaW9uID09ICdwZGYnKS5tYXAoZiA9PiBmPy5uYW1lKVxuY29uc3QgZXNjYXBlUmVnZXggPSAvWyxcXGAnKCldL2c7XG5vcHRpb25zID0gYXZhaWxhYmxlVGV4dHMubWFwKHQgPT4gXFxgb3B0aW9uKFtbXFwke3QucmVwbGFjZShlc2NhcGVSZWdleCxcXCQxKX1dXSwgXFwke3QucmVwbGFjZShlc2NhcGVSZWdleCxcXCQxKX0pXFxgIClcbmNvbnN0IHN0ciA9IFxcXFxcXGBJTlBVVFtpbmxpbmVMaXN0U3VnZ2VzdGVyKFxcJHtvcHRpb25zLmpvaW4oXCIsIFwiKX0pOnRleHRzXVxcXFxcXGBcbnJldHVybiBlbmdpbmUubWFya2Rvd24uY3JlYXRlKHN0cilcblxcYFxcYFxcYFxuXG4jIyBDb3Vyc2UgU2NoZWR1bGVcblxcYElOUFVUW211bHRpbGluZSgyMHg1MCk6Y291cnNlX3NjaGVkdWxlXVxcYFxuXG4jIyBBc3NpZ25tZW50c1xuXFxgSU5QVVRbbXVsdGlsaW5lKDE1eDUwKTphc3NpZ25tZW50c11cXGBcblxuIyMgUmVzb3VyY2VzXG5cXGBJTlBVVFttdWx0aWxpbmUoMTB4NTApOnJlc291cmNlc11cXGBcblxuIyMgVm9jYWJ1bGFyeVxuXFxgXFxgXFxgZGF0YXZpZXdqc1xuY29uc3Qge3Byb2Nlc3NDb3Vyc2VWb2NhYnVsYXJ5fSA9IHJlcXVpcmUoXCIke3RoaXMuc2V0dGluZ3MuZGF0YXZpZXdKc1BhdGggfHwgXCIvU3VwcG9ydGluZy9kYXRhdmlldy1mdW5jdGlvbnNcIn1cIik7XG5wcm9jZXNzQ291cnNlVm9jYWJ1bGFyeShkdiwgJzwlIGNvdXJzZUlkICU+Jyk7XG5cXGBcXGBcXGBcblxuIyMgRHVlIERhdGVzXG5cXGBcXGBcXGBkYXRhdmlld2pzXG5jb25zdCB7cHJvY2Vzc0R1ZURhdGVzfSA9IHJlcXVpcmUoXCIke3RoaXMuc2V0dGluZ3MuZGF0YXZpZXdKc1BhdGggfHwgXCIvU3VwcG9ydGluZy9kYXRhdmlldy1mdW5jdGlvbnNcIn1cIik7XG5wcm9jZXNzRHVlRGF0ZXMoZHYsJyM8JSBjb3Vyc2VJZCAlPicpO1xuXFxgXFxgXFxgXG5cbiMjIENsYXNzIE1hdGVyaWFsc1xuXFxgSU5QVVRbbXVsdGlsaW5lKDEweDUwKTpjbGFzc19tYXRlcmlhbHNdXFxgXG5cbiMjIENsYXNzbWF0ZXNcblxcYElOUFVUW211bHRpbGluZSgxNXg1MCk6Y2xhc3NtYXRlc11cXGBgO1xuICAgIH0gZWxzZSB7XG4gICAgICByZXR1cm4gYC0tLVxuY291cnNlX2lkOiA8JSBjb3Vyc2VJZCAlPlxuY291cnNlX25hbWU6IDwlIGNvdXJzZU5hbWUgJT5cbmNvdXJzZV9zZWFzb246IDwlIGNvdXJzZVNlYXNvbiAlPlxuY291cnNlX3llYXI6IDwlIGNvdXJzZVllYXIgJT5cbmNyZWF0ZWQ6IDwlIHRwLmRhdGUubm93KFwiWVlZWS1NTS1ERFtUXUhIOm1tOnNzWlwiKSAlPlxudGFnczpcbiAgLSA8JSBjb3Vyc2VJZCAlPlxuICAtIGNvdXJzZV9ob21lXG4gIC0gZWR1Y2F0aW9uXG4tLS1cblxuPCUqXG4vLyBUdWNrZXJzIFRvb2xzIENvdXJzZSBDcmVhdGlvblxuLy8gRm9yIGJlc3QgZXhwZXJpZW5jZSwgdXNlIHRoZSBwbHVnaW4gY29tbWFuZDogQ29tbWFuZCBQYWxldHRlIFx1MjE5MiAnQ3JlYXRlIE5ldyBDb3Vyc2UnXG5cbmxldCBjb3Vyc2VOYW1lID0gXCJOZXcgQ291cnNlXCI7XG5sZXQgY291cnNlU2Vhc29uID0gXCJGYWxsXCI7IFxubGV0IGNvdXJzZVllYXIgPSBuZXcgRGF0ZSgpLmdldEZ1bGxZZWFyKCkudG9TdHJpbmcoKTtcbmxldCBjb3Vyc2VJZCA9IFwiQ09VUlNFX0lEXCI7XG5cbi8vIFRyeSB0byB1c2Ugc3lzdGVtIHByb21wdHMsIHdpdGggZ3JhY2VmdWwgZmFsbGJhY2tcbnRyeSB7XG4gIGlmICh0cCAmJiB0cC5zeXN0ZW0gJiYgdHAuc3lzdGVtLnByb21wdCkge1xuICAgIGNvdXJzZU5hbWUgPSBhd2FpdCB0cC5zeXN0ZW0ucHJvbXB0KFwiQ291cnNlIE5hbWUgKGUuZy4gU1dPLTI1MCAtIENvdXJzZSBUaXRsZSlcIikgfHwgY291cnNlTmFtZTtcbiAgICBjb3Vyc2VJZCA9IGNvdXJzZU5hbWUuc3BsaXQoJyAtICcpWzBdIHx8IGNvdXJzZU5hbWUucmVwbGFjZSgvW15hLXpBLVowLTldL2csIFwiX1wiKTtcbiAgICBjb3Vyc2VTZWFzb24gPSBhd2FpdCB0cC5zeXN0ZW0uc3VnZ2VzdGVyKFtcIkZhbGxcIixcIldpbnRlclwiLFwiU3ByaW5nXCIsXCJTdW1tZXJcIl0sW1wiRmFsbFwiLFwiV2ludGVyXCIsXCJTcHJpbmdcIixcIlN1bW1lclwiXSwgXCJTZWFzb25cIikgfHwgY291cnNlU2Vhc29uO1xuICAgIGNvdXJzZVllYXIgPSBhd2FpdCB0cC5zeXN0ZW0ucHJvbXB0KFwiWWVhclwiKSB8fCBjb3Vyc2VZZWFyO1xuICB9IGVsc2Uge1xuICAgIGNvbnNvbGUubG9nKFwiU3lzdGVtIHByb21wdHMgbm90IGF2YWlsYWJsZSwgdXNlIHRoZSBwbHVnaW4gY29tbWFuZCBpbnN0ZWFkXCIpO1xuICB9XG59IGNhdGNoIChlKSB7XG4gIGNvbnNvbGUuZXJyb3IoXCJFcnJvciB3aXRoIHN5c3RlbSBwcm9tcHRzOlwiLCBlLm1lc3NhZ2UpO1xuICBjb25zb2xlLmxvZyhcIlVzZSB0aGUgcGx1Z2luIGNvbW1hbmQ6IENvbW1hbmQgUGFsZXR0ZSBcdTIxOTIgJ0NyZWF0ZSBOZXcgQ291cnNlJ1wiKTtcbn1cblxuLy8gTW92ZSBmaWxlIHRvIGFwcHJvcHJpYXRlIGxvY2F0aW9uXG5hd2FpdCB0cC5maWxlLm1vdmUoXFxgL1xcJHtjb3Vyc2VZZWFyfS9cXCR7Y291cnNlU2Vhc29ufS9cXCR7Y291cnNlTmFtZX0vXFwke2NvdXJzZU5hbWV9XFxgKTtcblxuLy8gQ3JlYXRlIGF0dGFjaG1lbnRzIGZvbGRlclxudHJ5IHtcbiAgYXdhaXQgYXBwLnZhdWx0LmNyZWF0ZUZvbGRlcihcXGAvXFwke2NvdXJzZVllYXJ9L1xcJHtjb3Vyc2VTZWFzb259L1xcJHtjb3Vyc2VOYW1lfS9BdHRhY2htZW50c1xcYCk7XG59IGNhdGNoIChlKSB7XG4gIC8vIEZvbGRlciBtaWdodCBhbHJlYWR5IGV4aXN0XG59XG4lPlxuXG4jIDwlIGNvdXJzZU5hbWUgJT5cblxuIyMgQ291cnNlIEluZm9ybWF0aW9uXG4qKkNvdXJzZSBJRCoqOiA8JSBjb3Vyc2VJZCAlPlxuKipUZXJtKio6IDwlIGNvdXJzZVNlYXNvbiAlPiA8JSBjb3Vyc2VZZWFyICU+XG4qKlNjaG9vbCoqOiAke3RoaXMuc2V0dGluZ3Muc2Nob29sTmFtZX1cblxuIyMgSW5zdHJ1Y3RvclxuKipOYW1lKio6IFxcYElOUFVUW3RleHQ6aW5zdHJ1Y3Rvcl9uYW1lXVxcYFxuKipFbWFpbCoqOiBcXGBJTlBVVFt0ZXh0Omluc3RydWN0b3JfZW1haWxdXFxgXG4qKk9mZmljZSBIb3VycyoqOiBcXGBJTlBVVFt0ZXh0Omluc3RydWN0b3Jfb2ZmaWNlX2hvdXJzXVxcYFxuKipPZmZpY2UgTG9jYXRpb24qKjogXFxgSU5QVVRbdGV4dDppbnN0cnVjdG9yX29mZmljZV9sb2NhdGlvbl1cXGBcblxuIyMgQ291cnNlIERlc2NyaXB0aW9uXG5cXGBJTlBVVFttdWx0aWxpbmUoMTB4NTApOmNvdXJzZV9kZXNjcmlwdGlvbl1cXGBcblxuIyMgTGVhcm5pbmcgT2JqZWN0aXZlc1xuXFxgSU5QVVRbbXVsdGlsaW5lKDEweDUwKTpsZWFybmluZ19vYmplY3RpdmVzXVxcYFxuXG4jIyBSZXF1aXJlZCBUZXh0c1xuXFxgXFxgXFxgbWV0YS1iaW5kLWpzLXZpZXdcbnt0ZXh0c30gYXMgdGV4dHNcbi0tLVxuY29uc3QgYXZhaWxhYmxlVGV4dHMgPSBhcHAudmF1bHQuZ2V0RmlsZXMoKS5maWx0ZXIoZmlsZSA9PiBmaWxlLmV4dGVuc2lvbiA9PSAncGRmJykubWFwKGYgPT4gZj8ubmFtZSlcbmNvbnN0IGVzY2FwZVJlZ2V4ID0gL1ssXFxgJygpXS9nO1xub3B0aW9ucyA9IGF2YWlsYWJsZVRleHRzLm1hcCh0ID0+IFxcYG9wdGlvbihbW1xcJHt0LnJlcGxhY2UoZXNjYXBlUmVnZXgsXFwkMSl9XV0sIFxcJHt0LnJlcGxhY2UoZXNjYXBlUmVnZXgsXFwkMSl9KVxcYCApXG5jb25zdCBzdHIgPSBcXFxcXFxgSU5QVVRbaW5saW5lTGlzdFN1Z2dlc3RlcihcXCR7b3B0aW9ucy5qb2luKFwiLCBcIil9KTp0ZXh0c11cXFxcXFxgXG5yZXR1cm4gZW5naW5lLm1hcmtkb3duLmNyZWF0ZShzdHIpXG5cXGBcXGBcXGBcblxuIyMgU2NoZWR1bGVcblxcYElOUFVUW211bHRpbGluZSgxNXg1MCk6Y291cnNlX3NjaGVkdWxlXVxcYFxuXG4jIyBBc3NpZ25tZW50c1xuXFxgSU5QVVRbbXVsdGlsaW5lKDEweDUwKTphc3NpZ25tZW50c11cXGBcblxuIyMgUmVzb3VyY2VzXG5cXGBJTlBVVFttdWx0aWxpbmUoMTB4NTApOnJlc291cmNlc11cXGBcblxuIyMgVm9jYWJ1bGFyeVxuXFxgXFxgXFxgZGF0YXZpZXdqc1xuY29uc3Qge3Byb2Nlc3NDb3Vyc2VWb2NhYnVsYXJ5fSA9IHJlcXVpcmUoXCIke3RoaXMuc2V0dGluZ3MuZGF0YXZpZXdKc1BhdGggfHwgXCIvU3VwcG9ydGluZy9kYXRhdmlldy1mdW5jdGlvbnNcIn1cIik7XG5wcm9jZXNzQ291cnNlVm9jYWJ1bGFyeShkdiwgJzwlIGNvdXJzZUlkICU+Jyk7XG5cXGBcXGBcXGBcblxuIyMgRHVlIERhdGVzXG5cXGBcXGBcXGBkYXRhdmlld2pzXG5jb25zdCB7cHJvY2Vzc0R1ZURhdGVzfSA9IHJlcXVpcmUoXCIke3RoaXMuc2V0dGluZ3MuZGF0YXZpZXdKc1BhdGggfHwgXCIvU3VwcG9ydGluZy9kYXRhdmlldy1mdW5jdGlvbnNcIn1cIik7XG5wcm9jZXNzRHVlRGF0ZXMoZHYsJyM8JSBjb3Vyc2VJZCAlPicpO1xuXFxgXFxgXFxgYDtcbiAgICB9XG4gIH1cblxuICBnZW5lcmF0ZUNvdXJzZUluZGV4VGVtcGxhdGUoKTogc3RyaW5nIHtcbiAgICByZXR1cm4gYC0tLVxuY29udGVudF90eXBlOiBjb3Vyc2VfaW5kZXhcbnRhZ3M6XG4gIC0gaW5kZXhcbi0tLVxuXG4jIENvdXJzZSBJbmRleFxuXG4jIyBNb2R1bGVzXG5cbiMjIENoYXB0ZXJzXG5cbiMjIEFzc2lnbm1lbnRzXG5cbiMjIFJlc291cmNlc1xuXG4jIyBWb2NhYnVsYXJ5XG5cbiMjIER1ZSBEYXRlc2BcbiAgfVxuXG4gIGdlbmVyYXRlTW9kdWxlVGVtcGxhdGUoKTogc3RyaW5nIHtcbiAgICByZXR1cm4gYC0tLVxuJHtcbiAgdGhpcy5zZXR0aW5ncy51c2VFbmhhbmNlZE1ldGFkYXRhXG4gICAgPyBgY291cnNlX2lkOiA8JSBjb3Vyc2VJZCAlPlxubW9kdWxlX251bWJlcjogPCUgbW9kdWxlTnVtYmVyICU+XG53ZWVrX251bWJlcjogPCUgd2Vla051bWJlciAlPlxuY2xhc3NfZGF5OiA8JSBkYXlPZldlZWsgJT5cbmNvbnRlbnRfdHlwZTogbW9kdWxlXG5wYXJlbnRfY291cnNlOiBcIltbPCUgY291cnNlICU+XV1cImBcbiAgICA6IGBjb3Vyc2VfaWQ6IDwlIGNvdXJzZUlkICU+XG5tb2R1bGVfbnVtYmVyOiA8JSBtb2R1bGVOdW1iZXIgJT5cbndlZWtfbnVtYmVyOiA8JSB3ZWVrTnVtYmVyICU+XG5jbGFzc19kYXk6IDwlIGRheU9mV2VlayAlPmBcbn1cbmNyZWF0ZWQ6IDwlIHRwLmRhdGUubm93KFwiWVlZWS1NTS1ERFtUXUhIOm1tOnNzWlwiKSAlPlxudGFnczpcbiAgLSBlZHVjYXRpb25cbiAgLSA8JSBjb3Vyc2VJZCAlPlxuICAtIG1vZHVsZVxuLS0tXG5cbjwlKlxuY29uc3QgeyBzZWFzb24sIG1vZHVsZU51bWJlciwgd2Vla051bWJlciwgY291cnNlLCBjb3Vyc2VJZCwgZGlzY2lwbGluZSwgZGF5T2ZXZWVrIH0gPSBhd2FpdCB0cC51c2VyLm5ld19tb2R1bGUoYXBwLCB0cCwgXCIyMDI1XCIpO1xubGV0IHRpdGxlID0gY291cnNlSWRcbmlmIChtb2R1bGVOdW1iZXIgJiYgd2Vla051bWJlcikgeyB0aXRsZSA9IFxcYE1cXCR7bW9kdWxlTnVtYmVyfS9XXFwke3dlZWtOdW1iZXJ9XFxgfVxuZWxzZSBpZiAobW9kdWxlTnVtYmVyKSB7IHRpdGxlID0gXFxgTVxcJHttb2R1bGVOdW1iZXJ9XFxgIH0gXG5lbHNlIGlmICh3ZWVrTnVtYmVyKSB7IHRpdGxlID0gXFxgV1xcJHt3ZWVrTnVtYmVyfVxcYH1cbiU+XG5cbiMgW1s8JSBjb3Vyc2UgJT5dXSAtIDwlIHRpdGxlICU+IC0gPCUgZGF5T2ZXZWVrICU+XG5cbiMjIER1ZSBEYXRlc1xufCBEYXRlIHwgQXNzaWdubWVudCB8XG58IC0tLS0gfCAtLS0tLS0tLS0tIHxcbnwgICAgICB8ICAgICAgICAgICAgfFxufCAgICAgIHwgICAgICAgICAgICB8XG58ICAgICAgfCAgICAgICAgICAgIHxcblxuXFxgXFxgXFxgZGF0YXZpZXdqc1xuY29uc3Qge3Byb2Nlc3NEdWVEYXRlc30gPSByZXF1aXJlKFwiJHt0aGlzLnNldHRpbmdzLmRhdGF2aWV3SnNQYXRoIHx8IFwiL1N1cHBvcnRpbmcvZGF0YXZpZXctZnVuY3Rpb25zXCJ9XCIpO1xucHJvY2Vzc0R1ZURhdGVzKGR2LCcjPCUgY291cnNlSWQgJT4nKTtcblxcYFxcYFxcYFxuXG4jIyBMZWFybmluZyBPYmplY3RpdmVzXG5cbiMjIFJlYWRpbmcgQXNzaWdubWVudFxuXG4jIyBMZWN0dXJlIE5vdGVzXG5cbiMjIERpc2N1c3Npb24gUXVlc3Rpb25zXG5cbiMjIFZvY2FidWxhcnlcblxuXFxgXFxgXFxgZGF0YXZpZXdqc1xuY29uc3Qge3Byb2Nlc3NDb3Vyc2VWb2NhYnVsYXJ5fSA9IHJlcXVpcmUoXCIke3RoaXMuc2V0dGluZ3MuZGF0YXZpZXdKc1BhdGggfHwgXCIvU3VwcG9ydGluZy9kYXRhdmlldy1mdW5jdGlvbnNcIn1cIik7XG5wcm9jZXNzQ291cnNlVm9jYWJ1bGFyeShkdiwgJzwlIGNvdXJzZUlkICU+Jyk7XG5cXGBcXGBcXGBcblxuIyMgQWRkaXRpb25hbCBSZXNvdXJjZXNgXG4gIH1cblxuICBnZW5lcmF0ZUNoYXB0ZXJUZW1wbGF0ZSgpOiBzdHJpbmcge1xuICAgIHJldHVybiBgLS0tXG4ke1xuICB0aGlzLnNldHRpbmdzLnVzZUVuaGFuY2VkTWV0YWRhdGFcbiAgICA/IGBjb3Vyc2VfaWQ6IDwlIGNvdXJzZUlkICU+XG5jaGFwdGVyX251bWJlcjogPCUgY2hhcHRlck51bWJlciAlPlxuY29udGVudF90eXBlOiBjaGFwdGVyXG5wYXJlbnRfY291cnNlOiBcIltbPCUgY291cnNlICU+XV1cIlxudGV4dF9yZWZlcmVuY2U6IFwiW1s8JSB0ZXh0ICU+XV1cImBcbiAgICA6IGBjb3Vyc2VfaWQ6IDwlIGNvdXJzZUlkICU+XG5jaGFwdGVyX251bWJlcjogPCUgY2hhcHRlck51bWJlciAlPmBcbn1cbmNyZWF0ZWQ6IDwlIHRwLmRhdGUubm93KFwiWVlZWS1NTS1ERFtUXUhIOm1tOnNzWlwiKSAlPlxudGFnczpcbiAgLSBlZHVjYXRpb25cbiAgLSA8JSBjb3Vyc2VJZCAlPlxuICAtIGNoYXB0ZXJcbi0tLVxuXG48JSpcbmNvbnN0IHsgY2hhcHRlck51bWJlciwgY291cnNlLCBjb3Vyc2VJZCwgZGlzY2lwbGluZSwgdGV4dH0gPSBhd2FpdCB0cC51c2VyLm5ld19jaGFwdGVyKHRwKTtcbiU+XG5cbiMgW1s8JSB0ZXh0ICU+XV0gLSBDaGFwdGVyIDwlIGNoYXB0ZXJOdW1iZXIgJT5cblxuIyMgUmVhZGluZyBBc3NpZ25tZW50XG4tICoqVGV4dGJvb2sqKjogW1s8JSB0ZXh0ICU+XV1cbi0gKipDaGFwdGVyKio6IDwlIGNoYXB0ZXJOdW1iZXIgJT5cbi0gKipQYWdlcyoqOiBcblxuIyMgU3VtbWFyeVxuXG4jIyBLZXkgQ29uY2VwdHNcblxuIyMgVm9jYWJ1bGFyeVxuLSBcblxuIyMgTm90ZXNcblxuIyMgRGlzY3Vzc2lvbiBRdWVzdGlvbnNcblxuIyMgRnVydGhlciBSZWFkaW5nYFxuICB9XG5cbiAgZ2VuZXJhdGVBc3NpZ25tZW50VGVtcGxhdGUoKTogc3RyaW5nIHtcbiAgICByZXR1cm4gYC0tLVxuJHtcbiAgdGhpcy5zZXR0aW5ncy51c2VFbmhhbmNlZE1ldGFkYXRhXG4gICAgPyBgY291cnNlX2lkOiA8JSBjb3Vyc2VJZCAlPlxuYXNzaWdubWVudF90eXBlOiA8JSBhc3NpZ25tZW50VHlwZSAlPlxuZHVlX2RhdGU6IDwlIGR1ZURhdGUgJT5cbnBvaW50czogPCUgcG9pbnRzICU+XG5jb250ZW50X3R5cGU6IGFzc2lnbm1lbnRcbnBhcmVudF9jb3Vyc2U6IFwiW1s8JSBjb3Vyc2UgJT5dXVwiYFxuICAgIDogYGNvdXJzZV9pZDogPCUgY291cnNlSWQgJT5cbmFzc2lnbm1lbnRfdHlwZTogPCUgYXNzaWdubWVudFR5cGUgJT5cbmR1ZV9kYXRlOiA8JSBkdWVEYXRlICU+YFxufVxuY3JlYXRlZDogPCUgdHAuZGF0ZS5ub3coXCJZWVlZLU1NLUREW1RdSEg6bW06c3NaXCIpICU+XG5zdGF0dXM6IHBlbmRpbmdcbnRhZ3M6XG4gIC0gZWR1Y2F0aW9uXG4gIC0gPCUgY291cnNlSWQgJT5cbiAgLSBhc3NpZ25tZW50XG4tLS1cblxuIyA8JSBhc3NpZ25tZW50TmFtZSAlPiAtIDwlIGNvdXJzZUlkICU+XG5cbiMjIERlc2NyaXB0aW9uXG5cbiMjIEluc3RydWN0aW9uc1xuXG4jIyBEdWUgRGF0ZVxuKipBc3NpZ25lZCoqOiA8JSB0cC5kYXRlLm5vdyhcIllZWVktTU0tRERcIikgJT5cbioqRHVlKio6IDwlIGR1ZURhdGUgJT5cblxuIyMgU3VibWlzc2lvblxuXG4jIyBHcmFkaW5nIENyaXRlcmlhXG5cbiMjIFJlc291cmNlc1xuXG4jIER1ZSBEYXRlc1xufCA8JSBkdWVEYXRlICU+IHwgPCUgYXNzaWdubWVudE5hbWUgJT4gfCBwZW5kaW5nIHxcbmBcbiAgfVxuXG4gIGdlbmVyYXRlRGFpbHlOb3RlVGVtcGxhdGUoKTogc3RyaW5nIHtcbiAgICByZXR1cm4gYC0tLVxuY29udGVudF90eXBlOiBkYWlseV9ub3RlXG5kYXRlOiA8JSB0cC5kYXRlLm5vdyhcIllZWVktTU0tRERcIikgJT5cbnRhZ3M6XG4gIC0gZGFpbHlcbiAgLSA8JSB0cC5kYXRlLm5vdyhcIllZWVlcIikgJT5cbiAgLSA8JSB0cC5kYXRlLm5vdyhcIk1NXCIpICU+XG4gIC0gPCUgdHAuZGF0ZS5ub3coXCJERFwiKSAlPlxuLS0tXG5cbiMgPCUgdHAuZGF0ZS5ub3coXCJZWVlZLU1NLUREIC0gZGRkZFwiKSAlPlxuXG48PCBbWzwlIHRwLmRhdGUueWVzdGVyZGF5KFwiWVlZWS1NTS1ERFwiKSAlPl1dIHwgW1s8JSB0cC5kYXRlLnRvbW9ycm93KFwiWVlZWS1NTS1ERFwiKSAlPl1dID4+XG5cbiMjIFRvZGF5J3MgRm9jdXNcblxuIyMgQ291cnNlcyBXb3JrZWQgT25cbi0gXG5cbiMjIFRhc2tzIENvbXBsZXRlZFxuLSBbIF0gXG5cbiMjIFZvY2FidWxhcnkgUmV2aWV3ZWRcbi0gXG5cbiMjIEFzc2lnbm1lbnRzIER1ZVxuLSBcblxuIyMgTGVhcm5pbmcgQWNoaWV2ZW1lbnRzXG5cbiMjIENoYWxsZW5nZXNcblxuIyMgVG9tb3Jyb3cncyBQbGFuXG5cbiMjIFJlZmxlY3Rpb25gXG4gIH1cblxuICBnZW5lcmF0ZVZvY2FidWxhcnlUZW1wbGF0ZSgpOiBzdHJpbmcge1xuICAgIHJldHVybiBgIyMgPCUgdGVybSAlPlxuKipUZXJtKio6IDwlIHRlcm0gJT5cbioqUGFydCBvZiBTcGVlY2gqKjogXG4qKkRlZmluaXRpb24qKjogXG4qKkNvbnRleHQqKjogXG4qKkV4YW1wbGVzKio6IFxuKipSZWxhdGVkIFRlcm1zKio6IFxuKipTZWUgQWxzbyoqOmBcbiAgfVxuXG4gIGdlbmVyYXRlRHVlRGF0ZVRlbXBsYXRlKCk6IHN0cmluZyB7XG4gICAgcmV0dXJuIGB8IDwlIGR1ZURhdGUgJT4gfCA8JSBhc3NpZ25tZW50ICU+IHwgPCUgc3RhdHVzICU+IHxgXG4gIH1cblxuICBhc3luYyBjcmVhdGVSRUFETUUoYmFzZVBhdGg6IHN0cmluZykge1xuICAgIGNvbnN0IHJlYWRtZUNvbnRlbnQgPSBgIyBUdWNrZXJzIFRvb2xzIFRlbXBsYXRlc1xuXG5UaGlzIGRpcmVjdG9yeSBjb250YWlucyB0ZW1wbGF0ZXMgZm9yIHRoZSBUdWNrZXJzIFRvb2xzIE9ic2lkaWFuIHBsdWdpbi5cblxuIyMgVGVtcGxhdGUgQ2F0ZWdvcmllc1xuXG4tICoqQ291cnNlcyoqOiBUZW1wbGF0ZXMgZm9yIGNyZWF0aW5nIGFuZCBvcmdhbml6aW5nIGNvdXJzZXNcbi0gKipNb2R1bGVzKio6IFRlbXBsYXRlcyBmb3IgY291cnNlIG1vZHVsZXNcbi0gKipDaGFwdGVycyoqOiBUZW1wbGF0ZXMgZm9yIGNoYXB0ZXIgbm90ZXNcbi0gKipBc3NpZ25tZW50cyoqOiBUZW1wbGF0ZXMgZm9yIGFzc2lnbm1lbnRzXG4tICoqRGFpbHkqKjogVGVtcGxhdGVzIGZvciBkYWlseSBub3Rlc1xuLSAqKlV0aWxpdGllcyoqOiBIZWxwZXIgdGVtcGxhdGVzXG5cbiMjIFVzYWdlXG5cblRoZXNlIHRlbXBsYXRlcyBhcmUgZGVzaWduZWQgdG8gd29yayB3aXRoIHRoZSBUdWNrZXJzIFRvb2xzIHBsdWdpbi4gVG8gdXNlIHRoZW06XG5cbjEuIEluc3RhbGwgdGhlIFR1Y2tlcnMgVG9vbHMgcGx1Z2luXG4yLiBDb25maWd1cmUgeW91ciBzZXR0aW5ncyBpbiB0aGUgcGx1Z2luIHNldHRpbmdzIHRhYlxuMy4gVXNlIHRoZSBcIkluc2VydCBUZW1wbGF0ZVwiIGNvbW1hbmQgdG8gYXBwbHkgdGhlc2UgdGVtcGxhdGVzIHRvIG5ldyBub3Rlc1xuXG4jIyBDdXN0b21pemF0aW9uXG5cbkZlZWwgZnJlZSB0byBjdXN0b21pemUgdGhlc2UgdGVtcGxhdGVzIHRvIHN1aXQgeW91ciBuZWVkcy4gVGhlIHBsdWdpbiB3aWxsIG5vdCBvdmVyd3JpdGUgeW91ciBjaGFuZ2VzIHdoZW4gdXBkYXRpbmcgdGVtcGxhdGVzLmBcblxuICAgIGF3YWl0IHRoaXMud3JpdGVUZW1wbGF0ZUZpbGUoYCR7YmFzZVBhdGh9L1JFQURNRS5tZGAsIHJlYWRtZUNvbnRlbnQpXG4gIH1cbn1cbiIsICIvLyBDb3Vyc2UgY3JlYXRpb24gd2l6YXJkIGZvciBUdWNrZXJzIFRvb2xzIHBsdWdpblxuXG5pbXBvcnQgeyBBcHAsIE5vdGljZSwgVEZpbGUgfSBmcm9tIFwib2JzaWRpYW5cIlxuaW1wb3J0IHsgVHVja2Vyc1Rvb2xzU2V0dGluZ3MgfSBmcm9tIFwiLi9zZXR0aW5nc1wiXG5pbXBvcnQgeyBzbHVnaWZ5IH0gZnJvbSBcIi4vdXRpbHNcIlxuaW1wb3J0IHsgSW5wdXRNb2RhbCwgU3VnZ2VzdGVyTW9kYWwgfSBmcm9tIFwiLi9pbnB1dE1vZGFsXCJcbmltcG9ydCB7IFRlbXBsYXRlTWFuYWdlciB9IGZyb20gXCIuL3RlbXBsYXRlTWFuYWdlclwiXG5cbmV4cG9ydCBjbGFzcyBDb3Vyc2VDcmVhdGlvbldpemFyZCB7XG4gIGFwcDogQXBwXG4gIHNldHRpbmdzOiBUdWNrZXJzVG9vbHNTZXR0aW5nc1xuXG4gIGNvbnN0cnVjdG9yKGFwcDogQXBwLCBzZXR0aW5nczogVHVja2Vyc1Rvb2xzU2V0dGluZ3MpIHtcbiAgICB0aGlzLmFwcCA9IGFwcFxuICAgIHRoaXMuc2V0dGluZ3MgPSBzZXR0aW5nc1xuICB9XG5cbiAgYXN5bmMgY3JlYXRlQ291cnNlSG9tZXBhZ2UoKSB7XG4gICAgdHJ5IHtcbiAgICAgIC8vIFByb21wdCB1c2VyIGZvciBjb3Vyc2UgZGV0YWlsc1xuICAgICAgY29uc3QgY291cnNlRGV0YWlscyA9IGF3YWl0IHRoaXMucHJvbXB0Q291cnNlRGV0YWlscygpXG5cbiAgICAgIGlmICghY291cnNlRGV0YWlscykge1xuICAgICAgICByZXR1cm4gZmFsc2UgLy8gVXNlciBjYW5jZWxsZWRcbiAgICAgIH1cblxuICAgICAgLy8gQ3JlYXRlIGZvbGRlciBzdHJ1Y3R1cmVcbiAgICAgIGNvbnN0IGZvbGRlclBhdGggPSBhd2FpdCB0aGlzLmNyZWF0ZUNvdXJzZUZvbGRlclN0cnVjdHVyZShjb3Vyc2VEZXRhaWxzKVxuXG4gICAgICAvLyBHZW5lcmF0ZSBjb3Vyc2UgaG9tZXBhZ2Ugbm90ZVxuICAgICAgYXdhaXQgdGhpcy5jcmVhdGVDb3Vyc2VIb21lcGFnZU5vdGUoY291cnNlRGV0YWlscywgZm9sZGVyUGF0aClcblxuICAgICAgLy8gQ3JlYXRlIGF0dGFjaG1lbnRzIGZvbGRlclxuICAgICAgYXdhaXQgdGhpcy5jcmVhdGVBdHRhY2htZW50c0ZvbGRlcihmb2xkZXJQYXRoKVxuXG4gICAgICBuZXcgTm90aWNlKGBDb3Vyc2UgXCIke2NvdXJzZURldGFpbHMuY291cnNlTmFtZX1cIiBjcmVhdGVkIHN1Y2Nlc3NmdWxseSFgKVxuICAgICAgY29uc29sZS5sb2coXG4gICAgICAgIGBDb3Vyc2UgY3JlYXRlZDogJHtjb3Vyc2VEZXRhaWxzLmNvdXJzZU5hbWV9IGF0ICR7Zm9sZGVyUGF0aH1gXG4gICAgICApXG5cbiAgICAgIHJldHVybiB0cnVlXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBjcmVhdGluZyBjb3Vyc2U6XCIsIGVycm9yKVxuICAgICAgbmV3IE5vdGljZShgRXJyb3IgY3JlYXRpbmcgY291cnNlOiAke2Vycm9yLm1lc3NhZ2V9YClcbiAgICAgIHJldHVybiBmYWxzZVxuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgcHJvbXB0Q291cnNlRGV0YWlscygpOiBQcm9taXNlPHtcbiAgICBjb3Vyc2VOYW1lOiBzdHJpbmdcbiAgICBjb3Vyc2VTZWFzb246IHN0cmluZ1xuICAgIGNvdXJzZVllYXI6IHN0cmluZ1xuICAgIGNvdXJzZUlkOiBzdHJpbmdcbiAgfSB8IG51bGw+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgY291cnNlTmFtZSA9IGF3YWl0IHRoaXMucHJvbXB0V2l0aFZhbGlkYXRpb24oXG4gICAgICAgIFwiQ291cnNlIE5hbWVcIixcbiAgICAgICAgXCJFbnRlciBjb3Vyc2UgbmFtZSAoZS5nLiwgUFNJLTEwMSAtIEludHJvIHRvIFBzeWNob2xvZ3kpXCIsXG4gICAgICAgICh2YWx1ZSkgPT4gdmFsdWUudHJpbSgpLmxlbmd0aCA+IDAsXG4gICAgICAgIFwiQ291cnNlIG5hbWUgaXMgcmVxdWlyZWRcIlxuICAgICAgKVxuXG4gICAgICBpZiAoIWNvdXJzZU5hbWUpIHJldHVybiBudWxsXG5cbiAgICAgIGNvbnN0IGNvdXJzZVNlYXNvbiA9IGF3YWl0IHRoaXMucHJvbXB0V2l0aE9wdGlvbnMoXG4gICAgICAgIFwiU2Vhc29uXCIsXG4gICAgICAgIFwiU2VsZWN0IHNlbWVzdGVyL3NlYXNvblwiLFxuICAgICAgICBbXCJGYWxsXCIsIFwiV2ludGVyXCIsIFwiU3ByaW5nXCIsIFwiU3VtbWVyXCJdXG4gICAgICApXG5cbiAgICAgIGlmICghY291cnNlU2Vhc29uKSByZXR1cm4gbnVsbFxuXG4gICAgICBjb25zdCBjb3Vyc2VZZWFyID0gYXdhaXQgdGhpcy5wcm9tcHRXaXRoVmFsaWRhdGlvbihcbiAgICAgICAgXCJZZWFyXCIsXG4gICAgICAgIFwiRW50ZXIgYWNhZGVtaWMgeWVhciAoZS5nLiwgMjAyNSlcIixcbiAgICAgICAgKHZhbHVlKSA9PiAvXlxcZHs0fSQvLnRlc3QodmFsdWUudHJpbSgpKSxcbiAgICAgICAgXCJQbGVhc2UgZW50ZXIgYSB2YWxpZCA0LWRpZ2l0IHllYXJcIlxuICAgICAgKVxuXG4gICAgICBpZiAoIWNvdXJzZVllYXIpIHJldHVybiBudWxsXG5cbiAgICAgIGNvbnN0IGNvdXJzZUlkID0gY291cnNlTmFtZS5zcGxpdChcIiAtIFwiKVswXT8udHJpbSgpIHx8IHNsdWdpZnkoY291cnNlTmFtZSlcblxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgY291cnNlTmFtZSxcbiAgICAgICAgY291cnNlU2Vhc29uLFxuICAgICAgICBjb3Vyc2VZZWFyLFxuICAgICAgICBjb3Vyc2VJZFxuICAgICAgfVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgcHJvbXB0aW5nIGZvciBjb3Vyc2UgZGV0YWlsczpcIiwgZXJyb3IpXG4gICAgICByZXR1cm4gbnVsbFxuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgcHJvbXB0V2l0aFZhbGlkYXRpb24oXG4gICAgdGl0bGU6IHN0cmluZyxcbiAgICBtZXNzYWdlOiBzdHJpbmcsXG4gICAgdmFsaWRhdG9yOiAodmFsdWU6IHN0cmluZykgPT4gYm9vbGVhbixcbiAgICBlcnJvck1lc3NhZ2U6IHN0cmluZ1xuICApOiBQcm9taXNlPHN0cmluZyB8IG51bGw+IHtcbiAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcbiAgICAgIGNvbnN0IG1vZGFsID0gbmV3IElucHV0TW9kYWwodGhpcy5hcHAsIChyZXN1bHQpID0+IHtcbiAgICAgICAgaWYgKHJlc3VsdCA9PT0gbnVsbCkge1xuICAgICAgICAgIC8vIFVzZXIgY2FuY2VsbGVkXG4gICAgICAgICAgcmVzb2x2ZShudWxsKTtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoIXZhbGlkYXRvcihyZXN1bHQpKSB7XG4gICAgICAgICAgbmV3IE5vdGljZShlcnJvck1lc3NhZ2UpO1xuICAgICAgICAgIC8vIFJlY3Vyc2l2ZWx5IGNhbGwgYWdhaW4gaWYgdmFsaWRhdGlvbiBmYWlsc1xuICAgICAgICAgIHRoaXMucHJvbXB0V2l0aFZhbGlkYXRpb24odGl0bGUsIG1lc3NhZ2UsIHZhbGlkYXRvciwgZXJyb3JNZXNzYWdlKVxuICAgICAgICAgICAgLnRoZW4ocmVzb2x2ZSk7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgcmVzb2x2ZShyZXN1bHQudHJpbSgpKTtcbiAgICAgIH0pO1xuXG4gICAgICAvLyBTZXQgdGhlIHRpdGxlIGFuZCBtZXNzYWdlIGRpZmZlcmVudGx5IHNpbmNlIG91ciBtb2RhbCBpcyBzaW1wbGVcbiAgICAgIG1vZGFsLnRpdGxlRWwuc2V0VGV4dCh0aXRsZSk7XG4gICAgICBjb25zdCBtZXNzYWdlRWwgPSBtb2RhbC5jb250ZW50RWwuY3JlYXRlRGl2KCk7XG4gICAgICBtZXNzYWdlRWwuc2V0VGV4dChtZXNzYWdlKTtcblxuICAgICAgbW9kYWwub3BlbigpO1xuICAgIH0pO1xuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBwcm9tcHRXaXRoT3B0aW9ucyhcbiAgICB0aXRsZTogc3RyaW5nLFxuICAgIG1lc3NhZ2U6IHN0cmluZyxcbiAgICBvcHRpb25zOiBzdHJpbmdbXVxuICApOiBQcm9taXNlPHN0cmluZyB8IG51bGw+IHtcbiAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcbiAgICAgIGNvbnN0IG1vZGFsID0gbmV3IFN1Z2dlc3Rlck1vZGFsKHRoaXMuYXBwLCBvcHRpb25zLCAocmVzdWx0KSA9PiB7XG4gICAgICAgIGlmIChyZXN1bHQgPT09IG51bGwpIHtcbiAgICAgICAgICAvLyBVc2VyIGNhbmNlbGxlZFxuICAgICAgICAgIHJlc29sdmUobnVsbCk7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKG9wdGlvbnMuaW5jbHVkZXMocmVzdWx0KSkge1xuICAgICAgICAgIHJlc29sdmUocmVzdWx0KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBuZXcgTm90aWNlKGBQbGVhc2Ugc2VsZWN0IG9uZSBvZjogJHtvcHRpb25zLmpvaW4oXCIsIFwiKX1gKTtcbiAgICAgICAgICAvLyBSZWN1cnNpdmVseSBjYWxsIGFnYWluIGlmIGNob2ljZSBpcyBpbnZhbGlkXG4gICAgICAgICAgdGhpcy5wcm9tcHRXaXRoT3B0aW9ucyh0aXRsZSwgbWVzc2FnZSwgb3B0aW9ucylcbiAgICAgICAgICAgIC50aGVuKHJlc29sdmUpO1xuICAgICAgICB9XG4gICAgICB9KTtcblxuICAgICAgLy8gU2V0IHRoZSB0aXRsZVxuICAgICAgbW9kYWwudGl0bGVFbC5zZXRUZXh0KHRpdGxlKTtcbiAgICAgIGNvbnN0IG1lc3NhZ2VFbCA9IG1vZGFsLmNvbnRlbnRFbC5jcmVhdGVEaXYoKTtcbiAgICAgIG1lc3NhZ2VFbC5zZXRUZXh0KG1lc3NhZ2UpO1xuXG4gICAgICBtb2RhbC5vcGVuKCk7XG4gICAgfSk7XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIGNyZWF0ZUNvdXJzZUZvbGRlclN0cnVjdHVyZShjb3Vyc2VEZXRhaWxzOiB7XG4gICAgY291cnNlTmFtZTogc3RyaW5nXG4gICAgY291cnNlU2Vhc29uOiBzdHJpbmdcbiAgICBjb3Vyc2VZZWFyOiBzdHJpbmdcbiAgICBjb3Vyc2VJZDogc3RyaW5nXG4gIH0pOiBQcm9taXNlPHN0cmluZz4ge1xuICAgIGNvbnN0IGZvbGRlclBhdGggPSBgJHtjb3Vyc2VEZXRhaWxzLmNvdXJzZVllYXJ9LyR7Y291cnNlRGV0YWlscy5jb3Vyc2VTZWFzb259LyR7Y291cnNlRGV0YWlscy5jb3Vyc2VOYW1lfWBcblxuICAgIHRyeSB7XG4gICAgICBhd2FpdCB0aGlzLmFwcC52YXVsdC5jcmVhdGVGb2xkZXIoZm9sZGVyUGF0aClcbiAgICAgIGNvbnNvbGUubG9nKGBDcmVhdGVkIGNvdXJzZSBmb2xkZXI6ICR7Zm9sZGVyUGF0aH1gKVxuICAgICAgcmV0dXJuIGZvbGRlclBhdGhcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgLy8gRm9sZGVyIG1pZ2h0IGFscmVhZHkgZXhpc3QsIHdoaWNoIGlzIGZpbmUgZm9yIG5vd1xuICAgICAgY29uc29sZS5sb2coYENvdXJzZSBmb2xkZXIgYWxyZWFkeSBleGlzdHMgb3IgY3JlYXRlZDogJHtmb2xkZXJQYXRofWApXG4gICAgICByZXR1cm4gZm9sZGVyUGF0aFxuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgY3JlYXRlQ291cnNlSG9tZXBhZ2VOb3RlKFxuICAgIGNvdXJzZURldGFpbHM6IHtcbiAgICAgIGNvdXJzZU5hbWU6IHN0cmluZ1xuICAgICAgY291cnNlU2Vhc29uOiBzdHJpbmdcbiAgICAgIGNvdXJzZVllYXI6IHN0cmluZ1xuICAgICAgY291cnNlSWQ6IHN0cmluZ1xuICAgIH0sXG4gICAgZm9sZGVyUGF0aDogc3RyaW5nXG4gICk6IFByb21pc2U8dm9pZD4ge1xuICAgIGNvbnN0IG5vdGVQYXRoID0gYCR7Zm9sZGVyUGF0aH0vJHtjb3Vyc2VEZXRhaWxzLmNvdXJzZU5hbWV9Lm1kYFxuICAgIGNvbnN0IGNvbnRlbnQgPSB0aGlzLmdlbmVyYXRlQ291cnNlSG9tZXBhZ2VDb250ZW50KGNvdXJzZURldGFpbHMpXG5cbiAgICB0cnkge1xuICAgICAgYXdhaXQgdGhpcy5hcHAudmF1bHQuY3JlYXRlKG5vdGVQYXRoLCBjb250ZW50KVxuICAgICAgY29uc29sZS5sb2coYENyZWF0ZWQgY291cnNlIGhvbWVwYWdlOiAke25vdGVQYXRofWApXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIGNyZWF0aW5nIGNvdXJzZSBob21lcGFnZTogJHtlcnJvcn1gKVxuICAgICAgdGhyb3cgZXJyb3JcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIGNyZWF0ZUF0dGFjaG1lbnRzRm9sZGVyKGZvbGRlclBhdGg6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICAgIGNvbnN0IGF0dGFjaG1lbnRzUGF0aCA9IGAke2ZvbGRlclBhdGh9L0F0dGFjaG1lbnRzYFxuXG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IHRoaXMuYXBwLnZhdWx0LmNyZWF0ZUZvbGRlcihhdHRhY2htZW50c1BhdGgpXG4gICAgICBjb25zb2xlLmxvZyhgQ3JlYXRlZCBhdHRhY2htZW50cyBmb2xkZXI6ICR7YXR0YWNobWVudHNQYXRofWApXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIC8vIEZvbGRlciBtaWdodCBhbHJlYWR5IGV4aXN0LCB3aGljaCBpcyBmaW5lXG4gICAgICBjb25zb2xlLmxvZyhgQXR0YWNobWVudHMgZm9sZGVyIGFscmVhZHkgZXhpc3RzOiAke2F0dGFjaG1lbnRzUGF0aH1gKVxuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgZ2VuZXJhdGVDb3Vyc2VIb21lcGFnZUNvbnRlbnQoY291cnNlRGV0YWlsczoge1xuICAgIGNvdXJzZU5hbWU6IHN0cmluZ1xuICAgIGNvdXJzZVNlYXNvbjogc3RyaW5nXG4gICAgY291cnNlWWVhcjogc3RyaW5nXG4gICAgY291cnNlSWQ6IHN0cmluZ1xuICB9KTogc3RyaW5nIHtcbiAgICAvLyBVc2UgdGhlIHRlbXBsYXRlTWFuYWdlciB0byBnZXQgdGhlIHRlbXBsYXRlIGNvbnRlbnRcbiAgICBjb25zdCB0ZW1wbGF0ZU1hbmFnZXIgPSBuZXcgVGVtcGxhdGVNYW5hZ2VyKHRoaXMuYXBwLCB0aGlzLnNldHRpbmdzKTtcbiAgICBjb25zdCB0ZW1wbGF0ZUNvbnRlbnQgPSB0ZW1wbGF0ZU1hbmFnZXIuZ2VuZXJhdGVDb3Vyc2VIb21lcGFnZVRlbXBsYXRlKCk7XG4gICAgXG4gICAgLy8gUmVwbGFjZSB0ZW1wbGF0ZSB2YXJpYWJsZXMgd2l0aCBhY3R1YWwgdmFsdWVzXG4gICAgcmV0dXJuIHRlbXBsYXRlQ29udGVudFxuICAgICAgLnJlcGxhY2UoJzwlIGNvdXJzZU5hbWUgJT4nLCBjb3Vyc2VEZXRhaWxzLmNvdXJzZU5hbWUpXG4gICAgICAucmVwbGFjZSgnPCUgY291cnNlU2Vhc29uICU+JywgY291cnNlRGV0YWlscy5jb3Vyc2VTZWFzb24pXG4gICAgICAucmVwbGFjZSgnPCUgY291cnNlWWVhciAlPicsIGNvdXJzZURldGFpbHMuY291cnNlWWVhcilcbiAgICAgIC5yZXBsYWNlKCc8JSBjb3Vyc2VJZCAlPicsIGNvdXJzZURldGFpbHMuY291cnNlSWQpXG4gICAgICAucmVwbGFjZSgnPCUgdHAuZGF0ZS5ub3coXCJZWVlZLU1NLUREW1RdSEg6bW06c3NaXCIpICU+JywgbmV3IERhdGUoKS50b0lTT1N0cmluZygpKVxuICAgICAgLnJlcGxhY2UoLzwlIHRwXFwuZGF0ZVxcLm5vd1xcKFwiWVlZWS1NTS1ERFxcW1RcXF1oaDptbTpTU1NTWlpcIlxcKSAlPi9nLCBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkpO1xuICB9XG59XG4iLCAiaW1wb3J0IHsgQXBwLCBNb2RhbCwgU2V0dGluZyB9IGZyb20gXCJvYnNpZGlhblwiO1xuXG5leHBvcnQgY2xhc3MgSW5wdXRNb2RhbCBleHRlbmRzIE1vZGFsIHtcbiAgcmVzdWx0OiBzdHJpbmcgfCBudWxsO1xuICBvblN1Ym1pdDogKHJlc3VsdDogc3RyaW5nIHwgbnVsbCkgPT4gdm9pZDtcblxuICBjb25zdHJ1Y3RvcihhcHA6IEFwcCwgb25TdWJtaXQ6IChyZXN1bHQ6IHN0cmluZyB8IG51bGwpID0+IHZvaWQpIHtcbiAgICBzdXBlcihhcHApO1xuICAgIHRoaXMub25TdWJtaXQgPSBvblN1Ym1pdDtcbiAgfVxuXG4gIG9uT3BlbigpIHtcbiAgICBjb25zdCB7IGNvbnRlbnRFbCB9ID0gdGhpcztcblxuICAgIGNvbnRlbnRFbC5jcmVhdGVFbChcImgyXCIsIHsgdGV4dDogXCJFbnRlciBWYWx1ZVwiIH0pO1xuXG4gICAgbmV3IFNldHRpbmcoY29udGVudEVsKVxuICAgICAgLnNldE5hbWUoXCJWYWx1ZVwiKVxuICAgICAgLmFkZFRleHQoKHRleHQpID0+IFxuICAgICAgICB0ZXh0XG4gICAgICAgICAgLm9uQ2hhbmdlKCh2YWx1ZSkgPT4ge1xuICAgICAgICAgICAgdGhpcy5yZXN1bHQgPSB2YWx1ZTtcbiAgICAgICAgICB9KVxuICAgICAgICAgIC5pbnB1dEVsLmZvY3VzKClcbiAgICAgICk7XG5cbiAgICBuZXcgU2V0dGluZyhjb250ZW50RWwpXG4gICAgICAuYWRkQnV0dG9uKChidG4pID0+XG4gICAgICAgIGJ0blxuICAgICAgICAgIC5zZXRCdXR0b25UZXh0KFwiU3VibWl0XCIpXG4gICAgICAgICAgLnNldEN0YSgpXG4gICAgICAgICAgLm9uQ2xpY2soKCkgPT4ge1xuICAgICAgICAgICAgdGhpcy5jbG9zZSgpO1xuICAgICAgICAgICAgdGhpcy5vblN1Ym1pdCh0aGlzLnJlc3VsdCB8fCBcIlwiKTtcbiAgICAgICAgICB9KVxuICAgICAgKVxuICAgICAgLmFkZEJ1dHRvbigoYnRuKSA9PlxuICAgICAgICBidG4uc2V0QnV0dG9uVGV4dChcIkNhbmNlbFwiKS5vbkNsaWNrKCgpID0+IHtcbiAgICAgICAgICB0aGlzLmNsb3NlKCk7XG4gICAgICAgICAgdGhpcy5vblN1Ym1pdChudWxsKTtcbiAgICAgICAgfSlcbiAgICAgICk7XG4gIH1cblxuICBvbkNsb3NlKCkge1xuICAgIGNvbnN0IHsgY29udGVudEVsIH0gPSB0aGlzO1xuICAgIGNvbnRlbnRFbC5lbXB0eSgpO1xuICB9XG59XG5cbmV4cG9ydCBjbGFzcyBTdWdnZXN0ZXJNb2RhbCBleHRlbmRzIE1vZGFsIHtcbiAgcmVzdWx0OiBzdHJpbmcgfCBudWxsO1xuICBvblN1Ym1pdDogKHJlc3VsdDogc3RyaW5nIHwgbnVsbCkgPT4gdm9pZDtcblxuICBjb25zdHJ1Y3RvcihhcHA6IEFwcCwgb3B0aW9uczogc3RyaW5nW10sIG9uU3VibWl0OiAocmVzdWx0OiBzdHJpbmcgfCBudWxsKSA9PiB2b2lkKSB7XG4gICAgc3VwZXIoYXBwKTtcbiAgICB0aGlzLm9uU3VibWl0ID0gb25TdWJtaXQ7XG5cbiAgICAvLyBDcmVhdGUgYSBkcm9wZG93biB3aXRoIHRoZSBwcm92aWRlZCBvcHRpb25zXG4gICAgY29uc3QgZHJvcGRvd25PcHRpb25zOiB7IFtrZXk6IHN0cmluZ106IHN0cmluZyB9ID0ge307XG4gICAgb3B0aW9ucy5mb3JFYWNoKG9wdGlvbiA9PiB7XG4gICAgICBkcm9wZG93bk9wdGlvbnNbb3B0aW9uXSA9IG9wdGlvbjtcbiAgICB9KTtcbiAgICBcbiAgICB0aGlzLmNyZWF0ZURyb3Bkb3duKGRyb3Bkb3duT3B0aW9ucyk7XG4gIH1cblxuICBjcmVhdGVEcm9wZG93bihvcHRpb25zOiB7IFtrZXk6IHN0cmluZ106IHN0cmluZyB9KSB7XG4gICAgY29uc3QgeyBjb250ZW50RWwgfSA9IHRoaXM7XG5cbiAgICBjb250ZW50RWwuY3JlYXRlRWwoXCJoMlwiLCB7IHRleHQ6IFwiU2VsZWN0IE9wdGlvblwiIH0pO1xuXG4gICAgbGV0IHNlbGVjdGVkVmFsdWUgPSBPYmplY3Qua2V5cyhvcHRpb25zKVswXSB8fCBudWxsOyAvLyBEZWZhdWx0IHRvIGZpcnN0IG9wdGlvbiBvciBudWxsXG5cbiAgICBjb25zdCBkcm9wZG93biA9IGNvbnRlbnRFbC5jcmVhdGVFbChcInNlbGVjdFwiKTtcbiAgICBPYmplY3QuZW50cmllcyhvcHRpb25zKS5mb3JFYWNoKChba2V5LCB2YWx1ZV0pID0+IHtcbiAgICAgIGNvbnN0IG9wdGlvbiA9IGRyb3Bkb3duLmNyZWF0ZUVsKFwib3B0aW9uXCIsIHtcbiAgICAgICAgdmFsdWU6IGtleSxcbiAgICAgICAgdGV4dDogdmFsdWVcbiAgICAgIH0pO1xuICAgICAgaWYgKGtleSA9PT0gc2VsZWN0ZWRWYWx1ZSkge1xuICAgICAgICBvcHRpb24uc2VsZWN0ZWQgPSB0cnVlO1xuICAgICAgfVxuICAgIH0pO1xuXG4gICAgZHJvcGRvd24uYWRkRXZlbnRMaXN0ZW5lcihcImNoYW5nZVwiLCAoZXZlbnQpID0+IHtcbiAgICAgIHNlbGVjdGVkVmFsdWUgPSAoZXZlbnQudGFyZ2V0IGFzIEhUTUxTZWxlY3RFbGVtZW50KS52YWx1ZTtcbiAgICAgIHRoaXMucmVzdWx0ID0gc2VsZWN0ZWRWYWx1ZTtcbiAgICB9KTtcblxuICAgIG5ldyBTZXR0aW5nKGNvbnRlbnRFbClcbiAgICAgIC5hZGRCdXR0b24oKGJ0bikgPT5cbiAgICAgICAgYnRuXG4gICAgICAgICAgLnNldEJ1dHRvblRleHQoXCJTdWJtaXRcIilcbiAgICAgICAgICAuc2V0Q3RhKClcbiAgICAgICAgICAub25DbGljaygoKSA9PiB7XG4gICAgICAgICAgICB0aGlzLmNsb3NlKCk7XG4gICAgICAgICAgICB0aGlzLm9uU3VibWl0KHNlbGVjdGVkVmFsdWUpO1xuICAgICAgICAgIH0pXG4gICAgICApXG4gICAgICAuYWRkQnV0dG9uKChidG4pID0+XG4gICAgICAgIGJ0bi5zZXRCdXR0b25UZXh0KFwiQ2FuY2VsXCIpLm9uQ2xpY2soKCkgPT4ge1xuICAgICAgICAgIHRoaXMuY2xvc2UoKTtcbiAgICAgICAgICB0aGlzLm9uU3VibWl0KG51bGwpO1xuICAgICAgICB9KVxuICAgICAgKTtcbiAgfVxuXG4gIG9uT3BlbigpIHtcbiAgICAvLyBUaGUgZHJvcGRvd24gaXMgYWxyZWFkeSBjcmVhdGVkIGluIGNvbnN0cnVjdG9yXG4gIH1cblxuICBvbkNsb3NlKCkge1xuICAgIGNvbnN0IHsgY29udGVudEVsIH0gPSB0aGlzO1xuICAgIGNvbnRlbnRFbC5lbXB0eSgpO1xuICB9XG59IiwgIi8vIFZvY2FidWxhcnkgZXh0cmFjdGlvbiBmb3IgVHVja2VycyBUb29scyBwbHVnaW5cblxuaW1wb3J0IHsgQXBwLCBURmlsZSB9IGZyb20gXCJvYnNpZGlhblwiXG5pbXBvcnQgeyBnZXRDb3Vyc2VJZEZyb21QYXRoIH0gZnJvbSBcIi4vdXRpbHNcIlxuXG5leHBvcnQgY2xhc3MgVm9jYWJ1bGFyeUV4dHJhY3RvciB7XG4gIGFwcDogQXBwXG5cbiAgY29uc3RydWN0b3IoYXBwOiBBcHApIHtcbiAgICB0aGlzLmFwcCA9IGFwcFxuICB9XG5cbiAgZXh0cmFjdFZvY2FidWxhcnlGcm9tTm90ZShjb250ZW50OiBzdHJpbmcpOiBzdHJpbmdbXSB7XG4gICAgLy8gRXh0cmFjdCB2b2NhYnVsYXJ5IHNlY3Rpb24gZnJvbSBub3RlIGNvbnRlbnRcbiAgICBjb25zdCB2b2NhYlJlZ2V4ID0gL14jKyBWb2NhYnVsYXJ5LipcXG4oKD86Lio/XFxuKSo/KSg/PV5cXHMqI1xcc3wkKS9tXG4gICAgY29uc3Qgdm9jYWJNYXRjaGVzID0gY29udGVudD8ubWF0Y2godm9jYWJSZWdleClcblxuICAgIGlmICh2b2NhYk1hdGNoZXMpIHtcbiAgICAgIGNvbnN0IHZvY2FiRGF0YSA9IHZvY2FiTWF0Y2hlc1sxXS50cmltKClcbiAgICAgIGNvbnN0IGNsZWFuZWRWb2NhYiA9IHZvY2FiRGF0YVxuICAgICAgICAucmVwbGFjZSgvXFxbXFxbLio/XFxdXFxdL2csIFwiXCIpIC8vIFJlbW92ZSB3aWtpbGlua3NcbiAgICAgICAgLnJlcGxhY2UoL15cXHMqLVxccyovZ20sIFwiXCIpIC8vIFJlbW92ZSBidWxsZXQgcG9pbnRzXG4gICAgICAgIC5zcGxpdChcIlxcblwiKVxuICAgICAgICAubWFwKCh0ZXJtKSA9PiB0ZXJtLnRyaW0oKSlcbiAgICAgICAgLmZpbHRlcigodGVybSkgPT4gdGVybS5sZW5ndGggPiAwKVxuXG4gICAgICByZXR1cm4gY2xlYW5lZFZvY2FiXG4gICAgfVxuXG4gICAgcmV0dXJuIFtdXG4gIH1cblxuICBhc3luYyBleHRyYWN0Vm9jYWJ1bGFyeUZyb21Db3Vyc2UoXG4gICAgY291cnNlSWQ6IHN0cmluZ1xuICApOiBQcm9taXNlPFJlY29yZDxzdHJpbmcsIHN0cmluZ1tdPj4ge1xuICAgIGNvbnNvbGUubG9nKGBFeHRyYWN0aW5nIHZvY2FidWxhcnkgZm9yIGNvdXJzZTogJHtjb3Vyc2VJZH1gKVxuXG4gICAgdHJ5IHtcbiAgICAgIC8vIEZpbmQgYWxsIG5vdGVzIHJlbGF0ZWQgdG8gdGhlIGNvdXJzZVxuICAgICAgY29uc3QgY291cnNlTm90ZXMgPSBhd2FpdCB0aGlzLmZpbmRDb3Vyc2VOb3Rlcyhjb3Vyc2VJZClcblxuICAgICAgaWYgKGNvdXJzZU5vdGVzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICBjb25zb2xlLmxvZyhgTm8gbm90ZXMgZm91bmQgZm9yIGNvdXJzZTogJHtjb3Vyc2VJZH1gKVxuICAgICAgICByZXR1cm4ge31cbiAgICAgIH1cblxuICAgICAgLy8gRXh0cmFjdCB2b2NhYnVsYXJ5IGZyb20gZWFjaCBub3RlXG4gICAgICBjb25zdCB2b2NhYnVsYXJ5RGF0YTogUmVjb3JkPHN0cmluZywgc3RyaW5nW10+ID0ge31cblxuICAgICAgZm9yIChjb25zdCBub3RlIG9mIGNvdXJzZU5vdGVzKSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgY29uc3QgY29udGVudCA9IGF3YWl0IHRoaXMuYXBwLnZhdWx0LnJlYWQobm90ZSlcbiAgICAgICAgICBjb25zdCB2b2NhYnVsYXJ5ID0gdGhpcy5leHRyYWN0Vm9jYWJ1bGFyeUZyb21Ob3RlKGNvbnRlbnQpXG5cbiAgICAgICAgICBpZiAodm9jYWJ1bGFyeS5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICB2b2NhYnVsYXJ5RGF0YVtub3RlLmJhc2VuYW1lXSA9IHZvY2FidWxhcnlcbiAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgY29uc29sZS5lcnJvcihgRXJyb3IgcmVhZGluZyBub3RlICR7bm90ZS5wYXRofTpgLCBlcnJvcilcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICBjb25zb2xlLmxvZyhcbiAgICAgICAgYEV4dHJhY3RlZCB2b2NhYnVsYXJ5IGZyb20gJHtcbiAgICAgICAgICBPYmplY3Qua2V5cyh2b2NhYnVsYXJ5RGF0YSkubGVuZ3RoXG4gICAgICAgIH0gbm90ZXMgZm9yIGNvdXJzZTogJHtjb3Vyc2VJZH1gXG4gICAgICApXG4gICAgICByZXR1cm4gdm9jYWJ1bGFyeURhdGFcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihcbiAgICAgICAgYEVycm9yIGV4dHJhY3Rpbmcgdm9jYWJ1bGFyeSBmb3IgY291cnNlICR7Y291cnNlSWR9OmAsXG4gICAgICAgIGVycm9yXG4gICAgICApXG4gICAgICByZXR1cm4ge31cbiAgICB9XG4gIH1cblxuICBhc3luYyBmaW5kQ291cnNlTm90ZXMoY291cnNlSWQ6IHN0cmluZyk6IFByb21pc2U8VEZpbGVbXT4ge1xuICAgIGNvbnN0IG5vdGVzOiBURmlsZVtdID0gW11cblxuICAgIC8vIEdldCBhbGwgbWFya2Rvd24gZmlsZXMgaW4gdGhlIHZhdWx0XG4gICAgY29uc3QgZmlsZXMgPSB0aGlzLmFwcC52YXVsdC5nZXRNYXJrZG93bkZpbGVzKClcblxuICAgIGZvciAoY29uc3QgZmlsZSBvZiBmaWxlcykge1xuICAgICAgLy8gQ2hlY2sgaWYgdGhlIGZpbGUgcGF0aCBjb250YWlucyB0aGUgY291cnNlIElEXG4gICAgICBpZiAoXG4gICAgICAgIGZpbGUucGF0aC5pbmNsdWRlcyhjb3Vyc2VJZCkgfHxcbiAgICAgICAgKGF3YWl0IHRoaXMubm90ZUJlbG9uZ3NUb0NvdXJzZShmaWxlLCBjb3Vyc2VJZCkpXG4gICAgICApIHtcbiAgICAgICAgbm90ZXMucHVzaChmaWxlKVxuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBub3Rlc1xuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBub3RlQmVsb25nc1RvQ291cnNlKFxuICAgIGZpbGU6IFRGaWxlLFxuICAgIGNvdXJzZUlkOiBzdHJpbmdcbiAgKTogUHJvbWlzZTxib29sZWFuPiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGNvbnRlbnQgPSBhd2FpdCB0aGlzLmFwcC52YXVsdC5yZWFkKGZpbGUpXG4gICAgICBjb25zdCBmcm9udG1hdHRlck1hdGNoID0gY29udGVudC5tYXRjaCgvXi0tLVxcbihbXFxzXFxTXSo/KVxcbi0tLS8pXG5cbiAgICAgIGlmIChmcm9udG1hdHRlck1hdGNoKSB7XG4gICAgICAgIGNvbnN0IGZyb250bWF0dGVyID0gZnJvbnRtYXR0ZXJNYXRjaFsxXVxuICAgICAgICAvLyBDaGVjayBpZiBjb3Vyc2VfaWQgaXMgaW4gdGhlIGZyb250bWF0dGVyXG4gICAgICAgIHJldHVybiAoXG4gICAgICAgICAgZnJvbnRtYXR0ZXIuaW5jbHVkZXMoYGNvdXJzZV9pZDogJHtjb3Vyc2VJZH1gKSB8fFxuICAgICAgICAgIGZyb250bWF0dGVyLmluY2x1ZGVzKGBjb3Vyc2VfaWQ6JHtjb3Vyc2VJZH1gKVxuICAgICAgICApXG4gICAgICB9XG5cbiAgICAgIHJldHVybiBmYWxzZVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFxuICAgICAgICBgRXJyb3IgY2hlY2tpbmcgaWYgbm90ZSAke2ZpbGUucGF0aH0gYmVsb25ncyB0byBjb3Vyc2UgJHtjb3Vyc2VJZH06YCxcbiAgICAgICAgZXJyb3JcbiAgICAgIClcbiAgICAgIHJldHVybiBmYWxzZVxuICAgIH1cbiAgfVxuXG4gIGFzeW5jIGdlbmVyYXRlVm9jYWJ1bGFyeUluZGV4KFxuICAgIGNvdXJzZUlkOiBzdHJpbmcsXG4gICAgdm9jYWJ1bGFyeURhdGE6IFJlY29yZDxzdHJpbmcsIHN0cmluZ1tdPlxuICApOiBQcm9taXNlPHN0cmluZz4ge1xuICAgIGNvbnN0IGFsbFRlcm1zOiBzdHJpbmdbXSA9IFtdXG4gICAgY29uc3QgdGVybVNvdXJjZXM6IFJlY29yZDxzdHJpbmcsIHN0cmluZ1tdPiA9IHt9XG5cbiAgICAvLyBDb2xsZWN0IGFsbCB1bmlxdWUgdGVybXMgYW5kIHRoZWlyIHNvdXJjZXNcbiAgICBmb3IgKGNvbnN0IFtub3RlTmFtZSwgdGVybXNdIG9mIE9iamVjdC5lbnRyaWVzKHZvY2FidWxhcnlEYXRhKSkge1xuICAgICAgZm9yIChjb25zdCB0ZXJtIG9mIHRlcm1zKSB7XG4gICAgICAgIGlmICghYWxsVGVybXMuaW5jbHVkZXModGVybSkpIHtcbiAgICAgICAgICBhbGxUZXJtcy5wdXNoKHRlcm0pXG4gICAgICAgICAgdGVybVNvdXJjZXNbdGVybV0gPSBbXVxuICAgICAgICB9XG4gICAgICAgIHRlcm1Tb3VyY2VzW3Rlcm1dLnB1c2gobm90ZU5hbWUpXG4gICAgICB9XG4gICAgfVxuXG4gICAgLy8gU29ydCB0ZXJtcyBhbHBoYWJldGljYWxseVxuICAgIGFsbFRlcm1zLnNvcnQoKVxuXG4gICAgLy8gR2VuZXJhdGUgbWFya2Rvd24gY29udGVudFxuICAgIGxldCBjb250ZW50ID0gYCMgVm9jYWJ1bGFyeSBJbmRleCAtICR7Y291cnNlSWR9XFxuXFxuYFxuICAgIGNvbnRlbnQgKz0gYFRvdGFsIHVuaXF1ZSB0ZXJtczogJHthbGxUZXJtcy5sZW5ndGh9XFxuXFxuYFxuXG4gICAgZm9yIChjb25zdCB0ZXJtIG9mIGFsbFRlcm1zKSB7XG4gICAgICBjb250ZW50ICs9IGAjIyAke3Rlcm19XFxuYFxuICAgICAgY29udGVudCArPSBgKipTb3VyY2VzOioqICR7dGVybVNvdXJjZXNbdGVybV0uam9pbihcIiwgXCIpfVxcblxcbmBcbiAgICAgIGNvbnRlbnQgKz0gYCoqRGVmaW5pdGlvbjoqKlxcblxcbmBcbiAgICAgIGNvbnRlbnQgKz0gYCoqQ29udGV4dDoqKlxcblxcbmBcbiAgICAgIGNvbnRlbnQgKz0gYCoqRXhhbXBsZXM6KipcXG5cXG5gXG4gICAgICBjb250ZW50ICs9IGAtLS1cXG5cXG5gXG4gICAgfVxuXG4gICAgcmV0dXJuIGNvbnRlbnRcbiAgfVxuXG4gIGFzeW5jIGNyZWF0ZVZvY2FidWxhcnlJbmRleEZpbGUoY291cnNlSWQ6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB2b2NhYnVsYXJ5RGF0YSA9IGF3YWl0IHRoaXMuZXh0cmFjdFZvY2FidWxhcnlGcm9tQ291cnNlKGNvdXJzZUlkKVxuXG4gICAgICBpZiAoT2JqZWN0LmtleXModm9jYWJ1bGFyeURhdGEpLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICBjb25zb2xlLmxvZyhgTm8gdm9jYWJ1bGFyeSBmb3VuZCBmb3IgY291cnNlOiAke2NvdXJzZUlkfWApXG4gICAgICAgIHJldHVyblxuICAgICAgfVxuXG4gICAgICBjb25zdCBpbmRleENvbnRlbnQgPSBhd2FpdCB0aGlzLmdlbmVyYXRlVm9jYWJ1bGFyeUluZGV4KFxuICAgICAgICBjb3Vyc2VJZCxcbiAgICAgICAgdm9jYWJ1bGFyeURhdGFcbiAgICAgIClcblxuICAgICAgLy8gQ3JlYXRlIHRoZSBpbmRleCBmaWxlXG4gICAgICBjb25zdCBmaWxlTmFtZSA9IGAke2NvdXJzZUlkfSAtIFZvY2FidWxhcnkgSW5kZXgubWRgXG4gICAgICBjb25zdCBmaWxlUGF0aCA9IGBDb3Vyc2VzLyR7Y291cnNlSWR9LyR7ZmlsZU5hbWV9YFxuXG4gICAgICB0cnkge1xuICAgICAgICBhd2FpdCB0aGlzLmFwcC52YXVsdC5jcmVhdGUoZmlsZVBhdGgsIGluZGV4Q29udGVudClcbiAgICAgICAgY29uc29sZS5sb2coYENyZWF0ZWQgdm9jYWJ1bGFyeSBpbmRleCBmaWxlOiAke2ZpbGVQYXRofWApXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAvLyBGaWxlIG1pZ2h0IGFscmVhZHkgZXhpc3QsIHRyeSB0byB1cGRhdGUgaXRcbiAgICAgICAgY29uc3QgZXhpc3RpbmdGaWxlID0gdGhpcy5hcHAudmF1bHQuZ2V0QWJzdHJhY3RGaWxlQnlQYXRoKGZpbGVQYXRoKVxuICAgICAgICBpZiAoZXhpc3RpbmdGaWxlICYmIGV4aXN0aW5nRmlsZSBpbnN0YW5jZW9mIFRGaWxlKSB7XG4gICAgICAgICAgYXdhaXQgdGhpcy5hcHAudmF1bHQubW9kaWZ5KGV4aXN0aW5nRmlsZSwgaW5kZXhDb250ZW50KVxuICAgICAgICAgIGNvbnNvbGUubG9nKGBVcGRhdGVkIHZvY2FidWxhcnkgaW5kZXggZmlsZTogJHtmaWxlUGF0aH1gKVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXG4gICAgICAgIGBFcnJvciBjcmVhdGluZyB2b2NhYnVsYXJ5IGluZGV4IGZvciBjb3Vyc2UgJHtjb3Vyc2VJZH06YCxcbiAgICAgICAgZXJyb3JcbiAgICAgIClcbiAgICAgIHRocm93IGVycm9yXG4gICAgfVxuICB9XG59XG4iLCAiaW1wb3J0IHsgQXBwLCBURmlsZSB9IGZyb20gXCJvYnNpZGlhblwiXG5pbXBvcnQgeyBpc0JldHdlZW4gfSBmcm9tIFwiLi91dGlsc1wiXG5cbmV4cG9ydCBjbGFzcyBEdWVEYXRlc1BhcnNlciB7XG4gIGFwcDogQXBwXG5cbiAgY29uc3RydWN0b3IoYXBwOiBBcHApIHtcbiAgICB0aGlzLmFwcCA9IGFwcFxuICB9XG5cbiAgcGFyc2VEdWVEYXRlc0Zyb21Ob3RlKFxuICAgIGNvbnRlbnQ6IHN0cmluZ1xuICApOiBBcnJheTx7IGRhdGU6IHN0cmluZzsgYXNzaWdubWVudDogc3RyaW5nOyBzdGF0dXM6IHN0cmluZyB9PiB7XG4gICAgLy8gRXh0cmFjdCBkdWUgZGF0ZXMgc2VjdGlvbiBmcm9tIG5vdGUgY29udGVudFxuICAgIGNvbnN0IGR1ZURhdGVzUmVnZXggPSAvIyBEdWUgRGF0ZXNbXFxzXFxTXSo/KD89XFxuI3wkKS9cbiAgICBjb25zdCBtYXRjaGVzID0gY29udGVudD8ubWF0Y2goZHVlRGF0ZXNSZWdleClcblxuICAgIGlmICghbWF0Y2hlcykge1xuICAgICAgcmV0dXJuIFtdXG4gICAgfVxuXG4gICAgY29uc3QgZHVlRGF0ZXNTZWN0aW9uID0gbWF0Y2hlc1swXVxuICAgIGNvbnN0IGR1ZURhdGVzID0gW11cblxuICAgIC8vIExvb2sgZm9yIG1hcmtkb3duIHRhYmxlcyBpbiB0aGUgZHVlIGRhdGVzIHNlY3Rpb25cbiAgICBjb25zdCB0YWJsZVJlZ2V4ID0gL1xcfFtcXHNcXFNdKj9cXG4vZ1xuICAgIGNvbnN0IHRhYmxlTWF0Y2hlcyA9IGR1ZURhdGVzU2VjdGlvbi5tYXRjaCh0YWJsZVJlZ2V4KVxuXG4gICAgaWYgKHRhYmxlTWF0Y2hlcykge1xuICAgICAgZm9yIChjb25zdCB0YWJsZSBvZiB0YWJsZU1hdGNoZXMpIHtcbiAgICAgICAgY29uc3Qgcm93cyA9IHRhYmxlXG4gICAgICAgICAgLnRyaW0oKVxuICAgICAgICAgIC5zcGxpdChcIlxcblwiKVxuICAgICAgICAgIC5maWx0ZXIoKHJvdykgPT4gcm93LnN0YXJ0c1dpdGgoXCJ8XCIpKVxuICAgICAgICBjb25zdCBwYXJzZWRSb3dzID0gdGhpcy5wYXJzZVRhYmxlUm93cyhyb3dzKVxuICAgICAgICBkdWVEYXRlcy5wdXNoKC4uLnBhcnNlZFJvd3MpXG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIGR1ZURhdGVzXG4gIH1cblxuICBwcml2YXRlIHBhcnNlVGFibGVSb3dzKFxuICAgIHJvd3M6IHN0cmluZ1tdXG4gICk6IEFycmF5PHsgZGF0ZTogc3RyaW5nOyBhc3NpZ25tZW50OiBzdHJpbmc7IHN0YXR1czogc3RyaW5nIH0+IHtcbiAgICBpZiAocm93cy5sZW5ndGggPCAyKSByZXR1cm4gW10gLy8gTmVlZCBhdCBsZWFzdCBoZWFkZXIgKyAxIGRhdGEgcm93XG5cbiAgICBjb25zdCBkdWVEYXRlcyA9IFtdXG5cbiAgICBmb3IgKGxldCBpID0gMTsgaSA8IHJvd3MubGVuZ3RoOyBpKyspIHtcbiAgICAgIC8vIFNraXAgaGVhZGVyIHJvd1xuICAgICAgY29uc3Qgcm93ID0gcm93c1tpXVxuICAgICAgY29uc3QgY29sdW1ucyA9IHJvd1xuICAgICAgICAuc3BsaXQoXCJ8XCIpXG4gICAgICAgIC5tYXAoKGNvbCkgPT4gY29sLnRyaW0oKSlcbiAgICAgICAgLmZpbHRlcigoY29sKSA9PiBjb2wpXG5cbiAgICAgIGlmIChjb2x1bW5zLmxlbmd0aCA+PSAyKSB7XG4gICAgICAgIGNvbnN0IFtkYXRlLCBhc3NpZ25tZW50LCBzdGF0dXMgPSBcInBlbmRpbmdcIl0gPSBjb2x1bW5zXG4gICAgICAgIGlmIChkYXRlICYmIGFzc2lnbm1lbnQgJiYgdGhpcy5pc1ZhbGlkRGF0ZShkYXRlKSkge1xuICAgICAgICAgIGR1ZURhdGVzLnB1c2goeyBkYXRlLCBhc3NpZ25tZW50LCBzdGF0dXMgfSlcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBkdWVEYXRlc1xuICB9XG5cbiAgcHJpdmF0ZSBpc1ZhbGlkRGF0ZShkYXRlU3RyaW5nOiBzdHJpbmcpOiBib29sZWFuIHtcbiAgICBjb25zdCBkYXRlUmVnZXggPSAvXlxcZHs0fS1cXGR7Mn0tXFxkezJ9JC9cbiAgICByZXR1cm4gZGF0ZVJlZ2V4LnRlc3QoZGF0ZVN0cmluZykgJiYgIWlzTmFOKERhdGUucGFyc2UoZGF0ZVN0cmluZykpXG4gIH1cblxuICBhc3luYyBwYXJzZUR1ZURhdGVzRnJvbUNvdXJzZShcbiAgICBjb3Vyc2VJZDogc3RyaW5nLFxuICAgIHN0YXJ0RGF0ZT86IHN0cmluZyxcbiAgICBlbmREYXRlPzogc3RyaW5nXG4gICk6IFByb21pc2U8XG4gICAgQXJyYXk8eyBkYXRlOiBzdHJpbmc7IGFzc2lnbm1lbnQ6IHN0cmluZzsgc3RhdHVzOiBzdHJpbmc7IHNvdXJjZTogc3RyaW5nIH0+XG4gID4ge1xuICAgIGNvbnNvbGUubG9nKGBQYXJzaW5nIGR1ZSBkYXRlcyBmb3IgY291cnNlOiAke2NvdXJzZUlkfWApXG5cbiAgICB0cnkge1xuICAgICAgLy8gRmluZCBhbGwgbm90ZXMgcmVsYXRlZCB0byB0aGUgY291cnNlXG4gICAgICBjb25zdCBjb3Vyc2VOb3RlcyA9IGF3YWl0IHRoaXMuZmluZENvdXJzZU5vdGVzKGNvdXJzZUlkKVxuXG4gICAgICBpZiAoY291cnNlTm90ZXMubGVuZ3RoID09PSAwKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKGBObyBub3RlcyBmb3VuZCBmb3IgY291cnNlOiAke2NvdXJzZUlkfWApXG4gICAgICAgIHJldHVybiBbXVxuICAgICAgfVxuXG4gICAgICAvLyBQYXJzZSBkdWUgZGF0ZXMgZnJvbSBlYWNoIG5vdGVcbiAgICAgIGNvbnN0IGFsbER1ZURhdGVzOiBBcnJheTx7XG4gICAgICAgIGRhdGU6IHN0cmluZ1xuICAgICAgICBhc3NpZ25tZW50OiBzdHJpbmdcbiAgICAgICAgc3RhdHVzOiBzdHJpbmdcbiAgICAgICAgc291cmNlOiBzdHJpbmdcbiAgICAgIH0+ID0gW11cblxuICAgICAgZm9yIChjb25zdCBub3RlIG9mIGNvdXJzZU5vdGVzKSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgY29uc3QgY29udGVudCA9IGF3YWl0IHRoaXMuYXBwLnZhdWx0LnJlYWQobm90ZSlcbiAgICAgICAgICBjb25zdCBkdWVEYXRlcyA9IHRoaXMucGFyc2VEdWVEYXRlc0Zyb21Ob3RlKGNvbnRlbnQpXG5cbiAgICAgICAgICAvLyBBZGQgc291cmNlIGluZm9ybWF0aW9uXG4gICAgICAgICAgY29uc3QgZHVlRGF0ZXNXaXRoU291cmNlID0gZHVlRGF0ZXMubWFwKChkdWVEYXRlKSA9PiAoe1xuICAgICAgICAgICAgLi4uZHVlRGF0ZSxcbiAgICAgICAgICAgIHNvdXJjZTogbm90ZS5iYXNlbmFtZVxuICAgICAgICAgIH0pKVxuXG4gICAgICAgICAgYWxsRHVlRGF0ZXMucHVzaCguLi5kdWVEYXRlc1dpdGhTb3VyY2UpXG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgY29uc29sZS5lcnJvcihgRXJyb3IgcmVhZGluZyBub3RlICR7bm90ZS5wYXRofTpgLCBlcnJvcilcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICAvLyBGaWx0ZXIgYnkgZGF0ZSByYW5nZSBpZiBwcm92aWRlZFxuICAgICAgbGV0IGZpbHRlcmVkRHVlRGF0ZXMgPSBhbGxEdWVEYXRlc1xuICAgICAgaWYgKHN0YXJ0RGF0ZSB8fCBlbmREYXRlKSB7XG4gICAgICAgIGZpbHRlcmVkRHVlRGF0ZXMgPSB0aGlzLmZpbHRlckJ5RGF0ZVJhbmdlKFxuICAgICAgICAgIGFsbER1ZURhdGVzLFxuICAgICAgICAgIHN0YXJ0RGF0ZSxcbiAgICAgICAgICBlbmREYXRlXG4gICAgICAgIClcbiAgICAgIH1cblxuICAgICAgLy8gU29ydCBieSBkYXRlXG4gICAgICBmaWx0ZXJlZER1ZURhdGVzLnNvcnQoXG4gICAgICAgIChhLCBiKSA9PiBuZXcgRGF0ZShhLmRhdGUpLmdldFRpbWUoKSAtIG5ldyBEYXRlKGIuZGF0ZSkuZ2V0VGltZSgpXG4gICAgICApXG5cbiAgICAgIGNvbnNvbGUubG9nKFxuICAgICAgICBgRm91bmQgJHtmaWx0ZXJlZER1ZURhdGVzLmxlbmd0aH0gZHVlIGRhdGVzIGZvciBjb3Vyc2U6ICR7Y291cnNlSWR9YFxuICAgICAgKVxuICAgICAgcmV0dXJuIGZpbHRlcmVkRHVlRGF0ZXNcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihgRXJyb3IgcGFyc2luZyBkdWUgZGF0ZXMgZm9yIGNvdXJzZSAke2NvdXJzZUlkfTpgLCBlcnJvcilcbiAgICAgIHJldHVybiBbXVxuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgZmluZENvdXJzZU5vdGVzKGNvdXJzZUlkOiBzdHJpbmcpOiBQcm9taXNlPFRGaWxlW10+IHtcbiAgICBjb25zdCBub3RlczogVEZpbGVbXSA9IFtdXG5cbiAgICAvLyBHZXQgYWxsIG1hcmtkb3duIGZpbGVzIGluIHRoZSB2YXVsdFxuICAgIGNvbnN0IGZpbGVzID0gdGhpcy5hcHAudmF1bHQuZ2V0TWFya2Rvd25GaWxlcygpXG5cbiAgICBmb3IgKGNvbnN0IGZpbGUgb2YgZmlsZXMpIHtcbiAgICAgIC8vIENoZWNrIGlmIHRoZSBmaWxlIHBhdGggY29udGFpbnMgdGhlIGNvdXJzZSBJRCBvciBiZWxvbmdzIHRvIHRoZSBjb3Vyc2VcbiAgICAgIGlmIChcbiAgICAgICAgZmlsZS5wYXRoLmluY2x1ZGVzKGNvdXJzZUlkKSB8fFxuICAgICAgICAoYXdhaXQgdGhpcy5ub3RlQmVsb25nc1RvQ291cnNlKGZpbGUsIGNvdXJzZUlkKSlcbiAgICAgICkge1xuICAgICAgICBub3Rlcy5wdXNoKGZpbGUpXG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIG5vdGVzXG4gIH1cblxuICBwcml2YXRlIGFzeW5jIG5vdGVCZWxvbmdzVG9Db3Vyc2UoXG4gICAgZmlsZTogVEZpbGUsXG4gICAgY291cnNlSWQ6IHN0cmluZ1xuICApOiBQcm9taXNlPGJvb2xlYW4+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgY29udGVudCA9IGF3YWl0IHRoaXMuYXBwLnZhdWx0LnJlYWQoZmlsZSlcbiAgICAgIGNvbnN0IGZyb250bWF0dGVyTWF0Y2ggPSBjb250ZW50Lm1hdGNoKC9eLS0tXFxuKFtcXHNcXFNdKj8pXFxuLS0tLylcblxuICAgICAgaWYgKGZyb250bWF0dGVyTWF0Y2gpIHtcbiAgICAgICAgY29uc3QgZnJvbnRtYXR0ZXIgPSBmcm9udG1hdHRlck1hdGNoWzFdXG4gICAgICAgIC8vIENoZWNrIGlmIGNvdXJzZV9pZCBpcyBpbiB0aGUgZnJvbnRtYXR0ZXJcbiAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICBmcm9udG1hdHRlci5pbmNsdWRlcyhgY291cnNlX2lkOiAke2NvdXJzZUlkfWApIHx8XG4gICAgICAgICAgZnJvbnRtYXR0ZXIuaW5jbHVkZXMoYGNvdXJzZV9pZDoke2NvdXJzZUlkfWApXG4gICAgICAgIClcbiAgICAgIH1cblxuICAgICAgcmV0dXJuIGZhbHNlXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXG4gICAgICAgIGBFcnJvciBjaGVja2luZyBpZiBub3RlICR7ZmlsZS5wYXRofSBiZWxvbmdzIHRvIGNvdXJzZSAke2NvdXJzZUlkfTpgLFxuICAgICAgICBlcnJvclxuICAgICAgKVxuICAgICAgcmV0dXJuIGZhbHNlXG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSBmaWx0ZXJCeURhdGVSYW5nZShcbiAgICBkdWVEYXRlczogQXJyYXk8e1xuICAgICAgZGF0ZTogc3RyaW5nXG4gICAgICBhc3NpZ25tZW50OiBzdHJpbmdcbiAgICAgIHN0YXR1czogc3RyaW5nXG4gICAgICBzb3VyY2U6IHN0cmluZ1xuICAgIH0+LFxuICAgIHN0YXJ0RGF0ZT86IHN0cmluZyxcbiAgICBlbmREYXRlPzogc3RyaW5nXG4gICk6IEFycmF5PHtcbiAgICBkYXRlOiBzdHJpbmdcbiAgICBhc3NpZ25tZW50OiBzdHJpbmdcbiAgICBzdGF0dXM6IHN0cmluZ1xuICAgIHNvdXJjZTogc3RyaW5nXG4gIH0+IHtcbiAgICByZXR1cm4gZHVlRGF0ZXMuZmlsdGVyKChkdWVEYXRlKSA9PiB7XG4gICAgICBjb25zdCBkdWVEYXRlVGltZSA9IG5ldyBEYXRlKGR1ZURhdGUuZGF0ZSkuZ2V0VGltZSgpXG5cbiAgICAgIGlmIChzdGFydERhdGUgJiYgZHVlRGF0ZVRpbWUgPCBuZXcgRGF0ZShzdGFydERhdGUpLmdldFRpbWUoKSkge1xuICAgICAgICByZXR1cm4gZmFsc2VcbiAgICAgIH1cblxuICAgICAgaWYgKGVuZERhdGUgJiYgZHVlRGF0ZVRpbWUgPiBuZXcgRGF0ZShlbmREYXRlKS5nZXRUaW1lKCkpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlXG4gICAgICB9XG5cbiAgICAgIHJldHVybiB0cnVlXG4gICAgfSlcbiAgfVxuXG4gIGFzeW5jIGdlbmVyYXRlRHVlRGF0ZXNTdW1tYXJ5KFxuICAgIGNvdXJzZUlkOiBzdHJpbmcsXG4gICAgZHVlRGF0ZXM6IEFycmF5PHtcbiAgICAgIGRhdGU6IHN0cmluZ1xuICAgICAgYXNzaWdubWVudDogc3RyaW5nXG4gICAgICBzdGF0dXM6IHN0cmluZ1xuICAgICAgc291cmNlOiBzdHJpbmdcbiAgICB9PlxuICApOiBQcm9taXNlPHN0cmluZz4ge1xuICAgIGlmIChkdWVEYXRlcy5sZW5ndGggPT09IDApIHtcbiAgICAgIHJldHVybiBgIyBEdWUgRGF0ZXMgU3VtbWFyeSAtICR7Y291cnNlSWR9XFxuXFxuTm8gZHVlIGRhdGVzIGZvdW5kLlxcbmBcbiAgICB9XG5cbiAgICAvLyBHcm91cCBieSBzdGF0dXNcbiAgICBjb25zdCBieVN0YXR1cyA9IGR1ZURhdGVzLnJlZHVjZSgoYWNjLCBkdWVEYXRlKSA9PiB7XG4gICAgICBpZiAoIWFjY1tkdWVEYXRlLnN0YXR1c10pIHtcbiAgICAgICAgYWNjW2R1ZURhdGUuc3RhdHVzXSA9IFtdXG4gICAgICB9XG4gICAgICBhY2NbZHVlRGF0ZS5zdGF0dXNdLnB1c2goZHVlRGF0ZSlcbiAgICAgIHJldHVybiBhY2NcbiAgICB9LCB7fSBhcyBSZWNvcmQ8c3RyaW5nLCB0eXBlb2YgZHVlRGF0ZXM+KVxuXG4gICAgbGV0IGNvbnRlbnQgPSBgIyBEdWUgRGF0ZXMgU3VtbWFyeSAtICR7Y291cnNlSWR9XFxuXFxuYFxuICAgIGNvbnRlbnQgKz0gYFRvdGFsIGFzc2lnbm1lbnRzOiAke2R1ZURhdGVzLmxlbmd0aH1cXG5cXG5gXG5cbiAgICAvLyBBZGQgc3VtbWFyeSBieSBzdGF0dXNcbiAgICBmb3IgKGNvbnN0IFtzdGF0dXMsIGl0ZW1zXSBvZiBPYmplY3QuZW50cmllcyhieVN0YXR1cykpIHtcbiAgICAgIGNvbnRlbnQgKz0gYCMjICR7c3RhdHVzLmNoYXJBdCgwKS50b1VwcGVyQ2FzZSgpICsgc3RhdHVzLnNsaWNlKDEpfSAoJHtcbiAgICAgICAgaXRlbXMubGVuZ3RoXG4gICAgICB9KVxcblxcbmBcbiAgICAgIGNvbnRlbnQgKz0gYHwgRGF0ZSB8IEFzc2lnbm1lbnQgfCBTb3VyY2UgfFxcbmBcbiAgICAgIGNvbnRlbnQgKz0gYHwgLS0tLSB8IC0tLS0tLS0tLS0gfCAtLS0tLS0gfFxcbmBcblxuICAgICAgZm9yIChjb25zdCBpdGVtIG9mIGl0ZW1zKSB7XG4gICAgICAgIGNvbnRlbnQgKz0gYHwgJHtpdGVtLmRhdGV9IHwgJHtpdGVtLmFzc2lnbm1lbnR9IHwgJHtpdGVtLnNvdXJjZX0gfFxcbmBcbiAgICAgIH1cbiAgICAgIGNvbnRlbnQgKz0gYFxcbmBcbiAgICB9XG5cbiAgICByZXR1cm4gY29udGVudFxuICB9XG5cbiAgYXN5bmMgY3JlYXRlRHVlRGF0ZXNTdW1tYXJ5RmlsZShcbiAgICBjb3Vyc2VJZDogc3RyaW5nLFxuICAgIHN0YXJ0RGF0ZT86IHN0cmluZyxcbiAgICBlbmREYXRlPzogc3RyaW5nXG4gICk6IFByb21pc2U8dm9pZD4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBkdWVEYXRlcyA9IGF3YWl0IHRoaXMucGFyc2VEdWVEYXRlc0Zyb21Db3Vyc2UoXG4gICAgICAgIGNvdXJzZUlkLFxuICAgICAgICBzdGFydERhdGUsXG4gICAgICAgIGVuZERhdGVcbiAgICAgIClcblxuICAgICAgY29uc3Qgc3VtbWFyeUNvbnRlbnQgPSBhd2FpdCB0aGlzLmdlbmVyYXRlRHVlRGF0ZXNTdW1tYXJ5KFxuICAgICAgICBjb3Vyc2VJZCxcbiAgICAgICAgZHVlRGF0ZXNcbiAgICAgIClcblxuICAgICAgLy8gQ3JlYXRlIHRoZSBzdW1tYXJ5IGZpbGVcbiAgICAgIGNvbnN0IGZpbGVOYW1lID0gYCR7Y291cnNlSWR9IC0gRHVlIERhdGVzIFN1bW1hcnkubWRgXG4gICAgICBjb25zdCBmaWxlUGF0aCA9IGBDb3Vyc2VzLyR7Y291cnNlSWR9LyR7ZmlsZU5hbWV9YFxuXG4gICAgICB0cnkge1xuICAgICAgICBhd2FpdCB0aGlzLmFwcC52YXVsdC5jcmVhdGUoZmlsZVBhdGgsIHN1bW1hcnlDb250ZW50KVxuICAgICAgICBjb25zb2xlLmxvZyhgQ3JlYXRlZCBkdWUgZGF0ZXMgc3VtbWFyeSBmaWxlOiAke2ZpbGVQYXRofWApXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAvLyBGaWxlIG1pZ2h0IGFscmVhZHkgZXhpc3QsIHRyeSB0byB1cGRhdGUgaXRcbiAgICAgICAgY29uc3QgZXhpc3RpbmdGaWxlID0gdGhpcy5hcHAudmF1bHQuZ2V0QWJzdHJhY3RGaWxlQnlQYXRoKGZpbGVQYXRoKVxuICAgICAgICBpZiAoZXhpc3RpbmdGaWxlICYmIGV4aXN0aW5nRmlsZSBpbnN0YW5jZW9mIFRGaWxlKSB7XG4gICAgICAgICAgYXdhaXQgdGhpcy5hcHAudmF1bHQubW9kaWZ5KGV4aXN0aW5nRmlsZSwgc3VtbWFyeUNvbnRlbnQpXG4gICAgICAgICAgY29uc29sZS5sb2coYFVwZGF0ZWQgZHVlIGRhdGVzIHN1bW1hcnkgZmlsZTogJHtmaWxlUGF0aH1gKVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXG4gICAgICAgIGBFcnJvciBjcmVhdGluZyBkdWUgZGF0ZXMgc3VtbWFyeSBmb3IgY291cnNlICR7Y291cnNlSWR9OmAsXG4gICAgICAgIGVycm9yXG4gICAgICApXG4gICAgICB0aHJvdyBlcnJvclxuICAgIH1cbiAgfVxufVxuIiwgIi8vIERhaWx5IG5vdGVzIGludGVncmF0aW9uIGZvciBUdWNrZXJzIFRvb2xzIHBsdWdpblxuXG5pbXBvcnQgeyBBcHAsIFRGaWxlIH0gZnJvbSBcIm9ic2lkaWFuXCJcblxuZXhwb3J0IGNsYXNzIERhaWx5Tm90ZXNJbnRlZ3JhdGlvbiB7XG4gIGFwcDogQXBwXG5cbiAgY29uc3RydWN0b3IoYXBwOiBBcHApIHtcbiAgICB0aGlzLmFwcCA9IGFwcFxuICB9XG5cbiAgYXN5bmMgZ2V0VG9kYXlzQWN0aXZpdGllcygpOiBQcm9taXNlPFxuICAgIEFycmF5PHsgZmlsZTogc3RyaW5nOyB0eXBlOiBzdHJpbmc7IGNvdXJzZT86IHN0cmluZyB9PlxuICA+IHtcbiAgICBjb25zb2xlLmxvZyhcIkdldHRpbmcgdG9kYXkncyBhY2FkZW1pYyBhY3Rpdml0aWVzXCIpXG5cbiAgICB0cnkge1xuICAgICAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpXG4gICAgICBjb25zdCB0b2RheVN0cmluZyA9IHRvZGF5LnRvSVNPU3RyaW5nKCkuc3BsaXQoXCJUXCIpWzBdXG5cbiAgICAgIC8vIEZpbmQgZmlsZXMgY3JlYXRlZCBvciBtb2RpZmllZCB0b2RheVxuICAgICAgY29uc3QgZmlsZXMgPSB0aGlzLmFwcC52YXVsdC5nZXRNYXJrZG93bkZpbGVzKClcbiAgICAgIGNvbnN0IHRvZGF5c0ZpbGVzOiBURmlsZVtdID0gW11cblxuICAgICAgZm9yIChjb25zdCBmaWxlIG9mIGZpbGVzKSB7XG4gICAgICAgIGNvbnN0IGZpbGVEYXRlID0gdGhpcy5leHRyYWN0RGF0ZUZyb21QYXRoKGZpbGUucGF0aClcbiAgICAgICAgaWYgKGZpbGVEYXRlID09PSB0b2RheVN0cmluZykge1xuICAgICAgICAgIHRvZGF5c0ZpbGVzLnB1c2goZmlsZSlcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICAvLyBBbmFseXplIGFjdGl2aXRpZXNcbiAgICAgIGNvbnN0IGFjdGl2aXRpZXM6IEFycmF5PHsgZmlsZTogc3RyaW5nOyB0eXBlOiBzdHJpbmc7IGNvdXJzZT86IHN0cmluZyB9PiA9XG4gICAgICAgIFtdXG5cbiAgICAgIGZvciAoY29uc3QgZmlsZSBvZiB0b2RheXNGaWxlcykge1xuICAgICAgICBjb25zdCBhY3Rpdml0eSA9IGF3YWl0IHRoaXMuYW5hbHl6ZUZpbGVBY3Rpdml0eShmaWxlKVxuICAgICAgICBpZiAoYWN0aXZpdHkpIHtcbiAgICAgICAgICBhY3Rpdml0aWVzLnB1c2goYWN0aXZpdHkpXG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgY29uc29sZS5sb2coYEZvdW5kICR7YWN0aXZpdGllcy5sZW5ndGh9IGFjYWRlbWljIGFjdGl2aXRpZXMgZm9yIHRvZGF5YClcbiAgICAgIHJldHVybiBhY3Rpdml0aWVzXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBnZXR0aW5nIHRvZGF5J3MgYWN0aXZpdGllczpcIiwgZXJyb3IpXG4gICAgICByZXR1cm4gW11cbiAgICB9XG4gIH1cblxuICBhc3luYyBnZXRDb3Vyc2VBY3Rpdml0eUZvckRhdGUoXG4gICAgY291cnNlSWQ6IHN0cmluZyxcbiAgICBkYXRlOiBzdHJpbmdcbiAgKTogUHJvbWlzZTxBcnJheTx7IGZpbGU6IHN0cmluZzsgdHlwZTogc3RyaW5nIH0+PiB7XG4gICAgY29uc29sZS5sb2coYEdldHRpbmcgYWN0aXZpdHkgZm9yIGNvdXJzZSAke2NvdXJzZUlkfSBvbiBkYXRlICR7ZGF0ZX1gKVxuXG4gICAgdHJ5IHtcbiAgICAgIC8vIEZpbmQgZmlsZXMgcmVsYXRlZCB0byB0aGUgY291cnNlIG1vZGlmaWVkIG9uIHRoZSBkYXRlXG4gICAgICBjb25zdCBjb3Vyc2VGaWxlcyA9IGF3YWl0IHRoaXMuZmluZENvdXJzZUZpbGVzRm9yRGF0ZShjb3Vyc2VJZCwgZGF0ZSlcblxuICAgICAgY29uc3QgYWN0aXZpdGllczogQXJyYXk8eyBmaWxlOiBzdHJpbmc7IHR5cGU6IHN0cmluZyB9PiA9IFtdXG5cbiAgICAgIGZvciAoY29uc3QgZmlsZSBvZiBjb3Vyc2VGaWxlcykge1xuICAgICAgICBjb25zdCBjb250ZW50ID0gYXdhaXQgdGhpcy5hcHAudmF1bHQucmVhZChmaWxlKVxuICAgICAgICBjb25zdCBmaWxlVHlwZSA9IHRoaXMuZGV0ZXJtaW5lRmlsZVR5cGUoZmlsZSwgY29udGVudClcblxuICAgICAgICBhY3Rpdml0aWVzLnB1c2goe1xuICAgICAgICAgIGZpbGU6IGZpbGUuYmFzZW5hbWUsXG4gICAgICAgICAgdHlwZTogZmlsZVR5cGVcbiAgICAgICAgfSlcbiAgICAgIH1cblxuICAgICAgY29uc29sZS5sb2coXG4gICAgICAgIGBGb3VuZCAke2FjdGl2aXRpZXMubGVuZ3RofSBhY3Rpdml0aWVzIGZvciBjb3Vyc2UgJHtjb3Vyc2VJZH0gb24gJHtkYXRlfWBcbiAgICAgIClcbiAgICAgIHJldHVybiBhY3Rpdml0aWVzXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXG4gICAgICAgIGBFcnJvciBnZXR0aW5nIGNvdXJzZSBhY3Rpdml0eSBmb3IgJHtjb3Vyc2VJZH0gb24gJHtkYXRlfTpgLFxuICAgICAgICBlcnJvclxuICAgICAgKVxuICAgICAgcmV0dXJuIFtdXG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSBleHRyYWN0RGF0ZUZyb21QYXRoKGZpbGVQYXRoOiBzdHJpbmcpOiBzdHJpbmcgfCBudWxsIHtcbiAgICAvLyBUcnkgdG8gZXh0cmFjdCBkYXRlIGZyb20gZmlsZSBwYXRoIChlLmcuLCBcIkRhaWx5LzIwMjUtMDEtMTUubWRcIiAtPiBcIjIwMjUtMDEtMTVcIilcbiAgICBjb25zdCBkYXRlUmVnZXggPSAvKFxcZHs0fS1cXGR7Mn0tXFxkezJ9KS9nXG4gICAgY29uc3QgbWF0Y2hlcyA9IGZpbGVQYXRoLm1hdGNoKGRhdGVSZWdleClcbiAgICByZXR1cm4gbWF0Y2hlcyA/IG1hdGNoZXNbbWF0Y2hlcy5sZW5ndGggLSAxXSA6IG51bGxcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgYW5hbHl6ZUZpbGVBY3Rpdml0eShcbiAgICBmaWxlOiBURmlsZVxuICApOiBQcm9taXNlPHsgZmlsZTogc3RyaW5nOyB0eXBlOiBzdHJpbmc7IGNvdXJzZT86IHN0cmluZyB9IHwgbnVsbD4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBjb250ZW50ID0gYXdhaXQgdGhpcy5hcHAudmF1bHQucmVhZChmaWxlKVxuXG4gICAgICAvLyBEZXRlcm1pbmUgZmlsZSB0eXBlIGJhc2VkIG9uIGNvbnRlbnQgYW5kIHBhdGhcbiAgICAgIGNvbnN0IGZpbGVUeXBlID0gdGhpcy5kZXRlcm1pbmVGaWxlVHlwZShmaWxlLCBjb250ZW50KVxuXG4gICAgICAvLyBFeHRyYWN0IGNvdXJzZSBJRCBpZiBhcHBsaWNhYmxlXG4gICAgICBjb25zdCBjb3Vyc2VJZCA9XG4gICAgICAgIHRoaXMuZXh0cmFjdENvdXJzZUlkRnJvbUNvbnRlbnQoY29udGVudCkgfHxcbiAgICAgICAgdGhpcy5leHRyYWN0Q291cnNlSWRGcm9tUGF0aChmaWxlLnBhdGgpXG5cbiAgICAgIHJldHVybiB7XG4gICAgICAgIGZpbGU6IGZpbGUuYmFzZW5hbWUsXG4gICAgICAgIHR5cGU6IGZpbGVUeXBlLFxuICAgICAgICBjb3Vyc2U6IGNvdXJzZUlkIHx8IHVuZGVmaW5lZFxuICAgICAgfVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKGBFcnJvciBhbmFseXppbmcgZmlsZSAke2ZpbGUucGF0aH06YCwgZXJyb3IpXG4gICAgICByZXR1cm4gbnVsbFxuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgZGV0ZXJtaW5lRmlsZVR5cGUoZmlsZTogVEZpbGUsIGNvbnRlbnQ6IHN0cmluZyk6IHN0cmluZyB7XG4gICAgY29uc3QgcGF0aCA9IGZpbGUucGF0aC50b0xvd2VyQ2FzZSgpXG5cbiAgICAvLyBDaGVjayBmb3IgZGFpbHkgbm90ZXNcbiAgICBpZiAoXG4gICAgICBwYXRoLmluY2x1ZGVzKFwiZGFpbHlcIikgfHxcbiAgICAgIGNvbnRlbnQuaW5jbHVkZXMoXCJjb250ZW50X3R5cGU6IGRhaWx5X25vdGVcIilcbiAgICApIHtcbiAgICAgIHJldHVybiBcImRhaWx5X25vdGVcIlxuICAgIH1cblxuICAgIC8vIENoZWNrIGZvciBjb3Vyc2UtcmVsYXRlZCBmaWxlc1xuICAgIGlmIChwYXRoLmluY2x1ZGVzKFwiY291cnNlc1wiKSB8fCBjb250ZW50LmluY2x1ZGVzKFwiY291cnNlX2lkOlwiKSkge1xuICAgICAgaWYgKGNvbnRlbnQuaW5jbHVkZXMoXCJjb250ZW50X3R5cGU6IGNvdXJzZV9ob21lcGFnZVwiKSkge1xuICAgICAgICByZXR1cm4gXCJjb3Vyc2VfaG9tZXBhZ2VcIlxuICAgICAgfVxuICAgICAgaWYgKGNvbnRlbnQuaW5jbHVkZXMoXCJjb250ZW50X3R5cGU6IG1vZHVsZVwiKSkge1xuICAgICAgICByZXR1cm4gXCJtb2R1bGVcIlxuICAgICAgfVxuICAgICAgaWYgKGNvbnRlbnQuaW5jbHVkZXMoXCJjb250ZW50X3R5cGU6IGNoYXB0ZXJcIikpIHtcbiAgICAgICAgcmV0dXJuIFwiY2hhcHRlclwiXG4gICAgICB9XG4gICAgICBpZiAoY29udGVudC5pbmNsdWRlcyhcImNvbnRlbnRfdHlwZTogYXNzaWdubWVudFwiKSkge1xuICAgICAgICByZXR1cm4gXCJhc3NpZ25tZW50XCJcbiAgICAgIH1cbiAgICAgIHJldHVybiBcImNvdXJzZV9ub3RlXCJcbiAgICB9XG5cbiAgICAvLyBDaGVjayBmb3Igdm9jYWJ1bGFyeSBlbnRyaWVzXG4gICAgaWYgKGNvbnRlbnQuaW5jbHVkZXMoXCIjIyBcIikgJiYgY29udGVudC5tYXRjaCgvXlxcKlxcKlRlcm1cXCpcXCo6L20pKSB7XG4gICAgICByZXR1cm4gXCJ2b2NhYnVsYXJ5X2VudHJ5XCJcbiAgICB9XG5cbiAgICByZXR1cm4gXCJvdGhlclwiXG4gIH1cblxuICBwcml2YXRlIGV4dHJhY3RDb3Vyc2VJZEZyb21Db250ZW50KGNvbnRlbnQ6IHN0cmluZyk6IHN0cmluZyB8IG51bGwge1xuICAgIGNvbnN0IGNvdXJzZUlkUmVnZXggPSAvY291cnNlX2lkOlxccyooW0EtWl17Miw0fS1cXGR7M30pL1xuICAgIGNvbnN0IG1hdGNoID0gY29udGVudC5tYXRjaChjb3Vyc2VJZFJlZ2V4KVxuICAgIHJldHVybiBtYXRjaCA/IG1hdGNoWzFdIDogbnVsbFxuICB9XG5cbiAgcHJpdmF0ZSBleHRyYWN0Q291cnNlSWRGcm9tUGF0aChmaWxlUGF0aDogc3RyaW5nKTogc3RyaW5nIHwgbnVsbCB7XG4gICAgY29uc3QgY291cnNlSWRSZWdleCA9IC8oW0EtWl17Miw0fS1cXGR7M30pL2dcbiAgICBjb25zdCBtYXRjaGVzID0gZmlsZVBhdGgubWF0Y2goY291cnNlSWRSZWdleClcbiAgICByZXR1cm4gbWF0Y2hlcyA/IG1hdGNoZXNbbWF0Y2hlcy5sZW5ndGggLSAxXSA6IG51bGxcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgZmluZENvdXJzZUZpbGVzRm9yRGF0ZShcbiAgICBjb3Vyc2VJZDogc3RyaW5nLFxuICAgIGRhdGU6IHN0cmluZ1xuICApOiBQcm9taXNlPFRGaWxlW10+IHtcbiAgICBjb25zdCBmaWxlczogVEZpbGVbXSA9IFtdXG5cbiAgICAvLyBHZXQgYWxsIGZpbGVzIGFuZCBmaWx0ZXIgYnkgY291cnNlIElEIGFuZCBkYXRlXG4gICAgY29uc3QgYWxsRmlsZXMgPSB0aGlzLmFwcC52YXVsdC5nZXRNYXJrZG93bkZpbGVzKClcblxuICAgIGZvciAoY29uc3QgZmlsZSBvZiBhbGxGaWxlcykge1xuICAgICAgLy8gQ2hlY2sgaWYgZmlsZSBiZWxvbmdzIHRvIHRoZSBjb3Vyc2VcbiAgICAgIGlmIChcbiAgICAgICAgZmlsZS5wYXRoLmluY2x1ZGVzKGNvdXJzZUlkKSB8fFxuICAgICAgICAoYXdhaXQgdGhpcy5maWxlQmVsb25nc1RvQ291cnNlKGZpbGUsIGNvdXJzZUlkKSlcbiAgICAgICkge1xuICAgICAgICAvLyBDaGVjayBpZiBmaWxlIHdhcyBtb2RpZmllZCBvbiB0aGUgc3BlY2lmaWVkIGRhdGVcbiAgICAgICAgY29uc3QgZmlsZURhdGUgPSB0aGlzLmV4dHJhY3REYXRlRnJvbVBhdGgoZmlsZS5wYXRoKVxuICAgICAgICBpZiAoZmlsZURhdGUgPT09IGRhdGUpIHtcbiAgICAgICAgICBmaWxlcy5wdXNoKGZpbGUpXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gZmlsZXNcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgZmlsZUJlbG9uZ3NUb0NvdXJzZShcbiAgICBmaWxlOiBURmlsZSxcbiAgICBjb3Vyc2VJZDogc3RyaW5nXG4gICk6IFByb21pc2U8Ym9vbGVhbj4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBjb250ZW50ID0gYXdhaXQgdGhpcy5hcHAudmF1bHQucmVhZChmaWxlKVxuICAgICAgcmV0dXJuIHRoaXMuZXh0cmFjdENvdXJzZUlkRnJvbUNvbnRlbnQoY29udGVudCkgPT09IGNvdXJzZUlkXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXG4gICAgICAgIGBFcnJvciBjaGVja2luZyBpZiBmaWxlICR7ZmlsZS5wYXRofSBiZWxvbmdzIHRvIGNvdXJzZSAke2NvdXJzZUlkfTpgLFxuICAgICAgICBlcnJvclxuICAgICAgKVxuICAgICAgcmV0dXJuIGZhbHNlXG4gICAgfVxuICB9XG5cbiAgYXN5bmMgZ2VuZXJhdGVEYWlseVN1bW1hcnkoZGF0ZT86IHN0cmluZyk6IFByb21pc2U8c3RyaW5nPiB7XG4gICAgY29uc3QgdGFyZ2V0RGF0ZSA9IGRhdGUgfHwgbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNwbGl0KFwiVFwiKVswXVxuICAgIGNvbnN0IGFjdGl2aXRpZXMgPSBhd2FpdCB0aGlzLmdldENvdXJzZUFjdGl2aXR5Rm9yRGF0ZShcIlwiLCB0YXJnZXREYXRlKVxuXG4gICAgaWYgKGFjdGl2aXRpZXMubGVuZ3RoID09PSAwKSB7XG4gICAgICByZXR1cm4gYCMgQWNhZGVtaWMgQWN0aXZpdGllcyAtICR7dGFyZ2V0RGF0ZX1cXG5cXG5ObyBhY2FkZW1pYyBhY3Rpdml0aWVzIHJlY29yZGVkIGZvciB0aGlzIGRhdGUuXFxuYFxuICAgIH1cblxuICAgIC8vIEdyb3VwIGFjdGl2aXRpZXMgYnkgY291cnNlXG4gICAgY29uc3QgYnlDb3Vyc2U6IFJlY29yZDxzdHJpbmcsIHR5cGVvZiBhY3Rpdml0aWVzPiA9IHt9XG4gICAgY29uc3Qgbm9Db3Vyc2U6IHR5cGVvZiBhY3Rpdml0aWVzID0gW11cblxuICAgIGZvciAoY29uc3QgYWN0aXZpdHkgb2YgYWN0aXZpdGllcykge1xuICAgICAgaWYgKGFjdGl2aXR5LmZpbGUuaW5jbHVkZXMoXCJDb3Vyc2VzL1wiKSkge1xuICAgICAgICAvLyBFeHRyYWN0IGNvdXJzZSBJRCBmcm9tIHBhdGhcbiAgICAgICAgY29uc3QgcGF0aFBhcnRzID0gYWN0aXZpdHkuZmlsZS5zcGxpdChcIi9cIilcbiAgICAgICAgY29uc3QgY291cnNlSW5kZXggPSBwYXRoUGFydHMuZmluZEluZGV4KChwYXJ0KSA9PiBwYXJ0LmluY2x1ZGVzKFwiLVwiKSlcbiAgICAgICAgaWYgKGNvdXJzZUluZGV4ID49IDApIHtcbiAgICAgICAgICBjb25zdCBjb3Vyc2VJZCA9IHBhdGhQYXJ0c1tjb3Vyc2VJbmRleF1cbiAgICAgICAgICBpZiAoIWJ5Q291cnNlW2NvdXJzZUlkXSkge1xuICAgICAgICAgICAgYnlDb3Vyc2VbY291cnNlSWRdID0gW11cbiAgICAgICAgICB9XG4gICAgICAgICAgYnlDb3Vyc2VbY291cnNlSWRdLnB1c2goYWN0aXZpdHkpXG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgbm9Db3Vyc2UucHVzaChhY3Rpdml0eSlcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgbm9Db3Vyc2UucHVzaChhY3Rpdml0eSlcbiAgICAgIH1cbiAgICB9XG5cbiAgICBsZXQgY29udGVudCA9IGAjIEFjYWRlbWljIEFjdGl2aXRpZXMgLSAke3RhcmdldERhdGV9XFxuXFxuYFxuICAgIGNvbnRlbnQgKz0gYFRvdGFsIGFjdGl2aXRpZXM6ICR7YWN0aXZpdGllcy5sZW5ndGh9XFxuXFxuYFxuXG4gICAgLy8gQWRkIGFjdGl2aXRpZXMgYnkgY291cnNlXG4gICAgZm9yIChjb25zdCBbY291cnNlSWQsIGNvdXJzZUFjdGl2aXRpZXNdIG9mIE9iamVjdC5lbnRyaWVzKGJ5Q291cnNlKSkge1xuICAgICAgY29udGVudCArPSBgIyMgJHtjb3Vyc2VJZH1cXG5cXG5gXG4gICAgICBjb250ZW50ICs9IGB8IEZpbGUgfCBUeXBlIHxcXG5gXG4gICAgICBjb250ZW50ICs9IGB8IC0tLS0gfCAtLS0tIHxcXG5gXG5cbiAgICAgIGZvciAoY29uc3QgYWN0aXZpdHkgb2YgY291cnNlQWN0aXZpdGllcykge1xuICAgICAgICBjb250ZW50ICs9IGB8ICR7YWN0aXZpdHkuZmlsZX0gfCAke2FjdGl2aXR5LnR5cGV9IHxcXG5gXG4gICAgICB9XG4gICAgICBjb250ZW50ICs9IGBcXG5gXG4gICAgfVxuXG4gICAgLy8gQWRkIGFjdGl2aXRpZXMgd2l0aG91dCBzcGVjaWZpYyBjb3Vyc2VcbiAgICBpZiAobm9Db3Vyc2UubGVuZ3RoID4gMCkge1xuICAgICAgY29udGVudCArPSBgIyMgT3RoZXIgQWN0aXZpdGllc1xcblxcbmBcbiAgICAgIGNvbnRlbnQgKz0gYHwgRmlsZSB8IFR5cGUgfFxcbmBcbiAgICAgIGNvbnRlbnQgKz0gYHwgLS0tLSB8IC0tLS0gfFxcbmBcblxuICAgICAgZm9yIChjb25zdCBhY3Rpdml0eSBvZiBub0NvdXJzZSkge1xuICAgICAgICBjb250ZW50ICs9IGB8ICR7YWN0aXZpdHkuZmlsZX0gfCAke2FjdGl2aXR5LnR5cGV9IHxcXG5gXG4gICAgICB9XG4gICAgICBjb250ZW50ICs9IGBcXG5gXG4gICAgfVxuXG4gICAgcmV0dXJuIGNvbnRlbnRcbiAgfVxuXG4gIGFzeW5jIGNyZWF0ZURhaWx5U3VtbWFyeUZpbGUoZGF0ZT86IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB0YXJnZXREYXRlID0gZGF0ZSB8fCBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc3BsaXQoXCJUXCIpWzBdXG4gICAgICBjb25zdCBzdW1tYXJ5Q29udGVudCA9IGF3YWl0IHRoaXMuZ2VuZXJhdGVEYWlseVN1bW1hcnkodGFyZ2V0RGF0ZSlcblxuICAgICAgLy8gQ3JlYXRlIHRoZSBzdW1tYXJ5IGZpbGVcbiAgICAgIGNvbnN0IGZpbGVOYW1lID0gYCR7dGFyZ2V0RGF0ZX0gLSBBY2FkZW1pYyBTdW1tYXJ5Lm1kYFxuICAgICAgY29uc3QgZmlsZVBhdGggPSBgRGFpbHkvJHtmaWxlTmFtZX1gXG5cbiAgICAgIHRyeSB7XG4gICAgICAgIGF3YWl0IHRoaXMuYXBwLnZhdWx0LmNyZWF0ZShmaWxlUGF0aCwgc3VtbWFyeUNvbnRlbnQpXG4gICAgICAgIGNvbnNvbGUubG9nKGBDcmVhdGVkIGRhaWx5IHN1bW1hcnkgZmlsZTogJHtmaWxlUGF0aH1gKVxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgLy8gRmlsZSBtaWdodCBhbHJlYWR5IGV4aXN0LCB0cnkgdG8gdXBkYXRlIGl0XG4gICAgICAgIGNvbnN0IGV4aXN0aW5nRmlsZSA9IHRoaXMuYXBwLnZhdWx0LmdldEFic3RyYWN0RmlsZUJ5UGF0aChmaWxlUGF0aClcbiAgICAgICAgaWYgKGV4aXN0aW5nRmlsZSAmJiBleGlzdGluZ0ZpbGUgaW5zdGFuY2VvZiBURmlsZSkge1xuICAgICAgICAgIGF3YWl0IHRoaXMuYXBwLnZhdWx0Lm1vZGlmeShleGlzdGluZ0ZpbGUsIHN1bW1hcnlDb250ZW50KVxuICAgICAgICAgIGNvbnNvbGUubG9nKGBVcGRhdGVkIGRhaWx5IHN1bW1hcnkgZmlsZTogJHtmaWxlUGF0aH1gKVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIGNyZWF0aW5nIGRhaWx5IHN1bW1hcnkgZm9yICR7ZGF0ZX06YCwgZXJyb3IpXG4gICAgICB0aHJvdyBlcnJvclxuICAgIH1cbiAgfVxufVxuIiwgImltcG9ydCB7IEFwcCwgTW9kYWwsIFNldHRpbmcsIFRleHRBcmVhQ29tcG9uZW50IH0gZnJvbSBcIm9ic2lkaWFuXCI7XG5cbmludGVyZmFjZSBBc3NpZ25tZW50IHtcbiAgbmFtZTogc3RyaW5nO1xuICBkdWVEYXRlOiBzdHJpbmc7XG4gIHR5cGU6IHN0cmluZztcbiAgcG9pbnRzOiBzdHJpbmc7XG4gIGRlc2NyaXB0aW9uOiBzdHJpbmc7XG59XG5cbmV4cG9ydCBjbGFzcyBBc3NpZ25tZW50c01vZGFsIGV4dGVuZHMgTW9kYWwge1xuICBhc3NpZ25tZW50czogQXNzaWdubWVudFtdO1xuICBjb3Vyc2VOYW1lOiBzdHJpbmc7XG4gIGNvdXJzZUlkOiBzdHJpbmc7XG4gIG9uU3VibWl0OiAoYXNzaWdubWVudHM6IEFzc2lnbm1lbnRbXSwgY291cnNlTmFtZTogc3RyaW5nLCBjb3Vyc2VJZDogc3RyaW5nKSA9PiB2b2lkO1xuXG4gIGNvbnN0cnVjdG9yKFxuICAgIGFwcDogQXBwLFxuICAgIGNvdXJzZU5hbWU6IHN0cmluZyxcbiAgICBjb3Vyc2VJZDogc3RyaW5nLFxuICAgIG9uU3VibWl0OiAoYXNzaWdubWVudHM6IEFzc2lnbm1lbnRbXSwgY291cnNlTmFtZTogc3RyaW5nLCBjb3Vyc2VJZDogc3RyaW5nKSA9PiB2b2lkXG4gICkge1xuICAgIHN1cGVyKGFwcCk7XG4gICAgdGhpcy5hc3NpZ25tZW50cyA9IFt7IG5hbWU6IFwiXCIsIGR1ZURhdGU6IFwiXCIsIHR5cGU6IFwiXCIsIHBvaW50czogXCJcIiwgZGVzY3JpcHRpb246IFwiXCIgfV07XG4gICAgdGhpcy5jb3Vyc2VOYW1lID0gY291cnNlTmFtZTtcbiAgICB0aGlzLmNvdXJzZUlkID0gY291cnNlSWQ7XG4gICAgdGhpcy5vblN1Ym1pdCA9IG9uU3VibWl0O1xuICB9XG5cbiAgb25PcGVuKCkge1xuICAgIGNvbnN0IHsgY29udGVudEVsIH0gPSB0aGlzO1xuICAgIGNvbnRlbnRFbC5lbXB0eSgpO1xuICAgIGNvbnRlbnRFbC5hZGRDbGFzcyhcInR1Y2tlcnMtdG9vbHMtYXNzaWdubWVudHMtbW9kYWxcIik7XG5cbiAgICBjb250ZW50RWwuY3JlYXRlRWwoXCJoMlwiLCB7IHRleHQ6IFwiQ3JlYXRlIE11bHRpcGxlIEFzc2lnbm1lbnRzXCIgfSk7XG5cbiAgICAvLyBDb3Vyc2UgaW5mb3JtYXRpb24gZGlzcGxheVxuICAgIG5ldyBTZXR0aW5nKGNvbnRlbnRFbClcbiAgICAgIC5zZXROYW1lKFwiQ291cnNlXCIpXG4gICAgICAuc2V0RGVzYyhgJHt0aGlzLmNvdXJzZU5hbWV9ICgke3RoaXMuY291cnNlSWR9KWApXG4gICAgICAuc2V0RGlzYWJsZWQodHJ1ZSk7XG5cbiAgICAvLyBDb250YWluZXIgZm9yIGFzc2lnbm1lbnQgbGlzdFxuICAgIGNvbnN0IGFzc2lnbm1lbnRzQ29udGFpbmVyID0gY29udGVudEVsLmNyZWF0ZURpdih7IGNsczogXCJhc3NpZ25tZW50cy1jb250YWluZXJcIiB9KTtcblxuICAgIC8vIEFkZCBmaXJzdCBhc3NpZ25tZW50XG4gICAgdGhpcy5hZGRBc3NpZ25tZW50U2VjdGlvbihhc3NpZ25tZW50c0NvbnRhaW5lciwgMCk7XG5cbiAgICAvLyBBZGQgYXNzaWdubWVudCBidXR0b25cbiAgICBuZXcgU2V0dGluZyhjb250ZW50RWwpXG4gICAgICAuYWRkQnV0dG9uKChidG4pID0+XG4gICAgICAgIGJ0blxuICAgICAgICAgIC5zZXRCdXR0b25UZXh0KFwiQWRkIEFzc2lnbm1lbnRcIilcbiAgICAgICAgICAuc2V0Q3RhKClcbiAgICAgICAgICAub25DbGljaygoKSA9PiB7XG4gICAgICAgICAgICBjb25zdCBuZXdJbmRleCA9IHRoaXMuYXNzaWdubWVudHMubGVuZ3RoO1xuICAgICAgICAgICAgdGhpcy5hc3NpZ25tZW50cy5wdXNoKHsgbmFtZTogXCJcIiwgZHVlRGF0ZTogXCJcIiwgdHlwZTogXCJcIiwgcG9pbnRzOiBcIlwiLCBkZXNjcmlwdGlvbjogXCJcIiB9KTtcbiAgICAgICAgICAgIHRoaXMuYWRkQXNzaWdubWVudFNlY3Rpb24oYXNzaWdubWVudHNDb250YWluZXIsIG5ld0luZGV4KTtcbiAgICAgICAgICB9KVxuICAgICAgKTtcblxuICAgIC8vIFN1Ym1pdCBidXR0b25cbiAgICBuZXcgU2V0dGluZyhjb250ZW50RWwpXG4gICAgICAuYWRkQnV0dG9uKChidG4pID0+XG4gICAgICAgIGJ0blxuICAgICAgICAgIC5zZXRCdXR0b25UZXh0KFwiQ3JlYXRlIEFzc2lnbm1lbnRzXCIpXG4gICAgICAgICAgLnNldEN0YSgpXG4gICAgICAgICAgLm9uQ2xpY2soKCkgPT4ge1xuICAgICAgICAgICAgLy8gRmlsdGVyIG91dCBlbXB0eSBhc3NpZ25tZW50c1xuICAgICAgICAgICAgY29uc3QgdmFsaWRBc3NpZ25tZW50cyA9IHRoaXMuYXNzaWdubWVudHMuZmlsdGVyKFxuICAgICAgICAgICAgICAoYSkgPT4gYS5uYW1lLnRyaW0oKSAhPT0gXCJcIiB8fCBhLmR1ZURhdGUudHJpbSgpICE9PSBcIlwiXG4gICAgICAgICAgICApO1xuICAgICAgICAgICAgdGhpcy5vblN1Ym1pdCh2YWxpZEFzc2lnbm1lbnRzLCB0aGlzLmNvdXJzZU5hbWUsIHRoaXMuY291cnNlSWQpO1xuICAgICAgICAgICAgdGhpcy5jbG9zZSgpO1xuICAgICAgICAgIH0pXG4gICAgICApO1xuICB9XG5cbiAgYWRkQXNzaWdubWVudFNlY3Rpb24oY29udGFpbmVyOiBIVE1MRWxlbWVudCwgaW5kZXg6IG51bWJlcikge1xuICAgIGNvbnN0IHNlY3Rpb24gPSBjb250YWluZXIuY3JlYXRlRGl2KHsgY2xzOiBcImFzc2lnbm1lbnQtc2VjdGlvblwiIH0pO1xuICAgIHNlY3Rpb24uY3JlYXRlRWwoXCJoM1wiLCB7IHRleHQ6IGBBc3NpZ25tZW50ICMke2luZGV4ICsgMX1gIH0pO1xuXG4gICAgbmV3IFNldHRpbmcoc2VjdGlvbilcbiAgICAgIC5zZXROYW1lKFwiQXNzaWdubWVudCBOYW1lXCIpXG4gICAgICAuYWRkVGV4dCgodGV4dCkgPT5cbiAgICAgICAgdGV4dFxuICAgICAgICAgIC5zZXRQbGFjZWhvbGRlcihcIkVudGVyIGFzc2lnbm1lbnQgbmFtZVwiKVxuICAgICAgICAgIC5zZXRWYWx1ZSh0aGlzLmFzc2lnbm1lbnRzW2luZGV4XS5uYW1lKVxuICAgICAgICAgIC5vbkNoYW5nZSgodmFsdWUpID0+IHtcbiAgICAgICAgICAgIHRoaXMuYXNzaWdubWVudHNbaW5kZXhdLm5hbWUgPSB2YWx1ZTtcbiAgICAgICAgICB9KVxuICAgICAgKTtcblxuICAgIG5ldyBTZXR0aW5nKHNlY3Rpb24pXG4gICAgICAuc2V0TmFtZShcIkR1ZSBEYXRlXCIpXG4gICAgICAuc2V0RGVzYyhcIkZvcm1hdDogWVlZWS1NTS1ERFwiKVxuICAgICAgLmFkZFRleHQoKHRleHQpID0+XG4gICAgICAgIHRleHRcbiAgICAgICAgICAuc2V0UGxhY2Vob2xkZXIoXCIyMDI0LTAxLTE1XCIpXG4gICAgICAgICAgLnNldFZhbHVlKHRoaXMuYXNzaWdubWVudHNbaW5kZXhdLmR1ZURhdGUpXG4gICAgICAgICAgLm9uQ2hhbmdlKCh2YWx1ZSkgPT4ge1xuICAgICAgICAgICAgdGhpcy5hc3NpZ25tZW50c1tpbmRleF0uZHVlRGF0ZSA9IHZhbHVlO1xuICAgICAgICAgIH0pXG4gICAgICApO1xuXG4gICAgbmV3IFNldHRpbmcoc2VjdGlvbilcbiAgICAgIC5zZXROYW1lKFwiQXNzaWdubWVudCBUeXBlXCIpXG4gICAgICAuYWRkVGV4dCgodGV4dCkgPT5cbiAgICAgICAgdGV4dFxuICAgICAgICAgIC5zZXRQbGFjZWhvbGRlcihcImUuZy4sIEhvbWV3b3JrLCBRdWl6LCBFeGFtXCIpXG4gICAgICAgICAgLnNldFZhbHVlKHRoaXMuYXNzaWdubWVudHNbaW5kZXhdLnR5cGUpXG4gICAgICAgICAgLm9uQ2hhbmdlKCh2YWx1ZSkgPT4ge1xuICAgICAgICAgICAgdGhpcy5hc3NpZ25tZW50c1tpbmRleF0udHlwZSA9IHZhbHVlO1xuICAgICAgICAgIH0pXG4gICAgICApO1xuXG4gICAgbmV3IFNldHRpbmcoc2VjdGlvbilcbiAgICAgIC5zZXROYW1lKFwiUG9pbnRzXCIpXG4gICAgICAuYWRkVGV4dCgodGV4dCkgPT5cbiAgICAgICAgdGV4dFxuICAgICAgICAgIC5zZXRQbGFjZWhvbGRlcihcImUuZy4sIDEwMFwiKVxuICAgICAgICAgIC5zZXRWYWx1ZSh0aGlzLmFzc2lnbm1lbnRzW2luZGV4XS5wb2ludHMpXG4gICAgICAgICAgLm9uQ2hhbmdlKCh2YWx1ZSkgPT4ge1xuICAgICAgICAgICAgdGhpcy5hc3NpZ25tZW50c1tpbmRleF0ucG9pbnRzID0gdmFsdWU7XG4gICAgICAgICAgfSlcbiAgICAgICk7XG5cbiAgICBuZXcgU2V0dGluZyhzZWN0aW9uKVxuICAgICAgLnNldE5hbWUoXCJEZXNjcmlwdGlvblwiKVxuICAgICAgLmFkZFRleHRBcmVhKCh0ZXh0KSA9PlxuICAgICAgICB0ZXh0XG4gICAgICAgICAgLnNldFBsYWNlaG9sZGVyKFwiRW50ZXIgYXNzaWdubWVudCBkZXNjcmlwdGlvblwiKVxuICAgICAgICAgIC5zZXRWYWx1ZSh0aGlzLmFzc2lnbm1lbnRzW2luZGV4XS5kZXNjcmlwdGlvbilcbiAgICAgICAgICAub25DaGFuZ2UoKHZhbHVlKSA9PiB7XG4gICAgICAgICAgICB0aGlzLmFzc2lnbm1lbnRzW2luZGV4XS5kZXNjcmlwdGlvbiA9IHZhbHVlO1xuICAgICAgICAgIH0pXG4gICAgICApO1xuXG4gICAgLy8gQWRkIHJlbW92ZSBidXR0b24gaWYgdGhlcmUncyBtb3JlIHRoYW4gb25lIGFzc2lnbm1lbnRcbiAgICBpZiAodGhpcy5hc3NpZ25tZW50cy5sZW5ndGggPiAxKSB7XG4gICAgICBuZXcgU2V0dGluZyhzZWN0aW9uKVxuICAgICAgICAuYWRkQnV0dG9uKChidG4pID0+XG4gICAgICAgICAgYnRuXG4gICAgICAgICAgICAuc2V0QnV0dG9uVGV4dChcIlJlbW92ZVwiKVxuICAgICAgICAgICAgLm9uQ2xpY2soKCkgPT4ge1xuICAgICAgICAgICAgICB0aGlzLmFzc2lnbm1lbnRzLnNwbGljZShpbmRleCwgMSk7XG4gICAgICAgICAgICAgIHNlY3Rpb24ucmVtb3ZlKCk7XG4gICAgICAgICAgICAgIHRoaXMucmVudW1iZXJBc3NpZ25tZW50cygpO1xuICAgICAgICAgICAgfSlcbiAgICAgICAgKTtcbiAgICB9XG4gIH1cblxuICByZW51bWJlckFzc2lnbm1lbnRzKCkge1xuICAgIGNvbnN0IHNlY3Rpb25zID0gdGhpcy5jb250ZW50RWwucXVlcnlTZWxlY3RvckFsbChcIi5hc3NpZ25tZW50LXNlY3Rpb25cIik7XG4gICAgc2VjdGlvbnMuZm9yRWFjaCgoc2VjdGlvbiwgaW5kZXgpID0+IHtcbiAgICAgIGNvbnN0IGhlYWRlciA9IHNlY3Rpb24ucXVlcnlTZWxlY3RvcihcImgzXCIpO1xuICAgICAgaWYgKGhlYWRlcikge1xuICAgICAgICBoZWFkZXIudGV4dENvbnRlbnQgPSBgQXNzaWdubWVudCAjJHtpbmRleCArIDF9YDtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuXG4gIG9uQ2xvc2UoKSB7XG4gICAgY29uc3QgeyBjb250ZW50RWwgfSA9IHRoaXM7XG4gICAgY29udGVudEVsLmVtcHR5KCk7XG4gIH1cbn0iXSwKICAibWFwcGluZ3MiOiAiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUFBQSxtQkFBdUI7OztBQ0F2QixzQkFBK0M7OztBQ2dCeEMsU0FBUyxRQUFRLE1BQXNCO0FBQzVDLFNBQU8sS0FDSixZQUFZLEVBQ1osS0FBSyxFQUNMLFVBQVUsS0FBSyxFQUNmLFFBQVEsb0JBQW9CLEVBQUUsRUFDOUIsUUFBUSxpQkFBaUIsRUFBRSxFQUMzQixRQUFRLFdBQVcsR0FBRyxFQUN0QixRQUFRLFlBQVksRUFBRTtBQUMzQjtBQWVPLFNBQVMsYUFBYSxZQUE2QjtBQUN4RCxRQUFNLFFBQVE7QUFDZCxNQUFJLENBQUMsV0FBVyxNQUFNLEtBQUs7QUFBRyxXQUFPO0FBRXJDLFFBQU0sT0FBTyxJQUFJLEtBQUssVUFBVTtBQUNoQyxRQUFNLFlBQVksS0FBSyxRQUFRO0FBRS9CLE1BQUksT0FBTyxjQUFjLFlBQVksTUFBTSxTQUFTO0FBQUcsV0FBTztBQUU5RCxTQUFPLGVBQWUsS0FBSyxZQUFZLEVBQUUsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUN2RDs7O0FEbkNPLElBQU0sbUJBQXlDO0FBQUEsRUFDcEQsZUFBZTtBQUFBLEVBQ2YsbUJBQW1CLElBQUksS0FBSyxFQUFFLFlBQVksRUFBRSxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsRUFDeEQsaUJBQWlCLElBQUksS0FBSyxJQUFJLEtBQUssRUFBRSxTQUFTLElBQUksS0FBSyxFQUFFLFNBQVMsSUFBSSxDQUFDLENBQUMsRUFBRSxZQUFZLEVBQUUsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLEVBQ3BHLFlBQVk7QUFBQSxFQUNaLG9CQUFvQjtBQUFBLEVBQ3BCLGdCQUFnQjtBQUFBLEVBQ2hCLHFCQUFxQjtBQUFBLEVBQ3JCLGdCQUFnQjtBQUNsQjtBQUVPLElBQU0seUJBQU4sY0FBcUMsaUNBQWlCO0FBQUEsRUFHM0QsWUFBWSxLQUFVLFFBQTRCO0FBQ2hELFVBQU0sS0FBSyxNQUFNO0FBQ2pCLFNBQUssU0FBUztBQUFBLEVBQ2hCO0FBQUEsRUFFQSxVQUFnQjtBQUNkLFVBQU0sRUFBRSxZQUFZLElBQUk7QUFFeEIsZ0JBQVksTUFBTTtBQUVsQixnQkFBWSxTQUFTLE1BQU0sRUFBRSxNQUFNLHlCQUF5QixDQUFDO0FBRTdELFFBQUksd0JBQVEsV0FBVyxFQUNwQixRQUFRLGdCQUFnQixFQUN4QixRQUFRLGdEQUFnRCxFQUN4RCxRQUFRLFVBQVEsS0FDZCxlQUFlLEdBQUcsRUFDbEIsU0FBUyxLQUFLLE9BQU8sU0FBUyxhQUFhLEVBQzNDLFNBQVMsQ0FBTyxVQUFVO0FBQ3pCLFdBQUssT0FBTyxTQUFTLGdCQUFnQjtBQUNyQyxZQUFNLEtBQUssT0FBTyxhQUFhO0FBQUEsSUFDakMsRUFBQyxDQUFDO0FBRU4sVUFBTSxtQkFBbUIsSUFBSSx3QkFBUSxXQUFXLEVBQzdDLFFBQVEscUJBQXFCLEVBQzdCLFFBQVEscUNBQXFDLEVBQzdDLFFBQVEsVUFBUSxLQUNkLGVBQWUsWUFBWSxFQUMzQixTQUFTLEtBQUssT0FBTyxTQUFTLGlCQUFpQixFQUMvQyxTQUFTLENBQU8sVUFBVTtBQUN6QixVQUFJLFNBQVMsQ0FBQyxhQUFhLEtBQUssR0FBRztBQUNqQyx5QkFBaUIsUUFBUSwyREFBMkQ7QUFBQSxNQUN0RixPQUFPO0FBQ0wseUJBQWlCLFFBQVEscUNBQXFDO0FBQUEsTUFDaEU7QUFDQSxXQUFLLE9BQU8sU0FBUyxvQkFBb0I7QUFDekMsWUFBTSxLQUFLLE9BQU8sYUFBYTtBQUFBLElBQ2pDLEVBQUMsQ0FBQztBQUVOLFVBQU0saUJBQWlCLElBQUksd0JBQVEsV0FBVyxFQUMzQyxRQUFRLG1CQUFtQixFQUMzQixRQUFRLG1DQUFtQyxFQUMzQyxRQUFRLFVBQVEsS0FDZCxlQUFlLFlBQVksRUFDM0IsU0FBUyxLQUFLLE9BQU8sU0FBUyxlQUFlLEVBQzdDLFNBQVMsQ0FBTyxVQUFVO0FBQ3pCLFVBQUksU0FBUyxDQUFDLGFBQWEsS0FBSyxHQUFHO0FBQ2pDLHVCQUFlLFFBQVEseURBQXlEO0FBQUEsTUFDbEYsT0FBTztBQUNMLHVCQUFlLFFBQVEsbUNBQW1DO0FBQUEsTUFDNUQ7QUFDQSxXQUFLLE9BQU8sU0FBUyxrQkFBa0I7QUFDdkMsWUFBTSxLQUFLLE9BQU8sYUFBYTtBQUFBLElBQ2pDLEVBQUMsQ0FBQztBQUVOLFFBQUksd0JBQVEsV0FBVyxFQUNwQixRQUFRLGFBQWEsRUFDckIsUUFBUSwwQkFBMEIsRUFDbEMsUUFBUSxVQUFRLEtBQ2QsZUFBZSxZQUFZLEVBQzNCLFNBQVMsS0FBSyxPQUFPLFNBQVMsVUFBVSxFQUN4QyxTQUFTLENBQU8sVUFBVTtBQUN6QixXQUFLLE9BQU8sU0FBUyxhQUFhO0FBQ2xDLFlBQU0sS0FBSyxPQUFPLGFBQWE7QUFBQSxJQUNqQyxFQUFDLENBQUM7QUFFTixRQUFJLHdCQUFRLFdBQVcsRUFDcEIsUUFBUSxxQkFBcUIsRUFDN0IsUUFBUSxtQ0FBbUMsRUFDM0MsUUFBUSxVQUFRLEtBQ2QsZUFBZSxHQUFHLEVBQ2xCLFNBQVMsS0FBSyxPQUFPLFNBQVMsa0JBQWtCLEVBQ2hELFNBQVMsQ0FBTyxVQUFVO0FBQ3pCLFdBQUssT0FBTyxTQUFTLHFCQUFxQjtBQUMxQyxZQUFNLEtBQUssT0FBTyxhQUFhO0FBQUEsSUFDakMsRUFBQyxDQUFDO0FBRU4sUUFBSSx3QkFBUSxXQUFXLEVBQ3BCLFFBQVEsaUJBQWlCLEVBQ3pCLFFBQVEsNkVBQTZFLEVBQ3JGLFFBQVEsVUFBUSxLQUNkLGVBQWUsZUFBZSxFQUM5QixTQUFTLEtBQUssT0FBTyxTQUFTLGNBQWMsRUFDNUMsU0FBUyxDQUFPLFVBQVU7QUFDekIsV0FBSyxPQUFPLFNBQVMsaUJBQWlCO0FBQ3RDLFlBQU0sS0FBSyxPQUFPLGFBQWE7QUFBQSxJQUNqQyxFQUFDLENBQUM7QUFFTixRQUFJLHdCQUFRLFdBQVcsRUFDcEIsUUFBUSx1QkFBdUIsRUFDL0IsUUFBUSxpRkFBaUYsRUFDekYsVUFBVSxZQUFVLE9BQ2xCLFNBQVMsS0FBSyxPQUFPLFNBQVMsbUJBQW1CLEVBQ2pELFNBQVMsQ0FBTyxVQUFVO0FBQ3pCLFdBQUssT0FBTyxTQUFTLHNCQUFzQjtBQUMzQyxZQUFNLEtBQUssT0FBTyxhQUFhO0FBQUEsSUFDakMsRUFBQyxDQUFDO0FBRU4sUUFBSSx3QkFBUSxXQUFXLEVBQ3BCLFFBQVEseUJBQXlCLEVBQ2pDLFFBQVEseURBQXlELEVBQ2pFLFFBQVEsVUFBUSxLQUNkLGVBQWUsZ0NBQWdDLEVBQy9DLFNBQVMsS0FBSyxPQUFPLFNBQVMsY0FBYyxFQUM1QyxTQUFTLENBQU8sVUFBVTtBQUN6QixXQUFLLE9BQU8sU0FBUyxpQkFBaUI7QUFDdEMsWUFBTSxLQUFLLE9BQU8sYUFBYTtBQUFBLElBQ2pDLEVBQUMsQ0FBQztBQUFBLEVBQ1I7QUFDRjs7O0FFMUlBLElBQUFDLG1CQUE0QjtBQVVyQixJQUFNLGtCQUFOLE1BQXNCO0FBQUEsRUFLM0IsWUFBWSxLQUFVLFVBQWdDO0FBQ3BELFNBQUssTUFBTTtBQUNYLFNBQUssV0FBVztBQUNoQixTQUFLLFdBQVc7QUFBQSxNQUNkLFNBQVM7QUFBQSxNQUNULFdBQVc7QUFBQSxRQUNULHFDQUFxQztBQUFBLFFBQ3JDLDJCQUEyQjtBQUFBLFFBQzNCLDRCQUE0QjtBQUFBLFFBQzVCLDhCQUE4QjtBQUFBLFFBQzlCLG9DQUFvQztBQUFBLFFBQ3BDLHVCQUF1QjtBQUFBLFFBQ3ZCLGlDQUFpQztBQUFBLFFBQ2pDLCtCQUErQjtBQUFBLE1BQ2pDO0FBQUEsTUFDQSxnQkFBZ0I7QUFBQSxNQUNoQixlQUFlO0FBQUEsSUFDakI7QUFBQSxFQUNGO0FBQUEsRUFFTSxtQkFBbUI7QUFBQTtBQUN2QixVQUFJO0FBRUYsY0FBTSxrQkFBa0IsS0FBSyxtQkFBbUI7QUFDaEQsWUFBSSxDQUFDLGlCQUFpQjtBQUNwQixjQUFJO0FBQUEsWUFDRjtBQUFBLFVBQ0Y7QUFDQSxrQkFBUTtBQUFBLFlBQ047QUFBQSxVQUNGO0FBQ0E7QUFBQSxRQUNGO0FBRUEsY0FBTSxxQkFBcUIsS0FBSyxzQkFBc0IsZUFBZTtBQUNyRSxZQUFJLENBQUMsb0JBQW9CO0FBQ3ZCLGNBQUk7QUFBQSxZQUNGO0FBQUEsVUFDRjtBQUNBLGtCQUFRO0FBQUEsWUFDTjtBQUFBLFVBQ0Y7QUFDQTtBQUFBLFFBQ0Y7QUFFQSxjQUFNLG1CQUFtQixHQUFHLHNCQUFzQixLQUFLLFNBQVM7QUFHaEUsWUFBSTtBQUNGLGdCQUFNLEtBQUssSUFBSSxNQUFNLGFBQWEsZ0JBQWdCO0FBQ2xELGtCQUFRLElBQUksNEJBQTRCLGtCQUFrQjtBQUFBLFFBQzVELFNBQVMsR0FBUDtBQUVBLGtCQUFRO0FBQUEsWUFDTiw4Q0FBOEM7QUFBQSxVQUNoRDtBQUFBLFFBQ0Y7QUFHQSxjQUFNLFVBQVU7QUFBQSxVQUNkO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxRQUNGO0FBQ0EsbUJBQVcsVUFBVSxTQUFTO0FBQzVCLGNBQUk7QUFDRixrQkFBTSxVQUFVLEdBQUcsb0JBQW9CO0FBQ3ZDLGtCQUFNLEtBQUssSUFBSSxNQUFNLGFBQWEsT0FBTztBQUN6QyxvQkFBUSxJQUFJLHlCQUF5QixTQUFTO0FBQUEsVUFDaEQsU0FBUyxHQUFQO0FBRUEsb0JBQVE7QUFBQSxjQUNOLGdDQUFnQyxvQkFBb0I7QUFBQSxZQUN0RDtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBR0EsY0FBTSxLQUFLLHVCQUF1QixnQkFBZ0I7QUFDbEQsY0FBTSxLQUFLLHVCQUF1QixnQkFBZ0I7QUFDbEQsY0FBTSxLQUFLLHdCQUF3QixnQkFBZ0I7QUFDbkQsY0FBTSxLQUFLLDJCQUEyQixnQkFBZ0I7QUFDdEQsY0FBTSxLQUFLLHNCQUFzQixnQkFBZ0I7QUFDakQsY0FBTSxLQUFLLHdCQUF3QixnQkFBZ0I7QUFHbkQsY0FBTSxLQUFLLGFBQWEsZ0JBQWdCO0FBR3hDLGNBQU0sS0FBSyx1QkFBdUIsZ0JBQWdCO0FBRWxELFlBQUksd0JBQU8saURBQWlEO0FBQzVELGdCQUFRLElBQUksZ0RBQWdEO0FBQUEsTUFDOUQsU0FBUyxPQUFQO0FBQ0EsZ0JBQVEsTUFBTSwrQkFBK0IsS0FBSztBQUNsRCxZQUFJLHdCQUFPLHdEQUF3RDtBQUFBLE1BQ3JFO0FBQUEsSUFDRjtBQUFBO0FBQUEsRUFFUSxxQkFBMEI7QUFFaEMsVUFBTSxnQkFBZ0I7QUFBQSxNQUNuQixLQUFLLElBQVksUUFBUSxRQUFRLG9CQUFvQjtBQUFBLE1BQ3JELEtBQUssSUFBWSxRQUFRLFFBQVEsV0FBVztBQUFBLE1BQzVDLEtBQUssSUFBWSxRQUFRLFVBQVUsb0JBQW9CO0FBQUEsTUFDdkQsS0FBSyxJQUFZLFFBQVEsVUFBVSxXQUFXO0FBQUEsSUFDakQ7QUFFQSxlQUFXLFFBQVEsZUFBZTtBQUNoQyxVQUFJLE1BQU07QUFDUixlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFFQSxXQUFPO0FBQUEsRUFDVDtBQUFBLEVBRVEsc0JBQXNCLGlCQUFxQztBQUNqRSxVQUFNLFdBQVcsZ0JBQWdCO0FBRWpDLFFBQUksQ0FBQyxVQUFVO0FBQ2IsY0FBUSxNQUFNLGtDQUFrQztBQUNoRCxhQUFPO0FBQUEsSUFDVDtBQUdBLFVBQU0sZ0JBQWdCO0FBQUEsTUFDcEIsU0FBUztBQUFBO0FBQUEsTUFDVCxTQUFTO0FBQUEsTUFDVCxTQUFTO0FBQUEsTUFDVCxTQUFTO0FBQUEsTUFDVCxTQUFTO0FBQUEsSUFDWDtBQUVBLGVBQVcsUUFBUSxlQUFlO0FBQ2hDLFVBQUksUUFBUSxPQUFPLFNBQVMsVUFBVTtBQUNwQyxlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFFQSxZQUFRO0FBQUEsTUFDTjtBQUFBLE1BQ0EsT0FBTyxLQUFLLFFBQVE7QUFBQSxJQUN0QjtBQUNBLFdBQU87QUFBQSxFQUNUO0FBQUEsRUFFTSx1QkFBdUIsVUFBa0I7QUFBQTtBQUM3QyxZQUFNLGVBQWUsR0FBRztBQUN4QixZQUFNLGtCQUFrQixLQUFLLFVBQVUsS0FBSyxVQUFVLE1BQU0sQ0FBQztBQUU3RCxVQUFJO0FBRUYsY0FBTSxtQkFDSixLQUFLLElBQUksTUFBTSxzQkFBc0IsWUFBWTtBQUNuRCxZQUFJLGtCQUFrQjtBQUVwQixnQkFBTSxPQUFPO0FBQ2IsZ0JBQU0sS0FBSyxJQUFJLE1BQU0sT0FBTyxNQUFNLGVBQWU7QUFDakQsa0JBQVEsSUFBSSw4QkFBOEIsY0FBYztBQUN4RDtBQUFBLFFBQ0Y7QUFHQSxjQUFNLEtBQUssSUFBSSxNQUFNLE9BQU8sY0FBYyxlQUFlO0FBQ3pELGdCQUFRLElBQUksOEJBQThCLGNBQWM7QUFBQSxNQUMxRCxTQUFTLEdBQVA7QUFDQSxZQUFJLHdCQUFPLG9DQUFvQyxjQUFjO0FBQzdELGdCQUFRLE1BQU0sb0NBQW9DLGlCQUFpQixDQUFDO0FBQUEsTUFDdEU7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVNLDBCQUE0QztBQUFBO0FBR2hELGNBQVEsSUFBSSwrQkFBK0I7QUFDM0MsYUFBTztBQUFBLElBQ1Q7QUFBQTtBQUFBLEVBRU0sa0JBQWtCO0FBQUE7QUFDdEIsVUFBSTtBQUVGLGdCQUFRLElBQUksb0JBQW9CO0FBR2hDLGNBQU0sa0JBQWtCLEtBQUssbUJBQW1CO0FBQ2hELFlBQUksQ0FBQyxpQkFBaUI7QUFDcEIsY0FBSTtBQUFBLFlBQ0Y7QUFBQSxVQUNGO0FBQ0Esa0JBQVE7QUFBQSxZQUNOO0FBQUEsVUFDRjtBQUNBO0FBQUEsUUFDRjtBQUVBLGNBQU0scUJBQXFCLEtBQUssc0JBQXNCLGVBQWU7QUFDckUsWUFBSSxDQUFDLG9CQUFvQjtBQUN2QixjQUFJO0FBQUEsWUFDRjtBQUFBLFVBQ0Y7QUFDQSxrQkFBUTtBQUFBLFlBQ047QUFBQSxVQUNGO0FBQ0E7QUFBQSxRQUNGO0FBRUEsY0FBTSxtQkFBbUIsR0FBRyxzQkFBc0IsS0FBSyxTQUFTO0FBR2hFLGNBQU0sS0FBSyx1QkFBdUIsZ0JBQWdCO0FBQ2xELGNBQU0sS0FBSyx1QkFBdUIsZ0JBQWdCO0FBQ2xELGNBQU0sS0FBSyx3QkFBd0IsZ0JBQWdCO0FBQ25ELGNBQU0sS0FBSywyQkFBMkIsZ0JBQWdCO0FBQ3RELGNBQU0sS0FBSyxzQkFBc0IsZ0JBQWdCO0FBQ2pELGNBQU0sS0FBSyx3QkFBd0IsZ0JBQWdCO0FBR25ELGNBQU0sS0FBSyxhQUFhLGdCQUFnQjtBQUd4QyxjQUFNLEtBQUssdUJBQXVCLGdCQUFnQjtBQUVsRCxZQUFJLHdCQUFPLCtDQUErQztBQUMxRCxnQkFBUSxJQUFJLDhDQUE4QztBQUFBLE1BQzVELFNBQVMsT0FBUDtBQUNBLGdCQUFRLE1BQU0sNkJBQTZCLEtBQUs7QUFDaEQsWUFBSSx3QkFBTyxzREFBc0Q7QUFBQSxNQUNuRTtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRU0sdUJBQXVCLFVBQWtCO0FBQUE7QUFDN0MsWUFBTSxhQUFhLEdBQUc7QUFHdEIsWUFBTSx5QkFBeUIsS0FBSywrQkFBK0I7QUFDbkUsWUFBTSxLQUFLO0FBQUEsUUFDVCxHQUFHO0FBQUEsUUFDSDtBQUFBLE1BQ0Y7QUFHQSxZQUFNLHNCQUFzQixLQUFLLDRCQUE0QjtBQUM3RCxZQUFNLEtBQUs7QUFBQSxRQUNULEdBQUc7QUFBQSxRQUNIO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRU0sdUJBQXVCLFVBQWtCO0FBQUE7QUFDN0MsWUFBTSxhQUFhLEdBQUc7QUFHdEIsWUFBTSxpQkFBaUIsS0FBSyx1QkFBdUI7QUFDbkQsWUFBTSxLQUFLO0FBQUEsUUFDVCxHQUFHO0FBQUEsUUFDSDtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVNLHdCQUF3QixVQUFrQjtBQUFBO0FBQzlDLFlBQU0sY0FBYyxHQUFHO0FBR3ZCLFlBQU0sa0JBQWtCLEtBQUssd0JBQXdCO0FBQ3JELFlBQU0sS0FBSztBQUFBLFFBQ1QsR0FBRztBQUFBLFFBQ0g7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBO0FBQUEsRUFFTSwyQkFBMkIsVUFBa0I7QUFBQTtBQUNqRCxZQUFNLGlCQUFpQixHQUFHO0FBRzFCLFlBQU0scUJBQXFCLEtBQUssMkJBQTJCO0FBQzNELFlBQU0sS0FBSztBQUFBLFFBQ1QsR0FBRztBQUFBLFFBQ0g7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBO0FBQUEsRUFFTSxzQkFBc0IsVUFBa0I7QUFBQTtBQUM1QyxZQUFNLFlBQVksR0FBRztBQUdyQixZQUFNLG9CQUFvQixLQUFLLDBCQUEwQjtBQUN6RCxZQUFNLEtBQUs7QUFBQSxRQUNULEdBQUc7QUFBQSxRQUNIO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRU0sd0JBQXdCLFVBQWtCO0FBQUE7QUFDOUMsWUFBTSxjQUFjLEdBQUc7QUFHdkIsWUFBTSxnQkFBZ0IsS0FBSywyQkFBMkI7QUFDdEQsWUFBTSxLQUFLO0FBQUEsUUFDVCxHQUFHO0FBQUEsUUFDSDtBQUFBLE1BQ0Y7QUFHQSxZQUFNLGtCQUFrQixLQUFLLHdCQUF3QjtBQUNyRCxZQUFNLEtBQUs7QUFBQSxRQUNULEdBQUc7QUFBQSxRQUNIO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRU0sa0JBQWtCLE1BQWMsU0FBaUI7QUFBQTtBQUNyRCxVQUFJO0FBRUYsY0FBTSxlQUFlLEtBQUssSUFBSSxNQUFNLHNCQUFzQixJQUFJO0FBQzlELFlBQUksY0FBYztBQUdoQixrQkFBUSxJQUFJLG9DQUFvQyxNQUFNO0FBQ3RELGdCQUFNLE9BQU87QUFDYixnQkFBTSxLQUFLLElBQUksTUFBTSxPQUFPLE1BQU0sT0FBTztBQUN6QztBQUFBLFFBQ0Y7QUFHQSxjQUFNLEtBQUssSUFBSSxNQUFNLE9BQU8sTUFBTSxPQUFPO0FBQ3pDLGdCQUFRLElBQUksMEJBQTBCLE1BQU07QUFBQSxNQUM5QyxTQUFTLEdBQVA7QUFDQSxZQUFJLHdCQUFPLGdDQUFnQyxNQUFNO0FBQ2pELGdCQUFRLE1BQU0sZ0NBQWdDLFNBQVMsQ0FBQztBQUFBLE1BQzFEO0FBQUEsSUFDRjtBQUFBO0FBQUEsRUFFQSxpQ0FBeUM7QUFDdkMsVUFBTSxtQkFBbUIsS0FBSyxTQUFTO0FBRXZDLFFBQUksa0JBQWtCO0FBQ3BCLGFBQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU9QLEtBQUssU0FBUztBQUFBO0FBQUE7QUFBQSxNQUdkLEtBQUssU0FBUyxXQUFXLFFBQVEsUUFBUSxHQUFHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQStDcEMsS0FBSyxTQUFTO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZDQW9DaUIsS0FBSyxTQUFTLGtCQUFrQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQ0FNeEMsS0FBSyxTQUFTLGtCQUFrQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQVNqRSxPQUFPO0FBQ0wsYUFBTztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBb0RDLEtBQUssU0FBUztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw2Q0FvQ2lCLEtBQUssU0FBUyxrQkFBa0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUNBTXhDLEtBQUssU0FBUyxrQkFBa0I7QUFBQTtBQUFBO0FBQUEsSUFHakU7QUFBQSxFQUNGO0FBQUEsRUFFQSw4QkFBc0M7QUFDcEMsV0FBTztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBbUJUO0FBQUEsRUFFQSx5QkFBaUM7QUFDL0IsV0FBTztBQUFBLEVBRVQsS0FBSyxTQUFTLHNCQUNWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQ0FNQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUNBOEIrQixLQUFLLFNBQVMsa0JBQWtCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZDQWV4QixLQUFLLFNBQVMsa0JBQWtCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUszRTtBQUFBLEVBRUEsMEJBQWtDO0FBQ2hDLFdBQU87QUFBQSxFQUVULEtBQUssU0FBUyxzQkFDVjtBQUFBO0FBQUE7QUFBQTtBQUFBLG9DQUtBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQWlDSjtBQUFBLEVBRUEsNkJBQXFDO0FBQ25DLFdBQU87QUFBQSxFQUVULEtBQUssU0FBUyxzQkFDVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUNBTUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUErQko7QUFBQSxFQUVBLDRCQUFvQztBQUNsQyxXQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQW1DVDtBQUFBLEVBRUEsNkJBQXFDO0FBQ25DLFdBQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBUVQ7QUFBQSxFQUVBLDBCQUFrQztBQUNoQyxXQUFPO0FBQUEsRUFDVDtBQUFBLEVBRU0sYUFBYSxVQUFrQjtBQUFBO0FBQ25DLFlBQU0sZ0JBQWdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQXlCdEIsWUFBTSxLQUFLLGtCQUFrQixHQUFHLHNCQUFzQixhQUFhO0FBQUEsSUFDckU7QUFBQTtBQUNGOzs7QUM5eUJBLElBQUFDLG1CQUFtQzs7O0FDRm5DLElBQUFDLG1CQUFvQztBQUU3QixJQUFNLGFBQU4sY0FBeUIsdUJBQU07QUFBQSxFQUlwQyxZQUFZLEtBQVUsVUFBMkM7QUFDL0QsVUFBTSxHQUFHO0FBQ1QsU0FBSyxXQUFXO0FBQUEsRUFDbEI7QUFBQSxFQUVBLFNBQVM7QUFDUCxVQUFNLEVBQUUsVUFBVSxJQUFJO0FBRXRCLGNBQVUsU0FBUyxNQUFNLEVBQUUsTUFBTSxjQUFjLENBQUM7QUFFaEQsUUFBSSx5QkFBUSxTQUFTLEVBQ2xCLFFBQVEsT0FBTyxFQUNmO0FBQUEsTUFBUSxDQUFDLFNBQ1IsS0FDRyxTQUFTLENBQUMsVUFBVTtBQUNuQixhQUFLLFNBQVM7QUFBQSxNQUNoQixDQUFDLEVBQ0EsUUFBUSxNQUFNO0FBQUEsSUFDbkI7QUFFRixRQUFJLHlCQUFRLFNBQVMsRUFDbEI7QUFBQSxNQUFVLENBQUMsUUFDVixJQUNHLGNBQWMsUUFBUSxFQUN0QixPQUFPLEVBQ1AsUUFBUSxNQUFNO0FBQ2IsYUFBSyxNQUFNO0FBQ1gsYUFBSyxTQUFTLEtBQUssVUFBVSxFQUFFO0FBQUEsTUFDakMsQ0FBQztBQUFBLElBQ0wsRUFDQztBQUFBLE1BQVUsQ0FBQyxRQUNWLElBQUksY0FBYyxRQUFRLEVBQUUsUUFBUSxNQUFNO0FBQ3hDLGFBQUssTUFBTTtBQUNYLGFBQUssU0FBUyxJQUFJO0FBQUEsTUFDcEIsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNKO0FBQUEsRUFFQSxVQUFVO0FBQ1IsVUFBTSxFQUFFLFVBQVUsSUFBSTtBQUN0QixjQUFVLE1BQU07QUFBQSxFQUNsQjtBQUNGO0FBRU8sSUFBTSxpQkFBTixjQUE2Qix1QkFBTTtBQUFBLEVBSXhDLFlBQVksS0FBVSxTQUFtQixVQUEyQztBQUNsRixVQUFNLEdBQUc7QUFDVCxTQUFLLFdBQVc7QUFHaEIsVUFBTSxrQkFBNkMsQ0FBQztBQUNwRCxZQUFRLFFBQVEsWUFBVTtBQUN4QixzQkFBZ0IsTUFBTSxJQUFJO0FBQUEsSUFDNUIsQ0FBQztBQUVELFNBQUssZUFBZSxlQUFlO0FBQUEsRUFDckM7QUFBQSxFQUVBLGVBQWUsU0FBb0M7QUFDakQsVUFBTSxFQUFFLFVBQVUsSUFBSTtBQUV0QixjQUFVLFNBQVMsTUFBTSxFQUFFLE1BQU0sZ0JBQWdCLENBQUM7QUFFbEQsUUFBSSxnQkFBZ0IsT0FBTyxLQUFLLE9BQU8sRUFBRSxDQUFDLEtBQUs7QUFFL0MsVUFBTSxXQUFXLFVBQVUsU0FBUyxRQUFRO0FBQzVDLFdBQU8sUUFBUSxPQUFPLEVBQUUsUUFBUSxDQUFDLENBQUMsS0FBSyxLQUFLLE1BQU07QUFDaEQsWUFBTSxTQUFTLFNBQVMsU0FBUyxVQUFVO0FBQUEsUUFDekMsT0FBTztBQUFBLFFBQ1AsTUFBTTtBQUFBLE1BQ1IsQ0FBQztBQUNELFVBQUksUUFBUSxlQUFlO0FBQ3pCLGVBQU8sV0FBVztBQUFBLE1BQ3BCO0FBQUEsSUFDRixDQUFDO0FBRUQsYUFBUyxpQkFBaUIsVUFBVSxDQUFDLFVBQVU7QUFDN0Msc0JBQWlCLE1BQU0sT0FBNkI7QUFDcEQsV0FBSyxTQUFTO0FBQUEsSUFDaEIsQ0FBQztBQUVELFFBQUkseUJBQVEsU0FBUyxFQUNsQjtBQUFBLE1BQVUsQ0FBQyxRQUNWLElBQ0csY0FBYyxRQUFRLEVBQ3RCLE9BQU8sRUFDUCxRQUFRLE1BQU07QUFDYixhQUFLLE1BQU07QUFDWCxhQUFLLFNBQVMsYUFBYTtBQUFBLE1BQzdCLENBQUM7QUFBQSxJQUNMLEVBQ0M7QUFBQSxNQUFVLENBQUMsUUFDVixJQUFJLGNBQWMsUUFBUSxFQUFFLFFBQVEsTUFBTTtBQUN4QyxhQUFLLE1BQU07QUFDWCxhQUFLLFNBQVMsSUFBSTtBQUFBLE1BQ3BCLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDSjtBQUFBLEVBRUEsU0FBUztBQUFBLEVBRVQ7QUFBQSxFQUVBLFVBQVU7QUFDUixVQUFNLEVBQUUsVUFBVSxJQUFJO0FBQ3RCLGNBQVUsTUFBTTtBQUFBLEVBQ2xCO0FBQ0Y7OztBRDVHTyxJQUFNLHVCQUFOLE1BQTJCO0FBQUEsRUFJaEMsWUFBWSxLQUFVLFVBQWdDO0FBQ3BELFNBQUssTUFBTTtBQUNYLFNBQUssV0FBVztBQUFBLEVBQ2xCO0FBQUEsRUFFTSx1QkFBdUI7QUFBQTtBQUMzQixVQUFJO0FBRUYsY0FBTSxnQkFBZ0IsTUFBTSxLQUFLLG9CQUFvQjtBQUVyRCxZQUFJLENBQUMsZUFBZTtBQUNsQixpQkFBTztBQUFBLFFBQ1Q7QUFHQSxjQUFNLGFBQWEsTUFBTSxLQUFLLDRCQUE0QixhQUFhO0FBR3ZFLGNBQU0sS0FBSyx5QkFBeUIsZUFBZSxVQUFVO0FBRzdELGNBQU0sS0FBSyx3QkFBd0IsVUFBVTtBQUU3QyxZQUFJLHdCQUFPLFdBQVcsY0FBYyxtQ0FBbUM7QUFDdkUsZ0JBQVE7QUFBQSxVQUNOLG1CQUFtQixjQUFjLGlCQUFpQjtBQUFBLFFBQ3BEO0FBRUEsZUFBTztBQUFBLE1BQ1QsU0FBUyxPQUFQO0FBQ0EsZ0JBQVEsTUFBTSwwQkFBMEIsS0FBSztBQUM3QyxZQUFJLHdCQUFPLDBCQUEwQixNQUFNLFNBQVM7QUFDcEQsZUFBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVjLHNCQUtKO0FBQUE7QUFyRFo7QUFzREksVUFBSTtBQUNGLGNBQU0sYUFBYSxNQUFNLEtBQUs7QUFBQSxVQUM1QjtBQUFBLFVBQ0E7QUFBQSxVQUNBLENBQUMsVUFBVSxNQUFNLEtBQUssRUFBRSxTQUFTO0FBQUEsVUFDakM7QUFBQSxRQUNGO0FBRUEsWUFBSSxDQUFDO0FBQVksaUJBQU87QUFFeEIsY0FBTSxlQUFlLE1BQU0sS0FBSztBQUFBLFVBQzlCO0FBQUEsVUFDQTtBQUFBLFVBQ0EsQ0FBQyxRQUFRLFVBQVUsVUFBVSxRQUFRO0FBQUEsUUFDdkM7QUFFQSxZQUFJLENBQUM7QUFBYyxpQkFBTztBQUUxQixjQUFNLGFBQWEsTUFBTSxLQUFLO0FBQUEsVUFDNUI7QUFBQSxVQUNBO0FBQUEsVUFDQSxDQUFDLFVBQVUsVUFBVSxLQUFLLE1BQU0sS0FBSyxDQUFDO0FBQUEsVUFDdEM7QUFBQSxRQUNGO0FBRUEsWUFBSSxDQUFDO0FBQVksaUJBQU87QUFFeEIsY0FBTSxhQUFXLGdCQUFXLE1BQU0sS0FBSyxFQUFFLENBQUMsTUFBekIsbUJBQTRCLFdBQVUsUUFBUSxVQUFVO0FBRXpFLGVBQU87QUFBQSxVQUNMO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsUUFDRjtBQUFBLE1BQ0YsU0FBUyxPQUFQO0FBQ0EsZ0JBQVEsTUFBTSx1Q0FBdUMsS0FBSztBQUMxRCxlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRWMscUJBQ1osT0FDQSxTQUNBLFdBQ0EsY0FDd0I7QUFBQTtBQUN4QixhQUFPLElBQUksUUFBUSxDQUFDLFlBQVk7QUFDOUIsY0FBTSxRQUFRLElBQUksV0FBVyxLQUFLLEtBQUssQ0FBQyxXQUFXO0FBQ2pELGNBQUksV0FBVyxNQUFNO0FBRW5CLG9CQUFRLElBQUk7QUFDWjtBQUFBLFVBQ0Y7QUFFQSxjQUFJLENBQUMsVUFBVSxNQUFNLEdBQUc7QUFDdEIsZ0JBQUksd0JBQU8sWUFBWTtBQUV2QixpQkFBSyxxQkFBcUIsT0FBTyxTQUFTLFdBQVcsWUFBWSxFQUM5RCxLQUFLLE9BQU87QUFDZjtBQUFBLFVBQ0Y7QUFFQSxrQkFBUSxPQUFPLEtBQUssQ0FBQztBQUFBLFFBQ3ZCLENBQUM7QUFHRCxjQUFNLFFBQVEsUUFBUSxLQUFLO0FBQzNCLGNBQU0sWUFBWSxNQUFNLFVBQVUsVUFBVTtBQUM1QyxrQkFBVSxRQUFRLE9BQU87QUFFekIsY0FBTSxLQUFLO0FBQUEsTUFDYixDQUFDO0FBQUEsSUFDSDtBQUFBO0FBQUEsRUFFYyxrQkFDWixPQUNBLFNBQ0EsU0FDd0I7QUFBQTtBQUN4QixhQUFPLElBQUksUUFBUSxDQUFDLFlBQVk7QUFDOUIsY0FBTSxRQUFRLElBQUksZUFBZSxLQUFLLEtBQUssU0FBUyxDQUFDLFdBQVc7QUFDOUQsY0FBSSxXQUFXLE1BQU07QUFFbkIsb0JBQVEsSUFBSTtBQUNaO0FBQUEsVUFDRjtBQUVBLGNBQUksUUFBUSxTQUFTLE1BQU0sR0FBRztBQUM1QixvQkFBUSxNQUFNO0FBQUEsVUFDaEIsT0FBTztBQUNMLGdCQUFJLHdCQUFPLHlCQUF5QixRQUFRLEtBQUssSUFBSSxHQUFHO0FBRXhELGlCQUFLLGtCQUFrQixPQUFPLFNBQVMsT0FBTyxFQUMzQyxLQUFLLE9BQU87QUFBQSxVQUNqQjtBQUFBLFFBQ0YsQ0FBQztBQUdELGNBQU0sUUFBUSxRQUFRLEtBQUs7QUFDM0IsY0FBTSxZQUFZLE1BQU0sVUFBVSxVQUFVO0FBQzVDLGtCQUFVLFFBQVEsT0FBTztBQUV6QixjQUFNLEtBQUs7QUFBQSxNQUNiLENBQUM7QUFBQSxJQUNIO0FBQUE7QUFBQSxFQUVjLDRCQUE0QixlQUt0QjtBQUFBO0FBQ2xCLFlBQU0sYUFBYSxHQUFHLGNBQWMsY0FBYyxjQUFjLGdCQUFnQixjQUFjO0FBRTlGLFVBQUk7QUFDRixjQUFNLEtBQUssSUFBSSxNQUFNLGFBQWEsVUFBVTtBQUM1QyxnQkFBUSxJQUFJLDBCQUEwQixZQUFZO0FBQ2xELGVBQU87QUFBQSxNQUNULFNBQVMsT0FBUDtBQUVBLGdCQUFRLElBQUksNENBQTRDLFlBQVk7QUFDcEUsZUFBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVjLHlCQUNaLGVBTUEsWUFDZTtBQUFBO0FBQ2YsWUFBTSxXQUFXLEdBQUcsY0FBYyxjQUFjO0FBQ2hELFlBQU0sVUFBVSxLQUFLLDhCQUE4QixhQUFhO0FBRWhFLFVBQUk7QUFDRixjQUFNLEtBQUssSUFBSSxNQUFNLE9BQU8sVUFBVSxPQUFPO0FBQzdDLGdCQUFRLElBQUksNEJBQTRCLFVBQVU7QUFBQSxNQUNwRCxTQUFTLE9BQVA7QUFDQSxnQkFBUSxNQUFNLG1DQUFtQyxPQUFPO0FBQ3hELGNBQU07QUFBQSxNQUNSO0FBQUEsSUFDRjtBQUFBO0FBQUEsRUFFYyx3QkFBd0IsWUFBbUM7QUFBQTtBQUN2RSxZQUFNLGtCQUFrQixHQUFHO0FBRTNCLFVBQUk7QUFDRixjQUFNLEtBQUssSUFBSSxNQUFNLGFBQWEsZUFBZTtBQUNqRCxnQkFBUSxJQUFJLCtCQUErQixpQkFBaUI7QUFBQSxNQUM5RCxTQUFTLE9BQVA7QUFFQSxnQkFBUSxJQUFJLHNDQUFzQyxpQkFBaUI7QUFBQSxNQUNyRTtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRVEsOEJBQThCLGVBSzNCO0FBRVQsVUFBTSxrQkFBa0IsSUFBSSxnQkFBZ0IsS0FBSyxLQUFLLEtBQUssUUFBUTtBQUNuRSxVQUFNLGtCQUFrQixnQkFBZ0IsK0JBQStCO0FBR3ZFLFdBQU8sZ0JBQ0osUUFBUSxvQkFBb0IsY0FBYyxVQUFVLEVBQ3BELFFBQVEsc0JBQXNCLGNBQWMsWUFBWSxFQUN4RCxRQUFRLG9CQUFvQixjQUFjLFVBQVUsRUFDcEQsUUFBUSxrQkFBa0IsY0FBYyxRQUFRLEVBQ2hELFFBQVEsK0NBQStDLElBQUksS0FBSyxFQUFFLFlBQVksQ0FBQyxFQUMvRSxRQUFRLHlEQUF5RCxJQUFJLEtBQUssRUFBRSxZQUFZLENBQUM7QUFBQSxFQUM5RjtBQUNGOzs7QUV0T0EsSUFBQUMsbUJBQTJCO0FBR3BCLElBQU0sc0JBQU4sTUFBMEI7QUFBQSxFQUcvQixZQUFZLEtBQVU7QUFDcEIsU0FBSyxNQUFNO0FBQUEsRUFDYjtBQUFBLEVBRUEsMEJBQTBCLFNBQTJCO0FBRW5ELFVBQU0sYUFBYTtBQUNuQixVQUFNLGVBQWUsbUNBQVMsTUFBTTtBQUVwQyxRQUFJLGNBQWM7QUFDaEIsWUFBTSxZQUFZLGFBQWEsQ0FBQyxFQUFFLEtBQUs7QUFDdkMsWUFBTSxlQUFlLFVBQ2xCLFFBQVEsZ0JBQWdCLEVBQUUsRUFDMUIsUUFBUSxjQUFjLEVBQUUsRUFDeEIsTUFBTSxJQUFJLEVBQ1YsSUFBSSxDQUFDLFNBQVMsS0FBSyxLQUFLLENBQUMsRUFDekIsT0FBTyxDQUFDLFNBQVMsS0FBSyxTQUFTLENBQUM7QUFFbkMsYUFBTztBQUFBLElBQ1Q7QUFFQSxXQUFPLENBQUM7QUFBQSxFQUNWO0FBQUEsRUFFTSw0QkFDSixVQUNtQztBQUFBO0FBQ25DLGNBQVEsSUFBSSxxQ0FBcUMsVUFBVTtBQUUzRCxVQUFJO0FBRUYsY0FBTSxjQUFjLE1BQU0sS0FBSyxnQkFBZ0IsUUFBUTtBQUV2RCxZQUFJLFlBQVksV0FBVyxHQUFHO0FBQzVCLGtCQUFRLElBQUksOEJBQThCLFVBQVU7QUFDcEQsaUJBQU8sQ0FBQztBQUFBLFFBQ1Y7QUFHQSxjQUFNLGlCQUEyQyxDQUFDO0FBRWxELG1CQUFXLFFBQVEsYUFBYTtBQUM5QixjQUFJO0FBQ0Ysa0JBQU0sVUFBVSxNQUFNLEtBQUssSUFBSSxNQUFNLEtBQUssSUFBSTtBQUM5QyxrQkFBTSxhQUFhLEtBQUssMEJBQTBCLE9BQU87QUFFekQsZ0JBQUksV0FBVyxTQUFTLEdBQUc7QUFDekIsNkJBQWUsS0FBSyxRQUFRLElBQUk7QUFBQSxZQUNsQztBQUFBLFVBQ0YsU0FBUyxPQUFQO0FBQ0Esb0JBQVEsTUFBTSxzQkFBc0IsS0FBSyxTQUFTLEtBQUs7QUFBQSxVQUN6RDtBQUFBLFFBQ0Y7QUFFQSxnQkFBUTtBQUFBLFVBQ04sNkJBQ0UsT0FBTyxLQUFLLGNBQWMsRUFBRSw0QkFDUjtBQUFBLFFBQ3hCO0FBQ0EsZUFBTztBQUFBLE1BQ1QsU0FBUyxPQUFQO0FBQ0EsZ0JBQVE7QUFBQSxVQUNOLDBDQUEwQztBQUFBLFVBQzFDO0FBQUEsUUFDRjtBQUNBLGVBQU8sQ0FBQztBQUFBLE1BQ1Y7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVNLGdCQUFnQixVQUFvQztBQUFBO0FBQ3hELFlBQU0sUUFBaUIsQ0FBQztBQUd4QixZQUFNLFFBQVEsS0FBSyxJQUFJLE1BQU0saUJBQWlCO0FBRTlDLGlCQUFXLFFBQVEsT0FBTztBQUV4QixZQUNFLEtBQUssS0FBSyxTQUFTLFFBQVEsTUFDMUIsTUFBTSxLQUFLLG9CQUFvQixNQUFNLFFBQVEsSUFDOUM7QUFDQSxnQkFBTSxLQUFLLElBQUk7QUFBQSxRQUNqQjtBQUFBLE1BQ0Y7QUFFQSxhQUFPO0FBQUEsSUFDVDtBQUFBO0FBQUEsRUFFYyxvQkFDWixNQUNBLFVBQ2tCO0FBQUE7QUFDbEIsVUFBSTtBQUNGLGNBQU0sVUFBVSxNQUFNLEtBQUssSUFBSSxNQUFNLEtBQUssSUFBSTtBQUM5QyxjQUFNLG1CQUFtQixRQUFRLE1BQU0sdUJBQXVCO0FBRTlELFlBQUksa0JBQWtCO0FBQ3BCLGdCQUFNLGNBQWMsaUJBQWlCLENBQUM7QUFFdEMsaUJBQ0UsWUFBWSxTQUFTLGNBQWMsVUFBVSxLQUM3QyxZQUFZLFNBQVMsYUFBYSxVQUFVO0FBQUEsUUFFaEQ7QUFFQSxlQUFPO0FBQUEsTUFDVCxTQUFTLE9BQVA7QUFDQSxnQkFBUTtBQUFBLFVBQ04sMEJBQTBCLEtBQUssMEJBQTBCO0FBQUEsVUFDekQ7QUFBQSxRQUNGO0FBQ0EsZUFBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVNLHdCQUNKLFVBQ0EsZ0JBQ2lCO0FBQUE7QUFDakIsWUFBTSxXQUFxQixDQUFDO0FBQzVCLFlBQU0sY0FBd0MsQ0FBQztBQUcvQyxpQkFBVyxDQUFDLFVBQVUsS0FBSyxLQUFLLE9BQU8sUUFBUSxjQUFjLEdBQUc7QUFDOUQsbUJBQVcsUUFBUSxPQUFPO0FBQ3hCLGNBQUksQ0FBQyxTQUFTLFNBQVMsSUFBSSxHQUFHO0FBQzVCLHFCQUFTLEtBQUssSUFBSTtBQUNsQix3QkFBWSxJQUFJLElBQUksQ0FBQztBQUFBLFVBQ3ZCO0FBQ0Esc0JBQVksSUFBSSxFQUFFLEtBQUssUUFBUTtBQUFBLFFBQ2pDO0FBQUEsTUFDRjtBQUdBLGVBQVMsS0FBSztBQUdkLFVBQUksVUFBVSx3QkFBd0I7QUFBQTtBQUFBO0FBQ3RDLGlCQUFXLHVCQUF1QixTQUFTO0FBQUE7QUFBQTtBQUUzQyxpQkFBVyxRQUFRLFVBQVU7QUFDM0IsbUJBQVcsTUFBTTtBQUFBO0FBQ2pCLG1CQUFXLGdCQUFnQixZQUFZLElBQUksRUFBRSxLQUFLLElBQUk7QUFBQTtBQUFBO0FBQ3RELG1CQUFXO0FBQUE7QUFBQTtBQUNYLG1CQUFXO0FBQUE7QUFBQTtBQUNYLG1CQUFXO0FBQUE7QUFBQTtBQUNYLG1CQUFXO0FBQUE7QUFBQTtBQUFBLE1BQ2I7QUFFQSxhQUFPO0FBQUEsSUFDVDtBQUFBO0FBQUEsRUFFTSwwQkFBMEIsVUFBaUM7QUFBQTtBQUMvRCxVQUFJO0FBQ0YsY0FBTSxpQkFBaUIsTUFBTSxLQUFLLDRCQUE0QixRQUFRO0FBRXRFLFlBQUksT0FBTyxLQUFLLGNBQWMsRUFBRSxXQUFXLEdBQUc7QUFDNUMsa0JBQVEsSUFBSSxtQ0FBbUMsVUFBVTtBQUN6RDtBQUFBLFFBQ0Y7QUFFQSxjQUFNLGVBQWUsTUFBTSxLQUFLO0FBQUEsVUFDOUI7QUFBQSxVQUNBO0FBQUEsUUFDRjtBQUdBLGNBQU0sV0FBVyxHQUFHO0FBQ3BCLGNBQU0sV0FBVyxXQUFXLFlBQVk7QUFFeEMsWUFBSTtBQUNGLGdCQUFNLEtBQUssSUFBSSxNQUFNLE9BQU8sVUFBVSxZQUFZO0FBQ2xELGtCQUFRLElBQUksa0NBQWtDLFVBQVU7QUFBQSxRQUMxRCxTQUFTLE9BQVA7QUFFQSxnQkFBTSxlQUFlLEtBQUssSUFBSSxNQUFNLHNCQUFzQixRQUFRO0FBQ2xFLGNBQUksZ0JBQWdCLHdCQUF3Qix3QkFBTztBQUNqRCxrQkFBTSxLQUFLLElBQUksTUFBTSxPQUFPLGNBQWMsWUFBWTtBQUN0RCxvQkFBUSxJQUFJLGtDQUFrQyxVQUFVO0FBQUEsVUFDMUQ7QUFBQSxRQUNGO0FBQUEsTUFDRixTQUFTLE9BQVA7QUFDQSxnQkFBUTtBQUFBLFVBQ04sOENBQThDO0FBQUEsVUFDOUM7QUFBQSxRQUNGO0FBQ0EsY0FBTTtBQUFBLE1BQ1I7QUFBQSxJQUNGO0FBQUE7QUFDRjs7O0FDck1BLElBQUFDLG1CQUEyQjtBQUdwQixJQUFNLGlCQUFOLE1BQXFCO0FBQUEsRUFHMUIsWUFBWSxLQUFVO0FBQ3BCLFNBQUssTUFBTTtBQUFBLEVBQ2I7QUFBQSxFQUVBLHNCQUNFLFNBQzZEO0FBRTdELFVBQU0sZ0JBQWdCO0FBQ3RCLFVBQU0sVUFBVSxtQ0FBUyxNQUFNO0FBRS9CLFFBQUksQ0FBQyxTQUFTO0FBQ1osYUFBTyxDQUFDO0FBQUEsSUFDVjtBQUVBLFVBQU0sa0JBQWtCLFFBQVEsQ0FBQztBQUNqQyxVQUFNLFdBQVcsQ0FBQztBQUdsQixVQUFNLGFBQWE7QUFDbkIsVUFBTSxlQUFlLGdCQUFnQixNQUFNLFVBQVU7QUFFckQsUUFBSSxjQUFjO0FBQ2hCLGlCQUFXLFNBQVMsY0FBYztBQUNoQyxjQUFNLE9BQU8sTUFDVixLQUFLLEVBQ0wsTUFBTSxJQUFJLEVBQ1YsT0FBTyxDQUFDLFFBQVEsSUFBSSxXQUFXLEdBQUcsQ0FBQztBQUN0QyxjQUFNLGFBQWEsS0FBSyxlQUFlLElBQUk7QUFDM0MsaUJBQVMsS0FBSyxHQUFHLFVBQVU7QUFBQSxNQUM3QjtBQUFBLElBQ0Y7QUFFQSxXQUFPO0FBQUEsRUFDVDtBQUFBLEVBRVEsZUFDTixNQUM2RDtBQUM3RCxRQUFJLEtBQUssU0FBUztBQUFHLGFBQU8sQ0FBQztBQUU3QixVQUFNLFdBQVcsQ0FBQztBQUVsQixhQUFTLElBQUksR0FBRyxJQUFJLEtBQUssUUFBUSxLQUFLO0FBRXBDLFlBQU0sTUFBTSxLQUFLLENBQUM7QUFDbEIsWUFBTSxVQUFVLElBQ2IsTUFBTSxHQUFHLEVBQ1QsSUFBSSxDQUFDLFFBQVEsSUFBSSxLQUFLLENBQUMsRUFDdkIsT0FBTyxDQUFDLFFBQVEsR0FBRztBQUV0QixVQUFJLFFBQVEsVUFBVSxHQUFHO0FBQ3ZCLGNBQU0sQ0FBQyxNQUFNLFlBQVksU0FBUyxTQUFTLElBQUk7QUFDL0MsWUFBSSxRQUFRLGNBQWMsS0FBSyxZQUFZLElBQUksR0FBRztBQUNoRCxtQkFBUyxLQUFLLEVBQUUsTUFBTSxZQUFZLE9BQU8sQ0FBQztBQUFBLFFBQzVDO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFFQSxXQUFPO0FBQUEsRUFDVDtBQUFBLEVBRVEsWUFBWSxZQUE2QjtBQUMvQyxVQUFNLFlBQVk7QUFDbEIsV0FBTyxVQUFVLEtBQUssVUFBVSxLQUFLLENBQUMsTUFBTSxLQUFLLE1BQU0sVUFBVSxDQUFDO0FBQUEsRUFDcEU7QUFBQSxFQUVNLHdCQUNKLFVBQ0EsV0FDQSxTQUdBO0FBQUE7QUFDQSxjQUFRLElBQUksaUNBQWlDLFVBQVU7QUFFdkQsVUFBSTtBQUVGLGNBQU0sY0FBYyxNQUFNLEtBQUssZ0JBQWdCLFFBQVE7QUFFdkQsWUFBSSxZQUFZLFdBQVcsR0FBRztBQUM1QixrQkFBUSxJQUFJLDhCQUE4QixVQUFVO0FBQ3BELGlCQUFPLENBQUM7QUFBQSxRQUNWO0FBR0EsY0FBTSxjQUtELENBQUM7QUFFTixtQkFBVyxRQUFRLGFBQWE7QUFDOUIsY0FBSTtBQUNGLGtCQUFNLFVBQVUsTUFBTSxLQUFLLElBQUksTUFBTSxLQUFLLElBQUk7QUFDOUMsa0JBQU0sV0FBVyxLQUFLLHNCQUFzQixPQUFPO0FBR25ELGtCQUFNLHFCQUFxQixTQUFTLElBQUksQ0FBQyxZQUFhLGlDQUNqRCxVQURpRDtBQUFBLGNBRXBELFFBQVEsS0FBSztBQUFBLFlBQ2YsRUFBRTtBQUVGLHdCQUFZLEtBQUssR0FBRyxrQkFBa0I7QUFBQSxVQUN4QyxTQUFTLE9BQVA7QUFDQSxvQkFBUSxNQUFNLHNCQUFzQixLQUFLLFNBQVMsS0FBSztBQUFBLFVBQ3pEO0FBQUEsUUFDRjtBQUdBLFlBQUksbUJBQW1CO0FBQ3ZCLFlBQUksYUFBYSxTQUFTO0FBQ3hCLDZCQUFtQixLQUFLO0FBQUEsWUFDdEI7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBR0EseUJBQWlCO0FBQUEsVUFDZixDQUFDLEdBQUcsTUFBTSxJQUFJLEtBQUssRUFBRSxJQUFJLEVBQUUsUUFBUSxJQUFJLElBQUksS0FBSyxFQUFFLElBQUksRUFBRSxRQUFRO0FBQUEsUUFDbEU7QUFFQSxnQkFBUTtBQUFBLFVBQ04sU0FBUyxpQkFBaUIsZ0NBQWdDO0FBQUEsUUFDNUQ7QUFDQSxlQUFPO0FBQUEsTUFDVCxTQUFTLE9BQVA7QUFDQSxnQkFBUSxNQUFNLHNDQUFzQyxhQUFhLEtBQUs7QUFDdEUsZUFBTyxDQUFDO0FBQUEsTUFDVjtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRWMsZ0JBQWdCLFVBQW9DO0FBQUE7QUFDaEUsWUFBTSxRQUFpQixDQUFDO0FBR3hCLFlBQU0sUUFBUSxLQUFLLElBQUksTUFBTSxpQkFBaUI7QUFFOUMsaUJBQVcsUUFBUSxPQUFPO0FBRXhCLFlBQ0UsS0FBSyxLQUFLLFNBQVMsUUFBUSxNQUMxQixNQUFNLEtBQUssb0JBQW9CLE1BQU0sUUFBUSxJQUM5QztBQUNBLGdCQUFNLEtBQUssSUFBSTtBQUFBLFFBQ2pCO0FBQUEsTUFDRjtBQUVBLGFBQU87QUFBQSxJQUNUO0FBQUE7QUFBQSxFQUVjLG9CQUNaLE1BQ0EsVUFDa0I7QUFBQTtBQUNsQixVQUFJO0FBQ0YsY0FBTSxVQUFVLE1BQU0sS0FBSyxJQUFJLE1BQU0sS0FBSyxJQUFJO0FBQzlDLGNBQU0sbUJBQW1CLFFBQVEsTUFBTSx1QkFBdUI7QUFFOUQsWUFBSSxrQkFBa0I7QUFDcEIsZ0JBQU0sY0FBYyxpQkFBaUIsQ0FBQztBQUV0QyxpQkFDRSxZQUFZLFNBQVMsY0FBYyxVQUFVLEtBQzdDLFlBQVksU0FBUyxhQUFhLFVBQVU7QUFBQSxRQUVoRDtBQUVBLGVBQU87QUFBQSxNQUNULFNBQVMsT0FBUDtBQUNBLGdCQUFRO0FBQUEsVUFDTiwwQkFBMEIsS0FBSywwQkFBMEI7QUFBQSxVQUN6RDtBQUFBLFFBQ0Y7QUFDQSxlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRVEsa0JBQ04sVUFNQSxXQUNBLFNBTUM7QUFDRCxXQUFPLFNBQVMsT0FBTyxDQUFDLFlBQVk7QUFDbEMsWUFBTSxjQUFjLElBQUksS0FBSyxRQUFRLElBQUksRUFBRSxRQUFRO0FBRW5ELFVBQUksYUFBYSxjQUFjLElBQUksS0FBSyxTQUFTLEVBQUUsUUFBUSxHQUFHO0FBQzVELGVBQU87QUFBQSxNQUNUO0FBRUEsVUFBSSxXQUFXLGNBQWMsSUFBSSxLQUFLLE9BQU8sRUFBRSxRQUFRLEdBQUc7QUFDeEQsZUFBTztBQUFBLE1BQ1Q7QUFFQSxhQUFPO0FBQUEsSUFDVCxDQUFDO0FBQUEsRUFDSDtBQUFBLEVBRU0sd0JBQ0osVUFDQSxVQU1pQjtBQUFBO0FBQ2pCLFVBQUksU0FBUyxXQUFXLEdBQUc7QUFDekIsZUFBTyx5QkFBeUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUNsQztBQUdBLFlBQU0sV0FBVyxTQUFTLE9BQU8sQ0FBQyxLQUFLLFlBQVk7QUFDakQsWUFBSSxDQUFDLElBQUksUUFBUSxNQUFNLEdBQUc7QUFDeEIsY0FBSSxRQUFRLE1BQU0sSUFBSSxDQUFDO0FBQUEsUUFDekI7QUFDQSxZQUFJLFFBQVEsTUFBTSxFQUFFLEtBQUssT0FBTztBQUNoQyxlQUFPO0FBQUEsTUFDVCxHQUFHLENBQUMsQ0FBb0M7QUFFeEMsVUFBSSxVQUFVLHlCQUF5QjtBQUFBO0FBQUE7QUFDdkMsaUJBQVcsc0JBQXNCLFNBQVM7QUFBQTtBQUFBO0FBRzFDLGlCQUFXLENBQUMsUUFBUSxLQUFLLEtBQUssT0FBTyxRQUFRLFFBQVEsR0FBRztBQUN0RCxtQkFBVyxNQUFNLE9BQU8sT0FBTyxDQUFDLEVBQUUsWUFBWSxJQUFJLE9BQU8sTUFBTSxDQUFDLE1BQzlELE1BQU07QUFBQTtBQUFBO0FBRVIsbUJBQVc7QUFBQTtBQUNYLG1CQUFXO0FBQUE7QUFFWCxtQkFBVyxRQUFRLE9BQU87QUFDeEIscUJBQVcsS0FBSyxLQUFLLFVBQVUsS0FBSyxnQkFBZ0IsS0FBSztBQUFBO0FBQUEsUUFDM0Q7QUFDQSxtQkFBVztBQUFBO0FBQUEsTUFDYjtBQUVBLGFBQU87QUFBQSxJQUNUO0FBQUE7QUFBQSxFQUVNLDBCQUNKLFVBQ0EsV0FDQSxTQUNlO0FBQUE7QUFDZixVQUFJO0FBQ0YsY0FBTSxXQUFXLE1BQU0sS0FBSztBQUFBLFVBQzFCO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxRQUNGO0FBRUEsY0FBTSxpQkFBaUIsTUFBTSxLQUFLO0FBQUEsVUFDaEM7QUFBQSxVQUNBO0FBQUEsUUFDRjtBQUdBLGNBQU0sV0FBVyxHQUFHO0FBQ3BCLGNBQU0sV0FBVyxXQUFXLFlBQVk7QUFFeEMsWUFBSTtBQUNGLGdCQUFNLEtBQUssSUFBSSxNQUFNLE9BQU8sVUFBVSxjQUFjO0FBQ3BELGtCQUFRLElBQUksbUNBQW1DLFVBQVU7QUFBQSxRQUMzRCxTQUFTLE9BQVA7QUFFQSxnQkFBTSxlQUFlLEtBQUssSUFBSSxNQUFNLHNCQUFzQixRQUFRO0FBQ2xFLGNBQUksZ0JBQWdCLHdCQUF3Qix3QkFBTztBQUNqRCxrQkFBTSxLQUFLLElBQUksTUFBTSxPQUFPLGNBQWMsY0FBYztBQUN4RCxvQkFBUSxJQUFJLG1DQUFtQyxVQUFVO0FBQUEsVUFDM0Q7QUFBQSxRQUNGO0FBQUEsTUFDRixTQUFTLE9BQVA7QUFDQSxnQkFBUTtBQUFBLFVBQ04sK0NBQStDO0FBQUEsVUFDL0M7QUFBQSxRQUNGO0FBQ0EsY0FBTTtBQUFBLE1BQ1I7QUFBQSxJQUNGO0FBQUE7QUFDRjs7O0FDelNBLElBQUFDLG1CQUEyQjtBQUVwQixJQUFNLHdCQUFOLE1BQTRCO0FBQUEsRUFHakMsWUFBWSxLQUFVO0FBQ3BCLFNBQUssTUFBTTtBQUFBLEVBQ2I7QUFBQSxFQUVNLHNCQUVKO0FBQUE7QUFDQSxjQUFRLElBQUkscUNBQXFDO0FBRWpELFVBQUk7QUFDRixjQUFNLFFBQVEsSUFBSSxLQUFLO0FBQ3ZCLGNBQU0sY0FBYyxNQUFNLFlBQVksRUFBRSxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBR3BELGNBQU0sUUFBUSxLQUFLLElBQUksTUFBTSxpQkFBaUI7QUFDOUMsY0FBTSxjQUF1QixDQUFDO0FBRTlCLG1CQUFXLFFBQVEsT0FBTztBQUN4QixnQkFBTSxXQUFXLEtBQUssb0JBQW9CLEtBQUssSUFBSTtBQUNuRCxjQUFJLGFBQWEsYUFBYTtBQUM1Qix3QkFBWSxLQUFLLElBQUk7QUFBQSxVQUN2QjtBQUFBLFFBQ0Y7QUFHQSxjQUFNLGFBQ0osQ0FBQztBQUVILG1CQUFXLFFBQVEsYUFBYTtBQUM5QixnQkFBTSxXQUFXLE1BQU0sS0FBSyxvQkFBb0IsSUFBSTtBQUNwRCxjQUFJLFVBQVU7QUFDWix1QkFBVyxLQUFLLFFBQVE7QUFBQSxVQUMxQjtBQUFBLFFBQ0Y7QUFFQSxnQkFBUSxJQUFJLFNBQVMsV0FBVyxzQ0FBc0M7QUFDdEUsZUFBTztBQUFBLE1BQ1QsU0FBUyxPQUFQO0FBQ0EsZ0JBQVEsTUFBTSxxQ0FBcUMsS0FBSztBQUN4RCxlQUFPLENBQUM7QUFBQSxNQUNWO0FBQUEsSUFDRjtBQUFBO0FBQUEsRUFFTSx5QkFDSixVQUNBLE1BQ2dEO0FBQUE7QUFDaEQsY0FBUSxJQUFJLCtCQUErQixvQkFBb0IsTUFBTTtBQUVyRSxVQUFJO0FBRUYsY0FBTSxjQUFjLE1BQU0sS0FBSyx1QkFBdUIsVUFBVSxJQUFJO0FBRXBFLGNBQU0sYUFBb0QsQ0FBQztBQUUzRCxtQkFBVyxRQUFRLGFBQWE7QUFDOUIsZ0JBQU0sVUFBVSxNQUFNLEtBQUssSUFBSSxNQUFNLEtBQUssSUFBSTtBQUM5QyxnQkFBTSxXQUFXLEtBQUssa0JBQWtCLE1BQU0sT0FBTztBQUVyRCxxQkFBVyxLQUFLO0FBQUEsWUFDZCxNQUFNLEtBQUs7QUFBQSxZQUNYLE1BQU07QUFBQSxVQUNSLENBQUM7QUFBQSxRQUNIO0FBRUEsZ0JBQVE7QUFBQSxVQUNOLFNBQVMsV0FBVyxnQ0FBZ0MsZUFBZTtBQUFBLFFBQ3JFO0FBQ0EsZUFBTztBQUFBLE1BQ1QsU0FBUyxPQUFQO0FBQ0EsZ0JBQVE7QUFBQSxVQUNOLHFDQUFxQyxlQUFlO0FBQUEsVUFDcEQ7QUFBQSxRQUNGO0FBQ0EsZUFBTyxDQUFDO0FBQUEsTUFDVjtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRVEsb0JBQW9CLFVBQWlDO0FBRTNELFVBQU0sWUFBWTtBQUNsQixVQUFNLFVBQVUsU0FBUyxNQUFNLFNBQVM7QUFDeEMsV0FBTyxVQUFVLFFBQVEsUUFBUSxTQUFTLENBQUMsSUFBSTtBQUFBLEVBQ2pEO0FBQUEsRUFFYyxvQkFDWixNQUNpRTtBQUFBO0FBQ2pFLFVBQUk7QUFDRixjQUFNLFVBQVUsTUFBTSxLQUFLLElBQUksTUFBTSxLQUFLLElBQUk7QUFHOUMsY0FBTSxXQUFXLEtBQUssa0JBQWtCLE1BQU0sT0FBTztBQUdyRCxjQUFNLFdBQ0osS0FBSywyQkFBMkIsT0FBTyxLQUN2QyxLQUFLLHdCQUF3QixLQUFLLElBQUk7QUFFeEMsZUFBTztBQUFBLFVBQ0wsTUFBTSxLQUFLO0FBQUEsVUFDWCxNQUFNO0FBQUEsVUFDTixRQUFRLFlBQVk7QUFBQSxRQUN0QjtBQUFBLE1BQ0YsU0FBUyxPQUFQO0FBQ0EsZ0JBQVEsTUFBTSx3QkFBd0IsS0FBSyxTQUFTLEtBQUs7QUFDekQsZUFBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVRLGtCQUFrQixNQUFhLFNBQXlCO0FBQzlELFVBQU0sT0FBTyxLQUFLLEtBQUssWUFBWTtBQUduQyxRQUNFLEtBQUssU0FBUyxPQUFPLEtBQ3JCLFFBQVEsU0FBUywwQkFBMEIsR0FDM0M7QUFDQSxhQUFPO0FBQUEsSUFDVDtBQUdBLFFBQUksS0FBSyxTQUFTLFNBQVMsS0FBSyxRQUFRLFNBQVMsWUFBWSxHQUFHO0FBQzlELFVBQUksUUFBUSxTQUFTLCtCQUErQixHQUFHO0FBQ3JELGVBQU87QUFBQSxNQUNUO0FBQ0EsVUFBSSxRQUFRLFNBQVMsc0JBQXNCLEdBQUc7QUFDNUMsZUFBTztBQUFBLE1BQ1Q7QUFDQSxVQUFJLFFBQVEsU0FBUyx1QkFBdUIsR0FBRztBQUM3QyxlQUFPO0FBQUEsTUFDVDtBQUNBLFVBQUksUUFBUSxTQUFTLDBCQUEwQixHQUFHO0FBQ2hELGVBQU87QUFBQSxNQUNUO0FBQ0EsYUFBTztBQUFBLElBQ1Q7QUFHQSxRQUFJLFFBQVEsU0FBUyxLQUFLLEtBQUssUUFBUSxNQUFNLGlCQUFpQixHQUFHO0FBQy9ELGFBQU87QUFBQSxJQUNUO0FBRUEsV0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUVRLDJCQUEyQixTQUFnQztBQUNqRSxVQUFNLGdCQUFnQjtBQUN0QixVQUFNLFFBQVEsUUFBUSxNQUFNLGFBQWE7QUFDekMsV0FBTyxRQUFRLE1BQU0sQ0FBQyxJQUFJO0FBQUEsRUFDNUI7QUFBQSxFQUVRLHdCQUF3QixVQUFpQztBQUMvRCxVQUFNLGdCQUFnQjtBQUN0QixVQUFNLFVBQVUsU0FBUyxNQUFNLGFBQWE7QUFDNUMsV0FBTyxVQUFVLFFBQVEsUUFBUSxTQUFTLENBQUMsSUFBSTtBQUFBLEVBQ2pEO0FBQUEsRUFFYyx1QkFDWixVQUNBLE1BQ2tCO0FBQUE7QUFDbEIsWUFBTSxRQUFpQixDQUFDO0FBR3hCLFlBQU0sV0FBVyxLQUFLLElBQUksTUFBTSxpQkFBaUI7QUFFakQsaUJBQVcsUUFBUSxVQUFVO0FBRTNCLFlBQ0UsS0FBSyxLQUFLLFNBQVMsUUFBUSxNQUMxQixNQUFNLEtBQUssb0JBQW9CLE1BQU0sUUFBUSxJQUM5QztBQUVBLGdCQUFNLFdBQVcsS0FBSyxvQkFBb0IsS0FBSyxJQUFJO0FBQ25ELGNBQUksYUFBYSxNQUFNO0FBQ3JCLGtCQUFNLEtBQUssSUFBSTtBQUFBLFVBQ2pCO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFFQSxhQUFPO0FBQUEsSUFDVDtBQUFBO0FBQUEsRUFFYyxvQkFDWixNQUNBLFVBQ2tCO0FBQUE7QUFDbEIsVUFBSTtBQUNGLGNBQU0sVUFBVSxNQUFNLEtBQUssSUFBSSxNQUFNLEtBQUssSUFBSTtBQUM5QyxlQUFPLEtBQUssMkJBQTJCLE9BQU8sTUFBTTtBQUFBLE1BQ3RELFNBQVMsT0FBUDtBQUNBLGdCQUFRO0FBQUEsVUFDTiwwQkFBMEIsS0FBSywwQkFBMEI7QUFBQSxVQUN6RDtBQUFBLFFBQ0Y7QUFDQSxlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRU0scUJBQXFCLE1BQWdDO0FBQUE7QUFDekQsWUFBTSxhQUFhLFFBQVEsSUFBSSxLQUFLLEVBQUUsWUFBWSxFQUFFLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFDaEUsWUFBTSxhQUFhLE1BQU0sS0FBSyx5QkFBeUIsSUFBSSxVQUFVO0FBRXJFLFVBQUksV0FBVyxXQUFXLEdBQUc7QUFDM0IsZUFBTywyQkFBMkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUNwQztBQUdBLFlBQU0sV0FBOEMsQ0FBQztBQUNyRCxZQUFNLFdBQThCLENBQUM7QUFFckMsaUJBQVcsWUFBWSxZQUFZO0FBQ2pDLFlBQUksU0FBUyxLQUFLLFNBQVMsVUFBVSxHQUFHO0FBRXRDLGdCQUFNLFlBQVksU0FBUyxLQUFLLE1BQU0sR0FBRztBQUN6QyxnQkFBTSxjQUFjLFVBQVUsVUFBVSxDQUFDLFNBQVMsS0FBSyxTQUFTLEdBQUcsQ0FBQztBQUNwRSxjQUFJLGVBQWUsR0FBRztBQUNwQixrQkFBTSxXQUFXLFVBQVUsV0FBVztBQUN0QyxnQkFBSSxDQUFDLFNBQVMsUUFBUSxHQUFHO0FBQ3ZCLHVCQUFTLFFBQVEsSUFBSSxDQUFDO0FBQUEsWUFDeEI7QUFDQSxxQkFBUyxRQUFRLEVBQUUsS0FBSyxRQUFRO0FBQUEsVUFDbEMsT0FBTztBQUNMLHFCQUFTLEtBQUssUUFBUTtBQUFBLFVBQ3hCO0FBQUEsUUFDRixPQUFPO0FBQ0wsbUJBQVMsS0FBSyxRQUFRO0FBQUEsUUFDeEI7QUFBQSxNQUNGO0FBRUEsVUFBSSxVQUFVLDJCQUEyQjtBQUFBO0FBQUE7QUFDekMsaUJBQVcscUJBQXFCLFdBQVc7QUFBQTtBQUFBO0FBRzNDLGlCQUFXLENBQUMsVUFBVSxnQkFBZ0IsS0FBSyxPQUFPLFFBQVEsUUFBUSxHQUFHO0FBQ25FLG1CQUFXLE1BQU07QUFBQTtBQUFBO0FBQ2pCLG1CQUFXO0FBQUE7QUFDWCxtQkFBVztBQUFBO0FBRVgsbUJBQVcsWUFBWSxrQkFBa0I7QUFDdkMscUJBQVcsS0FBSyxTQUFTLFVBQVUsU0FBUztBQUFBO0FBQUEsUUFDOUM7QUFDQSxtQkFBVztBQUFBO0FBQUEsTUFDYjtBQUdBLFVBQUksU0FBUyxTQUFTLEdBQUc7QUFDdkIsbUJBQVc7QUFBQTtBQUFBO0FBQ1gsbUJBQVc7QUFBQTtBQUNYLG1CQUFXO0FBQUE7QUFFWCxtQkFBVyxZQUFZLFVBQVU7QUFDL0IscUJBQVcsS0FBSyxTQUFTLFVBQVUsU0FBUztBQUFBO0FBQUEsUUFDOUM7QUFDQSxtQkFBVztBQUFBO0FBQUEsTUFDYjtBQUVBLGFBQU87QUFBQSxJQUNUO0FBQUE7QUFBQSxFQUVNLHVCQUF1QixNQUE4QjtBQUFBO0FBQ3pELFVBQUk7QUFDRixjQUFNLGFBQWEsUUFBUSxJQUFJLEtBQUssRUFBRSxZQUFZLEVBQUUsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUNoRSxjQUFNLGlCQUFpQixNQUFNLEtBQUsscUJBQXFCLFVBQVU7QUFHakUsY0FBTSxXQUFXLEdBQUc7QUFDcEIsY0FBTSxXQUFXLFNBQVM7QUFFMUIsWUFBSTtBQUNGLGdCQUFNLEtBQUssSUFBSSxNQUFNLE9BQU8sVUFBVSxjQUFjO0FBQ3BELGtCQUFRLElBQUksK0JBQStCLFVBQVU7QUFBQSxRQUN2RCxTQUFTLE9BQVA7QUFFQSxnQkFBTSxlQUFlLEtBQUssSUFBSSxNQUFNLHNCQUFzQixRQUFRO0FBQ2xFLGNBQUksZ0JBQWdCLHdCQUF3Qix3QkFBTztBQUNqRCxrQkFBTSxLQUFLLElBQUksTUFBTSxPQUFPLGNBQWMsY0FBYztBQUN4RCxvQkFBUSxJQUFJLCtCQUErQixVQUFVO0FBQUEsVUFDdkQ7QUFBQSxRQUNGO0FBQUEsTUFDRixTQUFTLE9BQVA7QUFDQSxnQkFBUSxNQUFNLG9DQUFvQyxTQUFTLEtBQUs7QUFDaEUsY0FBTTtBQUFBLE1BQ1I7QUFBQSxJQUNGO0FBQUE7QUFDRjs7O0FDclNBLElBQUFDLG1CQUF1RDtBQVVoRCxJQUFNLG1CQUFOLGNBQStCLHVCQUFNO0FBQUEsRUFNMUMsWUFDRSxLQUNBLFlBQ0EsVUFDQSxVQUNBO0FBQ0EsVUFBTSxHQUFHO0FBQ1QsU0FBSyxjQUFjLENBQUMsRUFBRSxNQUFNLElBQUksU0FBUyxJQUFJLE1BQU0sSUFBSSxRQUFRLElBQUksYUFBYSxHQUFHLENBQUM7QUFDcEYsU0FBSyxhQUFhO0FBQ2xCLFNBQUssV0FBVztBQUNoQixTQUFLLFdBQVc7QUFBQSxFQUNsQjtBQUFBLEVBRUEsU0FBUztBQUNQLFVBQU0sRUFBRSxVQUFVLElBQUk7QUFDdEIsY0FBVSxNQUFNO0FBQ2hCLGNBQVUsU0FBUyxpQ0FBaUM7QUFFcEQsY0FBVSxTQUFTLE1BQU0sRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBR2hFLFFBQUkseUJBQVEsU0FBUyxFQUNsQixRQUFRLFFBQVEsRUFDaEIsUUFBUSxHQUFHLEtBQUssZUFBZSxLQUFLLFdBQVcsRUFDL0MsWUFBWSxJQUFJO0FBR25CLFVBQU0sdUJBQXVCLFVBQVUsVUFBVSxFQUFFLEtBQUssd0JBQXdCLENBQUM7QUFHakYsU0FBSyxxQkFBcUIsc0JBQXNCLENBQUM7QUFHakQsUUFBSSx5QkFBUSxTQUFTLEVBQ2xCO0FBQUEsTUFBVSxDQUFDLFFBQ1YsSUFDRyxjQUFjLGdCQUFnQixFQUM5QixPQUFPLEVBQ1AsUUFBUSxNQUFNO0FBQ2IsY0FBTSxXQUFXLEtBQUssWUFBWTtBQUNsQyxhQUFLLFlBQVksS0FBSyxFQUFFLE1BQU0sSUFBSSxTQUFTLElBQUksTUFBTSxJQUFJLFFBQVEsSUFBSSxhQUFhLEdBQUcsQ0FBQztBQUN0RixhQUFLLHFCQUFxQixzQkFBc0IsUUFBUTtBQUFBLE1BQzFELENBQUM7QUFBQSxJQUNMO0FBR0YsUUFBSSx5QkFBUSxTQUFTLEVBQ2xCO0FBQUEsTUFBVSxDQUFDLFFBQ1YsSUFDRyxjQUFjLG9CQUFvQixFQUNsQyxPQUFPLEVBQ1AsUUFBUSxNQUFNO0FBRWIsY0FBTSxtQkFBbUIsS0FBSyxZQUFZO0FBQUEsVUFDeEMsQ0FBQyxNQUFNLEVBQUUsS0FBSyxLQUFLLE1BQU0sTUFBTSxFQUFFLFFBQVEsS0FBSyxNQUFNO0FBQUEsUUFDdEQ7QUFDQSxhQUFLLFNBQVMsa0JBQWtCLEtBQUssWUFBWSxLQUFLLFFBQVE7QUFDOUQsYUFBSyxNQUFNO0FBQUEsTUFDYixDQUFDO0FBQUEsSUFDTDtBQUFBLEVBQ0o7QUFBQSxFQUVBLHFCQUFxQixXQUF3QixPQUFlO0FBQzFELFVBQU0sVUFBVSxVQUFVLFVBQVUsRUFBRSxLQUFLLHFCQUFxQixDQUFDO0FBQ2pFLFlBQVEsU0FBUyxNQUFNLEVBQUUsTUFBTSxlQUFlLFFBQVEsSUFBSSxDQUFDO0FBRTNELFFBQUkseUJBQVEsT0FBTyxFQUNoQixRQUFRLGlCQUFpQixFQUN6QjtBQUFBLE1BQVEsQ0FBQyxTQUNSLEtBQ0csZUFBZSx1QkFBdUIsRUFDdEMsU0FBUyxLQUFLLFlBQVksS0FBSyxFQUFFLElBQUksRUFDckMsU0FBUyxDQUFDLFVBQVU7QUFDbkIsYUFBSyxZQUFZLEtBQUssRUFBRSxPQUFPO0FBQUEsTUFDakMsQ0FBQztBQUFBLElBQ0w7QUFFRixRQUFJLHlCQUFRLE9BQU8sRUFDaEIsUUFBUSxVQUFVLEVBQ2xCLFFBQVEsb0JBQW9CLEVBQzVCO0FBQUEsTUFBUSxDQUFDLFNBQ1IsS0FDRyxlQUFlLFlBQVksRUFDM0IsU0FBUyxLQUFLLFlBQVksS0FBSyxFQUFFLE9BQU8sRUFDeEMsU0FBUyxDQUFDLFVBQVU7QUFDbkIsYUFBSyxZQUFZLEtBQUssRUFBRSxVQUFVO0FBQUEsTUFDcEMsQ0FBQztBQUFBLElBQ0w7QUFFRixRQUFJLHlCQUFRLE9BQU8sRUFDaEIsUUFBUSxpQkFBaUIsRUFDekI7QUFBQSxNQUFRLENBQUMsU0FDUixLQUNHLGVBQWUsNEJBQTRCLEVBQzNDLFNBQVMsS0FBSyxZQUFZLEtBQUssRUFBRSxJQUFJLEVBQ3JDLFNBQVMsQ0FBQyxVQUFVO0FBQ25CLGFBQUssWUFBWSxLQUFLLEVBQUUsT0FBTztBQUFBLE1BQ2pDLENBQUM7QUFBQSxJQUNMO0FBRUYsUUFBSSx5QkFBUSxPQUFPLEVBQ2hCLFFBQVEsUUFBUSxFQUNoQjtBQUFBLE1BQVEsQ0FBQyxTQUNSLEtBQ0csZUFBZSxXQUFXLEVBQzFCLFNBQVMsS0FBSyxZQUFZLEtBQUssRUFBRSxNQUFNLEVBQ3ZDLFNBQVMsQ0FBQyxVQUFVO0FBQ25CLGFBQUssWUFBWSxLQUFLLEVBQUUsU0FBUztBQUFBLE1BQ25DLENBQUM7QUFBQSxJQUNMO0FBRUYsUUFBSSx5QkFBUSxPQUFPLEVBQ2hCLFFBQVEsYUFBYSxFQUNyQjtBQUFBLE1BQVksQ0FBQyxTQUNaLEtBQ0csZUFBZSw4QkFBOEIsRUFDN0MsU0FBUyxLQUFLLFlBQVksS0FBSyxFQUFFLFdBQVcsRUFDNUMsU0FBUyxDQUFDLFVBQVU7QUFDbkIsYUFBSyxZQUFZLEtBQUssRUFBRSxjQUFjO0FBQUEsTUFDeEMsQ0FBQztBQUFBLElBQ0w7QUFHRixRQUFJLEtBQUssWUFBWSxTQUFTLEdBQUc7QUFDL0IsVUFBSSx5QkFBUSxPQUFPLEVBQ2hCO0FBQUEsUUFBVSxDQUFDLFFBQ1YsSUFDRyxjQUFjLFFBQVEsRUFDdEIsUUFBUSxNQUFNO0FBQ2IsZUFBSyxZQUFZLE9BQU8sT0FBTyxDQUFDO0FBQ2hDLGtCQUFRLE9BQU87QUFDZixlQUFLLG9CQUFvQjtBQUFBLFFBQzNCLENBQUM7QUFBQSxNQUNMO0FBQUEsSUFDSjtBQUFBLEVBQ0Y7QUFBQSxFQUVBLHNCQUFzQjtBQUNwQixVQUFNLFdBQVcsS0FBSyxVQUFVLGlCQUFpQixxQkFBcUI7QUFDdEUsYUFBUyxRQUFRLENBQUMsU0FBUyxVQUFVO0FBQ25DLFlBQU0sU0FBUyxRQUFRLGNBQWMsSUFBSTtBQUN6QyxVQUFJLFFBQVE7QUFDVixlQUFPLGNBQWMsZUFBZSxRQUFRO0FBQUEsTUFDOUM7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNIO0FBQUEsRUFFQSxVQUFVO0FBQ1IsVUFBTSxFQUFFLFVBQVUsSUFBSTtBQUN0QixjQUFVLE1BQU07QUFBQSxFQUNsQjtBQUNGOzs7QVQxSkEsSUFBcUIscUJBQXJCLGNBQWdELHdCQUFPO0FBQUEsRUFRL0MsU0FBUztBQUFBO0FBQ2IsY0FBUSxJQUFJLDhCQUE4QjtBQUcxQyxZQUFNLEtBQUssYUFBYTtBQUd4QixXQUFLLGtCQUFrQixJQUFJLGdCQUFnQixLQUFLLEtBQUssS0FBSyxRQUFRO0FBQ2xFLFdBQUssZUFBZSxJQUFJLHFCQUFxQixLQUFLLEtBQUssS0FBSyxRQUFRO0FBQ3BFLFdBQUssc0JBQXNCLElBQUksb0JBQW9CLEtBQUssR0FBRztBQUMzRCxXQUFLLGlCQUFpQixJQUFJLGVBQWUsS0FBSyxHQUFHO0FBQ2pELFdBQUssd0JBQXdCLElBQUksc0JBQXNCLEtBQUssR0FBRztBQUcvRCxXQUFLLGNBQWMsSUFBSSx1QkFBdUIsS0FBSyxLQUFLLElBQUksQ0FBQztBQUc3RCxXQUFLLDZCQUE2QjtBQUdsQyxXQUFLLFdBQVc7QUFBQSxRQUNkLElBQUk7QUFBQSxRQUNKLE1BQU07QUFBQSxRQUNOLFVBQVUsTUFBTTtBQUNkLGVBQUssZ0JBQWdCLGlCQUFpQjtBQUFBLFFBQ3hDO0FBQUEsTUFDRixDQUFDO0FBRUQsV0FBSyxXQUFXO0FBQUEsUUFDZCxJQUFJO0FBQUEsUUFDSixNQUFNO0FBQUEsUUFDTixVQUFVLE1BQU07QUFDZCxlQUFLLGdCQUFnQixnQkFBZ0I7QUFBQSxRQUN2QztBQUFBLE1BQ0YsQ0FBQztBQUVELFdBQUssV0FBVztBQUFBLFFBQ2QsSUFBSTtBQUFBLFFBQ0osTUFBTTtBQUFBLFFBQ04sVUFBVSxNQUFNO0FBQ2QsZUFBSyxhQUFhLHFCQUFxQjtBQUFBLFFBQ3pDO0FBQUEsTUFDRixDQUFDO0FBRUQsV0FBSyxXQUFXO0FBQUEsUUFDZCxJQUFJO0FBQUEsUUFDSixNQUFNO0FBQUEsUUFDTixVQUFVLE1BQVk7QUFFcEIsZ0JBQU0sY0FBYyxLQUFLLElBQUksVUFBVSxjQUFjO0FBQ3JELGNBQUksV0FBVztBQUNmLGNBQUksYUFBYTtBQUdqQixjQUFJLGFBQWE7QUFDZixrQkFBTSxRQUFRLEtBQUssSUFBSSxjQUFjLGFBQWEsV0FBVztBQUM3RCxnQkFBSSxTQUFTLE1BQU0sYUFBYTtBQUM5Qix5QkFBVyxNQUFNLFlBQVksYUFBYTtBQUMxQywyQkFBYSxNQUFNLFlBQVksZUFBZSxNQUFNLFlBQVksU0FBUyxZQUFZO0FBQUEsWUFDdkY7QUFBQSxVQUNGO0FBR0EsY0FBSSxDQUFDLFVBQVU7QUFDYixrQkFBTSxtQkFBbUIsTUFBTSxLQUFLLGtCQUFrQixpQ0FBaUM7QUFDdkYsZ0JBQUksQ0FBQztBQUFrQjtBQUN2Qix1QkFBVztBQUNYLHlCQUFhO0FBQUEsVUFDZjtBQUdBLGNBQUk7QUFBQSxZQUNGLEtBQUs7QUFBQSxZQUNMO0FBQUEsWUFDQTtBQUFBLFlBQ0EsQ0FBTyxhQUFhQyxhQUFZQyxjQUFhO0FBRTNDLHlCQUFXLGNBQWMsYUFBYTtBQUNwQyxvQkFBSSxXQUFXLEtBQUssS0FBSyxNQUFNO0FBQUk7QUFHbkMsc0JBQU0sb0JBQW9CLEtBQUs7QUFBQSxrQkFDN0I7QUFBQSxrQkFDQUQ7QUFBQSxrQkFDQUM7QUFBQSxnQkFDRjtBQUNBLHNCQUFNLFdBQVcsR0FBR0EsZUFBYyxXQUFXLEtBQUssUUFBUSxpQkFBaUIsR0FBRztBQUM5RSxzQkFBTSxXQUFXLEdBQUdBLGFBQVk7QUFFaEMsb0JBQUk7QUFDRix3QkFBTSxLQUFLLElBQUksTUFBTSxPQUFPLFVBQVUsaUJBQWlCO0FBQ3ZELDBCQUFRLElBQUksNEJBQTRCLFVBQVU7QUFBQSxnQkFDcEQsU0FBUyxPQUFQO0FBQ0EsMEJBQVEsTUFBTSxrQ0FBa0MsYUFBYSxLQUFLO0FBQUEsZ0JBQ3BFO0FBQUEsY0FDRjtBQUFBLFlBQ0Y7QUFBQSxVQUNGLEVBQUUsS0FBSztBQUFBLFFBQ1Q7QUFBQSxNQUNGLENBQUM7QUFFRCxXQUFLLFdBQVc7QUFBQSxRQUNkLElBQUk7QUFBQSxRQUNKLE1BQU07QUFBQSxRQUNOLFVBQVUsTUFBWTtBQUNwQixnQkFBTSxXQUFXLE1BQU0sS0FBSztBQUFBLFlBQzFCO0FBQUEsVUFDRjtBQUNBLGNBQUksVUFBVTtBQUNaLGtCQUFNLEtBQUssb0JBQW9CLDBCQUEwQixRQUFRO0FBQUEsVUFDbkU7QUFBQSxRQUNGO0FBQUEsTUFDRixDQUFDO0FBRUQsV0FBSyxXQUFXO0FBQUEsUUFDZCxJQUFJO0FBQUEsUUFDSixNQUFNO0FBQUEsUUFDTixVQUFVLE1BQVk7QUFDcEIsZ0JBQU0sV0FBVyxNQUFNLEtBQUs7QUFBQSxZQUMxQjtBQUFBLFVBQ0Y7QUFDQSxjQUFJLFVBQVU7QUFDWixrQkFBTSxLQUFLLGVBQWUsMEJBQTBCLFFBQVE7QUFBQSxVQUM5RDtBQUFBLFFBQ0Y7QUFBQSxNQUNGLENBQUM7QUFFRCxXQUFLLFdBQVc7QUFBQSxRQUNkLElBQUk7QUFBQSxRQUNKLE1BQU07QUFBQSxRQUNOLFVBQVUsTUFBWTtBQUNwQixnQkFBTSxPQUFPLE1BQU0sS0FBSztBQUFBLFlBQ3RCO0FBQUEsVUFDRjtBQUNBLGdCQUFNLEtBQUssc0JBQXNCO0FBQUEsWUFDL0IsUUFBUTtBQUFBLFVBQ1Y7QUFBQSxRQUNGO0FBQUEsTUFDRixDQUFDO0FBR0QsV0FBSyxpQkFBaUIsRUFBRSxRQUFRLGVBQWU7QUFBQSxJQUNqRDtBQUFBO0FBQUEsRUFFYyxrQkFBa0IsU0FBeUM7QUFBQTtBQUN2RSxZQUFNLFdBQVcsT0FBTyxVQUFVLHNCQUFzQjtBQUN4RCxhQUFPLFdBQVcsU0FBUyxLQUFLLElBQUk7QUFBQSxJQUN0QztBQUFBO0FBQUEsRUFFYyxjQUFjLFNBQXlDO0FBQUE7QUFDbkUsWUFBTSxPQUFPO0FBQUEsUUFDWCxVQUFVO0FBQUEsTUFDWjtBQUNBLGFBQU8sT0FBTyxLQUFLLEtBQUssSUFBSTtBQUFBLElBQzlCO0FBQUE7QUFBQSxFQUVBLDhCQUE4QixZQUFpQixZQUFvQixVQUEwQjtBQUUzRixXQUFPO0FBQUEsYUFDRTtBQUFBLG1CQUNNLFdBQVcsUUFBUTtBQUFBLFlBQzFCLFdBQVc7QUFBQSxVQUNiLFdBQVcsVUFBVTtBQUFBO0FBQUEsV0FFcEIsSUFBSSxLQUFLLEVBQUUsWUFBWTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BSTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFJRixXQUFXLFVBQVU7QUFBQTtBQUFBO0FBQUEsRUFHdkIsV0FBVztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNRyxJQUFJLEtBQUssRUFBRSxZQUFZLEVBQUUsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLFdBQzFDLFdBQVc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFZbEIsV0FBVyxhQUFhLFdBQVc7QUFBQTtBQUFBLEVBRXJDO0FBQUEsRUFFQSxXQUFXO0FBQ1QsWUFBUSxJQUFJLGdDQUFnQztBQUFBLEVBQzlDO0FBQUEsRUFFTSwrQkFBK0I7QUFBQTtBQUVuQyxZQUFNLGtCQUFtQixLQUFLLElBQVksUUFBUSxVQUFVLG9CQUFvQjtBQUNoRixVQUFJLENBQUMsaUJBQWlCO0FBQ3BCLGdCQUFRLElBQUksc0VBQXNFO0FBQ2xGO0FBQUEsTUFDRjtBQUdBLFVBQUk7QUFFRixZQUFJLG1CQUFtQixnQkFBZ0IsV0FBVztBQUVoRCxjQUFJLENBQUMsZ0JBQWdCLFVBQVUsV0FBVztBQUN4Qyw0QkFBZ0IsVUFBVSxZQUFZLENBQUM7QUFBQSxVQUN6QztBQUdBLDBCQUFnQixVQUFVLFVBQVUsWUFBWSxJQUFJLENBQU8sS0FBVSxJQUFTLFNBQWM7QUFDMUYsbUJBQU8sS0FBSyxrQkFBa0IsS0FBSyxJQUFJLElBQUk7QUFBQSxVQUM3QztBQUVBLDBCQUFnQixVQUFVLFVBQVUsYUFBYSxJQUFJLENBQU8sT0FBWTtBQUN0RSxtQkFBTyxLQUFLLG1CQUFtQixFQUFFO0FBQUEsVUFDbkM7QUFFQSxrQkFBUSxJQUFJLDJEQUEyRDtBQUFBLFFBQ3pFLE9BQU87QUFDTCxrQkFBUSxNQUFNLHFFQUFxRTtBQUFBLFFBQ3JGO0FBQUEsTUFDRixTQUFTLEdBQVA7QUFDQSxnQkFBUSxNQUFNLDBDQUEwQyxDQUFDO0FBQUEsTUFDM0Q7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVNLGtCQUFrQixLQUFVLElBQVMsTUFBYztBQUFBO0FBbFEzRDtBQW9RSSxVQUFJLGVBQThCO0FBQ2xDLFVBQUksYUFBNEI7QUFDaEMsVUFBSSxTQUFTO0FBQ2IsVUFBSSxXQUFXO0FBQ2YsVUFBSSxhQUFhO0FBQ2pCLFVBQUksWUFBWTtBQUVoQixVQUFJO0FBRUYsWUFBSSxNQUFNLEdBQUcsVUFBVSxHQUFHLE9BQU8sUUFBUTtBQUN2QyxnQkFBTSxtQkFBbUIsTUFBTSxHQUFHLE9BQU8sT0FBTyw0QkFBNEIsRUFBRTtBQUM5RSx5QkFBZSxtQkFBbUIsbUJBQW1CO0FBRXJELGdCQUFNLGlCQUFpQixNQUFNLEdBQUcsT0FBTyxPQUFPLDBCQUEwQixFQUFFO0FBQzFFLHVCQUFhLGlCQUFpQixpQkFBaUI7QUFFL0MsbUJBQVMsTUFBTSxHQUFHLE9BQU87QUFBQSxZQUN2QixNQUFNLElBQUksTUFBTSxpQkFBaUIsRUFBRSxPQUFPLENBQUMsTUFBVyxFQUFFLEtBQUssU0FBUyxTQUFTLENBQUMsRUFBRSxJQUFJLENBQUMsTUFBVyxFQUFFLFFBQVE7QUFBQSxZQUM1RyxJQUFJLE1BQU0saUJBQWlCLEVBQUUsT0FBTyxDQUFDLE1BQVcsRUFBRSxLQUFLLFNBQVMsU0FBUyxDQUFDO0FBQUEsVUFDNUU7QUFFQSxzQkFBWSxNQUFNLEdBQUcsT0FBTztBQUFBLFlBQzFCLENBQUMsVUFBVSxXQUFXLGFBQWEsWUFBWSxVQUFVLFlBQVksUUFBUTtBQUFBLFlBQzdFLENBQUMsVUFBVSxXQUFXLGFBQWEsWUFBWSxVQUFVLFlBQVksUUFBUTtBQUFBLFlBQzdFO0FBQUEsVUFDRjtBQUFBLFFBQ0YsT0FBTztBQUVMLHlCQUFlO0FBQ2YsdUJBQWE7QUFDYixtQkFBUztBQUNULHNCQUFZO0FBQUEsUUFDZDtBQUFBLE1BQ0YsU0FBUyxHQUFQO0FBQ0EsZ0JBQVEsTUFBTSxnQ0FBZ0MsQ0FBQztBQUUvQyx1QkFBZTtBQUNmLHFCQUFhO0FBQ2IsaUJBQVM7QUFDVCxvQkFBWTtBQUFBLE1BQ2Q7QUFHQSxpQkFBVyxTQUFTLE9BQU8sTUFBTSxLQUFLLEVBQUUsQ0FBQyxLQUFLLFNBQVM7QUFDdkQsbUJBQWEsV0FBVSxZQUFPLE1BQU0sS0FBSyxFQUFFLENBQUMsTUFBckIsbUJBQXdCLFVBQVUsR0FBRyxPQUFNLFFBQVM7QUFFM0UsYUFBTztBQUFBLFFBQ0wsUUFBUTtBQUFBO0FBQUEsUUFDUjtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRU0sbUJBQW1CLElBQVM7QUFBQTtBQTdUcEM7QUE4VEksVUFBSSxnQkFBZ0I7QUFDcEIsVUFBSSxTQUFTO0FBQ2IsVUFBSSxXQUFXO0FBQ2YsVUFBSSxhQUFhO0FBQ2pCLFVBQUksT0FBTztBQUVYLFVBQUk7QUFDRixZQUFJLE1BQU0sR0FBRyxVQUFVLEdBQUcsT0FBTyxRQUFRO0FBQ3ZDLDJCQUFnQixNQUFNLEdBQUcsT0FBTyxPQUFPLGtCQUFrQixFQUFFLE1BQUs7QUFDaEUsbUJBQVMsTUFBTSxHQUFHLE9BQU87QUFBQSxZQUN2QixNQUFNLEdBQUcsSUFBSSxNQUFNLGlCQUFpQixFQUFFLE9BQU8sQ0FBQyxNQUFXLEVBQUUsS0FBSyxTQUFTLFNBQVMsQ0FBQyxFQUFFLElBQUksQ0FBQyxNQUFXLEVBQUUsUUFBUTtBQUFBLFlBQy9HLEdBQUcsSUFBSSxNQUFNLGlCQUFpQixFQUFFLE9BQU8sQ0FBQyxNQUFXLEVBQUUsS0FBSyxTQUFTLFNBQVMsQ0FBQztBQUFBLFVBQy9FO0FBQ0EsZ0JBQU0sY0FBYyxHQUFHLElBQUksTUFBTSxTQUFTLEVBQUUsT0FBTyxDQUFDLE1BQVcsRUFBRSxjQUFjLEtBQUssRUFBRSxJQUFJLENBQUMsTUFBVyxFQUFFLFFBQVE7QUFDaEgsaUJBQU8sTUFBTSxHQUFHLE9BQU8sVUFBVSxhQUFhLGFBQWEsVUFBVTtBQUFBLFFBQ3ZFLE9BQU87QUFFTCwwQkFBZ0I7QUFDaEIsbUJBQVM7QUFDVCxpQkFBTztBQUFBLFFBQ1Q7QUFBQSxNQUNGLFNBQVMsR0FBUDtBQUNBLGdCQUFRLE1BQU0saUNBQWlDLENBQUM7QUFFaEQsd0JBQWdCO0FBQ2hCLGlCQUFTO0FBQ1QsZUFBTztBQUFBLE1BQ1Q7QUFHQSxpQkFBVyxTQUFTLE9BQU8sTUFBTSxLQUFLLEVBQUUsQ0FBQyxLQUFLLFNBQVM7QUFDdkQsbUJBQWEsV0FBVSxZQUFPLE1BQU0sS0FBSyxFQUFFLENBQUMsTUFBckIsbUJBQXdCLFVBQVUsR0FBRyxPQUFNLFFBQVM7QUFFM0UsYUFBTztBQUFBLFFBQ0w7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRU0sZUFBZTtBQUFBO0FBQ25CLFdBQUssV0FBVyxPQUFPLE9BQU8sQ0FBQyxHQUFHLGtCQUFrQixNQUFNLEtBQUssU0FBUyxDQUFDO0FBQUEsSUFDM0U7QUFBQTtBQUFBLEVBRU0sZUFBZTtBQUFBO0FBQ25CLFlBQU0sS0FBSyxTQUFTLEtBQUssUUFBUTtBQUFBLElBQ25DO0FBQUE7QUFDRjsiLAogICJuYW1lcyI6IFsiaW1wb3J0X29ic2lkaWFuIiwgImltcG9ydF9vYnNpZGlhbiIsICJpbXBvcnRfb2JzaWRpYW4iLCAiaW1wb3J0X29ic2lkaWFuIiwgImltcG9ydF9vYnNpZGlhbiIsICJpbXBvcnRfb2JzaWRpYW4iLCAiaW1wb3J0X29ic2lkaWFuIiwgImltcG9ydF9vYnNpZGlhbiIsICJjb3Vyc2VOYW1lIiwgImNvdXJzZUlkIl0KfQo=
