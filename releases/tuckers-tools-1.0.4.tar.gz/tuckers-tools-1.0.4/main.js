var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __async = (__this, __arguments, generator) => {
  return new Promise((resolve, reject) => {
    var fulfilled = (value) => {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    };
    var rejected = (value) => {
      try {
        step(generator.throw(value));
      } catch (e) {
        reject(e);
      }
    };
    var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
    step((generator = generator.apply(__this, __arguments)).next());
  });
};

// main.ts
var main_exports = {};
__export(main_exports, {
  default: () => TuckersToolsPlugin
});
module.exports = __toCommonJS(main_exports);
var import_obsidian3 = require("obsidian");

// settings.ts
var import_obsidian = require("obsidian");

// utils.ts
function validateDate(dateString) {
  const regex = /^\d{4}-\d{2}-\d{2}$/;
  if (!dateString.match(regex))
    return false;
  const date = new Date(dateString);
  const timestamp = date.getTime();
  if (typeof timestamp !== "number" || isNaN(timestamp))
    return false;
  return dateString === date.toISOString().split("T")[0];
}

// settings.ts
var DEFAULT_SETTINGS = {
  baseDirectory: "/",
  semesterStartDate: new Date().toISOString().split("T")[0],
  semesterEndDate: new Date(new Date().setMonth(new Date().getMonth() + 4)).toISOString().split("T")[0],
  schoolName: "University",
  schoolAbbreviation: "U",
  templateFolder: "Tuckers Tools",
  useEnhancedMetadata: false
};
var TuckersToolsSettingTab = class extends import_obsidian.PluginSettingTab {
  constructor(app, plugin) {
    super(app, plugin);
    this.plugin = plugin;
  }
  display() {
    const { containerEl } = this;
    containerEl.empty();
    containerEl.createEl("h2", { text: "Tuckers Tools Settings" });
    new import_obsidian.Setting(containerEl).setName("Base Directory").setDesc("Root directory for course content organization").addText((text) => text.setPlaceholder("/").setValue(this.plugin.settings.baseDirectory).onChange((value) => __async(this, null, function* () {
      this.plugin.settings.baseDirectory = value;
      yield this.plugin.saveSettings();
    })));
    const startDateSetting = new import_obsidian.Setting(containerEl).setName("Semester Start Date").setDesc("Start date for the current semester").addText((text) => text.setPlaceholder("YYYY-MM-DD").setValue(this.plugin.settings.semesterStartDate).onChange((value) => __async(this, null, function* () {
      if (value && !validateDate(value)) {
        startDateSetting.setDesc("Start date for the current semester (Invalid date format)");
      } else {
        startDateSetting.setDesc("Start date for the current semester");
      }
      this.plugin.settings.semesterStartDate = value;
      yield this.plugin.saveSettings();
    })));
    const endDateSetting = new import_obsidian.Setting(containerEl).setName("Semester End Date").setDesc("End date for the current semester").addText((text) => text.setPlaceholder("YYYY-MM-DD").setValue(this.plugin.settings.semesterEndDate).onChange((value) => __async(this, null, function* () {
      if (value && !validateDate(value)) {
        endDateSetting.setDesc("End date for the current semester (Invalid date format)");
      } else {
        endDateSetting.setDesc("End date for the current semester");
      }
      this.plugin.settings.semesterEndDate = value;
      yield this.plugin.saveSettings();
    })));
    new import_obsidian.Setting(containerEl).setName("School Name").setDesc("Name of your institution").addText((text) => text.setPlaceholder("University").setValue(this.plugin.settings.schoolName).onChange((value) => __async(this, null, function* () {
      this.plugin.settings.schoolName = value;
      yield this.plugin.saveSettings();
    })));
    new import_obsidian.Setting(containerEl).setName("School Abbreviation").setDesc("Abbreviation for your institution").addText((text) => text.setPlaceholder("U").setValue(this.plugin.settings.schoolAbbreviation).onChange((value) => __async(this, null, function* () {
      this.plugin.settings.schoolAbbreviation = value;
      yield this.plugin.saveSettings();
    })));
    new import_obsidian.Setting(containerEl).setName("Template Folder").setDesc("Subfolder within your Templater template folder for Tuckers Tools templates").addText((text) => text.setPlaceholder("Tuckers Tools").setValue(this.plugin.settings.templateFolder).onChange((value) => __async(this, null, function* () {
      this.plugin.settings.templateFolder = value;
      yield this.plugin.saveSettings();
    })));
    new import_obsidian.Setting(containerEl).setName("Use Enhanced Metadata").setDesc("Enable enhanced metadata fields for new notes (existing notes remain unchanged)").addToggle((toggle) => toggle.setValue(this.plugin.settings.useEnhancedMetadata).onChange((value) => __async(this, null, function* () {
      this.plugin.settings.useEnhancedMetadata = value;
      yield this.plugin.saveSettings();
    })));
  }
};

// templateManager.ts
var import_obsidian2 = require("obsidian");
var TemplateManager = class {
  constructor(app, settings) {
    this.app = app;
    this.settings = settings;
    this.manifest = {
      version: "1.0.0",
      templates: {
        "Courses/Create Course Homepage.md": "1.0.0",
        "Courses/Course Index.md": "1.0.0",
        "Modules/Create Module.md": "1.0.0",
        "Chapters/Create Chapter.md": "1.0.0",
        "Assignments/Create Assignment.md": "1.0.0",
        "Daily/Daily Note.md": "1.0.0",
        "Utilities/Vocabulary Entry.md": "1.0.0",
        "Utilities/Due Date Entry.md": "1.0.0"
      },
      plugin_version: "1.0.0",
      release_notes: "Initial release of Tuckers Tools templates"
    };
  }
  installTemplates() {
    return __async(this, null, function* () {
      const templaterPlugin = this.app.plugins.plugins["templater-obsidian"];
      if (!templaterPlugin) {
        new import_obsidian2.Notice("Templater plugin not found. Please install and enable the Templater plugin first.");
        console.error("Templater plugin not found. Please install and enable the Templater plugin first.");
        return;
      }
      const templaterSettings = templaterPlugin.settings;
      const templateFolderPath = templaterSettings["template_folder"] || templaterSettings["templateFolder"] || templaterSettings["templateFolderPath"];
      if (!templateFolderPath) {
        new import_obsidian2.Notice("Template folder not configured in Templater settings. Please configure it in Templater settings first.");
        console.error("Template folder not configured in Templater settings. Please configure it in Templater settings first.");
        return;
      }
      const fullTemplatePath = `${templateFolderPath}/${this.settings.templateFolder}`;
      try {
        yield this.app.vault.createFolder(fullTemplatePath);
        console.log(`Created template folder: ${fullTemplatePath}`);
      } catch (e) {
        console.log(`Template folder already exists or created: ${fullTemplatePath}`);
      }
      const subdirs = ["Courses", "Modules", "Chapters", "Assignments", "Daily", "Utilities"];
      for (const subdir of subdirs) {
        try {
          const subPath = `${fullTemplatePath}/${subdir}`;
          yield this.app.vault.createFolder(subPath);
          console.log(`Created subdirectory: ${subPath}`);
        } catch (e) {
          console.log(`Subdirectory already exists: ${fullTemplatePath}/${subdir}`);
        }
      }
      yield this.installCourseTemplates(fullTemplatePath);
      yield this.installModuleTemplates(fullTemplatePath);
      yield this.installChapterTemplates(fullTemplatePath);
      yield this.installAssignmentTemplates(fullTemplatePath);
      yield this.installDailyTemplates(fullTemplatePath);
      yield this.installUtilityTemplates(fullTemplatePath);
      yield this.createREADME(fullTemplatePath);
      yield this.createTemplateManifest(fullTemplatePath);
      new import_obsidian2.Notice("Tuckers Tools templates installed successfully!");
      console.log("Tuckers Tools templates installed successfully");
    });
  }
  createTemplateManifest(basePath) {
    return __async(this, null, function* () {
      const manifestPath = `${basePath}/template-manifest.json`;
      const manifestContent = JSON.stringify(this.manifest, null, 2);
      try {
        const existingManifest = this.app.vault.getAbstractFileByPath(manifestPath);
        if (existingManifest) {
          const file = existingManifest;
          yield this.app.vault.modify(file, manifestContent);
          console.log(`Updated template manifest: ${manifestPath}`);
          return;
        }
        yield this.app.vault.create(manifestPath, manifestContent);
        console.log(`Created template manifest: ${manifestPath}`);
      } catch (e) {
        new import_obsidian2.Notice(`Error creating template manifest ${manifestPath}`);
        console.error(`Error creating template manifest ${manifestPath}:`, e);
      }
    });
  }
  checkForTemplateUpdates() {
    return __async(this, null, function* () {
      console.log("Checking for template updates");
      return false;
    });
  }
  updateTemplates() {
    return __async(this, null, function* () {
      console.log("Updating templates");
      const templaterPlugin = this.app.plugins.plugins["templater-obsidian"];
      if (!templaterPlugin) {
        new import_obsidian2.Notice("Templater plugin not found. Please install and enable the Templater plugin first.");
        console.error("Templater plugin not found. Please install and enable the Templater plugin first.");
        return;
      }
      const templaterSettings = templaterPlugin.settings;
      const templateFolderPath = templaterSettings["template_folder"] || templaterSettings["templateFolder"] || templaterSettings["templateFolderPath"];
      if (!templateFolderPath) {
        new import_obsidian2.Notice("Template folder not configured in Templater settings. Please configure it in Templater settings first.");
        console.error("Template folder not configured in Templater settings. Please configure it in Templater settings first.");
        return;
      }
      const fullTemplatePath = `${templateFolderPath}/${this.settings.templateFolder}`;
      yield this.installCourseTemplates(fullTemplatePath);
      yield this.installModuleTemplates(fullTemplatePath);
      yield this.installChapterTemplates(fullTemplatePath);
      yield this.installAssignmentTemplates(fullTemplatePath);
      yield this.installDailyTemplates(fullTemplatePath);
      yield this.installUtilityTemplates(fullTemplatePath);
      yield this.createREADME(fullTemplatePath);
      yield this.createTemplateManifest(fullTemplatePath);
      new import_obsidian2.Notice("Tuckers Tools templates updated successfully!");
      console.log("Tuckers Tools templates updated successfully");
    });
  }
  installCourseTemplates(basePath) {
    return __async(this, null, function* () {
      const coursePath = `${basePath}/Courses`;
      const courseHomepageTemplate = this.generateCourseHomepageTemplate();
      yield this.writeTemplateFile(`${coursePath}/Create Course Homepage.md`, courseHomepageTemplate);
      const courseIndexTemplate = this.generateCourseIndexTemplate();
      yield this.writeTemplateFile(`${coursePath}/Course Index.md`, courseIndexTemplate);
    });
  }
  installModuleTemplates(basePath) {
    return __async(this, null, function* () {
      const modulePath = `${basePath}/Modules`;
      const moduleTemplate = this.generateModuleTemplate();
      yield this.writeTemplateFile(`${modulePath}/Create Module.md`, moduleTemplate);
    });
  }
  installChapterTemplates(basePath) {
    return __async(this, null, function* () {
      const chapterPath = `${basePath}/Chapters`;
      const chapterTemplate = this.generateChapterTemplate();
      yield this.writeTemplateFile(`${chapterPath}/Create Chapter.md`, chapterTemplate);
    });
  }
  installAssignmentTemplates(basePath) {
    return __async(this, null, function* () {
      const assignmentPath = `${basePath}/Assignments`;
      const assignmentTemplate = this.generateAssignmentTemplate();
      yield this.writeTemplateFile(`${assignmentPath}/Create Assignment.md`, assignmentTemplate);
    });
  }
  installDailyTemplates(basePath) {
    return __async(this, null, function* () {
      const dailyPath = `${basePath}/Daily`;
      const dailyNoteTemplate = this.generateDailyNoteTemplate();
      yield this.writeTemplateFile(`${dailyPath}/Daily Note.md`, dailyNoteTemplate);
    });
  }
  installUtilityTemplates(basePath) {
    return __async(this, null, function* () {
      const utilityPath = `${basePath}/Utilities`;
      const vocabTemplate = this.generateVocabularyTemplate();
      yield this.writeTemplateFile(`${utilityPath}/Vocabulary Entry.md`, vocabTemplate);
      const dueDateTemplate = this.generateDueDateTemplate();
      yield this.writeTemplateFile(`${utilityPath}/Due Date Entry.md`, dueDateTemplate);
    });
  }
  writeTemplateFile(path, content) {
    return __async(this, null, function* () {
      try {
        const existingFile = this.app.vault.getAbstractFileByPath(path);
        if (existingFile) {
          console.log(`Updating existing template file: ${path}`);
          const file = existingFile;
          yield this.app.vault.modify(file, content);
          return;
        }
        yield this.app.vault.create(path, content);
        console.log(`Created template file: ${path}`);
      } catch (e) {
        new import_obsidian2.Notice(`Error creating template file ${path}`);
        console.error(`Error creating template file ${path}:`, e);
      }
    });
  }
  generateCourseHomepageTemplate() {
    return `---
${this.settings.useEnhancedMetadata ? `course_id: <% courseId %>
course_name: <% courseName %>
course_term: <% courseSeason %> <% courseYear %>
course_year: <% courseYear %>
course_semester: <% courseSeason %>
content_type: course_homepage
school: ${this.settings.schoolName}
school_abbreviation: ${this.settings.schoolAbbreviation}` : `course_id: <% courseId %>
title: <% courseName %>`}
created: <% tp.date.now("YYYY-MM-DD[T]HH:mm:ssZ") %>
tags: 
  - course_home
  - education
  - <% courseId %>
  - ${this.settings.schoolAbbreviation}/<% courseYear %>/<% courseSeason %>/<% courseId %>
---

<%*
const { exec } = require("child_process");
let courseName = await tp.system.prompt("Course Name (e.g. PSI-101 - Intro to Psych)")
let courseSeason = await tp.system.suggester(["Fall","Winter","Spring","Summer"],["Fall","Winter","Spring","Summer"], "Season")
let courseYear = await tp.system.prompt("Year")
let courseId = courseName.split(' - ')[0]
await tp.file.move(\`/\${courseYear}/\${courseSeason}/\${courseName}/\${courseName}\`)
try {await app.vault.createFolder(\`\${courseYear}/\${courseSeason}/\${courseName}/Attachments\`)} catch (e) {}
%>

# <% courseName %>

## Course Information
**Course ID**: <% courseId %>
**Term**: <% courseSeason %> <% courseYear %>
**School**: ${this.settings.schoolName}

## Instructor
**Name**: 
**Email**: 
**Office Hours**: 

## Course Description

## Learning Objectives

## Required Texts
\`\`\`meta-bind-js-view
{texts} as texts
---
const availableTexts = app.vault.getFiles().filter(file => file.extension == 'pdf').map(f => f?.name)
const escapeRegex = /[,"\`'()]/g;
options = availableTexts.map(t => \`option([[\${t.replace(escapeRegex,\`\\\\$1\`)}]], \${t.replace(escapeRegex,\`\\\\$1\`)})\` )
const str = \\\`INPUT[inlineListSuggester(\${options.join(", ")}):texts]\\\`
return engine.markdown.create(str)
\`\`\`

## Schedule

## Assignments

## Resources

## Vocabulary
\`\`\`dataviewjs
// Vocabulary aggregation code would go here
\`\`\`

## Due Dates
\`\`\`dataviewjs
// Due dates aggregation code would go here
\`\`\``;
  }
  generateCourseIndexTemplate() {
    return `---
content_type: course_index
tags:
  - index
---

# Course Index

## Modules

## Chapters

## Assignments

## Resources

## Vocabulary

## Due Dates`;
  }
  generateModuleTemplate() {
    return `---
${this.settings.useEnhancedMetadata ? `course_id: <% courseId %>
module_number: <% moduleNumber %>
week_number: <% weekNumber %>
class_day: <% dayOfWeek %>
content_type: module
parent_course: "[[<% course %>]]"` : `course_id: <% courseId %>
module_number: <% moduleNumber %>
week_number: <% weekNumber %>
class_day: <% dayOfWeek %>`}
created: <% tp.date.now("YYYY-MM-DD[T]HH:mm:ssZ") %>
tags:
  - education
  - <% courseId %>
  - module
---

<%*
const { season, moduleNumber, weekNumber, course, courseId, discipline, dayOfWeek } = await tp.user.new_module(app, tp, "2025");
let title = courseId
if (moduleNumber && weekNumber) { title = \`M\${moduleNumber}/W\${weekNumber}\`}
else if (moduleNumber) { title = \`M\${moduleNumber}\` } 
else if (weekNumber) { title = \`W\${weekNumber}\`}
%>

# [[<% course %>]] - <% title %> - <% dayOfWeek %>

## Learning Objectives

## Reading Assignment

## Lecture Notes

## Discussion Questions

## Assignments
| Date | Assignment | Status |
| ---- | ---------- | ------ |
|      |            |        |

## Vocabulary

## Additional Resources`;
  }
  generateChapterTemplate() {
    return `---
${this.settings.useEnhancedMetadata ? `course_id: <% courseId %>
chapter_number: <% chapterNumber %>
content_type: chapter
parent_course: "[[<% course %>]]"
text_reference: "[[<% text %>]]"` : `course_id: <% courseId %>
chapter_number: <% chapterNumber %>`}
created: <% tp.date.now("YYYY-MM-DD[T]HH:mm:ssZ") %>
tags:
  - education
  - <% courseId %>
  - chapter
---

<%*
const { chapterNumber, course, courseId, discipline, text} = await tp.user.new_chapter(tp);
%>

# [[<% text %>]] - Chapter <% chapterNumber %>

## Summary

## Key Concepts

## Vocabulary
- 

## Notes

## Discussion Questions

## Further Reading`;
  }
  generateAssignmentTemplate() {
    return `---
${this.settings.useEnhancedMetadata ? `course_id: <% courseId %>
assignment_type: <% assignmentType %>
due_date: <% dueDate %>
points: <% points %>
content_type: assignment
parent_course: "[[<% course %>]]"` : `course_id: <% courseId %>
assignment_type: <% assignmentType %>
due_date: <% dueDate %>`}
created: <% tp.date.now("YYYY-MM-DD[T]HH:mm:ssZ") %>
status: pending
tags:
  - education
  - <% courseId %>
  - assignment
---

# <% assignmentName %> - <% courseId %>

## Description

## Instructions

## Due Date
**Assigned**: <% tp.date.now("YYYY-MM-DD") %>
**Due**: <% dueDate %>

## Submission

## Grading Criteria

## Resources`;
  }
  generateDailyNoteTemplate() {
    return `---
content_type: daily_note
date: <% tp.date.now("YYYY-MM-DD") %>
tags:
  - daily
  - <% tp.date.now("YYYY") %>
  - <% tp.date.now("MM") %>
  - <% tp.date.now("DD") %>
---

# <% tp.date.now("YYYY-MM-DD - dddd") %>

<< [[<% tp.date.yesterday("YYYY-MM-DD") %>]] | [[<% tp.date.tomorrow("YYYY-MM-DD") %>]] >>

## Today's Focus

## Courses Worked On
- 

## Tasks Completed
- [ ] 

## Vocabulary Reviewed
- 

## Assignments Due
- 

## Learning Achievements

## Challenges

## Tomorrow's Plan

## Reflection`;
  }
  generateVocabularyTemplate() {
    return `## <% term %>
**Term**: <% term %>
**Part of Speech**: 
**Definition**: 
**Context**: 
**Examples**: 
**Related Terms**: 
**See Also**:`;
  }
  generateDueDateTemplate() {
    return `| <% dueDate %> | <% assignment %> | <% status %> |`;
  }
  createREADME(basePath) {
    return __async(this, null, function* () {
      const readmeContent = `# Tuckers Tools Templates

This directory contains templates for the Tuckers Tools Obsidian plugin.

## Template Categories

- **Courses**: Templates for creating and organizing courses
- **Modules**: Templates for course modules
- **Chapters**: Templates for chapter notes
- **Assignments**: Templates for assignments
- **Daily**: Templates for daily notes
- **Utilities**: Helper templates

## Usage

These templates are designed to work with the Tuckers Tools plugin. To use them:

1. Install the Tuckers Tools plugin
2. Configure your settings in the plugin settings tab
3. Use the "Insert Template" command to apply these templates to new notes

## Customization

Feel free to customize these templates to suit your needs. The plugin will not overwrite your changes when updating templates.`;
      yield this.writeTemplateFile(`${basePath}/README.md`, readmeContent);
    });
  }
};

// main.ts
var TuckersToolsPlugin = class extends import_obsidian3.Plugin {
  onload() {
    return __async(this, null, function* () {
      console.log("Loading Tuckers Tools plugin");
      yield this.loadSettings();
      this.templateManager = new TemplateManager(this.app, this.settings);
      this.addSettingTab(new TuckersToolsSettingTab(this.app, this));
      this.addCommand({
        id: "install-templates",
        name: "Install/Update Tuckers Tools Templates",
        callback: () => {
          this.templateManager.installTemplates();
        }
      });
      this.addCommand({
        id: "update-templates",
        name: "Update Tuckers Tools Templates",
        callback: () => {
          this.templateManager.updateTemplates();
        }
      });
      this.addStatusBarItem().setText("Tuckers Tools");
    });
  }
  onunload() {
    console.log("Unloading Tuckers Tools plugin");
  }
  loadSettings() {
    return __async(this, null, function* () {
      this.settings = Object.assign({}, DEFAULT_SETTINGS, yield this.loadData());
    });
  }
  saveSettings() {
    return __async(this, null, function* () {
      yield this.saveData(this.settings);
    });
  }
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsibWFpbi50cyIsICJzZXR0aW5ncy50cyIsICJ1dGlscy50cyIsICJ0ZW1wbGF0ZU1hbmFnZXIudHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbImltcG9ydCB7IFBsdWdpbiB9IGZyb20gJ29ic2lkaWFuJztcbmltcG9ydCB7IFR1Y2tlcnNUb29sc1NldHRpbmdzLCBERUZBVUxUX1NFVFRJTkdTLCBUdWNrZXJzVG9vbHNTZXR0aW5nVGFiIH0gZnJvbSAnLi9zZXR0aW5ncyc7XG5pbXBvcnQgeyBUZW1wbGF0ZU1hbmFnZXIgfSBmcm9tICcuL3RlbXBsYXRlTWFuYWdlcic7XG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFR1Y2tlcnNUb29sc1BsdWdpbiBleHRlbmRzIFBsdWdpbiB7XG4gIHNldHRpbmdzOiBUdWNrZXJzVG9vbHNTZXR0aW5ncztcbiAgdGVtcGxhdGVNYW5hZ2VyOiBUZW1wbGF0ZU1hbmFnZXI7XG5cbiAgYXN5bmMgb25sb2FkKCkge1xuICAgIGNvbnNvbGUubG9nKCdMb2FkaW5nIFR1Y2tlcnMgVG9vbHMgcGx1Z2luJyk7XG5cbiAgICAvLyBMb2FkIHNldHRpbmdzXG4gICAgYXdhaXQgdGhpcy5sb2FkU2V0dGluZ3MoKTtcblxuICAgIC8vIEluaXRpYWxpemUgdGVtcGxhdGUgbWFuYWdlclxuICAgIHRoaXMudGVtcGxhdGVNYW5hZ2VyID0gbmV3IFRlbXBsYXRlTWFuYWdlcih0aGlzLmFwcCwgdGhpcy5zZXR0aW5ncyk7XG5cbiAgICAvLyBBZGQgc2V0dGluZ3MgdGFiXG4gICAgdGhpcy5hZGRTZXR0aW5nVGFiKG5ldyBUdWNrZXJzVG9vbHNTZXR0aW5nVGFiKHRoaXMuYXBwLCB0aGlzKSk7XG5cbiAgICAvLyBBZGQgY29tbWFuZHNcbiAgICB0aGlzLmFkZENvbW1hbmQoe1xuICAgICAgaWQ6ICdpbnN0YWxsLXRlbXBsYXRlcycsXG4gICAgICBuYW1lOiAnSW5zdGFsbC9VcGRhdGUgVHVja2VycyBUb29scyBUZW1wbGF0ZXMnLFxuICAgICAgY2FsbGJhY2s6ICgpID0+IHtcbiAgICAgICAgdGhpcy50ZW1wbGF0ZU1hbmFnZXIuaW5zdGFsbFRlbXBsYXRlcygpO1xuICAgICAgfVxuICAgIH0pO1xuXG4gICAgdGhpcy5hZGRDb21tYW5kKHtcbiAgICAgIGlkOiAndXBkYXRlLXRlbXBsYXRlcycsXG4gICAgICBuYW1lOiAnVXBkYXRlIFR1Y2tlcnMgVG9vbHMgVGVtcGxhdGVzJyxcbiAgICAgIGNhbGxiYWNrOiAoKSA9PiB7XG4gICAgICAgIHRoaXMudGVtcGxhdGVNYW5hZ2VyLnVwZGF0ZVRlbXBsYXRlcygpO1xuICAgICAgfVxuICAgIH0pO1xuXG4gICAgLy8gQWRkIHN0YXR1cyBiYXIgaXRlbVxuICAgIHRoaXMuYWRkU3RhdHVzQmFySXRlbSgpLnNldFRleHQoJ1R1Y2tlcnMgVG9vbHMnKTtcbiAgfVxuXG4gIG9udW5sb2FkKCkge1xuICAgIGNvbnNvbGUubG9nKCdVbmxvYWRpbmcgVHVja2VycyBUb29scyBwbHVnaW4nKTtcbiAgfVxuXG4gIGFzeW5jIGxvYWRTZXR0aW5ncygpIHtcbiAgICB0aGlzLnNldHRpbmdzID0gT2JqZWN0LmFzc2lnbih7fSwgREVGQVVMVF9TRVRUSU5HUywgYXdhaXQgdGhpcy5sb2FkRGF0YSgpKTtcbiAgfVxuXG4gIGFzeW5jIHNhdmVTZXR0aW5ncygpIHtcbiAgICBhd2FpdCB0aGlzLnNhdmVEYXRhKHRoaXMuc2V0dGluZ3MpO1xuICB9XG59IiwgImltcG9ydCB7IEFwcCwgUGx1Z2luU2V0dGluZ1RhYiwgU2V0dGluZyB9IGZyb20gJ29ic2lkaWFuJztcbmltcG9ydCBUdWNrZXJzVG9vbHNQbHVnaW4gZnJvbSAnLi9tYWluJztcbmltcG9ydCB7IHZhbGlkYXRlRGF0ZSB9IGZyb20gJy4vdXRpbHMnO1xuXG5leHBvcnQgaW50ZXJmYWNlIFR1Y2tlcnNUb29sc1NldHRpbmdzIHtcbiAgYmFzZURpcmVjdG9yeTogc3RyaW5nO1xuICBzZW1lc3RlclN0YXJ0RGF0ZTogc3RyaW5nO1xuICBzZW1lc3RlckVuZERhdGU6IHN0cmluZztcbiAgc2Nob29sTmFtZTogc3RyaW5nO1xuICBzY2hvb2xBYmJyZXZpYXRpb246IHN0cmluZztcbiAgdGVtcGxhdGVGb2xkZXI6IHN0cmluZztcbiAgdXNlRW5oYW5jZWRNZXRhZGF0YTogYm9vbGVhbjtcbn1cblxuZXhwb3J0IGNvbnN0IERFRkFVTFRfU0VUVElOR1M6IFR1Y2tlcnNUb29sc1NldHRpbmdzID0ge1xuICBiYXNlRGlyZWN0b3J5OiAnLycsXG4gIHNlbWVzdGVyU3RhcnREYXRlOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc3BsaXQoJ1QnKVswXSxcbiAgc2VtZXN0ZXJFbmREYXRlOiBuZXcgRGF0ZShuZXcgRGF0ZSgpLnNldE1vbnRoKG5ldyBEYXRlKCkuZ2V0TW9udGgoKSArIDQpKS50b0lTT1N0cmluZygpLnNwbGl0KCdUJylbMF0sXG4gIHNjaG9vbE5hbWU6ICdVbml2ZXJzaXR5JyxcbiAgc2Nob29sQWJicmV2aWF0aW9uOiAnVScsXG4gIHRlbXBsYXRlRm9sZGVyOiAnVHVja2VycyBUb29scycsXG4gIHVzZUVuaGFuY2VkTWV0YWRhdGE6IGZhbHNlXG59XG5cbmV4cG9ydCBjbGFzcyBUdWNrZXJzVG9vbHNTZXR0aW5nVGFiIGV4dGVuZHMgUGx1Z2luU2V0dGluZ1RhYiB7XG4gIHBsdWdpbjogVHVja2Vyc1Rvb2xzUGx1Z2luO1xuXG4gIGNvbnN0cnVjdG9yKGFwcDogQXBwLCBwbHVnaW46IFR1Y2tlcnNUb29sc1BsdWdpbikge1xuICAgIHN1cGVyKGFwcCwgcGx1Z2luKTtcbiAgICB0aGlzLnBsdWdpbiA9IHBsdWdpbjtcbiAgfVxuXG4gIGRpc3BsYXkoKTogdm9pZCB7XG4gICAgY29uc3QgeyBjb250YWluZXJFbCB9ID0gdGhpcztcblxuICAgIGNvbnRhaW5lckVsLmVtcHR5KCk7XG5cbiAgICBjb250YWluZXJFbC5jcmVhdGVFbCgnaDInLCB7IHRleHQ6ICdUdWNrZXJzIFRvb2xzIFNldHRpbmdzJyB9KTtcblxuICAgIG5ldyBTZXR0aW5nKGNvbnRhaW5lckVsKVxuICAgICAgLnNldE5hbWUoJ0Jhc2UgRGlyZWN0b3J5JylcbiAgICAgIC5zZXREZXNjKCdSb290IGRpcmVjdG9yeSBmb3IgY291cnNlIGNvbnRlbnQgb3JnYW5pemF0aW9uJylcbiAgICAgIC5hZGRUZXh0KHRleHQgPT4gdGV4dFxuICAgICAgICAuc2V0UGxhY2Vob2xkZXIoJy8nKVxuICAgICAgICAuc2V0VmFsdWUodGhpcy5wbHVnaW4uc2V0dGluZ3MuYmFzZURpcmVjdG9yeSlcbiAgICAgICAgLm9uQ2hhbmdlKGFzeW5jICh2YWx1ZSkgPT4ge1xuICAgICAgICAgIHRoaXMucGx1Z2luLnNldHRpbmdzLmJhc2VEaXJlY3RvcnkgPSB2YWx1ZTtcbiAgICAgICAgICBhd2FpdCB0aGlzLnBsdWdpbi5zYXZlU2V0dGluZ3MoKTtcbiAgICAgICAgfSkpO1xuXG4gICAgY29uc3Qgc3RhcnREYXRlU2V0dGluZyA9IG5ldyBTZXR0aW5nKGNvbnRhaW5lckVsKVxuICAgICAgLnNldE5hbWUoJ1NlbWVzdGVyIFN0YXJ0IERhdGUnKVxuICAgICAgLnNldERlc2MoJ1N0YXJ0IGRhdGUgZm9yIHRoZSBjdXJyZW50IHNlbWVzdGVyJylcbiAgICAgIC5hZGRUZXh0KHRleHQgPT4gdGV4dFxuICAgICAgICAuc2V0UGxhY2Vob2xkZXIoJ1lZWVktTU0tREQnKVxuICAgICAgICAuc2V0VmFsdWUodGhpcy5wbHVnaW4uc2V0dGluZ3Muc2VtZXN0ZXJTdGFydERhdGUpXG4gICAgICAgIC5vbkNoYW5nZShhc3luYyAodmFsdWUpID0+IHtcbiAgICAgICAgICBpZiAodmFsdWUgJiYgIXZhbGlkYXRlRGF0ZSh2YWx1ZSkpIHtcbiAgICAgICAgICAgIHN0YXJ0RGF0ZVNldHRpbmcuc2V0RGVzYygnU3RhcnQgZGF0ZSBmb3IgdGhlIGN1cnJlbnQgc2VtZXN0ZXIgKEludmFsaWQgZGF0ZSBmb3JtYXQpJyk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHN0YXJ0RGF0ZVNldHRpbmcuc2V0RGVzYygnU3RhcnQgZGF0ZSBmb3IgdGhlIGN1cnJlbnQgc2VtZXN0ZXInKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgdGhpcy5wbHVnaW4uc2V0dGluZ3Muc2VtZXN0ZXJTdGFydERhdGUgPSB2YWx1ZTtcbiAgICAgICAgICBhd2FpdCB0aGlzLnBsdWdpbi5zYXZlU2V0dGluZ3MoKTtcbiAgICAgICAgfSkpO1xuXG4gICAgY29uc3QgZW5kRGF0ZVNldHRpbmcgPSBuZXcgU2V0dGluZyhjb250YWluZXJFbClcbiAgICAgIC5zZXROYW1lKCdTZW1lc3RlciBFbmQgRGF0ZScpXG4gICAgICAuc2V0RGVzYygnRW5kIGRhdGUgZm9yIHRoZSBjdXJyZW50IHNlbWVzdGVyJylcbiAgICAgIC5hZGRUZXh0KHRleHQgPT4gdGV4dFxuICAgICAgICAuc2V0UGxhY2Vob2xkZXIoJ1lZWVktTU0tREQnKVxuICAgICAgICAuc2V0VmFsdWUodGhpcy5wbHVnaW4uc2V0dGluZ3Muc2VtZXN0ZXJFbmREYXRlKVxuICAgICAgICAub25DaGFuZ2UoYXN5bmMgKHZhbHVlKSA9PiB7XG4gICAgICAgICAgaWYgKHZhbHVlICYmICF2YWxpZGF0ZURhdGUodmFsdWUpKSB7XG4gICAgICAgICAgICBlbmREYXRlU2V0dGluZy5zZXREZXNjKCdFbmQgZGF0ZSBmb3IgdGhlIGN1cnJlbnQgc2VtZXN0ZXIgKEludmFsaWQgZGF0ZSBmb3JtYXQpJyk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGVuZERhdGVTZXR0aW5nLnNldERlc2MoJ0VuZCBkYXRlIGZvciB0aGUgY3VycmVudCBzZW1lc3RlcicpO1xuICAgICAgICAgIH1cbiAgICAgICAgICB0aGlzLnBsdWdpbi5zZXR0aW5ncy5zZW1lc3RlckVuZERhdGUgPSB2YWx1ZTtcbiAgICAgICAgICBhd2FpdCB0aGlzLnBsdWdpbi5zYXZlU2V0dGluZ3MoKTtcbiAgICAgICAgfSkpO1xuXG4gICAgbmV3IFNldHRpbmcoY29udGFpbmVyRWwpXG4gICAgICAuc2V0TmFtZSgnU2Nob29sIE5hbWUnKVxuICAgICAgLnNldERlc2MoJ05hbWUgb2YgeW91ciBpbnN0aXR1dGlvbicpXG4gICAgICAuYWRkVGV4dCh0ZXh0ID0+IHRleHRcbiAgICAgICAgLnNldFBsYWNlaG9sZGVyKCdVbml2ZXJzaXR5JylcbiAgICAgICAgLnNldFZhbHVlKHRoaXMucGx1Z2luLnNldHRpbmdzLnNjaG9vbE5hbWUpXG4gICAgICAgIC5vbkNoYW5nZShhc3luYyAodmFsdWUpID0+IHtcbiAgICAgICAgICB0aGlzLnBsdWdpbi5zZXR0aW5ncy5zY2hvb2xOYW1lID0gdmFsdWU7XG4gICAgICAgICAgYXdhaXQgdGhpcy5wbHVnaW4uc2F2ZVNldHRpbmdzKCk7XG4gICAgICAgIH0pKTtcblxuICAgIG5ldyBTZXR0aW5nKGNvbnRhaW5lckVsKVxuICAgICAgLnNldE5hbWUoJ1NjaG9vbCBBYmJyZXZpYXRpb24nKVxuICAgICAgLnNldERlc2MoJ0FiYnJldmlhdGlvbiBmb3IgeW91ciBpbnN0aXR1dGlvbicpXG4gICAgICAuYWRkVGV4dCh0ZXh0ID0+IHRleHRcbiAgICAgICAgLnNldFBsYWNlaG9sZGVyKCdVJylcbiAgICAgICAgLnNldFZhbHVlKHRoaXMucGx1Z2luLnNldHRpbmdzLnNjaG9vbEFiYnJldmlhdGlvbilcbiAgICAgICAgLm9uQ2hhbmdlKGFzeW5jICh2YWx1ZSkgPT4ge1xuICAgICAgICAgIHRoaXMucGx1Z2luLnNldHRpbmdzLnNjaG9vbEFiYnJldmlhdGlvbiA9IHZhbHVlO1xuICAgICAgICAgIGF3YWl0IHRoaXMucGx1Z2luLnNhdmVTZXR0aW5ncygpO1xuICAgICAgICB9KSk7XG5cbiAgICBuZXcgU2V0dGluZyhjb250YWluZXJFbClcbiAgICAgIC5zZXROYW1lKCdUZW1wbGF0ZSBGb2xkZXInKVxuICAgICAgLnNldERlc2MoJ1N1YmZvbGRlciB3aXRoaW4geW91ciBUZW1wbGF0ZXIgdGVtcGxhdGUgZm9sZGVyIGZvciBUdWNrZXJzIFRvb2xzIHRlbXBsYXRlcycpXG4gICAgICAuYWRkVGV4dCh0ZXh0ID0+IHRleHRcbiAgICAgICAgLnNldFBsYWNlaG9sZGVyKCdUdWNrZXJzIFRvb2xzJylcbiAgICAgICAgLnNldFZhbHVlKHRoaXMucGx1Z2luLnNldHRpbmdzLnRlbXBsYXRlRm9sZGVyKVxuICAgICAgICAub25DaGFuZ2UoYXN5bmMgKHZhbHVlKSA9PiB7XG4gICAgICAgICAgdGhpcy5wbHVnaW4uc2V0dGluZ3MudGVtcGxhdGVGb2xkZXIgPSB2YWx1ZTtcbiAgICAgICAgICBhd2FpdCB0aGlzLnBsdWdpbi5zYXZlU2V0dGluZ3MoKTtcbiAgICAgICAgfSkpO1xuXG4gICAgbmV3IFNldHRpbmcoY29udGFpbmVyRWwpXG4gICAgICAuc2V0TmFtZSgnVXNlIEVuaGFuY2VkIE1ldGFkYXRhJylcbiAgICAgIC5zZXREZXNjKCdFbmFibGUgZW5oYW5jZWQgbWV0YWRhdGEgZmllbGRzIGZvciBuZXcgbm90ZXMgKGV4aXN0aW5nIG5vdGVzIHJlbWFpbiB1bmNoYW5nZWQpJylcbiAgICAgIC5hZGRUb2dnbGUodG9nZ2xlID0+IHRvZ2dsZVxuICAgICAgICAuc2V0VmFsdWUodGhpcy5wbHVnaW4uc2V0dGluZ3MudXNlRW5oYW5jZWRNZXRhZGF0YSlcbiAgICAgICAgLm9uQ2hhbmdlKGFzeW5jICh2YWx1ZSkgPT4ge1xuICAgICAgICAgIHRoaXMucGx1Z2luLnNldHRpbmdzLnVzZUVuaGFuY2VkTWV0YWRhdGEgPSB2YWx1ZTtcbiAgICAgICAgICBhd2FpdCB0aGlzLnBsdWdpbi5zYXZlU2V0dGluZ3MoKTtcbiAgICAgICAgfSkpO1xuICB9XG59IiwgIi8vIFV0aWxpdHkgZnVuY3Rpb25zIGZvciBUdWNrZXJzIFRvb2xzIHBsdWdpblxuXG5leHBvcnQgZnVuY3Rpb24gZm9ybWF0RGF0ZShkYXRlOiBEYXRlKTogc3RyaW5nIHtcbiAgcmV0dXJuIGRhdGUudG9JU09TdHJpbmcoKS5zcGxpdCgnVCcpWzBdO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gYWRkRGF5cyhkYXRlOiBEYXRlLCBkYXlzOiBudW1iZXIpOiBEYXRlIHtcbiAgY29uc3QgcmVzdWx0ID0gbmV3IERhdGUoZGF0ZSk7XG4gIHJlc3VsdC5zZXREYXRlKHJlc3VsdC5nZXREYXRlKCkgKyBkYXlzKTtcbiAgcmV0dXJuIHJlc3VsdDtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGlzQmV0d2VlbihkYXRlOiBEYXRlLCBzdGFydDogRGF0ZSwgZW5kOiBEYXRlKTogYm9vbGVhbiB7XG4gIHJldHVybiBkYXRlID49IHN0YXJ0ICYmIGRhdGUgPD0gZW5kO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gc2x1Z2lmeSh0ZXh0OiBzdHJpbmcpOiBzdHJpbmcge1xuICByZXR1cm4gdGV4dFxuICAgIC50b0xvd2VyQ2FzZSgpXG4gICAgLnRyaW0oKVxuICAgIC5ub3JtYWxpemUoJ05GRCcpXG4gICAgLnJlcGxhY2UoL1tcXHUwMzAwLVxcdTAzNmZdL2csICcnKVxuICAgIC5yZXBsYWNlKC9bXmEtejAtOVxccy1dL2csICcnKVxuICAgIC5yZXBsYWNlKC9bXFxzLV0rL2csICctJylcbiAgICAucmVwbGFjZSgvXi0rfC0rJC9nLCAnJyk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBnZXRDb3Vyc2VJZEZyb21QYXRoKHBhdGg6IHN0cmluZyk6IHN0cmluZyB8IG51bGwge1xuICAvLyBFeHRyYWN0IGNvdXJzZSBJRCBmcm9tIHBhdGggbGlrZSBcIjIwMjUvRmFsbC9QU0ktMTAxLy4uLlwiXG4gIGNvbnN0IHBhcnRzID0gcGF0aC5zcGxpdCgnLycpO1xuICBmb3IgKGNvbnN0IHBhcnQgb2YgcGFydHMpIHtcbiAgICBpZiAocGFydC5tYXRjaCgvXltBLVpdezIsNH0tXFxkezN9JC8pKSB7XG4gICAgICByZXR1cm4gcGFydDtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIG51bGw7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiB2YWxpZGF0ZURhdGUoZGF0ZVN0cmluZzogc3RyaW5nKTogYm9vbGVhbiB7XG4gIGNvbnN0IHJlZ2V4ID0gL15cXGR7NH0tXFxkezJ9LVxcZHsyfSQvO1xuICBpZiAoIWRhdGVTdHJpbmcubWF0Y2gocmVnZXgpKSByZXR1cm4gZmFsc2U7XG4gIFxuICBjb25zdCBkYXRlID0gbmV3IERhdGUoZGF0ZVN0cmluZyk7XG4gIGNvbnN0IHRpbWVzdGFtcCA9IGRhdGUuZ2V0VGltZSgpO1xuICBcbiAgaWYgKHR5cGVvZiB0aW1lc3RhbXAgIT09ICdudW1iZXInIHx8IGlzTmFOKHRpbWVzdGFtcCkpIHJldHVybiBmYWxzZTtcbiAgXG4gIHJldHVybiBkYXRlU3RyaW5nID09PSBkYXRlLnRvSVNPU3RyaW5nKCkuc3BsaXQoJ1QnKVswXTtcbn0iLCAiaW1wb3J0IHsgQXBwLCBOb3RpY2UgfSBmcm9tICdvYnNpZGlhbic7XG5pbXBvcnQgeyBUdWNrZXJzVG9vbHNTZXR0aW5ncyB9IGZyb20gJy4vc2V0dGluZ3MnO1xuXG5pbnRlcmZhY2UgVGVtcGxhdGVNYW5pZmVzdCB7XG4gIHZlcnNpb246IHN0cmluZztcbiAgdGVtcGxhdGVzOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+O1xuICBwbHVnaW5fdmVyc2lvbjogc3RyaW5nO1xuICByZWxlYXNlX25vdGVzOiBzdHJpbmc7XG59XG5cbmV4cG9ydCBjbGFzcyBUZW1wbGF0ZU1hbmFnZXIge1xuICBhcHA6IEFwcDtcbiAgc2V0dGluZ3M6IFR1Y2tlcnNUb29sc1NldHRpbmdzO1xuICBtYW5pZmVzdDogVGVtcGxhdGVNYW5pZmVzdDtcblxuICBjb25zdHJ1Y3RvcihhcHA6IEFwcCwgc2V0dGluZ3M6IFR1Y2tlcnNUb29sc1NldHRpbmdzKSB7XG4gICAgdGhpcy5hcHAgPSBhcHA7XG4gICAgdGhpcy5zZXR0aW5ncyA9IHNldHRpbmdzO1xuICAgIHRoaXMubWFuaWZlc3QgPSB7XG4gICAgICB2ZXJzaW9uOiBcIjEuMC4wXCIsXG4gICAgICB0ZW1wbGF0ZXM6IHtcbiAgICAgICAgXCJDb3Vyc2VzL0NyZWF0ZSBDb3Vyc2UgSG9tZXBhZ2UubWRcIjogXCIxLjAuMFwiLFxuICAgICAgICBcIkNvdXJzZXMvQ291cnNlIEluZGV4Lm1kXCI6IFwiMS4wLjBcIixcbiAgICAgICAgXCJNb2R1bGVzL0NyZWF0ZSBNb2R1bGUubWRcIjogXCIxLjAuMFwiLFxuICAgICAgICBcIkNoYXB0ZXJzL0NyZWF0ZSBDaGFwdGVyLm1kXCI6IFwiMS4wLjBcIixcbiAgICAgICAgXCJBc3NpZ25tZW50cy9DcmVhdGUgQXNzaWdubWVudC5tZFwiOiBcIjEuMC4wXCIsXG4gICAgICAgIFwiRGFpbHkvRGFpbHkgTm90ZS5tZFwiOiBcIjEuMC4wXCIsXG4gICAgICAgIFwiVXRpbGl0aWVzL1ZvY2FidWxhcnkgRW50cnkubWRcIjogXCIxLjAuMFwiLFxuICAgICAgICBcIlV0aWxpdGllcy9EdWUgRGF0ZSBFbnRyeS5tZFwiOiBcIjEuMC4wXCJcbiAgICAgIH0sXG4gICAgICBwbHVnaW5fdmVyc2lvbjogXCIxLjAuMFwiLFxuICAgICAgcmVsZWFzZV9ub3RlczogXCJJbml0aWFsIHJlbGVhc2Ugb2YgVHVja2VycyBUb29scyB0ZW1wbGF0ZXNcIlxuICAgIH07XG4gIH1cblxuICBhc3luYyBpbnN0YWxsVGVtcGxhdGVzKCkge1xuICAgIC8vIEdldCBUZW1wbGF0ZXIgcGx1Z2luIHNldHRpbmdzIHRvIGZpbmQgdGVtcGxhdGUgZm9sZGVyXG4gICAgY29uc3QgdGVtcGxhdGVyUGx1Z2luID0gKHRoaXMuYXBwIGFzIGFueSkucGx1Z2lucy5wbHVnaW5zWyd0ZW1wbGF0ZXItb2JzaWRpYW4nXTtcbiAgICBpZiAoIXRlbXBsYXRlclBsdWdpbikge1xuICAgICAgbmV3IE5vdGljZSgnVGVtcGxhdGVyIHBsdWdpbiBub3QgZm91bmQuIFBsZWFzZSBpbnN0YWxsIGFuZCBlbmFibGUgdGhlIFRlbXBsYXRlciBwbHVnaW4gZmlyc3QuJyk7XG4gICAgICBjb25zb2xlLmVycm9yKCdUZW1wbGF0ZXIgcGx1Z2luIG5vdCBmb3VuZC4gUGxlYXNlIGluc3RhbGwgYW5kIGVuYWJsZSB0aGUgVGVtcGxhdGVyIHBsdWdpbiBmaXJzdC4nKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBjb25zdCB0ZW1wbGF0ZXJTZXR0aW5ncyA9IHRlbXBsYXRlclBsdWdpbi5zZXR0aW5ncztcbiAgICAvLyBUcnkgZGlmZmVyZW50IHBvc3NpYmxlIHByb3BlcnR5IG5hbWVzIGZvciB0ZW1wbGF0ZSBmb2xkZXJcbiAgICBjb25zdCB0ZW1wbGF0ZUZvbGRlclBhdGggPSB0ZW1wbGF0ZXJTZXR0aW5nc1sndGVtcGxhdGVfZm9sZGVyJ10gfHwgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZW1wbGF0ZXJTZXR0aW5nc1sndGVtcGxhdGVGb2xkZXInXSB8fCBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRlbXBsYXRlclNldHRpbmdzWyd0ZW1wbGF0ZUZvbGRlclBhdGgnXTtcbiAgICBcbiAgICBpZiAoIXRlbXBsYXRlRm9sZGVyUGF0aCkge1xuICAgICAgbmV3IE5vdGljZSgnVGVtcGxhdGUgZm9sZGVyIG5vdCBjb25maWd1cmVkIGluIFRlbXBsYXRlciBzZXR0aW5ncy4gUGxlYXNlIGNvbmZpZ3VyZSBpdCBpbiBUZW1wbGF0ZXIgc2V0dGluZ3MgZmlyc3QuJyk7XG4gICAgICBjb25zb2xlLmVycm9yKCdUZW1wbGF0ZSBmb2xkZXIgbm90IGNvbmZpZ3VyZWQgaW4gVGVtcGxhdGVyIHNldHRpbmdzLiBQbGVhc2UgY29uZmlndXJlIGl0IGluIFRlbXBsYXRlciBzZXR0aW5ncyBmaXJzdC4nKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBjb25zdCBmdWxsVGVtcGxhdGVQYXRoID0gYCR7dGVtcGxhdGVGb2xkZXJQYXRofS8ke3RoaXMuc2V0dGluZ3MudGVtcGxhdGVGb2xkZXJ9YDtcbiAgICBcbiAgICAvLyBDcmVhdGUgdGhlIG1haW4gdGVtcGxhdGUgZm9sZGVyIGlmIGl0IGRvZXNuJ3QgZXhpc3RcbiAgICB0cnkge1xuICAgICAgYXdhaXQgdGhpcy5hcHAudmF1bHQuY3JlYXRlRm9sZGVyKGZ1bGxUZW1wbGF0ZVBhdGgpO1xuICAgICAgY29uc29sZS5sb2coYENyZWF0ZWQgdGVtcGxhdGUgZm9sZGVyOiAke2Z1bGxUZW1wbGF0ZVBhdGh9YCk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgLy8gRm9sZGVyIG1pZ2h0IGFscmVhZHkgZXhpc3QsIHdoaWNoIGlzIGZpbmVcbiAgICAgIGNvbnNvbGUubG9nKGBUZW1wbGF0ZSBmb2xkZXIgYWxyZWFkeSBleGlzdHMgb3IgY3JlYXRlZDogJHtmdWxsVGVtcGxhdGVQYXRofWApO1xuICAgIH1cblxuICAgIC8vIENyZWF0ZSBzdWJkaXJlY3Rvcmllc1xuICAgIGNvbnN0IHN1YmRpcnMgPSBbJ0NvdXJzZXMnLCAnTW9kdWxlcycsICdDaGFwdGVycycsICdBc3NpZ25tZW50cycsICdEYWlseScsICdVdGlsaXRpZXMnXTtcbiAgICBmb3IgKGNvbnN0IHN1YmRpciBvZiBzdWJkaXJzKSB7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBzdWJQYXRoID0gYCR7ZnVsbFRlbXBsYXRlUGF0aH0vJHtzdWJkaXJ9YDtcbiAgICAgICAgYXdhaXQgdGhpcy5hcHAudmF1bHQuY3JlYXRlRm9sZGVyKHN1YlBhdGgpO1xuICAgICAgICBjb25zb2xlLmxvZyhgQ3JlYXRlZCBzdWJkaXJlY3Rvcnk6ICR7c3ViUGF0aH1gKTtcbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgLy8gRm9sZGVyIG1pZ2h0IGFscmVhZHkgZXhpc3QsIHdoaWNoIGlzIGZpbmVcbiAgICAgICAgY29uc29sZS5sb2coYFN1YmRpcmVjdG9yeSBhbHJlYWR5IGV4aXN0czogJHtmdWxsVGVtcGxhdGVQYXRofS8ke3N1YmRpcn1gKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBJbnN0YWxsIHRlbXBsYXRlc1xuICAgIGF3YWl0IHRoaXMuaW5zdGFsbENvdXJzZVRlbXBsYXRlcyhmdWxsVGVtcGxhdGVQYXRoKTtcbiAgICBhd2FpdCB0aGlzLmluc3RhbGxNb2R1bGVUZW1wbGF0ZXMoZnVsbFRlbXBsYXRlUGF0aCk7XG4gICAgYXdhaXQgdGhpcy5pbnN0YWxsQ2hhcHRlclRlbXBsYXRlcyhmdWxsVGVtcGxhdGVQYXRoKTtcbiAgICBhd2FpdCB0aGlzLmluc3RhbGxBc3NpZ25tZW50VGVtcGxhdGVzKGZ1bGxUZW1wbGF0ZVBhdGgpO1xuICAgIGF3YWl0IHRoaXMuaW5zdGFsbERhaWx5VGVtcGxhdGVzKGZ1bGxUZW1wbGF0ZVBhdGgpO1xuICAgIGF3YWl0IHRoaXMuaW5zdGFsbFV0aWxpdHlUZW1wbGF0ZXMoZnVsbFRlbXBsYXRlUGF0aCk7XG4gICAgXG4gICAgLy8gQ3JlYXRlIFJFQURNRVxuICAgIGF3YWl0IHRoaXMuY3JlYXRlUkVBRE1FKGZ1bGxUZW1wbGF0ZVBhdGgpO1xuICAgIFxuICAgIC8vIENyZWF0ZSB0ZW1wbGF0ZSBtYW5pZmVzdFxuICAgIGF3YWl0IHRoaXMuY3JlYXRlVGVtcGxhdGVNYW5pZmVzdChmdWxsVGVtcGxhdGVQYXRoKTtcbiAgICBcbiAgICBuZXcgTm90aWNlKCdUdWNrZXJzIFRvb2xzIHRlbXBsYXRlcyBpbnN0YWxsZWQgc3VjY2Vzc2Z1bGx5IScpO1xuICAgIGNvbnNvbGUubG9nKCdUdWNrZXJzIFRvb2xzIHRlbXBsYXRlcyBpbnN0YWxsZWQgc3VjY2Vzc2Z1bGx5Jyk7XG4gIH1cblxuICBhc3luYyBjcmVhdGVUZW1wbGF0ZU1hbmlmZXN0KGJhc2VQYXRoOiBzdHJpbmcpIHtcbiAgICBjb25zdCBtYW5pZmVzdFBhdGggPSBgJHtiYXNlUGF0aH0vdGVtcGxhdGUtbWFuaWZlc3QuanNvbmA7XG4gICAgY29uc3QgbWFuaWZlc3RDb250ZW50ID0gSlNPTi5zdHJpbmdpZnkodGhpcy5tYW5pZmVzdCwgbnVsbCwgMik7XG4gICAgXG4gICAgdHJ5IHtcbiAgICAgIC8vIENoZWNrIGlmIG1hbmlmZXN0IGFscmVhZHkgZXhpc3RzXG4gICAgICBjb25zdCBleGlzdGluZ01hbmlmZXN0ID0gdGhpcy5hcHAudmF1bHQuZ2V0QWJzdHJhY3RGaWxlQnlQYXRoKG1hbmlmZXN0UGF0aCk7XG4gICAgICBpZiAoZXhpc3RpbmdNYW5pZmVzdCkge1xuICAgICAgICAvLyBVcGRhdGUgdGhlIGV4aXN0aW5nIG1hbmlmZXN0XG4gICAgICAgIGNvbnN0IGZpbGUgPSBleGlzdGluZ01hbmlmZXN0IGFzIGltcG9ydCgnb2JzaWRpYW4nKS5URmlsZTtcbiAgICAgICAgYXdhaXQgdGhpcy5hcHAudmF1bHQubW9kaWZ5KGZpbGUsIG1hbmlmZXN0Q29udGVudCk7XG4gICAgICAgIGNvbnNvbGUubG9nKGBVcGRhdGVkIHRlbXBsYXRlIG1hbmlmZXN0OiAke21hbmlmZXN0UGF0aH1gKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgXG4gICAgICAvLyBDcmVhdGUgdGhlIG1hbmlmZXN0IGZpbGVcbiAgICAgIGF3YWl0IHRoaXMuYXBwLnZhdWx0LmNyZWF0ZShtYW5pZmVzdFBhdGgsIG1hbmlmZXN0Q29udGVudCk7XG4gICAgICBjb25zb2xlLmxvZyhgQ3JlYXRlZCB0ZW1wbGF0ZSBtYW5pZmVzdDogJHttYW5pZmVzdFBhdGh9YCk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgbmV3IE5vdGljZShgRXJyb3IgY3JlYXRpbmcgdGVtcGxhdGUgbWFuaWZlc3QgJHttYW5pZmVzdFBhdGh9YCk7XG4gICAgICBjb25zb2xlLmVycm9yKGBFcnJvciBjcmVhdGluZyB0ZW1wbGF0ZSBtYW5pZmVzdCAke21hbmlmZXN0UGF0aH06YCwgZSk7XG4gICAgfVxuICB9XG5cbiAgYXN5bmMgY2hlY2tGb3JUZW1wbGF0ZVVwZGF0ZXMoKTogUHJvbWlzZTxib29sZWFuPiB7XG4gICAgLy8gVGhpcyB3b3VsZCBjaGVjayBpZiB0ZW1wbGF0ZXMgbmVlZCB0byBiZSB1cGRhdGVkXG4gICAgLy8gRm9yIG5vdywgd2UnbGwganVzdCByZXR1cm4gZmFsc2VcbiAgICBjb25zb2xlLmxvZyhcIkNoZWNraW5nIGZvciB0ZW1wbGF0ZSB1cGRhdGVzXCIpO1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuXG4gIGFzeW5jIHVwZGF0ZVRlbXBsYXRlcygpIHtcbiAgICAvLyBUaGlzIHdvdWxkIHVwZGF0ZSBleGlzdGluZyB0ZW1wbGF0ZXNcbiAgICAvLyBMZXQncyBpbXBsZW1lbnQgYSBwcm9wZXIgdXBkYXRlIGZ1bmN0aW9uYWxpdHlcbiAgICBjb25zb2xlLmxvZyhcIlVwZGF0aW5nIHRlbXBsYXRlc1wiKTtcbiAgICBcbiAgICAvLyBHZXQgVGVtcGxhdGVyIHBsdWdpbiBzZXR0aW5ncyB0byBmaW5kIHRlbXBsYXRlIGZvbGRlclxuICAgIGNvbnN0IHRlbXBsYXRlclBsdWdpbiA9ICh0aGlzLmFwcCBhcyBhbnkpLnBsdWdpbnMucGx1Z2luc1sndGVtcGxhdGVyLW9ic2lkaWFuJ107XG4gICAgaWYgKCF0ZW1wbGF0ZXJQbHVnaW4pIHtcbiAgICAgIG5ldyBOb3RpY2UoJ1RlbXBsYXRlciBwbHVnaW4gbm90IGZvdW5kLiBQbGVhc2UgaW5zdGFsbCBhbmQgZW5hYmxlIHRoZSBUZW1wbGF0ZXIgcGx1Z2luIGZpcnN0LicpO1xuICAgICAgY29uc29sZS5lcnJvcignVGVtcGxhdGVyIHBsdWdpbiBub3QgZm91bmQuIFBsZWFzZSBpbnN0YWxsIGFuZCBlbmFibGUgdGhlIFRlbXBsYXRlciBwbHVnaW4gZmlyc3QuJyk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgY29uc3QgdGVtcGxhdGVyU2V0dGluZ3MgPSB0ZW1wbGF0ZXJQbHVnaW4uc2V0dGluZ3M7XG4gICAgLy8gVHJ5IGRpZmZlcmVudCBwb3NzaWJsZSBwcm9wZXJ0eSBuYW1lcyBmb3IgdGVtcGxhdGUgZm9sZGVyXG4gICAgY29uc3QgdGVtcGxhdGVGb2xkZXJQYXRoID0gdGVtcGxhdGVyU2V0dGluZ3NbJ3RlbXBsYXRlX2ZvbGRlciddIHx8IFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGVyU2V0dGluZ3NbJ3RlbXBsYXRlRm9sZGVyJ10gfHwgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZW1wbGF0ZXJTZXR0aW5nc1sndGVtcGxhdGVGb2xkZXJQYXRoJ107XG4gICAgXG4gICAgaWYgKCF0ZW1wbGF0ZUZvbGRlclBhdGgpIHtcbiAgICAgIG5ldyBOb3RpY2UoJ1RlbXBsYXRlIGZvbGRlciBub3QgY29uZmlndXJlZCBpbiBUZW1wbGF0ZXIgc2V0dGluZ3MuIFBsZWFzZSBjb25maWd1cmUgaXQgaW4gVGVtcGxhdGVyIHNldHRpbmdzIGZpcnN0LicpO1xuICAgICAgY29uc29sZS5lcnJvcignVGVtcGxhdGUgZm9sZGVyIG5vdCBjb25maWd1cmVkIGluIFRlbXBsYXRlciBzZXR0aW5ncy4gUGxlYXNlIGNvbmZpZ3VyZSBpdCBpbiBUZW1wbGF0ZXIgc2V0dGluZ3MgZmlyc3QuJyk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgY29uc3QgZnVsbFRlbXBsYXRlUGF0aCA9IGAke3RlbXBsYXRlRm9sZGVyUGF0aH0vJHt0aGlzLnNldHRpbmdzLnRlbXBsYXRlRm9sZGVyfWA7XG4gICAgXG4gICAgLy8gVXBkYXRlIHRlbXBsYXRlcyAodGhpcyB3aWxsIG92ZXJ3cml0ZSBleGlzdGluZyBvbmVzKVxuICAgIGF3YWl0IHRoaXMuaW5zdGFsbENvdXJzZVRlbXBsYXRlcyhmdWxsVGVtcGxhdGVQYXRoKTtcbiAgICBhd2FpdCB0aGlzLmluc3RhbGxNb2R1bGVUZW1wbGF0ZXMoZnVsbFRlbXBsYXRlUGF0aCk7XG4gICAgYXdhaXQgdGhpcy5pbnN0YWxsQ2hhcHRlclRlbXBsYXRlcyhmdWxsVGVtcGxhdGVQYXRoKTtcbiAgICBhd2FpdCB0aGlzLmluc3RhbGxBc3NpZ25tZW50VGVtcGxhdGVzKGZ1bGxUZW1wbGF0ZVBhdGgpO1xuICAgIGF3YWl0IHRoaXMuaW5zdGFsbERhaWx5VGVtcGxhdGVzKGZ1bGxUZW1wbGF0ZVBhdGgpO1xuICAgIGF3YWl0IHRoaXMuaW5zdGFsbFV0aWxpdHlUZW1wbGF0ZXMoZnVsbFRlbXBsYXRlUGF0aCk7XG4gICAgXG4gICAgLy8gVXBkYXRlIFJFQURNRVxuICAgIGF3YWl0IHRoaXMuY3JlYXRlUkVBRE1FKGZ1bGxUZW1wbGF0ZVBhdGgpO1xuICAgIFxuICAgIC8vIFVwZGF0ZSB0ZW1wbGF0ZSBtYW5pZmVzdFxuICAgIGF3YWl0IHRoaXMuY3JlYXRlVGVtcGxhdGVNYW5pZmVzdChmdWxsVGVtcGxhdGVQYXRoKTtcbiAgICBcbiAgICBuZXcgTm90aWNlKCdUdWNrZXJzIFRvb2xzIHRlbXBsYXRlcyB1cGRhdGVkIHN1Y2Nlc3NmdWxseSEnKTtcbiAgICBjb25zb2xlLmxvZygnVHVja2VycyBUb29scyB0ZW1wbGF0ZXMgdXBkYXRlZCBzdWNjZXNzZnVsbHknKTtcbiAgfVxuXG4gIGFzeW5jIGluc3RhbGxDb3Vyc2VUZW1wbGF0ZXMoYmFzZVBhdGg6IHN0cmluZykge1xuICAgIGNvbnN0IGNvdXJzZVBhdGggPSBgJHtiYXNlUGF0aH0vQ291cnNlc2A7XG4gICAgXG4gICAgLy8gQ3JlYXRlIENvdXJzZSBIb21lcGFnZSB0ZW1wbGF0ZVxuICAgIGNvbnN0IGNvdXJzZUhvbWVwYWdlVGVtcGxhdGUgPSB0aGlzLmdlbmVyYXRlQ291cnNlSG9tZXBhZ2VUZW1wbGF0ZSgpO1xuICAgIGF3YWl0IHRoaXMud3JpdGVUZW1wbGF0ZUZpbGUoYCR7Y291cnNlUGF0aH0vQ3JlYXRlIENvdXJzZSBIb21lcGFnZS5tZGAsIGNvdXJzZUhvbWVwYWdlVGVtcGxhdGUpO1xuICAgIFxuICAgIC8vIENyZWF0ZSBDb3Vyc2UgSW5kZXggdGVtcGxhdGVcbiAgICBjb25zdCBjb3Vyc2VJbmRleFRlbXBsYXRlID0gdGhpcy5nZW5lcmF0ZUNvdXJzZUluZGV4VGVtcGxhdGUoKTtcbiAgICBhd2FpdCB0aGlzLndyaXRlVGVtcGxhdGVGaWxlKGAke2NvdXJzZVBhdGh9L0NvdXJzZSBJbmRleC5tZGAsIGNvdXJzZUluZGV4VGVtcGxhdGUpO1xuICB9XG5cbiAgYXN5bmMgaW5zdGFsbE1vZHVsZVRlbXBsYXRlcyhiYXNlUGF0aDogc3RyaW5nKSB7XG4gICAgY29uc3QgbW9kdWxlUGF0aCA9IGAke2Jhc2VQYXRofS9Nb2R1bGVzYDtcbiAgICBcbiAgICAvLyBDcmVhdGUgTW9kdWxlIHRlbXBsYXRlXG4gICAgY29uc3QgbW9kdWxlVGVtcGxhdGUgPSB0aGlzLmdlbmVyYXRlTW9kdWxlVGVtcGxhdGUoKTtcbiAgICBhd2FpdCB0aGlzLndyaXRlVGVtcGxhdGVGaWxlKGAke21vZHVsZVBhdGh9L0NyZWF0ZSBNb2R1bGUubWRgLCBtb2R1bGVUZW1wbGF0ZSk7XG4gIH1cblxuICBhc3luYyBpbnN0YWxsQ2hhcHRlclRlbXBsYXRlcyhiYXNlUGF0aDogc3RyaW5nKSB7XG4gICAgY29uc3QgY2hhcHRlclBhdGggPSBgJHtiYXNlUGF0aH0vQ2hhcHRlcnNgO1xuICAgIFxuICAgIC8vIENyZWF0ZSBDaGFwdGVyIHRlbXBsYXRlXG4gICAgY29uc3QgY2hhcHRlclRlbXBsYXRlID0gdGhpcy5nZW5lcmF0ZUNoYXB0ZXJUZW1wbGF0ZSgpO1xuICAgIGF3YWl0IHRoaXMud3JpdGVUZW1wbGF0ZUZpbGUoYCR7Y2hhcHRlclBhdGh9L0NyZWF0ZSBDaGFwdGVyLm1kYCwgY2hhcHRlclRlbXBsYXRlKTtcbiAgfVxuXG4gIGFzeW5jIGluc3RhbGxBc3NpZ25tZW50VGVtcGxhdGVzKGJhc2VQYXRoOiBzdHJpbmcpIHtcbiAgICBjb25zdCBhc3NpZ25tZW50UGF0aCA9IGAke2Jhc2VQYXRofS9Bc3NpZ25tZW50c2A7XG4gICAgXG4gICAgLy8gQ3JlYXRlIEFzc2lnbm1lbnQgdGVtcGxhdGVcbiAgICBjb25zdCBhc3NpZ25tZW50VGVtcGxhdGUgPSB0aGlzLmdlbmVyYXRlQXNzaWdubWVudFRlbXBsYXRlKCk7XG4gICAgYXdhaXQgdGhpcy53cml0ZVRlbXBsYXRlRmlsZShgJHthc3NpZ25tZW50UGF0aH0vQ3JlYXRlIEFzc2lnbm1lbnQubWRgLCBhc3NpZ25tZW50VGVtcGxhdGUpO1xuICB9XG5cbiAgYXN5bmMgaW5zdGFsbERhaWx5VGVtcGxhdGVzKGJhc2VQYXRoOiBzdHJpbmcpIHtcbiAgICBjb25zdCBkYWlseVBhdGggPSBgJHtiYXNlUGF0aH0vRGFpbHlgO1xuICAgIFxuICAgIC8vIENyZWF0ZSBEYWlseSBOb3RlIHRlbXBsYXRlXG4gICAgY29uc3QgZGFpbHlOb3RlVGVtcGxhdGUgPSB0aGlzLmdlbmVyYXRlRGFpbHlOb3RlVGVtcGxhdGUoKTtcbiAgICBhd2FpdCB0aGlzLndyaXRlVGVtcGxhdGVGaWxlKGAke2RhaWx5UGF0aH0vRGFpbHkgTm90ZS5tZGAsIGRhaWx5Tm90ZVRlbXBsYXRlKTtcbiAgfVxuXG4gIGFzeW5jIGluc3RhbGxVdGlsaXR5VGVtcGxhdGVzKGJhc2VQYXRoOiBzdHJpbmcpIHtcbiAgICBjb25zdCB1dGlsaXR5UGF0aCA9IGAke2Jhc2VQYXRofS9VdGlsaXRpZXNgO1xuICAgIFxuICAgIC8vIENyZWF0ZSBWb2NhYnVsYXJ5IEVudHJ5IHRlbXBsYXRlXG4gICAgY29uc3Qgdm9jYWJUZW1wbGF0ZSA9IHRoaXMuZ2VuZXJhdGVWb2NhYnVsYXJ5VGVtcGxhdGUoKTtcbiAgICBhd2FpdCB0aGlzLndyaXRlVGVtcGxhdGVGaWxlKGAke3V0aWxpdHlQYXRofS9Wb2NhYnVsYXJ5IEVudHJ5Lm1kYCwgdm9jYWJUZW1wbGF0ZSk7XG4gICAgXG4gICAgLy8gQ3JlYXRlIER1ZSBEYXRlIEVudHJ5IHRlbXBsYXRlXG4gICAgY29uc3QgZHVlRGF0ZVRlbXBsYXRlID0gdGhpcy5nZW5lcmF0ZUR1ZURhdGVUZW1wbGF0ZSgpO1xuICAgIGF3YWl0IHRoaXMud3JpdGVUZW1wbGF0ZUZpbGUoYCR7dXRpbGl0eVBhdGh9L0R1ZSBEYXRlIEVudHJ5Lm1kYCwgZHVlRGF0ZVRlbXBsYXRlKTtcbiAgfVxuXG4gIGFzeW5jIHdyaXRlVGVtcGxhdGVGaWxlKHBhdGg6IHN0cmluZywgY29udGVudDogc3RyaW5nKSB7XG4gICAgdHJ5IHtcbiAgICAgIC8vIENoZWNrIGlmIGZpbGUgYWxyZWFkeSBleGlzdHNcbiAgICAgIGNvbnN0IGV4aXN0aW5nRmlsZSA9IHRoaXMuYXBwLnZhdWx0LmdldEFic3RyYWN0RmlsZUJ5UGF0aChwYXRoKTtcbiAgICAgIGlmIChleGlzdGluZ0ZpbGUpIHtcbiAgICAgICAgLy8gRm9yIG5vdywgd2UnbGwgdXBkYXRlIGV4aXN0aW5nIHRlbXBsYXRlc1xuICAgICAgICAvLyBJbiBhIHJlYWwgaW1wbGVtZW50YXRpb24sIHdlJ2QgY2hlY2sgdmVyc2lvbnMgYW5kIG9mZmVyIHRvIHVwZGF0ZVxuICAgICAgICBjb25zb2xlLmxvZyhgVXBkYXRpbmcgZXhpc3RpbmcgdGVtcGxhdGUgZmlsZTogJHtwYXRofWApO1xuICAgICAgICBjb25zdCBmaWxlID0gZXhpc3RpbmdGaWxlIGFzIGltcG9ydCgnb2JzaWRpYW4nKS5URmlsZTtcbiAgICAgICAgYXdhaXQgdGhpcy5hcHAudmF1bHQubW9kaWZ5KGZpbGUsIGNvbnRlbnQpO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBcbiAgICAgIC8vIENyZWF0ZSB0aGUgZmlsZVxuICAgICAgYXdhaXQgdGhpcy5hcHAudmF1bHQuY3JlYXRlKHBhdGgsIGNvbnRlbnQpO1xuICAgICAgY29uc29sZS5sb2coYENyZWF0ZWQgdGVtcGxhdGUgZmlsZTogJHtwYXRofWApO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIG5ldyBOb3RpY2UoYEVycm9yIGNyZWF0aW5nIHRlbXBsYXRlIGZpbGUgJHtwYXRofWApO1xuICAgICAgY29uc29sZS5lcnJvcihgRXJyb3IgY3JlYXRpbmcgdGVtcGxhdGUgZmlsZSAke3BhdGh9OmAsIGUpO1xuICAgIH1cbiAgfVxuXG4gIGdlbmVyYXRlQ291cnNlSG9tZXBhZ2VUZW1wbGF0ZSgpOiBzdHJpbmcge1xuICAgIHJldHVybiBgLS0tXG4ke3RoaXMuc2V0dGluZ3MudXNlRW5oYW5jZWRNZXRhZGF0YSA/IGBjb3Vyc2VfaWQ6IDwlIGNvdXJzZUlkICU+XG5jb3Vyc2VfbmFtZTogPCUgY291cnNlTmFtZSAlPlxuY291cnNlX3Rlcm06IDwlIGNvdXJzZVNlYXNvbiAlPiA8JSBjb3Vyc2VZZWFyICU+XG5jb3Vyc2VfeWVhcjogPCUgY291cnNlWWVhciAlPlxuY291cnNlX3NlbWVzdGVyOiA8JSBjb3Vyc2VTZWFzb24gJT5cbmNvbnRlbnRfdHlwZTogY291cnNlX2hvbWVwYWdlXG5zY2hvb2w6ICR7dGhpcy5zZXR0aW5ncy5zY2hvb2xOYW1lfVxuc2Nob29sX2FiYnJldmlhdGlvbjogJHt0aGlzLnNldHRpbmdzLnNjaG9vbEFiYnJldmlhdGlvbn1gIDogYGNvdXJzZV9pZDogPCUgY291cnNlSWQgJT5cbnRpdGxlOiA8JSBjb3Vyc2VOYW1lICU+YH1cbmNyZWF0ZWQ6IDwlIHRwLmRhdGUubm93KFwiWVlZWS1NTS1ERFtUXUhIOm1tOnNzWlwiKSAlPlxudGFnczogXG4gIC0gY291cnNlX2hvbWVcbiAgLSBlZHVjYXRpb25cbiAgLSA8JSBjb3Vyc2VJZCAlPlxuICAtICR7dGhpcy5zZXR0aW5ncy5zY2hvb2xBYmJyZXZpYXRpb259LzwlIGNvdXJzZVllYXIgJT4vPCUgY291cnNlU2Vhc29uICU+LzwlIGNvdXJzZUlkICU+XG4tLS1cblxuPCUqXG5jb25zdCB7IGV4ZWMgfSA9IHJlcXVpcmUoXCJjaGlsZF9wcm9jZXNzXCIpO1xubGV0IGNvdXJzZU5hbWUgPSBhd2FpdCB0cC5zeXN0ZW0ucHJvbXB0KFwiQ291cnNlIE5hbWUgKGUuZy4gUFNJLTEwMSAtIEludHJvIHRvIFBzeWNoKVwiKVxubGV0IGNvdXJzZVNlYXNvbiA9IGF3YWl0IHRwLnN5c3RlbS5zdWdnZXN0ZXIoW1wiRmFsbFwiLFwiV2ludGVyXCIsXCJTcHJpbmdcIixcIlN1bW1lclwiXSxbXCJGYWxsXCIsXCJXaW50ZXJcIixcIlNwcmluZ1wiLFwiU3VtbWVyXCJdLCBcIlNlYXNvblwiKVxubGV0IGNvdXJzZVllYXIgPSBhd2FpdCB0cC5zeXN0ZW0ucHJvbXB0KFwiWWVhclwiKVxubGV0IGNvdXJzZUlkID0gY291cnNlTmFtZS5zcGxpdCgnIC0gJylbMF1cbmF3YWl0IHRwLmZpbGUubW92ZShcXGAvXFwke2NvdXJzZVllYXJ9L1xcJHtjb3Vyc2VTZWFzb259L1xcJHtjb3Vyc2VOYW1lfS9cXCR7Y291cnNlTmFtZX1cXGApXG50cnkge2F3YWl0IGFwcC52YXVsdC5jcmVhdGVGb2xkZXIoXFxgXFwke2NvdXJzZVllYXJ9L1xcJHtjb3Vyc2VTZWFzb259L1xcJHtjb3Vyc2VOYW1lfS9BdHRhY2htZW50c1xcYCl9IGNhdGNoIChlKSB7fVxuJT5cblxuIyA8JSBjb3Vyc2VOYW1lICU+XG5cbiMjIENvdXJzZSBJbmZvcm1hdGlvblxuKipDb3Vyc2UgSUQqKjogPCUgY291cnNlSWQgJT5cbioqVGVybSoqOiA8JSBjb3Vyc2VTZWFzb24gJT4gPCUgY291cnNlWWVhciAlPlxuKipTY2hvb2wqKjogJHt0aGlzLnNldHRpbmdzLnNjaG9vbE5hbWV9XG5cbiMjIEluc3RydWN0b3JcbioqTmFtZSoqOiBcbioqRW1haWwqKjogXG4qKk9mZmljZSBIb3VycyoqOiBcblxuIyMgQ291cnNlIERlc2NyaXB0aW9uXG5cbiMjIExlYXJuaW5nIE9iamVjdGl2ZXNcblxuIyMgUmVxdWlyZWQgVGV4dHNcblxcYFxcYFxcYG1ldGEtYmluZC1qcy12aWV3XG57dGV4dHN9IGFzIHRleHRzXG4tLS1cbmNvbnN0IGF2YWlsYWJsZVRleHRzID0gYXBwLnZhdWx0LmdldEZpbGVzKCkuZmlsdGVyKGZpbGUgPT4gZmlsZS5leHRlbnNpb24gPT0gJ3BkZicpLm1hcChmID0+IGY/Lm5hbWUpXG5jb25zdCBlc2NhcGVSZWdleCA9IC9bLFxcXCJcXGAnKCldL2c7XG5vcHRpb25zID0gYXZhaWxhYmxlVGV4dHMubWFwKHQgPT4gXFxgb3B0aW9uKFtbXFwke3QucmVwbGFjZShlc2NhcGVSZWdleCxcXGBcXFxcXFxcXCQxXFxgKX1dXSwgXFwke3QucmVwbGFjZShlc2NhcGVSZWdleCxcXGBcXFxcXFxcXCQxXFxgKX0pXFxgIClcbmNvbnN0IHN0ciA9IFxcXFxcXGBJTlBVVFtpbmxpbmVMaXN0U3VnZ2VzdGVyKFxcJHtvcHRpb25zLmpvaW4oXCIsIFwiKX0pOnRleHRzXVxcXFxcXGBcbnJldHVybiBlbmdpbmUubWFya2Rvd24uY3JlYXRlKHN0cilcblxcYFxcYFxcYFxuXG4jIyBTY2hlZHVsZVxuXG4jIyBBc3NpZ25tZW50c1xuXG4jIyBSZXNvdXJjZXNcblxuIyMgVm9jYWJ1bGFyeVxuXFxgXFxgXFxgZGF0YXZpZXdqc1xuLy8gVm9jYWJ1bGFyeSBhZ2dyZWdhdGlvbiBjb2RlIHdvdWxkIGdvIGhlcmVcblxcYFxcYFxcYFxuXG4jIyBEdWUgRGF0ZXNcblxcYFxcYFxcYGRhdGF2aWV3anNcbi8vIER1ZSBkYXRlcyBhZ2dyZWdhdGlvbiBjb2RlIHdvdWxkIGdvIGhlcmVcblxcYFxcYFxcYGA7XG4gIH1cblxuICBnZW5lcmF0ZUNvdXJzZUluZGV4VGVtcGxhdGUoKTogc3RyaW5nIHtcbiAgICByZXR1cm4gYC0tLVxuY29udGVudF90eXBlOiBjb3Vyc2VfaW5kZXhcbnRhZ3M6XG4gIC0gaW5kZXhcbi0tLVxuXG4jIENvdXJzZSBJbmRleFxuXG4jIyBNb2R1bGVzXG5cbiMjIENoYXB0ZXJzXG5cbiMjIEFzc2lnbm1lbnRzXG5cbiMjIFJlc291cmNlc1xuXG4jIyBWb2NhYnVsYXJ5XG5cbiMjIER1ZSBEYXRlc2A7XG4gIH1cblxuICBnZW5lcmF0ZU1vZHVsZVRlbXBsYXRlKCk6IHN0cmluZyB7XG4gICAgcmV0dXJuIGAtLS1cbiR7dGhpcy5zZXR0aW5ncy51c2VFbmhhbmNlZE1ldGFkYXRhID8gYGNvdXJzZV9pZDogPCUgY291cnNlSWQgJT5cbm1vZHVsZV9udW1iZXI6IDwlIG1vZHVsZU51bWJlciAlPlxud2Vla19udW1iZXI6IDwlIHdlZWtOdW1iZXIgJT5cbmNsYXNzX2RheTogPCUgZGF5T2ZXZWVrICU+XG5jb250ZW50X3R5cGU6IG1vZHVsZVxucGFyZW50X2NvdXJzZTogXCJbWzwlIGNvdXJzZSAlPl1dXCJgIDogYGNvdXJzZV9pZDogPCUgY291cnNlSWQgJT5cbm1vZHVsZV9udW1iZXI6IDwlIG1vZHVsZU51bWJlciAlPlxud2Vla19udW1iZXI6IDwlIHdlZWtOdW1iZXIgJT5cbmNsYXNzX2RheTogPCUgZGF5T2ZXZWVrICU+YH1cbmNyZWF0ZWQ6IDwlIHRwLmRhdGUubm93KFwiWVlZWS1NTS1ERFtUXUhIOm1tOnNzWlwiKSAlPlxudGFnczpcbiAgLSBlZHVjYXRpb25cbiAgLSA8JSBjb3Vyc2VJZCAlPlxuICAtIG1vZHVsZVxuLS0tXG5cbjwlKlxuY29uc3QgeyBzZWFzb24sIG1vZHVsZU51bWJlciwgd2Vla051bWJlciwgY291cnNlLCBjb3Vyc2VJZCwgZGlzY2lwbGluZSwgZGF5T2ZXZWVrIH0gPSBhd2FpdCB0cC51c2VyLm5ld19tb2R1bGUoYXBwLCB0cCwgXCIyMDI1XCIpO1xubGV0IHRpdGxlID0gY291cnNlSWRcbmlmIChtb2R1bGVOdW1iZXIgJiYgd2Vla051bWJlcikgeyB0aXRsZSA9IFxcYE1cXCR7bW9kdWxlTnVtYmVyfS9XXFwke3dlZWtOdW1iZXJ9XFxgfVxuZWxzZSBpZiAobW9kdWxlTnVtYmVyKSB7IHRpdGxlID0gXFxgTVxcJHttb2R1bGVOdW1iZXJ9XFxgIH0gXG5lbHNlIGlmICh3ZWVrTnVtYmVyKSB7IHRpdGxlID0gXFxgV1xcJHt3ZWVrTnVtYmVyfVxcYH1cbiU+XG5cbiMgW1s8JSBjb3Vyc2UgJT5dXSAtIDwlIHRpdGxlICU+IC0gPCUgZGF5T2ZXZWVrICU+XG5cbiMjIExlYXJuaW5nIE9iamVjdGl2ZXNcblxuIyMgUmVhZGluZyBBc3NpZ25tZW50XG5cbiMjIExlY3R1cmUgTm90ZXNcblxuIyMgRGlzY3Vzc2lvbiBRdWVzdGlvbnNcblxuIyMgQXNzaWdubWVudHNcbnwgRGF0ZSB8IEFzc2lnbm1lbnQgfCBTdGF0dXMgfFxufCAtLS0tIHwgLS0tLS0tLS0tLSB8IC0tLS0tLSB8XG58ICAgICAgfCAgICAgICAgICAgIHwgICAgICAgIHxcblxuIyMgVm9jYWJ1bGFyeVxuXG4jIyBBZGRpdGlvbmFsIFJlc291cmNlc2A7XG4gIH1cblxuICBnZW5lcmF0ZUNoYXB0ZXJUZW1wbGF0ZSgpOiBzdHJpbmcge1xuICAgIHJldHVybiBgLS0tXG4ke3RoaXMuc2V0dGluZ3MudXNlRW5oYW5jZWRNZXRhZGF0YSA/IGBjb3Vyc2VfaWQ6IDwlIGNvdXJzZUlkICU+XG5jaGFwdGVyX251bWJlcjogPCUgY2hhcHRlck51bWJlciAlPlxuY29udGVudF90eXBlOiBjaGFwdGVyXG5wYXJlbnRfY291cnNlOiBcIltbPCUgY291cnNlICU+XV1cIlxudGV4dF9yZWZlcmVuY2U6IFwiW1s8JSB0ZXh0ICU+XV1cImAgOiBgY291cnNlX2lkOiA8JSBjb3Vyc2VJZCAlPlxuY2hhcHRlcl9udW1iZXI6IDwlIGNoYXB0ZXJOdW1iZXIgJT5gfVxuY3JlYXRlZDogPCUgdHAuZGF0ZS5ub3coXCJZWVlZLU1NLUREW1RdSEg6bW06c3NaXCIpICU+XG50YWdzOlxuICAtIGVkdWNhdGlvblxuICAtIDwlIGNvdXJzZUlkICU+XG4gIC0gY2hhcHRlclxuLS0tXG5cbjwlKlxuY29uc3QgeyBjaGFwdGVyTnVtYmVyLCBjb3Vyc2UsIGNvdXJzZUlkLCBkaXNjaXBsaW5lLCB0ZXh0fSA9IGF3YWl0IHRwLnVzZXIubmV3X2NoYXB0ZXIodHApO1xuJT5cblxuIyBbWzwlIHRleHQgJT5dXSAtIENoYXB0ZXIgPCUgY2hhcHRlck51bWJlciAlPlxuXG4jIyBTdW1tYXJ5XG5cbiMjIEtleSBDb25jZXB0c1xuXG4jIyBWb2NhYnVsYXJ5XG4tIFxuXG4jIyBOb3Rlc1xuXG4jIyBEaXNjdXNzaW9uIFF1ZXN0aW9uc1xuXG4jIyBGdXJ0aGVyIFJlYWRpbmdgO1xuICB9XG5cbiAgZ2VuZXJhdGVBc3NpZ25tZW50VGVtcGxhdGUoKTogc3RyaW5nIHtcbiAgICByZXR1cm4gYC0tLVxuJHt0aGlzLnNldHRpbmdzLnVzZUVuaGFuY2VkTWV0YWRhdGEgPyBgY291cnNlX2lkOiA8JSBjb3Vyc2VJZCAlPlxuYXNzaWdubWVudF90eXBlOiA8JSBhc3NpZ25tZW50VHlwZSAlPlxuZHVlX2RhdGU6IDwlIGR1ZURhdGUgJT5cbnBvaW50czogPCUgcG9pbnRzICU+XG5jb250ZW50X3R5cGU6IGFzc2lnbm1lbnRcbnBhcmVudF9jb3Vyc2U6IFwiW1s8JSBjb3Vyc2UgJT5dXVwiYCA6IGBjb3Vyc2VfaWQ6IDwlIGNvdXJzZUlkICU+XG5hc3NpZ25tZW50X3R5cGU6IDwlIGFzc2lnbm1lbnRUeXBlICU+XG5kdWVfZGF0ZTogPCUgZHVlRGF0ZSAlPmB9XG5jcmVhdGVkOiA8JSB0cC5kYXRlLm5vdyhcIllZWVktTU0tRERbVF1ISDptbTpzc1pcIikgJT5cbnN0YXR1czogcGVuZGluZ1xudGFnczpcbiAgLSBlZHVjYXRpb25cbiAgLSA8JSBjb3Vyc2VJZCAlPlxuICAtIGFzc2lnbm1lbnRcbi0tLVxuXG4jIDwlIGFzc2lnbm1lbnROYW1lICU+IC0gPCUgY291cnNlSWQgJT5cblxuIyMgRGVzY3JpcHRpb25cblxuIyMgSW5zdHJ1Y3Rpb25zXG5cbiMjIER1ZSBEYXRlXG4qKkFzc2lnbmVkKio6IDwlIHRwLmRhdGUubm93KFwiWVlZWS1NTS1ERFwiKSAlPlxuKipEdWUqKjogPCUgZHVlRGF0ZSAlPlxuXG4jIyBTdWJtaXNzaW9uXG5cbiMjIEdyYWRpbmcgQ3JpdGVyaWFcblxuIyMgUmVzb3VyY2VzYDtcbiAgfVxuXG4gIGdlbmVyYXRlRGFpbHlOb3RlVGVtcGxhdGUoKTogc3RyaW5nIHtcbiAgICByZXR1cm4gYC0tLVxuY29udGVudF90eXBlOiBkYWlseV9ub3RlXG5kYXRlOiA8JSB0cC5kYXRlLm5vdyhcIllZWVktTU0tRERcIikgJT5cbnRhZ3M6XG4gIC0gZGFpbHlcbiAgLSA8JSB0cC5kYXRlLm5vdyhcIllZWVlcIikgJT5cbiAgLSA8JSB0cC5kYXRlLm5vdyhcIk1NXCIpICU+XG4gIC0gPCUgdHAuZGF0ZS5ub3coXCJERFwiKSAlPlxuLS0tXG5cbiMgPCUgdHAuZGF0ZS5ub3coXCJZWVlZLU1NLUREIC0gZGRkZFwiKSAlPlxuXG48PCBbWzwlIHRwLmRhdGUueWVzdGVyZGF5KFwiWVlZWS1NTS1ERFwiKSAlPl1dIHwgW1s8JSB0cC5kYXRlLnRvbW9ycm93KFwiWVlZWS1NTS1ERFwiKSAlPl1dID4+XG5cbiMjIFRvZGF5J3MgRm9jdXNcblxuIyMgQ291cnNlcyBXb3JrZWQgT25cbi0gXG5cbiMjIFRhc2tzIENvbXBsZXRlZFxuLSBbIF0gXG5cbiMjIFZvY2FidWxhcnkgUmV2aWV3ZWRcbi0gXG5cbiMjIEFzc2lnbm1lbnRzIER1ZVxuLSBcblxuIyMgTGVhcm5pbmcgQWNoaWV2ZW1lbnRzXG5cbiMjIENoYWxsZW5nZXNcblxuIyMgVG9tb3Jyb3cncyBQbGFuXG5cbiMjIFJlZmxlY3Rpb25gO1xuICB9XG5cbiAgZ2VuZXJhdGVWb2NhYnVsYXJ5VGVtcGxhdGUoKTogc3RyaW5nIHtcbiAgICByZXR1cm4gYCMjIDwlIHRlcm0gJT5cbioqVGVybSoqOiA8JSB0ZXJtICU+XG4qKlBhcnQgb2YgU3BlZWNoKio6IFxuKipEZWZpbml0aW9uKio6IFxuKipDb250ZXh0Kio6IFxuKipFeGFtcGxlcyoqOiBcbioqUmVsYXRlZCBUZXJtcyoqOiBcbioqU2VlIEFsc28qKjpgO1xuICB9XG5cbiAgZ2VuZXJhdGVEdWVEYXRlVGVtcGxhdGUoKTogc3RyaW5nIHtcbiAgICByZXR1cm4gYHwgPCUgZHVlRGF0ZSAlPiB8IDwlIGFzc2lnbm1lbnQgJT4gfCA8JSBzdGF0dXMgJT4gfGA7XG4gIH1cblxuICBhc3luYyBjcmVhdGVSRUFETUUoYmFzZVBhdGg6IHN0cmluZykge1xuICAgIGNvbnN0IHJlYWRtZUNvbnRlbnQgPSBgIyBUdWNrZXJzIFRvb2xzIFRlbXBsYXRlc1xuXG5UaGlzIGRpcmVjdG9yeSBjb250YWlucyB0ZW1wbGF0ZXMgZm9yIHRoZSBUdWNrZXJzIFRvb2xzIE9ic2lkaWFuIHBsdWdpbi5cblxuIyMgVGVtcGxhdGUgQ2F0ZWdvcmllc1xuXG4tICoqQ291cnNlcyoqOiBUZW1wbGF0ZXMgZm9yIGNyZWF0aW5nIGFuZCBvcmdhbml6aW5nIGNvdXJzZXNcbi0gKipNb2R1bGVzKio6IFRlbXBsYXRlcyBmb3IgY291cnNlIG1vZHVsZXNcbi0gKipDaGFwdGVycyoqOiBUZW1wbGF0ZXMgZm9yIGNoYXB0ZXIgbm90ZXNcbi0gKipBc3NpZ25tZW50cyoqOiBUZW1wbGF0ZXMgZm9yIGFzc2lnbm1lbnRzXG4tICoqRGFpbHkqKjogVGVtcGxhdGVzIGZvciBkYWlseSBub3Rlc1xuLSAqKlV0aWxpdGllcyoqOiBIZWxwZXIgdGVtcGxhdGVzXG5cbiMjIFVzYWdlXG5cblRoZXNlIHRlbXBsYXRlcyBhcmUgZGVzaWduZWQgdG8gd29yayB3aXRoIHRoZSBUdWNrZXJzIFRvb2xzIHBsdWdpbi4gVG8gdXNlIHRoZW06XG5cbjEuIEluc3RhbGwgdGhlIFR1Y2tlcnMgVG9vbHMgcGx1Z2luXG4yLiBDb25maWd1cmUgeW91ciBzZXR0aW5ncyBpbiB0aGUgcGx1Z2luIHNldHRpbmdzIHRhYlxuMy4gVXNlIHRoZSBcIkluc2VydCBUZW1wbGF0ZVwiIGNvbW1hbmQgdG8gYXBwbHkgdGhlc2UgdGVtcGxhdGVzIHRvIG5ldyBub3Rlc1xuXG4jIyBDdXN0b21pemF0aW9uXG5cbkZlZWwgZnJlZSB0byBjdXN0b21pemUgdGhlc2UgdGVtcGxhdGVzIHRvIHN1aXQgeW91ciBuZWVkcy4gVGhlIHBsdWdpbiB3aWxsIG5vdCBvdmVyd3JpdGUgeW91ciBjaGFuZ2VzIHdoZW4gdXBkYXRpbmcgdGVtcGxhdGVzLmA7XG5cbiAgICBhd2FpdCB0aGlzLndyaXRlVGVtcGxhdGVGaWxlKGAke2Jhc2VQYXRofS9SRUFETUUubWRgLCByZWFkbWVDb250ZW50KTtcbiAgfVxufSJdLAogICJtYXBwaW5ncyI6ICI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUFBQSxtQkFBdUI7OztBQ0F2QixzQkFBK0M7OztBQ3NDeEMsU0FBUyxhQUFhLFlBQTZCO0FBQ3hELFFBQU0sUUFBUTtBQUNkLE1BQUksQ0FBQyxXQUFXLE1BQU0sS0FBSztBQUFHLFdBQU87QUFFckMsUUFBTSxPQUFPLElBQUksS0FBSyxVQUFVO0FBQ2hDLFFBQU0sWUFBWSxLQUFLLFFBQVE7QUFFL0IsTUFBSSxPQUFPLGNBQWMsWUFBWSxNQUFNLFNBQVM7QUFBRyxXQUFPO0FBRTlELFNBQU8sZUFBZSxLQUFLLFlBQVksRUFBRSxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQ3ZEOzs7QURsQ08sSUFBTSxtQkFBeUM7QUFBQSxFQUNwRCxlQUFlO0FBQUEsRUFDZixtQkFBbUIsSUFBSSxLQUFLLEVBQUUsWUFBWSxFQUFFLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFBQSxFQUN4RCxpQkFBaUIsSUFBSSxLQUFLLElBQUksS0FBSyxFQUFFLFNBQVMsSUFBSSxLQUFLLEVBQUUsU0FBUyxJQUFJLENBQUMsQ0FBQyxFQUFFLFlBQVksRUFBRSxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsRUFDcEcsWUFBWTtBQUFBLEVBQ1osb0JBQW9CO0FBQUEsRUFDcEIsZ0JBQWdCO0FBQUEsRUFDaEIscUJBQXFCO0FBQ3ZCO0FBRU8sSUFBTSx5QkFBTixjQUFxQyxpQ0FBaUI7QUFBQSxFQUczRCxZQUFZLEtBQVUsUUFBNEI7QUFDaEQsVUFBTSxLQUFLLE1BQU07QUFDakIsU0FBSyxTQUFTO0FBQUEsRUFDaEI7QUFBQSxFQUVBLFVBQWdCO0FBQ2QsVUFBTSxFQUFFLFlBQVksSUFBSTtBQUV4QixnQkFBWSxNQUFNO0FBRWxCLGdCQUFZLFNBQVMsTUFBTSxFQUFFLE1BQU0seUJBQXlCLENBQUM7QUFFN0QsUUFBSSx3QkFBUSxXQUFXLEVBQ3BCLFFBQVEsZ0JBQWdCLEVBQ3hCLFFBQVEsZ0RBQWdELEVBQ3hELFFBQVEsVUFBUSxLQUNkLGVBQWUsR0FBRyxFQUNsQixTQUFTLEtBQUssT0FBTyxTQUFTLGFBQWEsRUFDM0MsU0FBUyxDQUFPLFVBQVU7QUFDekIsV0FBSyxPQUFPLFNBQVMsZ0JBQWdCO0FBQ3JDLFlBQU0sS0FBSyxPQUFPLGFBQWE7QUFBQSxJQUNqQyxFQUFDLENBQUM7QUFFTixVQUFNLG1CQUFtQixJQUFJLHdCQUFRLFdBQVcsRUFDN0MsUUFBUSxxQkFBcUIsRUFDN0IsUUFBUSxxQ0FBcUMsRUFDN0MsUUFBUSxVQUFRLEtBQ2QsZUFBZSxZQUFZLEVBQzNCLFNBQVMsS0FBSyxPQUFPLFNBQVMsaUJBQWlCLEVBQy9DLFNBQVMsQ0FBTyxVQUFVO0FBQ3pCLFVBQUksU0FBUyxDQUFDLGFBQWEsS0FBSyxHQUFHO0FBQ2pDLHlCQUFpQixRQUFRLDJEQUEyRDtBQUFBLE1BQ3RGLE9BQU87QUFDTCx5QkFBaUIsUUFBUSxxQ0FBcUM7QUFBQSxNQUNoRTtBQUNBLFdBQUssT0FBTyxTQUFTLG9CQUFvQjtBQUN6QyxZQUFNLEtBQUssT0FBTyxhQUFhO0FBQUEsSUFDakMsRUFBQyxDQUFDO0FBRU4sVUFBTSxpQkFBaUIsSUFBSSx3QkFBUSxXQUFXLEVBQzNDLFFBQVEsbUJBQW1CLEVBQzNCLFFBQVEsbUNBQW1DLEVBQzNDLFFBQVEsVUFBUSxLQUNkLGVBQWUsWUFBWSxFQUMzQixTQUFTLEtBQUssT0FBTyxTQUFTLGVBQWUsRUFDN0MsU0FBUyxDQUFPLFVBQVU7QUFDekIsVUFBSSxTQUFTLENBQUMsYUFBYSxLQUFLLEdBQUc7QUFDakMsdUJBQWUsUUFBUSx5REFBeUQ7QUFBQSxNQUNsRixPQUFPO0FBQ0wsdUJBQWUsUUFBUSxtQ0FBbUM7QUFBQSxNQUM1RDtBQUNBLFdBQUssT0FBTyxTQUFTLGtCQUFrQjtBQUN2QyxZQUFNLEtBQUssT0FBTyxhQUFhO0FBQUEsSUFDakMsRUFBQyxDQUFDO0FBRU4sUUFBSSx3QkFBUSxXQUFXLEVBQ3BCLFFBQVEsYUFBYSxFQUNyQixRQUFRLDBCQUEwQixFQUNsQyxRQUFRLFVBQVEsS0FDZCxlQUFlLFlBQVksRUFDM0IsU0FBUyxLQUFLLE9BQU8sU0FBUyxVQUFVLEVBQ3hDLFNBQVMsQ0FBTyxVQUFVO0FBQ3pCLFdBQUssT0FBTyxTQUFTLGFBQWE7QUFDbEMsWUFBTSxLQUFLLE9BQU8sYUFBYTtBQUFBLElBQ2pDLEVBQUMsQ0FBQztBQUVOLFFBQUksd0JBQVEsV0FBVyxFQUNwQixRQUFRLHFCQUFxQixFQUM3QixRQUFRLG1DQUFtQyxFQUMzQyxRQUFRLFVBQVEsS0FDZCxlQUFlLEdBQUcsRUFDbEIsU0FBUyxLQUFLLE9BQU8sU0FBUyxrQkFBa0IsRUFDaEQsU0FBUyxDQUFPLFVBQVU7QUFDekIsV0FBSyxPQUFPLFNBQVMscUJBQXFCO0FBQzFDLFlBQU0sS0FBSyxPQUFPLGFBQWE7QUFBQSxJQUNqQyxFQUFDLENBQUM7QUFFTixRQUFJLHdCQUFRLFdBQVcsRUFDcEIsUUFBUSxpQkFBaUIsRUFDekIsUUFBUSw2RUFBNkUsRUFDckYsUUFBUSxVQUFRLEtBQ2QsZUFBZSxlQUFlLEVBQzlCLFNBQVMsS0FBSyxPQUFPLFNBQVMsY0FBYyxFQUM1QyxTQUFTLENBQU8sVUFBVTtBQUN6QixXQUFLLE9BQU8sU0FBUyxpQkFBaUI7QUFDdEMsWUFBTSxLQUFLLE9BQU8sYUFBYTtBQUFBLElBQ2pDLEVBQUMsQ0FBQztBQUVOLFFBQUksd0JBQVEsV0FBVyxFQUNwQixRQUFRLHVCQUF1QixFQUMvQixRQUFRLGlGQUFpRixFQUN6RixVQUFVLFlBQVUsT0FDbEIsU0FBUyxLQUFLLE9BQU8sU0FBUyxtQkFBbUIsRUFDakQsU0FBUyxDQUFPLFVBQVU7QUFDekIsV0FBSyxPQUFPLFNBQVMsc0JBQXNCO0FBQzNDLFlBQU0sS0FBSyxPQUFPLGFBQWE7QUFBQSxJQUNqQyxFQUFDLENBQUM7QUFBQSxFQUNSO0FBQ0Y7OztBRTdIQSxJQUFBQyxtQkFBNEI7QUFVckIsSUFBTSxrQkFBTixNQUFzQjtBQUFBLEVBSzNCLFlBQVksS0FBVSxVQUFnQztBQUNwRCxTQUFLLE1BQU07QUFDWCxTQUFLLFdBQVc7QUFDaEIsU0FBSyxXQUFXO0FBQUEsTUFDZCxTQUFTO0FBQUEsTUFDVCxXQUFXO0FBQUEsUUFDVCxxQ0FBcUM7QUFBQSxRQUNyQywyQkFBMkI7QUFBQSxRQUMzQiw0QkFBNEI7QUFBQSxRQUM1Qiw4QkFBOEI7QUFBQSxRQUM5QixvQ0FBb0M7QUFBQSxRQUNwQyx1QkFBdUI7QUFBQSxRQUN2QixpQ0FBaUM7QUFBQSxRQUNqQywrQkFBK0I7QUFBQSxNQUNqQztBQUFBLE1BQ0EsZ0JBQWdCO0FBQUEsTUFDaEIsZUFBZTtBQUFBLElBQ2pCO0FBQUEsRUFDRjtBQUFBLEVBRU0sbUJBQW1CO0FBQUE7QUFFdkIsWUFBTSxrQkFBbUIsS0FBSyxJQUFZLFFBQVEsUUFBUSxvQkFBb0I7QUFDOUUsVUFBSSxDQUFDLGlCQUFpQjtBQUNwQixZQUFJLHdCQUFPLG1GQUFtRjtBQUM5RixnQkFBUSxNQUFNLG1GQUFtRjtBQUNqRztBQUFBLE1BQ0Y7QUFFQSxZQUFNLG9CQUFvQixnQkFBZ0I7QUFFMUMsWUFBTSxxQkFBcUIsa0JBQWtCLGlCQUFpQixLQUNwQyxrQkFBa0IsZ0JBQWdCLEtBQ2xDLGtCQUFrQixvQkFBb0I7QUFFaEUsVUFBSSxDQUFDLG9CQUFvQjtBQUN2QixZQUFJLHdCQUFPLHdHQUF3RztBQUNuSCxnQkFBUSxNQUFNLHdHQUF3RztBQUN0SDtBQUFBLE1BQ0Y7QUFFQSxZQUFNLG1CQUFtQixHQUFHLHNCQUFzQixLQUFLLFNBQVM7QUFHaEUsVUFBSTtBQUNGLGNBQU0sS0FBSyxJQUFJLE1BQU0sYUFBYSxnQkFBZ0I7QUFDbEQsZ0JBQVEsSUFBSSw0QkFBNEIsa0JBQWtCO0FBQUEsTUFDNUQsU0FBUyxHQUFQO0FBRUEsZ0JBQVEsSUFBSSw4Q0FBOEMsa0JBQWtCO0FBQUEsTUFDOUU7QUFHQSxZQUFNLFVBQVUsQ0FBQyxXQUFXLFdBQVcsWUFBWSxlQUFlLFNBQVMsV0FBVztBQUN0RixpQkFBVyxVQUFVLFNBQVM7QUFDNUIsWUFBSTtBQUNGLGdCQUFNLFVBQVUsR0FBRyxvQkFBb0I7QUFDdkMsZ0JBQU0sS0FBSyxJQUFJLE1BQU0sYUFBYSxPQUFPO0FBQ3pDLGtCQUFRLElBQUkseUJBQXlCLFNBQVM7QUFBQSxRQUNoRCxTQUFTLEdBQVA7QUFFQSxrQkFBUSxJQUFJLGdDQUFnQyxvQkFBb0IsUUFBUTtBQUFBLFFBQzFFO0FBQUEsTUFDRjtBQUdBLFlBQU0sS0FBSyx1QkFBdUIsZ0JBQWdCO0FBQ2xELFlBQU0sS0FBSyx1QkFBdUIsZ0JBQWdCO0FBQ2xELFlBQU0sS0FBSyx3QkFBd0IsZ0JBQWdCO0FBQ25ELFlBQU0sS0FBSywyQkFBMkIsZ0JBQWdCO0FBQ3RELFlBQU0sS0FBSyxzQkFBc0IsZ0JBQWdCO0FBQ2pELFlBQU0sS0FBSyx3QkFBd0IsZ0JBQWdCO0FBR25ELFlBQU0sS0FBSyxhQUFhLGdCQUFnQjtBQUd4QyxZQUFNLEtBQUssdUJBQXVCLGdCQUFnQjtBQUVsRCxVQUFJLHdCQUFPLGlEQUFpRDtBQUM1RCxjQUFRLElBQUksZ0RBQWdEO0FBQUEsSUFDOUQ7QUFBQTtBQUFBLEVBRU0sdUJBQXVCLFVBQWtCO0FBQUE7QUFDN0MsWUFBTSxlQUFlLEdBQUc7QUFDeEIsWUFBTSxrQkFBa0IsS0FBSyxVQUFVLEtBQUssVUFBVSxNQUFNLENBQUM7QUFFN0QsVUFBSTtBQUVGLGNBQU0sbUJBQW1CLEtBQUssSUFBSSxNQUFNLHNCQUFzQixZQUFZO0FBQzFFLFlBQUksa0JBQWtCO0FBRXBCLGdCQUFNLE9BQU87QUFDYixnQkFBTSxLQUFLLElBQUksTUFBTSxPQUFPLE1BQU0sZUFBZTtBQUNqRCxrQkFBUSxJQUFJLDhCQUE4QixjQUFjO0FBQ3hEO0FBQUEsUUFDRjtBQUdBLGNBQU0sS0FBSyxJQUFJLE1BQU0sT0FBTyxjQUFjLGVBQWU7QUFDekQsZ0JBQVEsSUFBSSw4QkFBOEIsY0FBYztBQUFBLE1BQzFELFNBQVMsR0FBUDtBQUNBLFlBQUksd0JBQU8sb0NBQW9DLGNBQWM7QUFDN0QsZ0JBQVEsTUFBTSxvQ0FBb0MsaUJBQWlCLENBQUM7QUFBQSxNQUN0RTtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRU0sMEJBQTRDO0FBQUE7QUFHaEQsY0FBUSxJQUFJLCtCQUErQjtBQUMzQyxhQUFPO0FBQUEsSUFDVDtBQUFBO0FBQUEsRUFFTSxrQkFBa0I7QUFBQTtBQUd0QixjQUFRLElBQUksb0JBQW9CO0FBR2hDLFlBQU0sa0JBQW1CLEtBQUssSUFBWSxRQUFRLFFBQVEsb0JBQW9CO0FBQzlFLFVBQUksQ0FBQyxpQkFBaUI7QUFDcEIsWUFBSSx3QkFBTyxtRkFBbUY7QUFDOUYsZ0JBQVEsTUFBTSxtRkFBbUY7QUFDakc7QUFBQSxNQUNGO0FBRUEsWUFBTSxvQkFBb0IsZ0JBQWdCO0FBRTFDLFlBQU0scUJBQXFCLGtCQUFrQixpQkFBaUIsS0FDcEMsa0JBQWtCLGdCQUFnQixLQUNsQyxrQkFBa0Isb0JBQW9CO0FBRWhFLFVBQUksQ0FBQyxvQkFBb0I7QUFDdkIsWUFBSSx3QkFBTyx3R0FBd0c7QUFDbkgsZ0JBQVEsTUFBTSx3R0FBd0c7QUFDdEg7QUFBQSxNQUNGO0FBRUEsWUFBTSxtQkFBbUIsR0FBRyxzQkFBc0IsS0FBSyxTQUFTO0FBR2hFLFlBQU0sS0FBSyx1QkFBdUIsZ0JBQWdCO0FBQ2xELFlBQU0sS0FBSyx1QkFBdUIsZ0JBQWdCO0FBQ2xELFlBQU0sS0FBSyx3QkFBd0IsZ0JBQWdCO0FBQ25ELFlBQU0sS0FBSywyQkFBMkIsZ0JBQWdCO0FBQ3RELFlBQU0sS0FBSyxzQkFBc0IsZ0JBQWdCO0FBQ2pELFlBQU0sS0FBSyx3QkFBd0IsZ0JBQWdCO0FBR25ELFlBQU0sS0FBSyxhQUFhLGdCQUFnQjtBQUd4QyxZQUFNLEtBQUssdUJBQXVCLGdCQUFnQjtBQUVsRCxVQUFJLHdCQUFPLCtDQUErQztBQUMxRCxjQUFRLElBQUksOENBQThDO0FBQUEsSUFDNUQ7QUFBQTtBQUFBLEVBRU0sdUJBQXVCLFVBQWtCO0FBQUE7QUFDN0MsWUFBTSxhQUFhLEdBQUc7QUFHdEIsWUFBTSx5QkFBeUIsS0FBSywrQkFBK0I7QUFDbkUsWUFBTSxLQUFLLGtCQUFrQixHQUFHLHdDQUF3QyxzQkFBc0I7QUFHOUYsWUFBTSxzQkFBc0IsS0FBSyw0QkFBNEI7QUFDN0QsWUFBTSxLQUFLLGtCQUFrQixHQUFHLDhCQUE4QixtQkFBbUI7QUFBQSxJQUNuRjtBQUFBO0FBQUEsRUFFTSx1QkFBdUIsVUFBa0I7QUFBQTtBQUM3QyxZQUFNLGFBQWEsR0FBRztBQUd0QixZQUFNLGlCQUFpQixLQUFLLHVCQUF1QjtBQUNuRCxZQUFNLEtBQUssa0JBQWtCLEdBQUcsK0JBQStCLGNBQWM7QUFBQSxJQUMvRTtBQUFBO0FBQUEsRUFFTSx3QkFBd0IsVUFBa0I7QUFBQTtBQUM5QyxZQUFNLGNBQWMsR0FBRztBQUd2QixZQUFNLGtCQUFrQixLQUFLLHdCQUF3QjtBQUNyRCxZQUFNLEtBQUssa0JBQWtCLEdBQUcsaUNBQWlDLGVBQWU7QUFBQSxJQUNsRjtBQUFBO0FBQUEsRUFFTSwyQkFBMkIsVUFBa0I7QUFBQTtBQUNqRCxZQUFNLGlCQUFpQixHQUFHO0FBRzFCLFlBQU0scUJBQXFCLEtBQUssMkJBQTJCO0FBQzNELFlBQU0sS0FBSyxrQkFBa0IsR0FBRyx1Q0FBdUMsa0JBQWtCO0FBQUEsSUFDM0Y7QUFBQTtBQUFBLEVBRU0sc0JBQXNCLFVBQWtCO0FBQUE7QUFDNUMsWUFBTSxZQUFZLEdBQUc7QUFHckIsWUFBTSxvQkFBb0IsS0FBSywwQkFBMEI7QUFDekQsWUFBTSxLQUFLLGtCQUFrQixHQUFHLDJCQUEyQixpQkFBaUI7QUFBQSxJQUM5RTtBQUFBO0FBQUEsRUFFTSx3QkFBd0IsVUFBa0I7QUFBQTtBQUM5QyxZQUFNLGNBQWMsR0FBRztBQUd2QixZQUFNLGdCQUFnQixLQUFLLDJCQUEyQjtBQUN0RCxZQUFNLEtBQUssa0JBQWtCLEdBQUcsbUNBQW1DLGFBQWE7QUFHaEYsWUFBTSxrQkFBa0IsS0FBSyx3QkFBd0I7QUFDckQsWUFBTSxLQUFLLGtCQUFrQixHQUFHLGlDQUFpQyxlQUFlO0FBQUEsSUFDbEY7QUFBQTtBQUFBLEVBRU0sa0JBQWtCLE1BQWMsU0FBaUI7QUFBQTtBQUNyRCxVQUFJO0FBRUYsY0FBTSxlQUFlLEtBQUssSUFBSSxNQUFNLHNCQUFzQixJQUFJO0FBQzlELFlBQUksY0FBYztBQUdoQixrQkFBUSxJQUFJLG9DQUFvQyxNQUFNO0FBQ3RELGdCQUFNLE9BQU87QUFDYixnQkFBTSxLQUFLLElBQUksTUFBTSxPQUFPLE1BQU0sT0FBTztBQUN6QztBQUFBLFFBQ0Y7QUFHQSxjQUFNLEtBQUssSUFBSSxNQUFNLE9BQU8sTUFBTSxPQUFPO0FBQ3pDLGdCQUFRLElBQUksMEJBQTBCLE1BQU07QUFBQSxNQUM5QyxTQUFTLEdBQVA7QUFDQSxZQUFJLHdCQUFPLGdDQUFnQyxNQUFNO0FBQ2pELGdCQUFRLE1BQU0sZ0NBQWdDLFNBQVMsQ0FBQztBQUFBLE1BQzFEO0FBQUEsSUFDRjtBQUFBO0FBQUEsRUFFQSxpQ0FBeUM7QUFDdkMsV0FBTztBQUFBLEVBQ1QsS0FBSyxTQUFTLHNCQUFzQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU01QixLQUFLLFNBQVM7QUFBQSx1QkFDRCxLQUFLLFNBQVMsdUJBQXVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFPdEQsS0FBSyxTQUFTO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBa0JOLEtBQUssU0FBUztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBcUMxQjtBQUFBLEVBRUEsOEJBQXNDO0FBQ3BDLFdBQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQW1CVDtBQUFBLEVBRUEseUJBQWlDO0FBQy9CLFdBQU87QUFBQSxFQUNULEtBQUssU0FBUyxzQkFBc0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFDQUtEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFxQ25DO0FBQUEsRUFFQSwwQkFBa0M7QUFDaEMsV0FBTztBQUFBLEVBQ1QsS0FBSyxTQUFTLHNCQUFzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG9DQUlGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBMkJsQztBQUFBLEVBRUEsNkJBQXFDO0FBQ25DLFdBQU87QUFBQSxFQUNULEtBQUssU0FBUyxzQkFBc0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFDQUtEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQTBCbkM7QUFBQSxFQUVBLDRCQUFvQztBQUNsQyxXQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQW1DVDtBQUFBLEVBRUEsNkJBQXFDO0FBQ25DLFdBQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBUVQ7QUFBQSxFQUVBLDBCQUFrQztBQUNoQyxXQUFPO0FBQUEsRUFDVDtBQUFBLEVBRU0sYUFBYSxVQUFrQjtBQUFBO0FBQ25DLFlBQU0sZ0JBQWdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQXlCdEIsWUFBTSxLQUFLLGtCQUFrQixHQUFHLHNCQUFzQixhQUFhO0FBQUEsSUFDckU7QUFBQTtBQUNGOzs7QUg1aEJBLElBQXFCLHFCQUFyQixjQUFnRCx3QkFBTztBQUFBLEVBSS9DLFNBQVM7QUFBQTtBQUNiLGNBQVEsSUFBSSw4QkFBOEI7QUFHMUMsWUFBTSxLQUFLLGFBQWE7QUFHeEIsV0FBSyxrQkFBa0IsSUFBSSxnQkFBZ0IsS0FBSyxLQUFLLEtBQUssUUFBUTtBQUdsRSxXQUFLLGNBQWMsSUFBSSx1QkFBdUIsS0FBSyxLQUFLLElBQUksQ0FBQztBQUc3RCxXQUFLLFdBQVc7QUFBQSxRQUNkLElBQUk7QUFBQSxRQUNKLE1BQU07QUFBQSxRQUNOLFVBQVUsTUFBTTtBQUNkLGVBQUssZ0JBQWdCLGlCQUFpQjtBQUFBLFFBQ3hDO0FBQUEsTUFDRixDQUFDO0FBRUQsV0FBSyxXQUFXO0FBQUEsUUFDZCxJQUFJO0FBQUEsUUFDSixNQUFNO0FBQUEsUUFDTixVQUFVLE1BQU07QUFDZCxlQUFLLGdCQUFnQixnQkFBZ0I7QUFBQSxRQUN2QztBQUFBLE1BQ0YsQ0FBQztBQUdELFdBQUssaUJBQWlCLEVBQUUsUUFBUSxlQUFlO0FBQUEsSUFDakQ7QUFBQTtBQUFBLEVBRUEsV0FBVztBQUNULFlBQVEsSUFBSSxnQ0FBZ0M7QUFBQSxFQUM5QztBQUFBLEVBRU0sZUFBZTtBQUFBO0FBQ25CLFdBQUssV0FBVyxPQUFPLE9BQU8sQ0FBQyxHQUFHLGtCQUFrQixNQUFNLEtBQUssU0FBUyxDQUFDO0FBQUEsSUFDM0U7QUFBQTtBQUFBLEVBRU0sZUFBZTtBQUFBO0FBQ25CLFlBQU0sS0FBSyxTQUFTLEtBQUssUUFBUTtBQUFBLElBQ25DO0FBQUE7QUFDRjsiLAogICJuYW1lcyI6IFsiaW1wb3J0X29ic2lkaWFuIiwgImltcG9ydF9vYnNpZGlhbiJdCn0K
