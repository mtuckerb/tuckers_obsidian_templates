| <% dueDate %> | <% assignment %> | <% status %> |
