var __defProp = Object.defineProperty;
var __defProps = Object.defineProperties;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getOwnPropSymbols = Object.getOwnPropertySymbols;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __propIsEnum = Object.prototype.propertyIsEnumerable;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __spreadValues = (a, b) => {
  for (var prop in b || (b = {}))
    if (__hasOwnProp.call(b, prop))
      __defNormalProp(a, prop, b[prop]);
  if (__getOwnPropSymbols)
    for (var prop of __getOwnPropSymbols(b)) {
      if (__propIsEnum.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    }
  return a;
};
var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __async = (__this, __arguments, generator) => {
  return new Promise((resolve, reject) => {
    var fulfilled = (value) => {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    };
    var rejected = (value) => {
      try {
        step(generator.throw(value));
      } catch (e) {
        reject(e);
      }
    };
    var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
    step((generator = generator.apply(__this, __arguments)).next());
  });
};

// main.ts
var main_exports = {};
__export(main_exports, {
  default: () => TuckersToolsPlugin
});
module.exports = __toCommonJS(main_exports);
var import_obsidian7 = require("obsidian");

// settings.ts
var import_obsidian = require("obsidian");

// utils.ts
function slugify(text) {
  return text.toLowerCase().trim().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9\s-]/g, "").replace(/[\s-]+/g, "-").replace(/^-+|-+$/g, "");
}
function validateDate(dateString) {
  const regex = /^\d{4}-\d{2}-\d{2}$/;
  if (!dateString.match(regex))
    return false;
  const date = new Date(dateString);
  const timestamp = date.getTime();
  if (typeof timestamp !== "number" || isNaN(timestamp))
    return false;
  return dateString === date.toISOString().split("T")[0];
}

// settings.ts
var DEFAULT_SETTINGS = {
  baseDirectory: "/",
  semesterStartDate: new Date().toISOString().split("T")[0],
  semesterEndDate: new Date(new Date().setMonth(new Date().getMonth() + 4)).toISOString().split("T")[0],
  schoolName: "University",
  schoolAbbreviation: "U",
  templateFolder: "Tuckers Tools",
  useEnhancedMetadata: false
};
var TuckersToolsSettingTab = class extends import_obsidian.PluginSettingTab {
  constructor(app, plugin) {
    super(app, plugin);
    this.plugin = plugin;
  }
  display() {
    const { containerEl } = this;
    containerEl.empty();
    containerEl.createEl("h2", { text: "Tuckers Tools Settings" });
    new import_obsidian.Setting(containerEl).setName("Base Directory").setDesc("Root directory for course content organization").addText((text) => text.setPlaceholder("/").setValue(this.plugin.settings.baseDirectory).onChange((value) => __async(this, null, function* () {
      this.plugin.settings.baseDirectory = value;
      yield this.plugin.saveSettings();
    })));
    const startDateSetting = new import_obsidian.Setting(containerEl).setName("Semester Start Date").setDesc("Start date for the current semester").addText((text) => text.setPlaceholder("YYYY-MM-DD").setValue(this.plugin.settings.semesterStartDate).onChange((value) => __async(this, null, function* () {
      if (value && !validateDate(value)) {
        startDateSetting.setDesc("Start date for the current semester (Invalid date format)");
      } else {
        startDateSetting.setDesc("Start date for the current semester");
      }
      this.plugin.settings.semesterStartDate = value;
      yield this.plugin.saveSettings();
    })));
    const endDateSetting = new import_obsidian.Setting(containerEl).setName("Semester End Date").setDesc("End date for the current semester").addText((text) => text.setPlaceholder("YYYY-MM-DD").setValue(this.plugin.settings.semesterEndDate).onChange((value) => __async(this, null, function* () {
      if (value && !validateDate(value)) {
        endDateSetting.setDesc("End date for the current semester (Invalid date format)");
      } else {
        endDateSetting.setDesc("End date for the current semester");
      }
      this.plugin.settings.semesterEndDate = value;
      yield this.plugin.saveSettings();
    })));
    new import_obsidian.Setting(containerEl).setName("School Name").setDesc("Name of your institution").addText((text) => text.setPlaceholder("University").setValue(this.plugin.settings.schoolName).onChange((value) => __async(this, null, function* () {
      this.plugin.settings.schoolName = value;
      yield this.plugin.saveSettings();
    })));
    new import_obsidian.Setting(containerEl).setName("School Abbreviation").setDesc("Abbreviation for your institution").addText((text) => text.setPlaceholder("U").setValue(this.plugin.settings.schoolAbbreviation).onChange((value) => __async(this, null, function* () {
      this.plugin.settings.schoolAbbreviation = value;
      yield this.plugin.saveSettings();
    })));
    new import_obsidian.Setting(containerEl).setName("Template Folder").setDesc("Subfolder within your Templater template folder for Tuckers Tools templates").addText((text) => text.setPlaceholder("Tuckers Tools").setValue(this.plugin.settings.templateFolder).onChange((value) => __async(this, null, function* () {
      this.plugin.settings.templateFolder = value;
      yield this.plugin.saveSettings();
    })));
    new import_obsidian.Setting(containerEl).setName("Use Enhanced Metadata").setDesc("Enable enhanced metadata fields for new notes (existing notes remain unchanged)").addToggle((toggle) => toggle.setValue(this.plugin.settings.useEnhancedMetadata).onChange((value) => __async(this, null, function* () {
      this.plugin.settings.useEnhancedMetadata = value;
      yield this.plugin.saveSettings();
    })));
  }
};

// templateManager.ts
var import_obsidian2 = require("obsidian");
var TemplateManager = class {
  constructor(app, settings) {
    this.app = app;
    this.settings = settings;
    this.manifest = {
      version: "1.0.0",
      templates: {
        "Courses/Create Course Homepage.md": "1.0.0",
        "Courses/Course Index.md": "1.0.0",
        "Modules/Create Module.md": "1.0.0",
        "Chapters/Create Chapter.md": "1.0.0",
        "Assignments/Create Assignment.md": "1.0.0",
        "Daily/Daily Note.md": "1.0.0",
        "Utilities/Vocabulary Entry.md": "1.0.0",
        "Utilities/Due Date Entry.md": "1.0.0"
      },
      plugin_version: "1.0.0",
      release_notes: "Initial release of Tuckers Tools templates"
    };
  }
  installTemplates() {
    return __async(this, null, function* () {
      try {
        const templaterPlugin = this.getTemplaterPlugin();
        if (!templaterPlugin) {
          new import_obsidian2.Notice(
            "Templater plugin not found. Please install and enable the Templater plugin first."
          );
          console.error(
            "Templater plugin not found. Please install and enable the Templater plugin first."
          );
          return;
        }
        const templateFolderPath = this.getTemplateFolderPath(templaterPlugin);
        if (!templateFolderPath) {
          new import_obsidian2.Notice(
            "Template folder not configured in Templater settings. Please configure it in Templater settings first."
          );
          console.error(
            "Template folder not configured in Templater settings. Please configure it in Templater settings first."
          );
          return;
        }
        const fullTemplatePath = `${templateFolderPath}/${this.settings.templateFolder}`;
        try {
          yield this.app.vault.createFolder(fullTemplatePath);
          console.log(`Created template folder: ${fullTemplatePath}`);
        } catch (e) {
          console.log(
            `Template folder already exists or created: ${fullTemplatePath}`
          );
        }
        const subdirs = [
          "Courses",
          "Modules",
          "Chapters",
          "Assignments",
          "Daily",
          "Utilities"
        ];
        for (const subdir of subdirs) {
          try {
            const subPath = `${fullTemplatePath}/${subdir}`;
            yield this.app.vault.createFolder(subPath);
            console.log(`Created subdirectory: ${subPath}`);
          } catch (e) {
            console.log(
              `Subdirectory already exists: ${fullTemplatePath}/${subdir}`
            );
          }
        }
        yield this.installCourseTemplates(fullTemplatePath);
        yield this.installModuleTemplates(fullTemplatePath);
        yield this.installChapterTemplates(fullTemplatePath);
        yield this.installAssignmentTemplates(fullTemplatePath);
        yield this.installDailyTemplates(fullTemplatePath);
        yield this.installUtilityTemplates(fullTemplatePath);
        yield this.createREADME(fullTemplatePath);
        yield this.createTemplateManifest(fullTemplatePath);
        new import_obsidian2.Notice("Tuckers Tools templates installed successfully!");
        console.log("Tuckers Tools templates installed successfully");
      } catch (error) {
        console.error("Error installing templates:", error);
        new import_obsidian2.Notice("Error installing templates. Check console for details.");
      }
    });
  }
  getTemplaterPlugin() {
    const possiblePaths = [
      this.app.plugins.plugins["templater-obsidian"],
      this.app.plugins.plugins["templater"],
      this.app.plugins.getPlugin("templater-obsidian"),
      this.app.plugins.getPlugin("templater")
    ];
    for (const path of possiblePaths) {
      if (path) {
        return path;
      }
    }
    return null;
  }
  getTemplateFolderPath(templaterPlugin) {
    const settings = templaterPlugin.settings;
    if (!settings) {
      console.error("Templater plugin has no settings");
      return null;
    }
    const possiblePaths = [
      settings.template_folder,
      settings.templateFolder,
      settings.templateFolderPath,
      settings.folder
    ];
    for (const path of possiblePaths) {
      if (path && typeof path === "string") {
        return path;
      }
    }
    console.error(
      "Template folder not found in Templater settings. Available settings:",
      Object.keys(settings)
    );
    return null;
  }
  createTemplateManifest(basePath) {
    return __async(this, null, function* () {
      const manifestPath = `${basePath}/template-manifest.json`;
      const manifestContent = JSON.stringify(this.manifest, null, 2);
      try {
        const existingManifest = this.app.vault.getAbstractFileByPath(manifestPath);
        if (existingManifest) {
          const file = existingManifest;
          yield this.app.vault.modify(file, manifestContent);
          console.log(`Updated template manifest: ${manifestPath}`);
          return;
        }
        yield this.app.vault.create(manifestPath, manifestContent);
        console.log(`Created template manifest: ${manifestPath}`);
      } catch (e) {
        new import_obsidian2.Notice(`Error creating template manifest ${manifestPath}`);
        console.error(`Error creating template manifest ${manifestPath}:`, e);
      }
    });
  }
  checkForTemplateUpdates() {
    return __async(this, null, function* () {
      console.log("Checking for template updates");
      return false;
    });
  }
  updateTemplates() {
    return __async(this, null, function* () {
      try {
        console.log("Updating templates");
        const templaterPlugin = this.getTemplaterPlugin();
        if (!templaterPlugin) {
          new import_obsidian2.Notice(
            "Templater plugin not found. Please install and enable the Templater plugin first."
          );
          console.error(
            "Templater plugin not found. Please install and enable the Templater plugin first."
          );
          return;
        }
        const templateFolderPath = this.getTemplateFolderPath(templaterPlugin);
        if (!templateFolderPath) {
          new import_obsidian2.Notice(
            "Template folder not configured in Templater settings. Please configure it in Templater settings first."
          );
          console.error(
            "Template folder not configured in Templater settings. Please configure it in Templater settings first."
          );
          return;
        }
        const fullTemplatePath = `${templateFolderPath}/${this.settings.templateFolder}`;
        yield this.installCourseTemplates(fullTemplatePath);
        yield this.installModuleTemplates(fullTemplatePath);
        yield this.installChapterTemplates(fullTemplatePath);
        yield this.installAssignmentTemplates(fullTemplatePath);
        yield this.installDailyTemplates(fullTemplatePath);
        yield this.installUtilityTemplates(fullTemplatePath);
        yield this.createREADME(fullTemplatePath);
        yield this.createTemplateManifest(fullTemplatePath);
        new import_obsidian2.Notice("Tuckers Tools templates updated successfully!");
        console.log("Tuckers Tools templates updated successfully");
      } catch (error) {
        console.error("Error updating templates:", error);
        new import_obsidian2.Notice("Error updating templates. Check console for details.");
      }
    });
  }
  installCourseTemplates(basePath) {
    return __async(this, null, function* () {
      const coursePath = `${basePath}/Courses`;
      const courseHomepageTemplate = this.generateCourseHomepageTemplate();
      yield this.writeTemplateFile(
        `${coursePath}/Create Course Homepage.md`,
        courseHomepageTemplate
      );
      const courseIndexTemplate = this.generateCourseIndexTemplate();
      yield this.writeTemplateFile(
        `${coursePath}/Course Index.md`,
        courseIndexTemplate
      );
    });
  }
  installModuleTemplates(basePath) {
    return __async(this, null, function* () {
      const modulePath = `${basePath}/Modules`;
      const moduleTemplate = this.generateModuleTemplate();
      yield this.writeTemplateFile(
        `${modulePath}/Create Module.md`,
        moduleTemplate
      );
    });
  }
  installChapterTemplates(basePath) {
    return __async(this, null, function* () {
      const chapterPath = `${basePath}/Chapters`;
      const chapterTemplate = this.generateChapterTemplate();
      yield this.writeTemplateFile(
        `${chapterPath}/Create Chapter.md`,
        chapterTemplate
      );
    });
  }
  installAssignmentTemplates(basePath) {
    return __async(this, null, function* () {
      const assignmentPath = `${basePath}/Assignments`;
      const assignmentTemplate = this.generateAssignmentTemplate();
      yield this.writeTemplateFile(
        `${assignmentPath}/Create Assignment.md`,
        assignmentTemplate
      );
    });
  }
  installDailyTemplates(basePath) {
    return __async(this, null, function* () {
      const dailyPath = `${basePath}/Daily`;
      const dailyNoteTemplate = this.generateDailyNoteTemplate();
      yield this.writeTemplateFile(
        `${dailyPath}/Daily Note.md`,
        dailyNoteTemplate
      );
    });
  }
  installUtilityTemplates(basePath) {
    return __async(this, null, function* () {
      const utilityPath = `${basePath}/Utilities`;
      const vocabTemplate = this.generateVocabularyTemplate();
      yield this.writeTemplateFile(
        `${utilityPath}/Vocabulary Entry.md`,
        vocabTemplate
      );
      const dueDateTemplate = this.generateDueDateTemplate();
      yield this.writeTemplateFile(
        `${utilityPath}/Due Date Entry.md`,
        dueDateTemplate
      );
    });
  }
  writeTemplateFile(path, content) {
    return __async(this, null, function* () {
      try {
        const existingFile = this.app.vault.getAbstractFileByPath(path);
        if (existingFile) {
          console.log(`Updating existing template file: ${path}`);
          const file = existingFile;
          yield this.app.vault.modify(file, content);
          return;
        }
        yield this.app.vault.create(path, content);
        console.log(`Created template file: ${path}`);
      } catch (e) {
        new import_obsidian2.Notice(`Error creating template file ${path}`);
        console.error(`Error creating template file ${path}:`, e);
      }
    });
  }
  generateCourseHomepageTemplate() {
    return `---
${this.settings.useEnhancedMetadata ? `course_id: <% courseId %>
course_name: <% courseName %>
course_term: <% courseSeason %> <% courseYear %>
course_year: <% courseYear %>
course_semester: <% courseSeason %>
content_type: course_homepage
school: ${this.settings.schoolName}
school_abbreviation: ${this.settings.schoolAbbreviation}` : `course_id: <% courseId %>
title: <% courseName %>`}
created: <% tp.date.now("YYYY-MM-DD[T]HH:mm:ssZ") %>
tags: 
  - course_home
  - education
  - <% courseId %>
  - ${this.settings.schoolAbbreviation}/<% courseYear %>/<% courseSeason %>/<% courseId %>
---

<%*
// Tuckers Tools Course Creation
// 
// NOTE: For the best experience, use the "Create New Course" command 
// from the command palette instead of using this template directly.
// 
// If you encounter 'prompt() is not supported' errors, this means the 
// tp.system functions are not available in your current context.
// Use the plugin command instead: Command Palette \u2192 'Create New Course'

const { exec } = require("child_process");

let courseName = "New Course";
let courseSeason = "Fall"; 
let courseYear = new Date().getFullYear().toString();
let courseId = "COURSE_ID";

// Try to use system prompts, with graceful fallback
try {
  if (tp && tp.system && tp.system.prompt) {
    courseName = await tp.system.prompt("Course Name (e.g. PSI-101 - Intro to Psych)") || courseName;
    courseSeason = await tp.system.suggester(["Fall","Winter","Spring","Summer"],["Fall","Winter","Spring","Summer"], "Season") || courseSeason;
    courseYear = await tp.system.prompt("Year") || courseYear;
    courseId = courseName.split(' - ')[0] || courseName.replace(/[^a-zA-Z0-9]/g, "_");
  } else {
    // Fallback if tp.system is not available
    console.log("System prompts not available, use the plugin command instead");
  }
} catch (e) {
  console.error("Error with system prompts:", e.message);
  console.log("Use the plugin command: Command Palette \u2192 'Create New Course'");
}

// Move file to appropriate location
await tp.file.move(\`/\${courseYear}/\${courseSeason}/\${courseName}/\${courseName}\`);

// Create attachments folder
try {
  await app.vault.createFolder(\`\${courseYear}/\${courseSeason}/\${courseName}/Attachments\`);
} catch (e) {
  // Folder might already exist
}
%>

# <% courseName %>

## Course Information
**Course ID**: <% courseId %>
**Term**: <% courseSeason %> <% courseYear %>
**School**: ${this.settings.schoolName}

## Instructor
**Name**: 
**Email**: 
**Office Hours**: 

## Course Description

## Learning Objectives

## Required Texts
\`\`\`meta-bind-js-view
{texts} as texts
---
const availableTexts = app.vault.getFiles().filter(file => file.extension == 'pdf').map(f => f?.name)
const escapeRegex = /[,\`'()]/g;
options = availableTexts.map(t => \`option([[\${t.replace(escapeRegex,$1)}]], \${t.replace(escapeRegex,$1)})\` )
const str = \\\`INPUT[inlineListSuggester(\${options.join(", ")}):texts]\\\`
return engine.markdown.create(str)
\`\`\`

## Schedule

## Assignments

## Resources

## Vocabulary
\`\`\`dataviewjs
// Vocabulary aggregation code would go here
\`\`\`

## Due Dates
\`\`\`dataviewjs
// Due dates aggregation code would go here
\`\`\``;
  }
  generateCourseIndexTemplate() {
    return `---
content_type: course_index
tags:
  - index
---

# Course Index

## Modules

## Chapters

## Assignments

## Resources

## Vocabulary

## Due Dates`;
  }
  generateModuleTemplate() {
    return `---
${this.settings.useEnhancedMetadata ? `course_id: <% courseId %>
module_number: <% moduleNumber %>
week_number: <% weekNumber %>
class_day: <% dayOfWeek %>
content_type: module
parent_course: "[[<% course %>]]"` : `course_id: <% courseId %>
module_number: <% moduleNumber %>
week_number: <% weekNumber %>
class_day: <% dayOfWeek %>`}
created: <% tp.date.now("YYYY-MM-DD[T]HH:mm:ssZ") %>
tags:
  - education
  - <% courseId %>
  - module
---

<%*
const { season, moduleNumber, weekNumber, course, courseId, discipline, dayOfWeek } = await tp.user.new_module(app, tp, "2025");
let title = courseId
if (moduleNumber && weekNumber) { title = \`M\${moduleNumber}/W\${weekNumber}\`}
else if (moduleNumber) { title = \`M\${moduleNumber}\` } 
else if (weekNumber) { title = \`W\${weekNumber}\`}
%>

# [[<% course %>]] - <% title %> - <% dayOfWeek %>

## Learning Objectives

## Reading Assignment

## Lecture Notes

## Discussion Questions

## Assignments
| Date | Assignment | Status |
| ---- | ---------- | ------ |
|      |            |        |

## Vocabulary

## Additional Resources`;
  }
  generateChapterTemplate() {
    return `---
${this.settings.useEnhancedMetadata ? `course_id: <% courseId %>
chapter_number: <% chapterNumber %>
content_type: chapter
parent_course: "[[<% course %>]]"
text_reference: "[[<% text %>]]"` : `course_id: <% courseId %>
chapter_number: <% chapterNumber %>`}
created: <% tp.date.now("YYYY-MM-DD[T]HH:mm:ssZ") %>
tags:
  - education
  - <% courseId %>
  - chapter
---

<%*
const { chapterNumber, course, courseId, discipline, text} = await tp.user.new_chapter(tp);
%>

# [[<% text %>]] - Chapter <% chapterNumber %>

## Summary

## Key Concepts

## Vocabulary
- 

## Notes

## Discussion Questions

## Further Reading`;
  }
  generateAssignmentTemplate() {
    return `---
${this.settings.useEnhancedMetadata ? `course_id: <% courseId %>
assignment_type: <% assignmentType %>
due_date: <% dueDate %>
points: <% points %>
content_type: assignment
parent_course: "[[<% course %>]]"` : `course_id: <% courseId %>
assignment_type: <% assignmentType %>
due_date: <% dueDate %>`}
created: <% tp.date.now("YYYY-MM-DD[T]HH:mm:ssZ") %>
status: pending
tags:
  - education
  - <% courseId %>
  - assignment
---

# <% assignmentName %> - <% courseId %>

## Description

## Instructions

## Due Date
**Assigned**: <% tp.date.now("YYYY-MM-DD") %>
**Due**: <% dueDate %>

## Submission

## Grading Criteria

## Resources`;
  }
  generateDailyNoteTemplate() {
    return `---
content_type: daily_note
date: <% tp.date.now("YYYY-MM-DD") %>
tags:
  - daily
  - <% tp.date.now("YYYY") %>
  - <% tp.date.now("MM") %>
  - <% tp.date.now("DD") %>
---

# <% tp.date.now("YYYY-MM-DD - dddd") %>

<< [[<% tp.date.yesterday("YYYY-MM-DD") %>]] | [[<% tp.date.tomorrow("YYYY-MM-DD") %>]] >>

## Today's Focus

## Courses Worked On
- 

## Tasks Completed
- [ ] 

## Vocabulary Reviewed
- 

## Assignments Due
- 

## Learning Achievements

## Challenges

## Tomorrow's Plan

## Reflection`;
  }
  generateVocabularyTemplate() {
    return `## <% term %>
**Term**: <% term %>
**Part of Speech**: 
**Definition**: 
**Context**: 
**Examples**: 
**Related Terms**: 
**See Also**:`;
  }
  generateDueDateTemplate() {
    return `| <% dueDate %> | <% assignment %> | <% status %> |`;
  }
  createREADME(basePath) {
    return __async(this, null, function* () {
      const readmeContent = `# Tuckers Tools Templates

This directory contains templates for the Tuckers Tools Obsidian plugin.

## Template Categories

- **Courses**: Templates for creating and organizing courses
- **Modules**: Templates for course modules
- **Chapters**: Templates for chapter notes
- **Assignments**: Templates for assignments
- **Daily**: Templates for daily notes
- **Utilities**: Helper templates

## Usage

These templates are designed to work with the Tuckers Tools plugin. To use them:

1. Install the Tuckers Tools plugin
2. Configure your settings in the plugin settings tab
3. Use the "Insert Template" command to apply these templates to new notes

## Customization

Feel free to customize these templates to suit your needs. The plugin will not overwrite your changes when updating templates.`;
      yield this.writeTemplateFile(`${basePath}/README.md`, readmeContent);
    });
  }
};

// courseWizard.ts
var import_obsidian3 = require("obsidian");
var CourseCreationWizard = class {
  constructor(app, settings) {
    this.app = app;
    this.settings = settings;
  }
  createCourseHomepage() {
    return __async(this, null, function* () {
      try {
        const courseDetails = yield this.promptCourseDetails();
        if (!courseDetails) {
          return false;
        }
        const folderPath = yield this.createCourseFolderStructure(courseDetails);
        yield this.createCourseHomepageNote(courseDetails, folderPath);
        yield this.createAttachmentsFolder(folderPath);
        new import_obsidian3.Notice(`Course "${courseDetails.courseName}" created successfully!`);
        console.log(
          `Course created: ${courseDetails.courseName} at ${folderPath}`
        );
        return true;
      } catch (error) {
        console.error("Error creating course:", error);
        new import_obsidian3.Notice(`Error creating course: ${error.message}`);
        return false;
      }
    });
  }
  promptCourseDetails() {
    return __async(this, null, function* () {
      var _a;
      try {
        const courseName = yield this.promptWithValidation(
          "Course Name",
          "Enter course name (e.g., PSI-101 - Intro to Psychology)",
          (value) => value.trim().length > 0,
          "Course name is required"
        );
        if (!courseName)
          return null;
        const courseSeason = yield this.promptWithOptions(
          "Season",
          "Select semester/season",
          ["Fall", "Winter", "Spring", "Summer"]
        );
        if (!courseSeason)
          return null;
        const courseYear = yield this.promptWithValidation(
          "Year",
          "Enter academic year (e.g., 2025)",
          (value) => /^\d{4}$/.test(value.trim()),
          "Please enter a valid 4-digit year"
        );
        if (!courseYear)
          return null;
        const courseId = ((_a = courseName.split(" - ")[0]) == null ? void 0 : _a.trim()) || slugify(courseName);
        return {
          courseName,
          courseSeason,
          courseYear,
          courseId
        };
      } catch (error) {
        console.error("Error prompting for course details:", error);
        return null;
      }
    });
  }
  promptWithValidation(title, message, validator, errorMessage) {
    return __async(this, null, function* () {
      const value = prompt(`${title}: ${message}`);
      if (!value)
        return null;
      if (!validator(value)) {
        new import_obsidian3.Notice(errorMessage);
        return yield this.promptWithValidation(
          title,
          message,
          validator,
          errorMessage
        );
      }
      return value.trim();
    });
  }
  promptWithOptions(title, message, options) {
    return __async(this, null, function* () {
      const choice = prompt(
        `${title}: ${message}
Options: ${options.join(", ")}
Enter your choice:`
      );
      if (!choice)
        return null;
      const trimmedChoice = choice.trim();
      if (options.includes(trimmedChoice)) {
        return trimmedChoice;
      }
      new import_obsidian3.Notice(`Please select one of: ${options.join(", ")}`);
      return yield this.promptWithOptions(title, message, options);
    });
  }
  createCourseFolderStructure(courseDetails) {
    return __async(this, null, function* () {
      const folderPath = `${courseDetails.courseYear}/${courseDetails.courseSeason}/${courseDetails.courseName}`;
      try {
        yield this.app.vault.createFolder(folderPath);
        console.log(`Created course folder: ${folderPath}`);
        return folderPath;
      } catch (error) {
        console.log(`Course folder already exists or created: ${folderPath}`);
        return folderPath;
      }
    });
  }
  createCourseHomepageNote(courseDetails, folderPath) {
    return __async(this, null, function* () {
      const notePath = `${folderPath}/${courseDetails.courseName}.md`;
      const content = this.generateCourseHomepageContent(courseDetails);
      try {
        yield this.app.vault.create(notePath, content);
        console.log(`Created course homepage: ${notePath}`);
      } catch (error) {
        console.error(`Error creating course homepage: ${error}`);
        throw error;
      }
    });
  }
  createAttachmentsFolder(folderPath) {
    return __async(this, null, function* () {
      const attachmentsPath = `${folderPath}/Attachments`;
      try {
        yield this.app.vault.createFolder(attachmentsPath);
        console.log(`Created attachments folder: ${attachmentsPath}`);
      } catch (error) {
        console.log(`Attachments folder already exists: ${attachmentsPath}`);
      }
    });
  }
  generateCourseHomepageContent(courseDetails) {
    const enhancedMetadata = this.settings.useEnhancedMetadata;
    return `---
${enhancedMetadata ? `course_id: ${courseDetails.courseId}
course_name: ${courseDetails.courseName}
course_term: ${courseDetails.courseSeason} ${courseDetails.courseYear}
course_year: ${courseDetails.courseYear}
course_semester: ${courseDetails.courseSeason}
content_type: course_homepage
school: ${this.settings.schoolName}
school_abbreviation: ${this.settings.schoolAbbreviation}` : `course_id: ${courseDetails.courseId}
title: ${courseDetails.courseName}`}
created: ${new Date().toISOString()}
tags:
 - course_home
 - education
 - ${courseDetails.courseId}
 - ${this.settings.schoolAbbreviation}/${courseDetails.courseYear}/${courseDetails.courseSeason}/${courseDetails.courseId}
---


# ${courseDetails.courseName}

## Course Information
**Course ID**: ${courseDetails.courseId}
**Term**: ${courseDetails.courseSeason} ${courseDetails.courseYear}
**School**: ${this.settings.schoolName}

## Instructor
**Name**:
**Email**:
**Office Hours**:

## Course Description

## Learning Objectives

## Required Texts

## Schedule

## Assignments

## Resources

## Vocabulary

## Due Dates`;
  }
};

// vocabulary.ts
var import_obsidian4 = require("obsidian");
var VocabularyExtractor = class {
  constructor(app) {
    this.app = app;
  }
  extractVocabularyFromNote(content) {
    const vocabRegex = /^#+ Vocabulary.*\n((?:.*?\n)*?)(?=^\s*#\s|$)/m;
    const vocabMatches = content == null ? void 0 : content.match(vocabRegex);
    if (vocabMatches) {
      const vocabData = vocabMatches[1].trim();
      const cleanedVocab = vocabData.replace(/\[\[.*?\]\]/g, "").replace(/^\s*-\s*/gm, "").split("\n").map((term) => term.trim()).filter((term) => term.length > 0);
      return cleanedVocab;
    }
    return [];
  }
  extractVocabularyFromCourse(courseId) {
    return __async(this, null, function* () {
      console.log(`Extracting vocabulary for course: ${courseId}`);
      try {
        const courseNotes = yield this.findCourseNotes(courseId);
        if (courseNotes.length === 0) {
          console.log(`No notes found for course: ${courseId}`);
          return {};
        }
        const vocabularyData = {};
        for (const note of courseNotes) {
          try {
            const content = yield this.app.vault.read(note);
            const vocabulary = this.extractVocabularyFromNote(content);
            if (vocabulary.length > 0) {
              vocabularyData[note.basename] = vocabulary;
            }
          } catch (error) {
            console.error(`Error reading note ${note.path}:`, error);
          }
        }
        console.log(
          `Extracted vocabulary from ${Object.keys(vocabularyData).length} notes for course: ${courseId}`
        );
        return vocabularyData;
      } catch (error) {
        console.error(
          `Error extracting vocabulary for course ${courseId}:`,
          error
        );
        return {};
      }
    });
  }
  findCourseNotes(courseId) {
    return __async(this, null, function* () {
      const notes = [];
      const files = this.app.vault.getMarkdownFiles();
      for (const file of files) {
        if (file.path.includes(courseId) || (yield this.noteBelongsToCourse(file, courseId))) {
          notes.push(file);
        }
      }
      return notes;
    });
  }
  noteBelongsToCourse(file, courseId) {
    return __async(this, null, function* () {
      try {
        const content = yield this.app.vault.read(file);
        const frontmatterMatch = content.match(/^---\n([\s\S]*?)\n---/);
        if (frontmatterMatch) {
          const frontmatter = frontmatterMatch[1];
          return frontmatter.includes(`course_id: ${courseId}`) || frontmatter.includes(`course_id:${courseId}`);
        }
        return false;
      } catch (error) {
        console.error(
          `Error checking if note ${file.path} belongs to course ${courseId}:`,
          error
        );
        return false;
      }
    });
  }
  generateVocabularyIndex(courseId, vocabularyData) {
    return __async(this, null, function* () {
      const allTerms = [];
      const termSources = {};
      for (const [noteName, terms] of Object.entries(vocabularyData)) {
        for (const term of terms) {
          if (!allTerms.includes(term)) {
            allTerms.push(term);
            termSources[term] = [];
          }
          termSources[term].push(noteName);
        }
      }
      allTerms.sort();
      let content = `# Vocabulary Index - ${courseId}

`;
      content += `Total unique terms: ${allTerms.length}

`;
      for (const term of allTerms) {
        content += `## ${term}
`;
        content += `**Sources:** ${termSources[term].join(", ")}

`;
        content += `**Definition:**

`;
        content += `**Context:**

`;
        content += `**Examples:**

`;
        content += `---

`;
      }
      return content;
    });
  }
  createVocabularyIndexFile(courseId) {
    return __async(this, null, function* () {
      try {
        const vocabularyData = yield this.extractVocabularyFromCourse(courseId);
        if (Object.keys(vocabularyData).length === 0) {
          console.log(`No vocabulary found for course: ${courseId}`);
          return;
        }
        const indexContent = yield this.generateVocabularyIndex(
          courseId,
          vocabularyData
        );
        const fileName = `${courseId} - Vocabulary Index.md`;
        const filePath = `Courses/${courseId}/${fileName}`;
        try {
          yield this.app.vault.create(filePath, indexContent);
          console.log(`Created vocabulary index file: ${filePath}`);
        } catch (error) {
          const existingFile = this.app.vault.getAbstractFileByPath(filePath);
          if (existingFile && existingFile instanceof import_obsidian4.TFile) {
            yield this.app.vault.modify(existingFile, indexContent);
            console.log(`Updated vocabulary index file: ${filePath}`);
          }
        }
      } catch (error) {
        console.error(
          `Error creating vocabulary index for course ${courseId}:`,
          error
        );
        throw error;
      }
    });
  }
};

// dueDates.ts
var import_obsidian5 = require("obsidian");
var DueDatesParser = class {
  constructor(app) {
    this.app = app;
  }
  parseDueDatesFromNote(content) {
    const dueDatesRegex = /# Due Dates[\s\S]*?(?=\n#|$)/;
    const matches = content == null ? void 0 : content.match(dueDatesRegex);
    if (!matches) {
      return [];
    }
    const dueDatesSection = matches[0];
    const dueDates = [];
    const tableRegex = /\|[\s\S]*?\n/g;
    const tableMatches = dueDatesSection.match(tableRegex);
    if (tableMatches) {
      for (const table of tableMatches) {
        const rows = table.trim().split("\n").filter((row) => row.startsWith("|"));
        const parsedRows = this.parseTableRows(rows);
        dueDates.push(...parsedRows);
      }
    }
    return dueDates;
  }
  parseTableRows(rows) {
    if (rows.length < 2)
      return [];
    const dueDates = [];
    for (let i = 1; i < rows.length; i++) {
      const row = rows[i];
      const columns = row.split("|").map((col) => col.trim()).filter((col) => col);
      if (columns.length >= 2) {
        const [date, assignment, status = "pending"] = columns;
        if (date && assignment && this.isValidDate(date)) {
          dueDates.push({ date, assignment, status });
        }
      }
    }
    return dueDates;
  }
  isValidDate(dateString) {
    const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
    return dateRegex.test(dateString) && !isNaN(Date.parse(dateString));
  }
  parseDueDatesFromCourse(courseId, startDate, endDate) {
    return __async(this, null, function* () {
      console.log(`Parsing due dates for course: ${courseId}`);
      try {
        const courseNotes = yield this.findCourseNotes(courseId);
        if (courseNotes.length === 0) {
          console.log(`No notes found for course: ${courseId}`);
          return [];
        }
        const allDueDates = [];
        for (const note of courseNotes) {
          try {
            const content = yield this.app.vault.read(note);
            const dueDates = this.parseDueDatesFromNote(content);
            const dueDatesWithSource = dueDates.map((dueDate) => __spreadProps(__spreadValues({}, dueDate), {
              source: note.basename
            }));
            allDueDates.push(...dueDatesWithSource);
          } catch (error) {
            console.error(`Error reading note ${note.path}:`, error);
          }
        }
        let filteredDueDates = allDueDates;
        if (startDate || endDate) {
          filteredDueDates = this.filterByDateRange(
            allDueDates,
            startDate,
            endDate
          );
        }
        filteredDueDates.sort(
          (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()
        );
        console.log(
          `Found ${filteredDueDates.length} due dates for course: ${courseId}`
        );
        return filteredDueDates;
      } catch (error) {
        console.error(`Error parsing due dates for course ${courseId}:`, error);
        return [];
      }
    });
  }
  findCourseNotes(courseId) {
    return __async(this, null, function* () {
      const notes = [];
      const files = this.app.vault.getMarkdownFiles();
      for (const file of files) {
        if (file.path.includes(courseId) || (yield this.noteBelongsToCourse(file, courseId))) {
          notes.push(file);
        }
      }
      return notes;
    });
  }
  noteBelongsToCourse(file, courseId) {
    return __async(this, null, function* () {
      try {
        const content = yield this.app.vault.read(file);
        const frontmatterMatch = content.match(/^---\n([\s\S]*?)\n---/);
        if (frontmatterMatch) {
          const frontmatter = frontmatterMatch[1];
          return frontmatter.includes(`course_id: ${courseId}`) || frontmatter.includes(`course_id:${courseId}`);
        }
        return false;
      } catch (error) {
        console.error(
          `Error checking if note ${file.path} belongs to course ${courseId}:`,
          error
        );
        return false;
      }
    });
  }
  filterByDateRange(dueDates, startDate, endDate) {
    return dueDates.filter((dueDate) => {
      const dueDateTime = new Date(dueDate.date).getTime();
      if (startDate && dueDateTime < new Date(startDate).getTime()) {
        return false;
      }
      if (endDate && dueDateTime > new Date(endDate).getTime()) {
        return false;
      }
      return true;
    });
  }
  generateDueDatesSummary(courseId, dueDates) {
    return __async(this, null, function* () {
      if (dueDates.length === 0) {
        return `# Due Dates Summary - ${courseId}

No due dates found.
`;
      }
      const byStatus = dueDates.reduce((acc, dueDate) => {
        if (!acc[dueDate.status]) {
          acc[dueDate.status] = [];
        }
        acc[dueDate.status].push(dueDate);
        return acc;
      }, {});
      let content = `# Due Dates Summary - ${courseId}

`;
      content += `Total assignments: ${dueDates.length}

`;
      for (const [status, items] of Object.entries(byStatus)) {
        content += `## ${status.charAt(0).toUpperCase() + status.slice(1)} (${items.length})

`;
        content += `| Date | Assignment | Source |
`;
        content += `| ---- | ---------- | ------ |
`;
        for (const item of items) {
          content += `| ${item.date} | ${item.assignment} | ${item.source} |
`;
        }
        content += `
`;
      }
      return content;
    });
  }
  createDueDatesSummaryFile(courseId, startDate, endDate) {
    return __async(this, null, function* () {
      try {
        const dueDates = yield this.parseDueDatesFromCourse(
          courseId,
          startDate,
          endDate
        );
        const summaryContent = yield this.generateDueDatesSummary(
          courseId,
          dueDates
        );
        const fileName = `${courseId} - Due Dates Summary.md`;
        const filePath = `Courses/${courseId}/${fileName}`;
        try {
          yield this.app.vault.create(filePath, summaryContent);
          console.log(`Created due dates summary file: ${filePath}`);
        } catch (error) {
          const existingFile = this.app.vault.getAbstractFileByPath(filePath);
          if (existingFile && existingFile instanceof import_obsidian5.TFile) {
            yield this.app.vault.modify(existingFile, summaryContent);
            console.log(`Updated due dates summary file: ${filePath}`);
          }
        }
      } catch (error) {
        console.error(
          `Error creating due dates summary for course ${courseId}:`,
          error
        );
        throw error;
      }
    });
  }
};

// dailyNotes.ts
var import_obsidian6 = require("obsidian");
var DailyNotesIntegration = class {
  constructor(app) {
    this.app = app;
  }
  getTodaysActivities() {
    return __async(this, null, function* () {
      console.log("Getting today's academic activities");
      try {
        const today = new Date();
        const todayString = today.toISOString().split("T")[0];
        const files = this.app.vault.getMarkdownFiles();
        const todaysFiles = [];
        for (const file of files) {
          const fileDate = this.extractDateFromPath(file.path);
          if (fileDate === todayString) {
            todaysFiles.push(file);
          }
        }
        const activities = [];
        for (const file of todaysFiles) {
          const activity = yield this.analyzeFileActivity(file);
          if (activity) {
            activities.push(activity);
          }
        }
        console.log(`Found ${activities.length} academic activities for today`);
        return activities;
      } catch (error) {
        console.error("Error getting today's activities:", error);
        return [];
      }
    });
  }
  getCourseActivityForDate(courseId, date) {
    return __async(this, null, function* () {
      console.log(`Getting activity for course ${courseId} on date ${date}`);
      try {
        const courseFiles = yield this.findCourseFilesForDate(courseId, date);
        const activities = [];
        for (const file of courseFiles) {
          const content = yield this.app.vault.read(file);
          const fileType = this.determineFileType(file, content);
          activities.push({
            file: file.basename,
            type: fileType
          });
        }
        console.log(
          `Found ${activities.length} activities for course ${courseId} on ${date}`
        );
        return activities;
      } catch (error) {
        console.error(
          `Error getting course activity for ${courseId} on ${date}:`,
          error
        );
        return [];
      }
    });
  }
  extractDateFromPath(filePath) {
    const dateRegex = /(\d{4}-\d{2}-\d{2})/g;
    const matches = filePath.match(dateRegex);
    return matches ? matches[matches.length - 1] : null;
  }
  analyzeFileActivity(file) {
    return __async(this, null, function* () {
      try {
        const content = yield this.app.vault.read(file);
        const fileType = this.determineFileType(file, content);
        const courseId = this.extractCourseIdFromContent(content) || this.extractCourseIdFromPath(file.path);
        return {
          file: file.basename,
          type: fileType,
          course: courseId || void 0
        };
      } catch (error) {
        console.error(`Error analyzing file ${file.path}:`, error);
        return null;
      }
    });
  }
  determineFileType(file, content) {
    const path = file.path.toLowerCase();
    if (path.includes("daily") || content.includes("content_type: daily_note")) {
      return "daily_note";
    }
    if (path.includes("courses") || content.includes("course_id:")) {
      if (content.includes("content_type: course_homepage")) {
        return "course_homepage";
      }
      if (content.includes("content_type: module")) {
        return "module";
      }
      if (content.includes("content_type: chapter")) {
        return "chapter";
      }
      if (content.includes("content_type: assignment")) {
        return "assignment";
      }
      return "course_note";
    }
    if (content.includes("## ") && content.match(/^\*\*Term\*\*:/m)) {
      return "vocabulary_entry";
    }
    return "other";
  }
  extractCourseIdFromContent(content) {
    const courseIdRegex = /course_id:\s*([A-Z]{2,4}-\d{3})/;
    const match = content.match(courseIdRegex);
    return match ? match[1] : null;
  }
  extractCourseIdFromPath(filePath) {
    const courseIdRegex = /([A-Z]{2,4}-\d{3})/g;
    const matches = filePath.match(courseIdRegex);
    return matches ? matches[matches.length - 1] : null;
  }
  findCourseFilesForDate(courseId, date) {
    return __async(this, null, function* () {
      const files = [];
      const allFiles = this.app.vault.getMarkdownFiles();
      for (const file of allFiles) {
        if (file.path.includes(courseId) || (yield this.fileBelongsToCourse(file, courseId))) {
          const fileDate = this.extractDateFromPath(file.path);
          if (fileDate === date) {
            files.push(file);
          }
        }
      }
      return files;
    });
  }
  fileBelongsToCourse(file, courseId) {
    return __async(this, null, function* () {
      try {
        const content = yield this.app.vault.read(file);
        return this.extractCourseIdFromContent(content) === courseId;
      } catch (error) {
        console.error(
          `Error checking if file ${file.path} belongs to course ${courseId}:`,
          error
        );
        return false;
      }
    });
  }
  generateDailySummary(date) {
    return __async(this, null, function* () {
      const targetDate = date || new Date().toISOString().split("T")[0];
      const activities = yield this.getCourseActivityForDate("", targetDate);
      if (activities.length === 0) {
        return `# Academic Activities - ${targetDate}

No academic activities recorded for this date.
`;
      }
      const byCourse = {};
      const noCourse = [];
      for (const activity of activities) {
        if (activity.file.includes("Courses/")) {
          const pathParts = activity.file.split("/");
          const courseIndex = pathParts.findIndex((part) => part.includes("-"));
          if (courseIndex >= 0) {
            const courseId = pathParts[courseIndex];
            if (!byCourse[courseId]) {
              byCourse[courseId] = [];
            }
            byCourse[courseId].push(activity);
          } else {
            noCourse.push(activity);
          }
        } else {
          noCourse.push(activity);
        }
      }
      let content = `# Academic Activities - ${targetDate}

`;
      content += `Total activities: ${activities.length}

`;
      for (const [courseId, courseActivities] of Object.entries(byCourse)) {
        content += `## ${courseId}

`;
        content += `| File | Type |
`;
        content += `| ---- | ---- |
`;
        for (const activity of courseActivities) {
          content += `| ${activity.file} | ${activity.type} |
`;
        }
        content += `
`;
      }
      if (noCourse.length > 0) {
        content += `## Other Activities

`;
        content += `| File | Type |
`;
        content += `| ---- | ---- |
`;
        for (const activity of noCourse) {
          content += `| ${activity.file} | ${activity.type} |
`;
        }
        content += `
`;
      }
      return content;
    });
  }
  createDailySummaryFile(date) {
    return __async(this, null, function* () {
      try {
        const targetDate = date || new Date().toISOString().split("T")[0];
        const summaryContent = yield this.generateDailySummary(targetDate);
        const fileName = `${targetDate} - Academic Summary.md`;
        const filePath = `Daily/${fileName}`;
        try {
          yield this.app.vault.create(filePath, summaryContent);
          console.log(`Created daily summary file: ${filePath}`);
        } catch (error) {
          const existingFile = this.app.vault.getAbstractFileByPath(filePath);
          if (existingFile && existingFile instanceof import_obsidian6.TFile) {
            yield this.app.vault.modify(existingFile, summaryContent);
            console.log(`Updated daily summary file: ${filePath}`);
          }
        }
      } catch (error) {
        console.error(`Error creating daily summary for ${date}:`, error);
        throw error;
      }
    });
  }
};

// main.ts
var TuckersToolsPlugin = class extends import_obsidian7.Plugin {
  onload() {
    return __async(this, null, function* () {
      console.log("Loading Tuckers Tools plugin");
      yield this.loadSettings();
      this.templateManager = new TemplateManager(this.app, this.settings);
      this.courseWizard = new CourseCreationWizard(this.app, this.settings);
      this.vocabularyExtractor = new VocabularyExtractor(this.app);
      this.dueDatesParser = new DueDatesParser(this.app);
      this.dailyNotesIntegration = new DailyNotesIntegration(this.app);
      this.addSettingTab(new TuckersToolsSettingTab(this.app, this));
      this.initializeTemplaterFunctions();
      this.addCommand({
        id: "install-templates",
        name: "Install/Update Tuckers Tools Templates",
        callback: () => {
          this.templateManager.installTemplates();
        }
      });
      this.addCommand({
        id: "update-templates",
        name: "Update Tuckers Tools Templates",
        callback: () => {
          this.templateManager.updateTemplates();
        }
      });
      this.addCommand({
        id: "create-course",
        name: "Create New Course",
        callback: () => {
          this.courseWizard.createCourseHomepage();
        }
      });
      this.addCommand({
        id: "extract-vocabulary",
        name: "Extract Course Vocabulary",
        callback: () => __async(this, null, function* () {
          const courseId = yield this.promptForCourseId(
            "Enter course ID to extract vocabulary from"
          );
          if (courseId) {
            yield this.vocabularyExtractor.createVocabularyIndexFile(courseId);
          }
        })
      });
      this.addCommand({
        id: "generate-due-dates-summary",
        name: "Generate Due Dates Summary",
        callback: () => __async(this, null, function* () {
          const courseId = yield this.promptForCourseId(
            "Enter course ID to generate due dates summary for"
          );
          if (courseId) {
            yield this.dueDatesParser.createDueDatesSummaryFile(courseId);
          }
        })
      });
      this.addCommand({
        id: "generate-daily-summary",
        name: "Generate Daily Academic Summary",
        callback: () => __async(this, null, function* () {
          const date = yield this.promptForDate(
            "Enter date (YYYY-MM-DD) or leave empty for today"
          );
          yield this.dailyNotesIntegration.createDailySummaryFile(
            date || void 0
          );
        })
      });
      this.addStatusBarItem().setText("Tuckers Tools");
    });
  }
  promptForCourseId(message) {
    return __async(this, null, function* () {
      const courseId = prompt(message + "\n\nExample: PSI-101");
      return courseId ? courseId.trim() : null;
    });
  }
  promptForDate(message) {
    return __async(this, null, function* () {
      const date = prompt(
        message + "\n\nExample: 2025-01-15 or leave empty for today"
      );
      return date ? date.trim() : null;
    });
  }
  onunload() {
    console.log("Unloading Tuckers Tools plugin");
  }
  initializeTemplaterFunctions() {
    return __async(this, null, function* () {
      const templaterPlugin = this.app.plugins.getPlugin("templater-obsidian");
      if (!templaterPlugin) {
        console.log("Templater plugin not found. Course templates will not work properly.");
        return;
      }
      try {
        if (templaterPlugin && templaterPlugin.templater) {
          if (!templaterPlugin.templater.functions) {
            templaterPlugin.templater.functions = {};
          }
          templaterPlugin.templater.functions["new_module"] = (app, tp, year) => __async(this, null, function* () {
            return this.newModuleFunction(app, tp, year);
          });
          templaterPlugin.templater.functions["new_chapter"] = (tp) => __async(this, null, function* () {
            return this.newChapterFunction(tp);
          });
          console.log("Tuckers Tools templater functions registered successfully");
        } else {
          console.error("Could not register templater functions - templater object not found");
        }
      } catch (e) {
        console.error("Error registering templater functions:", e);
      }
    });
  }
  newModuleFunction(app, tp, year) {
    return __async(this, null, function* () {
      var _a;
      const moduleNumber = yield tp.system.prompt("Module Number (optional)", "");
      const weekNumber = yield tp.system.prompt("Week Number (optional)", "");
      const course = yield tp.system.suggester(
        () => app.vault.getMarkdownFiles().filter((f) => f.path.includes("Courses")).map((f) => f.basename),
        app.vault.getMarkdownFiles().filter((f) => f.path.includes("Courses"))
      );
      const courseId = course ? course.split(" - ")[0] || course : "";
      const discipline = course ? ((_a = course.split(" - ")[0]) == null ? void 0 : _a.substring(0, 3)) || "GEN" : "GEN";
      const dayOptions = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
      const dayOfWeek = yield tp.system.suggester(dayOptions, dayOptions, "Day of Week");
      return {
        season: "Fall",
        // This would normally be dynamically determined
        moduleNumber: moduleNumber || null,
        weekNumber: weekNumber || null,
        course,
        courseId,
        discipline,
        dayOfWeek
      };
    });
  }
  newChapterFunction(tp) {
    return __async(this, null, function* () {
      var _a;
      const chapterNumber = yield tp.system.prompt("Chapter Number", "");
      const course = yield tp.system.suggester(
        () => tp.app.vault.getMarkdownFiles().filter((f) => f.path.includes("Courses")).map((f) => f.basename),
        tp.app.vault.getMarkdownFiles().filter((f) => f.path.includes("Courses"))
      );
      const courseId = course ? course.split(" - ")[0] || course : "";
      const discipline = course ? ((_a = course.split(" - ")[0]) == null ? void 0 : _a.substring(0, 3)) || "GEN" : "GEN";
      const textOptions = tp.app.vault.getFiles().filter((f) => f.extension === "pdf").map((f) => f.basename);
      const text = yield tp.system.suggester(textOptions, textOptions, "Textbook");
      return {
        chapterNumber: chapterNumber || "",
        course,
        courseId,
        discipline,
        text
      };
    });
  }
  loadSettings() {
    return __async(this, null, function* () {
      this.settings = Object.assign({}, DEFAULT_SETTINGS, yield this.loadData());
    });
  }
  saveSettings() {
    return __async(this, null, function* () {
      yield this.saveData(this.settings);
    });
  }
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsibWFpbi50cyIsICJzZXR0aW5ncy50cyIsICJ1dGlscy50cyIsICJ0ZW1wbGF0ZU1hbmFnZXIudHMiLCAiY291cnNlV2l6YXJkLnRzIiwgInZvY2FidWxhcnkudHMiLCAiZHVlRGF0ZXMudHMiLCAiZGFpbHlOb3Rlcy50cyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiaW1wb3J0IHsgUGx1Z2luIH0gZnJvbSBcIm9ic2lkaWFuXCJcbmltcG9ydCB7XG4gIFR1Y2tlcnNUb29sc1NldHRpbmdzLFxuICBERUZBVUxUX1NFVFRJTkdTLFxuICBUdWNrZXJzVG9vbHNTZXR0aW5nVGFiXG59IGZyb20gXCIuL3NldHRpbmdzXCJcbmltcG9ydCB7IFRlbXBsYXRlTWFuYWdlciB9IGZyb20gXCIuL3RlbXBsYXRlTWFuYWdlclwiXG5pbXBvcnQgeyBDb3Vyc2VDcmVhdGlvbldpemFyZCB9IGZyb20gXCIuL2NvdXJzZVdpemFyZFwiXG5pbXBvcnQgeyBWb2NhYnVsYXJ5RXh0cmFjdG9yIH0gZnJvbSBcIi4vdm9jYWJ1bGFyeVwiXG5pbXBvcnQgeyBEdWVEYXRlc1BhcnNlciB9IGZyb20gXCIuL2R1ZURhdGVzXCJcbmltcG9ydCB7IERhaWx5Tm90ZXNJbnRlZ3JhdGlvbiB9IGZyb20gXCIuL2RhaWx5Tm90ZXNcIlxuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBUdWNrZXJzVG9vbHNQbHVnaW4gZXh0ZW5kcyBQbHVnaW4ge1xuICBzZXR0aW5nczogVHVja2Vyc1Rvb2xzU2V0dGluZ3NcbiAgdGVtcGxhdGVNYW5hZ2VyOiBUZW1wbGF0ZU1hbmFnZXJcbiAgY291cnNlV2l6YXJkOiBDb3Vyc2VDcmVhdGlvbldpemFyZFxuICB2b2NhYnVsYXJ5RXh0cmFjdG9yOiBWb2NhYnVsYXJ5RXh0cmFjdG9yXG4gIGR1ZURhdGVzUGFyc2VyOiBEdWVEYXRlc1BhcnNlclxuICBkYWlseU5vdGVzSW50ZWdyYXRpb246IERhaWx5Tm90ZXNJbnRlZ3JhdGlvblxuXG4gIGFzeW5jIG9ubG9hZCgpIHtcbiAgICBjb25zb2xlLmxvZyhcIkxvYWRpbmcgVHVja2VycyBUb29scyBwbHVnaW5cIilcblxuICAgIC8vIExvYWQgc2V0dGluZ3NcbiAgICBhd2FpdCB0aGlzLmxvYWRTZXR0aW5ncygpXG5cbiAgICAvLyBJbml0aWFsaXplIGNvbXBvbmVudHNcbiAgICB0aGlzLnRlbXBsYXRlTWFuYWdlciA9IG5ldyBUZW1wbGF0ZU1hbmFnZXIodGhpcy5hcHAsIHRoaXMuc2V0dGluZ3MpXG4gICAgdGhpcy5jb3Vyc2VXaXphcmQgPSBuZXcgQ291cnNlQ3JlYXRpb25XaXphcmQodGhpcy5hcHAsIHRoaXMuc2V0dGluZ3MpXG4gICAgdGhpcy52b2NhYnVsYXJ5RXh0cmFjdG9yID0gbmV3IFZvY2FidWxhcnlFeHRyYWN0b3IodGhpcy5hcHApXG4gICAgdGhpcy5kdWVEYXRlc1BhcnNlciA9IG5ldyBEdWVEYXRlc1BhcnNlcih0aGlzLmFwcClcbiAgICB0aGlzLmRhaWx5Tm90ZXNJbnRlZ3JhdGlvbiA9IG5ldyBEYWlseU5vdGVzSW50ZWdyYXRpb24odGhpcy5hcHApXG5cbiAgICAvLyBBZGQgc2V0dGluZ3MgdGFiXG4gICAgdGhpcy5hZGRTZXR0aW5nVGFiKG5ldyBUdWNrZXJzVG9vbHNTZXR0aW5nVGFiKHRoaXMuYXBwLCB0aGlzKSlcblxuICAgIC8vIEluaXRpYWxpemUgdGVtcGxhdGVyIGZ1bmN0aW9ucyBpZiB0ZW1wbGF0ZXIgaXMgYXZhaWxhYmxlXG4gICAgdGhpcy5pbml0aWFsaXplVGVtcGxhdGVyRnVuY3Rpb25zKClcblxuICAgIC8vIEFkZCBjb21tYW5kc1xuICAgIHRoaXMuYWRkQ29tbWFuZCh7XG4gICAgICBpZDogXCJpbnN0YWxsLXRlbXBsYXRlc1wiLFxuICAgICAgbmFtZTogXCJJbnN0YWxsL1VwZGF0ZSBUdWNrZXJzIFRvb2xzIFRlbXBsYXRlc1wiLFxuICAgICAgY2FsbGJhY2s6ICgpID0+IHtcbiAgICAgICAgdGhpcy50ZW1wbGF0ZU1hbmFnZXIuaW5zdGFsbFRlbXBsYXRlcygpXG4gICAgICB9XG4gICAgfSlcblxuICAgIHRoaXMuYWRkQ29tbWFuZCh7XG4gICAgICBpZDogXCJ1cGRhdGUtdGVtcGxhdGVzXCIsXG4gICAgICBuYW1lOiBcIlVwZGF0ZSBUdWNrZXJzIFRvb2xzIFRlbXBsYXRlc1wiLFxuICAgICAgY2FsbGJhY2s6ICgpID0+IHtcbiAgICAgICAgdGhpcy50ZW1wbGF0ZU1hbmFnZXIudXBkYXRlVGVtcGxhdGVzKClcbiAgICAgIH1cbiAgICB9KVxuXG4gICAgdGhpcy5hZGRDb21tYW5kKHtcbiAgICAgIGlkOiBcImNyZWF0ZS1jb3Vyc2VcIixcbiAgICAgIG5hbWU6IFwiQ3JlYXRlIE5ldyBDb3Vyc2VcIixcbiAgICAgIGNhbGxiYWNrOiAoKSA9PiB7XG4gICAgICAgIHRoaXMuY291cnNlV2l6YXJkLmNyZWF0ZUNvdXJzZUhvbWVwYWdlKClcbiAgICAgIH1cbiAgICB9KVxuXG4gICAgdGhpcy5hZGRDb21tYW5kKHtcbiAgICAgIGlkOiBcImV4dHJhY3Qtdm9jYWJ1bGFyeVwiLFxuICAgICAgbmFtZTogXCJFeHRyYWN0IENvdXJzZSBWb2NhYnVsYXJ5XCIsXG4gICAgICBjYWxsYmFjazogYXN5bmMgKCkgPT4ge1xuICAgICAgICBjb25zdCBjb3Vyc2VJZCA9IGF3YWl0IHRoaXMucHJvbXB0Rm9yQ291cnNlSWQoXG4gICAgICAgICAgXCJFbnRlciBjb3Vyc2UgSUQgdG8gZXh0cmFjdCB2b2NhYnVsYXJ5IGZyb21cIlxuICAgICAgICApXG4gICAgICAgIGlmIChjb3Vyc2VJZCkge1xuICAgICAgICAgIGF3YWl0IHRoaXMudm9jYWJ1bGFyeUV4dHJhY3Rvci5jcmVhdGVWb2NhYnVsYXJ5SW5kZXhGaWxlKGNvdXJzZUlkKVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfSlcblxuICAgIHRoaXMuYWRkQ29tbWFuZCh7XG4gICAgICBpZDogXCJnZW5lcmF0ZS1kdWUtZGF0ZXMtc3VtbWFyeVwiLFxuICAgICAgbmFtZTogXCJHZW5lcmF0ZSBEdWUgRGF0ZXMgU3VtbWFyeVwiLFxuICAgICAgY2FsbGJhY2s6IGFzeW5jICgpID0+IHtcbiAgICAgICAgY29uc3QgY291cnNlSWQgPSBhd2FpdCB0aGlzLnByb21wdEZvckNvdXJzZUlkKFxuICAgICAgICAgIFwiRW50ZXIgY291cnNlIElEIHRvIGdlbmVyYXRlIGR1ZSBkYXRlcyBzdW1tYXJ5IGZvclwiXG4gICAgICAgIClcbiAgICAgICAgaWYgKGNvdXJzZUlkKSB7XG4gICAgICAgICAgYXdhaXQgdGhpcy5kdWVEYXRlc1BhcnNlci5jcmVhdGVEdWVEYXRlc1N1bW1hcnlGaWxlKGNvdXJzZUlkKVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfSlcblxuICAgIHRoaXMuYWRkQ29tbWFuZCh7XG4gICAgICBpZDogXCJnZW5lcmF0ZS1kYWlseS1zdW1tYXJ5XCIsXG4gICAgICBuYW1lOiBcIkdlbmVyYXRlIERhaWx5IEFjYWRlbWljIFN1bW1hcnlcIixcbiAgICAgIGNhbGxiYWNrOiBhc3luYyAoKSA9PiB7XG4gICAgICAgIGNvbnN0IGRhdGUgPSBhd2FpdCB0aGlzLnByb21wdEZvckRhdGUoXG4gICAgICAgICAgXCJFbnRlciBkYXRlIChZWVlZLU1NLUREKSBvciBsZWF2ZSBlbXB0eSBmb3IgdG9kYXlcIlxuICAgICAgICApXG4gICAgICAgIGF3YWl0IHRoaXMuZGFpbHlOb3Rlc0ludGVncmF0aW9uLmNyZWF0ZURhaWx5U3VtbWFyeUZpbGUoXG4gICAgICAgICAgZGF0ZSB8fCB1bmRlZmluZWRcbiAgICAgICAgKVxuICAgICAgfVxuICAgIH0pXG5cbiAgICAvLyBBZGQgc3RhdHVzIGJhciBpdGVtXG4gICAgdGhpcy5hZGRTdGF0dXNCYXJJdGVtKCkuc2V0VGV4dChcIlR1Y2tlcnMgVG9vbHNcIilcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgcHJvbXB0Rm9yQ291cnNlSWQobWVzc2FnZTogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmcgfCBudWxsPiB7XG4gICAgY29uc3QgY291cnNlSWQgPSBwcm9tcHQobWVzc2FnZSArIFwiXFxuXFxuRXhhbXBsZTogUFNJLTEwMVwiKVxuICAgIHJldHVybiBjb3Vyc2VJZCA/IGNvdXJzZUlkLnRyaW0oKSA6IG51bGxcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgcHJvbXB0Rm9yRGF0ZShtZXNzYWdlOiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZyB8IG51bGw+IHtcbiAgICBjb25zdCBkYXRlID0gcHJvbXB0KFxuICAgICAgbWVzc2FnZSArIFwiXFxuXFxuRXhhbXBsZTogMjAyNS0wMS0xNSBvciBsZWF2ZSBlbXB0eSBmb3IgdG9kYXlcIlxuICAgIClcbiAgICByZXR1cm4gZGF0ZSA/IGRhdGUudHJpbSgpIDogbnVsbFxuICB9XG5cbiAgb251bmxvYWQoKSB7XG4gICAgY29uc29sZS5sb2coXCJVbmxvYWRpbmcgVHVja2VycyBUb29scyBwbHVnaW5cIilcbiAgfVxuXG4gIGFzeW5jIGluaXRpYWxpemVUZW1wbGF0ZXJGdW5jdGlvbnMoKSB7XG4gICAgLy8gQ2hlY2sgaWYgVGVtcGxhdGVyIHBsdWdpbiBpcyBhdmFpbGFibGVcbiAgICBjb25zdCB0ZW1wbGF0ZXJQbHVnaW4gPSAodGhpcy5hcHAgYXMgYW55KS5wbHVnaW5zLmdldFBsdWdpbihcInRlbXBsYXRlci1vYnNpZGlhblwiKTtcbiAgICBpZiAoIXRlbXBsYXRlclBsdWdpbikge1xuICAgICAgY29uc29sZS5sb2coXCJUZW1wbGF0ZXIgcGx1Z2luIG5vdCBmb3VuZC4gQ291cnNlIHRlbXBsYXRlcyB3aWxsIG5vdCB3b3JrIHByb3Blcmx5LlwiKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICAvLyBSZWdpc3RlciB1c2VyIGZ1bmN0aW9ucyB3aXRoIFRlbXBsYXRlclxuICAgIHRyeSB7XG4gICAgICAvLyBUcnkgdG8gYWRkIGZ1bmN0aW9ucyB2aWEgZGlmZmVyZW50IG1ldGhvZHMgZGVwZW5kaW5nIG9uIHRoZSBUZW1wbGF0ZXIgdmVyc2lvblxuICAgICAgaWYgKHRlbXBsYXRlclBsdWdpbiAmJiB0ZW1wbGF0ZXJQbHVnaW4udGVtcGxhdGVyKSB7XG4gICAgICAgIC8vIENyZWF0ZSBhIHVzZXIgZnVuY3Rpb24gbWFuYWdlciBvYmplY3QgaWYgaXQgZG9lc24ndCBleGlzdFxuICAgICAgICBpZiAoIXRlbXBsYXRlclBsdWdpbi50ZW1wbGF0ZXIuZnVuY3Rpb25zKSB7XG4gICAgICAgICAgdGVtcGxhdGVyUGx1Z2luLnRlbXBsYXRlci5mdW5jdGlvbnMgPSB7fTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIEFkZCBvdXIgY3VzdG9tIGZ1bmN0aW9ucyBkaXJlY3RseSB0byB0aGUgdGVtcGxhdGVyIGZ1bmN0aW9ucyBvYmplY3RcbiAgICAgICAgdGVtcGxhdGVyUGx1Z2luLnRlbXBsYXRlci5mdW5jdGlvbnNbXCJuZXdfbW9kdWxlXCJdID0gYXN5bmMgKGFwcDogYW55LCB0cDogYW55LCB5ZWFyOiBhbnkpID0+IHtcbiAgICAgICAgICByZXR1cm4gdGhpcy5uZXdNb2R1bGVGdW5jdGlvbihhcHAsIHRwLCB5ZWFyKTtcbiAgICAgICAgfTtcblxuICAgICAgICB0ZW1wbGF0ZXJQbHVnaW4udGVtcGxhdGVyLmZ1bmN0aW9uc1tcIm5ld19jaGFwdGVyXCJdID0gYXN5bmMgKHRwOiBhbnkpID0+IHtcbiAgICAgICAgICByZXR1cm4gdGhpcy5uZXdDaGFwdGVyRnVuY3Rpb24odHApO1xuICAgICAgICB9O1xuXG4gICAgICAgIGNvbnNvbGUubG9nKFwiVHVja2VycyBUb29scyB0ZW1wbGF0ZXIgZnVuY3Rpb25zIHJlZ2lzdGVyZWQgc3VjY2Vzc2Z1bGx5XCIpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkNvdWxkIG5vdCByZWdpc3RlciB0ZW1wbGF0ZXIgZnVuY3Rpb25zIC0gdGVtcGxhdGVyIG9iamVjdCBub3QgZm91bmRcIik7XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHJlZ2lzdGVyaW5nIHRlbXBsYXRlciBmdW5jdGlvbnM6XCIsIGUpO1xuICAgIH1cbiAgfVxuXG4gIGFzeW5jIG5ld01vZHVsZUZ1bmN0aW9uKGFwcDogYW55LCB0cDogYW55LCB5ZWFyOiBzdHJpbmcpIHtcbiAgICAvLyBQcm9tcHQgdXNlciBmb3IgbW9kdWxlIGRldGFpbHNcbiAgICBjb25zdCBtb2R1bGVOdW1iZXIgPSBhd2FpdCB0cC5zeXN0ZW0ucHJvbXB0KFwiTW9kdWxlIE51bWJlciAob3B0aW9uYWwpXCIsIFwiXCIpO1xuICAgIGNvbnN0IHdlZWtOdW1iZXIgPSBhd2FpdCB0cC5zeXN0ZW0ucHJvbXB0KFwiV2VlayBOdW1iZXIgKG9wdGlvbmFsKVwiLCBcIlwiKTtcbiAgICBjb25zdCBjb3Vyc2UgPSBhd2FpdCB0cC5zeXN0ZW0uc3VnZ2VzdGVyKFxuICAgICAgKCkgPT4gYXBwLnZhdWx0LmdldE1hcmtkb3duRmlsZXMoKS5maWx0ZXIoKGY6IGFueSkgPT4gZi5wYXRoLmluY2x1ZGVzKFwiQ291cnNlc1wiKSkubWFwKChmOiBhbnkpID0+IGYuYmFzZW5hbWUpLFxuICAgICAgYXBwLnZhdWx0LmdldE1hcmtkb3duRmlsZXMoKS5maWx0ZXIoKGY6IGFueSkgPT4gZi5wYXRoLmluY2x1ZGVzKFwiQ291cnNlc1wiKSlcbiAgICApO1xuICAgIGNvbnN0IGNvdXJzZUlkID0gY291cnNlID8gY291cnNlLnNwbGl0KFwiIC0gXCIpWzBdIHx8IGNvdXJzZSA6IFwiXCI7XG4gICAgY29uc3QgZGlzY2lwbGluZSA9IGNvdXJzZSA/IGNvdXJzZS5zcGxpdChcIiAtIFwiKVswXT8uc3Vic3RyaW5nKDAsIDMpIHx8IFwiR0VOXCIgOiBcIkdFTlwiO1xuICAgIGNvbnN0IGRheU9wdGlvbnMgPSBbXCJNb25kYXlcIiwgXCJUdWVzZGF5XCIsIFwiV2VkbmVzZGF5XCIsIFwiVGh1cnNkYXlcIiwgXCJGcmlkYXlcIiwgXCJTYXR1cmRheVwiLCBcIlN1bmRheVwiXTtcbiAgICBjb25zdCBkYXlPZldlZWsgPSBhd2FpdCB0cC5zeXN0ZW0uc3VnZ2VzdGVyKGRheU9wdGlvbnMsIGRheU9wdGlvbnMsIFwiRGF5IG9mIFdlZWtcIik7XG5cbiAgICByZXR1cm4ge1xuICAgICAgc2Vhc29uOiBcIkZhbGxcIiwgLy8gVGhpcyB3b3VsZCBub3JtYWxseSBiZSBkeW5hbWljYWxseSBkZXRlcm1pbmVkXG4gICAgICBtb2R1bGVOdW1iZXI6IG1vZHVsZU51bWJlciB8fCBudWxsLFxuICAgICAgd2Vla051bWJlcjogd2Vla051bWJlciB8fCBudWxsLFxuICAgICAgY291cnNlLFxuICAgICAgY291cnNlSWQsXG4gICAgICBkaXNjaXBsaW5lLFxuICAgICAgZGF5T2ZXZWVrXG4gICAgfTtcbiAgfVxuXG4gIGFzeW5jIG5ld0NoYXB0ZXJGdW5jdGlvbih0cDogYW55KSB7XG4gICAgY29uc3QgY2hhcHRlck51bWJlciA9IGF3YWl0IHRwLnN5c3RlbS5wcm9tcHQoXCJDaGFwdGVyIE51bWJlclwiLCBcIlwiKTtcbiAgICBjb25zdCBjb3Vyc2UgPSBhd2FpdCB0cC5zeXN0ZW0uc3VnZ2VzdGVyKFxuICAgICAgKCkgPT4gdHAuYXBwLnZhdWx0LmdldE1hcmtkb3duRmlsZXMoKS5maWx0ZXIoKGY6IGFueSkgPT4gZi5wYXRoLmluY2x1ZGVzKFwiQ291cnNlc1wiKSkubWFwKChmOiBhbnkpID0+IGYuYmFzZW5hbWUpLFxuICAgICAgdHAuYXBwLnZhdWx0LmdldE1hcmtkb3duRmlsZXMoKS5maWx0ZXIoKGY6IGFueSkgPT4gZi5wYXRoLmluY2x1ZGVzKFwiQ291cnNlc1wiKSlcbiAgICApO1xuICAgIGNvbnN0IGNvdXJzZUlkID0gY291cnNlID8gY291cnNlLnNwbGl0KFwiIC0gXCIpWzBdIHx8IGNvdXJzZSA6IFwiXCI7XG4gICAgY29uc3QgZGlzY2lwbGluZSA9IGNvdXJzZSA/IGNvdXJzZS5zcGxpdChcIiAtIFwiKVswXT8uc3Vic3RyaW5nKDAsIDMpIHx8IFwiR0VOXCIgOiBcIkdFTlwiO1xuICAgIGNvbnN0IHRleHRPcHRpb25zID0gdHAuYXBwLnZhdWx0LmdldEZpbGVzKCkuZmlsdGVyKChmOiBhbnkpID0+IGYuZXh0ZW5zaW9uID09PSBcInBkZlwiKS5tYXAoKGY6IGFueSkgPT4gZi5iYXNlbmFtZSk7XG4gICAgY29uc3QgdGV4dCA9IGF3YWl0IHRwLnN5c3RlbS5zdWdnZXN0ZXIodGV4dE9wdGlvbnMsIHRleHRPcHRpb25zLCBcIlRleHRib29rXCIpO1xuXG4gICAgcmV0dXJuIHtcbiAgICAgIGNoYXB0ZXJOdW1iZXI6IGNoYXB0ZXJOdW1iZXIgfHwgXCJcIixcbiAgICAgIGNvdXJzZSxcbiAgICAgIGNvdXJzZUlkLFxuICAgICAgZGlzY2lwbGluZSxcbiAgICAgIHRleHRcbiAgICB9O1xuICB9XG5cbiAgYXN5bmMgbG9hZFNldHRpbmdzKCkge1xuICAgIHRoaXMuc2V0dGluZ3MgPSBPYmplY3QuYXNzaWduKHt9LCBERUZBVUxUX1NFVFRJTkdTLCBhd2FpdCB0aGlzLmxvYWREYXRhKCkpXG4gIH1cblxuICBhc3luYyBzYXZlU2V0dGluZ3MoKSB7XG4gICAgYXdhaXQgdGhpcy5zYXZlRGF0YSh0aGlzLnNldHRpbmdzKVxuICB9XG59XG4iLCAiaW1wb3J0IHsgQXBwLCBQbHVnaW5TZXR0aW5nVGFiLCBTZXR0aW5nIH0gZnJvbSAnb2JzaWRpYW4nO1xuaW1wb3J0IFR1Y2tlcnNUb29sc1BsdWdpbiBmcm9tICcuL21haW4nO1xuaW1wb3J0IHsgdmFsaWRhdGVEYXRlIH0gZnJvbSAnLi91dGlscyc7XG5cbmV4cG9ydCBpbnRlcmZhY2UgVHVja2Vyc1Rvb2xzU2V0dGluZ3Mge1xuICBiYXNlRGlyZWN0b3J5OiBzdHJpbmc7XG4gIHNlbWVzdGVyU3RhcnREYXRlOiBzdHJpbmc7XG4gIHNlbWVzdGVyRW5kRGF0ZTogc3RyaW5nO1xuICBzY2hvb2xOYW1lOiBzdHJpbmc7XG4gIHNjaG9vbEFiYnJldmlhdGlvbjogc3RyaW5nO1xuICB0ZW1wbGF0ZUZvbGRlcjogc3RyaW5nO1xuICB1c2VFbmhhbmNlZE1ldGFkYXRhOiBib29sZWFuO1xufVxuXG5leHBvcnQgY29uc3QgREVGQVVMVF9TRVRUSU5HUzogVHVja2Vyc1Rvb2xzU2V0dGluZ3MgPSB7XG4gIGJhc2VEaXJlY3Rvcnk6ICcvJyxcbiAgc2VtZXN0ZXJTdGFydERhdGU6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zcGxpdCgnVCcpWzBdLFxuICBzZW1lc3RlckVuZERhdGU6IG5ldyBEYXRlKG5ldyBEYXRlKCkuc2V0TW9udGgobmV3IERhdGUoKS5nZXRNb250aCgpICsgNCkpLnRvSVNPU3RyaW5nKCkuc3BsaXQoJ1QnKVswXSxcbiAgc2Nob29sTmFtZTogJ1VuaXZlcnNpdHknLFxuICBzY2hvb2xBYmJyZXZpYXRpb246ICdVJyxcbiAgdGVtcGxhdGVGb2xkZXI6ICdUdWNrZXJzIFRvb2xzJyxcbiAgdXNlRW5oYW5jZWRNZXRhZGF0YTogZmFsc2Vcbn1cblxuZXhwb3J0IGNsYXNzIFR1Y2tlcnNUb29sc1NldHRpbmdUYWIgZXh0ZW5kcyBQbHVnaW5TZXR0aW5nVGFiIHtcbiAgcGx1Z2luOiBUdWNrZXJzVG9vbHNQbHVnaW47XG5cbiAgY29uc3RydWN0b3IoYXBwOiBBcHAsIHBsdWdpbjogVHVja2Vyc1Rvb2xzUGx1Z2luKSB7XG4gICAgc3VwZXIoYXBwLCBwbHVnaW4pO1xuICAgIHRoaXMucGx1Z2luID0gcGx1Z2luO1xuICB9XG5cbiAgZGlzcGxheSgpOiB2b2lkIHtcbiAgICBjb25zdCB7IGNvbnRhaW5lckVsIH0gPSB0aGlzO1xuXG4gICAgY29udGFpbmVyRWwuZW1wdHkoKTtcblxuICAgIGNvbnRhaW5lckVsLmNyZWF0ZUVsKCdoMicsIHsgdGV4dDogJ1R1Y2tlcnMgVG9vbHMgU2V0dGluZ3MnIH0pO1xuXG4gICAgbmV3IFNldHRpbmcoY29udGFpbmVyRWwpXG4gICAgICAuc2V0TmFtZSgnQmFzZSBEaXJlY3RvcnknKVxuICAgICAgLnNldERlc2MoJ1Jvb3QgZGlyZWN0b3J5IGZvciBjb3Vyc2UgY29udGVudCBvcmdhbml6YXRpb24nKVxuICAgICAgLmFkZFRleHQodGV4dCA9PiB0ZXh0XG4gICAgICAgIC5zZXRQbGFjZWhvbGRlcignLycpXG4gICAgICAgIC5zZXRWYWx1ZSh0aGlzLnBsdWdpbi5zZXR0aW5ncy5iYXNlRGlyZWN0b3J5KVxuICAgICAgICAub25DaGFuZ2UoYXN5bmMgKHZhbHVlKSA9PiB7XG4gICAgICAgICAgdGhpcy5wbHVnaW4uc2V0dGluZ3MuYmFzZURpcmVjdG9yeSA9IHZhbHVlO1xuICAgICAgICAgIGF3YWl0IHRoaXMucGx1Z2luLnNhdmVTZXR0aW5ncygpO1xuICAgICAgICB9KSk7XG5cbiAgICBjb25zdCBzdGFydERhdGVTZXR0aW5nID0gbmV3IFNldHRpbmcoY29udGFpbmVyRWwpXG4gICAgICAuc2V0TmFtZSgnU2VtZXN0ZXIgU3RhcnQgRGF0ZScpXG4gICAgICAuc2V0RGVzYygnU3RhcnQgZGF0ZSBmb3IgdGhlIGN1cnJlbnQgc2VtZXN0ZXInKVxuICAgICAgLmFkZFRleHQodGV4dCA9PiB0ZXh0XG4gICAgICAgIC5zZXRQbGFjZWhvbGRlcignWVlZWS1NTS1ERCcpXG4gICAgICAgIC5zZXRWYWx1ZSh0aGlzLnBsdWdpbi5zZXR0aW5ncy5zZW1lc3RlclN0YXJ0RGF0ZSlcbiAgICAgICAgLm9uQ2hhbmdlKGFzeW5jICh2YWx1ZSkgPT4ge1xuICAgICAgICAgIGlmICh2YWx1ZSAmJiAhdmFsaWRhdGVEYXRlKHZhbHVlKSkge1xuICAgICAgICAgICAgc3RhcnREYXRlU2V0dGluZy5zZXREZXNjKCdTdGFydCBkYXRlIGZvciB0aGUgY3VycmVudCBzZW1lc3RlciAoSW52YWxpZCBkYXRlIGZvcm1hdCknKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgc3RhcnREYXRlU2V0dGluZy5zZXREZXNjKCdTdGFydCBkYXRlIGZvciB0aGUgY3VycmVudCBzZW1lc3RlcicpO1xuICAgICAgICAgIH1cbiAgICAgICAgICB0aGlzLnBsdWdpbi5zZXR0aW5ncy5zZW1lc3RlclN0YXJ0RGF0ZSA9IHZhbHVlO1xuICAgICAgICAgIGF3YWl0IHRoaXMucGx1Z2luLnNhdmVTZXR0aW5ncygpO1xuICAgICAgICB9KSk7XG5cbiAgICBjb25zdCBlbmREYXRlU2V0dGluZyA9IG5ldyBTZXR0aW5nKGNvbnRhaW5lckVsKVxuICAgICAgLnNldE5hbWUoJ1NlbWVzdGVyIEVuZCBEYXRlJylcbiAgICAgIC5zZXREZXNjKCdFbmQgZGF0ZSBmb3IgdGhlIGN1cnJlbnQgc2VtZXN0ZXInKVxuICAgICAgLmFkZFRleHQodGV4dCA9PiB0ZXh0XG4gICAgICAgIC5zZXRQbGFjZWhvbGRlcignWVlZWS1NTS1ERCcpXG4gICAgICAgIC5zZXRWYWx1ZSh0aGlzLnBsdWdpbi5zZXR0aW5ncy5zZW1lc3RlckVuZERhdGUpXG4gICAgICAgIC5vbkNoYW5nZShhc3luYyAodmFsdWUpID0+IHtcbiAgICAgICAgICBpZiAodmFsdWUgJiYgIXZhbGlkYXRlRGF0ZSh2YWx1ZSkpIHtcbiAgICAgICAgICAgIGVuZERhdGVTZXR0aW5nLnNldERlc2MoJ0VuZCBkYXRlIGZvciB0aGUgY3VycmVudCBzZW1lc3RlciAoSW52YWxpZCBkYXRlIGZvcm1hdCknKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgZW5kRGF0ZVNldHRpbmcuc2V0RGVzYygnRW5kIGRhdGUgZm9yIHRoZSBjdXJyZW50IHNlbWVzdGVyJyk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHRoaXMucGx1Z2luLnNldHRpbmdzLnNlbWVzdGVyRW5kRGF0ZSA9IHZhbHVlO1xuICAgICAgICAgIGF3YWl0IHRoaXMucGx1Z2luLnNhdmVTZXR0aW5ncygpO1xuICAgICAgICB9KSk7XG5cbiAgICBuZXcgU2V0dGluZyhjb250YWluZXJFbClcbiAgICAgIC5zZXROYW1lKCdTY2hvb2wgTmFtZScpXG4gICAgICAuc2V0RGVzYygnTmFtZSBvZiB5b3VyIGluc3RpdHV0aW9uJylcbiAgICAgIC5hZGRUZXh0KHRleHQgPT4gdGV4dFxuICAgICAgICAuc2V0UGxhY2Vob2xkZXIoJ1VuaXZlcnNpdHknKVxuICAgICAgICAuc2V0VmFsdWUodGhpcy5wbHVnaW4uc2V0dGluZ3Muc2Nob29sTmFtZSlcbiAgICAgICAgLm9uQ2hhbmdlKGFzeW5jICh2YWx1ZSkgPT4ge1xuICAgICAgICAgIHRoaXMucGx1Z2luLnNldHRpbmdzLnNjaG9vbE5hbWUgPSB2YWx1ZTtcbiAgICAgICAgICBhd2FpdCB0aGlzLnBsdWdpbi5zYXZlU2V0dGluZ3MoKTtcbiAgICAgICAgfSkpO1xuXG4gICAgbmV3IFNldHRpbmcoY29udGFpbmVyRWwpXG4gICAgICAuc2V0TmFtZSgnU2Nob29sIEFiYnJldmlhdGlvbicpXG4gICAgICAuc2V0RGVzYygnQWJicmV2aWF0aW9uIGZvciB5b3VyIGluc3RpdHV0aW9uJylcbiAgICAgIC5hZGRUZXh0KHRleHQgPT4gdGV4dFxuICAgICAgICAuc2V0UGxhY2Vob2xkZXIoJ1UnKVxuICAgICAgICAuc2V0VmFsdWUodGhpcy5wbHVnaW4uc2V0dGluZ3Muc2Nob29sQWJicmV2aWF0aW9uKVxuICAgICAgICAub25DaGFuZ2UoYXN5bmMgKHZhbHVlKSA9PiB7XG4gICAgICAgICAgdGhpcy5wbHVnaW4uc2V0dGluZ3Muc2Nob29sQWJicmV2aWF0aW9uID0gdmFsdWU7XG4gICAgICAgICAgYXdhaXQgdGhpcy5wbHVnaW4uc2F2ZVNldHRpbmdzKCk7XG4gICAgICAgIH0pKTtcblxuICAgIG5ldyBTZXR0aW5nKGNvbnRhaW5lckVsKVxuICAgICAgLnNldE5hbWUoJ1RlbXBsYXRlIEZvbGRlcicpXG4gICAgICAuc2V0RGVzYygnU3ViZm9sZGVyIHdpdGhpbiB5b3VyIFRlbXBsYXRlciB0ZW1wbGF0ZSBmb2xkZXIgZm9yIFR1Y2tlcnMgVG9vbHMgdGVtcGxhdGVzJylcbiAgICAgIC5hZGRUZXh0KHRleHQgPT4gdGV4dFxuICAgICAgICAuc2V0UGxhY2Vob2xkZXIoJ1R1Y2tlcnMgVG9vbHMnKVxuICAgICAgICAuc2V0VmFsdWUodGhpcy5wbHVnaW4uc2V0dGluZ3MudGVtcGxhdGVGb2xkZXIpXG4gICAgICAgIC5vbkNoYW5nZShhc3luYyAodmFsdWUpID0+IHtcbiAgICAgICAgICB0aGlzLnBsdWdpbi5zZXR0aW5ncy50ZW1wbGF0ZUZvbGRlciA9IHZhbHVlO1xuICAgICAgICAgIGF3YWl0IHRoaXMucGx1Z2luLnNhdmVTZXR0aW5ncygpO1xuICAgICAgICB9KSk7XG5cbiAgICBuZXcgU2V0dGluZyhjb250YWluZXJFbClcbiAgICAgIC5zZXROYW1lKCdVc2UgRW5oYW5jZWQgTWV0YWRhdGEnKVxuICAgICAgLnNldERlc2MoJ0VuYWJsZSBlbmhhbmNlZCBtZXRhZGF0YSBmaWVsZHMgZm9yIG5ldyBub3RlcyAoZXhpc3Rpbmcgbm90ZXMgcmVtYWluIHVuY2hhbmdlZCknKVxuICAgICAgLmFkZFRvZ2dsZSh0b2dnbGUgPT4gdG9nZ2xlXG4gICAgICAgIC5zZXRWYWx1ZSh0aGlzLnBsdWdpbi5zZXR0aW5ncy51c2VFbmhhbmNlZE1ldGFkYXRhKVxuICAgICAgICAub25DaGFuZ2UoYXN5bmMgKHZhbHVlKSA9PiB7XG4gICAgICAgICAgdGhpcy5wbHVnaW4uc2V0dGluZ3MudXNlRW5oYW5jZWRNZXRhZGF0YSA9IHZhbHVlO1xuICAgICAgICAgIGF3YWl0IHRoaXMucGx1Z2luLnNhdmVTZXR0aW5ncygpO1xuICAgICAgICB9KSk7XG4gIH1cbn0iLCAiLy8gVXRpbGl0eSBmdW5jdGlvbnMgZm9yIFR1Y2tlcnMgVG9vbHMgcGx1Z2luXG5cbmV4cG9ydCBmdW5jdGlvbiBmb3JtYXREYXRlKGRhdGU6IERhdGUpOiBzdHJpbmcge1xuICByZXR1cm4gZGF0ZS50b0lTT1N0cmluZygpLnNwbGl0KFwiVFwiKVswXVxufVxuXG5leHBvcnQgZnVuY3Rpb24gYWRkRGF5cyhkYXRlOiBEYXRlLCBkYXlzOiBudW1iZXIpOiBEYXRlIHtcbiAgY29uc3QgcmVzdWx0ID0gbmV3IERhdGUoZGF0ZSlcbiAgcmVzdWx0LnNldERhdGUocmVzdWx0LmdldERhdGUoKSArIGRheXMpXG4gIHJldHVybiByZXN1bHRcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGlzQmV0d2VlbihkYXRlOiBEYXRlLCBzdGFydDogRGF0ZSwgZW5kOiBEYXRlKTogYm9vbGVhbiB7XG4gIHJldHVybiBkYXRlID49IHN0YXJ0ICYmIGRhdGUgPD0gZW5kXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBzbHVnaWZ5KHRleHQ6IHN0cmluZyk6IHN0cmluZyB7XG4gIHJldHVybiB0ZXh0XG4gICAgLnRvTG93ZXJDYXNlKClcbiAgICAudHJpbSgpXG4gICAgLm5vcm1hbGl6ZShcIk5GRFwiKVxuICAgIC5yZXBsYWNlKC9bXFx1MDMwMC1cXHUwMzZmXS9nLCBcIlwiKVxuICAgIC5yZXBsYWNlKC9bXmEtejAtOVxccy1dL2csIFwiXCIpXG4gICAgLnJlcGxhY2UoL1tcXHMtXSsvZywgXCItXCIpXG4gICAgLnJlcGxhY2UoL14tK3wtKyQvZywgXCJcIilcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGdldENvdXJzZUlkRnJvbVBhdGgocGF0aDogc3RyaW5nKTogc3RyaW5nIHwgbnVsbCB7XG4gIC8vIEV4dHJhY3QgY291cnNlIElEIGZyb20gcGF0aCBsaWtlIFwiMjAyNS9GYWxsL1BTSS0xMDEvLi4uXCIgb3IgZmlsZW5hbWUgXCJQU0ktMTAxIC0gSW50cm8gdG8gUHN5Y2gubWRcIlxuICBjb25zdCBwYXJ0cyA9IHBhdGguc3BsaXQoXCIvXCIpXG4gIGZvciAoY29uc3QgcGFydCBvZiBwYXJ0cykge1xuICAgIC8vIExvb2sgZm9yIGNvdXJzZSBJRCBwYXR0ZXJuIGluIGVhY2ggcGF0aCBzZWdtZW50XG4gICAgY29uc3QgbWF0Y2ggPSBwYXJ0Lm1hdGNoKC8oW0EtWl17Miw0fS1cXGR7M30pLylcbiAgICBpZiAobWF0Y2gpIHtcbiAgICAgIHJldHVybiBtYXRjaFsxXVxuICAgIH1cbiAgfVxuICByZXR1cm4gbnVsbFxufVxuXG5leHBvcnQgZnVuY3Rpb24gdmFsaWRhdGVEYXRlKGRhdGVTdHJpbmc6IHN0cmluZyk6IGJvb2xlYW4ge1xuICBjb25zdCByZWdleCA9IC9eXFxkezR9LVxcZHsyfS1cXGR7Mn0kL1xuICBpZiAoIWRhdGVTdHJpbmcubWF0Y2gocmVnZXgpKSByZXR1cm4gZmFsc2VcblxuICBjb25zdCBkYXRlID0gbmV3IERhdGUoZGF0ZVN0cmluZylcbiAgY29uc3QgdGltZXN0YW1wID0gZGF0ZS5nZXRUaW1lKClcblxuICBpZiAodHlwZW9mIHRpbWVzdGFtcCAhPT0gXCJudW1iZXJcIiB8fCBpc05hTih0aW1lc3RhbXApKSByZXR1cm4gZmFsc2VcblxuICByZXR1cm4gZGF0ZVN0cmluZyA9PT0gZGF0ZS50b0lTT1N0cmluZygpLnNwbGl0KFwiVFwiKVswXVxufVxuIiwgImltcG9ydCB7IEFwcCwgTm90aWNlIH0gZnJvbSBcIm9ic2lkaWFuXCJcbmltcG9ydCB7IFR1Y2tlcnNUb29sc1NldHRpbmdzIH0gZnJvbSBcIi4vc2V0dGluZ3NcIlxuXG5pbnRlcmZhY2UgVGVtcGxhdGVNYW5pZmVzdCB7XG4gIHZlcnNpb246IHN0cmluZ1xuICB0ZW1wbGF0ZXM6IFJlY29yZDxzdHJpbmcsIHN0cmluZz5cbiAgcGx1Z2luX3ZlcnNpb246IHN0cmluZ1xuICByZWxlYXNlX25vdGVzOiBzdHJpbmdcbn1cblxuZXhwb3J0IGNsYXNzIFRlbXBsYXRlTWFuYWdlciB7XG4gIGFwcDogQXBwXG4gIHNldHRpbmdzOiBUdWNrZXJzVG9vbHNTZXR0aW5nc1xuICBtYW5pZmVzdDogVGVtcGxhdGVNYW5pZmVzdFxuXG4gIGNvbnN0cnVjdG9yKGFwcDogQXBwLCBzZXR0aW5nczogVHVja2Vyc1Rvb2xzU2V0dGluZ3MpIHtcbiAgICB0aGlzLmFwcCA9IGFwcFxuICAgIHRoaXMuc2V0dGluZ3MgPSBzZXR0aW5nc1xuICAgIHRoaXMubWFuaWZlc3QgPSB7XG4gICAgICB2ZXJzaW9uOiBcIjEuMC4wXCIsXG4gICAgICB0ZW1wbGF0ZXM6IHtcbiAgICAgICAgXCJDb3Vyc2VzL0NyZWF0ZSBDb3Vyc2UgSG9tZXBhZ2UubWRcIjogXCIxLjAuMFwiLFxuICAgICAgICBcIkNvdXJzZXMvQ291cnNlIEluZGV4Lm1kXCI6IFwiMS4wLjBcIixcbiAgICAgICAgXCJNb2R1bGVzL0NyZWF0ZSBNb2R1bGUubWRcIjogXCIxLjAuMFwiLFxuICAgICAgICBcIkNoYXB0ZXJzL0NyZWF0ZSBDaGFwdGVyLm1kXCI6IFwiMS4wLjBcIixcbiAgICAgICAgXCJBc3NpZ25tZW50cy9DcmVhdGUgQXNzaWdubWVudC5tZFwiOiBcIjEuMC4wXCIsXG4gICAgICAgIFwiRGFpbHkvRGFpbHkgTm90ZS5tZFwiOiBcIjEuMC4wXCIsXG4gICAgICAgIFwiVXRpbGl0aWVzL1ZvY2FidWxhcnkgRW50cnkubWRcIjogXCIxLjAuMFwiLFxuICAgICAgICBcIlV0aWxpdGllcy9EdWUgRGF0ZSBFbnRyeS5tZFwiOiBcIjEuMC4wXCJcbiAgICAgIH0sXG4gICAgICBwbHVnaW5fdmVyc2lvbjogXCIxLjAuMFwiLFxuICAgICAgcmVsZWFzZV9ub3RlczogXCJJbml0aWFsIHJlbGVhc2Ugb2YgVHVja2VycyBUb29scyB0ZW1wbGF0ZXNcIlxuICAgIH1cbiAgfVxuXG4gIGFzeW5jIGluc3RhbGxUZW1wbGF0ZXMoKSB7XG4gICAgdHJ5IHtcbiAgICAgIC8vIEdldCBUZW1wbGF0ZXIgcGx1Z2luIHNldHRpbmdzIHRvIGZpbmQgdGVtcGxhdGUgZm9sZGVyXG4gICAgICBjb25zdCB0ZW1wbGF0ZXJQbHVnaW4gPSB0aGlzLmdldFRlbXBsYXRlclBsdWdpbigpXG4gICAgICBpZiAoIXRlbXBsYXRlclBsdWdpbikge1xuICAgICAgICBuZXcgTm90aWNlKFxuICAgICAgICAgIFwiVGVtcGxhdGVyIHBsdWdpbiBub3QgZm91bmQuIFBsZWFzZSBpbnN0YWxsIGFuZCBlbmFibGUgdGhlIFRlbXBsYXRlciBwbHVnaW4gZmlyc3QuXCJcbiAgICAgICAgKVxuICAgICAgICBjb25zb2xlLmVycm9yKFxuICAgICAgICAgIFwiVGVtcGxhdGVyIHBsdWdpbiBub3QgZm91bmQuIFBsZWFzZSBpbnN0YWxsIGFuZCBlbmFibGUgdGhlIFRlbXBsYXRlciBwbHVnaW4gZmlyc3QuXCJcbiAgICAgICAgKVxuICAgICAgICByZXR1cm5cbiAgICAgIH1cblxuICAgICAgY29uc3QgdGVtcGxhdGVGb2xkZXJQYXRoID0gdGhpcy5nZXRUZW1wbGF0ZUZvbGRlclBhdGgodGVtcGxhdGVyUGx1Z2luKVxuICAgICAgaWYgKCF0ZW1wbGF0ZUZvbGRlclBhdGgpIHtcbiAgICAgICAgbmV3IE5vdGljZShcbiAgICAgICAgICBcIlRlbXBsYXRlIGZvbGRlciBub3QgY29uZmlndXJlZCBpbiBUZW1wbGF0ZXIgc2V0dGluZ3MuIFBsZWFzZSBjb25maWd1cmUgaXQgaW4gVGVtcGxhdGVyIHNldHRpbmdzIGZpcnN0LlwiXG4gICAgICAgIClcbiAgICAgICAgY29uc29sZS5lcnJvcihcbiAgICAgICAgICBcIlRlbXBsYXRlIGZvbGRlciBub3QgY29uZmlndXJlZCBpbiBUZW1wbGF0ZXIgc2V0dGluZ3MuIFBsZWFzZSBjb25maWd1cmUgaXQgaW4gVGVtcGxhdGVyIHNldHRpbmdzIGZpcnN0LlwiXG4gICAgICAgIClcbiAgICAgICAgcmV0dXJuXG4gICAgICB9XG5cbiAgICAgIGNvbnN0IGZ1bGxUZW1wbGF0ZVBhdGggPSBgJHt0ZW1wbGF0ZUZvbGRlclBhdGh9LyR7dGhpcy5zZXR0aW5ncy50ZW1wbGF0ZUZvbGRlcn1gXG5cbiAgICAgIC8vIENyZWF0ZSB0aGUgbWFpbiB0ZW1wbGF0ZSBmb2xkZXIgaWYgaXQgZG9lc24ndCBleGlzdFxuICAgICAgdHJ5IHtcbiAgICAgICAgYXdhaXQgdGhpcy5hcHAudmF1bHQuY3JlYXRlRm9sZGVyKGZ1bGxUZW1wbGF0ZVBhdGgpXG4gICAgICAgIGNvbnNvbGUubG9nKGBDcmVhdGVkIHRlbXBsYXRlIGZvbGRlcjogJHtmdWxsVGVtcGxhdGVQYXRofWApXG4gICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIC8vIEZvbGRlciBtaWdodCBhbHJlYWR5IGV4aXN0LCB3aGljaCBpcyBmaW5lXG4gICAgICAgIGNvbnNvbGUubG9nKFxuICAgICAgICAgIGBUZW1wbGF0ZSBmb2xkZXIgYWxyZWFkeSBleGlzdHMgb3IgY3JlYXRlZDogJHtmdWxsVGVtcGxhdGVQYXRofWBcbiAgICAgICAgKVxuICAgICAgfVxuXG4gICAgICAvLyBDcmVhdGUgc3ViZGlyZWN0b3JpZXNcbiAgICAgIGNvbnN0IHN1YmRpcnMgPSBbXG4gICAgICAgIFwiQ291cnNlc1wiLFxuICAgICAgICBcIk1vZHVsZXNcIixcbiAgICAgICAgXCJDaGFwdGVyc1wiLFxuICAgICAgICBcIkFzc2lnbm1lbnRzXCIsXG4gICAgICAgIFwiRGFpbHlcIixcbiAgICAgICAgXCJVdGlsaXRpZXNcIlxuICAgICAgXVxuICAgICAgZm9yIChjb25zdCBzdWJkaXIgb2Ygc3ViZGlycykge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGNvbnN0IHN1YlBhdGggPSBgJHtmdWxsVGVtcGxhdGVQYXRofS8ke3N1YmRpcn1gXG4gICAgICAgICAgYXdhaXQgdGhpcy5hcHAudmF1bHQuY3JlYXRlRm9sZGVyKHN1YlBhdGgpXG4gICAgICAgICAgY29uc29sZS5sb2coYENyZWF0ZWQgc3ViZGlyZWN0b3J5OiAke3N1YlBhdGh9YClcbiAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgIC8vIEZvbGRlciBtaWdodCBhbHJlYWR5IGV4aXN0LCB3aGljaCBpcyBmaW5lXG4gICAgICAgICAgY29uc29sZS5sb2coXG4gICAgICAgICAgICBgU3ViZGlyZWN0b3J5IGFscmVhZHkgZXhpc3RzOiAke2Z1bGxUZW1wbGF0ZVBhdGh9LyR7c3ViZGlyfWBcbiAgICAgICAgICApXG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgLy8gSW5zdGFsbCB0ZW1wbGF0ZXNcbiAgICAgIGF3YWl0IHRoaXMuaW5zdGFsbENvdXJzZVRlbXBsYXRlcyhmdWxsVGVtcGxhdGVQYXRoKVxuICAgICAgYXdhaXQgdGhpcy5pbnN0YWxsTW9kdWxlVGVtcGxhdGVzKGZ1bGxUZW1wbGF0ZVBhdGgpXG4gICAgICBhd2FpdCB0aGlzLmluc3RhbGxDaGFwdGVyVGVtcGxhdGVzKGZ1bGxUZW1wbGF0ZVBhdGgpXG4gICAgICBhd2FpdCB0aGlzLmluc3RhbGxBc3NpZ25tZW50VGVtcGxhdGVzKGZ1bGxUZW1wbGF0ZVBhdGgpXG4gICAgICBhd2FpdCB0aGlzLmluc3RhbGxEYWlseVRlbXBsYXRlcyhmdWxsVGVtcGxhdGVQYXRoKVxuICAgICAgYXdhaXQgdGhpcy5pbnN0YWxsVXRpbGl0eVRlbXBsYXRlcyhmdWxsVGVtcGxhdGVQYXRoKVxuXG4gICAgICAvLyBDcmVhdGUgUkVBRE1FXG4gICAgICBhd2FpdCB0aGlzLmNyZWF0ZVJFQURNRShmdWxsVGVtcGxhdGVQYXRoKVxuXG4gICAgICAvLyBDcmVhdGUgdGVtcGxhdGUgbWFuaWZlc3RcbiAgICAgIGF3YWl0IHRoaXMuY3JlYXRlVGVtcGxhdGVNYW5pZmVzdChmdWxsVGVtcGxhdGVQYXRoKVxuXG4gICAgICBuZXcgTm90aWNlKFwiVHVja2VycyBUb29scyB0ZW1wbGF0ZXMgaW5zdGFsbGVkIHN1Y2Nlc3NmdWxseSFcIilcbiAgICAgIGNvbnNvbGUubG9nKFwiVHVja2VycyBUb29scyB0ZW1wbGF0ZXMgaW5zdGFsbGVkIHN1Y2Nlc3NmdWxseVwiKVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgaW5zdGFsbGluZyB0ZW1wbGF0ZXM6XCIsIGVycm9yKVxuICAgICAgbmV3IE5vdGljZShcIkVycm9yIGluc3RhbGxpbmcgdGVtcGxhdGVzLiBDaGVjayBjb25zb2xlIGZvciBkZXRhaWxzLlwiKVxuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgZ2V0VGVtcGxhdGVyUGx1Z2luKCk6IGFueSB7XG4gICAgLy8gVHJ5IG11bHRpcGxlIHdheXMgdG8gYWNjZXNzIHRoZSBUZW1wbGF0ZXIgcGx1Z2luXG4gICAgY29uc3QgcG9zc2libGVQYXRocyA9IFtcbiAgICAgICh0aGlzLmFwcCBhcyBhbnkpLnBsdWdpbnMucGx1Z2luc1tcInRlbXBsYXRlci1vYnNpZGlhblwiXSxcbiAgICAgICh0aGlzLmFwcCBhcyBhbnkpLnBsdWdpbnMucGx1Z2luc1tcInRlbXBsYXRlclwiXSxcbiAgICAgICh0aGlzLmFwcCBhcyBhbnkpLnBsdWdpbnMuZ2V0UGx1Z2luKFwidGVtcGxhdGVyLW9ic2lkaWFuXCIpLFxuICAgICAgKHRoaXMuYXBwIGFzIGFueSkucGx1Z2lucy5nZXRQbHVnaW4oXCJ0ZW1wbGF0ZXJcIilcbiAgICBdXG5cbiAgICBmb3IgKGNvbnN0IHBhdGggb2YgcG9zc2libGVQYXRocykge1xuICAgICAgaWYgKHBhdGgpIHtcbiAgICAgICAgcmV0dXJuIHBhdGhcbiAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gbnVsbFxuICB9XG5cbiAgcHJpdmF0ZSBnZXRUZW1wbGF0ZUZvbGRlclBhdGgodGVtcGxhdGVyUGx1Z2luOiBhbnkpOiBzdHJpbmcgfCBudWxsIHtcbiAgICBjb25zdCBzZXR0aW5ncyA9IHRlbXBsYXRlclBsdWdpbi5zZXR0aW5nc1xuXG4gICAgaWYgKCFzZXR0aW5ncykge1xuICAgICAgY29uc29sZS5lcnJvcihcIlRlbXBsYXRlciBwbHVnaW4gaGFzIG5vIHNldHRpbmdzXCIpXG4gICAgICByZXR1cm4gbnVsbFxuICAgIH1cblxuICAgIC8vIFRyeSBkaWZmZXJlbnQgcG9zc2libGUgcHJvcGVydHkgbmFtZXMgZm9yIHRlbXBsYXRlIGZvbGRlclxuICAgIGNvbnN0IHBvc3NpYmxlUGF0aHMgPSBbXG4gICAgICBzZXR0aW5ncy50ZW1wbGF0ZV9mb2xkZXIsXG4gICAgICBzZXR0aW5ncy50ZW1wbGF0ZUZvbGRlcixcbiAgICAgIHNldHRpbmdzLnRlbXBsYXRlRm9sZGVyUGF0aCxcbiAgICAgIHNldHRpbmdzLmZvbGRlclxuICAgIF1cblxuICAgIGZvciAoY29uc3QgcGF0aCBvZiBwb3NzaWJsZVBhdGhzKSB7XG4gICAgICBpZiAocGF0aCAmJiB0eXBlb2YgcGF0aCA9PT0gXCJzdHJpbmdcIikge1xuICAgICAgICByZXR1cm4gcGF0aFxuICAgICAgfVxuICAgIH1cblxuICAgIGNvbnNvbGUuZXJyb3IoXG4gICAgICBcIlRlbXBsYXRlIGZvbGRlciBub3QgZm91bmQgaW4gVGVtcGxhdGVyIHNldHRpbmdzLiBBdmFpbGFibGUgc2V0dGluZ3M6XCIsXG4gICAgICBPYmplY3Qua2V5cyhzZXR0aW5ncylcbiAgICApXG4gICAgcmV0dXJuIG51bGxcbiAgfVxuXG4gIGFzeW5jIGNyZWF0ZVRlbXBsYXRlTWFuaWZlc3QoYmFzZVBhdGg6IHN0cmluZykge1xuICAgIGNvbnN0IG1hbmlmZXN0UGF0aCA9IGAke2Jhc2VQYXRofS90ZW1wbGF0ZS1tYW5pZmVzdC5qc29uYFxuICAgIGNvbnN0IG1hbmlmZXN0Q29udGVudCA9IEpTT04uc3RyaW5naWZ5KHRoaXMubWFuaWZlc3QsIG51bGwsIDIpXG5cbiAgICB0cnkge1xuICAgICAgLy8gQ2hlY2sgaWYgbWFuaWZlc3QgYWxyZWFkeSBleGlzdHNcbiAgICAgIGNvbnN0IGV4aXN0aW5nTWFuaWZlc3QgPVxuICAgICAgICB0aGlzLmFwcC52YXVsdC5nZXRBYnN0cmFjdEZpbGVCeVBhdGgobWFuaWZlc3RQYXRoKVxuICAgICAgaWYgKGV4aXN0aW5nTWFuaWZlc3QpIHtcbiAgICAgICAgLy8gVXBkYXRlIHRoZSBleGlzdGluZyBtYW5pZmVzdFxuICAgICAgICBjb25zdCBmaWxlID0gZXhpc3RpbmdNYW5pZmVzdCBhcyBpbXBvcnQoXCJvYnNpZGlhblwiKS5URmlsZVxuICAgICAgICBhd2FpdCB0aGlzLmFwcC52YXVsdC5tb2RpZnkoZmlsZSwgbWFuaWZlc3RDb250ZW50KVxuICAgICAgICBjb25zb2xlLmxvZyhgVXBkYXRlZCB0ZW1wbGF0ZSBtYW5pZmVzdDogJHttYW5pZmVzdFBhdGh9YClcbiAgICAgICAgcmV0dXJuXG4gICAgICB9XG5cbiAgICAgIC8vIENyZWF0ZSB0aGUgbWFuaWZlc3QgZmlsZVxuICAgICAgYXdhaXQgdGhpcy5hcHAudmF1bHQuY3JlYXRlKG1hbmlmZXN0UGF0aCwgbWFuaWZlc3RDb250ZW50KVxuICAgICAgY29uc29sZS5sb2coYENyZWF0ZWQgdGVtcGxhdGUgbWFuaWZlc3Q6ICR7bWFuaWZlc3RQYXRofWApXG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgbmV3IE5vdGljZShgRXJyb3IgY3JlYXRpbmcgdGVtcGxhdGUgbWFuaWZlc3QgJHttYW5pZmVzdFBhdGh9YClcbiAgICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIGNyZWF0aW5nIHRlbXBsYXRlIG1hbmlmZXN0ICR7bWFuaWZlc3RQYXRofTpgLCBlKVxuICAgIH1cbiAgfVxuXG4gIGFzeW5jIGNoZWNrRm9yVGVtcGxhdGVVcGRhdGVzKCk6IFByb21pc2U8Ym9vbGVhbj4ge1xuICAgIC8vIFRoaXMgd291bGQgY2hlY2sgaWYgdGVtcGxhdGVzIG5lZWQgdG8gYmUgdXBkYXRlZFxuICAgIC8vIEZvciBub3csIHdlJ2xsIGp1c3QgcmV0dXJuIGZhbHNlXG4gICAgY29uc29sZS5sb2coXCJDaGVja2luZyBmb3IgdGVtcGxhdGUgdXBkYXRlc1wiKVxuICAgIHJldHVybiBmYWxzZVxuICB9XG5cbiAgYXN5bmMgdXBkYXRlVGVtcGxhdGVzKCkge1xuICAgIHRyeSB7XG4gICAgICAvLyBUaGlzIHdvdWxkIHVwZGF0ZSBleGlzdGluZyB0ZW1wbGF0ZXNcbiAgICAgIGNvbnNvbGUubG9nKFwiVXBkYXRpbmcgdGVtcGxhdGVzXCIpXG5cbiAgICAgIC8vIEdldCBUZW1wbGF0ZXIgcGx1Z2luIHNldHRpbmdzIHRvIGZpbmQgdGVtcGxhdGUgZm9sZGVyXG4gICAgICBjb25zdCB0ZW1wbGF0ZXJQbHVnaW4gPSB0aGlzLmdldFRlbXBsYXRlclBsdWdpbigpXG4gICAgICBpZiAoIXRlbXBsYXRlclBsdWdpbikge1xuICAgICAgICBuZXcgTm90aWNlKFxuICAgICAgICAgIFwiVGVtcGxhdGVyIHBsdWdpbiBub3QgZm91bmQuIFBsZWFzZSBpbnN0YWxsIGFuZCBlbmFibGUgdGhlIFRlbXBsYXRlciBwbHVnaW4gZmlyc3QuXCJcbiAgICAgICAgKVxuICAgICAgICBjb25zb2xlLmVycm9yKFxuICAgICAgICAgIFwiVGVtcGxhdGVyIHBsdWdpbiBub3QgZm91bmQuIFBsZWFzZSBpbnN0YWxsIGFuZCBlbmFibGUgdGhlIFRlbXBsYXRlciBwbHVnaW4gZmlyc3QuXCJcbiAgICAgICAgKVxuICAgICAgICByZXR1cm5cbiAgICAgIH1cblxuICAgICAgY29uc3QgdGVtcGxhdGVGb2xkZXJQYXRoID0gdGhpcy5nZXRUZW1wbGF0ZUZvbGRlclBhdGgodGVtcGxhdGVyUGx1Z2luKVxuICAgICAgaWYgKCF0ZW1wbGF0ZUZvbGRlclBhdGgpIHtcbiAgICAgICAgbmV3IE5vdGljZShcbiAgICAgICAgICBcIlRlbXBsYXRlIGZvbGRlciBub3QgY29uZmlndXJlZCBpbiBUZW1wbGF0ZXIgc2V0dGluZ3MuIFBsZWFzZSBjb25maWd1cmUgaXQgaW4gVGVtcGxhdGVyIHNldHRpbmdzIGZpcnN0LlwiXG4gICAgICAgIClcbiAgICAgICAgY29uc29sZS5lcnJvcihcbiAgICAgICAgICBcIlRlbXBsYXRlIGZvbGRlciBub3QgY29uZmlndXJlZCBpbiBUZW1wbGF0ZXIgc2V0dGluZ3MuIFBsZWFzZSBjb25maWd1cmUgaXQgaW4gVGVtcGxhdGVyIHNldHRpbmdzIGZpcnN0LlwiXG4gICAgICAgIClcbiAgICAgICAgcmV0dXJuXG4gICAgICB9XG5cbiAgICAgIGNvbnN0IGZ1bGxUZW1wbGF0ZVBhdGggPSBgJHt0ZW1wbGF0ZUZvbGRlclBhdGh9LyR7dGhpcy5zZXR0aW5ncy50ZW1wbGF0ZUZvbGRlcn1gXG5cbiAgICAgIC8vIFVwZGF0ZSB0ZW1wbGF0ZXMgKHRoaXMgd2lsbCBvdmVyd3JpdGUgZXhpc3Rpbmcgb25lcylcbiAgICAgIGF3YWl0IHRoaXMuaW5zdGFsbENvdXJzZVRlbXBsYXRlcyhmdWxsVGVtcGxhdGVQYXRoKVxuICAgICAgYXdhaXQgdGhpcy5pbnN0YWxsTW9kdWxlVGVtcGxhdGVzKGZ1bGxUZW1wbGF0ZVBhdGgpXG4gICAgICBhd2FpdCB0aGlzLmluc3RhbGxDaGFwdGVyVGVtcGxhdGVzKGZ1bGxUZW1wbGF0ZVBhdGgpXG4gICAgICBhd2FpdCB0aGlzLmluc3RhbGxBc3NpZ25tZW50VGVtcGxhdGVzKGZ1bGxUZW1wbGF0ZVBhdGgpXG4gICAgICBhd2FpdCB0aGlzLmluc3RhbGxEYWlseVRlbXBsYXRlcyhmdWxsVGVtcGxhdGVQYXRoKVxuICAgICAgYXdhaXQgdGhpcy5pbnN0YWxsVXRpbGl0eVRlbXBsYXRlcyhmdWxsVGVtcGxhdGVQYXRoKVxuXG4gICAgICAvLyBVcGRhdGUgUkVBRE1FXG4gICAgICBhd2FpdCB0aGlzLmNyZWF0ZVJFQURNRShmdWxsVGVtcGxhdGVQYXRoKVxuXG4gICAgICAvLyBVcGRhdGUgdGVtcGxhdGUgbWFuaWZlc3RcbiAgICAgIGF3YWl0IHRoaXMuY3JlYXRlVGVtcGxhdGVNYW5pZmVzdChmdWxsVGVtcGxhdGVQYXRoKVxuXG4gICAgICBuZXcgTm90aWNlKFwiVHVja2VycyBUb29scyB0ZW1wbGF0ZXMgdXBkYXRlZCBzdWNjZXNzZnVsbHkhXCIpXG4gICAgICBjb25zb2xlLmxvZyhcIlR1Y2tlcnMgVG9vbHMgdGVtcGxhdGVzIHVwZGF0ZWQgc3VjY2Vzc2Z1bGx5XCIpXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciB1cGRhdGluZyB0ZW1wbGF0ZXM6XCIsIGVycm9yKVxuICAgICAgbmV3IE5vdGljZShcIkVycm9yIHVwZGF0aW5nIHRlbXBsYXRlcy4gQ2hlY2sgY29uc29sZSBmb3IgZGV0YWlscy5cIilcbiAgICB9XG4gIH1cblxuICBhc3luYyBpbnN0YWxsQ291cnNlVGVtcGxhdGVzKGJhc2VQYXRoOiBzdHJpbmcpIHtcbiAgICBjb25zdCBjb3Vyc2VQYXRoID0gYCR7YmFzZVBhdGh9L0NvdXJzZXNgXG5cbiAgICAvLyBDcmVhdGUgQ291cnNlIEhvbWVwYWdlIHRlbXBsYXRlXG4gICAgY29uc3QgY291cnNlSG9tZXBhZ2VUZW1wbGF0ZSA9IHRoaXMuZ2VuZXJhdGVDb3Vyc2VIb21lcGFnZVRlbXBsYXRlKClcbiAgICBhd2FpdCB0aGlzLndyaXRlVGVtcGxhdGVGaWxlKFxuICAgICAgYCR7Y291cnNlUGF0aH0vQ3JlYXRlIENvdXJzZSBIb21lcGFnZS5tZGAsXG4gICAgICBjb3Vyc2VIb21lcGFnZVRlbXBsYXRlXG4gICAgKVxuXG4gICAgLy8gQ3JlYXRlIENvdXJzZSBJbmRleCB0ZW1wbGF0ZVxuICAgIGNvbnN0IGNvdXJzZUluZGV4VGVtcGxhdGUgPSB0aGlzLmdlbmVyYXRlQ291cnNlSW5kZXhUZW1wbGF0ZSgpXG4gICAgYXdhaXQgdGhpcy53cml0ZVRlbXBsYXRlRmlsZShcbiAgICAgIGAke2NvdXJzZVBhdGh9L0NvdXJzZSBJbmRleC5tZGAsXG4gICAgICBjb3Vyc2VJbmRleFRlbXBsYXRlXG4gICAgKVxuICB9XG5cbiAgYXN5bmMgaW5zdGFsbE1vZHVsZVRlbXBsYXRlcyhiYXNlUGF0aDogc3RyaW5nKSB7XG4gICAgY29uc3QgbW9kdWxlUGF0aCA9IGAke2Jhc2VQYXRofS9Nb2R1bGVzYFxuXG4gICAgLy8gQ3JlYXRlIE1vZHVsZSB0ZW1wbGF0ZVxuICAgIGNvbnN0IG1vZHVsZVRlbXBsYXRlID0gdGhpcy5nZW5lcmF0ZU1vZHVsZVRlbXBsYXRlKClcbiAgICBhd2FpdCB0aGlzLndyaXRlVGVtcGxhdGVGaWxlKFxuICAgICAgYCR7bW9kdWxlUGF0aH0vQ3JlYXRlIE1vZHVsZS5tZGAsXG4gICAgICBtb2R1bGVUZW1wbGF0ZVxuICAgIClcbiAgfVxuXG4gIGFzeW5jIGluc3RhbGxDaGFwdGVyVGVtcGxhdGVzKGJhc2VQYXRoOiBzdHJpbmcpIHtcbiAgICBjb25zdCBjaGFwdGVyUGF0aCA9IGAke2Jhc2VQYXRofS9DaGFwdGVyc2BcblxuICAgIC8vIENyZWF0ZSBDaGFwdGVyIHRlbXBsYXRlXG4gICAgY29uc3QgY2hhcHRlclRlbXBsYXRlID0gdGhpcy5nZW5lcmF0ZUNoYXB0ZXJUZW1wbGF0ZSgpXG4gICAgYXdhaXQgdGhpcy53cml0ZVRlbXBsYXRlRmlsZShcbiAgICAgIGAke2NoYXB0ZXJQYXRofS9DcmVhdGUgQ2hhcHRlci5tZGAsXG4gICAgICBjaGFwdGVyVGVtcGxhdGVcbiAgICApXG4gIH1cblxuICBhc3luYyBpbnN0YWxsQXNzaWdubWVudFRlbXBsYXRlcyhiYXNlUGF0aDogc3RyaW5nKSB7XG4gICAgY29uc3QgYXNzaWdubWVudFBhdGggPSBgJHtiYXNlUGF0aH0vQXNzaWdubWVudHNgXG5cbiAgICAvLyBDcmVhdGUgQXNzaWdubWVudCB0ZW1wbGF0ZVxuICAgIGNvbnN0IGFzc2lnbm1lbnRUZW1wbGF0ZSA9IHRoaXMuZ2VuZXJhdGVBc3NpZ25tZW50VGVtcGxhdGUoKVxuICAgIGF3YWl0IHRoaXMud3JpdGVUZW1wbGF0ZUZpbGUoXG4gICAgICBgJHthc3NpZ25tZW50UGF0aH0vQ3JlYXRlIEFzc2lnbm1lbnQubWRgLFxuICAgICAgYXNzaWdubWVudFRlbXBsYXRlXG4gICAgKVxuICB9XG5cbiAgYXN5bmMgaW5zdGFsbERhaWx5VGVtcGxhdGVzKGJhc2VQYXRoOiBzdHJpbmcpIHtcbiAgICBjb25zdCBkYWlseVBhdGggPSBgJHtiYXNlUGF0aH0vRGFpbHlgXG5cbiAgICAvLyBDcmVhdGUgRGFpbHkgTm90ZSB0ZW1wbGF0ZVxuICAgIGNvbnN0IGRhaWx5Tm90ZVRlbXBsYXRlID0gdGhpcy5nZW5lcmF0ZURhaWx5Tm90ZVRlbXBsYXRlKClcbiAgICBhd2FpdCB0aGlzLndyaXRlVGVtcGxhdGVGaWxlKFxuICAgICAgYCR7ZGFpbHlQYXRofS9EYWlseSBOb3RlLm1kYCxcbiAgICAgIGRhaWx5Tm90ZVRlbXBsYXRlXG4gICAgKVxuICB9XG5cbiAgYXN5bmMgaW5zdGFsbFV0aWxpdHlUZW1wbGF0ZXMoYmFzZVBhdGg6IHN0cmluZykge1xuICAgIGNvbnN0IHV0aWxpdHlQYXRoID0gYCR7YmFzZVBhdGh9L1V0aWxpdGllc2BcblxuICAgIC8vIENyZWF0ZSBWb2NhYnVsYXJ5IEVudHJ5IHRlbXBsYXRlXG4gICAgY29uc3Qgdm9jYWJUZW1wbGF0ZSA9IHRoaXMuZ2VuZXJhdGVWb2NhYnVsYXJ5VGVtcGxhdGUoKVxuICAgIGF3YWl0IHRoaXMud3JpdGVUZW1wbGF0ZUZpbGUoXG4gICAgICBgJHt1dGlsaXR5UGF0aH0vVm9jYWJ1bGFyeSBFbnRyeS5tZGAsXG4gICAgICB2b2NhYlRlbXBsYXRlXG4gICAgKVxuXG4gICAgLy8gQ3JlYXRlIER1ZSBEYXRlIEVudHJ5IHRlbXBsYXRlXG4gICAgY29uc3QgZHVlRGF0ZVRlbXBsYXRlID0gdGhpcy5nZW5lcmF0ZUR1ZURhdGVUZW1wbGF0ZSgpXG4gICAgYXdhaXQgdGhpcy53cml0ZVRlbXBsYXRlRmlsZShcbiAgICAgIGAke3V0aWxpdHlQYXRofS9EdWUgRGF0ZSBFbnRyeS5tZGAsXG4gICAgICBkdWVEYXRlVGVtcGxhdGVcbiAgICApXG4gIH1cblxuICBhc3luYyB3cml0ZVRlbXBsYXRlRmlsZShwYXRoOiBzdHJpbmcsIGNvbnRlbnQ6IHN0cmluZykge1xuICAgIHRyeSB7XG4gICAgICAvLyBDaGVjayBpZiBmaWxlIGFscmVhZHkgZXhpc3RzXG4gICAgICBjb25zdCBleGlzdGluZ0ZpbGUgPSB0aGlzLmFwcC52YXVsdC5nZXRBYnN0cmFjdEZpbGVCeVBhdGgocGF0aClcbiAgICAgIGlmIChleGlzdGluZ0ZpbGUpIHtcbiAgICAgICAgLy8gRm9yIG5vdywgd2UnbGwgdXBkYXRlIGV4aXN0aW5nIHRlbXBsYXRlc1xuICAgICAgICAvLyBJbiBhIHJlYWwgaW1wbGVtZW50YXRpb24sIHdlJ2QgY2hlY2sgdmVyc2lvbnMgYW5kIG9mZmVyIHRvIHVwZGF0ZVxuICAgICAgICBjb25zb2xlLmxvZyhgVXBkYXRpbmcgZXhpc3RpbmcgdGVtcGxhdGUgZmlsZTogJHtwYXRofWApXG4gICAgICAgIGNvbnN0IGZpbGUgPSBleGlzdGluZ0ZpbGUgYXMgaW1wb3J0KFwib2JzaWRpYW5cIikuVEZpbGVcbiAgICAgICAgYXdhaXQgdGhpcy5hcHAudmF1bHQubW9kaWZ5KGZpbGUsIGNvbnRlbnQpXG4gICAgICAgIHJldHVyblxuICAgICAgfVxuXG4gICAgICAvLyBDcmVhdGUgdGhlIGZpbGVcbiAgICAgIGF3YWl0IHRoaXMuYXBwLnZhdWx0LmNyZWF0ZShwYXRoLCBjb250ZW50KVxuICAgICAgY29uc29sZS5sb2coYENyZWF0ZWQgdGVtcGxhdGUgZmlsZTogJHtwYXRofWApXG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgbmV3IE5vdGljZShgRXJyb3IgY3JlYXRpbmcgdGVtcGxhdGUgZmlsZSAke3BhdGh9YClcbiAgICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIGNyZWF0aW5nIHRlbXBsYXRlIGZpbGUgJHtwYXRofTpgLCBlKVxuICAgIH1cbiAgfVxuXG4gIGdlbmVyYXRlQ291cnNlSG9tZXBhZ2VUZW1wbGF0ZSgpOiBzdHJpbmcge1xuICAgIHJldHVybiBgLS0tXG4ke1xuICB0aGlzLnNldHRpbmdzLnVzZUVuaGFuY2VkTWV0YWRhdGFcbiAgICA/IGBjb3Vyc2VfaWQ6IDwlIGNvdXJzZUlkICU+XG5jb3Vyc2VfbmFtZTogPCUgY291cnNlTmFtZSAlPlxuY291cnNlX3Rlcm06IDwlIGNvdXJzZVNlYXNvbiAlPiA8JSBjb3Vyc2VZZWFyICU+XG5jb3Vyc2VfeWVhcjogPCUgY291cnNlWWVhciAlPlxuY291cnNlX3NlbWVzdGVyOiA8JSBjb3Vyc2VTZWFzb24gJT5cbmNvbnRlbnRfdHlwZTogY291cnNlX2hvbWVwYWdlXG5zY2hvb2w6ICR7dGhpcy5zZXR0aW5ncy5zY2hvb2xOYW1lfVxuc2Nob29sX2FiYnJldmlhdGlvbjogJHt0aGlzLnNldHRpbmdzLnNjaG9vbEFiYnJldmlhdGlvbn1gXG4gICAgOiBgY291cnNlX2lkOiA8JSBjb3Vyc2VJZCAlPlxudGl0bGU6IDwlIGNvdXJzZU5hbWUgJT5gXG59XG5jcmVhdGVkOiA8JSB0cC5kYXRlLm5vdyhcIllZWVktTU0tRERbVF1ISDptbTpzc1pcIikgJT5cbnRhZ3M6IFxuICAtIGNvdXJzZV9ob21lXG4gIC0gZWR1Y2F0aW9uXG4gIC0gPCUgY291cnNlSWQgJT5cbiAgLSAke1xuICAgIHRoaXMuc2V0dGluZ3Muc2Nob29sQWJicmV2aWF0aW9uXG4gIH0vPCUgY291cnNlWWVhciAlPi88JSBjb3Vyc2VTZWFzb24gJT4vPCUgY291cnNlSWQgJT5cbi0tLVxuXG48JSpcbi8vIFR1Y2tlcnMgVG9vbHMgQ291cnNlIENyZWF0aW9uXG4vLyBcbi8vIE5PVEU6IEZvciB0aGUgYmVzdCBleHBlcmllbmNlLCB1c2UgdGhlIFwiQ3JlYXRlIE5ldyBDb3Vyc2VcIiBjb21tYW5kIFxuLy8gZnJvbSB0aGUgY29tbWFuZCBwYWxldHRlIGluc3RlYWQgb2YgdXNpbmcgdGhpcyB0ZW1wbGF0ZSBkaXJlY3RseS5cbi8vIFxuLy8gSWYgeW91IGVuY291bnRlciAncHJvbXB0KCkgaXMgbm90IHN1cHBvcnRlZCcgZXJyb3JzLCB0aGlzIG1lYW5zIHRoZSBcbi8vIHRwLnN5c3RlbSBmdW5jdGlvbnMgYXJlIG5vdCBhdmFpbGFibGUgaW4geW91ciBjdXJyZW50IGNvbnRleHQuXG4vLyBVc2UgdGhlIHBsdWdpbiBjb21tYW5kIGluc3RlYWQ6IENvbW1hbmQgUGFsZXR0ZSBcdTIxOTIgJ0NyZWF0ZSBOZXcgQ291cnNlJ1xuXG5jb25zdCB7IGV4ZWMgfSA9IHJlcXVpcmUoXCJjaGlsZF9wcm9jZXNzXCIpO1xuXG5sZXQgY291cnNlTmFtZSA9IFwiTmV3IENvdXJzZVwiO1xubGV0IGNvdXJzZVNlYXNvbiA9IFwiRmFsbFwiOyBcbmxldCBjb3Vyc2VZZWFyID0gbmV3IERhdGUoKS5nZXRGdWxsWWVhcigpLnRvU3RyaW5nKCk7XG5sZXQgY291cnNlSWQgPSBcIkNPVVJTRV9JRFwiO1xuXG4vLyBUcnkgdG8gdXNlIHN5c3RlbSBwcm9tcHRzLCB3aXRoIGdyYWNlZnVsIGZhbGxiYWNrXG50cnkge1xuICBpZiAodHAgJiYgdHAuc3lzdGVtICYmIHRwLnN5c3RlbS5wcm9tcHQpIHtcbiAgICBjb3Vyc2VOYW1lID0gYXdhaXQgdHAuc3lzdGVtLnByb21wdChcIkNvdXJzZSBOYW1lIChlLmcuIFBTSS0xMDEgLSBJbnRybyB0byBQc3ljaClcIikgfHwgY291cnNlTmFtZTtcbiAgICBjb3Vyc2VTZWFzb24gPSBhd2FpdCB0cC5zeXN0ZW0uc3VnZ2VzdGVyKFtcIkZhbGxcIixcIldpbnRlclwiLFwiU3ByaW5nXCIsXCJTdW1tZXJcIl0sW1wiRmFsbFwiLFwiV2ludGVyXCIsXCJTcHJpbmdcIixcIlN1bW1lclwiXSwgXCJTZWFzb25cIikgfHwgY291cnNlU2Vhc29uO1xuICAgIGNvdXJzZVllYXIgPSBhd2FpdCB0cC5zeXN0ZW0ucHJvbXB0KFwiWWVhclwiKSB8fCBjb3Vyc2VZZWFyO1xuICAgIGNvdXJzZUlkID0gY291cnNlTmFtZS5zcGxpdCgnIC0gJylbMF0gfHwgY291cnNlTmFtZS5yZXBsYWNlKC9bXmEtekEtWjAtOV0vZywgXCJfXCIpO1xuICB9IGVsc2Uge1xuICAgIC8vIEZhbGxiYWNrIGlmIHRwLnN5c3RlbSBpcyBub3QgYXZhaWxhYmxlXG4gICAgY29uc29sZS5sb2coXCJTeXN0ZW0gcHJvbXB0cyBub3QgYXZhaWxhYmxlLCB1c2UgdGhlIHBsdWdpbiBjb21tYW5kIGluc3RlYWRcIik7XG4gIH1cbn0gY2F0Y2ggKGUpIHtcbiAgY29uc29sZS5lcnJvcihcIkVycm9yIHdpdGggc3lzdGVtIHByb21wdHM6XCIsIGUubWVzc2FnZSk7XG4gIGNvbnNvbGUubG9nKFwiVXNlIHRoZSBwbHVnaW4gY29tbWFuZDogQ29tbWFuZCBQYWxldHRlIFx1MjE5MiAnQ3JlYXRlIE5ldyBDb3Vyc2UnXCIpO1xufVxuXG4vLyBNb3ZlIGZpbGUgdG8gYXBwcm9wcmlhdGUgbG9jYXRpb25cbmF3YWl0IHRwLmZpbGUubW92ZShcXGAvXFwke2NvdXJzZVllYXJ9L1xcJHtjb3Vyc2VTZWFzb259L1xcJHtjb3Vyc2VOYW1lfS9cXCR7Y291cnNlTmFtZX1cXGApO1xuXG4vLyBDcmVhdGUgYXR0YWNobWVudHMgZm9sZGVyXG50cnkge1xuICBhd2FpdCBhcHAudmF1bHQuY3JlYXRlRm9sZGVyKFxcYFxcJHtjb3Vyc2VZZWFyfS9cXCR7Y291cnNlU2Vhc29ufS9cXCR7Y291cnNlTmFtZX0vQXR0YWNobWVudHNcXGApO1xufSBjYXRjaCAoZSkge1xuICAvLyBGb2xkZXIgbWlnaHQgYWxyZWFkeSBleGlzdFxufVxuJT5cblxuIyA8JSBjb3Vyc2VOYW1lICU+XG5cbiMjIENvdXJzZSBJbmZvcm1hdGlvblxuKipDb3Vyc2UgSUQqKjogPCUgY291cnNlSWQgJT5cbioqVGVybSoqOiA8JSBjb3Vyc2VTZWFzb24gJT4gPCUgY291cnNlWWVhciAlPlxuKipTY2hvb2wqKjogJHt0aGlzLnNldHRpbmdzLnNjaG9vbE5hbWV9XG5cbiMjIEluc3RydWN0b3JcbioqTmFtZSoqOiBcbioqRW1haWwqKjogXG4qKk9mZmljZSBIb3VycyoqOiBcblxuIyMgQ291cnNlIERlc2NyaXB0aW9uXG5cbiMjIExlYXJuaW5nIE9iamVjdGl2ZXNcblxuIyMgUmVxdWlyZWQgVGV4dHNcblxcYFxcYFxcYG1ldGEtYmluZC1qcy12aWV3XG57dGV4dHN9IGFzIHRleHRzXG4tLS1cbmNvbnN0IGF2YWlsYWJsZVRleHRzID0gYXBwLnZhdWx0LmdldEZpbGVzKCkuZmlsdGVyKGZpbGUgPT4gZmlsZS5leHRlbnNpb24gPT0gJ3BkZicpLm1hcChmID0+IGY/Lm5hbWUpXG5jb25zdCBlc2NhcGVSZWdleCA9IC9bLFxcYCcoKV0vZztcbm9wdGlvbnMgPSBhdmFpbGFibGVUZXh0cy5tYXAodCA9PiBcXGBvcHRpb24oW1tcXCR7dC5yZXBsYWNlKGVzY2FwZVJlZ2V4LFxcJDEpfV1dLCBcXCR7dC5yZXBsYWNlKGVzY2FwZVJlZ2V4LFxcJDEpfSlcXGAgKVxuY29uc3Qgc3RyID0gXFxcXFxcYElOUFVUW2lubGluZUxpc3RTdWdnZXN0ZXIoXFwke29wdGlvbnMuam9pbihcIiwgXCIpfSk6dGV4dHNdXFxcXFxcYFxucmV0dXJuIGVuZ2luZS5tYXJrZG93bi5jcmVhdGUoc3RyKVxuXFxgXFxgXFxgXG5cbiMjIFNjaGVkdWxlXG5cbiMjIEFzc2lnbm1lbnRzXG5cbiMjIFJlc291cmNlc1xuXG4jIyBWb2NhYnVsYXJ5XG5cXGBcXGBcXGBkYXRhdmlld2pzXG4vLyBWb2NhYnVsYXJ5IGFnZ3JlZ2F0aW9uIGNvZGUgd291bGQgZ28gaGVyZVxuXFxgXFxgXFxgXG5cbiMjIER1ZSBEYXRlc1xuXFxgXFxgXFxgZGF0YXZpZXdqc1xuLy8gRHVlIGRhdGVzIGFnZ3JlZ2F0aW9uIGNvZGUgd291bGQgZ28gaGVyZVxuXFxgXFxgXFxgYFxuICB9XG5cbiAgZ2VuZXJhdGVDb3Vyc2VJbmRleFRlbXBsYXRlKCk6IHN0cmluZyB7XG4gICAgcmV0dXJuIGAtLS1cbmNvbnRlbnRfdHlwZTogY291cnNlX2luZGV4XG50YWdzOlxuICAtIGluZGV4XG4tLS1cblxuIyBDb3Vyc2UgSW5kZXhcblxuIyMgTW9kdWxlc1xuXG4jIyBDaGFwdGVyc1xuXG4jIyBBc3NpZ25tZW50c1xuXG4jIyBSZXNvdXJjZXNcblxuIyMgVm9jYWJ1bGFyeVxuXG4jIyBEdWUgRGF0ZXNgXG4gIH1cblxuICBnZW5lcmF0ZU1vZHVsZVRlbXBsYXRlKCk6IHN0cmluZyB7XG4gICAgcmV0dXJuIGAtLS1cbiR7XG4gIHRoaXMuc2V0dGluZ3MudXNlRW5oYW5jZWRNZXRhZGF0YVxuICAgID8gYGNvdXJzZV9pZDogPCUgY291cnNlSWQgJT5cbm1vZHVsZV9udW1iZXI6IDwlIG1vZHVsZU51bWJlciAlPlxud2Vla19udW1iZXI6IDwlIHdlZWtOdW1iZXIgJT5cbmNsYXNzX2RheTogPCUgZGF5T2ZXZWVrICU+XG5jb250ZW50X3R5cGU6IG1vZHVsZVxucGFyZW50X2NvdXJzZTogXCJbWzwlIGNvdXJzZSAlPl1dXCJgXG4gICAgOiBgY291cnNlX2lkOiA8JSBjb3Vyc2VJZCAlPlxubW9kdWxlX251bWJlcjogPCUgbW9kdWxlTnVtYmVyICU+XG53ZWVrX251bWJlcjogPCUgd2Vla051bWJlciAlPlxuY2xhc3NfZGF5OiA8JSBkYXlPZldlZWsgJT5gXG59XG5jcmVhdGVkOiA8JSB0cC5kYXRlLm5vdyhcIllZWVktTU0tRERbVF1ISDptbTpzc1pcIikgJT5cbnRhZ3M6XG4gIC0gZWR1Y2F0aW9uXG4gIC0gPCUgY291cnNlSWQgJT5cbiAgLSBtb2R1bGVcbi0tLVxuXG48JSpcbmNvbnN0IHsgc2Vhc29uLCBtb2R1bGVOdW1iZXIsIHdlZWtOdW1iZXIsIGNvdXJzZSwgY291cnNlSWQsIGRpc2NpcGxpbmUsIGRheU9mV2VlayB9ID0gYXdhaXQgdHAudXNlci5uZXdfbW9kdWxlKGFwcCwgdHAsIFwiMjAyNVwiKTtcbmxldCB0aXRsZSA9IGNvdXJzZUlkXG5pZiAobW9kdWxlTnVtYmVyICYmIHdlZWtOdW1iZXIpIHsgdGl0bGUgPSBcXGBNXFwke21vZHVsZU51bWJlcn0vV1xcJHt3ZWVrTnVtYmVyfVxcYH1cbmVsc2UgaWYgKG1vZHVsZU51bWJlcikgeyB0aXRsZSA9IFxcYE1cXCR7bW9kdWxlTnVtYmVyfVxcYCB9IFxuZWxzZSBpZiAod2Vla051bWJlcikgeyB0aXRsZSA9IFxcYFdcXCR7d2Vla051bWJlcn1cXGB9XG4lPlxuXG4jIFtbPCUgY291cnNlICU+XV0gLSA8JSB0aXRsZSAlPiAtIDwlIGRheU9mV2VlayAlPlxuXG4jIyBMZWFybmluZyBPYmplY3RpdmVzXG5cbiMjIFJlYWRpbmcgQXNzaWdubWVudFxuXG4jIyBMZWN0dXJlIE5vdGVzXG5cbiMjIERpc2N1c3Npb24gUXVlc3Rpb25zXG5cbiMjIEFzc2lnbm1lbnRzXG58IERhdGUgfCBBc3NpZ25tZW50IHwgU3RhdHVzIHxcbnwgLS0tLSB8IC0tLS0tLS0tLS0gfCAtLS0tLS0gfFxufCAgICAgIHwgICAgICAgICAgICB8ICAgICAgICB8XG5cbiMjIFZvY2FidWxhcnlcblxuIyMgQWRkaXRpb25hbCBSZXNvdXJjZXNgXG4gIH1cblxuICBnZW5lcmF0ZUNoYXB0ZXJUZW1wbGF0ZSgpOiBzdHJpbmcge1xuICAgIHJldHVybiBgLS0tXG4ke1xuICB0aGlzLnNldHRpbmdzLnVzZUVuaGFuY2VkTWV0YWRhdGFcbiAgICA/IGBjb3Vyc2VfaWQ6IDwlIGNvdXJzZUlkICU+XG5jaGFwdGVyX251bWJlcjogPCUgY2hhcHRlck51bWJlciAlPlxuY29udGVudF90eXBlOiBjaGFwdGVyXG5wYXJlbnRfY291cnNlOiBcIltbPCUgY291cnNlICU+XV1cIlxudGV4dF9yZWZlcmVuY2U6IFwiW1s8JSB0ZXh0ICU+XV1cImBcbiAgICA6IGBjb3Vyc2VfaWQ6IDwlIGNvdXJzZUlkICU+XG5jaGFwdGVyX251bWJlcjogPCUgY2hhcHRlck51bWJlciAlPmBcbn1cbmNyZWF0ZWQ6IDwlIHRwLmRhdGUubm93KFwiWVlZWS1NTS1ERFtUXUhIOm1tOnNzWlwiKSAlPlxudGFnczpcbiAgLSBlZHVjYXRpb25cbiAgLSA8JSBjb3Vyc2VJZCAlPlxuICAtIGNoYXB0ZXJcbi0tLVxuXG48JSpcbmNvbnN0IHsgY2hhcHRlck51bWJlciwgY291cnNlLCBjb3Vyc2VJZCwgZGlzY2lwbGluZSwgdGV4dH0gPSBhd2FpdCB0cC51c2VyLm5ld19jaGFwdGVyKHRwKTtcbiU+XG5cbiMgW1s8JSB0ZXh0ICU+XV0gLSBDaGFwdGVyIDwlIGNoYXB0ZXJOdW1iZXIgJT5cblxuIyMgU3VtbWFyeVxuXG4jIyBLZXkgQ29uY2VwdHNcblxuIyMgVm9jYWJ1bGFyeVxuLSBcblxuIyMgTm90ZXNcblxuIyMgRGlzY3Vzc2lvbiBRdWVzdGlvbnNcblxuIyMgRnVydGhlciBSZWFkaW5nYFxuICB9XG5cbiAgZ2VuZXJhdGVBc3NpZ25tZW50VGVtcGxhdGUoKTogc3RyaW5nIHtcbiAgICByZXR1cm4gYC0tLVxuJHtcbiAgdGhpcy5zZXR0aW5ncy51c2VFbmhhbmNlZE1ldGFkYXRhXG4gICAgPyBgY291cnNlX2lkOiA8JSBjb3Vyc2VJZCAlPlxuYXNzaWdubWVudF90eXBlOiA8JSBhc3NpZ25tZW50VHlwZSAlPlxuZHVlX2RhdGU6IDwlIGR1ZURhdGUgJT5cbnBvaW50czogPCUgcG9pbnRzICU+XG5jb250ZW50X3R5cGU6IGFzc2lnbm1lbnRcbnBhcmVudF9jb3Vyc2U6IFwiW1s8JSBjb3Vyc2UgJT5dXVwiYFxuICAgIDogYGNvdXJzZV9pZDogPCUgY291cnNlSWQgJT5cbmFzc2lnbm1lbnRfdHlwZTogPCUgYXNzaWdubWVudFR5cGUgJT5cbmR1ZV9kYXRlOiA8JSBkdWVEYXRlICU+YFxufVxuY3JlYXRlZDogPCUgdHAuZGF0ZS5ub3coXCJZWVlZLU1NLUREW1RdSEg6bW06c3NaXCIpICU+XG5zdGF0dXM6IHBlbmRpbmdcbnRhZ3M6XG4gIC0gZWR1Y2F0aW9uXG4gIC0gPCUgY291cnNlSWQgJT5cbiAgLSBhc3NpZ25tZW50XG4tLS1cblxuIyA8JSBhc3NpZ25tZW50TmFtZSAlPiAtIDwlIGNvdXJzZUlkICU+XG5cbiMjIERlc2NyaXB0aW9uXG5cbiMjIEluc3RydWN0aW9uc1xuXG4jIyBEdWUgRGF0ZVxuKipBc3NpZ25lZCoqOiA8JSB0cC5kYXRlLm5vdyhcIllZWVktTU0tRERcIikgJT5cbioqRHVlKio6IDwlIGR1ZURhdGUgJT5cblxuIyMgU3VibWlzc2lvblxuXG4jIyBHcmFkaW5nIENyaXRlcmlhXG5cbiMjIFJlc291cmNlc2BcbiAgfVxuXG4gIGdlbmVyYXRlRGFpbHlOb3RlVGVtcGxhdGUoKTogc3RyaW5nIHtcbiAgICByZXR1cm4gYC0tLVxuY29udGVudF90eXBlOiBkYWlseV9ub3RlXG5kYXRlOiA8JSB0cC5kYXRlLm5vdyhcIllZWVktTU0tRERcIikgJT5cbnRhZ3M6XG4gIC0gZGFpbHlcbiAgLSA8JSB0cC5kYXRlLm5vdyhcIllZWVlcIikgJT5cbiAgLSA8JSB0cC5kYXRlLm5vdyhcIk1NXCIpICU+XG4gIC0gPCUgdHAuZGF0ZS5ub3coXCJERFwiKSAlPlxuLS0tXG5cbiMgPCUgdHAuZGF0ZS5ub3coXCJZWVlZLU1NLUREIC0gZGRkZFwiKSAlPlxuXG48PCBbWzwlIHRwLmRhdGUueWVzdGVyZGF5KFwiWVlZWS1NTS1ERFwiKSAlPl1dIHwgW1s8JSB0cC5kYXRlLnRvbW9ycm93KFwiWVlZWS1NTS1ERFwiKSAlPl1dID4+XG5cbiMjIFRvZGF5J3MgRm9jdXNcblxuIyMgQ291cnNlcyBXb3JrZWQgT25cbi0gXG5cbiMjIFRhc2tzIENvbXBsZXRlZFxuLSBbIF0gXG5cbiMjIFZvY2FidWxhcnkgUmV2aWV3ZWRcbi0gXG5cbiMjIEFzc2lnbm1lbnRzIER1ZVxuLSBcblxuIyMgTGVhcm5pbmcgQWNoaWV2ZW1lbnRzXG5cbiMjIENoYWxsZW5nZXNcblxuIyMgVG9tb3Jyb3cncyBQbGFuXG5cbiMjIFJlZmxlY3Rpb25gXG4gIH1cblxuICBnZW5lcmF0ZVZvY2FidWxhcnlUZW1wbGF0ZSgpOiBzdHJpbmcge1xuICAgIHJldHVybiBgIyMgPCUgdGVybSAlPlxuKipUZXJtKio6IDwlIHRlcm0gJT5cbioqUGFydCBvZiBTcGVlY2gqKjogXG4qKkRlZmluaXRpb24qKjogXG4qKkNvbnRleHQqKjogXG4qKkV4YW1wbGVzKio6IFxuKipSZWxhdGVkIFRlcm1zKio6IFxuKipTZWUgQWxzbyoqOmBcbiAgfVxuXG4gIGdlbmVyYXRlRHVlRGF0ZVRlbXBsYXRlKCk6IHN0cmluZyB7XG4gICAgcmV0dXJuIGB8IDwlIGR1ZURhdGUgJT4gfCA8JSBhc3NpZ25tZW50ICU+IHwgPCUgc3RhdHVzICU+IHxgXG4gIH1cblxuICBhc3luYyBjcmVhdGVSRUFETUUoYmFzZVBhdGg6IHN0cmluZykge1xuICAgIGNvbnN0IHJlYWRtZUNvbnRlbnQgPSBgIyBUdWNrZXJzIFRvb2xzIFRlbXBsYXRlc1xuXG5UaGlzIGRpcmVjdG9yeSBjb250YWlucyB0ZW1wbGF0ZXMgZm9yIHRoZSBUdWNrZXJzIFRvb2xzIE9ic2lkaWFuIHBsdWdpbi5cblxuIyMgVGVtcGxhdGUgQ2F0ZWdvcmllc1xuXG4tICoqQ291cnNlcyoqOiBUZW1wbGF0ZXMgZm9yIGNyZWF0aW5nIGFuZCBvcmdhbml6aW5nIGNvdXJzZXNcbi0gKipNb2R1bGVzKio6IFRlbXBsYXRlcyBmb3IgY291cnNlIG1vZHVsZXNcbi0gKipDaGFwdGVycyoqOiBUZW1wbGF0ZXMgZm9yIGNoYXB0ZXIgbm90ZXNcbi0gKipBc3NpZ25tZW50cyoqOiBUZW1wbGF0ZXMgZm9yIGFzc2lnbm1lbnRzXG4tICoqRGFpbHkqKjogVGVtcGxhdGVzIGZvciBkYWlseSBub3Rlc1xuLSAqKlV0aWxpdGllcyoqOiBIZWxwZXIgdGVtcGxhdGVzXG5cbiMjIFVzYWdlXG5cblRoZXNlIHRlbXBsYXRlcyBhcmUgZGVzaWduZWQgdG8gd29yayB3aXRoIHRoZSBUdWNrZXJzIFRvb2xzIHBsdWdpbi4gVG8gdXNlIHRoZW06XG5cbjEuIEluc3RhbGwgdGhlIFR1Y2tlcnMgVG9vbHMgcGx1Z2luXG4yLiBDb25maWd1cmUgeW91ciBzZXR0aW5ncyBpbiB0aGUgcGx1Z2luIHNldHRpbmdzIHRhYlxuMy4gVXNlIHRoZSBcIkluc2VydCBUZW1wbGF0ZVwiIGNvbW1hbmQgdG8gYXBwbHkgdGhlc2UgdGVtcGxhdGVzIHRvIG5ldyBub3Rlc1xuXG4jIyBDdXN0b21pemF0aW9uXG5cbkZlZWwgZnJlZSB0byBjdXN0b21pemUgdGhlc2UgdGVtcGxhdGVzIHRvIHN1aXQgeW91ciBuZWVkcy4gVGhlIHBsdWdpbiB3aWxsIG5vdCBvdmVyd3JpdGUgeW91ciBjaGFuZ2VzIHdoZW4gdXBkYXRpbmcgdGVtcGxhdGVzLmBcblxuICAgIGF3YWl0IHRoaXMud3JpdGVUZW1wbGF0ZUZpbGUoYCR7YmFzZVBhdGh9L1JFQURNRS5tZGAsIHJlYWRtZUNvbnRlbnQpXG4gIH1cbn1cbiIsICIvLyBDb3Vyc2UgY3JlYXRpb24gd2l6YXJkIGZvciBUdWNrZXJzIFRvb2xzIHBsdWdpblxuXG5pbXBvcnQgeyBBcHAsIE5vdGljZSwgVEZpbGUgfSBmcm9tIFwib2JzaWRpYW5cIlxuaW1wb3J0IHsgVHVja2Vyc1Rvb2xzU2V0dGluZ3MgfSBmcm9tIFwiLi9zZXR0aW5nc1wiXG5pbXBvcnQgeyBzbHVnaWZ5IH0gZnJvbSBcIi4vdXRpbHNcIlxuXG5leHBvcnQgY2xhc3MgQ291cnNlQ3JlYXRpb25XaXphcmQge1xuICBhcHA6IEFwcFxuICBzZXR0aW5nczogVHVja2Vyc1Rvb2xzU2V0dGluZ3NcblxuICBjb25zdHJ1Y3RvcihhcHA6IEFwcCwgc2V0dGluZ3M6IFR1Y2tlcnNUb29sc1NldHRpbmdzKSB7XG4gICAgdGhpcy5hcHAgPSBhcHBcbiAgICB0aGlzLnNldHRpbmdzID0gc2V0dGluZ3NcbiAgfVxuXG4gIGFzeW5jIGNyZWF0ZUNvdXJzZUhvbWVwYWdlKCkge1xuICAgIHRyeSB7XG4gICAgICAvLyBQcm9tcHQgdXNlciBmb3IgY291cnNlIGRldGFpbHNcbiAgICAgIGNvbnN0IGNvdXJzZURldGFpbHMgPSBhd2FpdCB0aGlzLnByb21wdENvdXJzZURldGFpbHMoKVxuXG4gICAgICBpZiAoIWNvdXJzZURldGFpbHMpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlIC8vIFVzZXIgY2FuY2VsbGVkXG4gICAgICB9XG5cbiAgICAgIC8vIENyZWF0ZSBmb2xkZXIgc3RydWN0dXJlXG4gICAgICBjb25zdCBmb2xkZXJQYXRoID0gYXdhaXQgdGhpcy5jcmVhdGVDb3Vyc2VGb2xkZXJTdHJ1Y3R1cmUoY291cnNlRGV0YWlscylcblxuICAgICAgLy8gR2VuZXJhdGUgY291cnNlIGhvbWVwYWdlIG5vdGVcbiAgICAgIGF3YWl0IHRoaXMuY3JlYXRlQ291cnNlSG9tZXBhZ2VOb3RlKGNvdXJzZURldGFpbHMsIGZvbGRlclBhdGgpXG5cbiAgICAgIC8vIENyZWF0ZSBhdHRhY2htZW50cyBmb2xkZXJcbiAgICAgIGF3YWl0IHRoaXMuY3JlYXRlQXR0YWNobWVudHNGb2xkZXIoZm9sZGVyUGF0aClcblxuICAgICAgbmV3IE5vdGljZShgQ291cnNlIFwiJHtjb3Vyc2VEZXRhaWxzLmNvdXJzZU5hbWV9XCIgY3JlYXRlZCBzdWNjZXNzZnVsbHkhYClcbiAgICAgIGNvbnNvbGUubG9nKFxuICAgICAgICBgQ291cnNlIGNyZWF0ZWQ6ICR7Y291cnNlRGV0YWlscy5jb3Vyc2VOYW1lfSBhdCAke2ZvbGRlclBhdGh9YFxuICAgICAgKVxuXG4gICAgICByZXR1cm4gdHJ1ZVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgY3JlYXRpbmcgY291cnNlOlwiLCBlcnJvcilcbiAgICAgIG5ldyBOb3RpY2UoYEVycm9yIGNyZWF0aW5nIGNvdXJzZTogJHtlcnJvci5tZXNzYWdlfWApXG4gICAgICByZXR1cm4gZmFsc2VcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIHByb21wdENvdXJzZURldGFpbHMoKTogUHJvbWlzZTx7XG4gICAgY291cnNlTmFtZTogc3RyaW5nXG4gICAgY291cnNlU2Vhc29uOiBzdHJpbmdcbiAgICBjb3Vyc2VZZWFyOiBzdHJpbmdcbiAgICBjb3Vyc2VJZDogc3RyaW5nXG4gIH0gfCBudWxsPiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGNvdXJzZU5hbWUgPSBhd2FpdCB0aGlzLnByb21wdFdpdGhWYWxpZGF0aW9uKFxuICAgICAgICBcIkNvdXJzZSBOYW1lXCIsXG4gICAgICAgIFwiRW50ZXIgY291cnNlIG5hbWUgKGUuZy4sIFBTSS0xMDEgLSBJbnRybyB0byBQc3ljaG9sb2d5KVwiLFxuICAgICAgICAodmFsdWUpID0+IHZhbHVlLnRyaW0oKS5sZW5ndGggPiAwLFxuICAgICAgICBcIkNvdXJzZSBuYW1lIGlzIHJlcXVpcmVkXCJcbiAgICAgIClcblxuICAgICAgaWYgKCFjb3Vyc2VOYW1lKSByZXR1cm4gbnVsbFxuXG4gICAgICBjb25zdCBjb3Vyc2VTZWFzb24gPSBhd2FpdCB0aGlzLnByb21wdFdpdGhPcHRpb25zKFxuICAgICAgICBcIlNlYXNvblwiLFxuICAgICAgICBcIlNlbGVjdCBzZW1lc3Rlci9zZWFzb25cIixcbiAgICAgICAgW1wiRmFsbFwiLCBcIldpbnRlclwiLCBcIlNwcmluZ1wiLCBcIlN1bW1lclwiXVxuICAgICAgKVxuXG4gICAgICBpZiAoIWNvdXJzZVNlYXNvbikgcmV0dXJuIG51bGxcblxuICAgICAgY29uc3QgY291cnNlWWVhciA9IGF3YWl0IHRoaXMucHJvbXB0V2l0aFZhbGlkYXRpb24oXG4gICAgICAgIFwiWWVhclwiLFxuICAgICAgICBcIkVudGVyIGFjYWRlbWljIHllYXIgKGUuZy4sIDIwMjUpXCIsXG4gICAgICAgICh2YWx1ZSkgPT4gL15cXGR7NH0kLy50ZXN0KHZhbHVlLnRyaW0oKSksXG4gICAgICAgIFwiUGxlYXNlIGVudGVyIGEgdmFsaWQgNC1kaWdpdCB5ZWFyXCJcbiAgICAgIClcblxuICAgICAgaWYgKCFjb3Vyc2VZZWFyKSByZXR1cm4gbnVsbFxuXG4gICAgICBjb25zdCBjb3Vyc2VJZCA9IGNvdXJzZU5hbWUuc3BsaXQoXCIgLSBcIilbMF0/LnRyaW0oKSB8fCBzbHVnaWZ5KGNvdXJzZU5hbWUpXG5cbiAgICAgIHJldHVybiB7XG4gICAgICAgIGNvdXJzZU5hbWUsXG4gICAgICAgIGNvdXJzZVNlYXNvbixcbiAgICAgICAgY291cnNlWWVhcixcbiAgICAgICAgY291cnNlSWRcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHByb21wdGluZyBmb3IgY291cnNlIGRldGFpbHM6XCIsIGVycm9yKVxuICAgICAgcmV0dXJuIG51bGxcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIHByb21wdFdpdGhWYWxpZGF0aW9uKFxuICAgIHRpdGxlOiBzdHJpbmcsXG4gICAgbWVzc2FnZTogc3RyaW5nLFxuICAgIHZhbGlkYXRvcjogKHZhbHVlOiBzdHJpbmcpID0+IGJvb2xlYW4sXG4gICAgZXJyb3JNZXNzYWdlOiBzdHJpbmdcbiAgKTogUHJvbWlzZTxzdHJpbmcgfCBudWxsPiB7XG4gICAgLy8gVXNlIGEgc2ltcGxlIHByb21wdCBmb3Igbm93IC0gaW4gYSByZWFsIGltcGxlbWVudGF0aW9uLCB0aGlzIHdvdWxkIHVzZSBhIHByb3BlciBtb2RhbFxuICAgIGNvbnN0IHZhbHVlID0gcHJvbXB0KGAke3RpdGxlfTogJHttZXNzYWdlfWApXG5cbiAgICBpZiAoIXZhbHVlKSByZXR1cm4gbnVsbCAvLyBVc2VyIGNhbmNlbGxlZFxuXG4gICAgaWYgKCF2YWxpZGF0b3IodmFsdWUpKSB7XG4gICAgICBuZXcgTm90aWNlKGVycm9yTWVzc2FnZSlcbiAgICAgIHJldHVybiBhd2FpdCB0aGlzLnByb21wdFdpdGhWYWxpZGF0aW9uKFxuICAgICAgICB0aXRsZSxcbiAgICAgICAgbWVzc2FnZSxcbiAgICAgICAgdmFsaWRhdG9yLFxuICAgICAgICBlcnJvck1lc3NhZ2VcbiAgICAgIClcbiAgICB9XG5cbiAgICByZXR1cm4gdmFsdWUudHJpbSgpXG4gIH1cblxuICBwcml2YXRlIGFzeW5jIHByb21wdFdpdGhPcHRpb25zKFxuICAgIHRpdGxlOiBzdHJpbmcsXG4gICAgbWVzc2FnZTogc3RyaW5nLFxuICAgIG9wdGlvbnM6IHN0cmluZ1tdXG4gICk6IFByb21pc2U8c3RyaW5nIHwgbnVsbD4ge1xuICAgIC8vIFVzZSBhIHNpbXBsZSBjb25maXJtIGRpYWxvZyBmb3Igbm93IC0gaW4gYSByZWFsIGltcGxlbWVudGF0aW9uLCB0aGlzIHdvdWxkIHVzZSBhIHByb3BlciBtb2RhbFxuICAgIGNvbnN0IGNob2ljZSA9IHByb21wdChcbiAgICAgIGAke3RpdGxlfTogJHttZXNzYWdlfVxcbk9wdGlvbnM6ICR7b3B0aW9ucy5qb2luKFwiLCBcIil9XFxuRW50ZXIgeW91ciBjaG9pY2U6YFxuICAgIClcblxuICAgIGlmICghY2hvaWNlKSByZXR1cm4gbnVsbCAvLyBVc2VyIGNhbmNlbGxlZFxuXG4gICAgY29uc3QgdHJpbW1lZENob2ljZSA9IGNob2ljZS50cmltKClcbiAgICBpZiAob3B0aW9ucy5pbmNsdWRlcyh0cmltbWVkQ2hvaWNlKSkge1xuICAgICAgcmV0dXJuIHRyaW1tZWRDaG9pY2VcbiAgICB9XG5cbiAgICBuZXcgTm90aWNlKGBQbGVhc2Ugc2VsZWN0IG9uZSBvZjogJHtvcHRpb25zLmpvaW4oXCIsIFwiKX1gKVxuICAgIHJldHVybiBhd2FpdCB0aGlzLnByb21wdFdpdGhPcHRpb25zKHRpdGxlLCBtZXNzYWdlLCBvcHRpb25zKVxuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBjcmVhdGVDb3Vyc2VGb2xkZXJTdHJ1Y3R1cmUoY291cnNlRGV0YWlsczoge1xuICAgIGNvdXJzZU5hbWU6IHN0cmluZ1xuICAgIGNvdXJzZVNlYXNvbjogc3RyaW5nXG4gICAgY291cnNlWWVhcjogc3RyaW5nXG4gICAgY291cnNlSWQ6IHN0cmluZ1xuICB9KTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgICBjb25zdCBmb2xkZXJQYXRoID0gYCR7Y291cnNlRGV0YWlscy5jb3Vyc2VZZWFyfS8ke2NvdXJzZURldGFpbHMuY291cnNlU2Vhc29ufS8ke2NvdXJzZURldGFpbHMuY291cnNlTmFtZX1gXG5cbiAgICB0cnkge1xuICAgICAgYXdhaXQgdGhpcy5hcHAudmF1bHQuY3JlYXRlRm9sZGVyKGZvbGRlclBhdGgpXG4gICAgICBjb25zb2xlLmxvZyhgQ3JlYXRlZCBjb3Vyc2UgZm9sZGVyOiAke2ZvbGRlclBhdGh9YClcbiAgICAgIHJldHVybiBmb2xkZXJQYXRoXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIC8vIEZvbGRlciBtaWdodCBhbHJlYWR5IGV4aXN0LCB3aGljaCBpcyBmaW5lIGZvciBub3dcbiAgICAgIGNvbnNvbGUubG9nKGBDb3Vyc2UgZm9sZGVyIGFscmVhZHkgZXhpc3RzIG9yIGNyZWF0ZWQ6ICR7Zm9sZGVyUGF0aH1gKVxuICAgICAgcmV0dXJuIGZvbGRlclBhdGhcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIGNyZWF0ZUNvdXJzZUhvbWVwYWdlTm90ZShcbiAgICBjb3Vyc2VEZXRhaWxzOiB7XG4gICAgICBjb3Vyc2VOYW1lOiBzdHJpbmdcbiAgICAgIGNvdXJzZVNlYXNvbjogc3RyaW5nXG4gICAgICBjb3Vyc2VZZWFyOiBzdHJpbmdcbiAgICAgIGNvdXJzZUlkOiBzdHJpbmdcbiAgICB9LFxuICAgIGZvbGRlclBhdGg6IHN0cmluZ1xuICApOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBjb25zdCBub3RlUGF0aCA9IGAke2ZvbGRlclBhdGh9LyR7Y291cnNlRGV0YWlscy5jb3Vyc2VOYW1lfS5tZGBcbiAgICBjb25zdCBjb250ZW50ID0gdGhpcy5nZW5lcmF0ZUNvdXJzZUhvbWVwYWdlQ29udGVudChjb3Vyc2VEZXRhaWxzKVxuXG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IHRoaXMuYXBwLnZhdWx0LmNyZWF0ZShub3RlUGF0aCwgY29udGVudClcbiAgICAgIGNvbnNvbGUubG9nKGBDcmVhdGVkIGNvdXJzZSBob21lcGFnZTogJHtub3RlUGF0aH1gKVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKGBFcnJvciBjcmVhdGluZyBjb3Vyc2UgaG9tZXBhZ2U6ICR7ZXJyb3J9YClcbiAgICAgIHRocm93IGVycm9yXG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBjcmVhdGVBdHRhY2htZW50c0ZvbGRlcihmb2xkZXJQYXRoOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBjb25zdCBhdHRhY2htZW50c1BhdGggPSBgJHtmb2xkZXJQYXRofS9BdHRhY2htZW50c2BcblxuICAgIHRyeSB7XG4gICAgICBhd2FpdCB0aGlzLmFwcC52YXVsdC5jcmVhdGVGb2xkZXIoYXR0YWNobWVudHNQYXRoKVxuICAgICAgY29uc29sZS5sb2coYENyZWF0ZWQgYXR0YWNobWVudHMgZm9sZGVyOiAke2F0dGFjaG1lbnRzUGF0aH1gKVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAvLyBGb2xkZXIgbWlnaHQgYWxyZWFkeSBleGlzdCwgd2hpY2ggaXMgZmluZVxuICAgICAgY29uc29sZS5sb2coYEF0dGFjaG1lbnRzIGZvbGRlciBhbHJlYWR5IGV4aXN0czogJHthdHRhY2htZW50c1BhdGh9YClcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGdlbmVyYXRlQ291cnNlSG9tZXBhZ2VDb250ZW50KGNvdXJzZURldGFpbHM6IHtcbiAgICBjb3Vyc2VOYW1lOiBzdHJpbmdcbiAgICBjb3Vyc2VTZWFzb246IHN0cmluZ1xuICAgIGNvdXJzZVllYXI6IHN0cmluZ1xuICAgIGNvdXJzZUlkOiBzdHJpbmdcbiAgfSk6IHN0cmluZyB7XG4gICAgY29uc3QgZW5oYW5jZWRNZXRhZGF0YSA9IHRoaXMuc2V0dGluZ3MudXNlRW5oYW5jZWRNZXRhZGF0YVxuXG4gICAgcmV0dXJuIGAtLS1cbiR7XG4gIGVuaGFuY2VkTWV0YWRhdGFcbiAgICA/IGBjb3Vyc2VfaWQ6ICR7Y291cnNlRGV0YWlscy5jb3Vyc2VJZH1cbmNvdXJzZV9uYW1lOiAke2NvdXJzZURldGFpbHMuY291cnNlTmFtZX1cbmNvdXJzZV90ZXJtOiAke2NvdXJzZURldGFpbHMuY291cnNlU2Vhc29ufSAke2NvdXJzZURldGFpbHMuY291cnNlWWVhcn1cbmNvdXJzZV95ZWFyOiAke2NvdXJzZURldGFpbHMuY291cnNlWWVhcn1cbmNvdXJzZV9zZW1lc3RlcjogJHtjb3Vyc2VEZXRhaWxzLmNvdXJzZVNlYXNvbn1cbmNvbnRlbnRfdHlwZTogY291cnNlX2hvbWVwYWdlXG5zY2hvb2w6ICR7dGhpcy5zZXR0aW5ncy5zY2hvb2xOYW1lfVxuc2Nob29sX2FiYnJldmlhdGlvbjogJHt0aGlzLnNldHRpbmdzLnNjaG9vbEFiYnJldmlhdGlvbn1gXG4gICAgOiBgY291cnNlX2lkOiAke2NvdXJzZURldGFpbHMuY291cnNlSWR9XG50aXRsZTogJHtjb3Vyc2VEZXRhaWxzLmNvdXJzZU5hbWV9YFxufVxuY3JlYXRlZDogJHtuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCl9XG50YWdzOlxuIC0gY291cnNlX2hvbWVcbiAtIGVkdWNhdGlvblxuIC0gJHtjb3Vyc2VEZXRhaWxzLmNvdXJzZUlkfVxuIC0gJHt0aGlzLnNldHRpbmdzLnNjaG9vbEFiYnJldmlhdGlvbn0vJHtjb3Vyc2VEZXRhaWxzLmNvdXJzZVllYXJ9LyR7XG4gICAgICBjb3Vyc2VEZXRhaWxzLmNvdXJzZVNlYXNvblxuICAgIH0vJHtjb3Vyc2VEZXRhaWxzLmNvdXJzZUlkfVxuLS0tXG5cblxuIyAke2NvdXJzZURldGFpbHMuY291cnNlTmFtZX1cblxuIyMgQ291cnNlIEluZm9ybWF0aW9uXG4qKkNvdXJzZSBJRCoqOiAke2NvdXJzZURldGFpbHMuY291cnNlSWR9XG4qKlRlcm0qKjogJHtjb3Vyc2VEZXRhaWxzLmNvdXJzZVNlYXNvbn0gJHtjb3Vyc2VEZXRhaWxzLmNvdXJzZVllYXJ9XG4qKlNjaG9vbCoqOiAke3RoaXMuc2V0dGluZ3Muc2Nob29sTmFtZX1cblxuIyMgSW5zdHJ1Y3RvclxuKipOYW1lKio6XG4qKkVtYWlsKio6XG4qKk9mZmljZSBIb3VycyoqOlxuXG4jIyBDb3Vyc2UgRGVzY3JpcHRpb25cblxuIyMgTGVhcm5pbmcgT2JqZWN0aXZlc1xuXG4jIyBSZXF1aXJlZCBUZXh0c1xuXG4jIyBTY2hlZHVsZVxuXG4jIyBBc3NpZ25tZW50c1xuXG4jIyBSZXNvdXJjZXNcblxuIyMgVm9jYWJ1bGFyeVxuXG4jIyBEdWUgRGF0ZXNgXG4gIH1cbn1cbiIsICIvLyBWb2NhYnVsYXJ5IGV4dHJhY3Rpb24gZm9yIFR1Y2tlcnMgVG9vbHMgcGx1Z2luXG5cbmltcG9ydCB7IEFwcCwgVEZpbGUgfSBmcm9tIFwib2JzaWRpYW5cIlxuaW1wb3J0IHsgZ2V0Q291cnNlSWRGcm9tUGF0aCB9IGZyb20gXCIuL3V0aWxzXCJcblxuZXhwb3J0IGNsYXNzIFZvY2FidWxhcnlFeHRyYWN0b3Ige1xuICBhcHA6IEFwcFxuXG4gIGNvbnN0cnVjdG9yKGFwcDogQXBwKSB7XG4gICAgdGhpcy5hcHAgPSBhcHBcbiAgfVxuXG4gIGV4dHJhY3RWb2NhYnVsYXJ5RnJvbU5vdGUoY29udGVudDogc3RyaW5nKTogc3RyaW5nW10ge1xuICAgIC8vIEV4dHJhY3Qgdm9jYWJ1bGFyeSBzZWN0aW9uIGZyb20gbm90ZSBjb250ZW50XG4gICAgY29uc3Qgdm9jYWJSZWdleCA9IC9eIysgVm9jYWJ1bGFyeS4qXFxuKCg/Oi4qP1xcbikqPykoPz1eXFxzKiNcXHN8JCkvbVxuICAgIGNvbnN0IHZvY2FiTWF0Y2hlcyA9IGNvbnRlbnQ/Lm1hdGNoKHZvY2FiUmVnZXgpXG5cbiAgICBpZiAodm9jYWJNYXRjaGVzKSB7XG4gICAgICBjb25zdCB2b2NhYkRhdGEgPSB2b2NhYk1hdGNoZXNbMV0udHJpbSgpXG4gICAgICBjb25zdCBjbGVhbmVkVm9jYWIgPSB2b2NhYkRhdGFcbiAgICAgICAgLnJlcGxhY2UoL1xcW1xcWy4qP1xcXVxcXS9nLCBcIlwiKSAvLyBSZW1vdmUgd2lraWxpbmtzXG4gICAgICAgIC5yZXBsYWNlKC9eXFxzKi1cXHMqL2dtLCBcIlwiKSAvLyBSZW1vdmUgYnVsbGV0IHBvaW50c1xuICAgICAgICAuc3BsaXQoXCJcXG5cIilcbiAgICAgICAgLm1hcCgodGVybSkgPT4gdGVybS50cmltKCkpXG4gICAgICAgIC5maWx0ZXIoKHRlcm0pID0+IHRlcm0ubGVuZ3RoID4gMClcblxuICAgICAgcmV0dXJuIGNsZWFuZWRWb2NhYlxuICAgIH1cblxuICAgIHJldHVybiBbXVxuICB9XG5cbiAgYXN5bmMgZXh0cmFjdFZvY2FidWxhcnlGcm9tQ291cnNlKFxuICAgIGNvdXJzZUlkOiBzdHJpbmdcbiAgKTogUHJvbWlzZTxSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT4+IHtcbiAgICBjb25zb2xlLmxvZyhgRXh0cmFjdGluZyB2b2NhYnVsYXJ5IGZvciBjb3Vyc2U6ICR7Y291cnNlSWR9YClcblxuICAgIHRyeSB7XG4gICAgICAvLyBGaW5kIGFsbCBub3RlcyByZWxhdGVkIHRvIHRoZSBjb3Vyc2VcbiAgICAgIGNvbnN0IGNvdXJzZU5vdGVzID0gYXdhaXQgdGhpcy5maW5kQ291cnNlTm90ZXMoY291cnNlSWQpXG5cbiAgICAgIGlmIChjb3Vyc2VOb3Rlcy5sZW5ndGggPT09IDApIHtcbiAgICAgICAgY29uc29sZS5sb2coYE5vIG5vdGVzIGZvdW5kIGZvciBjb3Vyc2U6ICR7Y291cnNlSWR9YClcbiAgICAgICAgcmV0dXJuIHt9XG4gICAgICB9XG5cbiAgICAgIC8vIEV4dHJhY3Qgdm9jYWJ1bGFyeSBmcm9tIGVhY2ggbm90ZVxuICAgICAgY29uc3Qgdm9jYWJ1bGFyeURhdGE6IFJlY29yZDxzdHJpbmcsIHN0cmluZ1tdPiA9IHt9XG5cbiAgICAgIGZvciAoY29uc3Qgbm90ZSBvZiBjb3Vyc2VOb3Rlcykge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGNvbnN0IGNvbnRlbnQgPSBhd2FpdCB0aGlzLmFwcC52YXVsdC5yZWFkKG5vdGUpXG4gICAgICAgICAgY29uc3Qgdm9jYWJ1bGFyeSA9IHRoaXMuZXh0cmFjdFZvY2FidWxhcnlGcm9tTm90ZShjb250ZW50KVxuXG4gICAgICAgICAgaWYgKHZvY2FidWxhcnkubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgdm9jYWJ1bGFyeURhdGFbbm90ZS5iYXNlbmFtZV0gPSB2b2NhYnVsYXJ5XG4gICAgICAgICAgfVxuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIHJlYWRpbmcgbm90ZSAke25vdGUucGF0aH06YCwgZXJyb3IpXG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgY29uc29sZS5sb2coXG4gICAgICAgIGBFeHRyYWN0ZWQgdm9jYWJ1bGFyeSBmcm9tICR7XG4gICAgICAgICAgT2JqZWN0LmtleXModm9jYWJ1bGFyeURhdGEpLmxlbmd0aFxuICAgICAgICB9IG5vdGVzIGZvciBjb3Vyc2U6ICR7Y291cnNlSWR9YFxuICAgICAgKVxuICAgICAgcmV0dXJuIHZvY2FidWxhcnlEYXRhXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXG4gICAgICAgIGBFcnJvciBleHRyYWN0aW5nIHZvY2FidWxhcnkgZm9yIGNvdXJzZSAke2NvdXJzZUlkfTpgLFxuICAgICAgICBlcnJvclxuICAgICAgKVxuICAgICAgcmV0dXJuIHt9XG4gICAgfVxuICB9XG5cbiAgYXN5bmMgZmluZENvdXJzZU5vdGVzKGNvdXJzZUlkOiBzdHJpbmcpOiBQcm9taXNlPFRGaWxlW10+IHtcbiAgICBjb25zdCBub3RlczogVEZpbGVbXSA9IFtdXG5cbiAgICAvLyBHZXQgYWxsIG1hcmtkb3duIGZpbGVzIGluIHRoZSB2YXVsdFxuICAgIGNvbnN0IGZpbGVzID0gdGhpcy5hcHAudmF1bHQuZ2V0TWFya2Rvd25GaWxlcygpXG5cbiAgICBmb3IgKGNvbnN0IGZpbGUgb2YgZmlsZXMpIHtcbiAgICAgIC8vIENoZWNrIGlmIHRoZSBmaWxlIHBhdGggY29udGFpbnMgdGhlIGNvdXJzZSBJRFxuICAgICAgaWYgKFxuICAgICAgICBmaWxlLnBhdGguaW5jbHVkZXMoY291cnNlSWQpIHx8XG4gICAgICAgIChhd2FpdCB0aGlzLm5vdGVCZWxvbmdzVG9Db3Vyc2UoZmlsZSwgY291cnNlSWQpKVxuICAgICAgKSB7XG4gICAgICAgIG5vdGVzLnB1c2goZmlsZSlcbiAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gbm90ZXNcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgbm90ZUJlbG9uZ3NUb0NvdXJzZShcbiAgICBmaWxlOiBURmlsZSxcbiAgICBjb3Vyc2VJZDogc3RyaW5nXG4gICk6IFByb21pc2U8Ym9vbGVhbj4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBjb250ZW50ID0gYXdhaXQgdGhpcy5hcHAudmF1bHQucmVhZChmaWxlKVxuICAgICAgY29uc3QgZnJvbnRtYXR0ZXJNYXRjaCA9IGNvbnRlbnQubWF0Y2goL14tLS1cXG4oW1xcc1xcU10qPylcXG4tLS0vKVxuXG4gICAgICBpZiAoZnJvbnRtYXR0ZXJNYXRjaCkge1xuICAgICAgICBjb25zdCBmcm9udG1hdHRlciA9IGZyb250bWF0dGVyTWF0Y2hbMV1cbiAgICAgICAgLy8gQ2hlY2sgaWYgY291cnNlX2lkIGlzIGluIHRoZSBmcm9udG1hdHRlclxuICAgICAgICByZXR1cm4gKFxuICAgICAgICAgIGZyb250bWF0dGVyLmluY2x1ZGVzKGBjb3Vyc2VfaWQ6ICR7Y291cnNlSWR9YCkgfHxcbiAgICAgICAgICBmcm9udG1hdHRlci5pbmNsdWRlcyhgY291cnNlX2lkOiR7Y291cnNlSWR9YClcbiAgICAgICAgKVxuICAgICAgfVxuXG4gICAgICByZXR1cm4gZmFsc2VcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihcbiAgICAgICAgYEVycm9yIGNoZWNraW5nIGlmIG5vdGUgJHtmaWxlLnBhdGh9IGJlbG9uZ3MgdG8gY291cnNlICR7Y291cnNlSWR9OmAsXG4gICAgICAgIGVycm9yXG4gICAgICApXG4gICAgICByZXR1cm4gZmFsc2VcbiAgICB9XG4gIH1cblxuICBhc3luYyBnZW5lcmF0ZVZvY2FidWxhcnlJbmRleChcbiAgICBjb3Vyc2VJZDogc3RyaW5nLFxuICAgIHZvY2FidWxhcnlEYXRhOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT5cbiAgKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgICBjb25zdCBhbGxUZXJtczogc3RyaW5nW10gPSBbXVxuICAgIGNvbnN0IHRlcm1Tb3VyY2VzOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT4gPSB7fVxuXG4gICAgLy8gQ29sbGVjdCBhbGwgdW5pcXVlIHRlcm1zIGFuZCB0aGVpciBzb3VyY2VzXG4gICAgZm9yIChjb25zdCBbbm90ZU5hbWUsIHRlcm1zXSBvZiBPYmplY3QuZW50cmllcyh2b2NhYnVsYXJ5RGF0YSkpIHtcbiAgICAgIGZvciAoY29uc3QgdGVybSBvZiB0ZXJtcykge1xuICAgICAgICBpZiAoIWFsbFRlcm1zLmluY2x1ZGVzKHRlcm0pKSB7XG4gICAgICAgICAgYWxsVGVybXMucHVzaCh0ZXJtKVxuICAgICAgICAgIHRlcm1Tb3VyY2VzW3Rlcm1dID0gW11cbiAgICAgICAgfVxuICAgICAgICB0ZXJtU291cmNlc1t0ZXJtXS5wdXNoKG5vdGVOYW1lKVxuICAgICAgfVxuICAgIH1cblxuICAgIC8vIFNvcnQgdGVybXMgYWxwaGFiZXRpY2FsbHlcbiAgICBhbGxUZXJtcy5zb3J0KClcblxuICAgIC8vIEdlbmVyYXRlIG1hcmtkb3duIGNvbnRlbnRcbiAgICBsZXQgY29udGVudCA9IGAjIFZvY2FidWxhcnkgSW5kZXggLSAke2NvdXJzZUlkfVxcblxcbmBcbiAgICBjb250ZW50ICs9IGBUb3RhbCB1bmlxdWUgdGVybXM6ICR7YWxsVGVybXMubGVuZ3RofVxcblxcbmBcblxuICAgIGZvciAoY29uc3QgdGVybSBvZiBhbGxUZXJtcykge1xuICAgICAgY29udGVudCArPSBgIyMgJHt0ZXJtfVxcbmBcbiAgICAgIGNvbnRlbnQgKz0gYCoqU291cmNlczoqKiAke3Rlcm1Tb3VyY2VzW3Rlcm1dLmpvaW4oXCIsIFwiKX1cXG5cXG5gXG4gICAgICBjb250ZW50ICs9IGAqKkRlZmluaXRpb246KipcXG5cXG5gXG4gICAgICBjb250ZW50ICs9IGAqKkNvbnRleHQ6KipcXG5cXG5gXG4gICAgICBjb250ZW50ICs9IGAqKkV4YW1wbGVzOioqXFxuXFxuYFxuICAgICAgY29udGVudCArPSBgLS0tXFxuXFxuYFxuICAgIH1cblxuICAgIHJldHVybiBjb250ZW50XG4gIH1cblxuICBhc3luYyBjcmVhdGVWb2NhYnVsYXJ5SW5kZXhGaWxlKGNvdXJzZUlkOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3Qgdm9jYWJ1bGFyeURhdGEgPSBhd2FpdCB0aGlzLmV4dHJhY3RWb2NhYnVsYXJ5RnJvbUNvdXJzZShjb3Vyc2VJZClcblxuICAgICAgaWYgKE9iamVjdC5rZXlzKHZvY2FidWxhcnlEYXRhKS5sZW5ndGggPT09IDApIHtcbiAgICAgICAgY29uc29sZS5sb2coYE5vIHZvY2FidWxhcnkgZm91bmQgZm9yIGNvdXJzZTogJHtjb3Vyc2VJZH1gKVxuICAgICAgICByZXR1cm5cbiAgICAgIH1cblxuICAgICAgY29uc3QgaW5kZXhDb250ZW50ID0gYXdhaXQgdGhpcy5nZW5lcmF0ZVZvY2FidWxhcnlJbmRleChcbiAgICAgICAgY291cnNlSWQsXG4gICAgICAgIHZvY2FidWxhcnlEYXRhXG4gICAgICApXG5cbiAgICAgIC8vIENyZWF0ZSB0aGUgaW5kZXggZmlsZVxuICAgICAgY29uc3QgZmlsZU5hbWUgPSBgJHtjb3Vyc2VJZH0gLSBWb2NhYnVsYXJ5IEluZGV4Lm1kYFxuICAgICAgY29uc3QgZmlsZVBhdGggPSBgQ291cnNlcy8ke2NvdXJzZUlkfS8ke2ZpbGVOYW1lfWBcblxuICAgICAgdHJ5IHtcbiAgICAgICAgYXdhaXQgdGhpcy5hcHAudmF1bHQuY3JlYXRlKGZpbGVQYXRoLCBpbmRleENvbnRlbnQpXG4gICAgICAgIGNvbnNvbGUubG9nKGBDcmVhdGVkIHZvY2FidWxhcnkgaW5kZXggZmlsZTogJHtmaWxlUGF0aH1gKVxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgLy8gRmlsZSBtaWdodCBhbHJlYWR5IGV4aXN0LCB0cnkgdG8gdXBkYXRlIGl0XG4gICAgICAgIGNvbnN0IGV4aXN0aW5nRmlsZSA9IHRoaXMuYXBwLnZhdWx0LmdldEFic3RyYWN0RmlsZUJ5UGF0aChmaWxlUGF0aClcbiAgICAgICAgaWYgKGV4aXN0aW5nRmlsZSAmJiBleGlzdGluZ0ZpbGUgaW5zdGFuY2VvZiBURmlsZSkge1xuICAgICAgICAgIGF3YWl0IHRoaXMuYXBwLnZhdWx0Lm1vZGlmeShleGlzdGluZ0ZpbGUsIGluZGV4Q29udGVudClcbiAgICAgICAgICBjb25zb2xlLmxvZyhgVXBkYXRlZCB2b2NhYnVsYXJ5IGluZGV4IGZpbGU6ICR7ZmlsZVBhdGh9YClcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFxuICAgICAgICBgRXJyb3IgY3JlYXRpbmcgdm9jYWJ1bGFyeSBpbmRleCBmb3IgY291cnNlICR7Y291cnNlSWR9OmAsXG4gICAgICAgIGVycm9yXG4gICAgICApXG4gICAgICB0aHJvdyBlcnJvclxuICAgIH1cbiAgfVxufVxuIiwgImltcG9ydCB7IEFwcCwgVEZpbGUgfSBmcm9tIFwib2JzaWRpYW5cIlxuaW1wb3J0IHsgaXNCZXR3ZWVuIH0gZnJvbSBcIi4vdXRpbHNcIlxuXG5leHBvcnQgY2xhc3MgRHVlRGF0ZXNQYXJzZXIge1xuICBhcHA6IEFwcFxuXG4gIGNvbnN0cnVjdG9yKGFwcDogQXBwKSB7XG4gICAgdGhpcy5hcHAgPSBhcHBcbiAgfVxuXG4gIHBhcnNlRHVlRGF0ZXNGcm9tTm90ZShcbiAgICBjb250ZW50OiBzdHJpbmdcbiAgKTogQXJyYXk8eyBkYXRlOiBzdHJpbmc7IGFzc2lnbm1lbnQ6IHN0cmluZzsgc3RhdHVzOiBzdHJpbmcgfT4ge1xuICAgIC8vIEV4dHJhY3QgZHVlIGRhdGVzIHNlY3Rpb24gZnJvbSBub3RlIGNvbnRlbnRcbiAgICBjb25zdCBkdWVEYXRlc1JlZ2V4ID0gLyMgRHVlIERhdGVzW1xcc1xcU10qPyg/PVxcbiN8JCkvXG4gICAgY29uc3QgbWF0Y2hlcyA9IGNvbnRlbnQ/Lm1hdGNoKGR1ZURhdGVzUmVnZXgpXG5cbiAgICBpZiAoIW1hdGNoZXMpIHtcbiAgICAgIHJldHVybiBbXVxuICAgIH1cblxuICAgIGNvbnN0IGR1ZURhdGVzU2VjdGlvbiA9IG1hdGNoZXNbMF1cbiAgICBjb25zdCBkdWVEYXRlcyA9IFtdXG5cbiAgICAvLyBMb29rIGZvciBtYXJrZG93biB0YWJsZXMgaW4gdGhlIGR1ZSBkYXRlcyBzZWN0aW9uXG4gICAgY29uc3QgdGFibGVSZWdleCA9IC9cXHxbXFxzXFxTXSo/XFxuL2dcbiAgICBjb25zdCB0YWJsZU1hdGNoZXMgPSBkdWVEYXRlc1NlY3Rpb24ubWF0Y2godGFibGVSZWdleClcblxuICAgIGlmICh0YWJsZU1hdGNoZXMpIHtcbiAgICAgIGZvciAoY29uc3QgdGFibGUgb2YgdGFibGVNYXRjaGVzKSB7XG4gICAgICAgIGNvbnN0IHJvd3MgPSB0YWJsZVxuICAgICAgICAgIC50cmltKClcbiAgICAgICAgICAuc3BsaXQoXCJcXG5cIilcbiAgICAgICAgICAuZmlsdGVyKChyb3cpID0+IHJvdy5zdGFydHNXaXRoKFwifFwiKSlcbiAgICAgICAgY29uc3QgcGFyc2VkUm93cyA9IHRoaXMucGFyc2VUYWJsZVJvd3Mocm93cylcbiAgICAgICAgZHVlRGF0ZXMucHVzaCguLi5wYXJzZWRSb3dzKVxuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBkdWVEYXRlc1xuICB9XG5cbiAgcHJpdmF0ZSBwYXJzZVRhYmxlUm93cyhcbiAgICByb3dzOiBzdHJpbmdbXVxuICApOiBBcnJheTx7IGRhdGU6IHN0cmluZzsgYXNzaWdubWVudDogc3RyaW5nOyBzdGF0dXM6IHN0cmluZyB9PiB7XG4gICAgaWYgKHJvd3MubGVuZ3RoIDwgMikgcmV0dXJuIFtdIC8vIE5lZWQgYXQgbGVhc3QgaGVhZGVyICsgMSBkYXRhIHJvd1xuXG4gICAgY29uc3QgZHVlRGF0ZXMgPSBbXVxuXG4gICAgZm9yIChsZXQgaSA9IDE7IGkgPCByb3dzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAvLyBTa2lwIGhlYWRlciByb3dcbiAgICAgIGNvbnN0IHJvdyA9IHJvd3NbaV1cbiAgICAgIGNvbnN0IGNvbHVtbnMgPSByb3dcbiAgICAgICAgLnNwbGl0KFwifFwiKVxuICAgICAgICAubWFwKChjb2wpID0+IGNvbC50cmltKCkpXG4gICAgICAgIC5maWx0ZXIoKGNvbCkgPT4gY29sKVxuXG4gICAgICBpZiAoY29sdW1ucy5sZW5ndGggPj0gMikge1xuICAgICAgICBjb25zdCBbZGF0ZSwgYXNzaWdubWVudCwgc3RhdHVzID0gXCJwZW5kaW5nXCJdID0gY29sdW1uc1xuICAgICAgICBpZiAoZGF0ZSAmJiBhc3NpZ25tZW50ICYmIHRoaXMuaXNWYWxpZERhdGUoZGF0ZSkpIHtcbiAgICAgICAgICBkdWVEYXRlcy5wdXNoKHsgZGF0ZSwgYXNzaWdubWVudCwgc3RhdHVzIH0pXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gZHVlRGF0ZXNcbiAgfVxuXG4gIHByaXZhdGUgaXNWYWxpZERhdGUoZGF0ZVN0cmluZzogc3RyaW5nKTogYm9vbGVhbiB7XG4gICAgY29uc3QgZGF0ZVJlZ2V4ID0gL15cXGR7NH0tXFxkezJ9LVxcZHsyfSQvXG4gICAgcmV0dXJuIGRhdGVSZWdleC50ZXN0KGRhdGVTdHJpbmcpICYmICFpc05hTihEYXRlLnBhcnNlKGRhdGVTdHJpbmcpKVxuICB9XG5cbiAgYXN5bmMgcGFyc2VEdWVEYXRlc0Zyb21Db3Vyc2UoXG4gICAgY291cnNlSWQ6IHN0cmluZyxcbiAgICBzdGFydERhdGU/OiBzdHJpbmcsXG4gICAgZW5kRGF0ZT86IHN0cmluZ1xuICApOiBQcm9taXNlPFxuICAgIEFycmF5PHsgZGF0ZTogc3RyaW5nOyBhc3NpZ25tZW50OiBzdHJpbmc7IHN0YXR1czogc3RyaW5nOyBzb3VyY2U6IHN0cmluZyB9PlxuICA+IHtcbiAgICBjb25zb2xlLmxvZyhgUGFyc2luZyBkdWUgZGF0ZXMgZm9yIGNvdXJzZTogJHtjb3Vyc2VJZH1gKVxuXG4gICAgdHJ5IHtcbiAgICAgIC8vIEZpbmQgYWxsIG5vdGVzIHJlbGF0ZWQgdG8gdGhlIGNvdXJzZVxuICAgICAgY29uc3QgY291cnNlTm90ZXMgPSBhd2FpdCB0aGlzLmZpbmRDb3Vyc2VOb3Rlcyhjb3Vyc2VJZClcblxuICAgICAgaWYgKGNvdXJzZU5vdGVzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICBjb25zb2xlLmxvZyhgTm8gbm90ZXMgZm91bmQgZm9yIGNvdXJzZTogJHtjb3Vyc2VJZH1gKVxuICAgICAgICByZXR1cm4gW11cbiAgICAgIH1cblxuICAgICAgLy8gUGFyc2UgZHVlIGRhdGVzIGZyb20gZWFjaCBub3RlXG4gICAgICBjb25zdCBhbGxEdWVEYXRlczogQXJyYXk8e1xuICAgICAgICBkYXRlOiBzdHJpbmdcbiAgICAgICAgYXNzaWdubWVudDogc3RyaW5nXG4gICAgICAgIHN0YXR1czogc3RyaW5nXG4gICAgICAgIHNvdXJjZTogc3RyaW5nXG4gICAgICB9PiA9IFtdXG5cbiAgICAgIGZvciAoY29uc3Qgbm90ZSBvZiBjb3Vyc2VOb3Rlcykge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGNvbnN0IGNvbnRlbnQgPSBhd2FpdCB0aGlzLmFwcC52YXVsdC5yZWFkKG5vdGUpXG4gICAgICAgICAgY29uc3QgZHVlRGF0ZXMgPSB0aGlzLnBhcnNlRHVlRGF0ZXNGcm9tTm90ZShjb250ZW50KVxuXG4gICAgICAgICAgLy8gQWRkIHNvdXJjZSBpbmZvcm1hdGlvblxuICAgICAgICAgIGNvbnN0IGR1ZURhdGVzV2l0aFNvdXJjZSA9IGR1ZURhdGVzLm1hcCgoZHVlRGF0ZSkgPT4gKHtcbiAgICAgICAgICAgIC4uLmR1ZURhdGUsXG4gICAgICAgICAgICBzb3VyY2U6IG5vdGUuYmFzZW5hbWVcbiAgICAgICAgICB9KSlcblxuICAgICAgICAgIGFsbER1ZURhdGVzLnB1c2goLi4uZHVlRGF0ZXNXaXRoU291cmNlKVxuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIHJlYWRpbmcgbm90ZSAke25vdGUucGF0aH06YCwgZXJyb3IpXG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgLy8gRmlsdGVyIGJ5IGRhdGUgcmFuZ2UgaWYgcHJvdmlkZWRcbiAgICAgIGxldCBmaWx0ZXJlZER1ZURhdGVzID0gYWxsRHVlRGF0ZXNcbiAgICAgIGlmIChzdGFydERhdGUgfHwgZW5kRGF0ZSkge1xuICAgICAgICBmaWx0ZXJlZER1ZURhdGVzID0gdGhpcy5maWx0ZXJCeURhdGVSYW5nZShcbiAgICAgICAgICBhbGxEdWVEYXRlcyxcbiAgICAgICAgICBzdGFydERhdGUsXG4gICAgICAgICAgZW5kRGF0ZVxuICAgICAgICApXG4gICAgICB9XG5cbiAgICAgIC8vIFNvcnQgYnkgZGF0ZVxuICAgICAgZmlsdGVyZWREdWVEYXRlcy5zb3J0KFxuICAgICAgICAoYSwgYikgPT4gbmV3IERhdGUoYS5kYXRlKS5nZXRUaW1lKCkgLSBuZXcgRGF0ZShiLmRhdGUpLmdldFRpbWUoKVxuICAgICAgKVxuXG4gICAgICBjb25zb2xlLmxvZyhcbiAgICAgICAgYEZvdW5kICR7ZmlsdGVyZWREdWVEYXRlcy5sZW5ndGh9IGR1ZSBkYXRlcyBmb3IgY291cnNlOiAke2NvdXJzZUlkfWBcbiAgICAgIClcbiAgICAgIHJldHVybiBmaWx0ZXJlZER1ZURhdGVzXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIHBhcnNpbmcgZHVlIGRhdGVzIGZvciBjb3Vyc2UgJHtjb3Vyc2VJZH06YCwgZXJyb3IpXG4gICAgICByZXR1cm4gW11cbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIGZpbmRDb3Vyc2VOb3Rlcyhjb3Vyc2VJZDogc3RyaW5nKTogUHJvbWlzZTxURmlsZVtdPiB7XG4gICAgY29uc3Qgbm90ZXM6IFRGaWxlW10gPSBbXVxuXG4gICAgLy8gR2V0IGFsbCBtYXJrZG93biBmaWxlcyBpbiB0aGUgdmF1bHRcbiAgICBjb25zdCBmaWxlcyA9IHRoaXMuYXBwLnZhdWx0LmdldE1hcmtkb3duRmlsZXMoKVxuXG4gICAgZm9yIChjb25zdCBmaWxlIG9mIGZpbGVzKSB7XG4gICAgICAvLyBDaGVjayBpZiB0aGUgZmlsZSBwYXRoIGNvbnRhaW5zIHRoZSBjb3Vyc2UgSUQgb3IgYmVsb25ncyB0byB0aGUgY291cnNlXG4gICAgICBpZiAoXG4gICAgICAgIGZpbGUucGF0aC5pbmNsdWRlcyhjb3Vyc2VJZCkgfHxcbiAgICAgICAgKGF3YWl0IHRoaXMubm90ZUJlbG9uZ3NUb0NvdXJzZShmaWxlLCBjb3Vyc2VJZCkpXG4gICAgICApIHtcbiAgICAgICAgbm90ZXMucHVzaChmaWxlKVxuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBub3Rlc1xuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBub3RlQmVsb25nc1RvQ291cnNlKFxuICAgIGZpbGU6IFRGaWxlLFxuICAgIGNvdXJzZUlkOiBzdHJpbmdcbiAgKTogUHJvbWlzZTxib29sZWFuPiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGNvbnRlbnQgPSBhd2FpdCB0aGlzLmFwcC52YXVsdC5yZWFkKGZpbGUpXG4gICAgICBjb25zdCBmcm9udG1hdHRlck1hdGNoID0gY29udGVudC5tYXRjaCgvXi0tLVxcbihbXFxzXFxTXSo/KVxcbi0tLS8pXG5cbiAgICAgIGlmIChmcm9udG1hdHRlck1hdGNoKSB7XG4gICAgICAgIGNvbnN0IGZyb250bWF0dGVyID0gZnJvbnRtYXR0ZXJNYXRjaFsxXVxuICAgICAgICAvLyBDaGVjayBpZiBjb3Vyc2VfaWQgaXMgaW4gdGhlIGZyb250bWF0dGVyXG4gICAgICAgIHJldHVybiAoXG4gICAgICAgICAgZnJvbnRtYXR0ZXIuaW5jbHVkZXMoYGNvdXJzZV9pZDogJHtjb3Vyc2VJZH1gKSB8fFxuICAgICAgICAgIGZyb250bWF0dGVyLmluY2x1ZGVzKGBjb3Vyc2VfaWQ6JHtjb3Vyc2VJZH1gKVxuICAgICAgICApXG4gICAgICB9XG5cbiAgICAgIHJldHVybiBmYWxzZVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFxuICAgICAgICBgRXJyb3IgY2hlY2tpbmcgaWYgbm90ZSAke2ZpbGUucGF0aH0gYmVsb25ncyB0byBjb3Vyc2UgJHtjb3Vyc2VJZH06YCxcbiAgICAgICAgZXJyb3JcbiAgICAgIClcbiAgICAgIHJldHVybiBmYWxzZVxuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgZmlsdGVyQnlEYXRlUmFuZ2UoXG4gICAgZHVlRGF0ZXM6IEFycmF5PHtcbiAgICAgIGRhdGU6IHN0cmluZ1xuICAgICAgYXNzaWdubWVudDogc3RyaW5nXG4gICAgICBzdGF0dXM6IHN0cmluZ1xuICAgICAgc291cmNlOiBzdHJpbmdcbiAgICB9PixcbiAgICBzdGFydERhdGU/OiBzdHJpbmcsXG4gICAgZW5kRGF0ZT86IHN0cmluZ1xuICApOiBBcnJheTx7XG4gICAgZGF0ZTogc3RyaW5nXG4gICAgYXNzaWdubWVudDogc3RyaW5nXG4gICAgc3RhdHVzOiBzdHJpbmdcbiAgICBzb3VyY2U6IHN0cmluZ1xuICB9PiB7XG4gICAgcmV0dXJuIGR1ZURhdGVzLmZpbHRlcigoZHVlRGF0ZSkgPT4ge1xuICAgICAgY29uc3QgZHVlRGF0ZVRpbWUgPSBuZXcgRGF0ZShkdWVEYXRlLmRhdGUpLmdldFRpbWUoKVxuXG4gICAgICBpZiAoc3RhcnREYXRlICYmIGR1ZURhdGVUaW1lIDwgbmV3IERhdGUoc3RhcnREYXRlKS5nZXRUaW1lKCkpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlXG4gICAgICB9XG5cbiAgICAgIGlmIChlbmREYXRlICYmIGR1ZURhdGVUaW1lID4gbmV3IERhdGUoZW5kRGF0ZSkuZ2V0VGltZSgpKSB7XG4gICAgICAgIHJldHVybiBmYWxzZVxuICAgICAgfVxuXG4gICAgICByZXR1cm4gdHJ1ZVxuICAgIH0pXG4gIH1cblxuICBhc3luYyBnZW5lcmF0ZUR1ZURhdGVzU3VtbWFyeShcbiAgICBjb3Vyc2VJZDogc3RyaW5nLFxuICAgIGR1ZURhdGVzOiBBcnJheTx7XG4gICAgICBkYXRlOiBzdHJpbmdcbiAgICAgIGFzc2lnbm1lbnQ6IHN0cmluZ1xuICAgICAgc3RhdHVzOiBzdHJpbmdcbiAgICAgIHNvdXJjZTogc3RyaW5nXG4gICAgfT5cbiAgKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgICBpZiAoZHVlRGF0ZXMubGVuZ3RoID09PSAwKSB7XG4gICAgICByZXR1cm4gYCMgRHVlIERhdGVzIFN1bW1hcnkgLSAke2NvdXJzZUlkfVxcblxcbk5vIGR1ZSBkYXRlcyBmb3VuZC5cXG5gXG4gICAgfVxuXG4gICAgLy8gR3JvdXAgYnkgc3RhdHVzXG4gICAgY29uc3QgYnlTdGF0dXMgPSBkdWVEYXRlcy5yZWR1Y2UoKGFjYywgZHVlRGF0ZSkgPT4ge1xuICAgICAgaWYgKCFhY2NbZHVlRGF0ZS5zdGF0dXNdKSB7XG4gICAgICAgIGFjY1tkdWVEYXRlLnN0YXR1c10gPSBbXVxuICAgICAgfVxuICAgICAgYWNjW2R1ZURhdGUuc3RhdHVzXS5wdXNoKGR1ZURhdGUpXG4gICAgICByZXR1cm4gYWNjXG4gICAgfSwge30gYXMgUmVjb3JkPHN0cmluZywgdHlwZW9mIGR1ZURhdGVzPilcblxuICAgIGxldCBjb250ZW50ID0gYCMgRHVlIERhdGVzIFN1bW1hcnkgLSAke2NvdXJzZUlkfVxcblxcbmBcbiAgICBjb250ZW50ICs9IGBUb3RhbCBhc3NpZ25tZW50czogJHtkdWVEYXRlcy5sZW5ndGh9XFxuXFxuYFxuXG4gICAgLy8gQWRkIHN1bW1hcnkgYnkgc3RhdHVzXG4gICAgZm9yIChjb25zdCBbc3RhdHVzLCBpdGVtc10gb2YgT2JqZWN0LmVudHJpZXMoYnlTdGF0dXMpKSB7XG4gICAgICBjb250ZW50ICs9IGAjIyAke3N0YXR1cy5jaGFyQXQoMCkudG9VcHBlckNhc2UoKSArIHN0YXR1cy5zbGljZSgxKX0gKCR7XG4gICAgICAgIGl0ZW1zLmxlbmd0aFxuICAgICAgfSlcXG5cXG5gXG4gICAgICBjb250ZW50ICs9IGB8IERhdGUgfCBBc3NpZ25tZW50IHwgU291cmNlIHxcXG5gXG4gICAgICBjb250ZW50ICs9IGB8IC0tLS0gfCAtLS0tLS0tLS0tIHwgLS0tLS0tIHxcXG5gXG5cbiAgICAgIGZvciAoY29uc3QgaXRlbSBvZiBpdGVtcykge1xuICAgICAgICBjb250ZW50ICs9IGB8ICR7aXRlbS5kYXRlfSB8ICR7aXRlbS5hc3NpZ25tZW50fSB8ICR7aXRlbS5zb3VyY2V9IHxcXG5gXG4gICAgICB9XG4gICAgICBjb250ZW50ICs9IGBcXG5gXG4gICAgfVxuXG4gICAgcmV0dXJuIGNvbnRlbnRcbiAgfVxuXG4gIGFzeW5jIGNyZWF0ZUR1ZURhdGVzU3VtbWFyeUZpbGUoXG4gICAgY291cnNlSWQ6IHN0cmluZyxcbiAgICBzdGFydERhdGU/OiBzdHJpbmcsXG4gICAgZW5kRGF0ZT86IHN0cmluZ1xuICApOiBQcm9taXNlPHZvaWQ+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgZHVlRGF0ZXMgPSBhd2FpdCB0aGlzLnBhcnNlRHVlRGF0ZXNGcm9tQ291cnNlKFxuICAgICAgICBjb3Vyc2VJZCxcbiAgICAgICAgc3RhcnREYXRlLFxuICAgICAgICBlbmREYXRlXG4gICAgICApXG5cbiAgICAgIGNvbnN0IHN1bW1hcnlDb250ZW50ID0gYXdhaXQgdGhpcy5nZW5lcmF0ZUR1ZURhdGVzU3VtbWFyeShcbiAgICAgICAgY291cnNlSWQsXG4gICAgICAgIGR1ZURhdGVzXG4gICAgICApXG5cbiAgICAgIC8vIENyZWF0ZSB0aGUgc3VtbWFyeSBmaWxlXG4gICAgICBjb25zdCBmaWxlTmFtZSA9IGAke2NvdXJzZUlkfSAtIER1ZSBEYXRlcyBTdW1tYXJ5Lm1kYFxuICAgICAgY29uc3QgZmlsZVBhdGggPSBgQ291cnNlcy8ke2NvdXJzZUlkfS8ke2ZpbGVOYW1lfWBcblxuICAgICAgdHJ5IHtcbiAgICAgICAgYXdhaXQgdGhpcy5hcHAudmF1bHQuY3JlYXRlKGZpbGVQYXRoLCBzdW1tYXJ5Q29udGVudClcbiAgICAgICAgY29uc29sZS5sb2coYENyZWF0ZWQgZHVlIGRhdGVzIHN1bW1hcnkgZmlsZTogJHtmaWxlUGF0aH1gKVxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgLy8gRmlsZSBtaWdodCBhbHJlYWR5IGV4aXN0LCB0cnkgdG8gdXBkYXRlIGl0XG4gICAgICAgIGNvbnN0IGV4aXN0aW5nRmlsZSA9IHRoaXMuYXBwLnZhdWx0LmdldEFic3RyYWN0RmlsZUJ5UGF0aChmaWxlUGF0aClcbiAgICAgICAgaWYgKGV4aXN0aW5nRmlsZSAmJiBleGlzdGluZ0ZpbGUgaW5zdGFuY2VvZiBURmlsZSkge1xuICAgICAgICAgIGF3YWl0IHRoaXMuYXBwLnZhdWx0Lm1vZGlmeShleGlzdGluZ0ZpbGUsIHN1bW1hcnlDb250ZW50KVxuICAgICAgICAgIGNvbnNvbGUubG9nKGBVcGRhdGVkIGR1ZSBkYXRlcyBzdW1tYXJ5IGZpbGU6ICR7ZmlsZVBhdGh9YClcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFxuICAgICAgICBgRXJyb3IgY3JlYXRpbmcgZHVlIGRhdGVzIHN1bW1hcnkgZm9yIGNvdXJzZSAke2NvdXJzZUlkfTpgLFxuICAgICAgICBlcnJvclxuICAgICAgKVxuICAgICAgdGhyb3cgZXJyb3JcbiAgICB9XG4gIH1cbn1cbiIsICIvLyBEYWlseSBub3RlcyBpbnRlZ3JhdGlvbiBmb3IgVHVja2VycyBUb29scyBwbHVnaW5cblxuaW1wb3J0IHsgQXBwLCBURmlsZSB9IGZyb20gXCJvYnNpZGlhblwiXG5cbmV4cG9ydCBjbGFzcyBEYWlseU5vdGVzSW50ZWdyYXRpb24ge1xuICBhcHA6IEFwcFxuXG4gIGNvbnN0cnVjdG9yKGFwcDogQXBwKSB7XG4gICAgdGhpcy5hcHAgPSBhcHBcbiAgfVxuXG4gIGFzeW5jIGdldFRvZGF5c0FjdGl2aXRpZXMoKTogUHJvbWlzZTxcbiAgICBBcnJheTx7IGZpbGU6IHN0cmluZzsgdHlwZTogc3RyaW5nOyBjb3Vyc2U/OiBzdHJpbmcgfT5cbiAgPiB7XG4gICAgY29uc29sZS5sb2coXCJHZXR0aW5nIHRvZGF5J3MgYWNhZGVtaWMgYWN0aXZpdGllc1wiKVxuXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHRvZGF5ID0gbmV3IERhdGUoKVxuICAgICAgY29uc3QgdG9kYXlTdHJpbmcgPSB0b2RheS50b0lTT1N0cmluZygpLnNwbGl0KFwiVFwiKVswXVxuXG4gICAgICAvLyBGaW5kIGZpbGVzIGNyZWF0ZWQgb3IgbW9kaWZpZWQgdG9kYXlcbiAgICAgIGNvbnN0IGZpbGVzID0gdGhpcy5hcHAudmF1bHQuZ2V0TWFya2Rvd25GaWxlcygpXG4gICAgICBjb25zdCB0b2RheXNGaWxlczogVEZpbGVbXSA9IFtdXG5cbiAgICAgIGZvciAoY29uc3QgZmlsZSBvZiBmaWxlcykge1xuICAgICAgICBjb25zdCBmaWxlRGF0ZSA9IHRoaXMuZXh0cmFjdERhdGVGcm9tUGF0aChmaWxlLnBhdGgpXG4gICAgICAgIGlmIChmaWxlRGF0ZSA9PT0gdG9kYXlTdHJpbmcpIHtcbiAgICAgICAgICB0b2RheXNGaWxlcy5wdXNoKGZpbGUpXG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgLy8gQW5hbHl6ZSBhY3Rpdml0aWVzXG4gICAgICBjb25zdCBhY3Rpdml0aWVzOiBBcnJheTx7IGZpbGU6IHN0cmluZzsgdHlwZTogc3RyaW5nOyBjb3Vyc2U/OiBzdHJpbmcgfT4gPVxuICAgICAgICBbXVxuXG4gICAgICBmb3IgKGNvbnN0IGZpbGUgb2YgdG9kYXlzRmlsZXMpIHtcbiAgICAgICAgY29uc3QgYWN0aXZpdHkgPSBhd2FpdCB0aGlzLmFuYWx5emVGaWxlQWN0aXZpdHkoZmlsZSlcbiAgICAgICAgaWYgKGFjdGl2aXR5KSB7XG4gICAgICAgICAgYWN0aXZpdGllcy5wdXNoKGFjdGl2aXR5KVxuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIGNvbnNvbGUubG9nKGBGb3VuZCAke2FjdGl2aXRpZXMubGVuZ3RofSBhY2FkZW1pYyBhY3Rpdml0aWVzIGZvciB0b2RheWApXG4gICAgICByZXR1cm4gYWN0aXZpdGllc1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZ2V0dGluZyB0b2RheSdzIGFjdGl2aXRpZXM6XCIsIGVycm9yKVxuICAgICAgcmV0dXJuIFtdXG4gICAgfVxuICB9XG5cbiAgYXN5bmMgZ2V0Q291cnNlQWN0aXZpdHlGb3JEYXRlKFxuICAgIGNvdXJzZUlkOiBzdHJpbmcsXG4gICAgZGF0ZTogc3RyaW5nXG4gICk6IFByb21pc2U8QXJyYXk8eyBmaWxlOiBzdHJpbmc7IHR5cGU6IHN0cmluZyB9Pj4ge1xuICAgIGNvbnNvbGUubG9nKGBHZXR0aW5nIGFjdGl2aXR5IGZvciBjb3Vyc2UgJHtjb3Vyc2VJZH0gb24gZGF0ZSAke2RhdGV9YClcblxuICAgIHRyeSB7XG4gICAgICAvLyBGaW5kIGZpbGVzIHJlbGF0ZWQgdG8gdGhlIGNvdXJzZSBtb2RpZmllZCBvbiB0aGUgZGF0ZVxuICAgICAgY29uc3QgY291cnNlRmlsZXMgPSBhd2FpdCB0aGlzLmZpbmRDb3Vyc2VGaWxlc0ZvckRhdGUoY291cnNlSWQsIGRhdGUpXG5cbiAgICAgIGNvbnN0IGFjdGl2aXRpZXM6IEFycmF5PHsgZmlsZTogc3RyaW5nOyB0eXBlOiBzdHJpbmcgfT4gPSBbXVxuXG4gICAgICBmb3IgKGNvbnN0IGZpbGUgb2YgY291cnNlRmlsZXMpIHtcbiAgICAgICAgY29uc3QgY29udGVudCA9IGF3YWl0IHRoaXMuYXBwLnZhdWx0LnJlYWQoZmlsZSlcbiAgICAgICAgY29uc3QgZmlsZVR5cGUgPSB0aGlzLmRldGVybWluZUZpbGVUeXBlKGZpbGUsIGNvbnRlbnQpXG5cbiAgICAgICAgYWN0aXZpdGllcy5wdXNoKHtcbiAgICAgICAgICBmaWxlOiBmaWxlLmJhc2VuYW1lLFxuICAgICAgICAgIHR5cGU6IGZpbGVUeXBlXG4gICAgICAgIH0pXG4gICAgICB9XG5cbiAgICAgIGNvbnNvbGUubG9nKFxuICAgICAgICBgRm91bmQgJHthY3Rpdml0aWVzLmxlbmd0aH0gYWN0aXZpdGllcyBmb3IgY291cnNlICR7Y291cnNlSWR9IG9uICR7ZGF0ZX1gXG4gICAgICApXG4gICAgICByZXR1cm4gYWN0aXZpdGllc1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFxuICAgICAgICBgRXJyb3IgZ2V0dGluZyBjb3Vyc2UgYWN0aXZpdHkgZm9yICR7Y291cnNlSWR9IG9uICR7ZGF0ZX06YCxcbiAgICAgICAgZXJyb3JcbiAgICAgIClcbiAgICAgIHJldHVybiBbXVxuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgZXh0cmFjdERhdGVGcm9tUGF0aChmaWxlUGF0aDogc3RyaW5nKTogc3RyaW5nIHwgbnVsbCB7XG4gICAgLy8gVHJ5IHRvIGV4dHJhY3QgZGF0ZSBmcm9tIGZpbGUgcGF0aCAoZS5nLiwgXCJEYWlseS8yMDI1LTAxLTE1Lm1kXCIgLT4gXCIyMDI1LTAxLTE1XCIpXG4gICAgY29uc3QgZGF0ZVJlZ2V4ID0gLyhcXGR7NH0tXFxkezJ9LVxcZHsyfSkvZ1xuICAgIGNvbnN0IG1hdGNoZXMgPSBmaWxlUGF0aC5tYXRjaChkYXRlUmVnZXgpXG4gICAgcmV0dXJuIG1hdGNoZXMgPyBtYXRjaGVzW21hdGNoZXMubGVuZ3RoIC0gMV0gOiBudWxsXG4gIH1cblxuICBwcml2YXRlIGFzeW5jIGFuYWx5emVGaWxlQWN0aXZpdHkoXG4gICAgZmlsZTogVEZpbGVcbiAgKTogUHJvbWlzZTx7IGZpbGU6IHN0cmluZzsgdHlwZTogc3RyaW5nOyBjb3Vyc2U/OiBzdHJpbmcgfSB8IG51bGw+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgY29udGVudCA9IGF3YWl0IHRoaXMuYXBwLnZhdWx0LnJlYWQoZmlsZSlcblxuICAgICAgLy8gRGV0ZXJtaW5lIGZpbGUgdHlwZSBiYXNlZCBvbiBjb250ZW50IGFuZCBwYXRoXG4gICAgICBjb25zdCBmaWxlVHlwZSA9IHRoaXMuZGV0ZXJtaW5lRmlsZVR5cGUoZmlsZSwgY29udGVudClcblxuICAgICAgLy8gRXh0cmFjdCBjb3Vyc2UgSUQgaWYgYXBwbGljYWJsZVxuICAgICAgY29uc3QgY291cnNlSWQgPVxuICAgICAgICB0aGlzLmV4dHJhY3RDb3Vyc2VJZEZyb21Db250ZW50KGNvbnRlbnQpIHx8XG4gICAgICAgIHRoaXMuZXh0cmFjdENvdXJzZUlkRnJvbVBhdGgoZmlsZS5wYXRoKVxuXG4gICAgICByZXR1cm4ge1xuICAgICAgICBmaWxlOiBmaWxlLmJhc2VuYW1lLFxuICAgICAgICB0eXBlOiBmaWxlVHlwZSxcbiAgICAgICAgY291cnNlOiBjb3Vyc2VJZCB8fCB1bmRlZmluZWRcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihgRXJyb3IgYW5hbHl6aW5nIGZpbGUgJHtmaWxlLnBhdGh9OmAsIGVycm9yKVxuICAgICAgcmV0dXJuIG51bGxcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGRldGVybWluZUZpbGVUeXBlKGZpbGU6IFRGaWxlLCBjb250ZW50OiBzdHJpbmcpOiBzdHJpbmcge1xuICAgIGNvbnN0IHBhdGggPSBmaWxlLnBhdGgudG9Mb3dlckNhc2UoKVxuXG4gICAgLy8gQ2hlY2sgZm9yIGRhaWx5IG5vdGVzXG4gICAgaWYgKFxuICAgICAgcGF0aC5pbmNsdWRlcyhcImRhaWx5XCIpIHx8XG4gICAgICBjb250ZW50LmluY2x1ZGVzKFwiY29udGVudF90eXBlOiBkYWlseV9ub3RlXCIpXG4gICAgKSB7XG4gICAgICByZXR1cm4gXCJkYWlseV9ub3RlXCJcbiAgICB9XG5cbiAgICAvLyBDaGVjayBmb3IgY291cnNlLXJlbGF0ZWQgZmlsZXNcbiAgICBpZiAocGF0aC5pbmNsdWRlcyhcImNvdXJzZXNcIikgfHwgY29udGVudC5pbmNsdWRlcyhcImNvdXJzZV9pZDpcIikpIHtcbiAgICAgIGlmIChjb250ZW50LmluY2x1ZGVzKFwiY29udGVudF90eXBlOiBjb3Vyc2VfaG9tZXBhZ2VcIikpIHtcbiAgICAgICAgcmV0dXJuIFwiY291cnNlX2hvbWVwYWdlXCJcbiAgICAgIH1cbiAgICAgIGlmIChjb250ZW50LmluY2x1ZGVzKFwiY29udGVudF90eXBlOiBtb2R1bGVcIikpIHtcbiAgICAgICAgcmV0dXJuIFwibW9kdWxlXCJcbiAgICAgIH1cbiAgICAgIGlmIChjb250ZW50LmluY2x1ZGVzKFwiY29udGVudF90eXBlOiBjaGFwdGVyXCIpKSB7XG4gICAgICAgIHJldHVybiBcImNoYXB0ZXJcIlxuICAgICAgfVxuICAgICAgaWYgKGNvbnRlbnQuaW5jbHVkZXMoXCJjb250ZW50X3R5cGU6IGFzc2lnbm1lbnRcIikpIHtcbiAgICAgICAgcmV0dXJuIFwiYXNzaWdubWVudFwiXG4gICAgICB9XG4gICAgICByZXR1cm4gXCJjb3Vyc2Vfbm90ZVwiXG4gICAgfVxuXG4gICAgLy8gQ2hlY2sgZm9yIHZvY2FidWxhcnkgZW50cmllc1xuICAgIGlmIChjb250ZW50LmluY2x1ZGVzKFwiIyMgXCIpICYmIGNvbnRlbnQubWF0Y2goL15cXCpcXCpUZXJtXFwqXFwqOi9tKSkge1xuICAgICAgcmV0dXJuIFwidm9jYWJ1bGFyeV9lbnRyeVwiXG4gICAgfVxuXG4gICAgcmV0dXJuIFwib3RoZXJcIlxuICB9XG5cbiAgcHJpdmF0ZSBleHRyYWN0Q291cnNlSWRGcm9tQ29udGVudChjb250ZW50OiBzdHJpbmcpOiBzdHJpbmcgfCBudWxsIHtcbiAgICBjb25zdCBjb3Vyc2VJZFJlZ2V4ID0gL2NvdXJzZV9pZDpcXHMqKFtBLVpdezIsNH0tXFxkezN9KS9cbiAgICBjb25zdCBtYXRjaCA9IGNvbnRlbnQubWF0Y2goY291cnNlSWRSZWdleClcbiAgICByZXR1cm4gbWF0Y2ggPyBtYXRjaFsxXSA6IG51bGxcbiAgfVxuXG4gIHByaXZhdGUgZXh0cmFjdENvdXJzZUlkRnJvbVBhdGgoZmlsZVBhdGg6IHN0cmluZyk6IHN0cmluZyB8IG51bGwge1xuICAgIGNvbnN0IGNvdXJzZUlkUmVnZXggPSAvKFtBLVpdezIsNH0tXFxkezN9KS9nXG4gICAgY29uc3QgbWF0Y2hlcyA9IGZpbGVQYXRoLm1hdGNoKGNvdXJzZUlkUmVnZXgpXG4gICAgcmV0dXJuIG1hdGNoZXMgPyBtYXRjaGVzW21hdGNoZXMubGVuZ3RoIC0gMV0gOiBudWxsXG4gIH1cblxuICBwcml2YXRlIGFzeW5jIGZpbmRDb3Vyc2VGaWxlc0ZvckRhdGUoXG4gICAgY291cnNlSWQ6IHN0cmluZyxcbiAgICBkYXRlOiBzdHJpbmdcbiAgKTogUHJvbWlzZTxURmlsZVtdPiB7XG4gICAgY29uc3QgZmlsZXM6IFRGaWxlW10gPSBbXVxuXG4gICAgLy8gR2V0IGFsbCBmaWxlcyBhbmQgZmlsdGVyIGJ5IGNvdXJzZSBJRCBhbmQgZGF0ZVxuICAgIGNvbnN0IGFsbEZpbGVzID0gdGhpcy5hcHAudmF1bHQuZ2V0TWFya2Rvd25GaWxlcygpXG5cbiAgICBmb3IgKGNvbnN0IGZpbGUgb2YgYWxsRmlsZXMpIHtcbiAgICAgIC8vIENoZWNrIGlmIGZpbGUgYmVsb25ncyB0byB0aGUgY291cnNlXG4gICAgICBpZiAoXG4gICAgICAgIGZpbGUucGF0aC5pbmNsdWRlcyhjb3Vyc2VJZCkgfHxcbiAgICAgICAgKGF3YWl0IHRoaXMuZmlsZUJlbG9uZ3NUb0NvdXJzZShmaWxlLCBjb3Vyc2VJZCkpXG4gICAgICApIHtcbiAgICAgICAgLy8gQ2hlY2sgaWYgZmlsZSB3YXMgbW9kaWZpZWQgb24gdGhlIHNwZWNpZmllZCBkYXRlXG4gICAgICAgIGNvbnN0IGZpbGVEYXRlID0gdGhpcy5leHRyYWN0RGF0ZUZyb21QYXRoKGZpbGUucGF0aClcbiAgICAgICAgaWYgKGZpbGVEYXRlID09PSBkYXRlKSB7XG4gICAgICAgICAgZmlsZXMucHVzaChmaWxlKVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIGZpbGVzXG4gIH1cblxuICBwcml2YXRlIGFzeW5jIGZpbGVCZWxvbmdzVG9Db3Vyc2UoXG4gICAgZmlsZTogVEZpbGUsXG4gICAgY291cnNlSWQ6IHN0cmluZ1xuICApOiBQcm9taXNlPGJvb2xlYW4+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgY29udGVudCA9IGF3YWl0IHRoaXMuYXBwLnZhdWx0LnJlYWQoZmlsZSlcbiAgICAgIHJldHVybiB0aGlzLmV4dHJhY3RDb3Vyc2VJZEZyb21Db250ZW50KGNvbnRlbnQpID09PSBjb3Vyc2VJZFxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFxuICAgICAgICBgRXJyb3IgY2hlY2tpbmcgaWYgZmlsZSAke2ZpbGUucGF0aH0gYmVsb25ncyB0byBjb3Vyc2UgJHtjb3Vyc2VJZH06YCxcbiAgICAgICAgZXJyb3JcbiAgICAgIClcbiAgICAgIHJldHVybiBmYWxzZVxuICAgIH1cbiAgfVxuXG4gIGFzeW5jIGdlbmVyYXRlRGFpbHlTdW1tYXJ5KGRhdGU/OiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz4ge1xuICAgIGNvbnN0IHRhcmdldERhdGUgPSBkYXRlIHx8IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zcGxpdChcIlRcIilbMF1cbiAgICBjb25zdCBhY3Rpdml0aWVzID0gYXdhaXQgdGhpcy5nZXRDb3Vyc2VBY3Rpdml0eUZvckRhdGUoXCJcIiwgdGFyZ2V0RGF0ZSlcblxuICAgIGlmIChhY3Rpdml0aWVzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgcmV0dXJuIGAjIEFjYWRlbWljIEFjdGl2aXRpZXMgLSAke3RhcmdldERhdGV9XFxuXFxuTm8gYWNhZGVtaWMgYWN0aXZpdGllcyByZWNvcmRlZCBmb3IgdGhpcyBkYXRlLlxcbmBcbiAgICB9XG5cbiAgICAvLyBHcm91cCBhY3Rpdml0aWVzIGJ5IGNvdXJzZVxuICAgIGNvbnN0IGJ5Q291cnNlOiBSZWNvcmQ8c3RyaW5nLCB0eXBlb2YgYWN0aXZpdGllcz4gPSB7fVxuICAgIGNvbnN0IG5vQ291cnNlOiB0eXBlb2YgYWN0aXZpdGllcyA9IFtdXG5cbiAgICBmb3IgKGNvbnN0IGFjdGl2aXR5IG9mIGFjdGl2aXRpZXMpIHtcbiAgICAgIGlmIChhY3Rpdml0eS5maWxlLmluY2x1ZGVzKFwiQ291cnNlcy9cIikpIHtcbiAgICAgICAgLy8gRXh0cmFjdCBjb3Vyc2UgSUQgZnJvbSBwYXRoXG4gICAgICAgIGNvbnN0IHBhdGhQYXJ0cyA9IGFjdGl2aXR5LmZpbGUuc3BsaXQoXCIvXCIpXG4gICAgICAgIGNvbnN0IGNvdXJzZUluZGV4ID0gcGF0aFBhcnRzLmZpbmRJbmRleCgocGFydCkgPT4gcGFydC5pbmNsdWRlcyhcIi1cIikpXG4gICAgICAgIGlmIChjb3Vyc2VJbmRleCA+PSAwKSB7XG4gICAgICAgICAgY29uc3QgY291cnNlSWQgPSBwYXRoUGFydHNbY291cnNlSW5kZXhdXG4gICAgICAgICAgaWYgKCFieUNvdXJzZVtjb3Vyc2VJZF0pIHtcbiAgICAgICAgICAgIGJ5Q291cnNlW2NvdXJzZUlkXSA9IFtdXG4gICAgICAgICAgfVxuICAgICAgICAgIGJ5Q291cnNlW2NvdXJzZUlkXS5wdXNoKGFjdGl2aXR5KVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIG5vQ291cnNlLnB1c2goYWN0aXZpdHkpXG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIG5vQ291cnNlLnB1c2goYWN0aXZpdHkpXG4gICAgICB9XG4gICAgfVxuXG4gICAgbGV0IGNvbnRlbnQgPSBgIyBBY2FkZW1pYyBBY3Rpdml0aWVzIC0gJHt0YXJnZXREYXRlfVxcblxcbmBcbiAgICBjb250ZW50ICs9IGBUb3RhbCBhY3Rpdml0aWVzOiAke2FjdGl2aXRpZXMubGVuZ3RofVxcblxcbmBcblxuICAgIC8vIEFkZCBhY3Rpdml0aWVzIGJ5IGNvdXJzZVxuICAgIGZvciAoY29uc3QgW2NvdXJzZUlkLCBjb3Vyc2VBY3Rpdml0aWVzXSBvZiBPYmplY3QuZW50cmllcyhieUNvdXJzZSkpIHtcbiAgICAgIGNvbnRlbnQgKz0gYCMjICR7Y291cnNlSWR9XFxuXFxuYFxuICAgICAgY29udGVudCArPSBgfCBGaWxlIHwgVHlwZSB8XFxuYFxuICAgICAgY29udGVudCArPSBgfCAtLS0tIHwgLS0tLSB8XFxuYFxuXG4gICAgICBmb3IgKGNvbnN0IGFjdGl2aXR5IG9mIGNvdXJzZUFjdGl2aXRpZXMpIHtcbiAgICAgICAgY29udGVudCArPSBgfCAke2FjdGl2aXR5LmZpbGV9IHwgJHthY3Rpdml0eS50eXBlfSB8XFxuYFxuICAgICAgfVxuICAgICAgY29udGVudCArPSBgXFxuYFxuICAgIH1cblxuICAgIC8vIEFkZCBhY3Rpdml0aWVzIHdpdGhvdXQgc3BlY2lmaWMgY291cnNlXG4gICAgaWYgKG5vQ291cnNlLmxlbmd0aCA+IDApIHtcbiAgICAgIGNvbnRlbnQgKz0gYCMjIE90aGVyIEFjdGl2aXRpZXNcXG5cXG5gXG4gICAgICBjb250ZW50ICs9IGB8IEZpbGUgfCBUeXBlIHxcXG5gXG4gICAgICBjb250ZW50ICs9IGB8IC0tLS0gfCAtLS0tIHxcXG5gXG5cbiAgICAgIGZvciAoY29uc3QgYWN0aXZpdHkgb2Ygbm9Db3Vyc2UpIHtcbiAgICAgICAgY29udGVudCArPSBgfCAke2FjdGl2aXR5LmZpbGV9IHwgJHthY3Rpdml0eS50eXBlfSB8XFxuYFxuICAgICAgfVxuICAgICAgY29udGVudCArPSBgXFxuYFxuICAgIH1cblxuICAgIHJldHVybiBjb250ZW50XG4gIH1cblxuICBhc3luYyBjcmVhdGVEYWlseVN1bW1hcnlGaWxlKGRhdGU/OiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgdGFyZ2V0RGF0ZSA9IGRhdGUgfHwgbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNwbGl0KFwiVFwiKVswXVxuICAgICAgY29uc3Qgc3VtbWFyeUNvbnRlbnQgPSBhd2FpdCB0aGlzLmdlbmVyYXRlRGFpbHlTdW1tYXJ5KHRhcmdldERhdGUpXG5cbiAgICAgIC8vIENyZWF0ZSB0aGUgc3VtbWFyeSBmaWxlXG4gICAgICBjb25zdCBmaWxlTmFtZSA9IGAke3RhcmdldERhdGV9IC0gQWNhZGVtaWMgU3VtbWFyeS5tZGBcbiAgICAgIGNvbnN0IGZpbGVQYXRoID0gYERhaWx5LyR7ZmlsZU5hbWV9YFxuXG4gICAgICB0cnkge1xuICAgICAgICBhd2FpdCB0aGlzLmFwcC52YXVsdC5jcmVhdGUoZmlsZVBhdGgsIHN1bW1hcnlDb250ZW50KVxuICAgICAgICBjb25zb2xlLmxvZyhgQ3JlYXRlZCBkYWlseSBzdW1tYXJ5IGZpbGU6ICR7ZmlsZVBhdGh9YClcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIC8vIEZpbGUgbWlnaHQgYWxyZWFkeSBleGlzdCwgdHJ5IHRvIHVwZGF0ZSBpdFxuICAgICAgICBjb25zdCBleGlzdGluZ0ZpbGUgPSB0aGlzLmFwcC52YXVsdC5nZXRBYnN0cmFjdEZpbGVCeVBhdGgoZmlsZVBhdGgpXG4gICAgICAgIGlmIChleGlzdGluZ0ZpbGUgJiYgZXhpc3RpbmdGaWxlIGluc3RhbmNlb2YgVEZpbGUpIHtcbiAgICAgICAgICBhd2FpdCB0aGlzLmFwcC52YXVsdC5tb2RpZnkoZXhpc3RpbmdGaWxlLCBzdW1tYXJ5Q29udGVudClcbiAgICAgICAgICBjb25zb2xlLmxvZyhgVXBkYXRlZCBkYWlseSBzdW1tYXJ5IGZpbGU6ICR7ZmlsZVBhdGh9YClcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKGBFcnJvciBjcmVhdGluZyBkYWlseSBzdW1tYXJ5IGZvciAke2RhdGV9OmAsIGVycm9yKVxuICAgICAgdGhyb3cgZXJyb3JcbiAgICB9XG4gIH1cbn1cbiJdLAogICJtYXBwaW5ncyI6ICI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBQUFBLG1CQUF1Qjs7O0FDQXZCLHNCQUErQzs7O0FDZ0J4QyxTQUFTLFFBQVEsTUFBc0I7QUFDNUMsU0FBTyxLQUNKLFlBQVksRUFDWixLQUFLLEVBQ0wsVUFBVSxLQUFLLEVBQ2YsUUFBUSxvQkFBb0IsRUFBRSxFQUM5QixRQUFRLGlCQUFpQixFQUFFLEVBQzNCLFFBQVEsV0FBVyxHQUFHLEVBQ3RCLFFBQVEsWUFBWSxFQUFFO0FBQzNCO0FBZU8sU0FBUyxhQUFhLFlBQTZCO0FBQ3hELFFBQU0sUUFBUTtBQUNkLE1BQUksQ0FBQyxXQUFXLE1BQU0sS0FBSztBQUFHLFdBQU87QUFFckMsUUFBTSxPQUFPLElBQUksS0FBSyxVQUFVO0FBQ2hDLFFBQU0sWUFBWSxLQUFLLFFBQVE7QUFFL0IsTUFBSSxPQUFPLGNBQWMsWUFBWSxNQUFNLFNBQVM7QUFBRyxXQUFPO0FBRTlELFNBQU8sZUFBZSxLQUFLLFlBQVksRUFBRSxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQ3ZEOzs7QURwQ08sSUFBTSxtQkFBeUM7QUFBQSxFQUNwRCxlQUFlO0FBQUEsRUFDZixtQkFBbUIsSUFBSSxLQUFLLEVBQUUsWUFBWSxFQUFFLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFBQSxFQUN4RCxpQkFBaUIsSUFBSSxLQUFLLElBQUksS0FBSyxFQUFFLFNBQVMsSUFBSSxLQUFLLEVBQUUsU0FBUyxJQUFJLENBQUMsQ0FBQyxFQUFFLFlBQVksRUFBRSxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsRUFDcEcsWUFBWTtBQUFBLEVBQ1osb0JBQW9CO0FBQUEsRUFDcEIsZ0JBQWdCO0FBQUEsRUFDaEIscUJBQXFCO0FBQ3ZCO0FBRU8sSUFBTSx5QkFBTixjQUFxQyxpQ0FBaUI7QUFBQSxFQUczRCxZQUFZLEtBQVUsUUFBNEI7QUFDaEQsVUFBTSxLQUFLLE1BQU07QUFDakIsU0FBSyxTQUFTO0FBQUEsRUFDaEI7QUFBQSxFQUVBLFVBQWdCO0FBQ2QsVUFBTSxFQUFFLFlBQVksSUFBSTtBQUV4QixnQkFBWSxNQUFNO0FBRWxCLGdCQUFZLFNBQVMsTUFBTSxFQUFFLE1BQU0seUJBQXlCLENBQUM7QUFFN0QsUUFBSSx3QkFBUSxXQUFXLEVBQ3BCLFFBQVEsZ0JBQWdCLEVBQ3hCLFFBQVEsZ0RBQWdELEVBQ3hELFFBQVEsVUFBUSxLQUNkLGVBQWUsR0FBRyxFQUNsQixTQUFTLEtBQUssT0FBTyxTQUFTLGFBQWEsRUFDM0MsU0FBUyxDQUFPLFVBQVU7QUFDekIsV0FBSyxPQUFPLFNBQVMsZ0JBQWdCO0FBQ3JDLFlBQU0sS0FBSyxPQUFPLGFBQWE7QUFBQSxJQUNqQyxFQUFDLENBQUM7QUFFTixVQUFNLG1CQUFtQixJQUFJLHdCQUFRLFdBQVcsRUFDN0MsUUFBUSxxQkFBcUIsRUFDN0IsUUFBUSxxQ0FBcUMsRUFDN0MsUUFBUSxVQUFRLEtBQ2QsZUFBZSxZQUFZLEVBQzNCLFNBQVMsS0FBSyxPQUFPLFNBQVMsaUJBQWlCLEVBQy9DLFNBQVMsQ0FBTyxVQUFVO0FBQ3pCLFVBQUksU0FBUyxDQUFDLGFBQWEsS0FBSyxHQUFHO0FBQ2pDLHlCQUFpQixRQUFRLDJEQUEyRDtBQUFBLE1BQ3RGLE9BQU87QUFDTCx5QkFBaUIsUUFBUSxxQ0FBcUM7QUFBQSxNQUNoRTtBQUNBLFdBQUssT0FBTyxTQUFTLG9CQUFvQjtBQUN6QyxZQUFNLEtBQUssT0FBTyxhQUFhO0FBQUEsSUFDakMsRUFBQyxDQUFDO0FBRU4sVUFBTSxpQkFBaUIsSUFBSSx3QkFBUSxXQUFXLEVBQzNDLFFBQVEsbUJBQW1CLEVBQzNCLFFBQVEsbUNBQW1DLEVBQzNDLFFBQVEsVUFBUSxLQUNkLGVBQWUsWUFBWSxFQUMzQixTQUFTLEtBQUssT0FBTyxTQUFTLGVBQWUsRUFDN0MsU0FBUyxDQUFPLFVBQVU7QUFDekIsVUFBSSxTQUFTLENBQUMsYUFBYSxLQUFLLEdBQUc7QUFDakMsdUJBQWUsUUFBUSx5REFBeUQ7QUFBQSxNQUNsRixPQUFPO0FBQ0wsdUJBQWUsUUFBUSxtQ0FBbUM7QUFBQSxNQUM1RDtBQUNBLFdBQUssT0FBTyxTQUFTLGtCQUFrQjtBQUN2QyxZQUFNLEtBQUssT0FBTyxhQUFhO0FBQUEsSUFDakMsRUFBQyxDQUFDO0FBRU4sUUFBSSx3QkFBUSxXQUFXLEVBQ3BCLFFBQVEsYUFBYSxFQUNyQixRQUFRLDBCQUEwQixFQUNsQyxRQUFRLFVBQVEsS0FDZCxlQUFlLFlBQVksRUFDM0IsU0FBUyxLQUFLLE9BQU8sU0FBUyxVQUFVLEVBQ3hDLFNBQVMsQ0FBTyxVQUFVO0FBQ3pCLFdBQUssT0FBTyxTQUFTLGFBQWE7QUFDbEMsWUFBTSxLQUFLLE9BQU8sYUFBYTtBQUFBLElBQ2pDLEVBQUMsQ0FBQztBQUVOLFFBQUksd0JBQVEsV0FBVyxFQUNwQixRQUFRLHFCQUFxQixFQUM3QixRQUFRLG1DQUFtQyxFQUMzQyxRQUFRLFVBQVEsS0FDZCxlQUFlLEdBQUcsRUFDbEIsU0FBUyxLQUFLLE9BQU8sU0FBUyxrQkFBa0IsRUFDaEQsU0FBUyxDQUFPLFVBQVU7QUFDekIsV0FBSyxPQUFPLFNBQVMscUJBQXFCO0FBQzFDLFlBQU0sS0FBSyxPQUFPLGFBQWE7QUFBQSxJQUNqQyxFQUFDLENBQUM7QUFFTixRQUFJLHdCQUFRLFdBQVcsRUFDcEIsUUFBUSxpQkFBaUIsRUFDekIsUUFBUSw2RUFBNkUsRUFDckYsUUFBUSxVQUFRLEtBQ2QsZUFBZSxlQUFlLEVBQzlCLFNBQVMsS0FBSyxPQUFPLFNBQVMsY0FBYyxFQUM1QyxTQUFTLENBQU8sVUFBVTtBQUN6QixXQUFLLE9BQU8sU0FBUyxpQkFBaUI7QUFDdEMsWUFBTSxLQUFLLE9BQU8sYUFBYTtBQUFBLElBQ2pDLEVBQUMsQ0FBQztBQUVOLFFBQUksd0JBQVEsV0FBVyxFQUNwQixRQUFRLHVCQUF1QixFQUMvQixRQUFRLGlGQUFpRixFQUN6RixVQUFVLFlBQVUsT0FDbEIsU0FBUyxLQUFLLE9BQU8sU0FBUyxtQkFBbUIsRUFDakQsU0FBUyxDQUFPLFVBQVU7QUFDekIsV0FBSyxPQUFPLFNBQVMsc0JBQXNCO0FBQzNDLFlBQU0sS0FBSyxPQUFPLGFBQWE7QUFBQSxJQUNqQyxFQUFDLENBQUM7QUFBQSxFQUNSO0FBQ0Y7OztBRTdIQSxJQUFBQyxtQkFBNEI7QUFVckIsSUFBTSxrQkFBTixNQUFzQjtBQUFBLEVBSzNCLFlBQVksS0FBVSxVQUFnQztBQUNwRCxTQUFLLE1BQU07QUFDWCxTQUFLLFdBQVc7QUFDaEIsU0FBSyxXQUFXO0FBQUEsTUFDZCxTQUFTO0FBQUEsTUFDVCxXQUFXO0FBQUEsUUFDVCxxQ0FBcUM7QUFBQSxRQUNyQywyQkFBMkI7QUFBQSxRQUMzQiw0QkFBNEI7QUFBQSxRQUM1Qiw4QkFBOEI7QUFBQSxRQUM5QixvQ0FBb0M7QUFBQSxRQUNwQyx1QkFBdUI7QUFBQSxRQUN2QixpQ0FBaUM7QUFBQSxRQUNqQywrQkFBK0I7QUFBQSxNQUNqQztBQUFBLE1BQ0EsZ0JBQWdCO0FBQUEsTUFDaEIsZUFBZTtBQUFBLElBQ2pCO0FBQUEsRUFDRjtBQUFBLEVBRU0sbUJBQW1CO0FBQUE7QUFDdkIsVUFBSTtBQUVGLGNBQU0sa0JBQWtCLEtBQUssbUJBQW1CO0FBQ2hELFlBQUksQ0FBQyxpQkFBaUI7QUFDcEIsY0FBSTtBQUFBLFlBQ0Y7QUFBQSxVQUNGO0FBQ0Esa0JBQVE7QUFBQSxZQUNOO0FBQUEsVUFDRjtBQUNBO0FBQUEsUUFDRjtBQUVBLGNBQU0scUJBQXFCLEtBQUssc0JBQXNCLGVBQWU7QUFDckUsWUFBSSxDQUFDLG9CQUFvQjtBQUN2QixjQUFJO0FBQUEsWUFDRjtBQUFBLFVBQ0Y7QUFDQSxrQkFBUTtBQUFBLFlBQ047QUFBQSxVQUNGO0FBQ0E7QUFBQSxRQUNGO0FBRUEsY0FBTSxtQkFBbUIsR0FBRyxzQkFBc0IsS0FBSyxTQUFTO0FBR2hFLFlBQUk7QUFDRixnQkFBTSxLQUFLLElBQUksTUFBTSxhQUFhLGdCQUFnQjtBQUNsRCxrQkFBUSxJQUFJLDRCQUE0QixrQkFBa0I7QUFBQSxRQUM1RCxTQUFTLEdBQVA7QUFFQSxrQkFBUTtBQUFBLFlBQ04sOENBQThDO0FBQUEsVUFDaEQ7QUFBQSxRQUNGO0FBR0EsY0FBTSxVQUFVO0FBQUEsVUFDZDtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsUUFDRjtBQUNBLG1CQUFXLFVBQVUsU0FBUztBQUM1QixjQUFJO0FBQ0Ysa0JBQU0sVUFBVSxHQUFHLG9CQUFvQjtBQUN2QyxrQkFBTSxLQUFLLElBQUksTUFBTSxhQUFhLE9BQU87QUFDekMsb0JBQVEsSUFBSSx5QkFBeUIsU0FBUztBQUFBLFVBQ2hELFNBQVMsR0FBUDtBQUVBLG9CQUFRO0FBQUEsY0FDTixnQ0FBZ0Msb0JBQW9CO0FBQUEsWUFDdEQ7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUdBLGNBQU0sS0FBSyx1QkFBdUIsZ0JBQWdCO0FBQ2xELGNBQU0sS0FBSyx1QkFBdUIsZ0JBQWdCO0FBQ2xELGNBQU0sS0FBSyx3QkFBd0IsZ0JBQWdCO0FBQ25ELGNBQU0sS0FBSywyQkFBMkIsZ0JBQWdCO0FBQ3RELGNBQU0sS0FBSyxzQkFBc0IsZ0JBQWdCO0FBQ2pELGNBQU0sS0FBSyx3QkFBd0IsZ0JBQWdCO0FBR25ELGNBQU0sS0FBSyxhQUFhLGdCQUFnQjtBQUd4QyxjQUFNLEtBQUssdUJBQXVCLGdCQUFnQjtBQUVsRCxZQUFJLHdCQUFPLGlEQUFpRDtBQUM1RCxnQkFBUSxJQUFJLGdEQUFnRDtBQUFBLE1BQzlELFNBQVMsT0FBUDtBQUNBLGdCQUFRLE1BQU0sK0JBQStCLEtBQUs7QUFDbEQsWUFBSSx3QkFBTyx3REFBd0Q7QUFBQSxNQUNyRTtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRVEscUJBQTBCO0FBRWhDLFVBQU0sZ0JBQWdCO0FBQUEsTUFDbkIsS0FBSyxJQUFZLFFBQVEsUUFBUSxvQkFBb0I7QUFBQSxNQUNyRCxLQUFLLElBQVksUUFBUSxRQUFRLFdBQVc7QUFBQSxNQUM1QyxLQUFLLElBQVksUUFBUSxVQUFVLG9CQUFvQjtBQUFBLE1BQ3ZELEtBQUssSUFBWSxRQUFRLFVBQVUsV0FBVztBQUFBLElBQ2pEO0FBRUEsZUFBVyxRQUFRLGVBQWU7QUFDaEMsVUFBSSxNQUFNO0FBQ1IsZUFBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBRUEsV0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUVRLHNCQUFzQixpQkFBcUM7QUFDakUsVUFBTSxXQUFXLGdCQUFnQjtBQUVqQyxRQUFJLENBQUMsVUFBVTtBQUNiLGNBQVEsTUFBTSxrQ0FBa0M7QUFDaEQsYUFBTztBQUFBLElBQ1Q7QUFHQSxVQUFNLGdCQUFnQjtBQUFBLE1BQ3BCLFNBQVM7QUFBQSxNQUNULFNBQVM7QUFBQSxNQUNULFNBQVM7QUFBQSxNQUNULFNBQVM7QUFBQSxJQUNYO0FBRUEsZUFBVyxRQUFRLGVBQWU7QUFDaEMsVUFBSSxRQUFRLE9BQU8sU0FBUyxVQUFVO0FBQ3BDLGVBQU87QUFBQSxNQUNUO0FBQUEsSUFDRjtBQUVBLFlBQVE7QUFBQSxNQUNOO0FBQUEsTUFDQSxPQUFPLEtBQUssUUFBUTtBQUFBLElBQ3RCO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUVNLHVCQUF1QixVQUFrQjtBQUFBO0FBQzdDLFlBQU0sZUFBZSxHQUFHO0FBQ3hCLFlBQU0sa0JBQWtCLEtBQUssVUFBVSxLQUFLLFVBQVUsTUFBTSxDQUFDO0FBRTdELFVBQUk7QUFFRixjQUFNLG1CQUNKLEtBQUssSUFBSSxNQUFNLHNCQUFzQixZQUFZO0FBQ25ELFlBQUksa0JBQWtCO0FBRXBCLGdCQUFNLE9BQU87QUFDYixnQkFBTSxLQUFLLElBQUksTUFBTSxPQUFPLE1BQU0sZUFBZTtBQUNqRCxrQkFBUSxJQUFJLDhCQUE4QixjQUFjO0FBQ3hEO0FBQUEsUUFDRjtBQUdBLGNBQU0sS0FBSyxJQUFJLE1BQU0sT0FBTyxjQUFjLGVBQWU7QUFDekQsZ0JBQVEsSUFBSSw4QkFBOEIsY0FBYztBQUFBLE1BQzFELFNBQVMsR0FBUDtBQUNBLFlBQUksd0JBQU8sb0NBQW9DLGNBQWM7QUFDN0QsZ0JBQVEsTUFBTSxvQ0FBb0MsaUJBQWlCLENBQUM7QUFBQSxNQUN0RTtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRU0sMEJBQTRDO0FBQUE7QUFHaEQsY0FBUSxJQUFJLCtCQUErQjtBQUMzQyxhQUFPO0FBQUEsSUFDVDtBQUFBO0FBQUEsRUFFTSxrQkFBa0I7QUFBQTtBQUN0QixVQUFJO0FBRUYsZ0JBQVEsSUFBSSxvQkFBb0I7QUFHaEMsY0FBTSxrQkFBa0IsS0FBSyxtQkFBbUI7QUFDaEQsWUFBSSxDQUFDLGlCQUFpQjtBQUNwQixjQUFJO0FBQUEsWUFDRjtBQUFBLFVBQ0Y7QUFDQSxrQkFBUTtBQUFBLFlBQ047QUFBQSxVQUNGO0FBQ0E7QUFBQSxRQUNGO0FBRUEsY0FBTSxxQkFBcUIsS0FBSyxzQkFBc0IsZUFBZTtBQUNyRSxZQUFJLENBQUMsb0JBQW9CO0FBQ3ZCLGNBQUk7QUFBQSxZQUNGO0FBQUEsVUFDRjtBQUNBLGtCQUFRO0FBQUEsWUFDTjtBQUFBLFVBQ0Y7QUFDQTtBQUFBLFFBQ0Y7QUFFQSxjQUFNLG1CQUFtQixHQUFHLHNCQUFzQixLQUFLLFNBQVM7QUFHaEUsY0FBTSxLQUFLLHVCQUF1QixnQkFBZ0I7QUFDbEQsY0FBTSxLQUFLLHVCQUF1QixnQkFBZ0I7QUFDbEQsY0FBTSxLQUFLLHdCQUF3QixnQkFBZ0I7QUFDbkQsY0FBTSxLQUFLLDJCQUEyQixnQkFBZ0I7QUFDdEQsY0FBTSxLQUFLLHNCQUFzQixnQkFBZ0I7QUFDakQsY0FBTSxLQUFLLHdCQUF3QixnQkFBZ0I7QUFHbkQsY0FBTSxLQUFLLGFBQWEsZ0JBQWdCO0FBR3hDLGNBQU0sS0FBSyx1QkFBdUIsZ0JBQWdCO0FBRWxELFlBQUksd0JBQU8sK0NBQStDO0FBQzFELGdCQUFRLElBQUksOENBQThDO0FBQUEsTUFDNUQsU0FBUyxPQUFQO0FBQ0EsZ0JBQVEsTUFBTSw2QkFBNkIsS0FBSztBQUNoRCxZQUFJLHdCQUFPLHNEQUFzRDtBQUFBLE1BQ25FO0FBQUEsSUFDRjtBQUFBO0FBQUEsRUFFTSx1QkFBdUIsVUFBa0I7QUFBQTtBQUM3QyxZQUFNLGFBQWEsR0FBRztBQUd0QixZQUFNLHlCQUF5QixLQUFLLCtCQUErQjtBQUNuRSxZQUFNLEtBQUs7QUFBQSxRQUNULEdBQUc7QUFBQSxRQUNIO0FBQUEsTUFDRjtBQUdBLFlBQU0sc0JBQXNCLEtBQUssNEJBQTRCO0FBQzdELFlBQU0sS0FBSztBQUFBLFFBQ1QsR0FBRztBQUFBLFFBQ0g7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBO0FBQUEsRUFFTSx1QkFBdUIsVUFBa0I7QUFBQTtBQUM3QyxZQUFNLGFBQWEsR0FBRztBQUd0QixZQUFNLGlCQUFpQixLQUFLLHVCQUF1QjtBQUNuRCxZQUFNLEtBQUs7QUFBQSxRQUNULEdBQUc7QUFBQSxRQUNIO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRU0sd0JBQXdCLFVBQWtCO0FBQUE7QUFDOUMsWUFBTSxjQUFjLEdBQUc7QUFHdkIsWUFBTSxrQkFBa0IsS0FBSyx3QkFBd0I7QUFDckQsWUFBTSxLQUFLO0FBQUEsUUFDVCxHQUFHO0FBQUEsUUFDSDtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVNLDJCQUEyQixVQUFrQjtBQUFBO0FBQ2pELFlBQU0saUJBQWlCLEdBQUc7QUFHMUIsWUFBTSxxQkFBcUIsS0FBSywyQkFBMkI7QUFDM0QsWUFBTSxLQUFLO0FBQUEsUUFDVCxHQUFHO0FBQUEsUUFDSDtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVNLHNCQUFzQixVQUFrQjtBQUFBO0FBQzVDLFlBQU0sWUFBWSxHQUFHO0FBR3JCLFlBQU0sb0JBQW9CLEtBQUssMEJBQTBCO0FBQ3pELFlBQU0sS0FBSztBQUFBLFFBQ1QsR0FBRztBQUFBLFFBQ0g7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBO0FBQUEsRUFFTSx3QkFBd0IsVUFBa0I7QUFBQTtBQUM5QyxZQUFNLGNBQWMsR0FBRztBQUd2QixZQUFNLGdCQUFnQixLQUFLLDJCQUEyQjtBQUN0RCxZQUFNLEtBQUs7QUFBQSxRQUNULEdBQUc7QUFBQSxRQUNIO0FBQUEsTUFDRjtBQUdBLFlBQU0sa0JBQWtCLEtBQUssd0JBQXdCO0FBQ3JELFlBQU0sS0FBSztBQUFBLFFBQ1QsR0FBRztBQUFBLFFBQ0g7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBO0FBQUEsRUFFTSxrQkFBa0IsTUFBYyxTQUFpQjtBQUFBO0FBQ3JELFVBQUk7QUFFRixjQUFNLGVBQWUsS0FBSyxJQUFJLE1BQU0sc0JBQXNCLElBQUk7QUFDOUQsWUFBSSxjQUFjO0FBR2hCLGtCQUFRLElBQUksb0NBQW9DLE1BQU07QUFDdEQsZ0JBQU0sT0FBTztBQUNiLGdCQUFNLEtBQUssSUFBSSxNQUFNLE9BQU8sTUFBTSxPQUFPO0FBQ3pDO0FBQUEsUUFDRjtBQUdBLGNBQU0sS0FBSyxJQUFJLE1BQU0sT0FBTyxNQUFNLE9BQU87QUFDekMsZ0JBQVEsSUFBSSwwQkFBMEIsTUFBTTtBQUFBLE1BQzlDLFNBQVMsR0FBUDtBQUNBLFlBQUksd0JBQU8sZ0NBQWdDLE1BQU07QUFDakQsZ0JBQVEsTUFBTSxnQ0FBZ0MsU0FBUyxDQUFDO0FBQUEsTUFDMUQ7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVBLGlDQUF5QztBQUN2QyxXQUFPO0FBQUEsRUFFVCxLQUFLLFNBQVMsc0JBQ1Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNSSxLQUFLLFNBQVM7QUFBQSx1QkFDRCxLQUFLLFNBQVMsdUJBQy9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFTRixLQUFLLFNBQVM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQXFESixLQUFLLFNBQVM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQXFDMUI7QUFBQSxFQUVBLDhCQUFzQztBQUNwQyxXQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFtQlQ7QUFBQSxFQUVBLHlCQUFpQztBQUMvQixXQUFPO0FBQUEsRUFFVCxLQUFLLFNBQVMsc0JBQ1Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFDQU1BO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFzQ0o7QUFBQSxFQUVBLDBCQUFrQztBQUNoQyxXQUFPO0FBQUEsRUFFVCxLQUFLLFNBQVMsc0JBQ1Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQ0FLQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQTRCSjtBQUFBLEVBRUEsNkJBQXFDO0FBQ25DLFdBQU87QUFBQSxFQUVULEtBQUssU0FBUyxzQkFDVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUNBTUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBMkJKO0FBQUEsRUFFQSw0QkFBb0M7QUFDbEMsV0FBTztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFtQ1Q7QUFBQSxFQUVBLDZCQUFxQztBQUNuQyxXQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVFUO0FBQUEsRUFFQSwwQkFBa0M7QUFDaEMsV0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUVNLGFBQWEsVUFBa0I7QUFBQTtBQUNuQyxZQUFNLGdCQUFnQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUF5QnRCLFlBQU0sS0FBSyxrQkFBa0IsR0FBRyxzQkFBc0IsYUFBYTtBQUFBLElBQ3JFO0FBQUE7QUFDRjs7O0FDcHJCQSxJQUFBQyxtQkFBbUM7QUFJNUIsSUFBTSx1QkFBTixNQUEyQjtBQUFBLEVBSWhDLFlBQVksS0FBVSxVQUFnQztBQUNwRCxTQUFLLE1BQU07QUFDWCxTQUFLLFdBQVc7QUFBQSxFQUNsQjtBQUFBLEVBRU0sdUJBQXVCO0FBQUE7QUFDM0IsVUFBSTtBQUVGLGNBQU0sZ0JBQWdCLE1BQU0sS0FBSyxvQkFBb0I7QUFFckQsWUFBSSxDQUFDLGVBQWU7QUFDbEIsaUJBQU87QUFBQSxRQUNUO0FBR0EsY0FBTSxhQUFhLE1BQU0sS0FBSyw0QkFBNEIsYUFBYTtBQUd2RSxjQUFNLEtBQUsseUJBQXlCLGVBQWUsVUFBVTtBQUc3RCxjQUFNLEtBQUssd0JBQXdCLFVBQVU7QUFFN0MsWUFBSSx3QkFBTyxXQUFXLGNBQWMsbUNBQW1DO0FBQ3ZFLGdCQUFRO0FBQUEsVUFDTixtQkFBbUIsY0FBYyxpQkFBaUI7QUFBQSxRQUNwRDtBQUVBLGVBQU87QUFBQSxNQUNULFNBQVMsT0FBUDtBQUNBLGdCQUFRLE1BQU0sMEJBQTBCLEtBQUs7QUFDN0MsWUFBSSx3QkFBTywwQkFBMEIsTUFBTSxTQUFTO0FBQ3BELGVBQU87QUFBQSxNQUNUO0FBQUEsSUFDRjtBQUFBO0FBQUEsRUFFYyxzQkFLSjtBQUFBO0FBbkRaO0FBb0RJLFVBQUk7QUFDRixjQUFNLGFBQWEsTUFBTSxLQUFLO0FBQUEsVUFDNUI7QUFBQSxVQUNBO0FBQUEsVUFDQSxDQUFDLFVBQVUsTUFBTSxLQUFLLEVBQUUsU0FBUztBQUFBLFVBQ2pDO0FBQUEsUUFDRjtBQUVBLFlBQUksQ0FBQztBQUFZLGlCQUFPO0FBRXhCLGNBQU0sZUFBZSxNQUFNLEtBQUs7QUFBQSxVQUM5QjtBQUFBLFVBQ0E7QUFBQSxVQUNBLENBQUMsUUFBUSxVQUFVLFVBQVUsUUFBUTtBQUFBLFFBQ3ZDO0FBRUEsWUFBSSxDQUFDO0FBQWMsaUJBQU87QUFFMUIsY0FBTSxhQUFhLE1BQU0sS0FBSztBQUFBLFVBQzVCO0FBQUEsVUFDQTtBQUFBLFVBQ0EsQ0FBQyxVQUFVLFVBQVUsS0FBSyxNQUFNLEtBQUssQ0FBQztBQUFBLFVBQ3RDO0FBQUEsUUFDRjtBQUVBLFlBQUksQ0FBQztBQUFZLGlCQUFPO0FBRXhCLGNBQU0sYUFBVyxnQkFBVyxNQUFNLEtBQUssRUFBRSxDQUFDLE1BQXpCLG1CQUE0QixXQUFVLFFBQVEsVUFBVTtBQUV6RSxlQUFPO0FBQUEsVUFDTDtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFFBQ0Y7QUFBQSxNQUNGLFNBQVMsT0FBUDtBQUNBLGdCQUFRLE1BQU0sdUNBQXVDLEtBQUs7QUFDMUQsZUFBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVjLHFCQUNaLE9BQ0EsU0FDQSxXQUNBLGNBQ3dCO0FBQUE7QUFFeEIsWUFBTSxRQUFRLE9BQU8sR0FBRyxVQUFVLFNBQVM7QUFFM0MsVUFBSSxDQUFDO0FBQU8sZUFBTztBQUVuQixVQUFJLENBQUMsVUFBVSxLQUFLLEdBQUc7QUFDckIsWUFBSSx3QkFBTyxZQUFZO0FBQ3ZCLGVBQU8sTUFBTSxLQUFLO0FBQUEsVUFDaEI7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUVBLGFBQU8sTUFBTSxLQUFLO0FBQUEsSUFDcEI7QUFBQTtBQUFBLEVBRWMsa0JBQ1osT0FDQSxTQUNBLFNBQ3dCO0FBQUE7QUFFeEIsWUFBTSxTQUFTO0FBQUEsUUFDYixHQUFHLFVBQVU7QUFBQSxXQUFxQixRQUFRLEtBQUssSUFBSTtBQUFBO0FBQUEsTUFDckQ7QUFFQSxVQUFJLENBQUM7QUFBUSxlQUFPO0FBRXBCLFlBQU0sZ0JBQWdCLE9BQU8sS0FBSztBQUNsQyxVQUFJLFFBQVEsU0FBUyxhQUFhLEdBQUc7QUFDbkMsZUFBTztBQUFBLE1BQ1Q7QUFFQSxVQUFJLHdCQUFPLHlCQUF5QixRQUFRLEtBQUssSUFBSSxHQUFHO0FBQ3hELGFBQU8sTUFBTSxLQUFLLGtCQUFrQixPQUFPLFNBQVMsT0FBTztBQUFBLElBQzdEO0FBQUE7QUFBQSxFQUVjLDRCQUE0QixlQUt0QjtBQUFBO0FBQ2xCLFlBQU0sYUFBYSxHQUFHLGNBQWMsY0FBYyxjQUFjLGdCQUFnQixjQUFjO0FBRTlGLFVBQUk7QUFDRixjQUFNLEtBQUssSUFBSSxNQUFNLGFBQWEsVUFBVTtBQUM1QyxnQkFBUSxJQUFJLDBCQUEwQixZQUFZO0FBQ2xELGVBQU87QUFBQSxNQUNULFNBQVMsT0FBUDtBQUVBLGdCQUFRLElBQUksNENBQTRDLFlBQVk7QUFDcEUsZUFBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVjLHlCQUNaLGVBTUEsWUFDZTtBQUFBO0FBQ2YsWUFBTSxXQUFXLEdBQUcsY0FBYyxjQUFjO0FBQ2hELFlBQU0sVUFBVSxLQUFLLDhCQUE4QixhQUFhO0FBRWhFLFVBQUk7QUFDRixjQUFNLEtBQUssSUFBSSxNQUFNLE9BQU8sVUFBVSxPQUFPO0FBQzdDLGdCQUFRLElBQUksNEJBQTRCLFVBQVU7QUFBQSxNQUNwRCxTQUFTLE9BQVA7QUFDQSxnQkFBUSxNQUFNLG1DQUFtQyxPQUFPO0FBQ3hELGNBQU07QUFBQSxNQUNSO0FBQUEsSUFDRjtBQUFBO0FBQUEsRUFFYyx3QkFBd0IsWUFBbUM7QUFBQTtBQUN2RSxZQUFNLGtCQUFrQixHQUFHO0FBRTNCLFVBQUk7QUFDRixjQUFNLEtBQUssSUFBSSxNQUFNLGFBQWEsZUFBZTtBQUNqRCxnQkFBUSxJQUFJLCtCQUErQixpQkFBaUI7QUFBQSxNQUM5RCxTQUFTLE9BQVA7QUFFQSxnQkFBUSxJQUFJLHNDQUFzQyxpQkFBaUI7QUFBQSxNQUNyRTtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRVEsOEJBQThCLGVBSzNCO0FBQ1QsVUFBTSxtQkFBbUIsS0FBSyxTQUFTO0FBRXZDLFdBQU87QUFBQSxFQUVULG1CQUNJLGNBQWMsY0FBYztBQUFBLGVBQ25CLGNBQWM7QUFBQSxlQUNkLGNBQWMsZ0JBQWdCLGNBQWM7QUFBQSxlQUM1QyxjQUFjO0FBQUEsbUJBQ1YsY0FBYztBQUFBO0FBQUEsVUFFdkIsS0FBSyxTQUFTO0FBQUEsdUJBQ0QsS0FBSyxTQUFTLHVCQUMvQixjQUFjLGNBQWM7QUFBQSxTQUN6QixjQUFjO0FBQUEsV0FFWixJQUFJLEtBQUssRUFBRSxZQUFZO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0FJN0IsY0FBYztBQUFBLEtBQ2QsS0FBSyxTQUFTLHNCQUFzQixjQUFjLGNBQ2pELGNBQWMsZ0JBQ1osY0FBYztBQUFBO0FBQUE7QUFBQTtBQUFBLElBSWxCLGNBQWM7QUFBQTtBQUFBO0FBQUEsaUJBR0QsY0FBYztBQUFBLFlBQ25CLGNBQWMsZ0JBQWdCLGNBQWM7QUFBQSxjQUMxQyxLQUFLLFNBQVM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQXNCMUI7QUFDRjs7O0FDelBBLElBQUFDLG1CQUEyQjtBQUdwQixJQUFNLHNCQUFOLE1BQTBCO0FBQUEsRUFHL0IsWUFBWSxLQUFVO0FBQ3BCLFNBQUssTUFBTTtBQUFBLEVBQ2I7QUFBQSxFQUVBLDBCQUEwQixTQUEyQjtBQUVuRCxVQUFNLGFBQWE7QUFDbkIsVUFBTSxlQUFlLG1DQUFTLE1BQU07QUFFcEMsUUFBSSxjQUFjO0FBQ2hCLFlBQU0sWUFBWSxhQUFhLENBQUMsRUFBRSxLQUFLO0FBQ3ZDLFlBQU0sZUFBZSxVQUNsQixRQUFRLGdCQUFnQixFQUFFLEVBQzFCLFFBQVEsY0FBYyxFQUFFLEVBQ3hCLE1BQU0sSUFBSSxFQUNWLElBQUksQ0FBQyxTQUFTLEtBQUssS0FBSyxDQUFDLEVBQ3pCLE9BQU8sQ0FBQyxTQUFTLEtBQUssU0FBUyxDQUFDO0FBRW5DLGFBQU87QUFBQSxJQUNUO0FBRUEsV0FBTyxDQUFDO0FBQUEsRUFDVjtBQUFBLEVBRU0sNEJBQ0osVUFDbUM7QUFBQTtBQUNuQyxjQUFRLElBQUkscUNBQXFDLFVBQVU7QUFFM0QsVUFBSTtBQUVGLGNBQU0sY0FBYyxNQUFNLEtBQUssZ0JBQWdCLFFBQVE7QUFFdkQsWUFBSSxZQUFZLFdBQVcsR0FBRztBQUM1QixrQkFBUSxJQUFJLDhCQUE4QixVQUFVO0FBQ3BELGlCQUFPLENBQUM7QUFBQSxRQUNWO0FBR0EsY0FBTSxpQkFBMkMsQ0FBQztBQUVsRCxtQkFBVyxRQUFRLGFBQWE7QUFDOUIsY0FBSTtBQUNGLGtCQUFNLFVBQVUsTUFBTSxLQUFLLElBQUksTUFBTSxLQUFLLElBQUk7QUFDOUMsa0JBQU0sYUFBYSxLQUFLLDBCQUEwQixPQUFPO0FBRXpELGdCQUFJLFdBQVcsU0FBUyxHQUFHO0FBQ3pCLDZCQUFlLEtBQUssUUFBUSxJQUFJO0FBQUEsWUFDbEM7QUFBQSxVQUNGLFNBQVMsT0FBUDtBQUNBLG9CQUFRLE1BQU0sc0JBQXNCLEtBQUssU0FBUyxLQUFLO0FBQUEsVUFDekQ7QUFBQSxRQUNGO0FBRUEsZ0JBQVE7QUFBQSxVQUNOLDZCQUNFLE9BQU8sS0FBSyxjQUFjLEVBQUUsNEJBQ1I7QUFBQSxRQUN4QjtBQUNBLGVBQU87QUFBQSxNQUNULFNBQVMsT0FBUDtBQUNBLGdCQUFRO0FBQUEsVUFDTiwwQ0FBMEM7QUFBQSxVQUMxQztBQUFBLFFBQ0Y7QUFDQSxlQUFPLENBQUM7QUFBQSxNQUNWO0FBQUEsSUFDRjtBQUFBO0FBQUEsRUFFTSxnQkFBZ0IsVUFBb0M7QUFBQTtBQUN4RCxZQUFNLFFBQWlCLENBQUM7QUFHeEIsWUFBTSxRQUFRLEtBQUssSUFBSSxNQUFNLGlCQUFpQjtBQUU5QyxpQkFBVyxRQUFRLE9BQU87QUFFeEIsWUFDRSxLQUFLLEtBQUssU0FBUyxRQUFRLE1BQzFCLE1BQU0sS0FBSyxvQkFBb0IsTUFBTSxRQUFRLElBQzlDO0FBQ0EsZ0JBQU0sS0FBSyxJQUFJO0FBQUEsUUFDakI7QUFBQSxNQUNGO0FBRUEsYUFBTztBQUFBLElBQ1Q7QUFBQTtBQUFBLEVBRWMsb0JBQ1osTUFDQSxVQUNrQjtBQUFBO0FBQ2xCLFVBQUk7QUFDRixjQUFNLFVBQVUsTUFBTSxLQUFLLElBQUksTUFBTSxLQUFLLElBQUk7QUFDOUMsY0FBTSxtQkFBbUIsUUFBUSxNQUFNLHVCQUF1QjtBQUU5RCxZQUFJLGtCQUFrQjtBQUNwQixnQkFBTSxjQUFjLGlCQUFpQixDQUFDO0FBRXRDLGlCQUNFLFlBQVksU0FBUyxjQUFjLFVBQVUsS0FDN0MsWUFBWSxTQUFTLGFBQWEsVUFBVTtBQUFBLFFBRWhEO0FBRUEsZUFBTztBQUFBLE1BQ1QsU0FBUyxPQUFQO0FBQ0EsZ0JBQVE7QUFBQSxVQUNOLDBCQUEwQixLQUFLLDBCQUEwQjtBQUFBLFVBQ3pEO0FBQUEsUUFDRjtBQUNBLGVBQU87QUFBQSxNQUNUO0FBQUEsSUFDRjtBQUFBO0FBQUEsRUFFTSx3QkFDSixVQUNBLGdCQUNpQjtBQUFBO0FBQ2pCLFlBQU0sV0FBcUIsQ0FBQztBQUM1QixZQUFNLGNBQXdDLENBQUM7QUFHL0MsaUJBQVcsQ0FBQyxVQUFVLEtBQUssS0FBSyxPQUFPLFFBQVEsY0FBYyxHQUFHO0FBQzlELG1CQUFXLFFBQVEsT0FBTztBQUN4QixjQUFJLENBQUMsU0FBUyxTQUFTLElBQUksR0FBRztBQUM1QixxQkFBUyxLQUFLLElBQUk7QUFDbEIsd0JBQVksSUFBSSxJQUFJLENBQUM7QUFBQSxVQUN2QjtBQUNBLHNCQUFZLElBQUksRUFBRSxLQUFLLFFBQVE7QUFBQSxRQUNqQztBQUFBLE1BQ0Y7QUFHQSxlQUFTLEtBQUs7QUFHZCxVQUFJLFVBQVUsd0JBQXdCO0FBQUE7QUFBQTtBQUN0QyxpQkFBVyx1QkFBdUIsU0FBUztBQUFBO0FBQUE7QUFFM0MsaUJBQVcsUUFBUSxVQUFVO0FBQzNCLG1CQUFXLE1BQU07QUFBQTtBQUNqQixtQkFBVyxnQkFBZ0IsWUFBWSxJQUFJLEVBQUUsS0FBSyxJQUFJO0FBQUE7QUFBQTtBQUN0RCxtQkFBVztBQUFBO0FBQUE7QUFDWCxtQkFBVztBQUFBO0FBQUE7QUFDWCxtQkFBVztBQUFBO0FBQUE7QUFDWCxtQkFBVztBQUFBO0FBQUE7QUFBQSxNQUNiO0FBRUEsYUFBTztBQUFBLElBQ1Q7QUFBQTtBQUFBLEVBRU0sMEJBQTBCLFVBQWlDO0FBQUE7QUFDL0QsVUFBSTtBQUNGLGNBQU0saUJBQWlCLE1BQU0sS0FBSyw0QkFBNEIsUUFBUTtBQUV0RSxZQUFJLE9BQU8sS0FBSyxjQUFjLEVBQUUsV0FBVyxHQUFHO0FBQzVDLGtCQUFRLElBQUksbUNBQW1DLFVBQVU7QUFDekQ7QUFBQSxRQUNGO0FBRUEsY0FBTSxlQUFlLE1BQU0sS0FBSztBQUFBLFVBQzlCO0FBQUEsVUFDQTtBQUFBLFFBQ0Y7QUFHQSxjQUFNLFdBQVcsR0FBRztBQUNwQixjQUFNLFdBQVcsV0FBVyxZQUFZO0FBRXhDLFlBQUk7QUFDRixnQkFBTSxLQUFLLElBQUksTUFBTSxPQUFPLFVBQVUsWUFBWTtBQUNsRCxrQkFBUSxJQUFJLGtDQUFrQyxVQUFVO0FBQUEsUUFDMUQsU0FBUyxPQUFQO0FBRUEsZ0JBQU0sZUFBZSxLQUFLLElBQUksTUFBTSxzQkFBc0IsUUFBUTtBQUNsRSxjQUFJLGdCQUFnQix3QkFBd0Isd0JBQU87QUFDakQsa0JBQU0sS0FBSyxJQUFJLE1BQU0sT0FBTyxjQUFjLFlBQVk7QUFDdEQsb0JBQVEsSUFBSSxrQ0FBa0MsVUFBVTtBQUFBLFVBQzFEO0FBQUEsUUFDRjtBQUFBLE1BQ0YsU0FBUyxPQUFQO0FBQ0EsZ0JBQVE7QUFBQSxVQUNOLDhDQUE4QztBQUFBLFVBQzlDO0FBQUEsUUFDRjtBQUNBLGNBQU07QUFBQSxNQUNSO0FBQUEsSUFDRjtBQUFBO0FBQ0Y7OztBQ3JNQSxJQUFBQyxtQkFBMkI7QUFHcEIsSUFBTSxpQkFBTixNQUFxQjtBQUFBLEVBRzFCLFlBQVksS0FBVTtBQUNwQixTQUFLLE1BQU07QUFBQSxFQUNiO0FBQUEsRUFFQSxzQkFDRSxTQUM2RDtBQUU3RCxVQUFNLGdCQUFnQjtBQUN0QixVQUFNLFVBQVUsbUNBQVMsTUFBTTtBQUUvQixRQUFJLENBQUMsU0FBUztBQUNaLGFBQU8sQ0FBQztBQUFBLElBQ1Y7QUFFQSxVQUFNLGtCQUFrQixRQUFRLENBQUM7QUFDakMsVUFBTSxXQUFXLENBQUM7QUFHbEIsVUFBTSxhQUFhO0FBQ25CLFVBQU0sZUFBZSxnQkFBZ0IsTUFBTSxVQUFVO0FBRXJELFFBQUksY0FBYztBQUNoQixpQkFBVyxTQUFTLGNBQWM7QUFDaEMsY0FBTSxPQUFPLE1BQ1YsS0FBSyxFQUNMLE1BQU0sSUFBSSxFQUNWLE9BQU8sQ0FBQyxRQUFRLElBQUksV0FBVyxHQUFHLENBQUM7QUFDdEMsY0FBTSxhQUFhLEtBQUssZUFBZSxJQUFJO0FBQzNDLGlCQUFTLEtBQUssR0FBRyxVQUFVO0FBQUEsTUFDN0I7QUFBQSxJQUNGO0FBRUEsV0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUVRLGVBQ04sTUFDNkQ7QUFDN0QsUUFBSSxLQUFLLFNBQVM7QUFBRyxhQUFPLENBQUM7QUFFN0IsVUFBTSxXQUFXLENBQUM7QUFFbEIsYUFBUyxJQUFJLEdBQUcsSUFBSSxLQUFLLFFBQVEsS0FBSztBQUVwQyxZQUFNLE1BQU0sS0FBSyxDQUFDO0FBQ2xCLFlBQU0sVUFBVSxJQUNiLE1BQU0sR0FBRyxFQUNULElBQUksQ0FBQyxRQUFRLElBQUksS0FBSyxDQUFDLEVBQ3ZCLE9BQU8sQ0FBQyxRQUFRLEdBQUc7QUFFdEIsVUFBSSxRQUFRLFVBQVUsR0FBRztBQUN2QixjQUFNLENBQUMsTUFBTSxZQUFZLFNBQVMsU0FBUyxJQUFJO0FBQy9DLFlBQUksUUFBUSxjQUFjLEtBQUssWUFBWSxJQUFJLEdBQUc7QUFDaEQsbUJBQVMsS0FBSyxFQUFFLE1BQU0sWUFBWSxPQUFPLENBQUM7QUFBQSxRQUM1QztBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBRUEsV0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUVRLFlBQVksWUFBNkI7QUFDL0MsVUFBTSxZQUFZO0FBQ2xCLFdBQU8sVUFBVSxLQUFLLFVBQVUsS0FBSyxDQUFDLE1BQU0sS0FBSyxNQUFNLFVBQVUsQ0FBQztBQUFBLEVBQ3BFO0FBQUEsRUFFTSx3QkFDSixVQUNBLFdBQ0EsU0FHQTtBQUFBO0FBQ0EsY0FBUSxJQUFJLGlDQUFpQyxVQUFVO0FBRXZELFVBQUk7QUFFRixjQUFNLGNBQWMsTUFBTSxLQUFLLGdCQUFnQixRQUFRO0FBRXZELFlBQUksWUFBWSxXQUFXLEdBQUc7QUFDNUIsa0JBQVEsSUFBSSw4QkFBOEIsVUFBVTtBQUNwRCxpQkFBTyxDQUFDO0FBQUEsUUFDVjtBQUdBLGNBQU0sY0FLRCxDQUFDO0FBRU4sbUJBQVcsUUFBUSxhQUFhO0FBQzlCLGNBQUk7QUFDRixrQkFBTSxVQUFVLE1BQU0sS0FBSyxJQUFJLE1BQU0sS0FBSyxJQUFJO0FBQzlDLGtCQUFNLFdBQVcsS0FBSyxzQkFBc0IsT0FBTztBQUduRCxrQkFBTSxxQkFBcUIsU0FBUyxJQUFJLENBQUMsWUFBYSxpQ0FDakQsVUFEaUQ7QUFBQSxjQUVwRCxRQUFRLEtBQUs7QUFBQSxZQUNmLEVBQUU7QUFFRix3QkFBWSxLQUFLLEdBQUcsa0JBQWtCO0FBQUEsVUFDeEMsU0FBUyxPQUFQO0FBQ0Esb0JBQVEsTUFBTSxzQkFBc0IsS0FBSyxTQUFTLEtBQUs7QUFBQSxVQUN6RDtBQUFBLFFBQ0Y7QUFHQSxZQUFJLG1CQUFtQjtBQUN2QixZQUFJLGFBQWEsU0FBUztBQUN4Qiw2QkFBbUIsS0FBSztBQUFBLFlBQ3RCO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUdBLHlCQUFpQjtBQUFBLFVBQ2YsQ0FBQyxHQUFHLE1BQU0sSUFBSSxLQUFLLEVBQUUsSUFBSSxFQUFFLFFBQVEsSUFBSSxJQUFJLEtBQUssRUFBRSxJQUFJLEVBQUUsUUFBUTtBQUFBLFFBQ2xFO0FBRUEsZ0JBQVE7QUFBQSxVQUNOLFNBQVMsaUJBQWlCLGdDQUFnQztBQUFBLFFBQzVEO0FBQ0EsZUFBTztBQUFBLE1BQ1QsU0FBUyxPQUFQO0FBQ0EsZ0JBQVEsTUFBTSxzQ0FBc0MsYUFBYSxLQUFLO0FBQ3RFLGVBQU8sQ0FBQztBQUFBLE1BQ1Y7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVjLGdCQUFnQixVQUFvQztBQUFBO0FBQ2hFLFlBQU0sUUFBaUIsQ0FBQztBQUd4QixZQUFNLFFBQVEsS0FBSyxJQUFJLE1BQU0saUJBQWlCO0FBRTlDLGlCQUFXLFFBQVEsT0FBTztBQUV4QixZQUNFLEtBQUssS0FBSyxTQUFTLFFBQVEsTUFDMUIsTUFBTSxLQUFLLG9CQUFvQixNQUFNLFFBQVEsSUFDOUM7QUFDQSxnQkFBTSxLQUFLLElBQUk7QUFBQSxRQUNqQjtBQUFBLE1BQ0Y7QUFFQSxhQUFPO0FBQUEsSUFDVDtBQUFBO0FBQUEsRUFFYyxvQkFDWixNQUNBLFVBQ2tCO0FBQUE7QUFDbEIsVUFBSTtBQUNGLGNBQU0sVUFBVSxNQUFNLEtBQUssSUFBSSxNQUFNLEtBQUssSUFBSTtBQUM5QyxjQUFNLG1CQUFtQixRQUFRLE1BQU0sdUJBQXVCO0FBRTlELFlBQUksa0JBQWtCO0FBQ3BCLGdCQUFNLGNBQWMsaUJBQWlCLENBQUM7QUFFdEMsaUJBQ0UsWUFBWSxTQUFTLGNBQWMsVUFBVSxLQUM3QyxZQUFZLFNBQVMsYUFBYSxVQUFVO0FBQUEsUUFFaEQ7QUFFQSxlQUFPO0FBQUEsTUFDVCxTQUFTLE9BQVA7QUFDQSxnQkFBUTtBQUFBLFVBQ04sMEJBQTBCLEtBQUssMEJBQTBCO0FBQUEsVUFDekQ7QUFBQSxRQUNGO0FBQ0EsZUFBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVRLGtCQUNOLFVBTUEsV0FDQSxTQU1DO0FBQ0QsV0FBTyxTQUFTLE9BQU8sQ0FBQyxZQUFZO0FBQ2xDLFlBQU0sY0FBYyxJQUFJLEtBQUssUUFBUSxJQUFJLEVBQUUsUUFBUTtBQUVuRCxVQUFJLGFBQWEsY0FBYyxJQUFJLEtBQUssU0FBUyxFQUFFLFFBQVEsR0FBRztBQUM1RCxlQUFPO0FBQUEsTUFDVDtBQUVBLFVBQUksV0FBVyxjQUFjLElBQUksS0FBSyxPQUFPLEVBQUUsUUFBUSxHQUFHO0FBQ3hELGVBQU87QUFBQSxNQUNUO0FBRUEsYUFBTztBQUFBLElBQ1QsQ0FBQztBQUFBLEVBQ0g7QUFBQSxFQUVNLHdCQUNKLFVBQ0EsVUFNaUI7QUFBQTtBQUNqQixVQUFJLFNBQVMsV0FBVyxHQUFHO0FBQ3pCLGVBQU8seUJBQXlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFDbEM7QUFHQSxZQUFNLFdBQVcsU0FBUyxPQUFPLENBQUMsS0FBSyxZQUFZO0FBQ2pELFlBQUksQ0FBQyxJQUFJLFFBQVEsTUFBTSxHQUFHO0FBQ3hCLGNBQUksUUFBUSxNQUFNLElBQUksQ0FBQztBQUFBLFFBQ3pCO0FBQ0EsWUFBSSxRQUFRLE1BQU0sRUFBRSxLQUFLLE9BQU87QUFDaEMsZUFBTztBQUFBLE1BQ1QsR0FBRyxDQUFDLENBQW9DO0FBRXhDLFVBQUksVUFBVSx5QkFBeUI7QUFBQTtBQUFBO0FBQ3ZDLGlCQUFXLHNCQUFzQixTQUFTO0FBQUE7QUFBQTtBQUcxQyxpQkFBVyxDQUFDLFFBQVEsS0FBSyxLQUFLLE9BQU8sUUFBUSxRQUFRLEdBQUc7QUFDdEQsbUJBQVcsTUFBTSxPQUFPLE9BQU8sQ0FBQyxFQUFFLFlBQVksSUFBSSxPQUFPLE1BQU0sQ0FBQyxNQUM5RCxNQUFNO0FBQUE7QUFBQTtBQUVSLG1CQUFXO0FBQUE7QUFDWCxtQkFBVztBQUFBO0FBRVgsbUJBQVcsUUFBUSxPQUFPO0FBQ3hCLHFCQUFXLEtBQUssS0FBSyxVQUFVLEtBQUssZ0JBQWdCLEtBQUs7QUFBQTtBQUFBLFFBQzNEO0FBQ0EsbUJBQVc7QUFBQTtBQUFBLE1BQ2I7QUFFQSxhQUFPO0FBQUEsSUFDVDtBQUFBO0FBQUEsRUFFTSwwQkFDSixVQUNBLFdBQ0EsU0FDZTtBQUFBO0FBQ2YsVUFBSTtBQUNGLGNBQU0sV0FBVyxNQUFNLEtBQUs7QUFBQSxVQUMxQjtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsUUFDRjtBQUVBLGNBQU0saUJBQWlCLE1BQU0sS0FBSztBQUFBLFVBQ2hDO0FBQUEsVUFDQTtBQUFBLFFBQ0Y7QUFHQSxjQUFNLFdBQVcsR0FBRztBQUNwQixjQUFNLFdBQVcsV0FBVyxZQUFZO0FBRXhDLFlBQUk7QUFDRixnQkFBTSxLQUFLLElBQUksTUFBTSxPQUFPLFVBQVUsY0FBYztBQUNwRCxrQkFBUSxJQUFJLG1DQUFtQyxVQUFVO0FBQUEsUUFDM0QsU0FBUyxPQUFQO0FBRUEsZ0JBQU0sZUFBZSxLQUFLLElBQUksTUFBTSxzQkFBc0IsUUFBUTtBQUNsRSxjQUFJLGdCQUFnQix3QkFBd0Isd0JBQU87QUFDakQsa0JBQU0sS0FBSyxJQUFJLE1BQU0sT0FBTyxjQUFjLGNBQWM7QUFDeEQsb0JBQVEsSUFBSSxtQ0FBbUMsVUFBVTtBQUFBLFVBQzNEO0FBQUEsUUFDRjtBQUFBLE1BQ0YsU0FBUyxPQUFQO0FBQ0EsZ0JBQVE7QUFBQSxVQUNOLCtDQUErQztBQUFBLFVBQy9DO0FBQUEsUUFDRjtBQUNBLGNBQU07QUFBQSxNQUNSO0FBQUEsSUFDRjtBQUFBO0FBQ0Y7OztBQ3pTQSxJQUFBQyxtQkFBMkI7QUFFcEIsSUFBTSx3QkFBTixNQUE0QjtBQUFBLEVBR2pDLFlBQVksS0FBVTtBQUNwQixTQUFLLE1BQU07QUFBQSxFQUNiO0FBQUEsRUFFTSxzQkFFSjtBQUFBO0FBQ0EsY0FBUSxJQUFJLHFDQUFxQztBQUVqRCxVQUFJO0FBQ0YsY0FBTSxRQUFRLElBQUksS0FBSztBQUN2QixjQUFNLGNBQWMsTUFBTSxZQUFZLEVBQUUsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUdwRCxjQUFNLFFBQVEsS0FBSyxJQUFJLE1BQU0saUJBQWlCO0FBQzlDLGNBQU0sY0FBdUIsQ0FBQztBQUU5QixtQkFBVyxRQUFRLE9BQU87QUFDeEIsZ0JBQU0sV0FBVyxLQUFLLG9CQUFvQixLQUFLLElBQUk7QUFDbkQsY0FBSSxhQUFhLGFBQWE7QUFDNUIsd0JBQVksS0FBSyxJQUFJO0FBQUEsVUFDdkI7QUFBQSxRQUNGO0FBR0EsY0FBTSxhQUNKLENBQUM7QUFFSCxtQkFBVyxRQUFRLGFBQWE7QUFDOUIsZ0JBQU0sV0FBVyxNQUFNLEtBQUssb0JBQW9CLElBQUk7QUFDcEQsY0FBSSxVQUFVO0FBQ1osdUJBQVcsS0FBSyxRQUFRO0FBQUEsVUFDMUI7QUFBQSxRQUNGO0FBRUEsZ0JBQVEsSUFBSSxTQUFTLFdBQVcsc0NBQXNDO0FBQ3RFLGVBQU87QUFBQSxNQUNULFNBQVMsT0FBUDtBQUNBLGdCQUFRLE1BQU0scUNBQXFDLEtBQUs7QUFDeEQsZUFBTyxDQUFDO0FBQUEsTUFDVjtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRU0seUJBQ0osVUFDQSxNQUNnRDtBQUFBO0FBQ2hELGNBQVEsSUFBSSwrQkFBK0Isb0JBQW9CLE1BQU07QUFFckUsVUFBSTtBQUVGLGNBQU0sY0FBYyxNQUFNLEtBQUssdUJBQXVCLFVBQVUsSUFBSTtBQUVwRSxjQUFNLGFBQW9ELENBQUM7QUFFM0QsbUJBQVcsUUFBUSxhQUFhO0FBQzlCLGdCQUFNLFVBQVUsTUFBTSxLQUFLLElBQUksTUFBTSxLQUFLLElBQUk7QUFDOUMsZ0JBQU0sV0FBVyxLQUFLLGtCQUFrQixNQUFNLE9BQU87QUFFckQscUJBQVcsS0FBSztBQUFBLFlBQ2QsTUFBTSxLQUFLO0FBQUEsWUFDWCxNQUFNO0FBQUEsVUFDUixDQUFDO0FBQUEsUUFDSDtBQUVBLGdCQUFRO0FBQUEsVUFDTixTQUFTLFdBQVcsZ0NBQWdDLGVBQWU7QUFBQSxRQUNyRTtBQUNBLGVBQU87QUFBQSxNQUNULFNBQVMsT0FBUDtBQUNBLGdCQUFRO0FBQUEsVUFDTixxQ0FBcUMsZUFBZTtBQUFBLFVBQ3BEO0FBQUEsUUFDRjtBQUNBLGVBQU8sQ0FBQztBQUFBLE1BQ1Y7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVRLG9CQUFvQixVQUFpQztBQUUzRCxVQUFNLFlBQVk7QUFDbEIsVUFBTSxVQUFVLFNBQVMsTUFBTSxTQUFTO0FBQ3hDLFdBQU8sVUFBVSxRQUFRLFFBQVEsU0FBUyxDQUFDLElBQUk7QUFBQSxFQUNqRDtBQUFBLEVBRWMsb0JBQ1osTUFDaUU7QUFBQTtBQUNqRSxVQUFJO0FBQ0YsY0FBTSxVQUFVLE1BQU0sS0FBSyxJQUFJLE1BQU0sS0FBSyxJQUFJO0FBRzlDLGNBQU0sV0FBVyxLQUFLLGtCQUFrQixNQUFNLE9BQU87QUFHckQsY0FBTSxXQUNKLEtBQUssMkJBQTJCLE9BQU8sS0FDdkMsS0FBSyx3QkFBd0IsS0FBSyxJQUFJO0FBRXhDLGVBQU87QUFBQSxVQUNMLE1BQU0sS0FBSztBQUFBLFVBQ1gsTUFBTTtBQUFBLFVBQ04sUUFBUSxZQUFZO0FBQUEsUUFDdEI7QUFBQSxNQUNGLFNBQVMsT0FBUDtBQUNBLGdCQUFRLE1BQU0sd0JBQXdCLEtBQUssU0FBUyxLQUFLO0FBQ3pELGVBQU87QUFBQSxNQUNUO0FBQUEsSUFDRjtBQUFBO0FBQUEsRUFFUSxrQkFBa0IsTUFBYSxTQUF5QjtBQUM5RCxVQUFNLE9BQU8sS0FBSyxLQUFLLFlBQVk7QUFHbkMsUUFDRSxLQUFLLFNBQVMsT0FBTyxLQUNyQixRQUFRLFNBQVMsMEJBQTBCLEdBQzNDO0FBQ0EsYUFBTztBQUFBLElBQ1Q7QUFHQSxRQUFJLEtBQUssU0FBUyxTQUFTLEtBQUssUUFBUSxTQUFTLFlBQVksR0FBRztBQUM5RCxVQUFJLFFBQVEsU0FBUywrQkFBK0IsR0FBRztBQUNyRCxlQUFPO0FBQUEsTUFDVDtBQUNBLFVBQUksUUFBUSxTQUFTLHNCQUFzQixHQUFHO0FBQzVDLGVBQU87QUFBQSxNQUNUO0FBQ0EsVUFBSSxRQUFRLFNBQVMsdUJBQXVCLEdBQUc7QUFDN0MsZUFBTztBQUFBLE1BQ1Q7QUFDQSxVQUFJLFFBQVEsU0FBUywwQkFBMEIsR0FBRztBQUNoRCxlQUFPO0FBQUEsTUFDVDtBQUNBLGFBQU87QUFBQSxJQUNUO0FBR0EsUUFBSSxRQUFRLFNBQVMsS0FBSyxLQUFLLFFBQVEsTUFBTSxpQkFBaUIsR0FBRztBQUMvRCxhQUFPO0FBQUEsSUFDVDtBQUVBLFdBQU87QUFBQSxFQUNUO0FBQUEsRUFFUSwyQkFBMkIsU0FBZ0M7QUFDakUsVUFBTSxnQkFBZ0I7QUFDdEIsVUFBTSxRQUFRLFFBQVEsTUFBTSxhQUFhO0FBQ3pDLFdBQU8sUUFBUSxNQUFNLENBQUMsSUFBSTtBQUFBLEVBQzVCO0FBQUEsRUFFUSx3QkFBd0IsVUFBaUM7QUFDL0QsVUFBTSxnQkFBZ0I7QUFDdEIsVUFBTSxVQUFVLFNBQVMsTUFBTSxhQUFhO0FBQzVDLFdBQU8sVUFBVSxRQUFRLFFBQVEsU0FBUyxDQUFDLElBQUk7QUFBQSxFQUNqRDtBQUFBLEVBRWMsdUJBQ1osVUFDQSxNQUNrQjtBQUFBO0FBQ2xCLFlBQU0sUUFBaUIsQ0FBQztBQUd4QixZQUFNLFdBQVcsS0FBSyxJQUFJLE1BQU0saUJBQWlCO0FBRWpELGlCQUFXLFFBQVEsVUFBVTtBQUUzQixZQUNFLEtBQUssS0FBSyxTQUFTLFFBQVEsTUFDMUIsTUFBTSxLQUFLLG9CQUFvQixNQUFNLFFBQVEsSUFDOUM7QUFFQSxnQkFBTSxXQUFXLEtBQUssb0JBQW9CLEtBQUssSUFBSTtBQUNuRCxjQUFJLGFBQWEsTUFBTTtBQUNyQixrQkFBTSxLQUFLLElBQUk7QUFBQSxVQUNqQjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBRUEsYUFBTztBQUFBLElBQ1Q7QUFBQTtBQUFBLEVBRWMsb0JBQ1osTUFDQSxVQUNrQjtBQUFBO0FBQ2xCLFVBQUk7QUFDRixjQUFNLFVBQVUsTUFBTSxLQUFLLElBQUksTUFBTSxLQUFLLElBQUk7QUFDOUMsZUFBTyxLQUFLLDJCQUEyQixPQUFPLE1BQU07QUFBQSxNQUN0RCxTQUFTLE9BQVA7QUFDQSxnQkFBUTtBQUFBLFVBQ04sMEJBQTBCLEtBQUssMEJBQTBCO0FBQUEsVUFDekQ7QUFBQSxRQUNGO0FBQ0EsZUFBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVNLHFCQUFxQixNQUFnQztBQUFBO0FBQ3pELFlBQU0sYUFBYSxRQUFRLElBQUksS0FBSyxFQUFFLFlBQVksRUFBRSxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQ2hFLFlBQU0sYUFBYSxNQUFNLEtBQUsseUJBQXlCLElBQUksVUFBVTtBQUVyRSxVQUFJLFdBQVcsV0FBVyxHQUFHO0FBQzNCLGVBQU8sMkJBQTJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFDcEM7QUFHQSxZQUFNLFdBQThDLENBQUM7QUFDckQsWUFBTSxXQUE4QixDQUFDO0FBRXJDLGlCQUFXLFlBQVksWUFBWTtBQUNqQyxZQUFJLFNBQVMsS0FBSyxTQUFTLFVBQVUsR0FBRztBQUV0QyxnQkFBTSxZQUFZLFNBQVMsS0FBSyxNQUFNLEdBQUc7QUFDekMsZ0JBQU0sY0FBYyxVQUFVLFVBQVUsQ0FBQyxTQUFTLEtBQUssU0FBUyxHQUFHLENBQUM7QUFDcEUsY0FBSSxlQUFlLEdBQUc7QUFDcEIsa0JBQU0sV0FBVyxVQUFVLFdBQVc7QUFDdEMsZ0JBQUksQ0FBQyxTQUFTLFFBQVEsR0FBRztBQUN2Qix1QkFBUyxRQUFRLElBQUksQ0FBQztBQUFBLFlBQ3hCO0FBQ0EscUJBQVMsUUFBUSxFQUFFLEtBQUssUUFBUTtBQUFBLFVBQ2xDLE9BQU87QUFDTCxxQkFBUyxLQUFLLFFBQVE7QUFBQSxVQUN4QjtBQUFBLFFBQ0YsT0FBTztBQUNMLG1CQUFTLEtBQUssUUFBUTtBQUFBLFFBQ3hCO0FBQUEsTUFDRjtBQUVBLFVBQUksVUFBVSwyQkFBMkI7QUFBQTtBQUFBO0FBQ3pDLGlCQUFXLHFCQUFxQixXQUFXO0FBQUE7QUFBQTtBQUczQyxpQkFBVyxDQUFDLFVBQVUsZ0JBQWdCLEtBQUssT0FBTyxRQUFRLFFBQVEsR0FBRztBQUNuRSxtQkFBVyxNQUFNO0FBQUE7QUFBQTtBQUNqQixtQkFBVztBQUFBO0FBQ1gsbUJBQVc7QUFBQTtBQUVYLG1CQUFXLFlBQVksa0JBQWtCO0FBQ3ZDLHFCQUFXLEtBQUssU0FBUyxVQUFVLFNBQVM7QUFBQTtBQUFBLFFBQzlDO0FBQ0EsbUJBQVc7QUFBQTtBQUFBLE1BQ2I7QUFHQSxVQUFJLFNBQVMsU0FBUyxHQUFHO0FBQ3ZCLG1CQUFXO0FBQUE7QUFBQTtBQUNYLG1CQUFXO0FBQUE7QUFDWCxtQkFBVztBQUFBO0FBRVgsbUJBQVcsWUFBWSxVQUFVO0FBQy9CLHFCQUFXLEtBQUssU0FBUyxVQUFVLFNBQVM7QUFBQTtBQUFBLFFBQzlDO0FBQ0EsbUJBQVc7QUFBQTtBQUFBLE1BQ2I7QUFFQSxhQUFPO0FBQUEsSUFDVDtBQUFBO0FBQUEsRUFFTSx1QkFBdUIsTUFBOEI7QUFBQTtBQUN6RCxVQUFJO0FBQ0YsY0FBTSxhQUFhLFFBQVEsSUFBSSxLQUFLLEVBQUUsWUFBWSxFQUFFLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFDaEUsY0FBTSxpQkFBaUIsTUFBTSxLQUFLLHFCQUFxQixVQUFVO0FBR2pFLGNBQU0sV0FBVyxHQUFHO0FBQ3BCLGNBQU0sV0FBVyxTQUFTO0FBRTFCLFlBQUk7QUFDRixnQkFBTSxLQUFLLElBQUksTUFBTSxPQUFPLFVBQVUsY0FBYztBQUNwRCxrQkFBUSxJQUFJLCtCQUErQixVQUFVO0FBQUEsUUFDdkQsU0FBUyxPQUFQO0FBRUEsZ0JBQU0sZUFBZSxLQUFLLElBQUksTUFBTSxzQkFBc0IsUUFBUTtBQUNsRSxjQUFJLGdCQUFnQix3QkFBd0Isd0JBQU87QUFDakQsa0JBQU0sS0FBSyxJQUFJLE1BQU0sT0FBTyxjQUFjLGNBQWM7QUFDeEQsb0JBQVEsSUFBSSwrQkFBK0IsVUFBVTtBQUFBLFVBQ3ZEO0FBQUEsUUFDRjtBQUFBLE1BQ0YsU0FBUyxPQUFQO0FBQ0EsZ0JBQVEsTUFBTSxvQ0FBb0MsU0FBUyxLQUFLO0FBQ2hFLGNBQU07QUFBQSxNQUNSO0FBQUEsSUFDRjtBQUFBO0FBQ0Y7OztBUHpSQSxJQUFxQixxQkFBckIsY0FBZ0Qsd0JBQU87QUFBQSxFQVEvQyxTQUFTO0FBQUE7QUFDYixjQUFRLElBQUksOEJBQThCO0FBRzFDLFlBQU0sS0FBSyxhQUFhO0FBR3hCLFdBQUssa0JBQWtCLElBQUksZ0JBQWdCLEtBQUssS0FBSyxLQUFLLFFBQVE7QUFDbEUsV0FBSyxlQUFlLElBQUkscUJBQXFCLEtBQUssS0FBSyxLQUFLLFFBQVE7QUFDcEUsV0FBSyxzQkFBc0IsSUFBSSxvQkFBb0IsS0FBSyxHQUFHO0FBQzNELFdBQUssaUJBQWlCLElBQUksZUFBZSxLQUFLLEdBQUc7QUFDakQsV0FBSyx3QkFBd0IsSUFBSSxzQkFBc0IsS0FBSyxHQUFHO0FBRy9ELFdBQUssY0FBYyxJQUFJLHVCQUF1QixLQUFLLEtBQUssSUFBSSxDQUFDO0FBRzdELFdBQUssNkJBQTZCO0FBR2xDLFdBQUssV0FBVztBQUFBLFFBQ2QsSUFBSTtBQUFBLFFBQ0osTUFBTTtBQUFBLFFBQ04sVUFBVSxNQUFNO0FBQ2QsZUFBSyxnQkFBZ0IsaUJBQWlCO0FBQUEsUUFDeEM7QUFBQSxNQUNGLENBQUM7QUFFRCxXQUFLLFdBQVc7QUFBQSxRQUNkLElBQUk7QUFBQSxRQUNKLE1BQU07QUFBQSxRQUNOLFVBQVUsTUFBTTtBQUNkLGVBQUssZ0JBQWdCLGdCQUFnQjtBQUFBLFFBQ3ZDO0FBQUEsTUFDRixDQUFDO0FBRUQsV0FBSyxXQUFXO0FBQUEsUUFDZCxJQUFJO0FBQUEsUUFDSixNQUFNO0FBQUEsUUFDTixVQUFVLE1BQU07QUFDZCxlQUFLLGFBQWEscUJBQXFCO0FBQUEsUUFDekM7QUFBQSxNQUNGLENBQUM7QUFFRCxXQUFLLFdBQVc7QUFBQSxRQUNkLElBQUk7QUFBQSxRQUNKLE1BQU07QUFBQSxRQUNOLFVBQVUsTUFBWTtBQUNwQixnQkFBTSxXQUFXLE1BQU0sS0FBSztBQUFBLFlBQzFCO0FBQUEsVUFDRjtBQUNBLGNBQUksVUFBVTtBQUNaLGtCQUFNLEtBQUssb0JBQW9CLDBCQUEwQixRQUFRO0FBQUEsVUFDbkU7QUFBQSxRQUNGO0FBQUEsTUFDRixDQUFDO0FBRUQsV0FBSyxXQUFXO0FBQUEsUUFDZCxJQUFJO0FBQUEsUUFDSixNQUFNO0FBQUEsUUFDTixVQUFVLE1BQVk7QUFDcEIsZ0JBQU0sV0FBVyxNQUFNLEtBQUs7QUFBQSxZQUMxQjtBQUFBLFVBQ0Y7QUFDQSxjQUFJLFVBQVU7QUFDWixrQkFBTSxLQUFLLGVBQWUsMEJBQTBCLFFBQVE7QUFBQSxVQUM5RDtBQUFBLFFBQ0Y7QUFBQSxNQUNGLENBQUM7QUFFRCxXQUFLLFdBQVc7QUFBQSxRQUNkLElBQUk7QUFBQSxRQUNKLE1BQU07QUFBQSxRQUNOLFVBQVUsTUFBWTtBQUNwQixnQkFBTSxPQUFPLE1BQU0sS0FBSztBQUFBLFlBQ3RCO0FBQUEsVUFDRjtBQUNBLGdCQUFNLEtBQUssc0JBQXNCO0FBQUEsWUFDL0IsUUFBUTtBQUFBLFVBQ1Y7QUFBQSxRQUNGO0FBQUEsTUFDRixDQUFDO0FBR0QsV0FBSyxpQkFBaUIsRUFBRSxRQUFRLGVBQWU7QUFBQSxJQUNqRDtBQUFBO0FBQUEsRUFFYyxrQkFBa0IsU0FBeUM7QUFBQTtBQUN2RSxZQUFNLFdBQVcsT0FBTyxVQUFVLHNCQUFzQjtBQUN4RCxhQUFPLFdBQVcsU0FBUyxLQUFLLElBQUk7QUFBQSxJQUN0QztBQUFBO0FBQUEsRUFFYyxjQUFjLFNBQXlDO0FBQUE7QUFDbkUsWUFBTSxPQUFPO0FBQUEsUUFDWCxVQUFVO0FBQUEsTUFDWjtBQUNBLGFBQU8sT0FBTyxLQUFLLEtBQUssSUFBSTtBQUFBLElBQzlCO0FBQUE7QUFBQSxFQUVBLFdBQVc7QUFDVCxZQUFRLElBQUksZ0NBQWdDO0FBQUEsRUFDOUM7QUFBQSxFQUVNLCtCQUErQjtBQUFBO0FBRW5DLFlBQU0sa0JBQW1CLEtBQUssSUFBWSxRQUFRLFVBQVUsb0JBQW9CO0FBQ2hGLFVBQUksQ0FBQyxpQkFBaUI7QUFDcEIsZ0JBQVEsSUFBSSxzRUFBc0U7QUFDbEY7QUFBQSxNQUNGO0FBR0EsVUFBSTtBQUVGLFlBQUksbUJBQW1CLGdCQUFnQixXQUFXO0FBRWhELGNBQUksQ0FBQyxnQkFBZ0IsVUFBVSxXQUFXO0FBQ3hDLDRCQUFnQixVQUFVLFlBQVksQ0FBQztBQUFBLFVBQ3pDO0FBR0EsMEJBQWdCLFVBQVUsVUFBVSxZQUFZLElBQUksQ0FBTyxLQUFVLElBQVMsU0FBYztBQUMxRixtQkFBTyxLQUFLLGtCQUFrQixLQUFLLElBQUksSUFBSTtBQUFBLFVBQzdDO0FBRUEsMEJBQWdCLFVBQVUsVUFBVSxhQUFhLElBQUksQ0FBTyxPQUFZO0FBQ3RFLG1CQUFPLEtBQUssbUJBQW1CLEVBQUU7QUFBQSxVQUNuQztBQUVBLGtCQUFRLElBQUksMkRBQTJEO0FBQUEsUUFDekUsT0FBTztBQUNMLGtCQUFRLE1BQU0scUVBQXFFO0FBQUEsUUFDckY7QUFBQSxNQUNGLFNBQVMsR0FBUDtBQUNBLGdCQUFRLE1BQU0sMENBQTBDLENBQUM7QUFBQSxNQUMzRDtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRU0sa0JBQWtCLEtBQVUsSUFBUyxNQUFjO0FBQUE7QUE5SjNEO0FBZ0tJLFlBQU0sZUFBZSxNQUFNLEdBQUcsT0FBTyxPQUFPLDRCQUE0QixFQUFFO0FBQzFFLFlBQU0sYUFBYSxNQUFNLEdBQUcsT0FBTyxPQUFPLDBCQUEwQixFQUFFO0FBQ3RFLFlBQU0sU0FBUyxNQUFNLEdBQUcsT0FBTztBQUFBLFFBQzdCLE1BQU0sSUFBSSxNQUFNLGlCQUFpQixFQUFFLE9BQU8sQ0FBQyxNQUFXLEVBQUUsS0FBSyxTQUFTLFNBQVMsQ0FBQyxFQUFFLElBQUksQ0FBQyxNQUFXLEVBQUUsUUFBUTtBQUFBLFFBQzVHLElBQUksTUFBTSxpQkFBaUIsRUFBRSxPQUFPLENBQUMsTUFBVyxFQUFFLEtBQUssU0FBUyxTQUFTLENBQUM7QUFBQSxNQUM1RTtBQUNBLFlBQU0sV0FBVyxTQUFTLE9BQU8sTUFBTSxLQUFLLEVBQUUsQ0FBQyxLQUFLLFNBQVM7QUFDN0QsWUFBTSxhQUFhLFdBQVMsWUFBTyxNQUFNLEtBQUssRUFBRSxDQUFDLE1BQXJCLG1CQUF3QixVQUFVLEdBQUcsT0FBTSxRQUFRO0FBQy9FLFlBQU0sYUFBYSxDQUFDLFVBQVUsV0FBVyxhQUFhLFlBQVksVUFBVSxZQUFZLFFBQVE7QUFDaEcsWUFBTSxZQUFZLE1BQU0sR0FBRyxPQUFPLFVBQVUsWUFBWSxZQUFZLGFBQWE7QUFFakYsYUFBTztBQUFBLFFBQ0wsUUFBUTtBQUFBO0FBQUEsUUFDUixjQUFjLGdCQUFnQjtBQUFBLFFBQzlCLFlBQVksY0FBYztBQUFBLFFBQzFCO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRU0sbUJBQW1CLElBQVM7QUFBQTtBQXRMcEM7QUF1TEksWUFBTSxnQkFBZ0IsTUFBTSxHQUFHLE9BQU8sT0FBTyxrQkFBa0IsRUFBRTtBQUNqRSxZQUFNLFNBQVMsTUFBTSxHQUFHLE9BQU87QUFBQSxRQUM3QixNQUFNLEdBQUcsSUFBSSxNQUFNLGlCQUFpQixFQUFFLE9BQU8sQ0FBQyxNQUFXLEVBQUUsS0FBSyxTQUFTLFNBQVMsQ0FBQyxFQUFFLElBQUksQ0FBQyxNQUFXLEVBQUUsUUFBUTtBQUFBLFFBQy9HLEdBQUcsSUFBSSxNQUFNLGlCQUFpQixFQUFFLE9BQU8sQ0FBQyxNQUFXLEVBQUUsS0FBSyxTQUFTLFNBQVMsQ0FBQztBQUFBLE1BQy9FO0FBQ0EsWUFBTSxXQUFXLFNBQVMsT0FBTyxNQUFNLEtBQUssRUFBRSxDQUFDLEtBQUssU0FBUztBQUM3RCxZQUFNLGFBQWEsV0FBUyxZQUFPLE1BQU0sS0FBSyxFQUFFLENBQUMsTUFBckIsbUJBQXdCLFVBQVUsR0FBRyxPQUFNLFFBQVE7QUFDL0UsWUFBTSxjQUFjLEdBQUcsSUFBSSxNQUFNLFNBQVMsRUFBRSxPQUFPLENBQUMsTUFBVyxFQUFFLGNBQWMsS0FBSyxFQUFFLElBQUksQ0FBQyxNQUFXLEVBQUUsUUFBUTtBQUNoSCxZQUFNLE9BQU8sTUFBTSxHQUFHLE9BQU8sVUFBVSxhQUFhLGFBQWEsVUFBVTtBQUUzRSxhQUFPO0FBQUEsUUFDTCxlQUFlLGlCQUFpQjtBQUFBLFFBQ2hDO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRU0sZUFBZTtBQUFBO0FBQ25CLFdBQUssV0FBVyxPQUFPLE9BQU8sQ0FBQyxHQUFHLGtCQUFrQixNQUFNLEtBQUssU0FBUyxDQUFDO0FBQUEsSUFDM0U7QUFBQTtBQUFBLEVBRU0sZUFBZTtBQUFBO0FBQ25CLFlBQU0sS0FBSyxTQUFTLEtBQUssUUFBUTtBQUFBLElBQ25DO0FBQUE7QUFDRjsiLAogICJuYW1lcyI6IFsiaW1wb3J0X29ic2lkaWFuIiwgImltcG9ydF9vYnNpZGlhbiIsICJpbXBvcnRfb2JzaWRpYW4iLCAiaW1wb3J0X29ic2lkaWFuIiwgImltcG9ydF9vYnNpZGlhbiIsICJpbXBvcnRfb2JzaWRpYW4iXQp9Cg==
