var __defProp = Object.defineProperty;
var __defProps = Object.defineProperties;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getOwnPropSymbols = Object.getOwnPropertySymbols;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __propIsEnum = Object.prototype.propertyIsEnumerable;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __spreadValues = (a, b) => {
  for (var prop in b || (b = {}))
    if (__hasOwnProp.call(b, prop))
      __defNormalProp(a, prop, b[prop]);
  if (__getOwnPropSymbols)
    for (var prop of __getOwnPropSymbols(b)) {
      if (__propIsEnum.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    }
  return a;
};
var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __async = (__this, __arguments, generator) => {
  return new Promise((resolve, reject) => {
    var fulfilled = (value) => {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    };
    var rejected = (value) => {
      try {
        step(generator.throw(value));
      } catch (e) {
        reject(e);
      }
    };
    var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
    step((generator = generator.apply(__this, __arguments)).next());
  });
};

// main.ts
var main_exports = {};
__export(main_exports, {
  default: () => TuckersToolsPlugin
});
module.exports = __toCommonJS(main_exports);
var import_obsidian9 = require("obsidian");

// settings.ts
var import_obsidian = require("obsidian");

// utils.ts
function slugify(text) {
  return text.toLowerCase().trim().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9\s-]/g, "").replace(/[\s-]+/g, "-").replace(/^-+|-+$/g, "");
}
function validateDate(dateString) {
  const regex = /^\d{4}-\d{2}-\d{2}$/;
  if (!dateString.match(regex))
    return false;
  const date = new Date(dateString);
  const timestamp = date.getTime();
  if (typeof timestamp !== "number" || isNaN(timestamp))
    return false;
  return dateString === date.toISOString().split("T")[0];
}

// settings.ts
var DEFAULT_SETTINGS = {
  baseDirectory: "/",
  semesterStartDate: new Date().toISOString().split("T")[0],
  semesterEndDate: new Date(new Date().setMonth(new Date().getMonth() + 4)).toISOString().split("T")[0],
  schoolName: "University",
  schoolAbbreviation: "U",
  templateFolder: "Tuckers Tools",
  useEnhancedMetadata: false,
  dataviewJsPath: "/Supporting/dataview-functions"
};
var TuckersToolsSettingTab = class extends import_obsidian.PluginSettingTab {
  constructor(app, plugin) {
    super(app, plugin);
    this.plugin = plugin;
  }
  display() {
    const { containerEl } = this;
    containerEl.empty();
    containerEl.createEl("h2", { text: "Tuckers Tools Settings" });
    new import_obsidian.Setting(containerEl).setName("Base Directory").setDesc("Root directory for course content organization").addText((text) => text.setPlaceholder("/").setValue(this.plugin.settings.baseDirectory).onChange((value) => __async(this, null, function* () {
      this.plugin.settings.baseDirectory = value;
      yield this.plugin.saveSettings();
    })));
    const startDateSetting = new import_obsidian.Setting(containerEl).setName("Semester Start Date").setDesc("Start date for the current semester").addText((text) => text.setPlaceholder("YYYY-MM-DD").setValue(this.plugin.settings.semesterStartDate).onChange((value) => __async(this, null, function* () {
      if (value && !validateDate(value)) {
        startDateSetting.setDesc("Start date for the current semester (Invalid date format)");
      } else {
        startDateSetting.setDesc("Start date for the current semester");
      }
      this.plugin.settings.semesterStartDate = value;
      yield this.plugin.saveSettings();
    })));
    const endDateSetting = new import_obsidian.Setting(containerEl).setName("Semester End Date").setDesc("End date for the current semester").addText((text) => text.setPlaceholder("YYYY-MM-DD").setValue(this.plugin.settings.semesterEndDate).onChange((value) => __async(this, null, function* () {
      if (value && !validateDate(value)) {
        endDateSetting.setDesc("End date for the current semester (Invalid date format)");
      } else {
        endDateSetting.setDesc("End date for the current semester");
      }
      this.plugin.settings.semesterEndDate = value;
      yield this.plugin.saveSettings();
    })));
    new import_obsidian.Setting(containerEl).setName("School Name").setDesc("Name of your institution").addText((text) => text.setPlaceholder("University").setValue(this.plugin.settings.schoolName).onChange((value) => __async(this, null, function* () {
      this.plugin.settings.schoolName = value;
      yield this.plugin.saveSettings();
    })));
    new import_obsidian.Setting(containerEl).setName("School Abbreviation").setDesc("Abbreviation for your institution").addText((text) => text.setPlaceholder("U").setValue(this.plugin.settings.schoolAbbreviation).onChange((value) => __async(this, null, function* () {
      this.plugin.settings.schoolAbbreviation = value;
      yield this.plugin.saveSettings();
    })));
    new import_obsidian.Setting(containerEl).setName("Template Folder").setDesc("Subfolder within your Templater template folder for Tuckers Tools templates").addText((text) => text.setPlaceholder("Tuckers Tools").setValue(this.plugin.settings.templateFolder).onChange((value) => __async(this, null, function* () {
      this.plugin.settings.templateFolder = value;
      yield this.plugin.saveSettings();
    })));
    new import_obsidian.Setting(containerEl).setName("Use Enhanced Metadata").setDesc("Enable enhanced metadata fields for new notes (existing notes remain unchanged)").addToggle((toggle) => toggle.setValue(this.plugin.settings.useEnhancedMetadata).onChange((value) => __async(this, null, function* () {
      this.plugin.settings.useEnhancedMetadata = value;
      yield this.plugin.saveSettings();
    })));
    new import_obsidian.Setting(containerEl).setName("Dataview Functions Path").setDesc("Path to the dataview functions file (without extension)").addText((text) => text.setPlaceholder("/Supporting/dataview-functions").setValue(this.plugin.settings.dataviewJsPath).onChange((value) => __async(this, null, function* () {
      this.plugin.settings.dataviewJsPath = value;
      yield this.plugin.saveSettings();
    })));
  }
};

// templateManager.ts
var import_obsidian2 = require("obsidian");
var TemplateManager = class {
  constructor(app, settings) {
    this.app = app;
    this.settings = settings;
    this.manifest = {
      version: "1.0.0",
      templates: {
        "Courses/Create Course Homepage.md": "1.0.0",
        "Courses/Course Index.md": "1.0.0",
        "Modules/Create Module.md": "1.0.0",
        "Chapters/Create Chapter.md": "1.0.0",
        "Assignments/Create Assignment.md": "1.0.0",
        "Daily/Daily Note.md": "1.0.0",
        "Utilities/Vocabulary Entry.md": "1.0.0",
        "Utilities/Due Date Entry.md": "1.0.0"
      },
      plugin_version: "1.0.0",
      release_notes: "Initial release of Tuckers Tools templates"
    };
  }
  installTemplates() {
    return __async(this, null, function* () {
      try {
        const templaterPlugin = this.getTemplaterPlugin();
        if (!templaterPlugin) {
          new import_obsidian2.Notice(
            "Templater plugin not found. Please install and enable the Templater plugin first."
          );
          console.error(
            "Templater plugin not found. Please install and enable the Templater plugin first."
          );
          return;
        }
        const templateFolderPath = this.getTemplateFolderPath(templaterPlugin);
        if (!templateFolderPath) {
          new import_obsidian2.Notice(
            "Template folder not configured in Templater settings. Please configure it in Templater settings first."
          );
          console.error(
            "Template folder not configured in Templater settings. Please configure it in Templater settings first."
          );
          return;
        }
        const fullTemplatePath = `${templateFolderPath}/${this.settings.templateFolder}`;
        try {
          yield this.app.vault.createFolder(fullTemplatePath);
          console.log(`Created template folder: ${fullTemplatePath}`);
        } catch (e) {
          console.log(
            `Template folder already exists or created: ${fullTemplatePath}`
          );
        }
        const subdirs = [
          "Courses",
          "Modules",
          "Chapters",
          "Assignments",
          "Daily",
          "Utilities"
        ];
        for (const subdir of subdirs) {
          try {
            const subPath = `${fullTemplatePath}/${subdir}`;
            yield this.app.vault.createFolder(subPath);
            console.log(`Created subdirectory: ${subPath}`);
          } catch (e) {
            console.log(
              `Subdirectory already exists: ${fullTemplatePath}/${subdir}`
            );
          }
        }
        yield this.installCourseTemplates(fullTemplatePath);
        yield this.installModuleTemplates(fullTemplatePath);
        yield this.installChapterTemplates(fullTemplatePath);
        yield this.installAssignmentTemplates(fullTemplatePath);
        yield this.installDailyTemplates(fullTemplatePath);
        yield this.createREADME(fullTemplatePath);
        yield this.createTemplateManifest(fullTemplatePath);
        new import_obsidian2.Notice("Tuckers Tools templates installed successfully!");
        console.log("Tuckers Tools templates installed successfully");
      } catch (error) {
        console.error("Error installing templates:", error);
        new import_obsidian2.Notice("Error installing templates. Check console for details.");
      }
    });
  }
  getTemplaterPlugin() {
    const possiblePaths = [
      this.app.plugins.plugins["templater-obsidian"],
      this.app.plugins.plugins["templater"],
      this.app.plugins.getPlugin("templater-obsidian"),
      this.app.plugins.getPlugin("templater")
    ];
    for (const path of possiblePaths) {
      if (path) {
        return path;
      }
    }
    return null;
  }
  getTemplateFolderPath(templaterPlugin) {
    const settings = templaterPlugin.settings;
    if (!settings) {
      console.error("Templater plugin has no settings");
      return null;
    }
    const possiblePaths = [
      settings.templates_folder,
      // Changed from template_folder to match actual setting
      settings.template_folder,
      settings.templateFolder,
      settings.templateFolderPath,
      settings.folder
    ];
    for (const path of possiblePaths) {
      if (path && typeof path === "string") {
        return path;
      }
    }
    console.error(
      "Template folder not found in Templater settings. Available settings:",
      Object.keys(settings)
    );
    return null;
  }
  createTemplateManifest(basePath) {
    return __async(this, null, function* () {
      const manifestPath = `${basePath}/template-manifest.json`;
      const manifestContent = JSON.stringify(this.manifest, null, 2);
      try {
        const existingManifest = this.app.vault.getAbstractFileByPath(manifestPath);
        if (existingManifest) {
          const file = existingManifest;
          yield this.app.vault.modify(file, manifestContent);
          console.log(`Updated template manifest: ${manifestPath}`);
          return;
        }
        yield this.app.vault.create(manifestPath, manifestContent);
        console.log(`Created template manifest: ${manifestPath}`);
      } catch (e) {
        new import_obsidian2.Notice(`Error creating template manifest ${manifestPath}`);
        console.error(`Error creating template manifest ${manifestPath}:`, e);
      }
    });
  }
  checkForTemplateUpdates() {
    return __async(this, null, function* () {
      console.log("Checking for template updates");
      return false;
    });
  }
  updateTemplates() {
    return __async(this, null, function* () {
      try {
        console.log("Updating templates");
        const templaterPlugin = this.getTemplaterPlugin();
        if (!templaterPlugin) {
          new import_obsidian2.Notice(
            "Templater plugin not found. Please install and enable the Templater plugin first."
          );
          console.error(
            "Templater plugin not found. Please install and enable the Templater plugin first."
          );
          return;
        }
        const templateFolderPath = this.getTemplateFolderPath(templaterPlugin);
        if (!templateFolderPath) {
          new import_obsidian2.Notice(
            "Template folder not configured in Templater settings. Please configure it in Templater settings first."
          );
          console.error(
            "Template folder not configured in Templater settings. Please configure it in Templater settings first."
          );
          return;
        }
        const fullTemplatePath = `${templateFolderPath}/${this.settings.templateFolder}`;
        yield this.installCourseTemplates(fullTemplatePath);
        yield this.installModuleTemplates(fullTemplatePath);
        yield this.installChapterTemplates(fullTemplatePath);
        yield this.installAssignmentTemplates(fullTemplatePath);
        yield this.installDailyTemplates(fullTemplatePath);
        yield this.createREADME(fullTemplatePath);
        yield this.createTemplateManifest(fullTemplatePath);
        new import_obsidian2.Notice("Tuckers Tools templates updated successfully!");
        console.log("Tuckers Tools templates updated successfully");
      } catch (error) {
        console.error("Error updating templates:", error);
        new import_obsidian2.Notice("Error updating templates. Check console for details.");
      }
    });
  }
  installCourseTemplates(basePath) {
    return __async(this, null, function* () {
      const coursePath = `${basePath}/Courses`;
      const courseHomepageTemplate = this.generateCourseHomepageTemplate();
      yield this.writeTemplateFile(
        `${coursePath}/Create Course Homepage.md`,
        courseHomepageTemplate
      );
      const courseIndexTemplate = this.generateCourseIndexTemplate();
      yield this.writeTemplateFile(
        `${coursePath}/Course Index.md`,
        courseIndexTemplate
      );
    });
  }
  installModuleTemplates(basePath) {
    return __async(this, null, function* () {
      const modulePath = `${basePath}/Modules`;
      const moduleTemplate = this.generateModuleTemplate();
      yield this.writeTemplateFile(
        `${modulePath}/Create Module.md`,
        moduleTemplate
      );
    });
  }
  installChapterTemplates(basePath) {
    return __async(this, null, function* () {
      const chapterPath = `${basePath}/Chapters`;
      const chapterTemplate = this.generateChapterTemplate();
      yield this.writeTemplateFile(
        `${chapterPath}/Create Chapter.md`,
        chapterTemplate
      );
    });
  }
  installAssignmentTemplates(basePath) {
    return __async(this, null, function* () {
      const assignmentPath = `${basePath}/Assignments`;
      const assignmentTemplate = this.generateAssignmentTemplate();
      yield this.writeTemplateFile(
        `${assignmentPath}/Create Assignment.md`,
        assignmentTemplate
      );
    });
  }
  installDailyTemplates(basePath) {
    return __async(this, null, function* () {
      const dailyPath = `${basePath}/Daily`;
      const dailyNoteTemplate = this.generateDailyNoteTemplate();
      yield this.writeTemplateFile(
        `${dailyPath}/Daily Note.md`,
        dailyNoteTemplate
      );
    });
  }
  /**
   * Generates the proper nested path for a module file based on course details
   * @param course - The course file object or course name string
   * @param courseId - The course ID
   * @param moduleNumber - The module number (optional)
   * @param weekNumber - The week number (optional)
   * @param dayOfWeek - The day of the week
   * @returns The proper nested path for the module file
   */
  generateModulePath(course, courseId, moduleNumber, weekNumber, dayOfWeek) {
    let modulePath = "";
    if (typeof course === "object" && course !== null && course.path) {
      const courseDir = course.path.substring(0, course.path.lastIndexOf("/"));
      const courseName = course.basename;
      if (moduleNumber && weekNumber) {
        modulePath = `${courseDir}/${courseId} - Module ${moduleNumber}/${courseId} - Week ${weekNumber}/${courseId}.${moduleNumber}.${weekNumber} - ${dayOfWeek}`;
      } else if (moduleNumber) {
        modulePath = `${courseDir}/${courseId} - Module ${moduleNumber}/${courseId}.${moduleNumber} - ${dayOfWeek}`;
      } else if (weekNumber) {
        modulePath = `${courseDir}/${courseId} - Week ${weekNumber}/${courseId}.${weekNumber} ${dayOfWeek}`;
      } else {
        modulePath = `${courseDir}/${courseId} - ${dayOfWeek}`;
      }
    } else {
      if (moduleNumber && weekNumber) {
        modulePath = `Modules/${courseId} - Module ${moduleNumber}/${courseId} - Week ${weekNumber}/${courseId}.${moduleNumber}.${weekNumber} - ${dayOfWeek}`;
      } else if (moduleNumber) {
        modulePath = `Modules/${courseId} - Module ${moduleNumber}/${courseId}.${moduleNumber} - ${dayOfWeek}`;
      } else if (weekNumber) {
        modulePath = `Modules/${courseId} - Week ${weekNumber}/${courseId}.${weekNumber} ${dayOfWeek}`;
      } else {
        modulePath = `Modules/${courseId} - ${dayOfWeek}`;
      }
    }
    return modulePath;
  }
  writeTemplateFile(path, content) {
    return __async(this, null, function* () {
      try {
        const existingFile = this.app.vault.getAbstractFileByPath(path);
        if (existingFile) {
          console.log(`Updating existing template file: ${path}`);
          const file = existingFile;
          yield this.app.vault.modify(file, content);
          return;
        }
        yield this.app.vault.create(path, content);
        console.log(`Created template file: ${path}`);
      } catch (e) {
        new import_obsidian2.Notice(`Error creating template file ${path}`);
        console.error(`Error creating template file ${path}:`, e);
      }
    });
  }
  generateCourseHomepageTemplate() {
    const enhancedMetadata = this.settings.useEnhancedMetadata;
    if (enhancedMetadata) {
      return `<%*
// Tuckers Tools Course Creation
// For best experience, use the plugin command: Command Palette \u2192 'Create New Course'

let courseName = "New Course";
let courseSeason = "Fall"; 
let courseYear = new Date().getFullYear().toString();
let courseId = "COURSE_ID";

// Try to use system prompts, with graceful fallback
try {
  if (tp && tp.system && tp.system.prompt) {
    courseName = await tp.system.prompt("Course Name (e.g. SWO-250 - Course Title)") || courseName;
    courseId = courseName.split(' - ')[0] || courseName.replace(/[^a-zA-Z0-9]/g, "_");
    courseSeason = await tp.system.suggester(["Fall","Winter","Spring","Summer"],["Fall","Winter","Spring","Summer"], "Season") || courseSeason;
    courseYear = await tp.system.prompt("Year") || courseYear;
  } else {
    console.log("System prompts not available, use the plugin command instead");
  }
} catch (e) {
  console.error("Error with system prompts:", e.message);
  console.log("Use the plugin command: Command Palette \u2192 'Create New Course'");
}

// Move file to appropriate location
await tp.file.move(\`/\${courseYear}/\${courseSeason}/\${courseName}/\${courseName}.md\`);

// Create attachments folder
try {
  await app.vault.createFolder(\`/\${courseYear}/\${courseSeason}/\${courseName}/Attachments\`);
} catch (e) {
  // Folder might already exist
}
%>---
course_id: <% courseId %>
course_season: <% courseSeason %>
course_year: <% courseYear %>
created: <% tp.date.now("YYYY-MM-DD[T]HH:mm:ssZ") %>
contentType: Course
tags: 
  - <% courseId %>
  - ${this.settings.schoolAbbreviation}/<% courseYear %>/<% courseSeason %>/<% courseId %>/
  - course_home
  - education
  - ${this.settings.schoolName.replace(/\s+/g, "_")}
banner:
cssclasses:
  - whiteboard-course
---

# <% courseName %>

## Course Information
**Course**: <% courseName %>
**Course ID**: <% courseId %>
**Term**: <% courseSeason %> <% courseYear %>
**School**: ${this.settings.schoolName}

## Instructor
**Name**: \`INPUT[text:instructor_name]\`
**Email**: \`INPUT[text:instructor_email]\`
**Office Hours**: \`INPUT[text:instructor_office_hours]\`
**Office Location**: \`INPUT[text:instructor_office_location]\`

## Course Description
\`INPUT[textArea:course_description]\`

## Learning Objectives
\`INPUT[textArea:learning_objectives]\`

## Required Texts
\`\`\`meta-bind-js-view
{texts} as texts
---
const availableTexts = app.vault.getFiles().filter(file => file.extension == 'pdf').map(f => f?.name)
const escapeRegex = /[,\`'()]/g;
options = availableTexts.map(t => \`option([[\${t.replace(escapeRegex,"$1")}]], \${t.replace(escapeRegex,"$1")})\` )
const str = \`\\\`INPUT[inlineListSuggester(\${options.join(", ")}):texts]\\\`\`
return engine.markdown.create(str)
\`\`\`

## Course Schedule
\`INPUT[textArea:course_schedule]\`

## Resources
\`INPUT[textArea:resources]\`

## Vocabulary
\`\`\`dataviewjs
const {processCourseVocabulary} = app.plugins.getPlugin("tuckers-tools")?.dataviewFunctions || app.globals.tuckersTools.processCourseVocabulary;
processCourseVocabulary(dv, '<% courseId %>');
\`\`\`

## Due Dates
\`\`\`dataviewjs
const {processDueDates} = app.plugins.getPlugin("tuckers-tools")?.dataviewFunctions || app.globals.tuckersTools.processDueDates;
processDueDates(dv,'#<% courseId %>');
\`\`\`

## Class Materials
\`INPUT[textArea:class_materials]\``;
    } else {
      return `---
course_id: <% courseId %>
course_name: <% courseName %>
course_season: <% courseSeason %>
course_year: <% courseYear %>
created: <% tp.date.now("YYYY-MM-DD[T]HH:mm:ssZ") %>
contentType: Course
tags:
  - <% courseId %>
  - course_home
  - education
---

# <% courseName %>

## Course Information
**Course ID**: <% courseId %>
**Term**: <% courseSeason %> <% courseYear %>
**School**: ${this.settings.schoolName}

## Instructor
**Name**: \`INPUT[text:instructor_name]\`
**Email**: \`INPUT[text:instructor_email]\`
**Office Hours**: \`INPUT[text:instructor_office_hours]\`
**Office Location**: \`INPUT[text:instructor_office_location]\`

## Course Description
\`INPUT[textArea:course_description]\`

## Learning Objectives
\`INPUT[textArea:learning_objectives]\`

## Required Texts
\`\`\`meta-bind-js-view
{texts} as texts
---
const availableTexts = app.vault.getFiles().filter(file => file.extension == 'pdf').map(f => f?.name)
const escapeRegex = /[,\`'()]/g;
options = availableTexts.map(t => \`option([[\${t.replace(escapeRegex,"$1")}]], \${t.replace(escapeRegex,"$1")})\` )
const str = \`\\\`INPUT[inlineListSuggester(\${options.join(", ")}):texts]\\\`\`
return engine.markdown.create(str)
\`\`\`

## Course Schedule
\`INPUT[textArea:course_schedule]\`

## Assignments
\`INPUT[textArea:assignments]\`

## Resources
\`INPUT[textArea:resources]\`

## Vocabulary
\`\`\`dataviewjs
const {processCourseVocabulary} = app.plugins.getPlugin("tuckers-tools")?.dataviewFunctions || app.globals.tuckersTools.processCourseVocabulary;
processCourseVocabulary(dv, '<% courseId %>');
\`\`\`

## Due Dates
\`\`\`dataviewjs
const {processDueDates} = app.plugins.getPlugin("tuckers-tools")?.dataviewFunctions || app.globals.tuckersTools.processDueDates;
processDueDates(dv,'#<% courseId %>');
\`\`\`

## Class Materials
\`INPUT[textArea:class_materials]\``;
    }
  }
  generateCourseIndexTemplate() {
    return `---
content_type: course_index
tags:
  - index
---

# Course Index

## Modules

## Chapters

## Assignments

## Resources

## Vocabulary

## Due Dates`;
  }
  generateModuleTemplate() {
    return `<%*
const { season, moduleNumber, weekNumber, course, courseId, discipline, dayOfWeek } = await tp.app.globals.tuckersTools.new_module(app, tp, "2025");
let title = courseId
if (moduleNumber && weekNumber) { title = "M" + moduleNumber + "/W" + weekNumber }
else if (moduleNumber) { title = "M" + moduleNumber } 
else if (weekNumber) { title = "W" + weekNumber }

// Move file to appropriate course location after creation
// Extract course information from the selected course file and create proper nested directory structure
let modulePath = "";
if (typeof course === 'object' && course !== null && course.path) {
  // Get the directory of the course file (should be Year/Season/CourseName/)
  const courseDir = course.path.substring(0, course.path.lastIndexOf('/'));
  const courseName = course.basename;
  
  // Create proper nested directory structure based on module/week numbers
  if (moduleNumber && weekNumber) {
    // Module and Week combination
    modulePath = courseDir + "/" + courseId + " - Module " + moduleNumber + "/" + courseId + " - Week " + weekNumber + "/" + courseId + "." + moduleNumber + "." + weekNumber + " - " + dayOfWeek;
  } else if (moduleNumber) {
    // Module only
    modulePath = courseDir + "/" + courseId + " - Module " + moduleNumber + "/" + courseId + "." + moduleNumber + " - " + dayOfWeek;
  } else if (weekNumber) {
    // Week only
    modulePath = courseDir + "/" + courseId + " - Week " + weekNumber + "/" + courseId + "." + weekNumber + " " + dayOfWeek;
  } else {
    // Neither module nor week
    modulePath = courseDir + "/" + courseId + " - " + dayOfWeek;
  }
} else {
  // Fallback - put in Modules directory with nested structure
  if (moduleNumber && weekNumber) {
    modulePath = "Modules/" + courseId + " - Module " + moduleNumber + "/" + courseId + " - Week " + weekNumber + "/" + courseId + "." + moduleNumber + "." + weekNumber + " - " + dayOfWeek;
  } else if (moduleNumber) {
    modulePath = "Modules/" + courseId + " - Module " + moduleNumber + "/" + courseId + "." + moduleNumber + " - " + dayOfWeek;
  } else if (weekNumber) {
    modulePath = "Modules/" + courseId + " - Week " + weekNumber + "/" + courseId + "." + weekNumber + " " + dayOfWeek;
  } else {
    modulePath = "Modules/" + courseId + " - " + dayOfWeek;
  }
}

// We'll move the file after creation using the modulePath variable
%>---
${this.settings.useEnhancedMetadata ? `course_id: <% courseId %>
module_number: <% moduleNumber %>
week_number: <% weekNumber %>
class_day: <% dayOfWeek %>
content_type: module
parent_course: "[[<% course %>]]"` : `course_id: <% courseId %>
module_number: <% moduleNumber %>
week_number: <% weekNumber %>
class_day: <% dayOfWeek %>`}
created: <% tp.date.now("YYYY-MM-DD[T]HH:mm:ssZ") %>
tags:
  - education
  - <% courseId %>
  - module
---


# [[<% course %>|<% courseId %> <% title %> <% dayOfWeek %>]]

## Due Dates
| Date | Assignment |
| ---- | ---------- |
|      |            |
|      |            |
|      |            |

\`\`\`dataviewjs
const {processDueDates} = app.plugins.getPlugin("tuckers-tools")?.dataviewFunctions || app.globals.tuckersTools.processDueDates;
processDueDates(dv,'#<% courseId %>');
\`\`\`

## Learning Objectives

## Reading Assignment

## Lecture Notes

## Discussion Questions

## Vocabulary

\`\`\`dataviewjs
const {processCourseVocabulary} = app.plugins.getPlugin("tuckers-tools")?.dataviewFunctions || app.globals.tuckersTools.processCourseVocabulary;
processCourseVocabulary(dv, '<% courseId %>');
\`\`\`

## Additional Resources

<%*
// Move file to appropriate location after content generation
if (modulePath) {
  try {
    await tp.file.move(modulePath + ".md");
  } catch (e) {
    console.error("Error moving module file:", e);
  }
}
%>
`;
  }
  generateChapterTemplate() {
    return `<%*
const { chapterNumber, course, courseId, discipline, text} = await tp.app.globals.tuckersTools.new_chapter(tp);
%>---
${this.settings.useEnhancedMetadata ? `course_id: <% courseId %>
chapter_number: <% chapterNumber %>
content_type: chapter
parent_course: "[[<% course %>]]"
text_reference: "[[<% text %>]]"` : `course_id: <% courseId %>
chapter_number: <% chapterNumber %>`}
created: <% tp.date.now("YYYY-MM-DD[T]HH:mm:ssZ") %>
tags:
  - education
  - <% courseId %>
  - chapter
---


# [[<% text %>]] - Chapter <% chapterNumber %>

## Reading Assignment
- **Textbook**: [[<% text %>]]
- **Chapter**: <% chapterNumber %>
- **Pages**: 

## Summary

## Key Concepts

## Vocabulary
- 

## Notes

## Discussion Questions

## Further Reading`;
  }
  generateAssignmentTemplate() {
    return `---
${this.settings.useEnhancedMetadata ? `course_id: <% courseId %>
assignment_type: <% assignmentType %>
due_date: <% dueDate %>
points: <% points %>
content_type: assignment
parent_course: "[[<% course %>]]"` : `course_id: <% courseId %>
assignment_type: <% assignmentType %>
due_date: <% dueDate %>`}
created: <% tp.date.now("YYYY-MM-DD[T]HH:mm:ssZ") %>
status: pending
tags:
  - education
  - <% courseId %>
  - assignment
---

# <% assignmentName %> - <% courseId %>

## Description

## Instructions

## Due Date
**Assigned**: <% tp.date.now("YYYY-MM-DD") %>
**Due**: <% dueDate %>

## Submission

## Grading Criteria

## Resources

# Due Dates
| <% dueDate %> | <% assignmentName %> | pending |
`;
  }
  generateDailyNoteTemplate() {
    return `---
content_type: daily_note
date: <% tp.date.now("YYYY-MM-DD") %>
tags:
  - daily
  - <% tp.date.now("YYYY") %>
  - <% tp.date.now("MM") %>
  - <% tp.date.now("DD") %>
---

# <% tp.date.now("YYYY-MM-DD - dddd") %>

<< [[<% tp.date.yesterday("YYYY-MM-DD") %>]] | [[<% tp.date.tomorrow("YYYY-MM-DD") %>]] >>

## Today's Focus

## Courses Worked On
- 

## Tasks Completed
- [ ] 

## Vocabulary Reviewed
- 

## Assignments Due
- 

## Learning Achievements

## Challenges

## Tomorrow's Plan

## Reflection`;
  }
  generateVocabularyTemplate() {
    return `## <% term %>
**Term**: <% term %>
**Part of Speech**: 
**Definition**: 
**Context**: 
**Examples**: 
**Related Terms**: 
**See Also**:`;
  }
  generateDueDateTemplate() {
    return `| <% dueDate %> | <% assignment %> | <% status %> |`;
  }
  createREADME(basePath) {
    return __async(this, null, function* () {
      const readmeContent = `# Tuckers Tools Templates

This directory contains templates for the Tuckers Tools Obsidian plugin.

## Template Categories

- **Courses**: Templates for creating and organizing courses
- **Modules**: Templates for course modules
- **Chapters**: Templates for chapter notes
- **Assignments**: Templates for assignments
- **Daily**: Templates for daily notes
- **Utilities**: Helper templates

## Usage

These templates are designed to work with the Tuckers Tools plugin. To use them:

1. Install the Tuckers Tools plugin
2. Configure your settings in the plugin settings tab
3. Use the "Insert Template" command to apply these templates to new notes

## Customization

Feel free to customize these templates to suit your needs. The plugin will not overwrite your changes when updating templates.`;
      yield this.writeTemplateFile(`${basePath}/README.md`, readmeContent);
    });
  }
};

// courseWizard.ts
var import_obsidian4 = require("obsidian");

// inputModal.ts
var import_obsidian3 = require("obsidian");
var InputModal = class extends import_obsidian3.Modal {
  constructor(app, onSubmit) {
    super(app);
    this.onSubmit = onSubmit;
  }
  onOpen() {
    const { contentEl } = this;
    contentEl.createEl("h2", { text: "Enter Value" });
    new import_obsidian3.Setting(contentEl).setName("Value").addText(
      (text) => text.onChange((value) => {
        this.result = value;
      }).inputEl.focus()
    );
    new import_obsidian3.Setting(contentEl).addButton(
      (btn) => btn.setButtonText("Submit").setCta().onClick(() => {
        this.close();
        this.onSubmit(this.result || "");
      })
    ).addButton(
      (btn) => btn.setButtonText("Cancel").onClick(() => {
        this.close();
        this.onSubmit(null);
      })
    );
  }
  onClose() {
    const { contentEl } = this;
    contentEl.empty();
  }
};
var SuggesterModal = class extends import_obsidian3.Modal {
  constructor(app, options, onSubmit) {
    super(app);
    this.onSubmit = onSubmit;
    const dropdownOptions = {};
    options.forEach((option) => {
      dropdownOptions[option] = option;
    });
    this.createDropdown(dropdownOptions);
  }
  createDropdown(options) {
    const { contentEl } = this;
    contentEl.createEl("h2", { text: "Select Option" });
    let selectedValue = Object.keys(options)[0] || null;
    const dropdown = contentEl.createEl("select");
    Object.entries(options).forEach(([key, value]) => {
      const option = dropdown.createEl("option", {
        value: key,
        text: value
      });
      if (key === selectedValue) {
        option.selected = true;
      }
    });
    dropdown.addEventListener("change", (event) => {
      selectedValue = event.target.value;
      this.result = selectedValue;
    });
    new import_obsidian3.Setting(contentEl).addButton(
      (btn) => btn.setButtonText("Submit").setCta().onClick(() => {
        this.close();
        this.onSubmit(selectedValue);
      })
    ).addButton(
      (btn) => btn.setButtonText("Cancel").onClick(() => {
        this.close();
        this.onSubmit(null);
      })
    );
  }
  onOpen() {
  }
  onClose() {
    const { contentEl } = this;
    contentEl.empty();
  }
};

// courseWizard.ts
var CourseCreationWizard = class {
  constructor(app, settings) {
    this.app = app;
    this.settings = settings;
  }
  createCourseHomepage() {
    return __async(this, null, function* () {
      try {
        const courseDetails = yield this.promptCourseDetails();
        if (!courseDetails) {
          return false;
        }
        const folderPath = yield this.createCourseFolderStructure(courseDetails);
        yield this.createCourseHomepageNote(courseDetails, folderPath);
        yield this.createAttachmentsFolder(folderPath);
        new import_obsidian4.Notice(`Course "${courseDetails.courseName}" created successfully!`);
        console.log(
          `Course created: ${courseDetails.courseName} at ${folderPath}`
        );
        return true;
      } catch (error) {
        console.error("Error creating course:", error);
        new import_obsidian4.Notice(`Error creating course: ${error.message}`);
        return false;
      }
    });
  }
  promptCourseDetails() {
    return __async(this, null, function* () {
      var _a;
      try {
        const courseName = yield this.promptWithValidation(
          "Course Name",
          "Enter course name (e.g., PSI-101 - Intro to Psychology)",
          (value) => value.trim().length > 0,
          "Course name is required"
        );
        if (!courseName)
          return null;
        const courseSeason = yield this.promptWithOptions(
          "Season",
          "Select semester/season",
          ["Fall", "Winter", "Spring", "Summer"]
        );
        if (!courseSeason)
          return null;
        const courseYear = yield this.promptWithValidation(
          "Year",
          "Enter academic year (e.g., 2025)",
          (value) => /^\d{4}$/.test(value.trim()),
          "Please enter a valid 4-digit year"
        );
        if (!courseYear)
          return null;
        const courseId = ((_a = courseName.split(" - ")[0]) == null ? void 0 : _a.trim()) || slugify(courseName);
        return {
          courseName,
          courseSeason,
          courseYear,
          courseId
        };
      } catch (error) {
        console.error("Error prompting for course details:", error);
        return null;
      }
    });
  }
  promptWithValidation(title, message, validator, errorMessage) {
    return __async(this, null, function* () {
      return new Promise((resolve) => {
        const modal = new InputModal(this.app, (result) => {
          if (result === null) {
            resolve(null);
            return;
          }
          if (!validator(result)) {
            new import_obsidian4.Notice(errorMessage);
            this.promptWithValidation(title, message, validator, errorMessage).then(resolve);
            return;
          }
          resolve(result.trim());
        });
        modal.titleEl.setText(title);
        const messageEl = modal.contentEl.createDiv();
        messageEl.setText(message);
        modal.open();
      });
    });
  }
  promptWithOptions(title, message, options) {
    return __async(this, null, function* () {
      return new Promise((resolve) => {
        const modal = new SuggesterModal(this.app, options, (result) => {
          if (result === null) {
            resolve(null);
            return;
          }
          if (options.includes(result)) {
            resolve(result);
          } else {
            new import_obsidian4.Notice(`Please select one of: ${options.join(", ")}`);
            this.promptWithOptions(title, message, options).then(resolve);
          }
        });
        modal.titleEl.setText(title);
        const messageEl = modal.contentEl.createDiv();
        messageEl.setText(message);
        modal.open();
      });
    });
  }
  createCourseFolderStructure(courseDetails) {
    return __async(this, null, function* () {
      const folderPath = `${courseDetails.courseYear}/${courseDetails.courseSeason}/${courseDetails.courseName}`;
      try {
        yield this.app.vault.createFolder(folderPath);
        console.log(`Created course folder: ${folderPath}`);
        return folderPath;
      } catch (error) {
        console.log(`Course folder already exists or created: ${folderPath}`);
        return folderPath;
      }
    });
  }
  createCourseHomepageNote(courseDetails, folderPath) {
    return __async(this, null, function* () {
      const notePath = `${folderPath}/${courseDetails.courseName}.md`;
      const content = this.generateCourseHomepageContent(courseDetails);
      try {
        yield this.app.vault.create(notePath, content);
        console.log(`Created course homepage: ${notePath}`);
      } catch (error) {
        console.error(`Error creating course homepage: ${error}`);
        throw error;
      }
    });
  }
  createAttachmentsFolder(folderPath) {
    return __async(this, null, function* () {
      const attachmentsPath = `${folderPath}/Attachments`;
      try {
        yield this.app.vault.createFolder(attachmentsPath);
        console.log(`Created attachments folder: ${attachmentsPath}`);
      } catch (error) {
        console.log(`Attachments folder already exists: ${attachmentsPath}`);
      }
    });
  }
  generateCourseHomepageContent(courseDetails) {
    const templateManager = new TemplateManager(this.app, this.settings);
    const templateContent = templateManager.generateCourseHomepageTemplate();
    return templateContent.replace(/<% courseName %>/g, courseDetails.courseName).replace(/<% courseSeason %>/g, courseDetails.courseSeason).replace(/<% courseYear %>/g, courseDetails.courseYear).replace(/<% courseId %>/g, courseDetails.courseId).replace(/<% tp\.date\.now\("YYYY-MM-DD\[T\]HH:mm:ssZ"\) %>/g, new Date().toISOString()).replace(/<% tp\.date\.now\("YYYY-MM-DD\[T\]hh:mm:SSSSZZ"\) %>/g, new Date().toISOString());
  }
};

// vocabulary.ts
var import_obsidian5 = require("obsidian");
var VocabularyExtractor = class {
  constructor(app) {
    this.app = app;
  }
  extractVocabularyFromNote(content) {
    const vocabRegex = /^#+ Vocabulary.*\n((?:.*?\n)*?)(?=^\s*#\s|$)/m;
    const vocabMatches = content == null ? void 0 : content.match(vocabRegex);
    if (vocabMatches) {
      const vocabData = vocabMatches[1].trim();
      const cleanedVocab = vocabData.replace(/\[\[.*?\]\]/g, "").replace(/^\s*-\s*/gm, "").split("\n").map((term) => term.trim()).filter((term) => term.length > 0);
      return cleanedVocab;
    }
    return [];
  }
  extractVocabularyFromCourse(courseId) {
    return __async(this, null, function* () {
      console.log(`Extracting vocabulary for course: ${courseId}`);
      try {
        const courseNotes = yield this.findCourseNotes(courseId);
        if (courseNotes.length === 0) {
          console.log(`No notes found for course: ${courseId}`);
          return {};
        }
        const vocabularyData = {};
        for (const note of courseNotes) {
          try {
            const content = yield this.app.vault.read(note);
            const vocabulary = this.extractVocabularyFromNote(content);
            if (vocabulary.length > 0) {
              vocabularyData[note.basename] = vocabulary;
            }
          } catch (error) {
            console.error(`Error reading note ${note.path}:`, error);
          }
        }
        console.log(
          `Extracted vocabulary from ${Object.keys(vocabularyData).length} notes for course: ${courseId}`
        );
        return vocabularyData;
      } catch (error) {
        console.error(
          `Error extracting vocabulary for course ${courseId}:`,
          error
        );
        return {};
      }
    });
  }
  findCourseNotes(courseId) {
    return __async(this, null, function* () {
      const notes = [];
      const files = this.app.vault.getMarkdownFiles();
      for (const file of files) {
        if (file.path.includes(courseId) || (yield this.noteBelongsToCourse(file, courseId))) {
          notes.push(file);
        }
      }
      return notes;
    });
  }
  noteBelongsToCourse(file, courseId) {
    return __async(this, null, function* () {
      try {
        const content = yield this.app.vault.read(file);
        const frontmatterMatch = content.match(/^---\n([\s\S]*?)\n---/);
        if (frontmatterMatch) {
          const frontmatter = frontmatterMatch[1];
          return frontmatter.includes(`course_id: ${courseId}`) || frontmatter.includes(`course_id:${courseId}`);
        }
        return false;
      } catch (error) {
        console.error(
          `Error checking if note ${file.path} belongs to course ${courseId}:`,
          error
        );
        return false;
      }
    });
  }
  generateVocabularyIndex(courseId, vocabularyData) {
    return __async(this, null, function* () {
      const allTerms = [];
      const termSources = {};
      for (const [noteName, terms] of Object.entries(vocabularyData)) {
        for (const term of terms) {
          if (!allTerms.includes(term)) {
            allTerms.push(term);
            termSources[term] = [];
          }
          termSources[term].push(noteName);
        }
      }
      allTerms.sort();
      let content = `# Vocabulary Index - ${courseId}

`;
      content += `Total unique terms: ${allTerms.length}

`;
      for (const term of allTerms) {
        content += `## ${term}
`;
        content += `**Sources:** ${termSources[term].join(", ")}

`;
        content += `**Definition:**

`;
        content += `**Context:**

`;
        content += `**Examples:**

`;
        content += `---

`;
      }
      return content;
    });
  }
  createVocabularyIndexFile(courseId) {
    return __async(this, null, function* () {
      try {
        const vocabularyData = yield this.extractVocabularyFromCourse(courseId);
        if (Object.keys(vocabularyData).length === 0) {
          console.log(`No vocabulary found for course: ${courseId}`);
          return;
        }
        const indexContent = yield this.generateVocabularyIndex(
          courseId,
          vocabularyData
        );
        const fileName = `${courseId} - Vocabulary Index.md`;
        const filePath = `Courses/${courseId}/${fileName}`;
        try {
          yield this.app.vault.create(filePath, indexContent);
          console.log(`Created vocabulary index file: ${filePath}`);
        } catch (error) {
          const existingFile = this.app.vault.getAbstractFileByPath(filePath);
          if (existingFile && existingFile instanceof import_obsidian5.TFile) {
            yield this.app.vault.modify(existingFile, indexContent);
            console.log(`Updated vocabulary index file: ${filePath}`);
          }
        }
      } catch (error) {
        console.error(
          `Error creating vocabulary index for course ${courseId}:`,
          error
        );
        throw error;
      }
    });
  }
};

// dueDates.ts
var import_obsidian6 = require("obsidian");
var DueDatesParser = class {
  constructor(app) {
    this.app = app;
  }
  parseDueDatesFromNote(content) {
    const dueDatesRegex = /# Due Dates[\s\S]*?(?=\n#|$)/;
    const matches = content == null ? void 0 : content.match(dueDatesRegex);
    if (!matches) {
      return [];
    }
    const dueDatesSection = matches[0];
    const dueDates = [];
    const tableRegex = /\|[\s\S]*?\n/g;
    const tableMatches = dueDatesSection.match(tableRegex);
    if (tableMatches) {
      for (const table of tableMatches) {
        const rows = table.trim().split("\n").filter((row) => row.startsWith("|"));
        const parsedRows = this.parseTableRows(rows);
        dueDates.push(...parsedRows);
      }
    }
    return dueDates;
  }
  parseTableRows(rows) {
    if (rows.length < 2)
      return [];
    const dueDates = [];
    for (let i = 1; i < rows.length; i++) {
      const row = rows[i];
      const columns = row.split("|").map((col) => col.trim()).filter((col) => col);
      if (columns.length >= 2) {
        const [date, assignment, status = "pending"] = columns;
        if (date && assignment && this.isValidDate(date)) {
          dueDates.push({ date, assignment, status });
        }
      }
    }
    return dueDates;
  }
  isValidDate(dateString) {
    const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
    return dateRegex.test(dateString) && !isNaN(Date.parse(dateString));
  }
  parseDueDatesFromCourse(courseId, startDate, endDate) {
    return __async(this, null, function* () {
      console.log(`Parsing due dates for course: ${courseId}`);
      try {
        const courseNotes = yield this.findCourseNotes(courseId);
        if (courseNotes.length === 0) {
          console.log(`No notes found for course: ${courseId}`);
          return [];
        }
        const allDueDates = [];
        for (const note of courseNotes) {
          try {
            const content = yield this.app.vault.read(note);
            const dueDates = this.parseDueDatesFromNote(content);
            const dueDatesWithSource = dueDates.map((dueDate) => __spreadProps(__spreadValues({}, dueDate), {
              source: note.basename
            }));
            allDueDates.push(...dueDatesWithSource);
          } catch (error) {
            console.error(`Error reading note ${note.path}:`, error);
          }
        }
        let filteredDueDates = allDueDates;
        if (startDate || endDate) {
          filteredDueDates = this.filterByDateRange(
            allDueDates,
            startDate,
            endDate
          );
        }
        filteredDueDates.sort(
          (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()
        );
        console.log(
          `Found ${filteredDueDates.length} due dates for course: ${courseId}`
        );
        return filteredDueDates;
      } catch (error) {
        console.error(`Error parsing due dates for course ${courseId}:`, error);
        return [];
      }
    });
  }
  findCourseNotes(courseId) {
    return __async(this, null, function* () {
      const notes = [];
      const files = this.app.vault.getMarkdownFiles();
      for (const file of files) {
        if (file.path.includes(courseId) || (yield this.noteBelongsToCourse(file, courseId))) {
          notes.push(file);
        }
      }
      return notes;
    });
  }
  noteBelongsToCourse(file, courseId) {
    return __async(this, null, function* () {
      try {
        const content = yield this.app.vault.read(file);
        const frontmatterMatch = content.match(/^---\n([\s\S]*?)\n---/);
        if (frontmatterMatch) {
          const frontmatter = frontmatterMatch[1];
          return frontmatter.includes(`course_id: ${courseId}`) || frontmatter.includes(`course_id:${courseId}`);
        }
        return false;
      } catch (error) {
        console.error(
          `Error checking if note ${file.path} belongs to course ${courseId}:`,
          error
        );
        return false;
      }
    });
  }
  filterByDateRange(dueDates, startDate, endDate) {
    return dueDates.filter((dueDate) => {
      const dueDateTime = new Date(dueDate.date).getTime();
      if (startDate && dueDateTime < new Date(startDate).getTime()) {
        return false;
      }
      if (endDate && dueDateTime > new Date(endDate).getTime()) {
        return false;
      }
      return true;
    });
  }
  generateDueDatesSummary(courseId, dueDates) {
    return __async(this, null, function* () {
      if (dueDates.length === 0) {
        return `# Due Dates Summary - ${courseId}

No due dates found.
`;
      }
      const byStatus = dueDates.reduce((acc, dueDate) => {
        if (!acc[dueDate.status]) {
          acc[dueDate.status] = [];
        }
        acc[dueDate.status].push(dueDate);
        return acc;
      }, {});
      let content = `# Due Dates Summary - ${courseId}

`;
      content += `Total assignments: ${dueDates.length}

`;
      for (const [status, items] of Object.entries(byStatus)) {
        content += `## ${status.charAt(0).toUpperCase() + status.slice(1)} (${items.length})

`;
        content += `| Date | Assignment | Source |
`;
        content += `| ---- | ---------- | ------ |
`;
        for (const item of items) {
          content += `| ${item.date} | ${item.assignment} | ${item.source} |
`;
        }
        content += `
`;
      }
      return content;
    });
  }
  createDueDatesSummaryFile(courseId, startDate, endDate) {
    return __async(this, null, function* () {
      try {
        const dueDates = yield this.parseDueDatesFromCourse(
          courseId,
          startDate,
          endDate
        );
        const summaryContent = yield this.generateDueDatesSummary(
          courseId,
          dueDates
        );
        const fileName = `${courseId} - Due Dates Summary.md`;
        const filePath = `Courses/${courseId}/${fileName}`;
        try {
          yield this.app.vault.create(filePath, summaryContent);
          console.log(`Created due dates summary file: ${filePath}`);
        } catch (error) {
          const existingFile = this.app.vault.getAbstractFileByPath(filePath);
          if (existingFile && existingFile instanceof import_obsidian6.TFile) {
            yield this.app.vault.modify(existingFile, summaryContent);
            console.log(`Updated due dates summary file: ${filePath}`);
          }
        }
      } catch (error) {
        console.error(
          `Error creating due dates summary for course ${courseId}:`,
          error
        );
        throw error;
      }
    });
  }
};

// dailyNotes.ts
var import_obsidian7 = require("obsidian");
var DailyNotesIntegration = class {
  constructor(app) {
    this.app = app;
  }
  getTodaysActivities() {
    return __async(this, null, function* () {
      console.log("Getting today's academic activities");
      try {
        const today = new Date();
        const todayString = today.toISOString().split("T")[0];
        const files = this.app.vault.getMarkdownFiles();
        const todaysFiles = [];
        for (const file of files) {
          const fileDate = this.extractDateFromPath(file.path);
          if (fileDate === todayString) {
            todaysFiles.push(file);
          }
        }
        const activities = [];
        for (const file of todaysFiles) {
          const activity = yield this.analyzeFileActivity(file);
          if (activity) {
            activities.push(activity);
          }
        }
        console.log(`Found ${activities.length} academic activities for today`);
        return activities;
      } catch (error) {
        console.error("Error getting today's activities:", error);
        return [];
      }
    });
  }
  getCourseActivityForDate(courseId, date) {
    return __async(this, null, function* () {
      console.log(`Getting activity for course ${courseId} on date ${date}`);
      try {
        const courseFiles = yield this.findCourseFilesForDate(courseId, date);
        const activities = [];
        for (const file of courseFiles) {
          const content = yield this.app.vault.read(file);
          const fileType = this.determineFileType(file, content);
          activities.push({
            file: file.basename,
            type: fileType
          });
        }
        console.log(
          `Found ${activities.length} activities for course ${courseId} on ${date}`
        );
        return activities;
      } catch (error) {
        console.error(
          `Error getting course activity for ${courseId} on ${date}:`,
          error
        );
        return [];
      }
    });
  }
  extractDateFromPath(filePath) {
    const dateRegex = /(\d{4}-\d{2}-\d{2})/g;
    const matches = filePath.match(dateRegex);
    return matches ? matches[matches.length - 1] : null;
  }
  analyzeFileActivity(file) {
    return __async(this, null, function* () {
      try {
        const content = yield this.app.vault.read(file);
        const fileType = this.determineFileType(file, content);
        const courseId = this.extractCourseIdFromContent(content) || this.extractCourseIdFromPath(file.path);
        return {
          file: file.basename,
          type: fileType,
          course: courseId || void 0
        };
      } catch (error) {
        console.error(`Error analyzing file ${file.path}:`, error);
        return null;
      }
    });
  }
  determineFileType(file, content) {
    const path = file.path.toLowerCase();
    if (path.includes("daily") || content.includes("content_type: daily_note")) {
      return "daily_note";
    }
    if (path.includes("courses") || content.includes("course_id:")) {
      if (content.includes("content_type: course_homepage")) {
        return "course_homepage";
      }
      if (content.includes("content_type: module")) {
        return "module";
      }
      if (content.includes("content_type: chapter")) {
        return "chapter";
      }
      if (content.includes("content_type: assignment")) {
        return "assignment";
      }
      return "course_note";
    }
    if (content.includes("## ") && content.match(/^\*\*Term\*\*:/m)) {
      return "vocabulary_entry";
    }
    return "other";
  }
  extractCourseIdFromContent(content) {
    const courseIdRegex = /course_id:\s*([A-Z]{2,4}-\d{3})/;
    const match = content.match(courseIdRegex);
    return match ? match[1] : null;
  }
  extractCourseIdFromPath(filePath) {
    const courseIdRegex = /([A-Z]{2,4}-\d{3})/g;
    const matches = filePath.match(courseIdRegex);
    return matches ? matches[matches.length - 1] : null;
  }
  findCourseFilesForDate(courseId, date) {
    return __async(this, null, function* () {
      const files = [];
      const allFiles = this.app.vault.getMarkdownFiles();
      for (const file of allFiles) {
        if (file.path.includes(courseId) || (yield this.fileBelongsToCourse(file, courseId))) {
          const fileDate = this.extractDateFromPath(file.path);
          if (fileDate === date) {
            files.push(file);
          }
        }
      }
      return files;
    });
  }
  fileBelongsToCourse(file, courseId) {
    return __async(this, null, function* () {
      try {
        const content = yield this.app.vault.read(file);
        return this.extractCourseIdFromContent(content) === courseId;
      } catch (error) {
        console.error(
          `Error checking if file ${file.path} belongs to course ${courseId}:`,
          error
        );
        return false;
      }
    });
  }
  generateDailySummary(date) {
    return __async(this, null, function* () {
      const targetDate = date || new Date().toISOString().split("T")[0];
      const activities = yield this.getCourseActivityForDate("", targetDate);
      if (activities.length === 0) {
        return `# Academic Activities - ${targetDate}

No academic activities recorded for this date.
`;
      }
      const byCourse = {};
      const noCourse = [];
      for (const activity of activities) {
        if (activity.file.includes("Courses/")) {
          const pathParts = activity.file.split("/");
          const courseIndex = pathParts.findIndex((part) => part.includes("-"));
          if (courseIndex >= 0) {
            const courseId = pathParts[courseIndex];
            if (!byCourse[courseId]) {
              byCourse[courseId] = [];
            }
            byCourse[courseId].push(activity);
          } else {
            noCourse.push(activity);
          }
        } else {
          noCourse.push(activity);
        }
      }
      let content = `# Academic Activities - ${targetDate}

`;
      content += `Total activities: ${activities.length}

`;
      for (const [courseId, courseActivities] of Object.entries(byCourse)) {
        content += `## ${courseId}

`;
        content += `| File | Type |
`;
        content += `| ---- | ---- |
`;
        for (const activity of courseActivities) {
          content += `| ${activity.file} | ${activity.type} |
`;
        }
        content += `
`;
      }
      if (noCourse.length > 0) {
        content += `## Other Activities

`;
        content += `| File | Type |
`;
        content += `| ---- | ---- |
`;
        for (const activity of noCourse) {
          content += `| ${activity.file} | ${activity.type} |
`;
        }
        content += `
`;
      }
      return content;
    });
  }
  createDailySummaryFile(date) {
    return __async(this, null, function* () {
      try {
        const targetDate = date || new Date().toISOString().split("T")[0];
        const summaryContent = yield this.generateDailySummary(targetDate);
        const fileName = `${targetDate} - Academic Summary.md`;
        const filePath = `Daily/${fileName}`;
        try {
          yield this.app.vault.create(filePath, summaryContent);
          console.log(`Created daily summary file: ${filePath}`);
        } catch (error) {
          const existingFile = this.app.vault.getAbstractFileByPath(filePath);
          if (existingFile && existingFile instanceof import_obsidian7.TFile) {
            yield this.app.vault.modify(existingFile, summaryContent);
            console.log(`Updated daily summary file: ${filePath}`);
          }
        }
      } catch (error) {
        console.error(`Error creating daily summary for ${date}:`, error);
        throw error;
      }
    });
  }
};

// assignmentsModal.ts
var import_obsidian8 = require("obsidian");
var AssignmentsModal = class extends import_obsidian8.Modal {
  constructor(app, courseName, courseId, onSubmit) {
    super(app);
    this.assignments = [{ name: "", dueDate: "", type: "", points: "", description: "" }];
    this.courseName = courseName;
    this.courseId = courseId;
    this.onSubmit = onSubmit;
  }
  onOpen() {
    const { contentEl } = this;
    contentEl.empty();
    contentEl.addClass("tuckers-tools-assignments-modal");
    contentEl.createEl("h2", { text: "Create Multiple Assignments" });
    new import_obsidian8.Setting(contentEl).setName("Course").setDesc(`${this.courseName} (${this.courseId})`).setDisabled(true);
    const assignmentsContainer = contentEl.createDiv({ cls: "assignments-container" });
    this.addAssignmentSection(assignmentsContainer, 0);
    new import_obsidian8.Setting(contentEl).addButton(
      (btn) => btn.setButtonText("Add Assignment").setCta().onClick(() => {
        const newIndex = this.assignments.length;
        this.assignments.push({ name: "", dueDate: "", type: "", points: "", description: "" });
        this.addAssignmentSection(assignmentsContainer, newIndex);
      })
    );
    new import_obsidian8.Setting(contentEl).addButton(
      (btn) => btn.setButtonText("Create Assignments").setCta().onClick(() => {
        const validAssignments = this.assignments.filter(
          (a) => a.name.trim() !== "" || a.dueDate.trim() !== ""
        );
        this.onSubmit(validAssignments, this.courseName, this.courseId);
        this.close();
      })
    );
  }
  addAssignmentSection(container, index) {
    const section = container.createDiv({ cls: "assignment-section" });
    section.createEl("h3", { text: `Assignment #${index + 1}` });
    new import_obsidian8.Setting(section).setName("Assignment Name").addText(
      (text) => text.setPlaceholder("Enter assignment name").setValue(this.assignments[index].name).onChange((value) => {
        this.assignments[index].name = value;
      })
    );
    new import_obsidian8.Setting(section).setName("Due Date").setDesc("Format: YYYY-MM-DD").addText(
      (text) => text.setPlaceholder("2024-01-15").setValue(this.assignments[index].dueDate).onChange((value) => {
        this.assignments[index].dueDate = value;
      })
    );
    new import_obsidian8.Setting(section).setName("Assignment Type").addText(
      (text) => text.setPlaceholder("e.g., Homework, Quiz, Exam").setValue(this.assignments[index].type).onChange((value) => {
        this.assignments[index].type = value;
      })
    );
    new import_obsidian8.Setting(section).setName("Points").addText(
      (text) => text.setPlaceholder("e.g., 100").setValue(this.assignments[index].points).onChange((value) => {
        this.assignments[index].points = value;
      })
    );
    new import_obsidian8.Setting(section).setName("Description").addTextArea(
      (text) => text.setPlaceholder("Enter assignment description").setValue(this.assignments[index].description).onChange((value) => {
        this.assignments[index].description = value;
      })
    );
    if (this.assignments.length > 1) {
      new import_obsidian8.Setting(section).addButton(
        (btn) => btn.setButtonText("Remove").onClick(() => {
          this.assignments.splice(index, 1);
          section.remove();
          this.renumberAssignments();
        })
      );
    }
  }
  renumberAssignments() {
    const sections = this.contentEl.querySelectorAll(".assignment-section");
    sections.forEach((section, index) => {
      const header = section.querySelector("h3");
      if (header) {
        header.textContent = `Assignment #${index + 1}`;
      }
    });
  }
  onClose() {
    const { contentEl } = this;
    contentEl.empty();
  }
};

// Supporting/dataview-functions.ts
function processCourseVocabulary(dv, courseId) {
  return __async(this, null, function* () {
    try {
      const pages = dv.pages(courseId).filter((p) => p.file.ext === "md" && p.file.name !== courseId).map((p) => ({
        name: p.file.name,
        path: p.file.path
      }));
      dv.header(1, "All Course Vocabulary");
      for (const page of pages) {
        if (!page.path)
          continue;
        try {
          const file = yield dv.app.vault.getFileByPath(page.path);
          const content = yield dv.app.vault.read(file);
          const vocabRegex = /^#+ Vocabulary.*\n((?:.*?\n)*?)(?=\n\s*#|$)/m;
          const vocabMatches = content == null ? void 0 : content.match(vocabRegex);
          if (vocabMatches) {
            const vocabData = vocabMatches[1].trim();
            const cleanedVocab = vocabData.replace(/\[\[.*?\]\]/g, "").trim().split("\n").filter((line) => line.startsWith("- ")).map((line) => line.substring(2)).filter(Boolean);
            if (cleanedVocab.length > 0) {
              dv.header(3, `[[${page.name}]]`);
              dv.list(cleanedVocab);
            }
          }
        } catch (e) {
          console.log(`Error processing ${page.path}:`, e);
          continue;
        }
      }
    } catch (error) {
      console.error("Error in Vocabulary Processing:", error);
    }
  });
}
function processDueDates(dv, source, startDate = null, endDate = null) {
  return __async(this, null, function* () {
    var _a, _b, _c, _d, _e, _f, _g, _h;
    function deduplicateFirstTwoColumns(arr) {
      const seen = /* @__PURE__ */ new Set();
      return arr.filter((entry) => {
        const key = JSON.stringify([entry[0], entry[1]]);
        return !seen.has(key) && seen.add(key);
      });
    }
    const defaultStartDate = window.moment().subtract(1, "day").format("YYYY-MM-DD");
    const start = startDate || defaultStartDate;
    const end = endDate || window.moment().add(1, "year").format("YYYY-MM-DD");
    const pages = yield dv.pages(source).filter((p) => p.file.name !== source && p.file.ext == "md");
    let allEntries = [];
    for (const page of pages.values) {
      if (!((_a = page == null ? void 0 : page.file) == null ? void 0 : _a.path)) {
        return;
      }
      const content = yield dv.app.vault.cachedRead(dv.app.vault.getFileByPath((_b = page.file) == null ? void 0 : _b.path));
      const regex = /# Due Dates([\s\S]*?)(?=\n#|$)/;
      const matches = content == null ? void 0 : content.match(regex);
      if (matches) {
        const tableData = matches[1].trim();
        const lines = tableData.split("\n").slice(1);
        for (const line of lines) {
          let formattedDueDate;
          const columns = line.split("|").map((c) => c.trim()).filter((c) => c);
          let [dueDate, assignment] = columns;
          if (!Date.parse(dueDate) || (assignment == null ? void 0 : assignment.match(/✅/))) {
            continue;
          }
          assignment = (assignment == null ? void 0 : assignment.match(/[A-Z]{3}-[0-9]{3}/)) ? assignment : `#${page.course_id} - ${assignment}`;
          if (window.moment(dueDate).isBetween(start, end, void 0, "[]")) {
            const uniqueRow = !allEntries.some(
              (e) => {
                var _a2;
                return e[0].match((_a2 = window.moment(dueDate)) == null ? void 0 : _a2.format("YYYY-MM-DD")) && e[1] == assignment;
              }
            );
            if (assignment && uniqueRow) {
              if ((_c = window.moment(dueDate)) == null ? void 0 : _c.isBefore(start)) {
                continue;
              } else if (window.moment(dueDate).isAfter(window.moment().subtract(1, "w"))) {
                formattedDueDate = `<span class="due one_week">${(_d = window.moment(
                  dueDate
                )) == null ? void 0 : _d.format("YYYY-MM-DD ddd")}</span>`;
              } else if (window.moment(dueDate).isAfter(window.moment().subtract(2, "w"))) {
                formattedDueDate = `<span class="due two_weeks">${(_e = window.moment(
                  dueDate
                )) == null ? void 0 : _e.format("YYYY-MM-DD ddd")}</span>`;
              } else {
                formattedDueDate = (_f = window.moment(dueDate)) == null ? void 0 : _f.format("YYYY-MM-DD ddd");
              }
              allEntries.push([
                dueDate,
                formattedDueDate,
                assignment,
                `[[${(_g = page == null ? void 0 : page.file) == null ? void 0 : _g.path}|${(_h = page == null ? void 0 : page.file) == null ? void 0 : _h.name}]]`
              ]);
            }
          }
        }
      }
    }
    const sortedRows = deduplicateFirstTwoColumns(
      allEntries.sort((a, b) => window.moment(a[0]).valueOf() - window.moment(b[0]).valueOf()).map((a) => [a[1], a[2], a[3]])
    );
    const table = dv.markdownTable(["Due Date", "Task Description", "File"], sortedRows);
    dv.el("table", table);
  });
}

// main.ts
var TuckersToolsPlugin = class extends import_obsidian9.Plugin {
  onload() {
    return __async(this, null, function* () {
      console.log("Loading Tuckers Tools plugin");
      yield this.loadSettings();
      this.templateManager = new TemplateManager(this.app, this.settings);
      this.courseWizard = new CourseCreationWizard(this.app, this.settings);
      this.vocabularyExtractor = new VocabularyExtractor(this.app);
      this.dueDatesParser = new DueDatesParser(this.app);
      this.dailyNotesIntegration = new DailyNotesIntegration(this.app);
      this.dataviewFunctions = { processCourseVocabulary, processDueDates };
      this.addSettingTab(new TuckersToolsSettingTab(this.app, this));
      this.initializeTemplaterFunctions();
      this.addCommand({
        id: "install-templates",
        name: "Install/Update Tuckers Tools Templates",
        callback: () => {
          this.templateManager.installTemplates();
        }
      });
      this.addCommand({
        id: "update-templates",
        name: "Update Tuckers Tools Templates",
        callback: () => {
          this.templateManager.updateTemplates();
        }
      });
      this.addCommand({
        id: "create-multiple-assignments",
        name: "Create Multiple Assignments for Course",
        callback: () => __async(this, null, function* () {
          const currentFile = this.app.workspace.getActiveFile();
          let courseId = "";
          let courseName = "";
          if (currentFile) {
            const cache = this.app.metadataCache.getFileCache(currentFile);
            if (cache && cache.frontmatter) {
              courseId = cache.frontmatter.course_id || "";
              courseName = cache.frontmatter.course_name || cache.frontmatter.title || currentFile.basename;
            }
          }
          if (!courseId) {
            const promptedCourseId = yield this.promptForCourseId("Enter course ID for assignments");
            if (!promptedCourseId)
              return;
            courseId = promptedCourseId;
            courseName = courseId;
          }
          new AssignmentsModal(
            this.app,
            courseName,
            courseId,
            (assignments, courseName2, courseId2) => __async(this, null, function* () {
              for (const assignment of assignments) {
                if (assignment.name.trim() === "")
                  continue;
                const assignmentContent = this.generateAssignmentFileContent(
                  assignment,
                  courseName2,
                  courseId2
                );
                const fileName = `${courseId2} - ${assignment.name.replace(/[<>:"/\\|?*]/g, "_")}.md`;
                const filePath = `${courseId2}/${fileName}`;
                try {
                  yield this.app.vault.create(filePath, assignmentContent);
                  console.log(`Created assignment file: ${filePath}`);
                } catch (error) {
                  console.error(`Error creating assignment file ${filePath}:`, error);
                }
              }
            })
          ).open();
        })
      });
      this.addCommand({
        id: "extract-vocabulary",
        name: "Extract Course Vocabulary",
        callback: () => __async(this, null, function* () {
          const courseId = yield this.promptForCourseId(
            "Enter course ID to extract vocabulary from"
          );
          if (courseId) {
            yield this.vocabularyExtractor.createVocabularyIndexFile(courseId);
          }
        })
      });
      this.addCommand({
        id: "generate-due-dates-summary",
        name: "Generate Due Dates Summary",
        callback: () => __async(this, null, function* () {
          const courseId = yield this.promptForCourseId(
            "Enter course ID to generate due dates summary for"
          );
          if (courseId) {
            yield this.dueDatesParser.createDueDatesSummaryFile(courseId);
          }
        })
      });
      this.addCommand({
        id: "generate-daily-summary",
        name: "Generate Daily Academic Summary",
        callback: () => __async(this, null, function* () {
          const date = yield this.promptForDate(
            "Enter date (YYYY-MM-DD) or leave empty for today"
          );
          yield this.dailyNotesIntegration.createDailySummaryFile(
            date || void 0
          );
        })
      });
      this.addStatusBarItem().setText("Tuckers Tools");
    });
  }
  promptForCourseId(message) {
    return __async(this, null, function* () {
      const courseId = prompt(message + "\n\nExample: PSI-101");
      return courseId ? courseId.trim() : null;
    });
  }
  promptForDate(message) {
    return __async(this, null, function* () {
      const date = prompt(
        message + "\n\nExample: 2025-01-15 or leave empty for today"
      );
      return date ? date.trim() : null;
    });
  }
  generateAssignmentFileContent(assignment, courseName, courseId) {
    return `---
course_id: ${courseId}
assignment_type: ${assignment.type || "Assignment"}
due_date: ${assignment.dueDate}
points: ${assignment.points || ""}
content_type: assignment
created: ${new Date().toISOString()}
status: pending
tags:
  - education
  - ${courseId}
  - assignment
---

# ${assignment.name} - ${courseId}

## Description
${assignment.description}

## Instructions


## Due Date
**Assigned**: ${new Date().toISOString().split("T")[0]}
**Due**: ${assignment.dueDate}

## Submission


## Grading Criteria


## Resources


# Due Dates
| ${assignment.dueDate} | ${assignment.name} | pending |
`;
  }
  onunload() {
    console.log("Unloading Tuckers Tools plugin");
  }
  initializeTemplaterFunctions() {
    return __async(this, null, function* () {
      try {
        if (!this.app.globals) {
          this.app.globals = {};
        }
        if (!this.app.globals.tuckersTools) {
          this.app.globals.tuckersTools = {};
        }
        this.app.globals.tuckersTools.new_module = (app, tp, year) => __async(this, null, function* () {
          return this.newModuleFunction(app, tp, year);
        });
        this.app.globals.tuckersTools.new_chapter = (tp) => __async(this, null, function* () {
          return this.newChapterFunction(tp);
        });
        this.app.globals.tuckersTools.processCourseVocabulary = (dv, courseId) => __async(this, null, function* () {
          return processCourseVocabulary(dv, courseId);
        });
        this.app.globals.tuckersTools.processDueDates = (dv, source, startDate = null, endDate = null) => __async(this, null, function* () {
          return processDueDates(dv, source, startDate, endDate);
        });
        const templaterPlugin = this.app.plugins.getPlugin("templater-obsidian");
        if (templaterPlugin && templaterPlugin.templater && templaterPlugin.templater.functions) {
          if (!templaterPlugin.templater.functions.user) {
            templaterPlugin.templater.functions.user = {};
          }
          templaterPlugin.templater.functions.user["new_module"] = (app, tp, year) => __async(this, null, function* () {
            return this.newModuleFunction(app, tp, year);
          });
          templaterPlugin.templater.functions.user["new_chapter"] = (tp) => __async(this, null, function* () {
            return this.newChapterFunction(tp);
          });
          templaterPlugin.templater.functions.user["processCourseVocabulary"] = (dv, courseId) => __async(this, null, function* () {
            return processCourseVocabulary(dv, courseId);
          });
          templaterPlugin.templater.functions.user["processDueDates"] = (dv, source, startDate = null, endDate = null) => __async(this, null, function* () {
            return processDueDates(dv, source, startDate, endDate);
          });
          console.log("Tuckers Tools templater functions registered successfully in both global and tp.user namespaces");
        } else {
          console.log("Templater plugin not found or not fully loaded, functions registered in global namespace only");
        }
        console.log("Tuckers Tools global functions registered successfully");
      } catch (e) {
        console.error("Error registering Tuckers Tools global functions:", e);
      }
    });
  }
  newModuleFunction(app, tp, year) {
    return __async(this, null, function* () {
      var _a, _b;
      let moduleNumber = "";
      let weekNumber = "";
      let course = "";
      let courseId = "";
      let discipline = "GEN";
      let dayOfWeek = "";
      let season = "";
      try {
        if (tp && tp.system && tp.system.prompt) {
          const currentDate = new Date();
          const currentYear = currentDate.getFullYear().toString();
          const currentMonth = currentDate.getMonth();
          let currentSemester = "Fall";
          if (currentMonth >= 0 && currentMonth <= 4) {
            currentSemester = "Spring";
          } else if (currentMonth >= 5 && currentMonth <= 7) {
            currentSemester = "Summer";
          } else {
            currentSemester = "Fall";
          }
          console.log(`Filtering courses for ${currentSemester} ${currentYear}`);
          const courseFiles = app.vault.getMarkdownFiles().filter((f) => {
            const cache = app.metadataCache.getFileCache(f);
            if (!cache)
              return false;
            const isCourseFile = cache && (cache.tags && cache.tags.some((tag) => tag.tag === "#course_home") || cache.frontmatter && cache.frontmatter.contentType === "Course" || cache.frontmatter && cache.frontmatter.tags && (Array.isArray(cache.frontmatter.tags) ? cache.frontmatter.tags.includes("course_home") : cache.frontmatter.tags === "course_home"));
            return isCourseFile;
          });
          console.log(`Found ${courseFiles.length} total course files`);
          const currentSemesterFiles = courseFiles.filter((f) => {
            const cache = app.metadataCache.getFileCache(f);
            if (!cache || !cache.frontmatter)
              return false;
            const courseYear = cache.frontmatter.course_year || cache.frontmatter.courseYear || "";
            const courseSeason = cache.frontmatter.course_season || cache.frontmatter.courseSeason || "";
            return courseYear === currentYear && courseSeason === currentSemester;
          });
          console.log(`Found ${currentSemesterFiles.length} current semester files`);
          console.log(`Found ${courseFiles.length} course files for ${currentSemester} ${currentYear}`);
          const filesToShow = currentSemesterFiles.length > 0 ? currentSemesterFiles : courseFiles;
          const promptMessage = currentSemesterFiles.length > 0 ? `Select Course (${currentSemester} ${currentYear})` : `Select Course (All Semesters - ${courseFiles.length} courses)`;
          console.log(`Showing ${filesToShow.length} courses with message: ${promptMessage}`);
          if (filesToShow.length > 0) {
            course = yield tp.system.suggester(
              filesToShow.map((f) => f.basename),
              // Display labels
              filesToShow,
              // Actual values
              promptMessage
            );
          } else {
            course = yield tp.system.prompt("Course Name", "New Course");
          }
          const tempModuleNumber = yield tp.system.prompt("Module Number (optional)", "");
          moduleNumber = tempModuleNumber ? tempModuleNumber : null;
          const tempWeekNumber = yield tp.system.prompt("Week Number (optional)", "");
          weekNumber = tempWeekNumber ? tempWeekNumber : null;
          dayOfWeek = yield tp.system.suggester(
            ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
            // Display labels
            ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
            // Actual values
            "Day of Week"
          );
          season = currentSemester;
        } else {
          moduleNumber = null;
          weekNumber = null;
          course = "New Course";
          dayOfWeek = "Monday";
          season = "Fall";
        }
      } catch (e) {
        console.error("Error in new_module prompts:", e);
        moduleNumber = null;
        weekNumber = null;
        course = "New Course";
        dayOfWeek = "Monday";
        season = "Fall";
      }
      if (typeof course === "object" && course !== null && course.basename) {
        courseId = course.basename.split(" - ")[0] || course.basename;
        discipline = ((_a = course.basename.split(" - ")[0]) == null ? void 0 : _a.substring(0, 3)) || "GEN";
      } else if (typeof course === "string") {
        courseId = course.split(" - ")[0] || course;
        discipline = ((_b = course.split(" - ")[0]) == null ? void 0 : _b.substring(0, 3)) || "GEN";
      } else {
        courseId = "";
        discipline = "GEN";
      }
      return {
        season,
        moduleNumber,
        weekNumber,
        course,
        courseId,
        discipline,
        dayOfWeek
      };
    });
  }
  newChapterFunction(tp) {
    return __async(this, null, function* () {
      var _a;
      let chapterNumber = "";
      let course = "";
      let courseId = "";
      let discipline = "GEN";
      let text = "";
      try {
        if (tp && tp.system && tp.system.prompt) {
          chapterNumber = (yield tp.system.prompt("Chapter Number", "")) || "";
          const courseFiles = tp.app.vault.getMarkdownFiles().filter((f) => {
            const cache = tp.app.metadataCache.getFileCache(f);
            return cache && (cache.tags && cache.tags.some((tag) => tag.tag === "#course_home") || cache.frontmatter && cache.frontmatter.contentType === "Course" || cache.frontmatter && cache.frontmatter.tags && (Array.isArray(cache.frontmatter.tags) ? cache.frontmatter.tags.includes("course_home") : cache.frontmatter.tags === "course_home"));
          });
          course = yield tp.system.suggester(
            () => courseFiles.map((f) => f.basename),
            courseFiles
          );
          const textOptions = tp.app.vault.getFiles().filter((f) => f.extension === "pdf").map((f) => f.basename);
          text = yield tp.system.suggester(textOptions, textOptions, "Textbook");
        } else {
          chapterNumber = "";
          course = "New Course";
          text = "New Textbook";
        }
      } catch (e) {
        console.error("Error in new_chapter prompts:", e);
        chapterNumber = "";
        course = "New Course";
        text = "New Textbook";
      }
      courseId = course ? course.split(" - ")[0] || course : "";
      discipline = course ? ((_a = course.split(" - ")[0]) == null ? void 0 : _a.substring(0, 3)) || "GEN" : "GEN";
      return {
        chapterNumber,
        course,
        courseId,
        discipline,
        text
      };
    });
  }
  loadSettings() {
    return __async(this, null, function* () {
      this.settings = Object.assign({}, DEFAULT_SETTINGS, yield this.loadData());
    });
  }
  saveSettings() {
    return __async(this, null, function* () {
      yield this.saveData(this.settings);
    });
  }
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsibWFpbi50cyIsICJzZXR0aW5ncy50cyIsICJ1dGlscy50cyIsICJ0ZW1wbGF0ZU1hbmFnZXIudHMiLCAiY291cnNlV2l6YXJkLnRzIiwgImlucHV0TW9kYWwudHMiLCAidm9jYWJ1bGFyeS50cyIsICJkdWVEYXRlcy50cyIsICJkYWlseU5vdGVzLnRzIiwgImFzc2lnbm1lbnRzTW9kYWwudHMiLCAiU3VwcG9ydGluZy9kYXRhdmlldy1mdW5jdGlvbnMudHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbImltcG9ydCB7IFBsdWdpbiwgTm90aWNlLCBURmlsZSB9IGZyb20gXCJvYnNpZGlhblwiXG5pbXBvcnQge1xuICBUdWNrZXJzVG9vbHNTZXR0aW5ncyxcbiAgREVGQVVMVF9TRVRUSU5HUyxcbiAgVHVja2Vyc1Rvb2xzU2V0dGluZ1RhYlxufSBmcm9tIFwiLi9zZXR0aW5nc1wiXG5pbXBvcnQgeyBUZW1wbGF0ZU1hbmFnZXIgfSBmcm9tIFwiLi90ZW1wbGF0ZU1hbmFnZXJcIlxuaW1wb3J0IHsgQ291cnNlQ3JlYXRpb25XaXphcmQgfSBmcm9tIFwiLi9jb3Vyc2VXaXphcmRcIlxuaW1wb3J0IHsgVm9jYWJ1bGFyeUV4dHJhY3RvciB9IGZyb20gXCIuL3ZvY2FidWxhcnlcIlxuaW1wb3J0IHsgRHVlRGF0ZXNQYXJzZXIgfSBmcm9tIFwiLi9kdWVEYXRlc1wiXG5pbXBvcnQgeyBEYWlseU5vdGVzSW50ZWdyYXRpb24gfSBmcm9tIFwiLi9kYWlseU5vdGVzXCJcbmltcG9ydCB7IEFzc2lnbm1lbnRzTW9kYWwgfSBmcm9tIFwiLi9hc3NpZ25tZW50c01vZGFsXCJcblxuaW1wb3J0IHsgcHJvY2Vzc0NvdXJzZVZvY2FidWxhcnksIHByb2Nlc3NEdWVEYXRlcyB9IGZyb20gXCIuL1N1cHBvcnRpbmcvZGF0YXZpZXctZnVuY3Rpb25zXCI7XG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFR1Y2tlcnNUb29sc1BsdWdpbiBleHRlbmRzIFBsdWdpbiB7XG4gIHNldHRpbmdzOiBUdWNrZXJzVG9vbHNTZXR0aW5nc1xuICB0ZW1wbGF0ZU1hbmFnZXI6IFRlbXBsYXRlTWFuYWdlclxuICBjb3Vyc2VXaXphcmQ6IENvdXJzZUNyZWF0aW9uV2l6YXJkXG4gIHZvY2FidWxhcnlFeHRyYWN0b3I6IFZvY2FidWxhcnlFeHRyYWN0b3JcbiAgZHVlRGF0ZXNQYXJzZXI6IER1ZURhdGVzUGFyc2VyXG4gIGRhaWx5Tm90ZXNJbnRlZ3JhdGlvbjogRGFpbHlOb3Rlc0ludGVncmF0aW9uXG4gIGRhdGF2aWV3RnVuY3Rpb25zOiBhbnk7XG5cbiAgYXN5bmMgb25sb2FkKCkge1xuICAgIGNvbnNvbGUubG9nKFwiTG9hZGluZyBUdWNrZXJzIFRvb2xzIHBsdWdpblwiKVxuXG4gICAgLy8gTG9hZCBzZXR0aW5nc1xuICAgIGF3YWl0IHRoaXMubG9hZFNldHRpbmdzKClcblxuICAgIC8vIEluaXRpYWxpemUgY29tcG9uZW50c1xuICAgIHRoaXMudGVtcGxhdGVNYW5hZ2VyID0gbmV3IFRlbXBsYXRlTWFuYWdlcih0aGlzLmFwcCwgdGhpcy5zZXR0aW5ncylcbiAgICB0aGlzLmNvdXJzZVdpemFyZCA9IG5ldyBDb3Vyc2VDcmVhdGlvbldpemFyZCh0aGlzLmFwcCwgdGhpcy5zZXR0aW5ncylcbiAgICB0aGlzLnZvY2FidWxhcnlFeHRyYWN0b3IgPSBuZXcgVm9jYWJ1bGFyeUV4dHJhY3Rvcih0aGlzLmFwcClcbiAgICB0aGlzLmR1ZURhdGVzUGFyc2VyID0gbmV3IER1ZURhdGVzUGFyc2VyKHRoaXMuYXBwKVxuICAgIHRoaXMuZGFpbHlOb3Rlc0ludGVncmF0aW9uID0gbmV3IERhaWx5Tm90ZXNJbnRlZ3JhdGlvbih0aGlzLmFwcClcbiAgICB0aGlzLmRhdGF2aWV3RnVuY3Rpb25zID0geyBwcm9jZXNzQ291cnNlVm9jYWJ1bGFyeSwgcHJvY2Vzc0R1ZURhdGVzIH07XG5cbiAgICAvLyBBZGQgc2V0dGluZ3MgdGFiXG4gICAgdGhpcy5hZGRTZXR0aW5nVGFiKG5ldyBUdWNrZXJzVG9vbHNTZXR0aW5nVGFiKHRoaXMuYXBwLCB0aGlzKSlcblxuICAgIC8vIEluaXRpYWxpemUgdGVtcGxhdGVyIGZ1bmN0aW9ucyBpZiB0ZW1wbGF0ZXIgaXMgYXZhaWxhYmxlXG4gICAgdGhpcy5pbml0aWFsaXplVGVtcGxhdGVyRnVuY3Rpb25zKClcblxuICAgIC8vIEFkZCBjb21tYW5kc1xuICAgIHRoaXMuYWRkQ29tbWFuZCh7XG4gICAgICBpZDogXCJpbnN0YWxsLXRlbXBsYXRlc1wiLFxuICAgICAgbmFtZTogXCJJbnN0YWxsL1VwZGF0ZSBUdWNrZXJzIFRvb2xzIFRlbXBsYXRlc1wiLFxuICAgICAgY2FsbGJhY2s6ICgpID0+IHtcbiAgICAgICAgdGhpcy50ZW1wbGF0ZU1hbmFnZXIuaW5zdGFsbFRlbXBsYXRlcygpXG4gICAgICB9XG4gICAgfSlcblxuICAgIHRoaXMuYWRkQ29tbWFuZCh7XG4gICAgICBpZDogXCJ1cGRhdGUtdGVtcGxhdGVzXCIsXG4gICAgICBuYW1lOiBcIlVwZGF0ZSBUdWNrZXJzIFRvb2xzIFRlbXBsYXRlc1wiLFxuICAgICAgY2FsbGJhY2s6ICgpID0+IHtcbiAgICAgICAgdGhpcy50ZW1wbGF0ZU1hbmFnZXIudXBkYXRlVGVtcGxhdGVzKClcbiAgICAgIH1cbiAgICB9KVxuXG4gICAgLy8gQ291cnNlIGNyZWF0aW9uIGlzIGhhbmRsZWQgYnkgVGVtcGxhdGVyIHRlbXBsYXRlcyAtIG5vIGN1c3RvbSBjb21tYW5kIG5lZWRlZFxuXG4gICAgdGhpcy5hZGRDb21tYW5kKHtcbiAgICAgIGlkOiBcImNyZWF0ZS1tdWx0aXBsZS1hc3NpZ25tZW50c1wiLFxuICAgICAgbmFtZTogXCJDcmVhdGUgTXVsdGlwbGUgQXNzaWdubWVudHMgZm9yIENvdXJzZVwiLFxuICAgICAgY2FsbGJhY2s6IGFzeW5jICgpID0+IHtcbiAgICAgICAgLy8gR2V0IHRoZSBjdXJyZW50IGNvdXJzZSBjb250ZXh0IG9yIHByb21wdCBmb3IgaXRcbiAgICAgICAgY29uc3QgY3VycmVudEZpbGUgPSB0aGlzLmFwcC53b3Jrc3BhY2UuZ2V0QWN0aXZlRmlsZSgpO1xuICAgICAgICBsZXQgY291cnNlSWQgPSBcIlwiO1xuICAgICAgICBsZXQgY291cnNlTmFtZSA9IFwiXCI7XG5cbiAgICAgICAgLy8gVHJ5IHRvIGRldGVybWluZSB0aGUgY291cnNlIGZyb20gdGhlIGN1cnJlbnQgZmlsZVxuICAgICAgICBpZiAoY3VycmVudEZpbGUpIHtcbiAgICAgICAgICBjb25zdCBjYWNoZSA9IHRoaXMuYXBwLm1ldGFkYXRhQ2FjaGUuZ2V0RmlsZUNhY2hlKGN1cnJlbnRGaWxlKTtcbiAgICAgICAgICBpZiAoY2FjaGUgJiYgY2FjaGUuZnJvbnRtYXR0ZXIpIHtcbiAgICAgICAgICAgIGNvdXJzZUlkID0gY2FjaGUuZnJvbnRtYXR0ZXIuY291cnNlX2lkIHx8IFwiXCI7XG4gICAgICAgICAgICBjb3Vyc2VOYW1lID0gY2FjaGUuZnJvbnRtYXR0ZXIuY291cnNlX25hbWUgfHwgY2FjaGUuZnJvbnRtYXR0ZXIudGl0bGUgfHwgY3VycmVudEZpbGUuYmFzZW5hbWU7XG4gICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgLy8gSWYgd2UgY291bGRuJ3QgZGV0ZXJtaW5lIHRoZSBjb3Vyc2UsIHByb21wdCBmb3IgaXRcbiAgICAgICAgaWYgKCFjb3Vyc2VJZCkge1xuICAgICAgICAgIGNvbnN0IHByb21wdGVkQ291cnNlSWQgPSBhd2FpdCB0aGlzLnByb21wdEZvckNvdXJzZUlkKFwiRW50ZXIgY291cnNlIElEIGZvciBhc3NpZ25tZW50c1wiKTtcbiAgICAgICAgICBpZiAoIXByb21wdGVkQ291cnNlSWQpIHJldHVybjtcbiAgICAgICAgICBjb3Vyc2VJZCA9IHByb21wdGVkQ291cnNlSWQ7XG4gICAgICAgICAgY291cnNlTmFtZSA9IGNvdXJzZUlkOyAvLyBGYWxsYmFjayBpZiB3ZSBkb24ndCBoYXZlIGEgYmV0dGVyIG5hbWVcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIFNob3cgdGhlIGFzc2lnbm1lbnRzIG1vZGFsXG4gICAgICAgIG5ldyBBc3NpZ25tZW50c01vZGFsKFxuICAgICAgICAgIHRoaXMuYXBwLFxuICAgICAgICAgIGNvdXJzZU5hbWUsXG4gICAgICAgICAgY291cnNlSWQsXG4gICAgICAgICAgYXN5bmMgKGFzc2lnbm1lbnRzLCBjb3Vyc2VOYW1lLCBjb3Vyc2VJZCkgPT4ge1xuICAgICAgICAgICAgLy8gUHJvY2VzcyB0aGUgYXNzaWdubWVudHMgLSBmb3Igbm93LCB3ZSdsbCBjcmVhdGUgaW5kaXZpZHVhbCBhc3NpZ25tZW50IGZpbGVzXG4gICAgICAgICAgICBmb3IgKGNvbnN0IGFzc2lnbm1lbnQgb2YgYXNzaWdubWVudHMpIHtcbiAgICAgICAgICAgICAgaWYgKGFzc2lnbm1lbnQubmFtZS50cmltKCkgPT09IFwiXCIpIGNvbnRpbnVlOyAvLyBTa2lwIGVtcHR5IGFzc2lnbm1lbnRzXG5cbiAgICAgICAgICAgICAgLy8gQ3JlYXRlIGFuIGFzc2lnbm1lbnQgZmlsZVxuICAgICAgICAgICAgICBjb25zdCBhc3NpZ25tZW50Q29udGVudCA9IHRoaXMuZ2VuZXJhdGVBc3NpZ25tZW50RmlsZUNvbnRlbnQoXG4gICAgICAgICAgICAgICAgYXNzaWdubWVudCxcbiAgICAgICAgICAgICAgICBjb3Vyc2VOYW1lLFxuICAgICAgICAgICAgICAgIGNvdXJzZUlkXG4gICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgIGNvbnN0IGZpbGVOYW1lID0gYCR7Y291cnNlSWR9IC0gJHthc3NpZ25tZW50Lm5hbWUucmVwbGFjZSgvWzw+OlwiL1xcXFx8PypdL2csIFwiX1wiKX0ubWRgO1xuICAgICAgICAgICAgICBjb25zdCBmaWxlUGF0aCA9IGAke2NvdXJzZUlkfS8ke2ZpbGVOYW1lfWA7XG5cbiAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBhd2FpdCB0aGlzLmFwcC52YXVsdC5jcmVhdGUoZmlsZVBhdGgsIGFzc2lnbm1lbnRDb250ZW50KTtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhgQ3JlYXRlZCBhc3NpZ25tZW50IGZpbGU6ICR7ZmlsZVBhdGh9YCk7XG4gICAgICAgICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihgRXJyb3IgY3JlYXRpbmcgYXNzaWdubWVudCBmaWxlICR7ZmlsZVBhdGh9OmAsIGVycm9yKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgKS5vcGVuKCk7XG4gICAgICB9XG4gICAgfSlcblxuICAgIHRoaXMuYWRkQ29tbWFuZCh7XG4gICAgICBpZDogXCJleHRyYWN0LXZvY2FidWxhcnlcIixcbiAgICAgIG5hbWU6IFwiRXh0cmFjdCBDb3Vyc2UgVm9jYWJ1bGFyeVwiLFxuICAgICAgY2FsbGJhY2s6IGFzeW5jICgpID0+IHtcbiAgICAgICAgY29uc3QgY291cnNlSWQgPSBhd2FpdCB0aGlzLnByb21wdEZvckNvdXJzZUlkKFxuICAgICAgICAgIFwiRW50ZXIgY291cnNlIElEIHRvIGV4dHJhY3Qgdm9jYWJ1bGFyeSBmcm9tXCJcbiAgICAgICAgKVxuICAgICAgICBpZiAoY291cnNlSWQpIHtcbiAgICAgICAgICBhd2FpdCB0aGlzLnZvY2FidWxhcnlFeHRyYWN0b3IuY3JlYXRlVm9jYWJ1bGFyeUluZGV4RmlsZShjb3Vyc2VJZClcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0pXG5cbiAgICB0aGlzLmFkZENvbW1hbmQoe1xuICAgICAgaWQ6IFwiZ2VuZXJhdGUtZHVlLWRhdGVzLXN1bW1hcnlcIixcbiAgICAgIG5hbWU6IFwiR2VuZXJhdGUgRHVlIERhdGVzIFN1bW1hcnlcIixcbiAgICAgIGNhbGxiYWNrOiBhc3luYyAoKSA9PiB7XG4gICAgICAgIGNvbnN0IGNvdXJzZUlkID0gYXdhaXQgdGhpcy5wcm9tcHRGb3JDb3Vyc2VJZChcbiAgICAgICAgICBcIkVudGVyIGNvdXJzZSBJRCB0byBnZW5lcmF0ZSBkdWUgZGF0ZXMgc3VtbWFyeSBmb3JcIlxuICAgICAgICApXG4gICAgICAgIGlmIChjb3Vyc2VJZCkge1xuICAgICAgICAgIGF3YWl0IHRoaXMuZHVlRGF0ZXNQYXJzZXIuY3JlYXRlRHVlRGF0ZXNTdW1tYXJ5RmlsZShjb3Vyc2VJZClcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0pXG5cbiAgICB0aGlzLmFkZENvbW1hbmQoe1xuICAgICAgaWQ6IFwiZ2VuZXJhdGUtZGFpbHktc3VtbWFyeVwiLFxuICAgICAgbmFtZTogXCJHZW5lcmF0ZSBEYWlseSBBY2FkZW1pYyBTdW1tYXJ5XCIsXG4gICAgICBjYWxsYmFjazogYXN5bmMgKCkgPT4ge1xuICAgICAgICBjb25zdCBkYXRlID0gYXdhaXQgdGhpcy5wcm9tcHRGb3JEYXRlKFxuICAgICAgICAgIFwiRW50ZXIgZGF0ZSAoWVlZWS1NTS1ERCkgb3IgbGVhdmUgZW1wdHkgZm9yIHRvZGF5XCJcbiAgICAgICAgKVxuICAgICAgICBhd2FpdCB0aGlzLmRhaWx5Tm90ZXNJbnRlZ3JhdGlvbi5jcmVhdGVEYWlseVN1bW1hcnlGaWxlKFxuICAgICAgICAgIGRhdGUgfHwgdW5kZWZpbmVkXG4gICAgICAgIClcbiAgICAgIH1cbiAgICB9KVxuXG4gICAgLy8gQWRkIHN0YXR1cyBiYXIgaXRlbVxuICAgIHRoaXMuYWRkU3RhdHVzQmFySXRlbSgpLnNldFRleHQoXCJUdWNrZXJzIFRvb2xzXCIpXG4gIH1cblxuICBwcml2YXRlIGFzeW5jIHByb21wdEZvckNvdXJzZUlkKG1lc3NhZ2U6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nIHwgbnVsbD4ge1xuICAgIGNvbnN0IGNvdXJzZUlkID0gcHJvbXB0KG1lc3NhZ2UgKyBcIlxcblxcbkV4YW1wbGU6IFBTSS0xMDFcIilcbiAgICByZXR1cm4gY291cnNlSWQgPyBjb3Vyc2VJZC50cmltKCkgOiBudWxsXG4gIH1cblxuICBwcml2YXRlIGFzeW5jIHByb21wdEZvckRhdGUobWVzc2FnZTogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmcgfCBudWxsPiB7XG4gICAgY29uc3QgZGF0ZSA9IHByb21wdChcbiAgICAgIG1lc3NhZ2UgKyBcIlxcblxcbkV4YW1wbGU6IDIwMjUtMDEtMTUgb3IgbGVhdmUgZW1wdHkgZm9yIHRvZGF5XCJcbiAgICApXG4gICAgcmV0dXJuIGRhdGUgPyBkYXRlLnRyaW0oKSA6IG51bGxcbiAgfVxuXG4gIGdlbmVyYXRlQXNzaWdubWVudEZpbGVDb250ZW50KGFzc2lnbm1lbnQ6IGFueSwgY291cnNlTmFtZTogc3RyaW5nLCBjb3Vyc2VJZDogc3RyaW5nKTogc3RyaW5nIHtcbiAgICAvLyBDcmVhdGUgdGhlIGFzc2lnbm1lbnQgZmlsZSBjb250ZW50IHVzaW5nIHRoZSBhc3NpZ25tZW50IHRlbXBsYXRlIHN0cnVjdHVyZVxuICAgIHJldHVybiBgLS0tXG5jb3Vyc2VfaWQ6ICR7Y291cnNlSWR9XG5hc3NpZ25tZW50X3R5cGU6ICR7YXNzaWdubWVudC50eXBlIHx8IFwiQXNzaWdubWVudFwifVxuZHVlX2RhdGU6ICR7YXNzaWdubWVudC5kdWVEYXRlfVxucG9pbnRzOiAke2Fzc2lnbm1lbnQucG9pbnRzIHx8IFwiXCJ9XG5jb250ZW50X3R5cGU6IGFzc2lnbm1lbnRcbmNyZWF0ZWQ6ICR7bmV3IERhdGUoKS50b0lTT1N0cmluZygpfVxuc3RhdHVzOiBwZW5kaW5nXG50YWdzOlxuICAtIGVkdWNhdGlvblxuICAtICR7Y291cnNlSWR9XG4gIC0gYXNzaWdubWVudFxuLS0tXG5cbiMgJHthc3NpZ25tZW50Lm5hbWV9IC0gJHtjb3Vyc2VJZH1cblxuIyMgRGVzY3JpcHRpb25cbiR7YXNzaWdubWVudC5kZXNjcmlwdGlvbn1cblxuIyMgSW5zdHJ1Y3Rpb25zXG5cblxuIyMgRHVlIERhdGVcbioqQXNzaWduZWQqKjogJHtuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc3BsaXQoJ1QnKVswXX1cbioqRHVlKio6ICR7YXNzaWdubWVudC5kdWVEYXRlfVxuXG4jIyBTdWJtaXNzaW9uXG5cblxuIyMgR3JhZGluZyBDcml0ZXJpYVxuXG5cbiMjIFJlc291cmNlc1xuXG5cbiMgRHVlIERhdGVzXG58ICR7YXNzaWdubWVudC5kdWVEYXRlfSB8ICR7YXNzaWdubWVudC5uYW1lfSB8IHBlbmRpbmcgfFxuYDtcbiAgfVxuXG4gIG9udW5sb2FkKCkge1xuICAgIGNvbnNvbGUubG9nKFwiVW5sb2FkaW5nIFR1Y2tlcnMgVG9vbHMgcGx1Z2luXCIpXG4gIH1cblxuICBhc3luYyBpbml0aWFsaXplVGVtcGxhdGVyRnVuY3Rpb25zKCkge1xuICAgIC8vIFJlZ2lzdGVyIG91ciBjdXN0b20gdGVtcGxhdGVyIGZ1bmN0aW9ucyBpbiB0aGUgZ2xvYmFsIG5hbWVzcGFjZVxuICAgICAgLy8gVGhpcyBhcHByb2FjaCBzdXJ2aXZlcyB0ZW1wbGF0ZSBleGVjdXRpb24gdW5saWtlIGRpcmVjdCBmdW5jdGlvbiByZWdpc3RyYXRpb25cbiAgICAgIHRyeSB7XG4gICAgICAgIC8vIENyZWF0ZSBvdXIgZ2xvYmFsIG5hbWVzcGFjZSB1bmRlciBhcHAuZ2xvYmFscyB0byBzdG9yZSBvdXIgZnVuY3Rpb25zXG4gICAgICAgIGlmICghKHRoaXMuYXBwIGFzIGFueSkuZ2xvYmFscykge1xuICAgICAgICAgICh0aGlzLmFwcCBhcyBhbnkpLmdsb2JhbHMgPSB7fTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoISh0aGlzLmFwcCBhcyBhbnkpLmdsb2JhbHMudHVja2Vyc1Rvb2xzKSB7XG4gICAgICAgICAgKHRoaXMuYXBwIGFzIGFueSkuZ2xvYmFscy50dWNrZXJzVG9vbHMgPSB7fTtcbiAgICAgICAgfVxuICAgICAgICBcbiAgICAgICAgLy8gUmVnaXN0ZXIgb3VyIGZ1bmN0aW9ucyBpbiB0aGUgZ2xvYmFsIG5hbWVzcGFjZVxuICAgICAgICAodGhpcy5hcHAgYXMgYW55KS5nbG9iYWxzLnR1Y2tlcnNUb29scy5uZXdfbW9kdWxlID0gYXN5bmMgKGFwcDogYW55LCB0cDogYW55LCB5ZWFyOiBhbnkpID0+IHtcbiAgICAgICAgICByZXR1cm4gdGhpcy5uZXdNb2R1bGVGdW5jdGlvbihhcHAsIHRwLCB5ZWFyKTtcbiAgICAgICAgfTtcbiAgICAgICAgXG4gICAgICAgICh0aGlzLmFwcCBhcyBhbnkpLmdsb2JhbHMudHVja2Vyc1Rvb2xzLm5ld19jaGFwdGVyID0gYXN5bmMgKHRwOiBhbnkpID0+IHtcbiAgICAgICAgICByZXR1cm4gdGhpcy5uZXdDaGFwdGVyRnVuY3Rpb24odHApO1xuICAgICAgICB9O1xuICAgICAgICBcbiAgICAgICAgLy8gUmVnaXN0ZXIgZGF0YXZpZXcgZnVuY3Rpb25zIGluIHRoZSBnbG9iYWwgbmFtZXNwYWNlXG4gICAgICAgICh0aGlzLmFwcCBhcyBhbnkpLmdsb2JhbHMudHVja2Vyc1Rvb2xzLnByb2Nlc3NDb3Vyc2VWb2NhYnVsYXJ5ID0gYXN5bmMgKGR2OiBhbnksIGNvdXJzZUlkOiBzdHJpbmcpID0+IHtcbiAgICAgICAgICByZXR1cm4gcHJvY2Vzc0NvdXJzZVZvY2FidWxhcnkoZHYsIGNvdXJzZUlkKTtcbiAgICAgICAgfTtcbiAgICAgICAgXG4gICAgICAgICh0aGlzLmFwcCBhcyBhbnkpLmdsb2JhbHMudHVja2Vyc1Rvb2xzLnByb2Nlc3NEdWVEYXRlcyA9IGFzeW5jIChkdjogYW55LCBzb3VyY2U6IHN0cmluZywgc3RhcnREYXRlOiBzdHJpbmcgfCBudWxsID0gbnVsbCwgZW5kRGF0ZTogc3RyaW5nIHwgbnVsbCA9IG51bGwpID0+IHtcbiAgICAgICAgICByZXR1cm4gcHJvY2Vzc0R1ZURhdGVzKGR2LCBzb3VyY2UsIHN0YXJ0RGF0ZSwgZW5kRGF0ZSk7XG4gICAgICAgIH07XG4gICAgICAgIFxuICAgICAgICAvLyBBbHNvIHJlZ2lzdGVyIGZ1bmN0aW9ucyBpbiB0cC51c2VyIG5hbWVzcGFjZSBmb3IgdGVtcGxhdGUgYWNjZXNzXG4gICAgICAgIC8vIFRoaXMgZW5zdXJlcyBjb21wYXRpYmlsaXR5IHdpdGggdGVtcGxhdGVzIHRoYXQgZXhwZWN0IHRwLnVzZXIuZnVuY3Rpb25fbmFtZVxuICAgICAgICBjb25zdCB0ZW1wbGF0ZXJQbHVnaW46IGFueSA9ICh0aGlzLmFwcCBhcyBhbnkpLnBsdWdpbnMuZ2V0UGx1Z2luKFwidGVtcGxhdGVyLW9ic2lkaWFuXCIpO1xuICAgICAgICBpZiAodGVtcGxhdGVyUGx1Z2luICYmIHRlbXBsYXRlclBsdWdpbi50ZW1wbGF0ZXIgJiYgdGVtcGxhdGVyUGx1Z2luLnRlbXBsYXRlci5mdW5jdGlvbnMpIHtcbiAgICAgICAgICAvLyBDcmVhdGUgdHAudXNlciBuYW1lc3BhY2UgaWYgaXQgZG9lc24ndCBleGlzdFxuICAgICAgICAgIGlmICghdGVtcGxhdGVyUGx1Z2luLnRlbXBsYXRlci5mdW5jdGlvbnMudXNlcikge1xuICAgICAgICAgICAgdGVtcGxhdGVyUGx1Z2luLnRlbXBsYXRlci5mdW5jdGlvbnMudXNlciA9IHt9O1xuICAgICAgICAgIH1cbiAgICAgICAgICBcbiAgICAgICAgICAvLyBSZWdpc3RlciBvdXIgZnVuY3Rpb25zIGluIHRoZSB0cC51c2VyIG5hbWVzcGFjZVxuICAgICAgICAgIHRlbXBsYXRlclBsdWdpbi50ZW1wbGF0ZXIuZnVuY3Rpb25zLnVzZXJbXCJuZXdfbW9kdWxlXCJdID0gYXN5bmMgKGFwcDogYW55LCB0cDogYW55LCB5ZWFyOiBhbnkpID0+IHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLm5ld01vZHVsZUZ1bmN0aW9uKGFwcCwgdHAsIHllYXIpO1xuICAgICAgICAgIH07XG4gICAgICAgICAgXG4gICAgICAgICAgdGVtcGxhdGVyUGx1Z2luLnRlbXBsYXRlci5mdW5jdGlvbnMudXNlcltcIm5ld19jaGFwdGVyXCJdID0gYXN5bmMgKHRwOiBhbnkpID0+IHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLm5ld0NoYXB0ZXJGdW5jdGlvbih0cCk7XG4gICAgICAgICAgfTtcbiAgICAgICAgICBcbiAgICAgICAgICAvLyBSZWdpc3RlciBkYXRhdmlldyBmdW5jdGlvbnMgaW4gdGhlIHRwLnVzZXIgbmFtZXNwYWNlXG4gICAgICAgICAgdGVtcGxhdGVyUGx1Z2luLnRlbXBsYXRlci5mdW5jdGlvbnMudXNlcltcInByb2Nlc3NDb3Vyc2VWb2NhYnVsYXJ5XCJdID0gYXN5bmMgKGR2OiBhbnksIGNvdXJzZUlkOiBzdHJpbmcpID0+IHtcbiAgICAgICAgICAgIHJldHVybiBwcm9jZXNzQ291cnNlVm9jYWJ1bGFyeShkdiwgY291cnNlSWQpO1xuICAgICAgICAgIH07XG4gICAgICAgICAgXG4gICAgICAgICAgdGVtcGxhdGVyUGx1Z2luLnRlbXBsYXRlci5mdW5jdGlvbnMudXNlcltcInByb2Nlc3NEdWVEYXRlc1wiXSA9IGFzeW5jIChkdjogYW55LCBzb3VyY2U6IHN0cmluZywgc3RhcnREYXRlOiBzdHJpbmcgfCBudWxsID0gbnVsbCwgZW5kRGF0ZTogc3RyaW5nIHwgbnVsbCA9IG51bGwpID0+IHtcbiAgICAgICAgICAgIHJldHVybiBwcm9jZXNzRHVlRGF0ZXMoZHYsIHNvdXJjZSwgc3RhcnREYXRlLCBlbmREYXRlKTtcbiAgICAgICAgICB9O1xuICAgICAgICAgIFxuICAgICAgICAgIGNvbnNvbGUubG9nKFwiVHVja2VycyBUb29scyB0ZW1wbGF0ZXIgZnVuY3Rpb25zIHJlZ2lzdGVyZWQgc3VjY2Vzc2Z1bGx5IGluIGJvdGggZ2xvYmFsIGFuZCB0cC51c2VyIG5hbWVzcGFjZXNcIik7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgY29uc29sZS5sb2coXCJUZW1wbGF0ZXIgcGx1Z2luIG5vdCBmb3VuZCBvciBub3QgZnVsbHkgbG9hZGVkLCBmdW5jdGlvbnMgcmVnaXN0ZXJlZCBpbiBnbG9iYWwgbmFtZXNwYWNlIG9ubHlcIik7XG4gICAgICAgIH1cbiAgICAgICAgXG4gICAgICAgIGNvbnNvbGUubG9nKFwiVHVja2VycyBUb29scyBnbG9iYWwgZnVuY3Rpb25zIHJlZ2lzdGVyZWQgc3VjY2Vzc2Z1bGx5XCIpO1xuICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgcmVnaXN0ZXJpbmcgVHVja2VycyBUb29scyBnbG9iYWwgZnVuY3Rpb25zOlwiLCBlKTtcbiAgICAgIH1cbiAgfVxuXG4gIGFzeW5jIG5ld01vZHVsZUZ1bmN0aW9uKGFwcDogYW55LCB0cDogYW55LCB5ZWFyOiBzdHJpbmcpIHtcbiAgICAvLyBQcm9tcHQgdXNlciBmb3IgbW9kdWxlIGRldGFpbHMgaW4gdGhlIGNvcnJlY3Qgb3JkZXJcbiAgICBsZXQgbW9kdWxlTnVtYmVyOiBzdHJpbmcgfCBudWxsID0gXCJcIjtcbiAgICBsZXQgd2Vla051bWJlcjogc3RyaW5nIHwgbnVsbCA9IFwiXCI7XG4gICAgbGV0IGNvdXJzZSA9IFwiXCI7XG4gICAgbGV0IGNvdXJzZUlkID0gXCJcIjtcbiAgICBsZXQgZGlzY2lwbGluZSA9IFwiR0VOXCI7XG4gICAgbGV0IGRheU9mV2VlayA9IFwiXCI7XG4gICAgbGV0IHNlYXNvbiA9IFwiXCI7XG5cbiAgICB0cnkge1xuICAgICAgLy8gQXR0ZW1wdCBwcm9tcHRzIHdpdGggZmFsbGJhY2tcbiAgICAgIGlmICh0cCAmJiB0cC5zeXN0ZW0gJiYgdHAuc3lzdGVtLnByb21wdCkge1xuICAgICAgICAvLyBGaXJzdCwgYXNrIGZvciB0aGUgY291cnNlIChmaWx0ZXJlZCBieSBjdXJyZW50IHNlbWVzdGVyKVxuICAgICAgICAvLyBHZXQgY3VycmVudCBkYXRlIGZvciBmaWx0ZXJpbmdcbiAgICAgICAgY29uc3QgY3VycmVudERhdGUgPSBuZXcgRGF0ZSgpO1xuICAgICAgICBjb25zdCBjdXJyZW50WWVhciA9IGN1cnJlbnREYXRlLmdldEZ1bGxZZWFyKCkudG9TdHJpbmcoKTtcbiAgICAgICAgY29uc3QgY3VycmVudE1vbnRoID0gY3VycmVudERhdGUuZ2V0TW9udGgoKTsgLy8gMC0xMVxuICAgICAgICBsZXQgY3VycmVudFNlbWVzdGVyID0gXCJGYWxsXCI7XG4gICAgICAgIFxuICAgICAgICAvLyBEZXRlcm1pbmUgY3VycmVudCBzZW1lc3RlciBiYXNlZCBvbiBtb250aFxuICAgICAgICBpZiAoY3VycmVudE1vbnRoID49IDAgJiYgY3VycmVudE1vbnRoIDw9IDQpIHtcbiAgICAgICAgICBjdXJyZW50U2VtZXN0ZXIgPSBcIlNwcmluZ1wiO1xuICAgICAgICB9IGVsc2UgaWYgKGN1cnJlbnRNb250aCA+PSA1ICYmIGN1cnJlbnRNb250aCA8PSA3KSB7XG4gICAgICAgICAgY3VycmVudFNlbWVzdGVyID0gXCJTdW1tZXJcIjtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBjdXJyZW50U2VtZXN0ZXIgPSBcIkZhbGxcIjtcbiAgICAgICAgfVxuICAgICAgICBcbiAgICAgICAgY29uc29sZS5sb2coYEZpbHRlcmluZyBjb3Vyc2VzIGZvciAke2N1cnJlbnRTZW1lc3Rlcn0gJHtjdXJyZW50WWVhcn1gKTtcbiAgICAgICAgXG4gICAgICAgIC8vIExvb2sgZm9yIGNvdXJzZSBmaWxlcywgcHJpb3JpdGl6aW5nIGN1cnJlbnQgc2VtZXN0ZXJcbiAgICAgICAgY29uc3QgY291cnNlRmlsZXMgPSBhcHAudmF1bHQuZ2V0TWFya2Rvd25GaWxlcygpLmZpbHRlcigoZjogYW55KSA9PiB7XG4gICAgICAgICAgY29uc3QgY2FjaGUgPSBhcHAubWV0YWRhdGFDYWNoZS5nZXRGaWxlQ2FjaGUoZik7XG4gICAgICAgICAgaWYgKCFjYWNoZSkgcmV0dXJuIGZhbHNlO1xuICAgICAgICAgIFxuICAgICAgICAgIC8vIENoZWNrIGlmIGl0J3MgYSBjb3Vyc2UgZmlsZVxuICAgICAgICAgIGNvbnN0IGlzQ291cnNlRmlsZSA9IGNhY2hlICYmIChcbiAgICAgICAgICAgIChjYWNoZS50YWdzICYmIGNhY2hlLnRhZ3Muc29tZSgodGFnOiBhbnkpID0+IHRhZy50YWcgPT09IFwiI2NvdXJzZV9ob21lXCIpKSB8fFxuICAgICAgICAgICAgKGNhY2hlLmZyb250bWF0dGVyICYmIGNhY2hlLmZyb250bWF0dGVyLmNvbnRlbnRUeXBlID09PSBcIkNvdXJzZVwiKSB8fFxuICAgICAgICAgICAgKGNhY2hlLmZyb250bWF0dGVyICYmIGNhY2hlLmZyb250bWF0dGVyLnRhZ3MgJiYgXG4gICAgICAgICAgICAgKEFycmF5LmlzQXJyYXkoY2FjaGUuZnJvbnRtYXR0ZXIudGFncykgXG4gICAgICAgICAgICAgICA/IGNhY2hlLmZyb250bWF0dGVyLnRhZ3MuaW5jbHVkZXMoXCJjb3Vyc2VfaG9tZVwiKVxuICAgICAgICAgICAgICAgOiBjYWNoZS5mcm9udG1hdHRlci50YWdzID09PSBcImNvdXJzZV9ob21lXCIpKVxuICAgICAgICAgICk7XG4gICAgICAgICAgXG4gICAgICAgICAgcmV0dXJuIGlzQ291cnNlRmlsZTtcbiAgICAgICAgfSk7XG4gICAgICAgIFxuICAgICAgICBjb25zb2xlLmxvZyhgRm91bmQgJHtjb3Vyc2VGaWxlcy5sZW5ndGh9IHRvdGFsIGNvdXJzZSBmaWxlc2ApO1xuICAgICAgICBcbiAgICAgICAgLy8gRmlsdGVyIGJ5IGN1cnJlbnQgc2VtZXN0ZXIgaWYgcG9zc2libGVcbiAgICAgICAgY29uc3QgY3VycmVudFNlbWVzdGVyRmlsZXMgPSBjb3Vyc2VGaWxlcy5maWx0ZXIoKGY6IGFueSkgPT4ge1xuICAgICAgICAgIGNvbnN0IGNhY2hlID0gYXBwLm1ldGFkYXRhQ2FjaGUuZ2V0RmlsZUNhY2hlKGYpO1xuICAgICAgICAgIGlmICghY2FjaGUgfHwgIWNhY2hlLmZyb250bWF0dGVyKSByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgXG4gICAgICAgICAgY29uc3QgY291cnNlWWVhciA9IGNhY2hlLmZyb250bWF0dGVyLmNvdXJzZV95ZWFyIHx8IGNhY2hlLmZyb250bWF0dGVyLmNvdXJzZVllYXIgfHwgXCJcIjtcbiAgICAgICAgICBjb25zdCBjb3Vyc2VTZWFzb24gPSBjYWNoZS5mcm9udG1hdHRlci5jb3Vyc2Vfc2Vhc29uIHx8IGNhY2hlLmZyb250bWF0dGVyLmNvdXJzZVNlYXNvbiB8fCBcIlwiO1xuICAgICAgICAgIFxuICAgICAgICAgIHJldHVybiAoY291cnNlWWVhciA9PT0gY3VycmVudFllYXIgJiYgY291cnNlU2Vhc29uID09PSBjdXJyZW50U2VtZXN0ZXIpO1xuICAgICAgICB9KTtcbiAgICAgICAgXG4gICAgICAgIGNvbnNvbGUubG9nKGBGb3VuZCAke2N1cnJlbnRTZW1lc3RlckZpbGVzLmxlbmd0aH0gY3VycmVudCBzZW1lc3RlciBmaWxlc2ApO1xuICAgICAgICBcbiAgICAgICAgY29uc29sZS5sb2coYEZvdW5kICR7Y291cnNlRmlsZXMubGVuZ3RofSBjb3Vyc2UgZmlsZXMgZm9yICR7Y3VycmVudFNlbWVzdGVyfSAke2N1cnJlbnRZZWFyfWApO1xuXG4gICAgICAgIC8vIFVzZSBjdXJyZW50IHNlbWVzdGVyIGZpbGVzIGlmIGF2YWlsYWJsZSwgb3RoZXJ3aXNlIGFsbCBjb3Vyc2UgZmlsZXNcbiAgICAgICAgY29uc3QgZmlsZXNUb1Nob3cgPSBjdXJyZW50U2VtZXN0ZXJGaWxlcy5sZW5ndGggPiAwID8gY3VycmVudFNlbWVzdGVyRmlsZXMgOiBjb3Vyc2VGaWxlcztcbiAgICAgICAgY29uc3QgcHJvbXB0TWVzc2FnZSA9IGN1cnJlbnRTZW1lc3RlckZpbGVzLmxlbmd0aCA+IDAgXG4gICAgICAgICAgPyBgU2VsZWN0IENvdXJzZSAoJHtjdXJyZW50U2VtZXN0ZXJ9ICR7Y3VycmVudFllYXJ9KWAgXG4gICAgICAgICAgOiBgU2VsZWN0IENvdXJzZSAoQWxsIFNlbWVzdGVycyAtICR7Y291cnNlRmlsZXMubGVuZ3RofSBjb3Vyc2VzKWA7XG4gICAgICAgIFxuICAgICAgICBjb25zb2xlLmxvZyhgU2hvd2luZyAke2ZpbGVzVG9TaG93Lmxlbmd0aH0gY291cnNlcyB3aXRoIG1lc3NhZ2U6ICR7cHJvbXB0TWVzc2FnZX1gKTtcbiAgICAgICAgXG4gICAgICAgIGlmIChmaWxlc1RvU2hvdy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgY291cnNlID0gYXdhaXQgdHAuc3lzdGVtLnN1Z2dlc3RlcihcbiAgICAgICAgICAgIGZpbGVzVG9TaG93Lm1hcCgoZjogYW55KSA9PiBmLmJhc2VuYW1lKSwgLy8gRGlzcGxheSBsYWJlbHNcbiAgICAgICAgICAgIGZpbGVzVG9TaG93LCAvLyBBY3R1YWwgdmFsdWVzXG4gICAgICAgICAgICBwcm9tcHRNZXNzYWdlXG4gICAgICAgICAgKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAvLyBObyBjb3Vyc2VzIGZvdW5kIGF0IGFsbCwgZmFsbCBiYWNrIHRvIHByb21wdFxuICAgICAgICAgIGNvdXJzZSA9IGF3YWl0IHRwLnN5c3RlbS5wcm9tcHQoXCJDb3Vyc2UgTmFtZVwiLCBcIk5ldyBDb3Vyc2VcIik7XG4gICAgICAgIH1cblxuICAgICAgICAvLyBOb3cgYXNrIGZvciBtb2R1bGUgZGV0YWlsc1xuICAgICAgICBjb25zdCB0ZW1wTW9kdWxlTnVtYmVyID0gYXdhaXQgdHAuc3lzdGVtLnByb21wdChcIk1vZHVsZSBOdW1iZXIgKG9wdGlvbmFsKVwiLCBcIlwiKTtcbiAgICAgICAgbW9kdWxlTnVtYmVyID0gdGVtcE1vZHVsZU51bWJlciA/IHRlbXBNb2R1bGVOdW1iZXIgOiBudWxsO1xuICAgICAgICBcbiAgICAgICAgY29uc3QgdGVtcFdlZWtOdW1iZXIgPSBhd2FpdCB0cC5zeXN0ZW0ucHJvbXB0KFwiV2VlayBOdW1iZXIgKG9wdGlvbmFsKVwiLCBcIlwiKTtcbiAgICAgICAgd2Vla051bWJlciA9IHRlbXBXZWVrTnVtYmVyID8gdGVtcFdlZWtOdW1iZXIgOiBudWxsO1xuICAgICAgICBcbiAgICAgICAgZGF5T2ZXZWVrID0gYXdhaXQgdHAuc3lzdGVtLnN1Z2dlc3RlcihcbiAgICAgICAgICBbXCJNb25kYXlcIiwgXCJUdWVzZGF5XCIsIFwiV2VkbmVzZGF5XCIsIFwiVGh1cnNkYXlcIiwgXCJGcmlkYXlcIiwgXCJTYXR1cmRheVwiLCBcIlN1bmRheVwiXSwgLy8gRGlzcGxheSBsYWJlbHNcbiAgICAgICAgICBbXCJNb25kYXlcIiwgXCJUdWVzZGF5XCIsIFwiV2VkbmVzZGF5XCIsIFwiVGh1cnNkYXlcIiwgXCJGcmlkYXlcIiwgXCJTYXR1cmRheVwiLCBcIlN1bmRheVwiXSwgLy8gQWN0dWFsIHZhbHVlc1xuICAgICAgICAgIFwiRGF5IG9mIFdlZWtcIlxuICAgICAgICApO1xuICAgICAgICBcbiAgICAgICAgLy8gU2V0IHNlYXNvbiB0byBjdXJyZW50IHNlbWVzdGVyXG4gICAgICAgIHNlYXNvbiA9IGN1cnJlbnRTZW1lc3RlcjtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIC8vIEZhbGxiYWNrIHZhbHVlc1xuICAgICAgICBtb2R1bGVOdW1iZXIgPSBudWxsO1xuICAgICAgICB3ZWVrTnVtYmVyID0gbnVsbDtcbiAgICAgICAgY291cnNlID0gXCJOZXcgQ291cnNlXCI7XG4gICAgICAgIGRheU9mV2VlayA9IFwiTW9uZGF5XCI7XG4gICAgICAgIHNlYXNvbiA9IFwiRmFsbFwiOyAvLyBEZWZhdWx0IGZhbGxiYWNrXG4gICAgICB9XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGluIG5ld19tb2R1bGUgcHJvbXB0czpcIiwgZSk7XG4gICAgICAvLyBEZWZhdWx0IHZhbHVlcyBvbiBlcnJvclxuICAgICAgbW9kdWxlTnVtYmVyID0gbnVsbDtcbiAgICAgIHdlZWtOdW1iZXIgPSBudWxsO1xuICAgICAgY291cnNlID0gXCJOZXcgQ291cnNlXCI7XG4gICAgICBkYXlPZldlZWsgPSBcIk1vbmRheVwiO1xuICAgICAgc2Vhc29uID0gXCJGYWxsXCI7XG4gICAgfVxuXG4gICAgLy8gQ2FsY3VsYXRlIGRlcml2ZWQgdmFsdWVzXG4gICAgLy8gSGFuZGxlIGJvdGggZmlsZSBvYmplY3QgKGZyb20gc3VnZ2VzdGVyKSBhbmQgc3RyaW5nIChmcm9tIHByb21wdCBmYWxsYmFjaylcbiAgICBpZiAodHlwZW9mIGNvdXJzZSA9PT0gJ29iamVjdCcgJiYgY291cnNlICE9PSBudWxsICYmIChjb3Vyc2UgYXMgYW55KS5iYXNlbmFtZSkge1xuICAgICAgLy8gY291cnNlIGlzIGEgZmlsZSBvYmplY3QgZnJvbSBzdWdnZXN0ZXJcbiAgICAgIGNvdXJzZUlkID0gKGNvdXJzZSBhcyBhbnkpLmJhc2VuYW1lLnNwbGl0KFwiIC0gXCIpWzBdIHx8IChjb3Vyc2UgYXMgYW55KS5iYXNlbmFtZTtcbiAgICAgIGRpc2NpcGxpbmUgPSAoKGNvdXJzZSBhcyBhbnkpLmJhc2VuYW1lLnNwbGl0KFwiIC0gXCIpWzBdPy5zdWJzdHJpbmcoMCwgMykgfHwgXCJHRU5cIik7XG4gICAgfSBlbHNlIGlmICh0eXBlb2YgY291cnNlID09PSAnc3RyaW5nJykge1xuICAgICAgLy8gY291cnNlIGlzIGEgc3RyaW5nIGZyb20gcHJvbXB0IGZhbGxiYWNrXG4gICAgICBjb3Vyc2VJZCA9IGNvdXJzZS5zcGxpdChcIiAtIFwiKVswXSB8fCBjb3Vyc2U7XG4gICAgICBkaXNjaXBsaW5lID0gKGNvdXJzZS5zcGxpdChcIiAtIFwiKVswXT8uc3Vic3RyaW5nKDAsIDMpIHx8IFwiR0VOXCIpO1xuICAgIH0gZWxzZSB7XG4gICAgICAvLyBGYWxsYmFja1xuICAgICAgY291cnNlSWQgPSBcIlwiO1xuICAgICAgZGlzY2lwbGluZSA9IFwiR0VOXCI7XG4gICAgfVxuXG4gICAgcmV0dXJuIHtcbiAgICAgIHNlYXNvbixcbiAgICAgIG1vZHVsZU51bWJlcixcbiAgICAgIHdlZWtOdW1iZXIsXG4gICAgICBjb3Vyc2UsXG4gICAgICBjb3Vyc2VJZCxcbiAgICAgIGRpc2NpcGxpbmUsXG4gICAgICBkYXlPZldlZWtcbiAgICB9O1xuICB9XG5cbiAgYXN5bmMgbmV3Q2hhcHRlckZ1bmN0aW9uKHRwOiBhbnkpIHtcbiAgICBsZXQgY2hhcHRlck51bWJlciA9IFwiXCI7XG4gICAgbGV0IGNvdXJzZSA9IFwiXCI7XG4gICAgbGV0IGNvdXJzZUlkID0gXCJcIjtcbiAgICBsZXQgZGlzY2lwbGluZSA9IFwiR0VOXCI7XG4gICAgbGV0IHRleHQgPSBcIlwiO1xuXG4gICAgdHJ5IHtcbiAgICAgIGlmICh0cCAmJiB0cC5zeXN0ZW0gJiYgdHAuc3lzdGVtLnByb21wdCkge1xuICAgICAgICBjaGFwdGVyTnVtYmVyID0gYXdhaXQgdHAuc3lzdGVtLnByb21wdChcIkNoYXB0ZXIgTnVtYmVyXCIsIFwiXCIpIHx8IFwiXCI7XG4gICAgICAgIC8vIExvb2sgZm9yIGZpbGVzIHdpdGggY291cnNlX2hvbWUgdGFnIG9yIGNvbnRlbnRUeXBlOiBDb3Vyc2UgaW5zdGVhZCBvZiBoYXJkY29kZWQgcGF0aFxuICAgICAgICBjb25zdCBjb3Vyc2VGaWxlcyA9IHRwLmFwcC52YXVsdC5nZXRNYXJrZG93bkZpbGVzKCkuZmlsdGVyKChmOiBhbnkpID0+IHtcbiAgICAgICAgICBjb25zdCBjYWNoZSA9IHRwLmFwcC5tZXRhZGF0YUNhY2hlLmdldEZpbGVDYWNoZShmKTtcbiAgICAgICAgICByZXR1cm4gY2FjaGUgJiYgKFxuICAgICAgICAgICAgKGNhY2hlLnRhZ3MgJiYgY2FjaGUudGFncy5zb21lKCh0YWc6IGFueSkgPT4gdGFnLnRhZyA9PT0gXCIjY291cnNlX2hvbWVcIikpIHx8XG4gICAgICAgICAgICAoY2FjaGUuZnJvbnRtYXR0ZXIgJiYgY2FjaGUuZnJvbnRtYXR0ZXIuY29udGVudFR5cGUgPT09IFwiQ291cnNlXCIpIHx8XG4gICAgICAgICAgICAoY2FjaGUuZnJvbnRtYXR0ZXIgJiYgY2FjaGUuZnJvbnRtYXR0ZXIudGFncyAmJiBcbiAgICAgICAgICAgICAoQXJyYXkuaXNBcnJheShjYWNoZS5mcm9udG1hdHRlci50YWdzKSBcbiAgICAgICAgICAgICAgID8gY2FjaGUuZnJvbnRtYXR0ZXIudGFncy5pbmNsdWRlcyhcImNvdXJzZV9ob21lXCIpXG4gICAgICAgICAgICAgICA6IGNhY2hlLmZyb250bWF0dGVyLnRhZ3MgPT09IFwiY291cnNlX2hvbWVcIikpXG4gICAgICAgICAgKTtcbiAgICAgICAgfSk7XG4gICAgICAgIFxuICAgICAgICBjb3Vyc2UgPSBhd2FpdCB0cC5zeXN0ZW0uc3VnZ2VzdGVyKFxuICAgICAgICAgICgpID0+IGNvdXJzZUZpbGVzLm1hcCgoZjogYW55KSA9PiBmLmJhc2VuYW1lKSxcbiAgICAgICAgICBjb3Vyc2VGaWxlc1xuICAgICAgICApO1xuICAgICAgICBjb25zdCB0ZXh0T3B0aW9ucyA9IHRwLmFwcC52YXVsdC5nZXRGaWxlcygpLmZpbHRlcigoZjogYW55KSA9PiBmLmV4dGVuc2lvbiA9PT0gXCJwZGZcIikubWFwKChmOiBhbnkpID0+IGYuYmFzZW5hbWUpO1xuICAgICAgICB0ZXh0ID0gYXdhaXQgdHAuc3lzdGVtLnN1Z2dlc3Rlcih0ZXh0T3B0aW9ucywgdGV4dE9wdGlvbnMsIFwiVGV4dGJvb2tcIik7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICAvLyBGYWxsYmFjayB2YWx1ZXNcbiAgICAgICAgY2hhcHRlck51bWJlciA9IFwiXCI7XG4gICAgICAgIGNvdXJzZSA9IFwiTmV3IENvdXJzZVwiO1xuICAgICAgICB0ZXh0ID0gXCJOZXcgVGV4dGJvb2tcIjtcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgaW4gbmV3X2NoYXB0ZXIgcHJvbXB0czpcIiwgZSk7XG4gICAgICAvLyBEZWZhdWx0IHZhbHVlcyBvbiBlcnJvclxuICAgICAgY2hhcHRlck51bWJlciA9IFwiXCI7XG4gICAgICBjb3Vyc2UgPSBcIk5ldyBDb3Vyc2VcIjtcbiAgICAgIHRleHQgPSBcIk5ldyBUZXh0Ym9va1wiO1xuICAgIH1cblxuICAgIC8vIENhbGN1bGF0ZSBkZXJpdmVkIHZhbHVlc1xuICAgIGNvdXJzZUlkID0gY291cnNlID8gY291cnNlLnNwbGl0KFwiIC0gXCIpWzBdIHx8IGNvdXJzZSA6IFwiXCI7XG4gICAgZGlzY2lwbGluZSA9IGNvdXJzZSA/IChjb3Vyc2Uuc3BsaXQoXCIgLSBcIilbMF0/LnN1YnN0cmluZygwLCAzKSB8fCBcIkdFTlwiKSA6IFwiR0VOXCI7XG5cbiAgICByZXR1cm4ge1xuICAgICAgY2hhcHRlck51bWJlcixcbiAgICAgIGNvdXJzZSxcbiAgICAgIGNvdXJzZUlkLFxuICAgICAgZGlzY2lwbGluZSxcbiAgICAgIHRleHRcbiAgICB9O1xuICB9XG5cbiAgYXN5bmMgbG9hZFNldHRpbmdzKCkge1xuICAgIHRoaXMuc2V0dGluZ3MgPSBPYmplY3QuYXNzaWduKHt9LCBERUZBVUxUX1NFVFRJTkdTLCBhd2FpdCB0aGlzLmxvYWREYXRhKCkpXG4gIH1cblxuICBhc3luYyBzYXZlU2V0dGluZ3MoKSB7XG4gICAgYXdhaXQgdGhpcy5zYXZlRGF0YSh0aGlzLnNldHRpbmdzKVxuICB9XG59XG4iLCAiaW1wb3J0IHsgQXBwLCBQbHVnaW5TZXR0aW5nVGFiLCBTZXR0aW5nIH0gZnJvbSAnb2JzaWRpYW4nO1xuaW1wb3J0IFR1Y2tlcnNUb29sc1BsdWdpbiBmcm9tICcuL21haW4nO1xuaW1wb3J0IHsgdmFsaWRhdGVEYXRlIH0gZnJvbSAnLi91dGlscyc7XG5cbmV4cG9ydCBpbnRlcmZhY2UgVHVja2Vyc1Rvb2xzU2V0dGluZ3Mge1xuICBiYXNlRGlyZWN0b3J5OiBzdHJpbmc7XG4gIHNlbWVzdGVyU3RhcnREYXRlOiBzdHJpbmc7XG4gIHNlbWVzdGVyRW5kRGF0ZTogc3RyaW5nO1xuICBzY2hvb2xOYW1lOiBzdHJpbmc7XG4gIHNjaG9vbEFiYnJldmlhdGlvbjogc3RyaW5nO1xuICB0ZW1wbGF0ZUZvbGRlcjogc3RyaW5nO1xuICB1c2VFbmhhbmNlZE1ldGFkYXRhOiBib29sZWFuO1xuICBkYXRhdmlld0pzUGF0aDogc3RyaW5nO1xufVxuXG5leHBvcnQgY29uc3QgREVGQVVMVF9TRVRUSU5HUzogVHVja2Vyc1Rvb2xzU2V0dGluZ3MgPSB7XG4gIGJhc2VEaXJlY3Rvcnk6ICcvJyxcbiAgc2VtZXN0ZXJTdGFydERhdGU6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zcGxpdCgnVCcpWzBdLFxuICBzZW1lc3RlckVuZERhdGU6IG5ldyBEYXRlKG5ldyBEYXRlKCkuc2V0TW9udGgobmV3IERhdGUoKS5nZXRNb250aCgpICsgNCkpLnRvSVNPU3RyaW5nKCkuc3BsaXQoJ1QnKVswXSxcbiAgc2Nob29sTmFtZTogJ1VuaXZlcnNpdHknLFxuICBzY2hvb2xBYmJyZXZpYXRpb246ICdVJyxcbiAgdGVtcGxhdGVGb2xkZXI6ICdUdWNrZXJzIFRvb2xzJyxcbiAgdXNlRW5oYW5jZWRNZXRhZGF0YTogZmFsc2UsXG4gIGRhdGF2aWV3SnNQYXRoOiAnL1N1cHBvcnRpbmcvZGF0YXZpZXctZnVuY3Rpb25zJ1xufVxuXG5leHBvcnQgY2xhc3MgVHVja2Vyc1Rvb2xzU2V0dGluZ1RhYiBleHRlbmRzIFBsdWdpblNldHRpbmdUYWIge1xuICBwbHVnaW46IFR1Y2tlcnNUb29sc1BsdWdpbjtcblxuICBjb25zdHJ1Y3RvcihhcHA6IEFwcCwgcGx1Z2luOiBUdWNrZXJzVG9vbHNQbHVnaW4pIHtcbiAgICBzdXBlcihhcHAsIHBsdWdpbik7XG4gICAgdGhpcy5wbHVnaW4gPSBwbHVnaW47XG4gIH1cblxuICBkaXNwbGF5KCk6IHZvaWQge1xuICAgIGNvbnN0IHsgY29udGFpbmVyRWwgfSA9IHRoaXM7XG5cbiAgICBjb250YWluZXJFbC5lbXB0eSgpO1xuXG4gICAgY29udGFpbmVyRWwuY3JlYXRlRWwoJ2gyJywgeyB0ZXh0OiAnVHVja2VycyBUb29scyBTZXR0aW5ncycgfSk7XG5cbiAgICBuZXcgU2V0dGluZyhjb250YWluZXJFbClcbiAgICAgIC5zZXROYW1lKCdCYXNlIERpcmVjdG9yeScpXG4gICAgICAuc2V0RGVzYygnUm9vdCBkaXJlY3RvcnkgZm9yIGNvdXJzZSBjb250ZW50IG9yZ2FuaXphdGlvbicpXG4gICAgICAuYWRkVGV4dCh0ZXh0ID0+IHRleHRcbiAgICAgICAgLnNldFBsYWNlaG9sZGVyKCcvJylcbiAgICAgICAgLnNldFZhbHVlKHRoaXMucGx1Z2luLnNldHRpbmdzLmJhc2VEaXJlY3RvcnkpXG4gICAgICAgIC5vbkNoYW5nZShhc3luYyAodmFsdWUpID0+IHtcbiAgICAgICAgICB0aGlzLnBsdWdpbi5zZXR0aW5ncy5iYXNlRGlyZWN0b3J5ID0gdmFsdWU7XG4gICAgICAgICAgYXdhaXQgdGhpcy5wbHVnaW4uc2F2ZVNldHRpbmdzKCk7XG4gICAgICAgIH0pKTtcblxuICAgIGNvbnN0IHN0YXJ0RGF0ZVNldHRpbmcgPSBuZXcgU2V0dGluZyhjb250YWluZXJFbClcbiAgICAgIC5zZXROYW1lKCdTZW1lc3RlciBTdGFydCBEYXRlJylcbiAgICAgIC5zZXREZXNjKCdTdGFydCBkYXRlIGZvciB0aGUgY3VycmVudCBzZW1lc3RlcicpXG4gICAgICAuYWRkVGV4dCh0ZXh0ID0+IHRleHRcbiAgICAgICAgLnNldFBsYWNlaG9sZGVyKCdZWVlZLU1NLUREJylcbiAgICAgICAgLnNldFZhbHVlKHRoaXMucGx1Z2luLnNldHRpbmdzLnNlbWVzdGVyU3RhcnREYXRlKVxuICAgICAgICAub25DaGFuZ2UoYXN5bmMgKHZhbHVlKSA9PiB7XG4gICAgICAgICAgaWYgKHZhbHVlICYmICF2YWxpZGF0ZURhdGUodmFsdWUpKSB7XG4gICAgICAgICAgICBzdGFydERhdGVTZXR0aW5nLnNldERlc2MoJ1N0YXJ0IGRhdGUgZm9yIHRoZSBjdXJyZW50IHNlbWVzdGVyIChJbnZhbGlkIGRhdGUgZm9ybWF0KScpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBzdGFydERhdGVTZXR0aW5nLnNldERlc2MoJ1N0YXJ0IGRhdGUgZm9yIHRoZSBjdXJyZW50IHNlbWVzdGVyJyk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHRoaXMucGx1Z2luLnNldHRpbmdzLnNlbWVzdGVyU3RhcnREYXRlID0gdmFsdWU7XG4gICAgICAgICAgYXdhaXQgdGhpcy5wbHVnaW4uc2F2ZVNldHRpbmdzKCk7XG4gICAgICAgIH0pKTtcblxuICAgIGNvbnN0IGVuZERhdGVTZXR0aW5nID0gbmV3IFNldHRpbmcoY29udGFpbmVyRWwpXG4gICAgICAuc2V0TmFtZSgnU2VtZXN0ZXIgRW5kIERhdGUnKVxuICAgICAgLnNldERlc2MoJ0VuZCBkYXRlIGZvciB0aGUgY3VycmVudCBzZW1lc3RlcicpXG4gICAgICAuYWRkVGV4dCh0ZXh0ID0+IHRleHRcbiAgICAgICAgLnNldFBsYWNlaG9sZGVyKCdZWVlZLU1NLUREJylcbiAgICAgICAgLnNldFZhbHVlKHRoaXMucGx1Z2luLnNldHRpbmdzLnNlbWVzdGVyRW5kRGF0ZSlcbiAgICAgICAgLm9uQ2hhbmdlKGFzeW5jICh2YWx1ZSkgPT4ge1xuICAgICAgICAgIGlmICh2YWx1ZSAmJiAhdmFsaWRhdGVEYXRlKHZhbHVlKSkge1xuICAgICAgICAgICAgZW5kRGF0ZVNldHRpbmcuc2V0RGVzYygnRW5kIGRhdGUgZm9yIHRoZSBjdXJyZW50IHNlbWVzdGVyIChJbnZhbGlkIGRhdGUgZm9ybWF0KScpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBlbmREYXRlU2V0dGluZy5zZXREZXNjKCdFbmQgZGF0ZSBmb3IgdGhlIGN1cnJlbnQgc2VtZXN0ZXInKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgdGhpcy5wbHVnaW4uc2V0dGluZ3Muc2VtZXN0ZXJFbmREYXRlID0gdmFsdWU7XG4gICAgICAgICAgYXdhaXQgdGhpcy5wbHVnaW4uc2F2ZVNldHRpbmdzKCk7XG4gICAgICAgIH0pKTtcblxuICAgIG5ldyBTZXR0aW5nKGNvbnRhaW5lckVsKVxuICAgICAgLnNldE5hbWUoJ1NjaG9vbCBOYW1lJylcbiAgICAgIC5zZXREZXNjKCdOYW1lIG9mIHlvdXIgaW5zdGl0dXRpb24nKVxuICAgICAgLmFkZFRleHQodGV4dCA9PiB0ZXh0XG4gICAgICAgIC5zZXRQbGFjZWhvbGRlcignVW5pdmVyc2l0eScpXG4gICAgICAgIC5zZXRWYWx1ZSh0aGlzLnBsdWdpbi5zZXR0aW5ncy5zY2hvb2xOYW1lKVxuICAgICAgICAub25DaGFuZ2UoYXN5bmMgKHZhbHVlKSA9PiB7XG4gICAgICAgICAgdGhpcy5wbHVnaW4uc2V0dGluZ3Muc2Nob29sTmFtZSA9IHZhbHVlO1xuICAgICAgICAgIGF3YWl0IHRoaXMucGx1Z2luLnNhdmVTZXR0aW5ncygpO1xuICAgICAgICB9KSk7XG5cbiAgICBuZXcgU2V0dGluZyhjb250YWluZXJFbClcbiAgICAgIC5zZXROYW1lKCdTY2hvb2wgQWJicmV2aWF0aW9uJylcbiAgICAgIC5zZXREZXNjKCdBYmJyZXZpYXRpb24gZm9yIHlvdXIgaW5zdGl0dXRpb24nKVxuICAgICAgLmFkZFRleHQodGV4dCA9PiB0ZXh0XG4gICAgICAgIC5zZXRQbGFjZWhvbGRlcignVScpXG4gICAgICAgIC5zZXRWYWx1ZSh0aGlzLnBsdWdpbi5zZXR0aW5ncy5zY2hvb2xBYmJyZXZpYXRpb24pXG4gICAgICAgIC5vbkNoYW5nZShhc3luYyAodmFsdWUpID0+IHtcbiAgICAgICAgICB0aGlzLnBsdWdpbi5zZXR0aW5ncy5zY2hvb2xBYmJyZXZpYXRpb24gPSB2YWx1ZTtcbiAgICAgICAgICBhd2FpdCB0aGlzLnBsdWdpbi5zYXZlU2V0dGluZ3MoKTtcbiAgICAgICAgfSkpO1xuXG4gICAgbmV3IFNldHRpbmcoY29udGFpbmVyRWwpXG4gICAgICAuc2V0TmFtZSgnVGVtcGxhdGUgRm9sZGVyJylcbiAgICAgIC5zZXREZXNjKCdTdWJmb2xkZXIgd2l0aGluIHlvdXIgVGVtcGxhdGVyIHRlbXBsYXRlIGZvbGRlciBmb3IgVHVja2VycyBUb29scyB0ZW1wbGF0ZXMnKVxuICAgICAgLmFkZFRleHQodGV4dCA9PiB0ZXh0XG4gICAgICAgIC5zZXRQbGFjZWhvbGRlcignVHVja2VycyBUb29scycpXG4gICAgICAgIC5zZXRWYWx1ZSh0aGlzLnBsdWdpbi5zZXR0aW5ncy50ZW1wbGF0ZUZvbGRlcilcbiAgICAgICAgLm9uQ2hhbmdlKGFzeW5jICh2YWx1ZSkgPT4ge1xuICAgICAgICAgIHRoaXMucGx1Z2luLnNldHRpbmdzLnRlbXBsYXRlRm9sZGVyID0gdmFsdWU7XG4gICAgICAgICAgYXdhaXQgdGhpcy5wbHVnaW4uc2F2ZVNldHRpbmdzKCk7XG4gICAgICAgIH0pKTtcblxuICAgIG5ldyBTZXR0aW5nKGNvbnRhaW5lckVsKVxuICAgICAgLnNldE5hbWUoJ1VzZSBFbmhhbmNlZCBNZXRhZGF0YScpXG4gICAgICAuc2V0RGVzYygnRW5hYmxlIGVuaGFuY2VkIG1ldGFkYXRhIGZpZWxkcyBmb3IgbmV3IG5vdGVzIChleGlzdGluZyBub3RlcyByZW1haW4gdW5jaGFuZ2VkKScpXG4gICAgICAuYWRkVG9nZ2xlKHRvZ2dsZSA9PiB0b2dnbGVcbiAgICAgICAgLnNldFZhbHVlKHRoaXMucGx1Z2luLnNldHRpbmdzLnVzZUVuaGFuY2VkTWV0YWRhdGEpXG4gICAgICAgIC5vbkNoYW5nZShhc3luYyAodmFsdWUpID0+IHtcbiAgICAgICAgICB0aGlzLnBsdWdpbi5zZXR0aW5ncy51c2VFbmhhbmNlZE1ldGFkYXRhID0gdmFsdWU7XG4gICAgICAgICAgYXdhaXQgdGhpcy5wbHVnaW4uc2F2ZVNldHRpbmdzKCk7XG4gICAgICAgIH0pKTtcblxuICAgIG5ldyBTZXR0aW5nKGNvbnRhaW5lckVsKVxuICAgICAgLnNldE5hbWUoJ0RhdGF2aWV3IEZ1bmN0aW9ucyBQYXRoJylcbiAgICAgIC5zZXREZXNjKCdQYXRoIHRvIHRoZSBkYXRhdmlldyBmdW5jdGlvbnMgZmlsZSAod2l0aG91dCBleHRlbnNpb24pJylcbiAgICAgIC5hZGRUZXh0KHRleHQgPT4gdGV4dFxuICAgICAgICAuc2V0UGxhY2Vob2xkZXIoJy9TdXBwb3J0aW5nL2RhdGF2aWV3LWZ1bmN0aW9ucycpXG4gICAgICAgIC5zZXRWYWx1ZSh0aGlzLnBsdWdpbi5zZXR0aW5ncy5kYXRhdmlld0pzUGF0aClcbiAgICAgICAgLm9uQ2hhbmdlKGFzeW5jICh2YWx1ZSkgPT4ge1xuICAgICAgICAgIHRoaXMucGx1Z2luLnNldHRpbmdzLmRhdGF2aWV3SnNQYXRoID0gdmFsdWU7XG4gICAgICAgICAgYXdhaXQgdGhpcy5wbHVnaW4uc2F2ZVNldHRpbmdzKCk7XG4gICAgICAgIH0pKTtcbiAgfVxufSIsICIvLyBVdGlsaXR5IGZ1bmN0aW9ucyBmb3IgVHVja2VycyBUb29scyBwbHVnaW5cblxuZXhwb3J0IGZ1bmN0aW9uIGZvcm1hdERhdGUoZGF0ZTogRGF0ZSk6IHN0cmluZyB7XG4gIHJldHVybiBkYXRlLnRvSVNPU3RyaW5nKCkuc3BsaXQoXCJUXCIpWzBdXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBhZGREYXlzKGRhdGU6IERhdGUsIGRheXM6IG51bWJlcik6IERhdGUge1xuICBjb25zdCByZXN1bHQgPSBuZXcgRGF0ZShkYXRlKVxuICByZXN1bHQuc2V0RGF0ZShyZXN1bHQuZ2V0RGF0ZSgpICsgZGF5cylcbiAgcmV0dXJuIHJlc3VsdFxufVxuXG5leHBvcnQgZnVuY3Rpb24gaXNCZXR3ZWVuKGRhdGU6IERhdGUsIHN0YXJ0OiBEYXRlLCBlbmQ6IERhdGUpOiBib29sZWFuIHtcbiAgcmV0dXJuIGRhdGUgPj0gc3RhcnQgJiYgZGF0ZSA8PSBlbmRcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHNsdWdpZnkodGV4dDogc3RyaW5nKTogc3RyaW5nIHtcbiAgcmV0dXJuIHRleHRcbiAgICAudG9Mb3dlckNhc2UoKVxuICAgIC50cmltKClcbiAgICAubm9ybWFsaXplKFwiTkZEXCIpXG4gICAgLnJlcGxhY2UoL1tcXHUwMzAwLVxcdTAzNmZdL2csIFwiXCIpXG4gICAgLnJlcGxhY2UoL1teYS16MC05XFxzLV0vZywgXCJcIilcbiAgICAucmVwbGFjZSgvW1xccy1dKy9nLCBcIi1cIilcbiAgICAucmVwbGFjZSgvXi0rfC0rJC9nLCBcIlwiKVxufVxuXG5leHBvcnQgZnVuY3Rpb24gZ2V0Q291cnNlSWRGcm9tUGF0aChwYXRoOiBzdHJpbmcpOiBzdHJpbmcgfCBudWxsIHtcbiAgLy8gRXh0cmFjdCBjb3Vyc2UgSUQgZnJvbSBwYXRoIGxpa2UgXCIyMDI1L0ZhbGwvUFNJLTEwMS8uLi5cIiBvciBmaWxlbmFtZSBcIlBTSS0xMDEgLSBJbnRybyB0byBQc3ljaC5tZFwiXG4gIGNvbnN0IHBhcnRzID0gcGF0aC5zcGxpdChcIi9cIilcbiAgZm9yIChjb25zdCBwYXJ0IG9mIHBhcnRzKSB7XG4gICAgLy8gTG9vayBmb3IgY291cnNlIElEIHBhdHRlcm4gaW4gZWFjaCBwYXRoIHNlZ21lbnRcbiAgICBjb25zdCBtYXRjaCA9IHBhcnQubWF0Y2goLyhbQS1aXXsyLDR9LVxcZHszfSkvKVxuICAgIGlmIChtYXRjaCkge1xuICAgICAgcmV0dXJuIG1hdGNoWzFdXG4gICAgfVxuICB9XG4gIHJldHVybiBudWxsXG59XG5cbmV4cG9ydCBmdW5jdGlvbiB2YWxpZGF0ZURhdGUoZGF0ZVN0cmluZzogc3RyaW5nKTogYm9vbGVhbiB7XG4gIGNvbnN0IHJlZ2V4ID0gL15cXGR7NH0tXFxkezJ9LVxcZHsyfSQvXG4gIGlmICghZGF0ZVN0cmluZy5tYXRjaChyZWdleCkpIHJldHVybiBmYWxzZVxuXG4gIGNvbnN0IGRhdGUgPSBuZXcgRGF0ZShkYXRlU3RyaW5nKVxuICBjb25zdCB0aW1lc3RhbXAgPSBkYXRlLmdldFRpbWUoKVxuXG4gIGlmICh0eXBlb2YgdGltZXN0YW1wICE9PSBcIm51bWJlclwiIHx8IGlzTmFOKHRpbWVzdGFtcCkpIHJldHVybiBmYWxzZVxuXG4gIHJldHVybiBkYXRlU3RyaW5nID09PSBkYXRlLnRvSVNPU3RyaW5nKCkuc3BsaXQoXCJUXCIpWzBdXG59XG4iLCAiaW1wb3J0IHsgQXBwLCBOb3RpY2UgfSBmcm9tIFwib2JzaWRpYW5cIlxuaW1wb3J0IHsgVHVja2Vyc1Rvb2xzU2V0dGluZ3MgfSBmcm9tIFwiLi9zZXR0aW5nc1wiXG5cbmludGVyZmFjZSBUZW1wbGF0ZU1hbmlmZXN0IHtcbiAgdmVyc2lvbjogc3RyaW5nXG4gIHRlbXBsYXRlczogUmVjb3JkPHN0cmluZywgc3RyaW5nPlxuICBwbHVnaW5fdmVyc2lvbjogc3RyaW5nXG4gIHJlbGVhc2Vfbm90ZXM6IHN0cmluZ1xufVxuXG5leHBvcnQgY2xhc3MgVGVtcGxhdGVNYW5hZ2VyIHtcbiAgYXBwOiBBcHBcbiAgc2V0dGluZ3M6IFR1Y2tlcnNUb29sc1NldHRpbmdzXG4gIG1hbmlmZXN0OiBUZW1wbGF0ZU1hbmlmZXN0XG5cbiAgY29uc3RydWN0b3IoYXBwOiBBcHAsIHNldHRpbmdzOiBUdWNrZXJzVG9vbHNTZXR0aW5ncykge1xuICAgIHRoaXMuYXBwID0gYXBwXG4gICAgdGhpcy5zZXR0aW5ncyA9IHNldHRpbmdzXG4gICAgdGhpcy5tYW5pZmVzdCA9IHtcbiAgICAgIHZlcnNpb246IFwiMS4wLjBcIixcbiAgICAgIHRlbXBsYXRlczoge1xuICAgICAgICBcIkNvdXJzZXMvQ3JlYXRlIENvdXJzZSBIb21lcGFnZS5tZFwiOiBcIjEuMC4wXCIsXG4gICAgICAgIFwiQ291cnNlcy9Db3Vyc2UgSW5kZXgubWRcIjogXCIxLjAuMFwiLFxuICAgICAgICBcIk1vZHVsZXMvQ3JlYXRlIE1vZHVsZS5tZFwiOiBcIjEuMC4wXCIsXG4gICAgICAgIFwiQ2hhcHRlcnMvQ3JlYXRlIENoYXB0ZXIubWRcIjogXCIxLjAuMFwiLFxuICAgICAgICBcIkFzc2lnbm1lbnRzL0NyZWF0ZSBBc3NpZ25tZW50Lm1kXCI6IFwiMS4wLjBcIixcbiAgICAgICAgXCJEYWlseS9EYWlseSBOb3RlLm1kXCI6IFwiMS4wLjBcIixcbiAgICAgICAgXCJVdGlsaXRpZXMvVm9jYWJ1bGFyeSBFbnRyeS5tZFwiOiBcIjEuMC4wXCIsXG4gICAgICAgIFwiVXRpbGl0aWVzL0R1ZSBEYXRlIEVudHJ5Lm1kXCI6IFwiMS4wLjBcIlxuICAgICAgfSxcbiAgICAgIHBsdWdpbl92ZXJzaW9uOiBcIjEuMC4wXCIsXG4gICAgICByZWxlYXNlX25vdGVzOiBcIkluaXRpYWwgcmVsZWFzZSBvZiBUdWNrZXJzIFRvb2xzIHRlbXBsYXRlc1wiXG4gICAgfVxuICB9XG5cbiAgYXN5bmMgaW5zdGFsbFRlbXBsYXRlcygpIHtcbiAgICB0cnkge1xuICAgICAgLy8gR2V0IFRlbXBsYXRlciBwbHVnaW4gc2V0dGluZ3MgdG8gZmluZCB0ZW1wbGF0ZSBmb2xkZXJcbiAgICAgIGNvbnN0IHRlbXBsYXRlclBsdWdpbiA9IHRoaXMuZ2V0VGVtcGxhdGVyUGx1Z2luKClcbiAgICAgIGlmICghdGVtcGxhdGVyUGx1Z2luKSB7XG4gICAgICAgIG5ldyBOb3RpY2UoXG4gICAgICAgICAgXCJUZW1wbGF0ZXIgcGx1Z2luIG5vdCBmb3VuZC4gUGxlYXNlIGluc3RhbGwgYW5kIGVuYWJsZSB0aGUgVGVtcGxhdGVyIHBsdWdpbiBmaXJzdC5cIlxuICAgICAgICApXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXG4gICAgICAgICAgXCJUZW1wbGF0ZXIgcGx1Z2luIG5vdCBmb3VuZC4gUGxlYXNlIGluc3RhbGwgYW5kIGVuYWJsZSB0aGUgVGVtcGxhdGVyIHBsdWdpbiBmaXJzdC5cIlxuICAgICAgICApXG4gICAgICAgIHJldHVyblxuICAgICAgfVxuXG4gICAgICBjb25zdCB0ZW1wbGF0ZUZvbGRlclBhdGggPSB0aGlzLmdldFRlbXBsYXRlRm9sZGVyUGF0aCh0ZW1wbGF0ZXJQbHVnaW4pXG4gICAgICBpZiAoIXRlbXBsYXRlRm9sZGVyUGF0aCkge1xuICAgICAgICBuZXcgTm90aWNlKFxuICAgICAgICAgIFwiVGVtcGxhdGUgZm9sZGVyIG5vdCBjb25maWd1cmVkIGluIFRlbXBsYXRlciBzZXR0aW5ncy4gUGxlYXNlIGNvbmZpZ3VyZSBpdCBpbiBUZW1wbGF0ZXIgc2V0dGluZ3MgZmlyc3QuXCJcbiAgICAgICAgKVxuICAgICAgICBjb25zb2xlLmVycm9yKFxuICAgICAgICAgIFwiVGVtcGxhdGUgZm9sZGVyIG5vdCBjb25maWd1cmVkIGluIFRlbXBsYXRlciBzZXR0aW5ncy4gUGxlYXNlIGNvbmZpZ3VyZSBpdCBpbiBUZW1wbGF0ZXIgc2V0dGluZ3MgZmlyc3QuXCJcbiAgICAgICAgKVxuICAgICAgICByZXR1cm5cbiAgICAgIH1cblxuICAgICAgY29uc3QgZnVsbFRlbXBsYXRlUGF0aCA9IGAke3RlbXBsYXRlRm9sZGVyUGF0aH0vJHt0aGlzLnNldHRpbmdzLnRlbXBsYXRlRm9sZGVyfWBcblxuICAgICAgLy8gQ3JlYXRlIHRoZSBtYWluIHRlbXBsYXRlIGZvbGRlciBpZiBpdCBkb2Vzbid0IGV4aXN0XG4gICAgICB0cnkge1xuICAgICAgICBhd2FpdCB0aGlzLmFwcC52YXVsdC5jcmVhdGVGb2xkZXIoZnVsbFRlbXBsYXRlUGF0aClcbiAgICAgICAgY29uc29sZS5sb2coYENyZWF0ZWQgdGVtcGxhdGUgZm9sZGVyOiAke2Z1bGxUZW1wbGF0ZVBhdGh9YClcbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgLy8gRm9sZGVyIG1pZ2h0IGFscmVhZHkgZXhpc3QsIHdoaWNoIGlzIGZpbmVcbiAgICAgICAgY29uc29sZS5sb2coXG4gICAgICAgICAgYFRlbXBsYXRlIGZvbGRlciBhbHJlYWR5IGV4aXN0cyBvciBjcmVhdGVkOiAke2Z1bGxUZW1wbGF0ZVBhdGh9YFxuICAgICAgICApXG4gICAgICB9XG5cbiAgICAgIC8vIENyZWF0ZSBzdWJkaXJlY3Rvcmllc1xuICAgICAgY29uc3Qgc3ViZGlycyA9IFtcbiAgICAgICAgXCJDb3Vyc2VzXCIsXG4gICAgICAgIFwiTW9kdWxlc1wiLFxuICAgICAgICBcIkNoYXB0ZXJzXCIsXG4gICAgICAgIFwiQXNzaWdubWVudHNcIixcbiAgICAgICAgXCJEYWlseVwiLFxuICAgICAgICBcIlV0aWxpdGllc1wiXG4gICAgICBdXG4gICAgICBmb3IgKGNvbnN0IHN1YmRpciBvZiBzdWJkaXJzKSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgY29uc3Qgc3ViUGF0aCA9IGAke2Z1bGxUZW1wbGF0ZVBhdGh9LyR7c3ViZGlyfWBcbiAgICAgICAgICBhd2FpdCB0aGlzLmFwcC52YXVsdC5jcmVhdGVGb2xkZXIoc3ViUGF0aClcbiAgICAgICAgICBjb25zb2xlLmxvZyhgQ3JlYXRlZCBzdWJkaXJlY3Rvcnk6ICR7c3ViUGF0aH1gKVxuICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgLy8gRm9sZGVyIG1pZ2h0IGFscmVhZHkgZXhpc3QsIHdoaWNoIGlzIGZpbmVcbiAgICAgICAgICBjb25zb2xlLmxvZyhcbiAgICAgICAgICAgIGBTdWJkaXJlY3RvcnkgYWxyZWFkeSBleGlzdHM6ICR7ZnVsbFRlbXBsYXRlUGF0aH0vJHtzdWJkaXJ9YFxuICAgICAgICAgIClcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICAvLyBJbnN0YWxsIHRlbXBsYXRlc1xuICAgICAgYXdhaXQgdGhpcy5pbnN0YWxsQ291cnNlVGVtcGxhdGVzKGZ1bGxUZW1wbGF0ZVBhdGgpXG4gICAgICBhd2FpdCB0aGlzLmluc3RhbGxNb2R1bGVUZW1wbGF0ZXMoZnVsbFRlbXBsYXRlUGF0aClcbiAgICAgIGF3YWl0IHRoaXMuaW5zdGFsbENoYXB0ZXJUZW1wbGF0ZXMoZnVsbFRlbXBsYXRlUGF0aClcbiAgICAgIGF3YWl0IHRoaXMuaW5zdGFsbEFzc2lnbm1lbnRUZW1wbGF0ZXMoZnVsbFRlbXBsYXRlUGF0aClcbiAgICAgIGF3YWl0IHRoaXMuaW5zdGFsbERhaWx5VGVtcGxhdGVzKGZ1bGxUZW1wbGF0ZVBhdGgpXG5cbiAgICAgIC8vIENyZWF0ZSBSRUFETUVcbiAgICAgIGF3YWl0IHRoaXMuY3JlYXRlUkVBRE1FKGZ1bGxUZW1wbGF0ZVBhdGgpXG5cbiAgICAgIC8vIENyZWF0ZSB0ZW1wbGF0ZSBtYW5pZmVzdFxuICAgICAgYXdhaXQgdGhpcy5jcmVhdGVUZW1wbGF0ZU1hbmlmZXN0KGZ1bGxUZW1wbGF0ZVBhdGgpXG5cbiAgICAgIG5ldyBOb3RpY2UoXCJUdWNrZXJzIFRvb2xzIHRlbXBsYXRlcyBpbnN0YWxsZWQgc3VjY2Vzc2Z1bGx5IVwiKVxuICAgICAgY29uc29sZS5sb2coXCJUdWNrZXJzIFRvb2xzIHRlbXBsYXRlcyBpbnN0YWxsZWQgc3VjY2Vzc2Z1bGx5XCIpXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBpbnN0YWxsaW5nIHRlbXBsYXRlczpcIiwgZXJyb3IpXG4gICAgICBuZXcgTm90aWNlKFwiRXJyb3IgaW5zdGFsbGluZyB0ZW1wbGF0ZXMuIENoZWNrIGNvbnNvbGUgZm9yIGRldGFpbHMuXCIpXG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSBnZXRUZW1wbGF0ZXJQbHVnaW4oKTogYW55IHtcbiAgICAvLyBUcnkgbXVsdGlwbGUgd2F5cyB0byBhY2Nlc3MgdGhlIFRlbXBsYXRlciBwbHVnaW5cbiAgICBjb25zdCBwb3NzaWJsZVBhdGhzID0gW1xuICAgICAgKHRoaXMuYXBwIGFzIGFueSkucGx1Z2lucy5wbHVnaW5zW1widGVtcGxhdGVyLW9ic2lkaWFuXCJdLFxuICAgICAgKHRoaXMuYXBwIGFzIGFueSkucGx1Z2lucy5wbHVnaW5zW1widGVtcGxhdGVyXCJdLFxuICAgICAgKHRoaXMuYXBwIGFzIGFueSkucGx1Z2lucy5nZXRQbHVnaW4oXCJ0ZW1wbGF0ZXItb2JzaWRpYW5cIiksXG4gICAgICAodGhpcy5hcHAgYXMgYW55KS5wbHVnaW5zLmdldFBsdWdpbihcInRlbXBsYXRlclwiKVxuICAgIF1cblxuICAgIGZvciAoY29uc3QgcGF0aCBvZiBwb3NzaWJsZVBhdGhzKSB7XG4gICAgICBpZiAocGF0aCkge1xuICAgICAgICByZXR1cm4gcGF0aFxuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBudWxsXG4gIH1cblxuICBwcml2YXRlIGdldFRlbXBsYXRlRm9sZGVyUGF0aCh0ZW1wbGF0ZXJQbHVnaW46IGFueSk6IHN0cmluZyB8IG51bGwge1xuICAgIGNvbnN0IHNldHRpbmdzID0gdGVtcGxhdGVyUGx1Z2luLnNldHRpbmdzXG5cbiAgICBpZiAoIXNldHRpbmdzKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiVGVtcGxhdGVyIHBsdWdpbiBoYXMgbm8gc2V0dGluZ3NcIilcbiAgICAgIHJldHVybiBudWxsXG4gICAgfVxuXG4gICAgLy8gVHJ5IGRpZmZlcmVudCBwb3NzaWJsZSBwcm9wZXJ0eSBuYW1lcyBmb3IgdGVtcGxhdGUgZm9sZGVyXG4gICAgY29uc3QgcG9zc2libGVQYXRocyA9IFtcbiAgICAgIHNldHRpbmdzLnRlbXBsYXRlc19mb2xkZXIsICAvLyBDaGFuZ2VkIGZyb20gdGVtcGxhdGVfZm9sZGVyIHRvIG1hdGNoIGFjdHVhbCBzZXR0aW5nXG4gICAgICBzZXR0aW5ncy50ZW1wbGF0ZV9mb2xkZXIsXG4gICAgICBzZXR0aW5ncy50ZW1wbGF0ZUZvbGRlcixcbiAgICAgIHNldHRpbmdzLnRlbXBsYXRlRm9sZGVyUGF0aCxcbiAgICAgIHNldHRpbmdzLmZvbGRlclxuICAgIF1cblxuICAgIGZvciAoY29uc3QgcGF0aCBvZiBwb3NzaWJsZVBhdGhzKSB7XG4gICAgICBpZiAocGF0aCAmJiB0eXBlb2YgcGF0aCA9PT0gXCJzdHJpbmdcIikge1xuICAgICAgICByZXR1cm4gcGF0aFxuICAgICAgfVxuICAgIH1cblxuICAgIGNvbnNvbGUuZXJyb3IoXG4gICAgICBcIlRlbXBsYXRlIGZvbGRlciBub3QgZm91bmQgaW4gVGVtcGxhdGVyIHNldHRpbmdzLiBBdmFpbGFibGUgc2V0dGluZ3M6XCIsXG4gICAgICBPYmplY3Qua2V5cyhzZXR0aW5ncylcbiAgICApXG4gICAgcmV0dXJuIG51bGxcbiAgfVxuXG4gIGFzeW5jIGNyZWF0ZVRlbXBsYXRlTWFuaWZlc3QoYmFzZVBhdGg6IHN0cmluZykge1xuICAgIGNvbnN0IG1hbmlmZXN0UGF0aCA9IGAke2Jhc2VQYXRofS90ZW1wbGF0ZS1tYW5pZmVzdC5qc29uYFxuICAgIGNvbnN0IG1hbmlmZXN0Q29udGVudCA9IEpTT04uc3RyaW5naWZ5KHRoaXMubWFuaWZlc3QsIG51bGwsIDIpXG5cbiAgICB0cnkge1xuICAgICAgLy8gQ2hlY2sgaWYgbWFuaWZlc3QgYWxyZWFkeSBleGlzdHNcbiAgICAgIGNvbnN0IGV4aXN0aW5nTWFuaWZlc3QgPVxuICAgICAgICB0aGlzLmFwcC52YXVsdC5nZXRBYnN0cmFjdEZpbGVCeVBhdGgobWFuaWZlc3RQYXRoKVxuICAgICAgaWYgKGV4aXN0aW5nTWFuaWZlc3QpIHtcbiAgICAgICAgLy8gVXBkYXRlIHRoZSBleGlzdGluZyBtYW5pZmVzdFxuICAgICAgICBjb25zdCBmaWxlID0gZXhpc3RpbmdNYW5pZmVzdCBhcyBpbXBvcnQoXCJvYnNpZGlhblwiKS5URmlsZVxuICAgICAgICBhd2FpdCB0aGlzLmFwcC52YXVsdC5tb2RpZnkoZmlsZSwgbWFuaWZlc3RDb250ZW50KVxuICAgICAgICBjb25zb2xlLmxvZyhgVXBkYXRlZCB0ZW1wbGF0ZSBtYW5pZmVzdDogJHttYW5pZmVzdFBhdGh9YClcbiAgICAgICAgcmV0dXJuXG4gICAgICB9XG5cbiAgICAgIC8vIENyZWF0ZSB0aGUgbWFuaWZlc3QgZmlsZVxuICAgICAgYXdhaXQgdGhpcy5hcHAudmF1bHQuY3JlYXRlKG1hbmlmZXN0UGF0aCwgbWFuaWZlc3RDb250ZW50KVxuICAgICAgY29uc29sZS5sb2coYENyZWF0ZWQgdGVtcGxhdGUgbWFuaWZlc3Q6ICR7bWFuaWZlc3RQYXRofWApXG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgbmV3IE5vdGljZShgRXJyb3IgY3JlYXRpbmcgdGVtcGxhdGUgbWFuaWZlc3QgJHttYW5pZmVzdFBhdGh9YClcbiAgICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIGNyZWF0aW5nIHRlbXBsYXRlIG1hbmlmZXN0ICR7bWFuaWZlc3RQYXRofTpgLCBlKVxuICAgIH1cbiAgfVxuXG4gIGFzeW5jIGNoZWNrRm9yVGVtcGxhdGVVcGRhdGVzKCk6IFByb21pc2U8Ym9vbGVhbj4ge1xuICAgIC8vIFRoaXMgd291bGQgY2hlY2sgaWYgdGVtcGxhdGVzIG5lZWQgdG8gYmUgdXBkYXRlZFxuICAgIC8vIEZvciBub3csIHdlJ2xsIGp1c3QgcmV0dXJuIGZhbHNlXG4gICAgY29uc29sZS5sb2coXCJDaGVja2luZyBmb3IgdGVtcGxhdGUgdXBkYXRlc1wiKVxuICAgIHJldHVybiBmYWxzZVxuICB9XG5cbiAgYXN5bmMgdXBkYXRlVGVtcGxhdGVzKCkge1xuICAgIHRyeSB7XG4gICAgICAvLyBUaGlzIHdvdWxkIHVwZGF0ZSBleGlzdGluZyB0ZW1wbGF0ZXNcbiAgICAgIGNvbnNvbGUubG9nKFwiVXBkYXRpbmcgdGVtcGxhdGVzXCIpXG5cbiAgICAgIC8vIEdldCBUZW1wbGF0ZXIgcGx1Z2luIHNldHRpbmdzIHRvIGZpbmQgdGVtcGxhdGUgZm9sZGVyXG4gICAgICBjb25zdCB0ZW1wbGF0ZXJQbHVnaW4gPSB0aGlzLmdldFRlbXBsYXRlclBsdWdpbigpXG4gICAgICBpZiAoIXRlbXBsYXRlclBsdWdpbikge1xuICAgICAgICBuZXcgTm90aWNlKFxuICAgICAgICAgIFwiVGVtcGxhdGVyIHBsdWdpbiBub3QgZm91bmQuIFBsZWFzZSBpbnN0YWxsIGFuZCBlbmFibGUgdGhlIFRlbXBsYXRlciBwbHVnaW4gZmlyc3QuXCJcbiAgICAgICAgKVxuICAgICAgICBjb25zb2xlLmVycm9yKFxuICAgICAgICAgIFwiVGVtcGxhdGVyIHBsdWdpbiBub3QgZm91bmQuIFBsZWFzZSBpbnN0YWxsIGFuZCBlbmFibGUgdGhlIFRlbXBsYXRlciBwbHVnaW4gZmlyc3QuXCJcbiAgICAgICAgKVxuICAgICAgICByZXR1cm5cbiAgICAgIH1cblxuICAgICAgY29uc3QgdGVtcGxhdGVGb2xkZXJQYXRoID0gdGhpcy5nZXRUZW1wbGF0ZUZvbGRlclBhdGgodGVtcGxhdGVyUGx1Z2luKVxuICAgICAgaWYgKCF0ZW1wbGF0ZUZvbGRlclBhdGgpIHtcbiAgICAgICAgbmV3IE5vdGljZShcbiAgICAgICAgICBcIlRlbXBsYXRlIGZvbGRlciBub3QgY29uZmlndXJlZCBpbiBUZW1wbGF0ZXIgc2V0dGluZ3MuIFBsZWFzZSBjb25maWd1cmUgaXQgaW4gVGVtcGxhdGVyIHNldHRpbmdzIGZpcnN0LlwiXG4gICAgICAgIClcbiAgICAgICAgY29uc29sZS5lcnJvcihcbiAgICAgICAgICBcIlRlbXBsYXRlIGZvbGRlciBub3QgY29uZmlndXJlZCBpbiBUZW1wbGF0ZXIgc2V0dGluZ3MuIFBsZWFzZSBjb25maWd1cmUgaXQgaW4gVGVtcGxhdGVyIHNldHRpbmdzIGZpcnN0LlwiXG4gICAgICAgIClcbiAgICAgICAgcmV0dXJuXG4gICAgICB9XG5cbiAgICAgIGNvbnN0IGZ1bGxUZW1wbGF0ZVBhdGggPSBgJHt0ZW1wbGF0ZUZvbGRlclBhdGh9LyR7dGhpcy5zZXR0aW5ncy50ZW1wbGF0ZUZvbGRlcn1gXG5cbiAgICAgIC8vIFVwZGF0ZSB0ZW1wbGF0ZXMgKHRoaXMgd2lsbCBvdmVyd3JpdGUgZXhpc3Rpbmcgb25lcylcbiAgICAgIGF3YWl0IHRoaXMuaW5zdGFsbENvdXJzZVRlbXBsYXRlcyhmdWxsVGVtcGxhdGVQYXRoKVxuICAgICAgYXdhaXQgdGhpcy5pbnN0YWxsTW9kdWxlVGVtcGxhdGVzKGZ1bGxUZW1wbGF0ZVBhdGgpXG4gICAgICBhd2FpdCB0aGlzLmluc3RhbGxDaGFwdGVyVGVtcGxhdGVzKGZ1bGxUZW1wbGF0ZVBhdGgpXG4gICAgICBhd2FpdCB0aGlzLmluc3RhbGxBc3NpZ25tZW50VGVtcGxhdGVzKGZ1bGxUZW1wbGF0ZVBhdGgpXG4gICAgICBhd2FpdCB0aGlzLmluc3RhbGxEYWlseVRlbXBsYXRlcyhmdWxsVGVtcGxhdGVQYXRoKVxuXG4gICAgICAvLyBVcGRhdGUgUkVBRE1FXG4gICAgICBhd2FpdCB0aGlzLmNyZWF0ZVJFQURNRShmdWxsVGVtcGxhdGVQYXRoKVxuXG4gICAgICAvLyBVcGRhdGUgdGVtcGxhdGUgbWFuaWZlc3RcbiAgICAgIGF3YWl0IHRoaXMuY3JlYXRlVGVtcGxhdGVNYW5pZmVzdChmdWxsVGVtcGxhdGVQYXRoKVxuXG4gICAgICBuZXcgTm90aWNlKFwiVHVja2VycyBUb29scyB0ZW1wbGF0ZXMgdXBkYXRlZCBzdWNjZXNzZnVsbHkhXCIpXG4gICAgICBjb25zb2xlLmxvZyhcIlR1Y2tlcnMgVG9vbHMgdGVtcGxhdGVzIHVwZGF0ZWQgc3VjY2Vzc2Z1bGx5XCIpXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciB1cGRhdGluZyB0ZW1wbGF0ZXM6XCIsIGVycm9yKVxuICAgICAgbmV3IE5vdGljZShcIkVycm9yIHVwZGF0aW5nIHRlbXBsYXRlcy4gQ2hlY2sgY29uc29sZSBmb3IgZGV0YWlscy5cIilcbiAgICB9XG4gIH1cblxuICBhc3luYyBpbnN0YWxsQ291cnNlVGVtcGxhdGVzKGJhc2VQYXRoOiBzdHJpbmcpIHtcbiAgICBjb25zdCBjb3Vyc2VQYXRoID0gYCR7YmFzZVBhdGh9L0NvdXJzZXNgXG5cbiAgICAvLyBDcmVhdGUgQ291cnNlIEhvbWVwYWdlIHRlbXBsYXRlXG4gICAgY29uc3QgY291cnNlSG9tZXBhZ2VUZW1wbGF0ZSA9IHRoaXMuZ2VuZXJhdGVDb3Vyc2VIb21lcGFnZVRlbXBsYXRlKClcbiAgICBhd2FpdCB0aGlzLndyaXRlVGVtcGxhdGVGaWxlKFxuICAgICAgYCR7Y291cnNlUGF0aH0vQ3JlYXRlIENvdXJzZSBIb21lcGFnZS5tZGAsXG4gICAgICBjb3Vyc2VIb21lcGFnZVRlbXBsYXRlXG4gICAgKVxuXG4gICAgLy8gQ3JlYXRlIENvdXJzZSBJbmRleCB0ZW1wbGF0ZVxuICAgIGNvbnN0IGNvdXJzZUluZGV4VGVtcGxhdGUgPSB0aGlzLmdlbmVyYXRlQ291cnNlSW5kZXhUZW1wbGF0ZSgpXG4gICAgYXdhaXQgdGhpcy53cml0ZVRlbXBsYXRlRmlsZShcbiAgICAgIGAke2NvdXJzZVBhdGh9L0NvdXJzZSBJbmRleC5tZGAsXG4gICAgICBjb3Vyc2VJbmRleFRlbXBsYXRlXG4gICAgKVxuICB9XG5cbiAgYXN5bmMgaW5zdGFsbE1vZHVsZVRlbXBsYXRlcyhiYXNlUGF0aDogc3RyaW5nKSB7XG4gICAgY29uc3QgbW9kdWxlUGF0aCA9IGAke2Jhc2VQYXRofS9Nb2R1bGVzYFxuXG4gICAgLy8gQ3JlYXRlIE1vZHVsZSB0ZW1wbGF0ZVxuICAgIGNvbnN0IG1vZHVsZVRlbXBsYXRlID0gdGhpcy5nZW5lcmF0ZU1vZHVsZVRlbXBsYXRlKClcbiAgICBhd2FpdCB0aGlzLndyaXRlVGVtcGxhdGVGaWxlKFxuICAgICAgYCR7bW9kdWxlUGF0aH0vQ3JlYXRlIE1vZHVsZS5tZGAsXG4gICAgICBtb2R1bGVUZW1wbGF0ZVxuICAgIClcbiAgfVxuXG4gIGFzeW5jIGluc3RhbGxDaGFwdGVyVGVtcGxhdGVzKGJhc2VQYXRoOiBzdHJpbmcpIHtcbiAgICBjb25zdCBjaGFwdGVyUGF0aCA9IGAke2Jhc2VQYXRofS9DaGFwdGVyc2BcblxuICAgIC8vIENyZWF0ZSBDaGFwdGVyIHRlbXBsYXRlXG4gICAgY29uc3QgY2hhcHRlclRlbXBsYXRlID0gdGhpcy5nZW5lcmF0ZUNoYXB0ZXJUZW1wbGF0ZSgpXG4gICAgYXdhaXQgdGhpcy53cml0ZVRlbXBsYXRlRmlsZShcbiAgICAgIGAke2NoYXB0ZXJQYXRofS9DcmVhdGUgQ2hhcHRlci5tZGAsXG4gICAgICBjaGFwdGVyVGVtcGxhdGVcbiAgICApXG4gIH1cblxuICBhc3luYyBpbnN0YWxsQXNzaWdubWVudFRlbXBsYXRlcyhiYXNlUGF0aDogc3RyaW5nKSB7XG4gICAgY29uc3QgYXNzaWdubWVudFBhdGggPSBgJHtiYXNlUGF0aH0vQXNzaWdubWVudHNgXG5cbiAgICAvLyBDcmVhdGUgQXNzaWdubWVudCB0ZW1wbGF0ZVxuICAgIGNvbnN0IGFzc2lnbm1lbnRUZW1wbGF0ZSA9IHRoaXMuZ2VuZXJhdGVBc3NpZ25tZW50VGVtcGxhdGUoKVxuICAgIGF3YWl0IHRoaXMud3JpdGVUZW1wbGF0ZUZpbGUoXG4gICAgICBgJHthc3NpZ25tZW50UGF0aH0vQ3JlYXRlIEFzc2lnbm1lbnQubWRgLFxuICAgICAgYXNzaWdubWVudFRlbXBsYXRlXG4gICAgKVxuICB9XG5cbiAgYXN5bmMgaW5zdGFsbERhaWx5VGVtcGxhdGVzKGJhc2VQYXRoOiBzdHJpbmcpIHtcbiAgICBjb25zdCBkYWlseVBhdGggPSBgJHtiYXNlUGF0aH0vRGFpbHlgXG5cbiAgICAvLyBDcmVhdGUgRGFpbHkgTm90ZSB0ZW1wbGF0ZVxuICAgIGNvbnN0IGRhaWx5Tm90ZVRlbXBsYXRlID0gdGhpcy5nZW5lcmF0ZURhaWx5Tm90ZVRlbXBsYXRlKClcbiAgICBhd2FpdCB0aGlzLndyaXRlVGVtcGxhdGVGaWxlKFxuICAgICAgYCR7ZGFpbHlQYXRofS9EYWlseSBOb3RlLm1kYCxcbiAgICAgIGRhaWx5Tm90ZVRlbXBsYXRlXG4gICAgKVxuICB9XG5cbiAgLyoqXG4gICAqIEdlbmVyYXRlcyB0aGUgcHJvcGVyIG5lc3RlZCBwYXRoIGZvciBhIG1vZHVsZSBmaWxlIGJhc2VkIG9uIGNvdXJzZSBkZXRhaWxzXG4gICAqIEBwYXJhbSBjb3Vyc2UgLSBUaGUgY291cnNlIGZpbGUgb2JqZWN0IG9yIGNvdXJzZSBuYW1lIHN0cmluZ1xuICAgKiBAcGFyYW0gY291cnNlSWQgLSBUaGUgY291cnNlIElEXG4gICAqIEBwYXJhbSBtb2R1bGVOdW1iZXIgLSBUaGUgbW9kdWxlIG51bWJlciAob3B0aW9uYWwpXG4gICAqIEBwYXJhbSB3ZWVrTnVtYmVyIC0gVGhlIHdlZWsgbnVtYmVyIChvcHRpb25hbClcbiAgICogQHBhcmFtIGRheU9mV2VlayAtIFRoZSBkYXkgb2YgdGhlIHdlZWtcbiAgICogQHJldHVybnMgVGhlIHByb3BlciBuZXN0ZWQgcGF0aCBmb3IgdGhlIG1vZHVsZSBmaWxlXG4gICAqL1xuICBnZW5lcmF0ZU1vZHVsZVBhdGgoXG4gICAgY291cnNlOiBhbnksXG4gICAgY291cnNlSWQ6IHN0cmluZyxcbiAgICBtb2R1bGVOdW1iZXI6IHN0cmluZyB8IG51bGwsXG4gICAgd2Vla051bWJlcjogc3RyaW5nIHwgbnVsbCxcbiAgICBkYXlPZldlZWs6IHN0cmluZ1xuICApOiBzdHJpbmcge1xuICAgIGxldCBtb2R1bGVQYXRoID0gXCJcIjtcbiAgICBcbiAgICBpZiAodHlwZW9mIGNvdXJzZSA9PT0gJ29iamVjdCcgJiYgY291cnNlICE9PSBudWxsICYmIGNvdXJzZS5wYXRoKSB7XG4gICAgICAvLyBHZXQgdGhlIGRpcmVjdG9yeSBvZiB0aGUgY291cnNlIGZpbGUgKHNob3VsZCBiZSBZZWFyL1NlYXNvbi9Db3Vyc2VOYW1lLylcbiAgICAgIGNvbnN0IGNvdXJzZURpciA9IGNvdXJzZS5wYXRoLnN1YnN0cmluZygwLCBjb3Vyc2UucGF0aC5sYXN0SW5kZXhPZignLycpKTtcbiAgICAgIGNvbnN0IGNvdXJzZU5hbWUgPSBjb3Vyc2UuYmFzZW5hbWU7XG4gICAgICBcbiAgICAgIC8vIENyZWF0ZSBwcm9wZXIgbmVzdGVkIGRpcmVjdG9yeSBzdHJ1Y3R1cmUgYmFzZWQgb24gbW9kdWxlL3dlZWsgbnVtYmVyc1xuICAgICAgaWYgKG1vZHVsZU51bWJlciAmJiB3ZWVrTnVtYmVyKSB7XG4gICAgICAgIC8vIE1vZHVsZSBhbmQgV2VlayBjb21iaW5hdGlvbjogL1llYXIvU2Vhc29uL0NvdXJzZU5hbWUvQ291cnNlSWQgLSBNb2R1bGUgWC9Db3Vyc2VJZCAtIFdlZWsgWS9Db3Vyc2VJZC5YLlkubWRcbiAgICAgICAgbW9kdWxlUGF0aCA9IGAke2NvdXJzZURpcn0vJHtjb3Vyc2VJZH0gLSBNb2R1bGUgJHttb2R1bGVOdW1iZXJ9LyR7Y291cnNlSWR9IC0gV2VlayAke3dlZWtOdW1iZXJ9LyR7Y291cnNlSWR9LiR7bW9kdWxlTnVtYmVyfS4ke3dlZWtOdW1iZXJ9IC0gJHtkYXlPZldlZWt9YDtcbiAgICAgIH0gZWxzZSBpZiAobW9kdWxlTnVtYmVyKSB7XG4gICAgICAgIC8vIE1vZHVsZSBvbmx5OiAvWWVhci9TZWFzb24vQ291cnNlTmFtZS9Db3Vyc2VJZCAtIE1vZHVsZSBYL0NvdXJzZUlkLlgubWRcbiAgICAgICAgbW9kdWxlUGF0aCA9IGAke2NvdXJzZURpcn0vJHtjb3Vyc2VJZH0gLSBNb2R1bGUgJHttb2R1bGVOdW1iZXJ9LyR7Y291cnNlSWR9LiR7bW9kdWxlTnVtYmVyfSAtICR7ZGF5T2ZXZWVrfWA7XG4gICAgICB9IGVsc2UgaWYgKHdlZWtOdW1iZXIpIHtcbiAgICAgICAgLy8gV2VlayBvbmx5OiAvWWVhci9TZWFzb24vQ291cnNlTmFtZS9Db3Vyc2VJZCAtIFdlZWsgWC9Db3Vyc2VJZC5YIERPVy5tZFxuICAgICAgICBtb2R1bGVQYXRoID0gYCR7Y291cnNlRGlyfS8ke2NvdXJzZUlkfSAtIFdlZWsgJHt3ZWVrTnVtYmVyfS8ke2NvdXJzZUlkfS4ke3dlZWtOdW1iZXJ9ICR7ZGF5T2ZXZWVrfWA7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICAvLyBOZWl0aGVyIG1vZHVsZSBub3Igd2VlazogL1llYXIvU2Vhc29uL0NvdXJzZU5hbWUvQ291cnNlSWQgLSBET1cubWRcbiAgICAgICAgbW9kdWxlUGF0aCA9IGAke2NvdXJzZURpcn0vJHtjb3Vyc2VJZH0gLSAke2RheU9mV2Vla31gO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICAvLyBGYWxsYmFjayAtIHB1dCBpbiBNb2R1bGVzIGRpcmVjdG9yeSB3aXRoIG5lc3RlZCBzdHJ1Y3R1cmVcbiAgICAgIGlmIChtb2R1bGVOdW1iZXIgJiYgd2Vla051bWJlcikge1xuICAgICAgICBtb2R1bGVQYXRoID0gYE1vZHVsZXMvJHtjb3Vyc2VJZH0gLSBNb2R1bGUgJHttb2R1bGVOdW1iZXJ9LyR7Y291cnNlSWR9IC0gV2VlayAke3dlZWtOdW1iZXJ9LyR7Y291cnNlSWR9LiR7bW9kdWxlTnVtYmVyfS4ke3dlZWtOdW1iZXJ9IC0gJHtkYXlPZldlZWt9YDtcbiAgICAgIH0gZWxzZSBpZiAobW9kdWxlTnVtYmVyKSB7XG4gICAgICAgIG1vZHVsZVBhdGggPSBgTW9kdWxlcy8ke2NvdXJzZUlkfSAtIE1vZHVsZSAke21vZHVsZU51bWJlcn0vJHtjb3Vyc2VJZH0uJHttb2R1bGVOdW1iZXJ9IC0gJHtkYXlPZldlZWt9YDtcbiAgICAgIH0gZWxzZSBpZiAod2Vla051bWJlcikge1xuICAgICAgICBtb2R1bGVQYXRoID0gYE1vZHVsZXMvJHtjb3Vyc2VJZH0gLSBXZWVrICR7d2Vla051bWJlcn0vJHtjb3Vyc2VJZH0uJHt3ZWVrTnVtYmVyfSAke2RheU9mV2Vla31gO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgbW9kdWxlUGF0aCA9IGBNb2R1bGVzLyR7Y291cnNlSWR9IC0gJHtkYXlPZldlZWt9YDtcbiAgICAgIH1cbiAgICB9XG4gICAgXG4gICAgcmV0dXJuIG1vZHVsZVBhdGg7XG4gIH1cblxuICBhc3luYyB3cml0ZVRlbXBsYXRlRmlsZShwYXRoOiBzdHJpbmcsIGNvbnRlbnQ6IHN0cmluZykge1xuICAgIHRyeSB7XG4gICAgICAvLyBDaGVjayBpZiBmaWxlIGFscmVhZHkgZXhpc3RzXG4gICAgICBjb25zdCBleGlzdGluZ0ZpbGUgPSB0aGlzLmFwcC52YXVsdC5nZXRBYnN0cmFjdEZpbGVCeVBhdGgocGF0aClcbiAgICAgIGlmIChleGlzdGluZ0ZpbGUpIHtcbiAgICAgICAgLy8gRm9yIG5vdywgd2UnbGwgdXBkYXRlIGV4aXN0aW5nIHRlbXBsYXRlc1xuICAgICAgICAvLyBJbiBhIHJlYWwgaW1wbGVtZW50YXRpb24sIHdlJ2QgY2hlY2sgdmVyc2lvbnMgYW5kIG9mZmVyIHRvIHVwZGF0ZVxuICAgICAgICBjb25zb2xlLmxvZyhgVXBkYXRpbmcgZXhpc3RpbmcgdGVtcGxhdGUgZmlsZTogJHtwYXRofWApXG4gICAgICAgIGNvbnN0IGZpbGUgPSBleGlzdGluZ0ZpbGUgYXMgaW1wb3J0KFwib2JzaWRpYW5cIikuVEZpbGVcbiAgICAgICAgYXdhaXQgdGhpcy5hcHAudmF1bHQubW9kaWZ5KGZpbGUsIGNvbnRlbnQpXG4gICAgICAgIHJldHVyblxuICAgICAgfVxuXG4gICAgICAvLyBDcmVhdGUgdGhlIGZpbGVcbiAgICAgIGF3YWl0IHRoaXMuYXBwLnZhdWx0LmNyZWF0ZShwYXRoLCBjb250ZW50KVxuICAgICAgY29uc29sZS5sb2coYENyZWF0ZWQgdGVtcGxhdGUgZmlsZTogJHtwYXRofWApXG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgbmV3IE5vdGljZShgRXJyb3IgY3JlYXRpbmcgdGVtcGxhdGUgZmlsZSAke3BhdGh9YClcbiAgICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIGNyZWF0aW5nIHRlbXBsYXRlIGZpbGUgJHtwYXRofTpgLCBlKVxuICAgIH1cbiAgfVxuXG4gICAgZ2VuZXJhdGVDb3Vyc2VIb21lcGFnZVRlbXBsYXRlKCk6IHN0cmluZyB7XG4gICAgY29uc3QgZW5oYW5jZWRNZXRhZGF0YSA9IHRoaXMuc2V0dGluZ3MudXNlRW5oYW5jZWRNZXRhZGF0YTtcbiAgICBcbiAgICBpZiAoZW5oYW5jZWRNZXRhZGF0YSkge1xuICAgICAgcmV0dXJuIGA8JSpcbi8vIFR1Y2tlcnMgVG9vbHMgQ291cnNlIENyZWF0aW9uXG4vLyBGb3IgYmVzdCBleHBlcmllbmNlLCB1c2UgdGhlIHBsdWdpbiBjb21tYW5kOiBDb21tYW5kIFBhbGV0dGUgXHUyMTkyICdDcmVhdGUgTmV3IENvdXJzZSdcblxubGV0IGNvdXJzZU5hbWUgPSBcIk5ldyBDb3Vyc2VcIjtcbmxldCBjb3Vyc2VTZWFzb24gPSBcIkZhbGxcIjsgXG5sZXQgY291cnNlWWVhciA9IG5ldyBEYXRlKCkuZ2V0RnVsbFllYXIoKS50b1N0cmluZygpO1xubGV0IGNvdXJzZUlkID0gXCJDT1VSU0VfSURcIjtcblxuLy8gVHJ5IHRvIHVzZSBzeXN0ZW0gcHJvbXB0cywgd2l0aCBncmFjZWZ1bCBmYWxsYmFja1xudHJ5IHtcbiAgaWYgKHRwICYmIHRwLnN5c3RlbSAmJiB0cC5zeXN0ZW0ucHJvbXB0KSB7XG4gICAgY291cnNlTmFtZSA9IGF3YWl0IHRwLnN5c3RlbS5wcm9tcHQoXCJDb3Vyc2UgTmFtZSAoZS5nLiBTV08tMjUwIC0gQ291cnNlIFRpdGxlKVwiKSB8fCBjb3Vyc2VOYW1lO1xuICAgIGNvdXJzZUlkID0gY291cnNlTmFtZS5zcGxpdCgnIC0gJylbMF0gfHwgY291cnNlTmFtZS5yZXBsYWNlKC9bXmEtekEtWjAtOV0vZywgXCJfXCIpO1xuICAgIGNvdXJzZVNlYXNvbiA9IGF3YWl0IHRwLnN5c3RlbS5zdWdnZXN0ZXIoW1wiRmFsbFwiLFwiV2ludGVyXCIsXCJTcHJpbmdcIixcIlN1bW1lclwiXSxbXCJGYWxsXCIsXCJXaW50ZXJcIixcIlNwcmluZ1wiLFwiU3VtbWVyXCJdLCBcIlNlYXNvblwiKSB8fCBjb3Vyc2VTZWFzb247XG4gICAgY291cnNlWWVhciA9IGF3YWl0IHRwLnN5c3RlbS5wcm9tcHQoXCJZZWFyXCIpIHx8IGNvdXJzZVllYXI7XG4gIH0gZWxzZSB7XG4gICAgY29uc29sZS5sb2coXCJTeXN0ZW0gcHJvbXB0cyBub3QgYXZhaWxhYmxlLCB1c2UgdGhlIHBsdWdpbiBjb21tYW5kIGluc3RlYWRcIik7XG4gIH1cbn0gY2F0Y2ggKGUpIHtcbiAgY29uc29sZS5lcnJvcihcIkVycm9yIHdpdGggc3lzdGVtIHByb21wdHM6XCIsIGUubWVzc2FnZSk7XG4gIGNvbnNvbGUubG9nKFwiVXNlIHRoZSBwbHVnaW4gY29tbWFuZDogQ29tbWFuZCBQYWxldHRlIFx1MjE5MiAnQ3JlYXRlIE5ldyBDb3Vyc2UnXCIpO1xufVxuXG4vLyBNb3ZlIGZpbGUgdG8gYXBwcm9wcmlhdGUgbG9jYXRpb25cbmF3YWl0IHRwLmZpbGUubW92ZShcXGAvXFwke2NvdXJzZVllYXJ9L1xcJHtjb3Vyc2VTZWFzb259L1xcJHtjb3Vyc2VOYW1lfS9cXCR7Y291cnNlTmFtZX0ubWRcXGApO1xuXG4vLyBDcmVhdGUgYXR0YWNobWVudHMgZm9sZGVyXG50cnkge1xuICBhd2FpdCBhcHAudmF1bHQuY3JlYXRlRm9sZGVyKFxcYC9cXCR7Y291cnNlWWVhcn0vXFwke2NvdXJzZVNlYXNvbn0vXFwke2NvdXJzZU5hbWV9L0F0dGFjaG1lbnRzXFxgKTtcbn0gY2F0Y2ggKGUpIHtcbiAgLy8gRm9sZGVyIG1pZ2h0IGFscmVhZHkgZXhpc3Rcbn1cbiU+LS0tXG5jb3Vyc2VfaWQ6IDwlIGNvdXJzZUlkICU+XG5jb3Vyc2Vfc2Vhc29uOiA8JSBjb3Vyc2VTZWFzb24gJT5cbmNvdXJzZV95ZWFyOiA8JSBjb3Vyc2VZZWFyICU+XG5jcmVhdGVkOiA8JSB0cC5kYXRlLm5vdyhcIllZWVktTU0tRERbVF1ISDptbTpzc1pcIikgJT5cbmNvbnRlbnRUeXBlOiBDb3Vyc2VcbnRhZ3M6IFxuICAtIDwlIGNvdXJzZUlkICU+XG4gIC0gJHt0aGlzLnNldHRpbmdzLnNjaG9vbEFiYnJldmlhdGlvbn0vPCUgY291cnNlWWVhciAlPi88JSBjb3Vyc2VTZWFzb24gJT4vPCUgY291cnNlSWQgJT4vXG4gIC0gY291cnNlX2hvbWVcbiAgLSBlZHVjYXRpb25cbiAgLSAke3RoaXMuc2V0dGluZ3Muc2Nob29sTmFtZS5yZXBsYWNlKC9cXHMrL2csICdfJyl9XG5iYW5uZXI6XG5jc3NjbGFzc2VzOlxuICAtIHdoaXRlYm9hcmQtY291cnNlXG4tLS1cblxuIyA8JSBjb3Vyc2VOYW1lICU+XG5cbiMjIENvdXJzZSBJbmZvcm1hdGlvblxuKipDb3Vyc2UqKjogPCUgY291cnNlTmFtZSAlPlxuKipDb3Vyc2UgSUQqKjogPCUgY291cnNlSWQgJT5cbioqVGVybSoqOiA8JSBjb3Vyc2VTZWFzb24gJT4gPCUgY291cnNlWWVhciAlPlxuKipTY2hvb2wqKjogJHt0aGlzLnNldHRpbmdzLnNjaG9vbE5hbWV9XG5cbiMjIEluc3RydWN0b3JcbioqTmFtZSoqOiBcXGBJTlBVVFt0ZXh0Omluc3RydWN0b3JfbmFtZV1cXGBcbioqRW1haWwqKjogXFxgSU5QVVRbdGV4dDppbnN0cnVjdG9yX2VtYWlsXVxcYFxuKipPZmZpY2UgSG91cnMqKjogXFxgSU5QVVRbdGV4dDppbnN0cnVjdG9yX29mZmljZV9ob3Vyc11cXGBcbioqT2ZmaWNlIExvY2F0aW9uKio6IFxcYElOUFVUW3RleHQ6aW5zdHJ1Y3Rvcl9vZmZpY2VfbG9jYXRpb25dXFxgXG5cbiMjIENvdXJzZSBEZXNjcmlwdGlvblxuXFxgSU5QVVRbdGV4dEFyZWE6Y291cnNlX2Rlc2NyaXB0aW9uXVxcYFxuXG4jIyBMZWFybmluZyBPYmplY3RpdmVzXG5cXGBJTlBVVFt0ZXh0QXJlYTpsZWFybmluZ19vYmplY3RpdmVzXVxcYFxuXG4jIyBSZXF1aXJlZCBUZXh0c1xuXFxgXFxgXFxgbWV0YS1iaW5kLWpzLXZpZXdcbnt0ZXh0c30gYXMgdGV4dHNcbi0tLVxuY29uc3QgYXZhaWxhYmxlVGV4dHMgPSBhcHAudmF1bHQuZ2V0RmlsZXMoKS5maWx0ZXIoZmlsZSA9PiBmaWxlLmV4dGVuc2lvbiA9PSAncGRmJykubWFwKGYgPT4gZj8ubmFtZSlcbmNvbnN0IGVzY2FwZVJlZ2V4ID0gL1ssXFxgJygpXS9nO1xub3B0aW9ucyA9IGF2YWlsYWJsZVRleHRzLm1hcCh0ID0+IFxcYG9wdGlvbihbW1xcJHt0LnJlcGxhY2UoZXNjYXBlUmVnZXgsXCJcXCQxXCIpfV1dLCBcXCR7dC5yZXBsYWNlKGVzY2FwZVJlZ2V4LFwiXFwkMVwiKX0pXFxgIClcbmNvbnN0IHN0ciA9IFxcYFxcXFxcXGBJTlBVVFtpbmxpbmVMaXN0U3VnZ2VzdGVyKFxcJHtvcHRpb25zLmpvaW4oXCIsIFwiKX0pOnRleHRzXVxcXFxcXGBcXGBcbnJldHVybiBlbmdpbmUubWFya2Rvd24uY3JlYXRlKHN0cilcblxcYFxcYFxcYFxuXG4jIyBDb3Vyc2UgU2NoZWR1bGVcblxcYElOUFVUW3RleHRBcmVhOmNvdXJzZV9zY2hlZHVsZV1cXGBcblxuIyMgUmVzb3VyY2VzXG5cXGBJTlBVVFt0ZXh0QXJlYTpyZXNvdXJjZXNdXFxgXG5cbiMjIFZvY2FidWxhcnlcblxcYFxcYFxcYGRhdGF2aWV3anNcbmNvbnN0IHtwcm9jZXNzQ291cnNlVm9jYWJ1bGFyeX0gPSBhcHAucGx1Z2lucy5nZXRQbHVnaW4oXCJ0dWNrZXJzLXRvb2xzXCIpPy5kYXRhdmlld0Z1bmN0aW9ucyB8fCBhcHAuZ2xvYmFscy50dWNrZXJzVG9vbHMucHJvY2Vzc0NvdXJzZVZvY2FidWxhcnk7XG5wcm9jZXNzQ291cnNlVm9jYWJ1bGFyeShkdiwgJzwlIGNvdXJzZUlkICU+Jyk7XG5cXGBcXGBcXGBcblxuIyMgRHVlIERhdGVzXG5cXGBcXGBcXGBkYXRhdmlld2pzXG5jb25zdCB7cHJvY2Vzc0R1ZURhdGVzfSA9IGFwcC5wbHVnaW5zLmdldFBsdWdpbihcInR1Y2tlcnMtdG9vbHNcIik/LmRhdGF2aWV3RnVuY3Rpb25zIHx8IGFwcC5nbG9iYWxzLnR1Y2tlcnNUb29scy5wcm9jZXNzRHVlRGF0ZXM7XG5wcm9jZXNzRHVlRGF0ZXMoZHYsJyM8JSBjb3Vyc2VJZCAlPicpO1xuXFxgXFxgXFxgXG5cbiMjIENsYXNzIE1hdGVyaWFsc1xuXFxgSU5QVVRbdGV4dEFyZWE6Y2xhc3NfbWF0ZXJpYWxzXVxcYGA7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiBgLS0tXG5jb3Vyc2VfaWQ6IDwlIGNvdXJzZUlkICU+XG5jb3Vyc2VfbmFtZTogPCUgY291cnNlTmFtZSAlPlxuY291cnNlX3NlYXNvbjogPCUgY291cnNlU2Vhc29uICU+XG5jb3Vyc2VfeWVhcjogPCUgY291cnNlWWVhciAlPlxuY3JlYXRlZDogPCUgdHAuZGF0ZS5ub3coXCJZWVlZLU1NLUREW1RdSEg6bW06c3NaXCIpICU+XG5jb250ZW50VHlwZTogQ291cnNlXG50YWdzOlxuICAtIDwlIGNvdXJzZUlkICU+XG4gIC0gY291cnNlX2hvbWVcbiAgLSBlZHVjYXRpb25cbi0tLVxuXG4jIDwlIGNvdXJzZU5hbWUgJT5cblxuIyMgQ291cnNlIEluZm9ybWF0aW9uXG4qKkNvdXJzZSBJRCoqOiA8JSBjb3Vyc2VJZCAlPlxuKipUZXJtKio6IDwlIGNvdXJzZVNlYXNvbiAlPiA8JSBjb3Vyc2VZZWFyICU+XG4qKlNjaG9vbCoqOiAke3RoaXMuc2V0dGluZ3Muc2Nob29sTmFtZX1cblxuIyMgSW5zdHJ1Y3RvclxuKipOYW1lKio6IFxcYElOUFVUW3RleHQ6aW5zdHJ1Y3Rvcl9uYW1lXVxcYFxuKipFbWFpbCoqOiBcXGBJTlBVVFt0ZXh0Omluc3RydWN0b3JfZW1haWxdXFxgXG4qKk9mZmljZSBIb3VycyoqOiBcXGBJTlBVVFt0ZXh0Omluc3RydWN0b3Jfb2ZmaWNlX2hvdXJzXVxcYFxuKipPZmZpY2UgTG9jYXRpb24qKjogXFxgSU5QVVRbdGV4dDppbnN0cnVjdG9yX29mZmljZV9sb2NhdGlvbl1cXGBcblxuIyMgQ291cnNlIERlc2NyaXB0aW9uXG5cXGBJTlBVVFt0ZXh0QXJlYTpjb3Vyc2VfZGVzY3JpcHRpb25dXFxgXG5cbiMjIExlYXJuaW5nIE9iamVjdGl2ZXNcblxcYElOUFVUW3RleHRBcmVhOmxlYXJuaW5nX29iamVjdGl2ZXNdXFxgXG5cbiMjIFJlcXVpcmVkIFRleHRzXG5cXGBcXGBcXGBtZXRhLWJpbmQtanMtdmlld1xue3RleHRzfSBhcyB0ZXh0c1xuLS0tXG5jb25zdCBhdmFpbGFibGVUZXh0cyA9IGFwcC52YXVsdC5nZXRGaWxlcygpLmZpbHRlcihmaWxlID0+IGZpbGUuZXh0ZW5zaW9uID09ICdwZGYnKS5tYXAoZiA9PiBmPy5uYW1lKVxuY29uc3QgZXNjYXBlUmVnZXggPSAvWyxcXGAnKCldL2c7XG5vcHRpb25zID0gYXZhaWxhYmxlVGV4dHMubWFwKHQgPT4gXFxgb3B0aW9uKFtbXFwke3QucmVwbGFjZShlc2NhcGVSZWdleCxcIlxcJDFcIil9XV0sIFxcJHt0LnJlcGxhY2UoZXNjYXBlUmVnZXgsXCJcXCQxXCIpfSlcXGAgKVxuY29uc3Qgc3RyID0gXFxgXFxcXFxcYElOUFVUW2lubGluZUxpc3RTdWdnZXN0ZXIoXFwke29wdGlvbnMuam9pbihcIiwgXCIpfSk6dGV4dHNdXFxcXFxcYFxcYFxucmV0dXJuIGVuZ2luZS5tYXJrZG93bi5jcmVhdGUoc3RyKVxuXFxgXFxgXFxgXG5cbiMjIENvdXJzZSBTY2hlZHVsZVxuXFxgSU5QVVRbdGV4dEFyZWE6Y291cnNlX3NjaGVkdWxlXVxcYFxuXG4jIyBBc3NpZ25tZW50c1xuXFxgSU5QVVRbdGV4dEFyZWE6YXNzaWdubWVudHNdXFxgXG5cbiMjIFJlc291cmNlc1xuXFxgSU5QVVRbdGV4dEFyZWE6cmVzb3VyY2VzXVxcYFxuXG4jIyBWb2NhYnVsYXJ5XG5cXGBcXGBcXGBkYXRhdmlld2pzXG5jb25zdCB7cHJvY2Vzc0NvdXJzZVZvY2FidWxhcnl9ID0gYXBwLnBsdWdpbnMuZ2V0UGx1Z2luKFwidHVja2Vycy10b29sc1wiKT8uZGF0YXZpZXdGdW5jdGlvbnMgfHwgYXBwLmdsb2JhbHMudHVja2Vyc1Rvb2xzLnByb2Nlc3NDb3Vyc2VWb2NhYnVsYXJ5O1xucHJvY2Vzc0NvdXJzZVZvY2FidWxhcnkoZHYsICc8JSBjb3Vyc2VJZCAlPicpO1xuXFxgXFxgXFxgXG5cbiMjIER1ZSBEYXRlc1xuXFxgXFxgXFxgZGF0YXZpZXdqc1xuY29uc3Qge3Byb2Nlc3NEdWVEYXRlc30gPSBhcHAucGx1Z2lucy5nZXRQbHVnaW4oXCJ0dWNrZXJzLXRvb2xzXCIpPy5kYXRhdmlld0Z1bmN0aW9ucyB8fCBhcHAuZ2xvYmFscy50dWNrZXJzVG9vbHMucHJvY2Vzc0R1ZURhdGVzO1xucHJvY2Vzc0R1ZURhdGVzKGR2LCcjPCUgY291cnNlSWQgJT4nKTtcblxcYFxcYFxcYFxuXG4jIyBDbGFzcyBNYXRlcmlhbHNcblxcYElOUFVUW3RleHRBcmVhOmNsYXNzX21hdGVyaWFsc11cXGBgO1xuICAgIH1cbiAgfVxuXG4gIGdlbmVyYXRlQ291cnNlSW5kZXhUZW1wbGF0ZSgpOiBzdHJpbmcge1xuICAgIHJldHVybiBgLS0tXG5jb250ZW50X3R5cGU6IGNvdXJzZV9pbmRleFxudGFnczpcbiAgLSBpbmRleFxuLS0tXG5cbiMgQ291cnNlIEluZGV4XG5cbiMjIE1vZHVsZXNcblxuIyMgQ2hhcHRlcnNcblxuIyMgQXNzaWdubWVudHNcblxuIyMgUmVzb3VyY2VzXG5cbiMjIFZvY2FidWxhcnlcblxuIyMgRHVlIERhdGVzYFxuICB9XG5cbiAgZ2VuZXJhdGVNb2R1bGVUZW1wbGF0ZSgpOiBzdHJpbmcge1xuICAgIHJldHVybiBgPCUqXG5jb25zdCB7IHNlYXNvbiwgbW9kdWxlTnVtYmVyLCB3ZWVrTnVtYmVyLCBjb3Vyc2UsIGNvdXJzZUlkLCBkaXNjaXBsaW5lLCBkYXlPZldlZWsgfSA9IGF3YWl0IHRwLmFwcC5nbG9iYWxzLnR1Y2tlcnNUb29scy5uZXdfbW9kdWxlKGFwcCwgdHAsIFwiMjAyNVwiKTtcbmxldCB0aXRsZSA9IGNvdXJzZUlkXG5pZiAobW9kdWxlTnVtYmVyICYmIHdlZWtOdW1iZXIpIHsgdGl0bGUgPSBcIk1cIiArIG1vZHVsZU51bWJlciArIFwiL1dcIiArIHdlZWtOdW1iZXIgfVxuZWxzZSBpZiAobW9kdWxlTnVtYmVyKSB7IHRpdGxlID0gXCJNXCIgKyBtb2R1bGVOdW1iZXIgfSBcbmVsc2UgaWYgKHdlZWtOdW1iZXIpIHsgdGl0bGUgPSBcIldcIiArIHdlZWtOdW1iZXIgfVxuXG4vLyBNb3ZlIGZpbGUgdG8gYXBwcm9wcmlhdGUgY291cnNlIGxvY2F0aW9uIGFmdGVyIGNyZWF0aW9uXG4vLyBFeHRyYWN0IGNvdXJzZSBpbmZvcm1hdGlvbiBmcm9tIHRoZSBzZWxlY3RlZCBjb3Vyc2UgZmlsZSBhbmQgY3JlYXRlIHByb3BlciBuZXN0ZWQgZGlyZWN0b3J5IHN0cnVjdHVyZVxubGV0IG1vZHVsZVBhdGggPSBcIlwiO1xuaWYgKHR5cGVvZiBjb3Vyc2UgPT09ICdvYmplY3QnICYmIGNvdXJzZSAhPT0gbnVsbCAmJiBjb3Vyc2UucGF0aCkge1xuICAvLyBHZXQgdGhlIGRpcmVjdG9yeSBvZiB0aGUgY291cnNlIGZpbGUgKHNob3VsZCBiZSBZZWFyL1NlYXNvbi9Db3Vyc2VOYW1lLylcbiAgY29uc3QgY291cnNlRGlyID0gY291cnNlLnBhdGguc3Vic3RyaW5nKDAsIGNvdXJzZS5wYXRoLmxhc3RJbmRleE9mKCcvJykpO1xuICBjb25zdCBjb3Vyc2VOYW1lID0gY291cnNlLmJhc2VuYW1lO1xuICBcbiAgLy8gQ3JlYXRlIHByb3BlciBuZXN0ZWQgZGlyZWN0b3J5IHN0cnVjdHVyZSBiYXNlZCBvbiBtb2R1bGUvd2VlayBudW1iZXJzXG4gIGlmIChtb2R1bGVOdW1iZXIgJiYgd2Vla051bWJlcikge1xuICAgIC8vIE1vZHVsZSBhbmQgV2VlayBjb21iaW5hdGlvblxuICAgIG1vZHVsZVBhdGggPSBjb3Vyc2VEaXIgKyBcIi9cIiArIGNvdXJzZUlkICsgXCIgLSBNb2R1bGUgXCIgKyBtb2R1bGVOdW1iZXIgKyBcIi9cIiArIGNvdXJzZUlkICsgXCIgLSBXZWVrIFwiICsgd2Vla051bWJlciArIFwiL1wiICsgY291cnNlSWQgKyBcIi5cIiArIG1vZHVsZU51bWJlciArIFwiLlwiICsgd2Vla051bWJlciArIFwiIC0gXCIgKyBkYXlPZldlZWs7XG4gIH0gZWxzZSBpZiAobW9kdWxlTnVtYmVyKSB7XG4gICAgLy8gTW9kdWxlIG9ubHlcbiAgICBtb2R1bGVQYXRoID0gY291cnNlRGlyICsgXCIvXCIgKyBjb3Vyc2VJZCArIFwiIC0gTW9kdWxlIFwiICsgbW9kdWxlTnVtYmVyICsgXCIvXCIgKyBjb3Vyc2VJZCArIFwiLlwiICsgbW9kdWxlTnVtYmVyICsgXCIgLSBcIiArIGRheU9mV2VlaztcbiAgfSBlbHNlIGlmICh3ZWVrTnVtYmVyKSB7XG4gICAgLy8gV2VlayBvbmx5XG4gICAgbW9kdWxlUGF0aCA9IGNvdXJzZURpciArIFwiL1wiICsgY291cnNlSWQgKyBcIiAtIFdlZWsgXCIgKyB3ZWVrTnVtYmVyICsgXCIvXCIgKyBjb3Vyc2VJZCArIFwiLlwiICsgd2Vla051bWJlciArIFwiIFwiICsgZGF5T2ZXZWVrO1xuICB9IGVsc2Uge1xuICAgIC8vIE5laXRoZXIgbW9kdWxlIG5vciB3ZWVrXG4gICAgbW9kdWxlUGF0aCA9IGNvdXJzZURpciArIFwiL1wiICsgY291cnNlSWQgKyBcIiAtIFwiICsgZGF5T2ZXZWVrO1xuICB9XG59IGVsc2Uge1xuICAvLyBGYWxsYmFjayAtIHB1dCBpbiBNb2R1bGVzIGRpcmVjdG9yeSB3aXRoIG5lc3RlZCBzdHJ1Y3R1cmVcbiAgaWYgKG1vZHVsZU51bWJlciAmJiB3ZWVrTnVtYmVyKSB7XG4gICAgbW9kdWxlUGF0aCA9IFwiTW9kdWxlcy9cIiArIGNvdXJzZUlkICsgXCIgLSBNb2R1bGUgXCIgKyBtb2R1bGVOdW1iZXIgKyBcIi9cIiArIGNvdXJzZUlkICsgXCIgLSBXZWVrIFwiICsgd2Vla051bWJlciArIFwiL1wiICsgY291cnNlSWQgKyBcIi5cIiArIG1vZHVsZU51bWJlciArIFwiLlwiICsgd2Vla051bWJlciArIFwiIC0gXCIgKyBkYXlPZldlZWs7XG4gIH0gZWxzZSBpZiAobW9kdWxlTnVtYmVyKSB7XG4gICAgbW9kdWxlUGF0aCA9IFwiTW9kdWxlcy9cIiArIGNvdXJzZUlkICsgXCIgLSBNb2R1bGUgXCIgKyBtb2R1bGVOdW1iZXIgKyBcIi9cIiArIGNvdXJzZUlkICsgXCIuXCIgKyBtb2R1bGVOdW1iZXIgKyBcIiAtIFwiICsgZGF5T2ZXZWVrO1xuICB9IGVsc2UgaWYgKHdlZWtOdW1iZXIpIHtcbiAgICBtb2R1bGVQYXRoID0gXCJNb2R1bGVzL1wiICsgY291cnNlSWQgKyBcIiAtIFdlZWsgXCIgKyB3ZWVrTnVtYmVyICsgXCIvXCIgKyBjb3Vyc2VJZCArIFwiLlwiICsgd2Vla051bWJlciArIFwiIFwiICsgZGF5T2ZXZWVrO1xuICB9IGVsc2Uge1xuICAgIG1vZHVsZVBhdGggPSBcIk1vZHVsZXMvXCIgKyBjb3Vyc2VJZCArIFwiIC0gXCIgKyBkYXlPZldlZWs7XG4gIH1cbn1cblxuLy8gV2UnbGwgbW92ZSB0aGUgZmlsZSBhZnRlciBjcmVhdGlvbiB1c2luZyB0aGUgbW9kdWxlUGF0aCB2YXJpYWJsZVxuJT4tLS1cbiR7XG4gIHRoaXMuc2V0dGluZ3MudXNlRW5oYW5jZWRNZXRhZGF0YVxuICAgID8gYGNvdXJzZV9pZDogPCUgY291cnNlSWQgJT5cbm1vZHVsZV9udW1iZXI6IDwlIG1vZHVsZU51bWJlciAlPlxud2Vla19udW1iZXI6IDwlIHdlZWtOdW1iZXIgJT5cbmNsYXNzX2RheTogPCUgZGF5T2ZXZWVrICU+XG5jb250ZW50X3R5cGU6IG1vZHVsZVxucGFyZW50X2NvdXJzZTogXCJbWzwlIGNvdXJzZSAlPl1dXCJgXG4gICAgOiBgY291cnNlX2lkOiA8JSBjb3Vyc2VJZCAlPlxubW9kdWxlX251bWJlcjogPCUgbW9kdWxlTnVtYmVyICU+XG53ZWVrX251bWJlcjogPCUgd2Vla051bWJlciAlPlxuY2xhc3NfZGF5OiA8JSBkYXlPZldlZWsgJT5gXG59XG5jcmVhdGVkOiA8JSB0cC5kYXRlLm5vdyhcIllZWVktTU0tRERbVF1ISDptbTpzc1pcIikgJT5cbnRhZ3M6XG4gIC0gZWR1Y2F0aW9uXG4gIC0gPCUgY291cnNlSWQgJT5cbiAgLSBtb2R1bGVcbi0tLVxuXG5cbiMgW1s8JSBjb3Vyc2UgJT58PCUgY291cnNlSWQgJT4gPCUgdGl0bGUgJT4gPCUgZGF5T2ZXZWVrICU+XV1cblxuIyMgRHVlIERhdGVzXG58IERhdGUgfCBBc3NpZ25tZW50IHxcbnwgLS0tLSB8IC0tLS0tLS0tLS0gfFxufCAgICAgIHwgICAgICAgICAgICB8XG58ICAgICAgfCAgICAgICAgICAgIHxcbnwgICAgICB8ICAgICAgICAgICAgfFxuXG5cXGBcXGBcXGBkYXRhdmlld2pzXG5jb25zdCB7cHJvY2Vzc0R1ZURhdGVzfSA9IGFwcC5wbHVnaW5zLmdldFBsdWdpbihcInR1Y2tlcnMtdG9vbHNcIik/LmRhdGF2aWV3RnVuY3Rpb25zIHx8IGFwcC5nbG9iYWxzLnR1Y2tlcnNUb29scy5wcm9jZXNzRHVlRGF0ZXM7XG5wcm9jZXNzRHVlRGF0ZXMoZHYsJyM8JSBjb3Vyc2VJZCAlPicpO1xuXFxgXFxgXFxgXG5cbiMjIExlYXJuaW5nIE9iamVjdGl2ZXNcblxuIyMgUmVhZGluZyBBc3NpZ25tZW50XG5cbiMjIExlY3R1cmUgTm90ZXNcblxuIyMgRGlzY3Vzc2lvbiBRdWVzdGlvbnNcblxuIyMgVm9jYWJ1bGFyeVxuXG5cXGBcXGBcXGBkYXRhdmlld2pzXG5jb25zdCB7cHJvY2Vzc0NvdXJzZVZvY2FidWxhcnl9ID0gYXBwLnBsdWdpbnMuZ2V0UGx1Z2luKFwidHVja2Vycy10b29sc1wiKT8uZGF0YXZpZXdGdW5jdGlvbnMgfHwgYXBwLmdsb2JhbHMudHVja2Vyc1Rvb2xzLnByb2Nlc3NDb3Vyc2VWb2NhYnVsYXJ5O1xucHJvY2Vzc0NvdXJzZVZvY2FidWxhcnkoZHYsICc8JSBjb3Vyc2VJZCAlPicpO1xuXFxgXFxgXFxgXG5cbiMjIEFkZGl0aW9uYWwgUmVzb3VyY2VzXG5cbjwlKlxuLy8gTW92ZSBmaWxlIHRvIGFwcHJvcHJpYXRlIGxvY2F0aW9uIGFmdGVyIGNvbnRlbnQgZ2VuZXJhdGlvblxuaWYgKG1vZHVsZVBhdGgpIHtcbiAgdHJ5IHtcbiAgICBhd2FpdCB0cC5maWxlLm1vdmUobW9kdWxlUGF0aCArIFwiLm1kXCIpO1xuICB9IGNhdGNoIChlKSB7XG4gICAgY29uc29sZS5lcnJvcihcIkVycm9yIG1vdmluZyBtb2R1bGUgZmlsZTpcIiwgZSk7XG4gIH1cbn1cbiU+XG5gO1xuICB9XG5cbiAgZ2VuZXJhdGVDaGFwdGVyVGVtcGxhdGUoKTogc3RyaW5nIHtcbiAgICByZXR1cm4gYDwlKlxuY29uc3QgeyBjaGFwdGVyTnVtYmVyLCBjb3Vyc2UsIGNvdXJzZUlkLCBkaXNjaXBsaW5lLCB0ZXh0fSA9IGF3YWl0IHRwLmFwcC5nbG9iYWxzLnR1Y2tlcnNUb29scy5uZXdfY2hhcHRlcih0cCk7XG4lPi0tLVxuJHtcbiAgdGhpcy5zZXR0aW5ncy51c2VFbmhhbmNlZE1ldGFkYXRhXG4gICAgPyBgY291cnNlX2lkOiA8JSBjb3Vyc2VJZCAlPlxuY2hhcHRlcl9udW1iZXI6IDwlIGNoYXB0ZXJOdW1iZXIgJT5cbmNvbnRlbnRfdHlwZTogY2hhcHRlclxucGFyZW50X2NvdXJzZTogXCJbWzwlIGNvdXJzZSAlPl1dXCJcbnRleHRfcmVmZXJlbmNlOiBcIltbPCUgdGV4dCAlPl1dXCJgXG4gICAgOiBgY291cnNlX2lkOiA8JSBjb3Vyc2VJZCAlPlxuY2hhcHRlcl9udW1iZXI6IDwlIGNoYXB0ZXJOdW1iZXIgJT5gXG59XG5jcmVhdGVkOiA8JSB0cC5kYXRlLm5vdyhcIllZWVktTU0tRERbVF1ISDptbTpzc1pcIikgJT5cbnRhZ3M6XG4gIC0gZWR1Y2F0aW9uXG4gIC0gPCUgY291cnNlSWQgJT5cbiAgLSBjaGFwdGVyXG4tLS1cblxuXG4jIFtbPCUgdGV4dCAlPl1dIC0gQ2hhcHRlciA8JSBjaGFwdGVyTnVtYmVyICU+XG5cbiMjIFJlYWRpbmcgQXNzaWdubWVudFxuLSAqKlRleHRib29rKio6IFtbPCUgdGV4dCAlPl1dXG4tICoqQ2hhcHRlcioqOiA8JSBjaGFwdGVyTnVtYmVyICU+XG4tICoqUGFnZXMqKjogXG5cbiMjIFN1bW1hcnlcblxuIyMgS2V5IENvbmNlcHRzXG5cbiMjIFZvY2FidWxhcnlcbi0gXG5cbiMjIE5vdGVzXG5cbiMjIERpc2N1c3Npb24gUXVlc3Rpb25zXG5cbiMjIEZ1cnRoZXIgUmVhZGluZ2BcbiAgfVxuXG4gIGdlbmVyYXRlQXNzaWdubWVudFRlbXBsYXRlKCk6IHN0cmluZyB7XG4gICAgcmV0dXJuIGAtLS1cbiR7XG4gIHRoaXMuc2V0dGluZ3MudXNlRW5oYW5jZWRNZXRhZGF0YVxuICAgID8gYGNvdXJzZV9pZDogPCUgY291cnNlSWQgJT5cbmFzc2lnbm1lbnRfdHlwZTogPCUgYXNzaWdubWVudFR5cGUgJT5cbmR1ZV9kYXRlOiA8JSBkdWVEYXRlICU+XG5wb2ludHM6IDwlIHBvaW50cyAlPlxuY29udGVudF90eXBlOiBhc3NpZ25tZW50XG5wYXJlbnRfY291cnNlOiBcIltbPCUgY291cnNlICU+XV1cImBcbiAgICA6IGBjb3Vyc2VfaWQ6IDwlIGNvdXJzZUlkICU+XG5hc3NpZ25tZW50X3R5cGU6IDwlIGFzc2lnbm1lbnRUeXBlICU+XG5kdWVfZGF0ZTogPCUgZHVlRGF0ZSAlPmBcbn1cbmNyZWF0ZWQ6IDwlIHRwLmRhdGUubm93KFwiWVlZWS1NTS1ERFtUXUhIOm1tOnNzWlwiKSAlPlxuc3RhdHVzOiBwZW5kaW5nXG50YWdzOlxuICAtIGVkdWNhdGlvblxuICAtIDwlIGNvdXJzZUlkICU+XG4gIC0gYXNzaWdubWVudFxuLS0tXG5cbiMgPCUgYXNzaWdubWVudE5hbWUgJT4gLSA8JSBjb3Vyc2VJZCAlPlxuXG4jIyBEZXNjcmlwdGlvblxuXG4jIyBJbnN0cnVjdGlvbnNcblxuIyMgRHVlIERhdGVcbioqQXNzaWduZWQqKjogPCUgdHAuZGF0ZS5ub3coXCJZWVlZLU1NLUREXCIpICU+XG4qKkR1ZSoqOiA8JSBkdWVEYXRlICU+XG5cbiMjIFN1Ym1pc3Npb25cblxuIyMgR3JhZGluZyBDcml0ZXJpYVxuXG4jIyBSZXNvdXJjZXNcblxuIyBEdWUgRGF0ZXNcbnwgPCUgZHVlRGF0ZSAlPiB8IDwlIGFzc2lnbm1lbnROYW1lICU+IHwgcGVuZGluZyB8XG5gXG4gIH1cblxuICBnZW5lcmF0ZURhaWx5Tm90ZVRlbXBsYXRlKCk6IHN0cmluZyB7XG4gICAgcmV0dXJuIGAtLS1cbmNvbnRlbnRfdHlwZTogZGFpbHlfbm90ZVxuZGF0ZTogPCUgdHAuZGF0ZS5ub3coXCJZWVlZLU1NLUREXCIpICU+XG50YWdzOlxuICAtIGRhaWx5XG4gIC0gPCUgdHAuZGF0ZS5ub3coXCJZWVlZXCIpICU+XG4gIC0gPCUgdHAuZGF0ZS5ub3coXCJNTVwiKSAlPlxuICAtIDwlIHRwLmRhdGUubm93KFwiRERcIikgJT5cbi0tLVxuXG4jIDwlIHRwLmRhdGUubm93KFwiWVlZWS1NTS1ERCAtIGRkZGRcIikgJT5cblxuPDwgW1s8JSB0cC5kYXRlLnllc3RlcmRheShcIllZWVktTU0tRERcIikgJT5dXSB8IFtbPCUgdHAuZGF0ZS50b21vcnJvdyhcIllZWVktTU0tRERcIikgJT5dXSA+PlxuXG4jIyBUb2RheSdzIEZvY3VzXG5cbiMjIENvdXJzZXMgV29ya2VkIE9uXG4tIFxuXG4jIyBUYXNrcyBDb21wbGV0ZWRcbi0gWyBdIFxuXG4jIyBWb2NhYnVsYXJ5IFJldmlld2VkXG4tIFxuXG4jIyBBc3NpZ25tZW50cyBEdWVcbi0gXG5cbiMjIExlYXJuaW5nIEFjaGlldmVtZW50c1xuXG4jIyBDaGFsbGVuZ2VzXG5cbiMjIFRvbW9ycm93J3MgUGxhblxuXG4jIyBSZWZsZWN0aW9uYFxuICB9XG5cbiAgZ2VuZXJhdGVWb2NhYnVsYXJ5VGVtcGxhdGUoKTogc3RyaW5nIHtcbiAgICByZXR1cm4gYCMjIDwlIHRlcm0gJT5cbioqVGVybSoqOiA8JSB0ZXJtICU+XG4qKlBhcnQgb2YgU3BlZWNoKio6IFxuKipEZWZpbml0aW9uKio6IFxuKipDb250ZXh0Kio6IFxuKipFeGFtcGxlcyoqOiBcbioqUmVsYXRlZCBUZXJtcyoqOiBcbioqU2VlIEFsc28qKjpgXG4gIH1cblxuICBnZW5lcmF0ZUR1ZURhdGVUZW1wbGF0ZSgpOiBzdHJpbmcge1xuICAgIHJldHVybiBgfCA8JSBkdWVEYXRlICU+IHwgPCUgYXNzaWdubWVudCAlPiB8IDwlIHN0YXR1cyAlPiB8YFxuICB9XG5cbiAgYXN5bmMgY3JlYXRlUkVBRE1FKGJhc2VQYXRoOiBzdHJpbmcpIHtcbiAgICBjb25zdCByZWFkbWVDb250ZW50ID0gYCMgVHVja2VycyBUb29scyBUZW1wbGF0ZXNcblxuVGhpcyBkaXJlY3RvcnkgY29udGFpbnMgdGVtcGxhdGVzIGZvciB0aGUgVHVja2VycyBUb29scyBPYnNpZGlhbiBwbHVnaW4uXG5cbiMjIFRlbXBsYXRlIENhdGVnb3JpZXNcblxuLSAqKkNvdXJzZXMqKjogVGVtcGxhdGVzIGZvciBjcmVhdGluZyBhbmQgb3JnYW5pemluZyBjb3Vyc2VzXG4tICoqTW9kdWxlcyoqOiBUZW1wbGF0ZXMgZm9yIGNvdXJzZSBtb2R1bGVzXG4tICoqQ2hhcHRlcnMqKjogVGVtcGxhdGVzIGZvciBjaGFwdGVyIG5vdGVzXG4tICoqQXNzaWdubWVudHMqKjogVGVtcGxhdGVzIGZvciBhc3NpZ25tZW50c1xuLSAqKkRhaWx5Kio6IFRlbXBsYXRlcyBmb3IgZGFpbHkgbm90ZXNcbi0gKipVdGlsaXRpZXMqKjogSGVscGVyIHRlbXBsYXRlc1xuXG4jIyBVc2FnZVxuXG5UaGVzZSB0ZW1wbGF0ZXMgYXJlIGRlc2lnbmVkIHRvIHdvcmsgd2l0aCB0aGUgVHVja2VycyBUb29scyBwbHVnaW4uIFRvIHVzZSB0aGVtOlxuXG4xLiBJbnN0YWxsIHRoZSBUdWNrZXJzIFRvb2xzIHBsdWdpblxuMi4gQ29uZmlndXJlIHlvdXIgc2V0dGluZ3MgaW4gdGhlIHBsdWdpbiBzZXR0aW5ncyB0YWJcbjMuIFVzZSB0aGUgXCJJbnNlcnQgVGVtcGxhdGVcIiBjb21tYW5kIHRvIGFwcGx5IHRoZXNlIHRlbXBsYXRlcyB0byBuZXcgbm90ZXNcblxuIyMgQ3VzdG9taXphdGlvblxuXG5GZWVsIGZyZWUgdG8gY3VzdG9taXplIHRoZXNlIHRlbXBsYXRlcyB0byBzdWl0IHlvdXIgbmVlZHMuIFRoZSBwbHVnaW4gd2lsbCBub3Qgb3ZlcndyaXRlIHlvdXIgY2hhbmdlcyB3aGVuIHVwZGF0aW5nIHRlbXBsYXRlcy5gXG5cbiAgICBhd2FpdCB0aGlzLndyaXRlVGVtcGxhdGVGaWxlKGAke2Jhc2VQYXRofS9SRUFETUUubWRgLCByZWFkbWVDb250ZW50KVxuICB9XG59XG4iLCAiLy8gQ291cnNlIGNyZWF0aW9uIHdpemFyZCBmb3IgVHVja2VycyBUb29scyBwbHVnaW5cblxuaW1wb3J0IHsgQXBwLCBOb3RpY2UsIFRGaWxlIH0gZnJvbSBcIm9ic2lkaWFuXCJcbmltcG9ydCB7IFR1Y2tlcnNUb29sc1NldHRpbmdzIH0gZnJvbSBcIi4vc2V0dGluZ3NcIlxuaW1wb3J0IHsgc2x1Z2lmeSB9IGZyb20gXCIuL3V0aWxzXCJcbmltcG9ydCB7IElucHV0TW9kYWwsIFN1Z2dlc3Rlck1vZGFsIH0gZnJvbSBcIi4vaW5wdXRNb2RhbFwiXG5pbXBvcnQgeyBUZW1wbGF0ZU1hbmFnZXIgfSBmcm9tIFwiLi90ZW1wbGF0ZU1hbmFnZXJcIlxuXG5leHBvcnQgY2xhc3MgQ291cnNlQ3JlYXRpb25XaXphcmQge1xuICBhcHA6IEFwcFxuICBzZXR0aW5nczogVHVja2Vyc1Rvb2xzU2V0dGluZ3NcblxuICBjb25zdHJ1Y3RvcihhcHA6IEFwcCwgc2V0dGluZ3M6IFR1Y2tlcnNUb29sc1NldHRpbmdzKSB7XG4gICAgdGhpcy5hcHAgPSBhcHBcbiAgICB0aGlzLnNldHRpbmdzID0gc2V0dGluZ3NcbiAgfVxuXG4gIGFzeW5jIGNyZWF0ZUNvdXJzZUhvbWVwYWdlKCkge1xuICAgIHRyeSB7XG4gICAgICAvLyBQcm9tcHQgdXNlciBmb3IgY291cnNlIGRldGFpbHNcbiAgICAgIGNvbnN0IGNvdXJzZURldGFpbHMgPSBhd2FpdCB0aGlzLnByb21wdENvdXJzZURldGFpbHMoKVxuXG4gICAgICBpZiAoIWNvdXJzZURldGFpbHMpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlIC8vIFVzZXIgY2FuY2VsbGVkXG4gICAgICB9XG5cbiAgICAgIC8vIENyZWF0ZSBmb2xkZXIgc3RydWN0dXJlXG4gICAgICBjb25zdCBmb2xkZXJQYXRoID0gYXdhaXQgdGhpcy5jcmVhdGVDb3Vyc2VGb2xkZXJTdHJ1Y3R1cmUoY291cnNlRGV0YWlscylcblxuICAgICAgLy8gR2VuZXJhdGUgY291cnNlIGhvbWVwYWdlIG5vdGVcbiAgICAgIGF3YWl0IHRoaXMuY3JlYXRlQ291cnNlSG9tZXBhZ2VOb3RlKGNvdXJzZURldGFpbHMsIGZvbGRlclBhdGgpXG5cbiAgICAgIC8vIENyZWF0ZSBhdHRhY2htZW50cyBmb2xkZXJcbiAgICAgIGF3YWl0IHRoaXMuY3JlYXRlQXR0YWNobWVudHNGb2xkZXIoZm9sZGVyUGF0aClcblxuICAgICAgbmV3IE5vdGljZShgQ291cnNlIFwiJHtjb3Vyc2VEZXRhaWxzLmNvdXJzZU5hbWV9XCIgY3JlYXRlZCBzdWNjZXNzZnVsbHkhYClcbiAgICAgIGNvbnNvbGUubG9nKFxuICAgICAgICBgQ291cnNlIGNyZWF0ZWQ6ICR7Y291cnNlRGV0YWlscy5jb3Vyc2VOYW1lfSBhdCAke2ZvbGRlclBhdGh9YFxuICAgICAgKVxuXG4gICAgICByZXR1cm4gdHJ1ZVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgY3JlYXRpbmcgY291cnNlOlwiLCBlcnJvcilcbiAgICAgIG5ldyBOb3RpY2UoYEVycm9yIGNyZWF0aW5nIGNvdXJzZTogJHtlcnJvci5tZXNzYWdlfWApXG4gICAgICByZXR1cm4gZmFsc2VcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIHByb21wdENvdXJzZURldGFpbHMoKTogUHJvbWlzZTx7XG4gICAgY291cnNlTmFtZTogc3RyaW5nXG4gICAgY291cnNlU2Vhc29uOiBzdHJpbmdcbiAgICBjb3Vyc2VZZWFyOiBzdHJpbmdcbiAgICBjb3Vyc2VJZDogc3RyaW5nXG4gIH0gfCBudWxsPiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGNvdXJzZU5hbWUgPSBhd2FpdCB0aGlzLnByb21wdFdpdGhWYWxpZGF0aW9uKFxuICAgICAgICBcIkNvdXJzZSBOYW1lXCIsXG4gICAgICAgIFwiRW50ZXIgY291cnNlIG5hbWUgKGUuZy4sIFBTSS0xMDEgLSBJbnRybyB0byBQc3ljaG9sb2d5KVwiLFxuICAgICAgICAodmFsdWUpID0+IHZhbHVlLnRyaW0oKS5sZW5ndGggPiAwLFxuICAgICAgICBcIkNvdXJzZSBuYW1lIGlzIHJlcXVpcmVkXCJcbiAgICAgIClcblxuICAgICAgaWYgKCFjb3Vyc2VOYW1lKSByZXR1cm4gbnVsbFxuXG4gICAgICBjb25zdCBjb3Vyc2VTZWFzb24gPSBhd2FpdCB0aGlzLnByb21wdFdpdGhPcHRpb25zKFxuICAgICAgICBcIlNlYXNvblwiLFxuICAgICAgICBcIlNlbGVjdCBzZW1lc3Rlci9zZWFzb25cIixcbiAgICAgICAgW1wiRmFsbFwiLCBcIldpbnRlclwiLCBcIlNwcmluZ1wiLCBcIlN1bW1lclwiXVxuICAgICAgKVxuXG4gICAgICBpZiAoIWNvdXJzZVNlYXNvbikgcmV0dXJuIG51bGxcblxuICAgICAgY29uc3QgY291cnNlWWVhciA9IGF3YWl0IHRoaXMucHJvbXB0V2l0aFZhbGlkYXRpb24oXG4gICAgICAgIFwiWWVhclwiLFxuICAgICAgICBcIkVudGVyIGFjYWRlbWljIHllYXIgKGUuZy4sIDIwMjUpXCIsXG4gICAgICAgICh2YWx1ZSkgPT4gL15cXGR7NH0kLy50ZXN0KHZhbHVlLnRyaW0oKSksXG4gICAgICAgIFwiUGxlYXNlIGVudGVyIGEgdmFsaWQgNC1kaWdpdCB5ZWFyXCJcbiAgICAgIClcblxuICAgICAgaWYgKCFjb3Vyc2VZZWFyKSByZXR1cm4gbnVsbFxuXG4gICAgICBjb25zdCBjb3Vyc2VJZCA9IGNvdXJzZU5hbWUuc3BsaXQoXCIgLSBcIilbMF0/LnRyaW0oKSB8fCBzbHVnaWZ5KGNvdXJzZU5hbWUpXG5cbiAgICAgIHJldHVybiB7XG4gICAgICAgIGNvdXJzZU5hbWUsXG4gICAgICAgIGNvdXJzZVNlYXNvbixcbiAgICAgICAgY291cnNlWWVhcixcbiAgICAgICAgY291cnNlSWRcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHByb21wdGluZyBmb3IgY291cnNlIGRldGFpbHM6XCIsIGVycm9yKVxuICAgICAgcmV0dXJuIG51bGxcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIHByb21wdFdpdGhWYWxpZGF0aW9uKFxuICAgIHRpdGxlOiBzdHJpbmcsXG4gICAgbWVzc2FnZTogc3RyaW5nLFxuICAgIHZhbGlkYXRvcjogKHZhbHVlOiBzdHJpbmcpID0+IGJvb2xlYW4sXG4gICAgZXJyb3JNZXNzYWdlOiBzdHJpbmdcbiAgKTogUHJvbWlzZTxzdHJpbmcgfCBudWxsPiB7XG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG4gICAgICBjb25zdCBtb2RhbCA9IG5ldyBJbnB1dE1vZGFsKHRoaXMuYXBwLCAocmVzdWx0KSA9PiB7XG4gICAgICAgIGlmIChyZXN1bHQgPT09IG51bGwpIHtcbiAgICAgICAgICAvLyBVc2VyIGNhbmNlbGxlZFxuICAgICAgICAgIHJlc29sdmUobnVsbCk7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKCF2YWxpZGF0b3IocmVzdWx0KSkge1xuICAgICAgICAgIG5ldyBOb3RpY2UoZXJyb3JNZXNzYWdlKTtcbiAgICAgICAgICAvLyBSZWN1cnNpdmVseSBjYWxsIGFnYWluIGlmIHZhbGlkYXRpb24gZmFpbHNcbiAgICAgICAgICB0aGlzLnByb21wdFdpdGhWYWxpZGF0aW9uKHRpdGxlLCBtZXNzYWdlLCB2YWxpZGF0b3IsIGVycm9yTWVzc2FnZSlcbiAgICAgICAgICAgIC50aGVuKHJlc29sdmUpO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIHJlc29sdmUocmVzdWx0LnRyaW0oKSk7XG4gICAgICB9KTtcblxuICAgICAgLy8gU2V0IHRoZSB0aXRsZSBhbmQgbWVzc2FnZSBkaWZmZXJlbnRseSBzaW5jZSBvdXIgbW9kYWwgaXMgc2ltcGxlXG4gICAgICBtb2RhbC50aXRsZUVsLnNldFRleHQodGl0bGUpO1xuICAgICAgY29uc3QgbWVzc2FnZUVsID0gbW9kYWwuY29udGVudEVsLmNyZWF0ZURpdigpO1xuICAgICAgbWVzc2FnZUVsLnNldFRleHQobWVzc2FnZSk7XG5cbiAgICAgIG1vZGFsLm9wZW4oKTtcbiAgICB9KTtcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgcHJvbXB0V2l0aE9wdGlvbnMoXG4gICAgdGl0bGU6IHN0cmluZyxcbiAgICBtZXNzYWdlOiBzdHJpbmcsXG4gICAgb3B0aW9uczogc3RyaW5nW11cbiAgKTogUHJvbWlzZTxzdHJpbmcgfCBudWxsPiB7XG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG4gICAgICBjb25zdCBtb2RhbCA9IG5ldyBTdWdnZXN0ZXJNb2RhbCh0aGlzLmFwcCwgb3B0aW9ucywgKHJlc3VsdCkgPT4ge1xuICAgICAgICBpZiAocmVzdWx0ID09PSBudWxsKSB7XG4gICAgICAgICAgLy8gVXNlciBjYW5jZWxsZWRcbiAgICAgICAgICByZXNvbHZlKG51bGwpO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChvcHRpb25zLmluY2x1ZGVzKHJlc3VsdCkpIHtcbiAgICAgICAgICByZXNvbHZlKHJlc3VsdCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgbmV3IE5vdGljZShgUGxlYXNlIHNlbGVjdCBvbmUgb2Y6ICR7b3B0aW9ucy5qb2luKFwiLCBcIil9YCk7XG4gICAgICAgICAgLy8gUmVjdXJzaXZlbHkgY2FsbCBhZ2FpbiBpZiBjaG9pY2UgaXMgaW52YWxpZFxuICAgICAgICAgIHRoaXMucHJvbXB0V2l0aE9wdGlvbnModGl0bGUsIG1lc3NhZ2UsIG9wdGlvbnMpXG4gICAgICAgICAgICAudGhlbihyZXNvbHZlKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG5cbiAgICAgIC8vIFNldCB0aGUgdGl0bGVcbiAgICAgIG1vZGFsLnRpdGxlRWwuc2V0VGV4dCh0aXRsZSk7XG4gICAgICBjb25zdCBtZXNzYWdlRWwgPSBtb2RhbC5jb250ZW50RWwuY3JlYXRlRGl2KCk7XG4gICAgICBtZXNzYWdlRWwuc2V0VGV4dChtZXNzYWdlKTtcblxuICAgICAgbW9kYWwub3BlbigpO1xuICAgIH0pO1xuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBjcmVhdGVDb3Vyc2VGb2xkZXJTdHJ1Y3R1cmUoY291cnNlRGV0YWlsczoge1xuICAgIGNvdXJzZU5hbWU6IHN0cmluZ1xuICAgIGNvdXJzZVNlYXNvbjogc3RyaW5nXG4gICAgY291cnNlWWVhcjogc3RyaW5nXG4gICAgY291cnNlSWQ6IHN0cmluZ1xuICB9KTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgICBjb25zdCBmb2xkZXJQYXRoID0gYCR7Y291cnNlRGV0YWlscy5jb3Vyc2VZZWFyfS8ke2NvdXJzZURldGFpbHMuY291cnNlU2Vhc29ufS8ke2NvdXJzZURldGFpbHMuY291cnNlTmFtZX1gXG5cbiAgICB0cnkge1xuICAgICAgYXdhaXQgdGhpcy5hcHAudmF1bHQuY3JlYXRlRm9sZGVyKGZvbGRlclBhdGgpXG4gICAgICBjb25zb2xlLmxvZyhgQ3JlYXRlZCBjb3Vyc2UgZm9sZGVyOiAke2ZvbGRlclBhdGh9YClcbiAgICAgIHJldHVybiBmb2xkZXJQYXRoXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIC8vIEZvbGRlciBtaWdodCBhbHJlYWR5IGV4aXN0LCB3aGljaCBpcyBmaW5lIGZvciBub3dcbiAgICAgIGNvbnNvbGUubG9nKGBDb3Vyc2UgZm9sZGVyIGFscmVhZHkgZXhpc3RzIG9yIGNyZWF0ZWQ6ICR7Zm9sZGVyUGF0aH1gKVxuICAgICAgcmV0dXJuIGZvbGRlclBhdGhcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIGNyZWF0ZUNvdXJzZUhvbWVwYWdlTm90ZShcbiAgICBjb3Vyc2VEZXRhaWxzOiB7XG4gICAgICBjb3Vyc2VOYW1lOiBzdHJpbmdcbiAgICAgIGNvdXJzZVNlYXNvbjogc3RyaW5nXG4gICAgICBjb3Vyc2VZZWFyOiBzdHJpbmdcbiAgICAgIGNvdXJzZUlkOiBzdHJpbmdcbiAgICB9LFxuICAgIGZvbGRlclBhdGg6IHN0cmluZ1xuICApOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBjb25zdCBub3RlUGF0aCA9IGAke2ZvbGRlclBhdGh9LyR7Y291cnNlRGV0YWlscy5jb3Vyc2VOYW1lfS5tZGBcbiAgICBjb25zdCBjb250ZW50ID0gdGhpcy5nZW5lcmF0ZUNvdXJzZUhvbWVwYWdlQ29udGVudChjb3Vyc2VEZXRhaWxzKVxuXG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IHRoaXMuYXBwLnZhdWx0LmNyZWF0ZShub3RlUGF0aCwgY29udGVudClcbiAgICAgIGNvbnNvbGUubG9nKGBDcmVhdGVkIGNvdXJzZSBob21lcGFnZTogJHtub3RlUGF0aH1gKVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKGBFcnJvciBjcmVhdGluZyBjb3Vyc2UgaG9tZXBhZ2U6ICR7ZXJyb3J9YClcbiAgICAgIHRocm93IGVycm9yXG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBjcmVhdGVBdHRhY2htZW50c0ZvbGRlcihmb2xkZXJQYXRoOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBjb25zdCBhdHRhY2htZW50c1BhdGggPSBgJHtmb2xkZXJQYXRofS9BdHRhY2htZW50c2BcblxuICAgIHRyeSB7XG4gICAgICBhd2FpdCB0aGlzLmFwcC52YXVsdC5jcmVhdGVGb2xkZXIoYXR0YWNobWVudHNQYXRoKVxuICAgICAgY29uc29sZS5sb2coYENyZWF0ZWQgYXR0YWNobWVudHMgZm9sZGVyOiAke2F0dGFjaG1lbnRzUGF0aH1gKVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAvLyBGb2xkZXIgbWlnaHQgYWxyZWFkeSBleGlzdCwgd2hpY2ggaXMgZmluZVxuICAgICAgY29uc29sZS5sb2coYEF0dGFjaG1lbnRzIGZvbGRlciBhbHJlYWR5IGV4aXN0czogJHthdHRhY2htZW50c1BhdGh9YClcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGdlbmVyYXRlQ291cnNlSG9tZXBhZ2VDb250ZW50KGNvdXJzZURldGFpbHM6IHtcbiAgICBjb3Vyc2VOYW1lOiBzdHJpbmdcbiAgICBjb3Vyc2VTZWFzb246IHN0cmluZ1xuICAgIGNvdXJzZVllYXI6IHN0cmluZ1xuICAgIGNvdXJzZUlkOiBzdHJpbmdcbiAgfSk6IHN0cmluZyB7XG4gICAgLy8gVXNlIHRoZSB0ZW1wbGF0ZU1hbmFnZXIgdG8gZ2V0IHRoZSB0ZW1wbGF0ZSBjb250ZW50IGFuZCByZXBsYWNlIHZhbHVlc1xuICAgIGNvbnN0IHRlbXBsYXRlTWFuYWdlciA9IG5ldyBUZW1wbGF0ZU1hbmFnZXIodGhpcy5hcHAsIHRoaXMuc2V0dGluZ3MpO1xuICAgIGNvbnN0IHRlbXBsYXRlQ29udGVudCA9IHRlbXBsYXRlTWFuYWdlci5nZW5lcmF0ZUNvdXJzZUhvbWVwYWdlVGVtcGxhdGUoKTtcbiAgICBcbiAgICAvLyBSZXBsYWNlIHRlbXBsYXRlIHZhcmlhYmxlcyB3aXRoIGFjdHVhbCB2YWx1ZXNcbiAgICByZXR1cm4gdGVtcGxhdGVDb250ZW50XG4gICAgICAucmVwbGFjZSgvPCUgY291cnNlTmFtZSAlPi9nLCBjb3Vyc2VEZXRhaWxzLmNvdXJzZU5hbWUpXG4gICAgICAucmVwbGFjZSgvPCUgY291cnNlU2Vhc29uICU+L2csIGNvdXJzZURldGFpbHMuY291cnNlU2Vhc29uKVxuICAgICAgLnJlcGxhY2UoLzwlIGNvdXJzZVllYXIgJT4vZywgY291cnNlRGV0YWlscy5jb3Vyc2VZZWFyKVxuICAgICAgLnJlcGxhY2UoLzwlIGNvdXJzZUlkICU+L2csIGNvdXJzZURldGFpbHMuY291cnNlSWQpXG4gICAgICAucmVwbGFjZSgvPCUgdHBcXC5kYXRlXFwubm93XFwoXCJZWVlZLU1NLUREXFxbVFxcXUhIOm1tOnNzWlwiXFwpICU+L2csIG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSlcbiAgICAgIC5yZXBsYWNlKC88JSB0cFxcLmRhdGVcXC5ub3dcXChcIllZWVktTU0tRERcXFtUXFxdaGg6bW06U1NTU1paXCJcXCkgJT4vZywgbmV3IERhdGUoKS50b0lTT1N0cmluZygpKTtcbiAgfVxufVxuIiwgImltcG9ydCB7IEFwcCwgTW9kYWwsIFNldHRpbmcgfSBmcm9tIFwib2JzaWRpYW5cIjtcblxuZXhwb3J0IGNsYXNzIElucHV0TW9kYWwgZXh0ZW5kcyBNb2RhbCB7XG4gIHJlc3VsdDogc3RyaW5nIHwgbnVsbDtcbiAgb25TdWJtaXQ6IChyZXN1bHQ6IHN0cmluZyB8IG51bGwpID0+IHZvaWQ7XG5cbiAgY29uc3RydWN0b3IoYXBwOiBBcHAsIG9uU3VibWl0OiAocmVzdWx0OiBzdHJpbmcgfCBudWxsKSA9PiB2b2lkKSB7XG4gICAgc3VwZXIoYXBwKTtcbiAgICB0aGlzLm9uU3VibWl0ID0gb25TdWJtaXQ7XG4gIH1cblxuICBvbk9wZW4oKSB7XG4gICAgY29uc3QgeyBjb250ZW50RWwgfSA9IHRoaXM7XG5cbiAgICBjb250ZW50RWwuY3JlYXRlRWwoXCJoMlwiLCB7IHRleHQ6IFwiRW50ZXIgVmFsdWVcIiB9KTtcblxuICAgIG5ldyBTZXR0aW5nKGNvbnRlbnRFbClcbiAgICAgIC5zZXROYW1lKFwiVmFsdWVcIilcbiAgICAgIC5hZGRUZXh0KCh0ZXh0KSA9PiBcbiAgICAgICAgdGV4dFxuICAgICAgICAgIC5vbkNoYW5nZSgodmFsdWUpID0+IHtcbiAgICAgICAgICAgIHRoaXMucmVzdWx0ID0gdmFsdWU7XG4gICAgICAgICAgfSlcbiAgICAgICAgICAuaW5wdXRFbC5mb2N1cygpXG4gICAgICApO1xuXG4gICAgbmV3IFNldHRpbmcoY29udGVudEVsKVxuICAgICAgLmFkZEJ1dHRvbigoYnRuKSA9PlxuICAgICAgICBidG5cbiAgICAgICAgICAuc2V0QnV0dG9uVGV4dChcIlN1Ym1pdFwiKVxuICAgICAgICAgIC5zZXRDdGEoKVxuICAgICAgICAgIC5vbkNsaWNrKCgpID0+IHtcbiAgICAgICAgICAgIHRoaXMuY2xvc2UoKTtcbiAgICAgICAgICAgIHRoaXMub25TdWJtaXQodGhpcy5yZXN1bHQgfHwgXCJcIik7XG4gICAgICAgICAgfSlcbiAgICAgIClcbiAgICAgIC5hZGRCdXR0b24oKGJ0bikgPT5cbiAgICAgICAgYnRuLnNldEJ1dHRvblRleHQoXCJDYW5jZWxcIikub25DbGljaygoKSA9PiB7XG4gICAgICAgICAgdGhpcy5jbG9zZSgpO1xuICAgICAgICAgIHRoaXMub25TdWJtaXQobnVsbCk7XG4gICAgICAgIH0pXG4gICAgICApO1xuICB9XG5cbiAgb25DbG9zZSgpIHtcbiAgICBjb25zdCB7IGNvbnRlbnRFbCB9ID0gdGhpcztcbiAgICBjb250ZW50RWwuZW1wdHkoKTtcbiAgfVxufVxuXG5leHBvcnQgY2xhc3MgU3VnZ2VzdGVyTW9kYWwgZXh0ZW5kcyBNb2RhbCB7XG4gIHJlc3VsdDogc3RyaW5nIHwgbnVsbDtcbiAgb25TdWJtaXQ6IChyZXN1bHQ6IHN0cmluZyB8IG51bGwpID0+IHZvaWQ7XG5cbiAgY29uc3RydWN0b3IoYXBwOiBBcHAsIG9wdGlvbnM6IHN0cmluZ1tdLCBvblN1Ym1pdDogKHJlc3VsdDogc3RyaW5nIHwgbnVsbCkgPT4gdm9pZCkge1xuICAgIHN1cGVyKGFwcCk7XG4gICAgdGhpcy5vblN1Ym1pdCA9IG9uU3VibWl0O1xuXG4gICAgLy8gQ3JlYXRlIGEgZHJvcGRvd24gd2l0aCB0aGUgcHJvdmlkZWQgb3B0aW9uc1xuICAgIGNvbnN0IGRyb3Bkb3duT3B0aW9uczogeyBba2V5OiBzdHJpbmddOiBzdHJpbmcgfSA9IHt9O1xuICAgIG9wdGlvbnMuZm9yRWFjaChvcHRpb24gPT4ge1xuICAgICAgZHJvcGRvd25PcHRpb25zW29wdGlvbl0gPSBvcHRpb247XG4gICAgfSk7XG4gICAgXG4gICAgdGhpcy5jcmVhdGVEcm9wZG93bihkcm9wZG93bk9wdGlvbnMpO1xuICB9XG5cbiAgY3JlYXRlRHJvcGRvd24ob3B0aW9uczogeyBba2V5OiBzdHJpbmddOiBzdHJpbmcgfSkge1xuICAgIGNvbnN0IHsgY29udGVudEVsIH0gPSB0aGlzO1xuXG4gICAgY29udGVudEVsLmNyZWF0ZUVsKFwiaDJcIiwgeyB0ZXh0OiBcIlNlbGVjdCBPcHRpb25cIiB9KTtcblxuICAgIGxldCBzZWxlY3RlZFZhbHVlID0gT2JqZWN0LmtleXMob3B0aW9ucylbMF0gfHwgbnVsbDsgLy8gRGVmYXVsdCB0byBmaXJzdCBvcHRpb24gb3IgbnVsbFxuXG4gICAgY29uc3QgZHJvcGRvd24gPSBjb250ZW50RWwuY3JlYXRlRWwoXCJzZWxlY3RcIik7XG4gICAgT2JqZWN0LmVudHJpZXMob3B0aW9ucykuZm9yRWFjaCgoW2tleSwgdmFsdWVdKSA9PiB7XG4gICAgICBjb25zdCBvcHRpb24gPSBkcm9wZG93bi5jcmVhdGVFbChcIm9wdGlvblwiLCB7XG4gICAgICAgIHZhbHVlOiBrZXksXG4gICAgICAgIHRleHQ6IHZhbHVlXG4gICAgICB9KTtcbiAgICAgIGlmIChrZXkgPT09IHNlbGVjdGVkVmFsdWUpIHtcbiAgICAgICAgb3B0aW9uLnNlbGVjdGVkID0gdHJ1ZTtcbiAgICAgIH1cbiAgICB9KTtcblxuICAgIGRyb3Bkb3duLmFkZEV2ZW50TGlzdGVuZXIoXCJjaGFuZ2VcIiwgKGV2ZW50KSA9PiB7XG4gICAgICBzZWxlY3RlZFZhbHVlID0gKGV2ZW50LnRhcmdldCBhcyBIVE1MU2VsZWN0RWxlbWVudCkudmFsdWU7XG4gICAgICB0aGlzLnJlc3VsdCA9IHNlbGVjdGVkVmFsdWU7XG4gICAgfSk7XG5cbiAgICBuZXcgU2V0dGluZyhjb250ZW50RWwpXG4gICAgICAuYWRkQnV0dG9uKChidG4pID0+XG4gICAgICAgIGJ0blxuICAgICAgICAgIC5zZXRCdXR0b25UZXh0KFwiU3VibWl0XCIpXG4gICAgICAgICAgLnNldEN0YSgpXG4gICAgICAgICAgLm9uQ2xpY2soKCkgPT4ge1xuICAgICAgICAgICAgdGhpcy5jbG9zZSgpO1xuICAgICAgICAgICAgdGhpcy5vblN1Ym1pdChzZWxlY3RlZFZhbHVlKTtcbiAgICAgICAgICB9KVxuICAgICAgKVxuICAgICAgLmFkZEJ1dHRvbigoYnRuKSA9PlxuICAgICAgICBidG4uc2V0QnV0dG9uVGV4dChcIkNhbmNlbFwiKS5vbkNsaWNrKCgpID0+IHtcbiAgICAgICAgICB0aGlzLmNsb3NlKCk7XG4gICAgICAgICAgdGhpcy5vblN1Ym1pdChudWxsKTtcbiAgICAgICAgfSlcbiAgICAgICk7XG4gIH1cblxuICBvbk9wZW4oKSB7XG4gICAgLy8gVGhlIGRyb3Bkb3duIGlzIGFscmVhZHkgY3JlYXRlZCBpbiBjb25zdHJ1Y3RvclxuICB9XG5cbiAgb25DbG9zZSgpIHtcbiAgICBjb25zdCB7IGNvbnRlbnRFbCB9ID0gdGhpcztcbiAgICBjb250ZW50RWwuZW1wdHkoKTtcbiAgfVxufSIsICIvLyBWb2NhYnVsYXJ5IGV4dHJhY3Rpb24gZm9yIFR1Y2tlcnMgVG9vbHMgcGx1Z2luXG5cbmltcG9ydCB7IEFwcCwgVEZpbGUgfSBmcm9tIFwib2JzaWRpYW5cIlxuaW1wb3J0IHsgZ2V0Q291cnNlSWRGcm9tUGF0aCB9IGZyb20gXCIuL3V0aWxzXCJcblxuZXhwb3J0IGNsYXNzIFZvY2FidWxhcnlFeHRyYWN0b3Ige1xuICBhcHA6IEFwcFxuXG4gIGNvbnN0cnVjdG9yKGFwcDogQXBwKSB7XG4gICAgdGhpcy5hcHAgPSBhcHBcbiAgfVxuXG4gIGV4dHJhY3RWb2NhYnVsYXJ5RnJvbU5vdGUoY29udGVudDogc3RyaW5nKTogc3RyaW5nW10ge1xuICAgIC8vIEV4dHJhY3Qgdm9jYWJ1bGFyeSBzZWN0aW9uIGZyb20gbm90ZSBjb250ZW50XG4gICAgY29uc3Qgdm9jYWJSZWdleCA9IC9eIysgVm9jYWJ1bGFyeS4qXFxuKCg/Oi4qP1xcbikqPykoPz1eXFxzKiNcXHN8JCkvbVxuICAgIGNvbnN0IHZvY2FiTWF0Y2hlcyA9IGNvbnRlbnQ/Lm1hdGNoKHZvY2FiUmVnZXgpXG5cbiAgICBpZiAodm9jYWJNYXRjaGVzKSB7XG4gICAgICBjb25zdCB2b2NhYkRhdGEgPSB2b2NhYk1hdGNoZXNbMV0udHJpbSgpXG4gICAgICBjb25zdCBjbGVhbmVkVm9jYWIgPSB2b2NhYkRhdGFcbiAgICAgICAgLnJlcGxhY2UoL1xcW1xcWy4qP1xcXVxcXS9nLCBcIlwiKSAvLyBSZW1vdmUgd2lraWxpbmtzXG4gICAgICAgIC5yZXBsYWNlKC9eXFxzKi1cXHMqL2dtLCBcIlwiKSAvLyBSZW1vdmUgYnVsbGV0IHBvaW50c1xuICAgICAgICAuc3BsaXQoXCJcXG5cIilcbiAgICAgICAgLm1hcCgodGVybSkgPT4gdGVybS50cmltKCkpXG4gICAgICAgIC5maWx0ZXIoKHRlcm0pID0+IHRlcm0ubGVuZ3RoID4gMClcblxuICAgICAgcmV0dXJuIGNsZWFuZWRWb2NhYlxuICAgIH1cblxuICAgIHJldHVybiBbXVxuICB9XG5cbiAgYXN5bmMgZXh0cmFjdFZvY2FidWxhcnlGcm9tQ291cnNlKFxuICAgIGNvdXJzZUlkOiBzdHJpbmdcbiAgKTogUHJvbWlzZTxSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT4+IHtcbiAgICBjb25zb2xlLmxvZyhgRXh0cmFjdGluZyB2b2NhYnVsYXJ5IGZvciBjb3Vyc2U6ICR7Y291cnNlSWR9YClcblxuICAgIHRyeSB7XG4gICAgICAvLyBGaW5kIGFsbCBub3RlcyByZWxhdGVkIHRvIHRoZSBjb3Vyc2VcbiAgICAgIGNvbnN0IGNvdXJzZU5vdGVzID0gYXdhaXQgdGhpcy5maW5kQ291cnNlTm90ZXMoY291cnNlSWQpXG5cbiAgICAgIGlmIChjb3Vyc2VOb3Rlcy5sZW5ndGggPT09IDApIHtcbiAgICAgICAgY29uc29sZS5sb2coYE5vIG5vdGVzIGZvdW5kIGZvciBjb3Vyc2U6ICR7Y291cnNlSWR9YClcbiAgICAgICAgcmV0dXJuIHt9XG4gICAgICB9XG5cbiAgICAgIC8vIEV4dHJhY3Qgdm9jYWJ1bGFyeSBmcm9tIGVhY2ggbm90ZVxuICAgICAgY29uc3Qgdm9jYWJ1bGFyeURhdGE6IFJlY29yZDxzdHJpbmcsIHN0cmluZ1tdPiA9IHt9XG5cbiAgICAgIGZvciAoY29uc3Qgbm90ZSBvZiBjb3Vyc2VOb3Rlcykge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGNvbnN0IGNvbnRlbnQgPSBhd2FpdCB0aGlzLmFwcC52YXVsdC5yZWFkKG5vdGUpXG4gICAgICAgICAgY29uc3Qgdm9jYWJ1bGFyeSA9IHRoaXMuZXh0cmFjdFZvY2FidWxhcnlGcm9tTm90ZShjb250ZW50KVxuXG4gICAgICAgICAgaWYgKHZvY2FidWxhcnkubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgdm9jYWJ1bGFyeURhdGFbbm90ZS5iYXNlbmFtZV0gPSB2b2NhYnVsYXJ5XG4gICAgICAgICAgfVxuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIHJlYWRpbmcgbm90ZSAke25vdGUucGF0aH06YCwgZXJyb3IpXG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgY29uc29sZS5sb2coXG4gICAgICAgIGBFeHRyYWN0ZWQgdm9jYWJ1bGFyeSBmcm9tICR7XG4gICAgICAgICAgT2JqZWN0LmtleXModm9jYWJ1bGFyeURhdGEpLmxlbmd0aFxuICAgICAgICB9IG5vdGVzIGZvciBjb3Vyc2U6ICR7Y291cnNlSWR9YFxuICAgICAgKVxuICAgICAgcmV0dXJuIHZvY2FidWxhcnlEYXRhXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXG4gICAgICAgIGBFcnJvciBleHRyYWN0aW5nIHZvY2FidWxhcnkgZm9yIGNvdXJzZSAke2NvdXJzZUlkfTpgLFxuICAgICAgICBlcnJvclxuICAgICAgKVxuICAgICAgcmV0dXJuIHt9XG4gICAgfVxuICB9XG5cbiAgYXN5bmMgZmluZENvdXJzZU5vdGVzKGNvdXJzZUlkOiBzdHJpbmcpOiBQcm9taXNlPFRGaWxlW10+IHtcbiAgICBjb25zdCBub3RlczogVEZpbGVbXSA9IFtdXG5cbiAgICAvLyBHZXQgYWxsIG1hcmtkb3duIGZpbGVzIGluIHRoZSB2YXVsdFxuICAgIGNvbnN0IGZpbGVzID0gdGhpcy5hcHAudmF1bHQuZ2V0TWFya2Rvd25GaWxlcygpXG5cbiAgICBmb3IgKGNvbnN0IGZpbGUgb2YgZmlsZXMpIHtcbiAgICAgIC8vIENoZWNrIGlmIHRoZSBmaWxlIHBhdGggY29udGFpbnMgdGhlIGNvdXJzZSBJRFxuICAgICAgaWYgKFxuICAgICAgICBmaWxlLnBhdGguaW5jbHVkZXMoY291cnNlSWQpIHx8XG4gICAgICAgIChhd2FpdCB0aGlzLm5vdGVCZWxvbmdzVG9Db3Vyc2UoZmlsZSwgY291cnNlSWQpKVxuICAgICAgKSB7XG4gICAgICAgIG5vdGVzLnB1c2goZmlsZSlcbiAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gbm90ZXNcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgbm90ZUJlbG9uZ3NUb0NvdXJzZShcbiAgICBmaWxlOiBURmlsZSxcbiAgICBjb3Vyc2VJZDogc3RyaW5nXG4gICk6IFByb21pc2U8Ym9vbGVhbj4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBjb250ZW50ID0gYXdhaXQgdGhpcy5hcHAudmF1bHQucmVhZChmaWxlKVxuICAgICAgY29uc3QgZnJvbnRtYXR0ZXJNYXRjaCA9IGNvbnRlbnQubWF0Y2goL14tLS1cXG4oW1xcc1xcU10qPylcXG4tLS0vKVxuXG4gICAgICBpZiAoZnJvbnRtYXR0ZXJNYXRjaCkge1xuICAgICAgICBjb25zdCBmcm9udG1hdHRlciA9IGZyb250bWF0dGVyTWF0Y2hbMV1cbiAgICAgICAgLy8gQ2hlY2sgaWYgY291cnNlX2lkIGlzIGluIHRoZSBmcm9udG1hdHRlclxuICAgICAgICByZXR1cm4gKFxuICAgICAgICAgIGZyb250bWF0dGVyLmluY2x1ZGVzKGBjb3Vyc2VfaWQ6ICR7Y291cnNlSWR9YCkgfHxcbiAgICAgICAgICBmcm9udG1hdHRlci5pbmNsdWRlcyhgY291cnNlX2lkOiR7Y291cnNlSWR9YClcbiAgICAgICAgKVxuICAgICAgfVxuXG4gICAgICByZXR1cm4gZmFsc2VcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihcbiAgICAgICAgYEVycm9yIGNoZWNraW5nIGlmIG5vdGUgJHtmaWxlLnBhdGh9IGJlbG9uZ3MgdG8gY291cnNlICR7Y291cnNlSWR9OmAsXG4gICAgICAgIGVycm9yXG4gICAgICApXG4gICAgICByZXR1cm4gZmFsc2VcbiAgICB9XG4gIH1cblxuICBhc3luYyBnZW5lcmF0ZVZvY2FidWxhcnlJbmRleChcbiAgICBjb3Vyc2VJZDogc3RyaW5nLFxuICAgIHZvY2FidWxhcnlEYXRhOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT5cbiAgKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgICBjb25zdCBhbGxUZXJtczogc3RyaW5nW10gPSBbXVxuICAgIGNvbnN0IHRlcm1Tb3VyY2VzOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT4gPSB7fVxuXG4gICAgLy8gQ29sbGVjdCBhbGwgdW5pcXVlIHRlcm1zIGFuZCB0aGVpciBzb3VyY2VzXG4gICAgZm9yIChjb25zdCBbbm90ZU5hbWUsIHRlcm1zXSBvZiBPYmplY3QuZW50cmllcyh2b2NhYnVsYXJ5RGF0YSkpIHtcbiAgICAgIGZvciAoY29uc3QgdGVybSBvZiB0ZXJtcykge1xuICAgICAgICBpZiAoIWFsbFRlcm1zLmluY2x1ZGVzKHRlcm0pKSB7XG4gICAgICAgICAgYWxsVGVybXMucHVzaCh0ZXJtKVxuICAgICAgICAgIHRlcm1Tb3VyY2VzW3Rlcm1dID0gW11cbiAgICAgICAgfVxuICAgICAgICB0ZXJtU291cmNlc1t0ZXJtXS5wdXNoKG5vdGVOYW1lKVxuICAgICAgfVxuICAgIH1cblxuICAgIC8vIFNvcnQgdGVybXMgYWxwaGFiZXRpY2FsbHlcbiAgICBhbGxUZXJtcy5zb3J0KClcblxuICAgIC8vIEdlbmVyYXRlIG1hcmtkb3duIGNvbnRlbnRcbiAgICBsZXQgY29udGVudCA9IGAjIFZvY2FidWxhcnkgSW5kZXggLSAke2NvdXJzZUlkfVxcblxcbmBcbiAgICBjb250ZW50ICs9IGBUb3RhbCB1bmlxdWUgdGVybXM6ICR7YWxsVGVybXMubGVuZ3RofVxcblxcbmBcblxuICAgIGZvciAoY29uc3QgdGVybSBvZiBhbGxUZXJtcykge1xuICAgICAgY29udGVudCArPSBgIyMgJHt0ZXJtfVxcbmBcbiAgICAgIGNvbnRlbnQgKz0gYCoqU291cmNlczoqKiAke3Rlcm1Tb3VyY2VzW3Rlcm1dLmpvaW4oXCIsIFwiKX1cXG5cXG5gXG4gICAgICBjb250ZW50ICs9IGAqKkRlZmluaXRpb246KipcXG5cXG5gXG4gICAgICBjb250ZW50ICs9IGAqKkNvbnRleHQ6KipcXG5cXG5gXG4gICAgICBjb250ZW50ICs9IGAqKkV4YW1wbGVzOioqXFxuXFxuYFxuICAgICAgY29udGVudCArPSBgLS0tXFxuXFxuYFxuICAgIH1cblxuICAgIHJldHVybiBjb250ZW50XG4gIH1cblxuICBhc3luYyBjcmVhdGVWb2NhYnVsYXJ5SW5kZXhGaWxlKGNvdXJzZUlkOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3Qgdm9jYWJ1bGFyeURhdGEgPSBhd2FpdCB0aGlzLmV4dHJhY3RWb2NhYnVsYXJ5RnJvbUNvdXJzZShjb3Vyc2VJZClcblxuICAgICAgaWYgKE9iamVjdC5rZXlzKHZvY2FidWxhcnlEYXRhKS5sZW5ndGggPT09IDApIHtcbiAgICAgICAgY29uc29sZS5sb2coYE5vIHZvY2FidWxhcnkgZm91bmQgZm9yIGNvdXJzZTogJHtjb3Vyc2VJZH1gKVxuICAgICAgICByZXR1cm5cbiAgICAgIH1cblxuICAgICAgY29uc3QgaW5kZXhDb250ZW50ID0gYXdhaXQgdGhpcy5nZW5lcmF0ZVZvY2FidWxhcnlJbmRleChcbiAgICAgICAgY291cnNlSWQsXG4gICAgICAgIHZvY2FidWxhcnlEYXRhXG4gICAgICApXG5cbiAgICAgIC8vIENyZWF0ZSB0aGUgaW5kZXggZmlsZVxuICAgICAgY29uc3QgZmlsZU5hbWUgPSBgJHtjb3Vyc2VJZH0gLSBWb2NhYnVsYXJ5IEluZGV4Lm1kYFxuICAgICAgY29uc3QgZmlsZVBhdGggPSBgQ291cnNlcy8ke2NvdXJzZUlkfS8ke2ZpbGVOYW1lfWBcblxuICAgICAgdHJ5IHtcbiAgICAgICAgYXdhaXQgdGhpcy5hcHAudmF1bHQuY3JlYXRlKGZpbGVQYXRoLCBpbmRleENvbnRlbnQpXG4gICAgICAgIGNvbnNvbGUubG9nKGBDcmVhdGVkIHZvY2FidWxhcnkgaW5kZXggZmlsZTogJHtmaWxlUGF0aH1gKVxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgLy8gRmlsZSBtaWdodCBhbHJlYWR5IGV4aXN0LCB0cnkgdG8gdXBkYXRlIGl0XG4gICAgICAgIGNvbnN0IGV4aXN0aW5nRmlsZSA9IHRoaXMuYXBwLnZhdWx0LmdldEFic3RyYWN0RmlsZUJ5UGF0aChmaWxlUGF0aClcbiAgICAgICAgaWYgKGV4aXN0aW5nRmlsZSAmJiBleGlzdGluZ0ZpbGUgaW5zdGFuY2VvZiBURmlsZSkge1xuICAgICAgICAgIGF3YWl0IHRoaXMuYXBwLnZhdWx0Lm1vZGlmeShleGlzdGluZ0ZpbGUsIGluZGV4Q29udGVudClcbiAgICAgICAgICBjb25zb2xlLmxvZyhgVXBkYXRlZCB2b2NhYnVsYXJ5IGluZGV4IGZpbGU6ICR7ZmlsZVBhdGh9YClcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFxuICAgICAgICBgRXJyb3IgY3JlYXRpbmcgdm9jYWJ1bGFyeSBpbmRleCBmb3IgY291cnNlICR7Y291cnNlSWR9OmAsXG4gICAgICAgIGVycm9yXG4gICAgICApXG4gICAgICB0aHJvdyBlcnJvclxuICAgIH1cbiAgfVxufVxuIiwgImltcG9ydCB7IEFwcCwgVEZpbGUgfSBmcm9tIFwib2JzaWRpYW5cIlxuaW1wb3J0IHsgaXNCZXR3ZWVuIH0gZnJvbSBcIi4vdXRpbHNcIlxuXG5leHBvcnQgY2xhc3MgRHVlRGF0ZXNQYXJzZXIge1xuICBhcHA6IEFwcFxuXG4gIGNvbnN0cnVjdG9yKGFwcDogQXBwKSB7XG4gICAgdGhpcy5hcHAgPSBhcHBcbiAgfVxuXG4gIHBhcnNlRHVlRGF0ZXNGcm9tTm90ZShcbiAgICBjb250ZW50OiBzdHJpbmdcbiAgKTogQXJyYXk8eyBkYXRlOiBzdHJpbmc7IGFzc2lnbm1lbnQ6IHN0cmluZzsgc3RhdHVzOiBzdHJpbmcgfT4ge1xuICAgIC8vIEV4dHJhY3QgZHVlIGRhdGVzIHNlY3Rpb24gZnJvbSBub3RlIGNvbnRlbnRcbiAgICBjb25zdCBkdWVEYXRlc1JlZ2V4ID0gLyMgRHVlIERhdGVzW1xcc1xcU10qPyg/PVxcbiN8JCkvXG4gICAgY29uc3QgbWF0Y2hlcyA9IGNvbnRlbnQ/Lm1hdGNoKGR1ZURhdGVzUmVnZXgpXG5cbiAgICBpZiAoIW1hdGNoZXMpIHtcbiAgICAgIHJldHVybiBbXVxuICAgIH1cblxuICAgIGNvbnN0IGR1ZURhdGVzU2VjdGlvbiA9IG1hdGNoZXNbMF1cbiAgICBjb25zdCBkdWVEYXRlcyA9IFtdXG5cbiAgICAvLyBMb29rIGZvciBtYXJrZG93biB0YWJsZXMgaW4gdGhlIGR1ZSBkYXRlcyBzZWN0aW9uXG4gICAgY29uc3QgdGFibGVSZWdleCA9IC9cXHxbXFxzXFxTXSo/XFxuL2dcbiAgICBjb25zdCB0YWJsZU1hdGNoZXMgPSBkdWVEYXRlc1NlY3Rpb24ubWF0Y2godGFibGVSZWdleClcblxuICAgIGlmICh0YWJsZU1hdGNoZXMpIHtcbiAgICAgIGZvciAoY29uc3QgdGFibGUgb2YgdGFibGVNYXRjaGVzKSB7XG4gICAgICAgIGNvbnN0IHJvd3MgPSB0YWJsZVxuICAgICAgICAgIC50cmltKClcbiAgICAgICAgICAuc3BsaXQoXCJcXG5cIilcbiAgICAgICAgICAuZmlsdGVyKChyb3cpID0+IHJvdy5zdGFydHNXaXRoKFwifFwiKSlcbiAgICAgICAgY29uc3QgcGFyc2VkUm93cyA9IHRoaXMucGFyc2VUYWJsZVJvd3Mocm93cylcbiAgICAgICAgZHVlRGF0ZXMucHVzaCguLi5wYXJzZWRSb3dzKVxuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBkdWVEYXRlc1xuICB9XG5cbiAgcHJpdmF0ZSBwYXJzZVRhYmxlUm93cyhcbiAgICByb3dzOiBzdHJpbmdbXVxuICApOiBBcnJheTx7IGRhdGU6IHN0cmluZzsgYXNzaWdubWVudDogc3RyaW5nOyBzdGF0dXM6IHN0cmluZyB9PiB7XG4gICAgaWYgKHJvd3MubGVuZ3RoIDwgMikgcmV0dXJuIFtdIC8vIE5lZWQgYXQgbGVhc3QgaGVhZGVyICsgMSBkYXRhIHJvd1xuXG4gICAgY29uc3QgZHVlRGF0ZXMgPSBbXVxuXG4gICAgZm9yIChsZXQgaSA9IDE7IGkgPCByb3dzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAvLyBTa2lwIGhlYWRlciByb3dcbiAgICAgIGNvbnN0IHJvdyA9IHJvd3NbaV1cbiAgICAgIGNvbnN0IGNvbHVtbnMgPSByb3dcbiAgICAgICAgLnNwbGl0KFwifFwiKVxuICAgICAgICAubWFwKChjb2wpID0+IGNvbC50cmltKCkpXG4gICAgICAgIC5maWx0ZXIoKGNvbCkgPT4gY29sKVxuXG4gICAgICBpZiAoY29sdW1ucy5sZW5ndGggPj0gMikge1xuICAgICAgICBjb25zdCBbZGF0ZSwgYXNzaWdubWVudCwgc3RhdHVzID0gXCJwZW5kaW5nXCJdID0gY29sdW1uc1xuICAgICAgICBpZiAoZGF0ZSAmJiBhc3NpZ25tZW50ICYmIHRoaXMuaXNWYWxpZERhdGUoZGF0ZSkpIHtcbiAgICAgICAgICBkdWVEYXRlcy5wdXNoKHsgZGF0ZSwgYXNzaWdubWVudCwgc3RhdHVzIH0pXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gZHVlRGF0ZXNcbiAgfVxuXG4gIHByaXZhdGUgaXNWYWxpZERhdGUoZGF0ZVN0cmluZzogc3RyaW5nKTogYm9vbGVhbiB7XG4gICAgY29uc3QgZGF0ZVJlZ2V4ID0gL15cXGR7NH0tXFxkezJ9LVxcZHsyfSQvXG4gICAgcmV0dXJuIGRhdGVSZWdleC50ZXN0KGRhdGVTdHJpbmcpICYmICFpc05hTihEYXRlLnBhcnNlKGRhdGVTdHJpbmcpKVxuICB9XG5cbiAgYXN5bmMgcGFyc2VEdWVEYXRlc0Zyb21Db3Vyc2UoXG4gICAgY291cnNlSWQ6IHN0cmluZyxcbiAgICBzdGFydERhdGU/OiBzdHJpbmcsXG4gICAgZW5kRGF0ZT86IHN0cmluZ1xuICApOiBQcm9taXNlPFxuICAgIEFycmF5PHsgZGF0ZTogc3RyaW5nOyBhc3NpZ25tZW50OiBzdHJpbmc7IHN0YXR1czogc3RyaW5nOyBzb3VyY2U6IHN0cmluZyB9PlxuICA+IHtcbiAgICBjb25zb2xlLmxvZyhgUGFyc2luZyBkdWUgZGF0ZXMgZm9yIGNvdXJzZTogJHtjb3Vyc2VJZH1gKVxuXG4gICAgdHJ5IHtcbiAgICAgIC8vIEZpbmQgYWxsIG5vdGVzIHJlbGF0ZWQgdG8gdGhlIGNvdXJzZVxuICAgICAgY29uc3QgY291cnNlTm90ZXMgPSBhd2FpdCB0aGlzLmZpbmRDb3Vyc2VOb3Rlcyhjb3Vyc2VJZClcblxuICAgICAgaWYgKGNvdXJzZU5vdGVzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICBjb25zb2xlLmxvZyhgTm8gbm90ZXMgZm91bmQgZm9yIGNvdXJzZTogJHtjb3Vyc2VJZH1gKVxuICAgICAgICByZXR1cm4gW11cbiAgICAgIH1cblxuICAgICAgLy8gUGFyc2UgZHVlIGRhdGVzIGZyb20gZWFjaCBub3RlXG4gICAgICBjb25zdCBhbGxEdWVEYXRlczogQXJyYXk8e1xuICAgICAgICBkYXRlOiBzdHJpbmdcbiAgICAgICAgYXNzaWdubWVudDogc3RyaW5nXG4gICAgICAgIHN0YXR1czogc3RyaW5nXG4gICAgICAgIHNvdXJjZTogc3RyaW5nXG4gICAgICB9PiA9IFtdXG5cbiAgICAgIGZvciAoY29uc3Qgbm90ZSBvZiBjb3Vyc2VOb3Rlcykge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGNvbnN0IGNvbnRlbnQgPSBhd2FpdCB0aGlzLmFwcC52YXVsdC5yZWFkKG5vdGUpXG4gICAgICAgICAgY29uc3QgZHVlRGF0ZXMgPSB0aGlzLnBhcnNlRHVlRGF0ZXNGcm9tTm90ZShjb250ZW50KVxuXG4gICAgICAgICAgLy8gQWRkIHNvdXJjZSBpbmZvcm1hdGlvblxuICAgICAgICAgIGNvbnN0IGR1ZURhdGVzV2l0aFNvdXJjZSA9IGR1ZURhdGVzLm1hcCgoZHVlRGF0ZSkgPT4gKHtcbiAgICAgICAgICAgIC4uLmR1ZURhdGUsXG4gICAgICAgICAgICBzb3VyY2U6IG5vdGUuYmFzZW5hbWVcbiAgICAgICAgICB9KSlcblxuICAgICAgICAgIGFsbER1ZURhdGVzLnB1c2goLi4uZHVlRGF0ZXNXaXRoU291cmNlKVxuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIHJlYWRpbmcgbm90ZSAke25vdGUucGF0aH06YCwgZXJyb3IpXG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgLy8gRmlsdGVyIGJ5IGRhdGUgcmFuZ2UgaWYgcHJvdmlkZWRcbiAgICAgIGxldCBmaWx0ZXJlZER1ZURhdGVzID0gYWxsRHVlRGF0ZXNcbiAgICAgIGlmIChzdGFydERhdGUgfHwgZW5kRGF0ZSkge1xuICAgICAgICBmaWx0ZXJlZER1ZURhdGVzID0gdGhpcy5maWx0ZXJCeURhdGVSYW5nZShcbiAgICAgICAgICBhbGxEdWVEYXRlcyxcbiAgICAgICAgICBzdGFydERhdGUsXG4gICAgICAgICAgZW5kRGF0ZVxuICAgICAgICApXG4gICAgICB9XG5cbiAgICAgIC8vIFNvcnQgYnkgZGF0ZVxuICAgICAgZmlsdGVyZWREdWVEYXRlcy5zb3J0KFxuICAgICAgICAoYSwgYikgPT4gbmV3IERhdGUoYS5kYXRlKS5nZXRUaW1lKCkgLSBuZXcgRGF0ZShiLmRhdGUpLmdldFRpbWUoKVxuICAgICAgKVxuXG4gICAgICBjb25zb2xlLmxvZyhcbiAgICAgICAgYEZvdW5kICR7ZmlsdGVyZWREdWVEYXRlcy5sZW5ndGh9IGR1ZSBkYXRlcyBmb3IgY291cnNlOiAke2NvdXJzZUlkfWBcbiAgICAgIClcbiAgICAgIHJldHVybiBmaWx0ZXJlZER1ZURhdGVzXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIHBhcnNpbmcgZHVlIGRhdGVzIGZvciBjb3Vyc2UgJHtjb3Vyc2VJZH06YCwgZXJyb3IpXG4gICAgICByZXR1cm4gW11cbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIGZpbmRDb3Vyc2VOb3Rlcyhjb3Vyc2VJZDogc3RyaW5nKTogUHJvbWlzZTxURmlsZVtdPiB7XG4gICAgY29uc3Qgbm90ZXM6IFRGaWxlW10gPSBbXVxuXG4gICAgLy8gR2V0IGFsbCBtYXJrZG93biBmaWxlcyBpbiB0aGUgdmF1bHRcbiAgICBjb25zdCBmaWxlcyA9IHRoaXMuYXBwLnZhdWx0LmdldE1hcmtkb3duRmlsZXMoKVxuXG4gICAgZm9yIChjb25zdCBmaWxlIG9mIGZpbGVzKSB7XG4gICAgICAvLyBDaGVjayBpZiB0aGUgZmlsZSBwYXRoIGNvbnRhaW5zIHRoZSBjb3Vyc2UgSUQgb3IgYmVsb25ncyB0byB0aGUgY291cnNlXG4gICAgICBpZiAoXG4gICAgICAgIGZpbGUucGF0aC5pbmNsdWRlcyhjb3Vyc2VJZCkgfHxcbiAgICAgICAgKGF3YWl0IHRoaXMubm90ZUJlbG9uZ3NUb0NvdXJzZShmaWxlLCBjb3Vyc2VJZCkpXG4gICAgICApIHtcbiAgICAgICAgbm90ZXMucHVzaChmaWxlKVxuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBub3Rlc1xuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBub3RlQmVsb25nc1RvQ291cnNlKFxuICAgIGZpbGU6IFRGaWxlLFxuICAgIGNvdXJzZUlkOiBzdHJpbmdcbiAgKTogUHJvbWlzZTxib29sZWFuPiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGNvbnRlbnQgPSBhd2FpdCB0aGlzLmFwcC52YXVsdC5yZWFkKGZpbGUpXG4gICAgICBjb25zdCBmcm9udG1hdHRlck1hdGNoID0gY29udGVudC5tYXRjaCgvXi0tLVxcbihbXFxzXFxTXSo/KVxcbi0tLS8pXG5cbiAgICAgIGlmIChmcm9udG1hdHRlck1hdGNoKSB7XG4gICAgICAgIGNvbnN0IGZyb250bWF0dGVyID0gZnJvbnRtYXR0ZXJNYXRjaFsxXVxuICAgICAgICAvLyBDaGVjayBpZiBjb3Vyc2VfaWQgaXMgaW4gdGhlIGZyb250bWF0dGVyXG4gICAgICAgIHJldHVybiAoXG4gICAgICAgICAgZnJvbnRtYXR0ZXIuaW5jbHVkZXMoYGNvdXJzZV9pZDogJHtjb3Vyc2VJZH1gKSB8fFxuICAgICAgICAgIGZyb250bWF0dGVyLmluY2x1ZGVzKGBjb3Vyc2VfaWQ6JHtjb3Vyc2VJZH1gKVxuICAgICAgICApXG4gICAgICB9XG5cbiAgICAgIHJldHVybiBmYWxzZVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFxuICAgICAgICBgRXJyb3IgY2hlY2tpbmcgaWYgbm90ZSAke2ZpbGUucGF0aH0gYmVsb25ncyB0byBjb3Vyc2UgJHtjb3Vyc2VJZH06YCxcbiAgICAgICAgZXJyb3JcbiAgICAgIClcbiAgICAgIHJldHVybiBmYWxzZVxuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgZmlsdGVyQnlEYXRlUmFuZ2UoXG4gICAgZHVlRGF0ZXM6IEFycmF5PHtcbiAgICAgIGRhdGU6IHN0cmluZ1xuICAgICAgYXNzaWdubWVudDogc3RyaW5nXG4gICAgICBzdGF0dXM6IHN0cmluZ1xuICAgICAgc291cmNlOiBzdHJpbmdcbiAgICB9PixcbiAgICBzdGFydERhdGU/OiBzdHJpbmcsXG4gICAgZW5kRGF0ZT86IHN0cmluZ1xuICApOiBBcnJheTx7XG4gICAgZGF0ZTogc3RyaW5nXG4gICAgYXNzaWdubWVudDogc3RyaW5nXG4gICAgc3RhdHVzOiBzdHJpbmdcbiAgICBzb3VyY2U6IHN0cmluZ1xuICB9PiB7XG4gICAgcmV0dXJuIGR1ZURhdGVzLmZpbHRlcigoZHVlRGF0ZSkgPT4ge1xuICAgICAgY29uc3QgZHVlRGF0ZVRpbWUgPSBuZXcgRGF0ZShkdWVEYXRlLmRhdGUpLmdldFRpbWUoKVxuXG4gICAgICBpZiAoc3RhcnREYXRlICYmIGR1ZURhdGVUaW1lIDwgbmV3IERhdGUoc3RhcnREYXRlKS5nZXRUaW1lKCkpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlXG4gICAgICB9XG5cbiAgICAgIGlmIChlbmREYXRlICYmIGR1ZURhdGVUaW1lID4gbmV3IERhdGUoZW5kRGF0ZSkuZ2V0VGltZSgpKSB7XG4gICAgICAgIHJldHVybiBmYWxzZVxuICAgICAgfVxuXG4gICAgICByZXR1cm4gdHJ1ZVxuICAgIH0pXG4gIH1cblxuICBhc3luYyBnZW5lcmF0ZUR1ZURhdGVzU3VtbWFyeShcbiAgICBjb3Vyc2VJZDogc3RyaW5nLFxuICAgIGR1ZURhdGVzOiBBcnJheTx7XG4gICAgICBkYXRlOiBzdHJpbmdcbiAgICAgIGFzc2lnbm1lbnQ6IHN0cmluZ1xuICAgICAgc3RhdHVzOiBzdHJpbmdcbiAgICAgIHNvdXJjZTogc3RyaW5nXG4gICAgfT5cbiAgKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgICBpZiAoZHVlRGF0ZXMubGVuZ3RoID09PSAwKSB7XG4gICAgICByZXR1cm4gYCMgRHVlIERhdGVzIFN1bW1hcnkgLSAke2NvdXJzZUlkfVxcblxcbk5vIGR1ZSBkYXRlcyBmb3VuZC5cXG5gXG4gICAgfVxuXG4gICAgLy8gR3JvdXAgYnkgc3RhdHVzXG4gICAgY29uc3QgYnlTdGF0dXMgPSBkdWVEYXRlcy5yZWR1Y2UoKGFjYywgZHVlRGF0ZSkgPT4ge1xuICAgICAgaWYgKCFhY2NbZHVlRGF0ZS5zdGF0dXNdKSB7XG4gICAgICAgIGFjY1tkdWVEYXRlLnN0YXR1c10gPSBbXVxuICAgICAgfVxuICAgICAgYWNjW2R1ZURhdGUuc3RhdHVzXS5wdXNoKGR1ZURhdGUpXG4gICAgICByZXR1cm4gYWNjXG4gICAgfSwge30gYXMgUmVjb3JkPHN0cmluZywgdHlwZW9mIGR1ZURhdGVzPilcblxuICAgIGxldCBjb250ZW50ID0gYCMgRHVlIERhdGVzIFN1bW1hcnkgLSAke2NvdXJzZUlkfVxcblxcbmBcbiAgICBjb250ZW50ICs9IGBUb3RhbCBhc3NpZ25tZW50czogJHtkdWVEYXRlcy5sZW5ndGh9XFxuXFxuYFxuXG4gICAgLy8gQWRkIHN1bW1hcnkgYnkgc3RhdHVzXG4gICAgZm9yIChjb25zdCBbc3RhdHVzLCBpdGVtc10gb2YgT2JqZWN0LmVudHJpZXMoYnlTdGF0dXMpKSB7XG4gICAgICBjb250ZW50ICs9IGAjIyAke3N0YXR1cy5jaGFyQXQoMCkudG9VcHBlckNhc2UoKSArIHN0YXR1cy5zbGljZSgxKX0gKCR7XG4gICAgICAgIGl0ZW1zLmxlbmd0aFxuICAgICAgfSlcXG5cXG5gXG4gICAgICBjb250ZW50ICs9IGB8IERhdGUgfCBBc3NpZ25tZW50IHwgU291cmNlIHxcXG5gXG4gICAgICBjb250ZW50ICs9IGB8IC0tLS0gfCAtLS0tLS0tLS0tIHwgLS0tLS0tIHxcXG5gXG5cbiAgICAgIGZvciAoY29uc3QgaXRlbSBvZiBpdGVtcykge1xuICAgICAgICBjb250ZW50ICs9IGB8ICR7aXRlbS5kYXRlfSB8ICR7aXRlbS5hc3NpZ25tZW50fSB8ICR7aXRlbS5zb3VyY2V9IHxcXG5gXG4gICAgICB9XG4gICAgICBjb250ZW50ICs9IGBcXG5gXG4gICAgfVxuXG4gICAgcmV0dXJuIGNvbnRlbnRcbiAgfVxuXG4gIGFzeW5jIGNyZWF0ZUR1ZURhdGVzU3VtbWFyeUZpbGUoXG4gICAgY291cnNlSWQ6IHN0cmluZyxcbiAgICBzdGFydERhdGU/OiBzdHJpbmcsXG4gICAgZW5kRGF0ZT86IHN0cmluZ1xuICApOiBQcm9taXNlPHZvaWQ+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgZHVlRGF0ZXMgPSBhd2FpdCB0aGlzLnBhcnNlRHVlRGF0ZXNGcm9tQ291cnNlKFxuICAgICAgICBjb3Vyc2VJZCxcbiAgICAgICAgc3RhcnREYXRlLFxuICAgICAgICBlbmREYXRlXG4gICAgICApXG5cbiAgICAgIGNvbnN0IHN1bW1hcnlDb250ZW50ID0gYXdhaXQgdGhpcy5nZW5lcmF0ZUR1ZURhdGVzU3VtbWFyeShcbiAgICAgICAgY291cnNlSWQsXG4gICAgICAgIGR1ZURhdGVzXG4gICAgICApXG5cbiAgICAgIC8vIENyZWF0ZSB0aGUgc3VtbWFyeSBmaWxlXG4gICAgICBjb25zdCBmaWxlTmFtZSA9IGAke2NvdXJzZUlkfSAtIER1ZSBEYXRlcyBTdW1tYXJ5Lm1kYFxuICAgICAgY29uc3QgZmlsZVBhdGggPSBgQ291cnNlcy8ke2NvdXJzZUlkfS8ke2ZpbGVOYW1lfWBcblxuICAgICAgdHJ5IHtcbiAgICAgICAgYXdhaXQgdGhpcy5hcHAudmF1bHQuY3JlYXRlKGZpbGVQYXRoLCBzdW1tYXJ5Q29udGVudClcbiAgICAgICAgY29uc29sZS5sb2coYENyZWF0ZWQgZHVlIGRhdGVzIHN1bW1hcnkgZmlsZTogJHtmaWxlUGF0aH1gKVxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgLy8gRmlsZSBtaWdodCBhbHJlYWR5IGV4aXN0LCB0cnkgdG8gdXBkYXRlIGl0XG4gICAgICAgIGNvbnN0IGV4aXN0aW5nRmlsZSA9IHRoaXMuYXBwLnZhdWx0LmdldEFic3RyYWN0RmlsZUJ5UGF0aChmaWxlUGF0aClcbiAgICAgICAgaWYgKGV4aXN0aW5nRmlsZSAmJiBleGlzdGluZ0ZpbGUgaW5zdGFuY2VvZiBURmlsZSkge1xuICAgICAgICAgIGF3YWl0IHRoaXMuYXBwLnZhdWx0Lm1vZGlmeShleGlzdGluZ0ZpbGUsIHN1bW1hcnlDb250ZW50KVxuICAgICAgICAgIGNvbnNvbGUubG9nKGBVcGRhdGVkIGR1ZSBkYXRlcyBzdW1tYXJ5IGZpbGU6ICR7ZmlsZVBhdGh9YClcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFxuICAgICAgICBgRXJyb3IgY3JlYXRpbmcgZHVlIGRhdGVzIHN1bW1hcnkgZm9yIGNvdXJzZSAke2NvdXJzZUlkfTpgLFxuICAgICAgICBlcnJvclxuICAgICAgKVxuICAgICAgdGhyb3cgZXJyb3JcbiAgICB9XG4gIH1cbn1cbiIsICIvLyBEYWlseSBub3RlcyBpbnRlZ3JhdGlvbiBmb3IgVHVja2VycyBUb29scyBwbHVnaW5cblxuaW1wb3J0IHsgQXBwLCBURmlsZSB9IGZyb20gXCJvYnNpZGlhblwiXG5cbmV4cG9ydCBjbGFzcyBEYWlseU5vdGVzSW50ZWdyYXRpb24ge1xuICBhcHA6IEFwcFxuXG4gIGNvbnN0cnVjdG9yKGFwcDogQXBwKSB7XG4gICAgdGhpcy5hcHAgPSBhcHBcbiAgfVxuXG4gIGFzeW5jIGdldFRvZGF5c0FjdGl2aXRpZXMoKTogUHJvbWlzZTxcbiAgICBBcnJheTx7IGZpbGU6IHN0cmluZzsgdHlwZTogc3RyaW5nOyBjb3Vyc2U/OiBzdHJpbmcgfT5cbiAgPiB7XG4gICAgY29uc29sZS5sb2coXCJHZXR0aW5nIHRvZGF5J3MgYWNhZGVtaWMgYWN0aXZpdGllc1wiKVxuXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHRvZGF5ID0gbmV3IERhdGUoKVxuICAgICAgY29uc3QgdG9kYXlTdHJpbmcgPSB0b2RheS50b0lTT1N0cmluZygpLnNwbGl0KFwiVFwiKVswXVxuXG4gICAgICAvLyBGaW5kIGZpbGVzIGNyZWF0ZWQgb3IgbW9kaWZpZWQgdG9kYXlcbiAgICAgIGNvbnN0IGZpbGVzID0gdGhpcy5hcHAudmF1bHQuZ2V0TWFya2Rvd25GaWxlcygpXG4gICAgICBjb25zdCB0b2RheXNGaWxlczogVEZpbGVbXSA9IFtdXG5cbiAgICAgIGZvciAoY29uc3QgZmlsZSBvZiBmaWxlcykge1xuICAgICAgICBjb25zdCBmaWxlRGF0ZSA9IHRoaXMuZXh0cmFjdERhdGVGcm9tUGF0aChmaWxlLnBhdGgpXG4gICAgICAgIGlmIChmaWxlRGF0ZSA9PT0gdG9kYXlTdHJpbmcpIHtcbiAgICAgICAgICB0b2RheXNGaWxlcy5wdXNoKGZpbGUpXG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgLy8gQW5hbHl6ZSBhY3Rpdml0aWVzXG4gICAgICBjb25zdCBhY3Rpdml0aWVzOiBBcnJheTx7IGZpbGU6IHN0cmluZzsgdHlwZTogc3RyaW5nOyBjb3Vyc2U/OiBzdHJpbmcgfT4gPVxuICAgICAgICBbXVxuXG4gICAgICBmb3IgKGNvbnN0IGZpbGUgb2YgdG9kYXlzRmlsZXMpIHtcbiAgICAgICAgY29uc3QgYWN0aXZpdHkgPSBhd2FpdCB0aGlzLmFuYWx5emVGaWxlQWN0aXZpdHkoZmlsZSlcbiAgICAgICAgaWYgKGFjdGl2aXR5KSB7XG4gICAgICAgICAgYWN0aXZpdGllcy5wdXNoKGFjdGl2aXR5KVxuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIGNvbnNvbGUubG9nKGBGb3VuZCAke2FjdGl2aXRpZXMubGVuZ3RofSBhY2FkZW1pYyBhY3Rpdml0aWVzIGZvciB0b2RheWApXG4gICAgICByZXR1cm4gYWN0aXZpdGllc1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZ2V0dGluZyB0b2RheSdzIGFjdGl2aXRpZXM6XCIsIGVycm9yKVxuICAgICAgcmV0dXJuIFtdXG4gICAgfVxuICB9XG5cbiAgYXN5bmMgZ2V0Q291cnNlQWN0aXZpdHlGb3JEYXRlKFxuICAgIGNvdXJzZUlkOiBzdHJpbmcsXG4gICAgZGF0ZTogc3RyaW5nXG4gICk6IFByb21pc2U8QXJyYXk8eyBmaWxlOiBzdHJpbmc7IHR5cGU6IHN0cmluZyB9Pj4ge1xuICAgIGNvbnNvbGUubG9nKGBHZXR0aW5nIGFjdGl2aXR5IGZvciBjb3Vyc2UgJHtjb3Vyc2VJZH0gb24gZGF0ZSAke2RhdGV9YClcblxuICAgIHRyeSB7XG4gICAgICAvLyBGaW5kIGZpbGVzIHJlbGF0ZWQgdG8gdGhlIGNvdXJzZSBtb2RpZmllZCBvbiB0aGUgZGF0ZVxuICAgICAgY29uc3QgY291cnNlRmlsZXMgPSBhd2FpdCB0aGlzLmZpbmRDb3Vyc2VGaWxlc0ZvckRhdGUoY291cnNlSWQsIGRhdGUpXG5cbiAgICAgIGNvbnN0IGFjdGl2aXRpZXM6IEFycmF5PHsgZmlsZTogc3RyaW5nOyB0eXBlOiBzdHJpbmcgfT4gPSBbXVxuXG4gICAgICBmb3IgKGNvbnN0IGZpbGUgb2YgY291cnNlRmlsZXMpIHtcbiAgICAgICAgY29uc3QgY29udGVudCA9IGF3YWl0IHRoaXMuYXBwLnZhdWx0LnJlYWQoZmlsZSlcbiAgICAgICAgY29uc3QgZmlsZVR5cGUgPSB0aGlzLmRldGVybWluZUZpbGVUeXBlKGZpbGUsIGNvbnRlbnQpXG5cbiAgICAgICAgYWN0aXZpdGllcy5wdXNoKHtcbiAgICAgICAgICBmaWxlOiBmaWxlLmJhc2VuYW1lLFxuICAgICAgICAgIHR5cGU6IGZpbGVUeXBlXG4gICAgICAgIH0pXG4gICAgICB9XG5cbiAgICAgIGNvbnNvbGUubG9nKFxuICAgICAgICBgRm91bmQgJHthY3Rpdml0aWVzLmxlbmd0aH0gYWN0aXZpdGllcyBmb3IgY291cnNlICR7Y291cnNlSWR9IG9uICR7ZGF0ZX1gXG4gICAgICApXG4gICAgICByZXR1cm4gYWN0aXZpdGllc1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFxuICAgICAgICBgRXJyb3IgZ2V0dGluZyBjb3Vyc2UgYWN0aXZpdHkgZm9yICR7Y291cnNlSWR9IG9uICR7ZGF0ZX06YCxcbiAgICAgICAgZXJyb3JcbiAgICAgIClcbiAgICAgIHJldHVybiBbXVxuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgZXh0cmFjdERhdGVGcm9tUGF0aChmaWxlUGF0aDogc3RyaW5nKTogc3RyaW5nIHwgbnVsbCB7XG4gICAgLy8gVHJ5IHRvIGV4dHJhY3QgZGF0ZSBmcm9tIGZpbGUgcGF0aCAoZS5nLiwgXCJEYWlseS8yMDI1LTAxLTE1Lm1kXCIgLT4gXCIyMDI1LTAxLTE1XCIpXG4gICAgY29uc3QgZGF0ZVJlZ2V4ID0gLyhcXGR7NH0tXFxkezJ9LVxcZHsyfSkvZ1xuICAgIGNvbnN0IG1hdGNoZXMgPSBmaWxlUGF0aC5tYXRjaChkYXRlUmVnZXgpXG4gICAgcmV0dXJuIG1hdGNoZXMgPyBtYXRjaGVzW21hdGNoZXMubGVuZ3RoIC0gMV0gOiBudWxsXG4gIH1cblxuICBwcml2YXRlIGFzeW5jIGFuYWx5emVGaWxlQWN0aXZpdHkoXG4gICAgZmlsZTogVEZpbGVcbiAgKTogUHJvbWlzZTx7IGZpbGU6IHN0cmluZzsgdHlwZTogc3RyaW5nOyBjb3Vyc2U/OiBzdHJpbmcgfSB8IG51bGw+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgY29udGVudCA9IGF3YWl0IHRoaXMuYXBwLnZhdWx0LnJlYWQoZmlsZSlcblxuICAgICAgLy8gRGV0ZXJtaW5lIGZpbGUgdHlwZSBiYXNlZCBvbiBjb250ZW50IGFuZCBwYXRoXG4gICAgICBjb25zdCBmaWxlVHlwZSA9IHRoaXMuZGV0ZXJtaW5lRmlsZVR5cGUoZmlsZSwgY29udGVudClcblxuICAgICAgLy8gRXh0cmFjdCBjb3Vyc2UgSUQgaWYgYXBwbGljYWJsZVxuICAgICAgY29uc3QgY291cnNlSWQgPVxuICAgICAgICB0aGlzLmV4dHJhY3RDb3Vyc2VJZEZyb21Db250ZW50KGNvbnRlbnQpIHx8XG4gICAgICAgIHRoaXMuZXh0cmFjdENvdXJzZUlkRnJvbVBhdGgoZmlsZS5wYXRoKVxuXG4gICAgICByZXR1cm4ge1xuICAgICAgICBmaWxlOiBmaWxlLmJhc2VuYW1lLFxuICAgICAgICB0eXBlOiBmaWxlVHlwZSxcbiAgICAgICAgY291cnNlOiBjb3Vyc2VJZCB8fCB1bmRlZmluZWRcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihgRXJyb3IgYW5hbHl6aW5nIGZpbGUgJHtmaWxlLnBhdGh9OmAsIGVycm9yKVxuICAgICAgcmV0dXJuIG51bGxcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGRldGVybWluZUZpbGVUeXBlKGZpbGU6IFRGaWxlLCBjb250ZW50OiBzdHJpbmcpOiBzdHJpbmcge1xuICAgIGNvbnN0IHBhdGggPSBmaWxlLnBhdGgudG9Mb3dlckNhc2UoKVxuXG4gICAgLy8gQ2hlY2sgZm9yIGRhaWx5IG5vdGVzXG4gICAgaWYgKFxuICAgICAgcGF0aC5pbmNsdWRlcyhcImRhaWx5XCIpIHx8XG4gICAgICBjb250ZW50LmluY2x1ZGVzKFwiY29udGVudF90eXBlOiBkYWlseV9ub3RlXCIpXG4gICAgKSB7XG4gICAgICByZXR1cm4gXCJkYWlseV9ub3RlXCJcbiAgICB9XG5cbiAgICAvLyBDaGVjayBmb3IgY291cnNlLXJlbGF0ZWQgZmlsZXNcbiAgICBpZiAocGF0aC5pbmNsdWRlcyhcImNvdXJzZXNcIikgfHwgY29udGVudC5pbmNsdWRlcyhcImNvdXJzZV9pZDpcIikpIHtcbiAgICAgIGlmIChjb250ZW50LmluY2x1ZGVzKFwiY29udGVudF90eXBlOiBjb3Vyc2VfaG9tZXBhZ2VcIikpIHtcbiAgICAgICAgcmV0dXJuIFwiY291cnNlX2hvbWVwYWdlXCJcbiAgICAgIH1cbiAgICAgIGlmIChjb250ZW50LmluY2x1ZGVzKFwiY29udGVudF90eXBlOiBtb2R1bGVcIikpIHtcbiAgICAgICAgcmV0dXJuIFwibW9kdWxlXCJcbiAgICAgIH1cbiAgICAgIGlmIChjb250ZW50LmluY2x1ZGVzKFwiY29udGVudF90eXBlOiBjaGFwdGVyXCIpKSB7XG4gICAgICAgIHJldHVybiBcImNoYXB0ZXJcIlxuICAgICAgfVxuICAgICAgaWYgKGNvbnRlbnQuaW5jbHVkZXMoXCJjb250ZW50X3R5cGU6IGFzc2lnbm1lbnRcIikpIHtcbiAgICAgICAgcmV0dXJuIFwiYXNzaWdubWVudFwiXG4gICAgICB9XG4gICAgICByZXR1cm4gXCJjb3Vyc2Vfbm90ZVwiXG4gICAgfVxuXG4gICAgLy8gQ2hlY2sgZm9yIHZvY2FidWxhcnkgZW50cmllc1xuICAgIGlmIChjb250ZW50LmluY2x1ZGVzKFwiIyMgXCIpICYmIGNvbnRlbnQubWF0Y2goL15cXCpcXCpUZXJtXFwqXFwqOi9tKSkge1xuICAgICAgcmV0dXJuIFwidm9jYWJ1bGFyeV9lbnRyeVwiXG4gICAgfVxuXG4gICAgcmV0dXJuIFwib3RoZXJcIlxuICB9XG5cbiAgcHJpdmF0ZSBleHRyYWN0Q291cnNlSWRGcm9tQ29udGVudChjb250ZW50OiBzdHJpbmcpOiBzdHJpbmcgfCBudWxsIHtcbiAgICBjb25zdCBjb3Vyc2VJZFJlZ2V4ID0gL2NvdXJzZV9pZDpcXHMqKFtBLVpdezIsNH0tXFxkezN9KS9cbiAgICBjb25zdCBtYXRjaCA9IGNvbnRlbnQubWF0Y2goY291cnNlSWRSZWdleClcbiAgICByZXR1cm4gbWF0Y2ggPyBtYXRjaFsxXSA6IG51bGxcbiAgfVxuXG4gIHByaXZhdGUgZXh0cmFjdENvdXJzZUlkRnJvbVBhdGgoZmlsZVBhdGg6IHN0cmluZyk6IHN0cmluZyB8IG51bGwge1xuICAgIGNvbnN0IGNvdXJzZUlkUmVnZXggPSAvKFtBLVpdezIsNH0tXFxkezN9KS9nXG4gICAgY29uc3QgbWF0Y2hlcyA9IGZpbGVQYXRoLm1hdGNoKGNvdXJzZUlkUmVnZXgpXG4gICAgcmV0dXJuIG1hdGNoZXMgPyBtYXRjaGVzW21hdGNoZXMubGVuZ3RoIC0gMV0gOiBudWxsXG4gIH1cblxuICBwcml2YXRlIGFzeW5jIGZpbmRDb3Vyc2VGaWxlc0ZvckRhdGUoXG4gICAgY291cnNlSWQ6IHN0cmluZyxcbiAgICBkYXRlOiBzdHJpbmdcbiAgKTogUHJvbWlzZTxURmlsZVtdPiB7XG4gICAgY29uc3QgZmlsZXM6IFRGaWxlW10gPSBbXVxuXG4gICAgLy8gR2V0IGFsbCBmaWxlcyBhbmQgZmlsdGVyIGJ5IGNvdXJzZSBJRCBhbmQgZGF0ZVxuICAgIGNvbnN0IGFsbEZpbGVzID0gdGhpcy5hcHAudmF1bHQuZ2V0TWFya2Rvd25GaWxlcygpXG5cbiAgICBmb3IgKGNvbnN0IGZpbGUgb2YgYWxsRmlsZXMpIHtcbiAgICAgIC8vIENoZWNrIGlmIGZpbGUgYmVsb25ncyB0byB0aGUgY291cnNlXG4gICAgICBpZiAoXG4gICAgICAgIGZpbGUucGF0aC5pbmNsdWRlcyhjb3Vyc2VJZCkgfHxcbiAgICAgICAgKGF3YWl0IHRoaXMuZmlsZUJlbG9uZ3NUb0NvdXJzZShmaWxlLCBjb3Vyc2VJZCkpXG4gICAgICApIHtcbiAgICAgICAgLy8gQ2hlY2sgaWYgZmlsZSB3YXMgbW9kaWZpZWQgb24gdGhlIHNwZWNpZmllZCBkYXRlXG4gICAgICAgIGNvbnN0IGZpbGVEYXRlID0gdGhpcy5leHRyYWN0RGF0ZUZyb21QYXRoKGZpbGUucGF0aClcbiAgICAgICAgaWYgKGZpbGVEYXRlID09PSBkYXRlKSB7XG4gICAgICAgICAgZmlsZXMucHVzaChmaWxlKVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIGZpbGVzXG4gIH1cblxuICBwcml2YXRlIGFzeW5jIGZpbGVCZWxvbmdzVG9Db3Vyc2UoXG4gICAgZmlsZTogVEZpbGUsXG4gICAgY291cnNlSWQ6IHN0cmluZ1xuICApOiBQcm9taXNlPGJvb2xlYW4+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgY29udGVudCA9IGF3YWl0IHRoaXMuYXBwLnZhdWx0LnJlYWQoZmlsZSlcbiAgICAgIHJldHVybiB0aGlzLmV4dHJhY3RDb3Vyc2VJZEZyb21Db250ZW50KGNvbnRlbnQpID09PSBjb3Vyc2VJZFxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFxuICAgICAgICBgRXJyb3IgY2hlY2tpbmcgaWYgZmlsZSAke2ZpbGUucGF0aH0gYmVsb25ncyB0byBjb3Vyc2UgJHtjb3Vyc2VJZH06YCxcbiAgICAgICAgZXJyb3JcbiAgICAgIClcbiAgICAgIHJldHVybiBmYWxzZVxuICAgIH1cbiAgfVxuXG4gIGFzeW5jIGdlbmVyYXRlRGFpbHlTdW1tYXJ5KGRhdGU/OiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz4ge1xuICAgIGNvbnN0IHRhcmdldERhdGUgPSBkYXRlIHx8IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zcGxpdChcIlRcIilbMF1cbiAgICBjb25zdCBhY3Rpdml0aWVzID0gYXdhaXQgdGhpcy5nZXRDb3Vyc2VBY3Rpdml0eUZvckRhdGUoXCJcIiwgdGFyZ2V0RGF0ZSlcblxuICAgIGlmIChhY3Rpdml0aWVzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgcmV0dXJuIGAjIEFjYWRlbWljIEFjdGl2aXRpZXMgLSAke3RhcmdldERhdGV9XFxuXFxuTm8gYWNhZGVtaWMgYWN0aXZpdGllcyByZWNvcmRlZCBmb3IgdGhpcyBkYXRlLlxcbmBcbiAgICB9XG5cbiAgICAvLyBHcm91cCBhY3Rpdml0aWVzIGJ5IGNvdXJzZVxuICAgIGNvbnN0IGJ5Q291cnNlOiBSZWNvcmQ8c3RyaW5nLCB0eXBlb2YgYWN0aXZpdGllcz4gPSB7fVxuICAgIGNvbnN0IG5vQ291cnNlOiB0eXBlb2YgYWN0aXZpdGllcyA9IFtdXG5cbiAgICBmb3IgKGNvbnN0IGFjdGl2aXR5IG9mIGFjdGl2aXRpZXMpIHtcbiAgICAgIGlmIChhY3Rpdml0eS5maWxlLmluY2x1ZGVzKFwiQ291cnNlcy9cIikpIHtcbiAgICAgICAgLy8gRXh0cmFjdCBjb3Vyc2UgSUQgZnJvbSBwYXRoXG4gICAgICAgIGNvbnN0IHBhdGhQYXJ0cyA9IGFjdGl2aXR5LmZpbGUuc3BsaXQoXCIvXCIpXG4gICAgICAgIGNvbnN0IGNvdXJzZUluZGV4ID0gcGF0aFBhcnRzLmZpbmRJbmRleCgocGFydCkgPT4gcGFydC5pbmNsdWRlcyhcIi1cIikpXG4gICAgICAgIGlmIChjb3Vyc2VJbmRleCA+PSAwKSB7XG4gICAgICAgICAgY29uc3QgY291cnNlSWQgPSBwYXRoUGFydHNbY291cnNlSW5kZXhdXG4gICAgICAgICAgaWYgKCFieUNvdXJzZVtjb3Vyc2VJZF0pIHtcbiAgICAgICAgICAgIGJ5Q291cnNlW2NvdXJzZUlkXSA9IFtdXG4gICAgICAgICAgfVxuICAgICAgICAgIGJ5Q291cnNlW2NvdXJzZUlkXS5wdXNoKGFjdGl2aXR5KVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIG5vQ291cnNlLnB1c2goYWN0aXZpdHkpXG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIG5vQ291cnNlLnB1c2goYWN0aXZpdHkpXG4gICAgICB9XG4gICAgfVxuXG4gICAgbGV0IGNvbnRlbnQgPSBgIyBBY2FkZW1pYyBBY3Rpdml0aWVzIC0gJHt0YXJnZXREYXRlfVxcblxcbmBcbiAgICBjb250ZW50ICs9IGBUb3RhbCBhY3Rpdml0aWVzOiAke2FjdGl2aXRpZXMubGVuZ3RofVxcblxcbmBcblxuICAgIC8vIEFkZCBhY3Rpdml0aWVzIGJ5IGNvdXJzZVxuICAgIGZvciAoY29uc3QgW2NvdXJzZUlkLCBjb3Vyc2VBY3Rpdml0aWVzXSBvZiBPYmplY3QuZW50cmllcyhieUNvdXJzZSkpIHtcbiAgICAgIGNvbnRlbnQgKz0gYCMjICR7Y291cnNlSWR9XFxuXFxuYFxuICAgICAgY29udGVudCArPSBgfCBGaWxlIHwgVHlwZSB8XFxuYFxuICAgICAgY29udGVudCArPSBgfCAtLS0tIHwgLS0tLSB8XFxuYFxuXG4gICAgICBmb3IgKGNvbnN0IGFjdGl2aXR5IG9mIGNvdXJzZUFjdGl2aXRpZXMpIHtcbiAgICAgICAgY29udGVudCArPSBgfCAke2FjdGl2aXR5LmZpbGV9IHwgJHthY3Rpdml0eS50eXBlfSB8XFxuYFxuICAgICAgfVxuICAgICAgY29udGVudCArPSBgXFxuYFxuICAgIH1cblxuICAgIC8vIEFkZCBhY3Rpdml0aWVzIHdpdGhvdXQgc3BlY2lmaWMgY291cnNlXG4gICAgaWYgKG5vQ291cnNlLmxlbmd0aCA+IDApIHtcbiAgICAgIGNvbnRlbnQgKz0gYCMjIE90aGVyIEFjdGl2aXRpZXNcXG5cXG5gXG4gICAgICBjb250ZW50ICs9IGB8IEZpbGUgfCBUeXBlIHxcXG5gXG4gICAgICBjb250ZW50ICs9IGB8IC0tLS0gfCAtLS0tIHxcXG5gXG5cbiAgICAgIGZvciAoY29uc3QgYWN0aXZpdHkgb2Ygbm9Db3Vyc2UpIHtcbiAgICAgICAgY29udGVudCArPSBgfCAke2FjdGl2aXR5LmZpbGV9IHwgJHthY3Rpdml0eS50eXBlfSB8XFxuYFxuICAgICAgfVxuICAgICAgY29udGVudCArPSBgXFxuYFxuICAgIH1cblxuICAgIHJldHVybiBjb250ZW50XG4gIH1cblxuICBhc3luYyBjcmVhdGVEYWlseVN1bW1hcnlGaWxlKGRhdGU/OiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgdGFyZ2V0RGF0ZSA9IGRhdGUgfHwgbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNwbGl0KFwiVFwiKVswXVxuICAgICAgY29uc3Qgc3VtbWFyeUNvbnRlbnQgPSBhd2FpdCB0aGlzLmdlbmVyYXRlRGFpbHlTdW1tYXJ5KHRhcmdldERhdGUpXG5cbiAgICAgIC8vIENyZWF0ZSB0aGUgc3VtbWFyeSBmaWxlXG4gICAgICBjb25zdCBmaWxlTmFtZSA9IGAke3RhcmdldERhdGV9IC0gQWNhZGVtaWMgU3VtbWFyeS5tZGBcbiAgICAgIGNvbnN0IGZpbGVQYXRoID0gYERhaWx5LyR7ZmlsZU5hbWV9YFxuXG4gICAgICB0cnkge1xuICAgICAgICBhd2FpdCB0aGlzLmFwcC52YXVsdC5jcmVhdGUoZmlsZVBhdGgsIHN1bW1hcnlDb250ZW50KVxuICAgICAgICBjb25zb2xlLmxvZyhgQ3JlYXRlZCBkYWlseSBzdW1tYXJ5IGZpbGU6ICR7ZmlsZVBhdGh9YClcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIC8vIEZpbGUgbWlnaHQgYWxyZWFkeSBleGlzdCwgdHJ5IHRvIHVwZGF0ZSBpdFxuICAgICAgICBjb25zdCBleGlzdGluZ0ZpbGUgPSB0aGlzLmFwcC52YXVsdC5nZXRBYnN0cmFjdEZpbGVCeVBhdGgoZmlsZVBhdGgpXG4gICAgICAgIGlmIChleGlzdGluZ0ZpbGUgJiYgZXhpc3RpbmdGaWxlIGluc3RhbmNlb2YgVEZpbGUpIHtcbiAgICAgICAgICBhd2FpdCB0aGlzLmFwcC52YXVsdC5tb2RpZnkoZXhpc3RpbmdGaWxlLCBzdW1tYXJ5Q29udGVudClcbiAgICAgICAgICBjb25zb2xlLmxvZyhgVXBkYXRlZCBkYWlseSBzdW1tYXJ5IGZpbGU6ICR7ZmlsZVBhdGh9YClcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKGBFcnJvciBjcmVhdGluZyBkYWlseSBzdW1tYXJ5IGZvciAke2RhdGV9OmAsIGVycm9yKVxuICAgICAgdGhyb3cgZXJyb3JcbiAgICB9XG4gIH1cbn1cbiIsICJpbXBvcnQgeyBBcHAsIE1vZGFsLCBTZXR0aW5nLCBUZXh0QXJlYUNvbXBvbmVudCB9IGZyb20gXCJvYnNpZGlhblwiO1xuXG5pbnRlcmZhY2UgQXNzaWdubWVudCB7XG4gIG5hbWU6IHN0cmluZztcbiAgZHVlRGF0ZTogc3RyaW5nO1xuICB0eXBlOiBzdHJpbmc7XG4gIHBvaW50czogc3RyaW5nO1xuICBkZXNjcmlwdGlvbjogc3RyaW5nO1xufVxuXG5leHBvcnQgY2xhc3MgQXNzaWdubWVudHNNb2RhbCBleHRlbmRzIE1vZGFsIHtcbiAgYXNzaWdubWVudHM6IEFzc2lnbm1lbnRbXTtcbiAgY291cnNlTmFtZTogc3RyaW5nO1xuICBjb3Vyc2VJZDogc3RyaW5nO1xuICBvblN1Ym1pdDogKGFzc2lnbm1lbnRzOiBBc3NpZ25tZW50W10sIGNvdXJzZU5hbWU6IHN0cmluZywgY291cnNlSWQ6IHN0cmluZykgPT4gdm9pZDtcblxuICBjb25zdHJ1Y3RvcihcbiAgICBhcHA6IEFwcCxcbiAgICBjb3Vyc2VOYW1lOiBzdHJpbmcsXG4gICAgY291cnNlSWQ6IHN0cmluZyxcbiAgICBvblN1Ym1pdDogKGFzc2lnbm1lbnRzOiBBc3NpZ25tZW50W10sIGNvdXJzZU5hbWU6IHN0cmluZywgY291cnNlSWQ6IHN0cmluZykgPT4gdm9pZFxuICApIHtcbiAgICBzdXBlcihhcHApO1xuICAgIHRoaXMuYXNzaWdubWVudHMgPSBbeyBuYW1lOiBcIlwiLCBkdWVEYXRlOiBcIlwiLCB0eXBlOiBcIlwiLCBwb2ludHM6IFwiXCIsIGRlc2NyaXB0aW9uOiBcIlwiIH1dO1xuICAgIHRoaXMuY291cnNlTmFtZSA9IGNvdXJzZU5hbWU7XG4gICAgdGhpcy5jb3Vyc2VJZCA9IGNvdXJzZUlkO1xuICAgIHRoaXMub25TdWJtaXQgPSBvblN1Ym1pdDtcbiAgfVxuXG4gIG9uT3BlbigpIHtcbiAgICBjb25zdCB7IGNvbnRlbnRFbCB9ID0gdGhpcztcbiAgICBjb250ZW50RWwuZW1wdHkoKTtcbiAgICBjb250ZW50RWwuYWRkQ2xhc3MoXCJ0dWNrZXJzLXRvb2xzLWFzc2lnbm1lbnRzLW1vZGFsXCIpO1xuXG4gICAgY29udGVudEVsLmNyZWF0ZUVsKFwiaDJcIiwgeyB0ZXh0OiBcIkNyZWF0ZSBNdWx0aXBsZSBBc3NpZ25tZW50c1wiIH0pO1xuXG4gICAgLy8gQ291cnNlIGluZm9ybWF0aW9uIGRpc3BsYXlcbiAgICBuZXcgU2V0dGluZyhjb250ZW50RWwpXG4gICAgICAuc2V0TmFtZShcIkNvdXJzZVwiKVxuICAgICAgLnNldERlc2MoYCR7dGhpcy5jb3Vyc2VOYW1lfSAoJHt0aGlzLmNvdXJzZUlkfSlgKVxuICAgICAgLnNldERpc2FibGVkKHRydWUpO1xuXG4gICAgLy8gQ29udGFpbmVyIGZvciBhc3NpZ25tZW50IGxpc3RcbiAgICBjb25zdCBhc3NpZ25tZW50c0NvbnRhaW5lciA9IGNvbnRlbnRFbC5jcmVhdGVEaXYoeyBjbHM6IFwiYXNzaWdubWVudHMtY29udGFpbmVyXCIgfSk7XG5cbiAgICAvLyBBZGQgZmlyc3QgYXNzaWdubWVudFxuICAgIHRoaXMuYWRkQXNzaWdubWVudFNlY3Rpb24oYXNzaWdubWVudHNDb250YWluZXIsIDApO1xuXG4gICAgLy8gQWRkIGFzc2lnbm1lbnQgYnV0dG9uXG4gICAgbmV3IFNldHRpbmcoY29udGVudEVsKVxuICAgICAgLmFkZEJ1dHRvbigoYnRuKSA9PlxuICAgICAgICBidG5cbiAgICAgICAgICAuc2V0QnV0dG9uVGV4dChcIkFkZCBBc3NpZ25tZW50XCIpXG4gICAgICAgICAgLnNldEN0YSgpXG4gICAgICAgICAgLm9uQ2xpY2soKCkgPT4ge1xuICAgICAgICAgICAgY29uc3QgbmV3SW5kZXggPSB0aGlzLmFzc2lnbm1lbnRzLmxlbmd0aDtcbiAgICAgICAgICAgIHRoaXMuYXNzaWdubWVudHMucHVzaCh7IG5hbWU6IFwiXCIsIGR1ZURhdGU6IFwiXCIsIHR5cGU6IFwiXCIsIHBvaW50czogXCJcIiwgZGVzY3JpcHRpb246IFwiXCIgfSk7XG4gICAgICAgICAgICB0aGlzLmFkZEFzc2lnbm1lbnRTZWN0aW9uKGFzc2lnbm1lbnRzQ29udGFpbmVyLCBuZXdJbmRleCk7XG4gICAgICAgICAgfSlcbiAgICAgICk7XG5cbiAgICAvLyBTdWJtaXQgYnV0dG9uXG4gICAgbmV3IFNldHRpbmcoY29udGVudEVsKVxuICAgICAgLmFkZEJ1dHRvbigoYnRuKSA9PlxuICAgICAgICBidG5cbiAgICAgICAgICAuc2V0QnV0dG9uVGV4dChcIkNyZWF0ZSBBc3NpZ25tZW50c1wiKVxuICAgICAgICAgIC5zZXRDdGEoKVxuICAgICAgICAgIC5vbkNsaWNrKCgpID0+IHtcbiAgICAgICAgICAgIC8vIEZpbHRlciBvdXQgZW1wdHkgYXNzaWdubWVudHNcbiAgICAgICAgICAgIGNvbnN0IHZhbGlkQXNzaWdubWVudHMgPSB0aGlzLmFzc2lnbm1lbnRzLmZpbHRlcihcbiAgICAgICAgICAgICAgKGEpID0+IGEubmFtZS50cmltKCkgIT09IFwiXCIgfHwgYS5kdWVEYXRlLnRyaW0oKSAhPT0gXCJcIlxuICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIHRoaXMub25TdWJtaXQodmFsaWRBc3NpZ25tZW50cywgdGhpcy5jb3Vyc2VOYW1lLCB0aGlzLmNvdXJzZUlkKTtcbiAgICAgICAgICAgIHRoaXMuY2xvc2UoKTtcbiAgICAgICAgICB9KVxuICAgICAgKTtcbiAgfVxuXG4gIGFkZEFzc2lnbm1lbnRTZWN0aW9uKGNvbnRhaW5lcjogSFRNTEVsZW1lbnQsIGluZGV4OiBudW1iZXIpIHtcbiAgICBjb25zdCBzZWN0aW9uID0gY29udGFpbmVyLmNyZWF0ZURpdih7IGNsczogXCJhc3NpZ25tZW50LXNlY3Rpb25cIiB9KTtcbiAgICBzZWN0aW9uLmNyZWF0ZUVsKFwiaDNcIiwgeyB0ZXh0OiBgQXNzaWdubWVudCAjJHtpbmRleCArIDF9YCB9KTtcblxuICAgIG5ldyBTZXR0aW5nKHNlY3Rpb24pXG4gICAgICAuc2V0TmFtZShcIkFzc2lnbm1lbnQgTmFtZVwiKVxuICAgICAgLmFkZFRleHQoKHRleHQpID0+XG4gICAgICAgIHRleHRcbiAgICAgICAgICAuc2V0UGxhY2Vob2xkZXIoXCJFbnRlciBhc3NpZ25tZW50IG5hbWVcIilcbiAgICAgICAgICAuc2V0VmFsdWUodGhpcy5hc3NpZ25tZW50c1tpbmRleF0ubmFtZSlcbiAgICAgICAgICAub25DaGFuZ2UoKHZhbHVlKSA9PiB7XG4gICAgICAgICAgICB0aGlzLmFzc2lnbm1lbnRzW2luZGV4XS5uYW1lID0gdmFsdWU7XG4gICAgICAgICAgfSlcbiAgICAgICk7XG5cbiAgICBuZXcgU2V0dGluZyhzZWN0aW9uKVxuICAgICAgLnNldE5hbWUoXCJEdWUgRGF0ZVwiKVxuICAgICAgLnNldERlc2MoXCJGb3JtYXQ6IFlZWVktTU0tRERcIilcbiAgICAgIC5hZGRUZXh0KCh0ZXh0KSA9PlxuICAgICAgICB0ZXh0XG4gICAgICAgICAgLnNldFBsYWNlaG9sZGVyKFwiMjAyNC0wMS0xNVwiKVxuICAgICAgICAgIC5zZXRWYWx1ZSh0aGlzLmFzc2lnbm1lbnRzW2luZGV4XS5kdWVEYXRlKVxuICAgICAgICAgIC5vbkNoYW5nZSgodmFsdWUpID0+IHtcbiAgICAgICAgICAgIHRoaXMuYXNzaWdubWVudHNbaW5kZXhdLmR1ZURhdGUgPSB2YWx1ZTtcbiAgICAgICAgICB9KVxuICAgICAgKTtcblxuICAgIG5ldyBTZXR0aW5nKHNlY3Rpb24pXG4gICAgICAuc2V0TmFtZShcIkFzc2lnbm1lbnQgVHlwZVwiKVxuICAgICAgLmFkZFRleHQoKHRleHQpID0+XG4gICAgICAgIHRleHRcbiAgICAgICAgICAuc2V0UGxhY2Vob2xkZXIoXCJlLmcuLCBIb21ld29yaywgUXVpeiwgRXhhbVwiKVxuICAgICAgICAgIC5zZXRWYWx1ZSh0aGlzLmFzc2lnbm1lbnRzW2luZGV4XS50eXBlKVxuICAgICAgICAgIC5vbkNoYW5nZSgodmFsdWUpID0+IHtcbiAgICAgICAgICAgIHRoaXMuYXNzaWdubWVudHNbaW5kZXhdLnR5cGUgPSB2YWx1ZTtcbiAgICAgICAgICB9KVxuICAgICAgKTtcblxuICAgIG5ldyBTZXR0aW5nKHNlY3Rpb24pXG4gICAgICAuc2V0TmFtZShcIlBvaW50c1wiKVxuICAgICAgLmFkZFRleHQoKHRleHQpID0+XG4gICAgICAgIHRleHRcbiAgICAgICAgICAuc2V0UGxhY2Vob2xkZXIoXCJlLmcuLCAxMDBcIilcbiAgICAgICAgICAuc2V0VmFsdWUodGhpcy5hc3NpZ25tZW50c1tpbmRleF0ucG9pbnRzKVxuICAgICAgICAgIC5vbkNoYW5nZSgodmFsdWUpID0+IHtcbiAgICAgICAgICAgIHRoaXMuYXNzaWdubWVudHNbaW5kZXhdLnBvaW50cyA9IHZhbHVlO1xuICAgICAgICAgIH0pXG4gICAgICApO1xuXG4gICAgbmV3IFNldHRpbmcoc2VjdGlvbilcbiAgICAgIC5zZXROYW1lKFwiRGVzY3JpcHRpb25cIilcbiAgICAgIC5hZGRUZXh0QXJlYSgodGV4dCkgPT5cbiAgICAgICAgdGV4dFxuICAgICAgICAgIC5zZXRQbGFjZWhvbGRlcihcIkVudGVyIGFzc2lnbm1lbnQgZGVzY3JpcHRpb25cIilcbiAgICAgICAgICAuc2V0VmFsdWUodGhpcy5hc3NpZ25tZW50c1tpbmRleF0uZGVzY3JpcHRpb24pXG4gICAgICAgICAgLm9uQ2hhbmdlKCh2YWx1ZSkgPT4ge1xuICAgICAgICAgICAgdGhpcy5hc3NpZ25tZW50c1tpbmRleF0uZGVzY3JpcHRpb24gPSB2YWx1ZTtcbiAgICAgICAgICB9KVxuICAgICAgKTtcblxuICAgIC8vIEFkZCByZW1vdmUgYnV0dG9uIGlmIHRoZXJlJ3MgbW9yZSB0aGFuIG9uZSBhc3NpZ25tZW50XG4gICAgaWYgKHRoaXMuYXNzaWdubWVudHMubGVuZ3RoID4gMSkge1xuICAgICAgbmV3IFNldHRpbmcoc2VjdGlvbilcbiAgICAgICAgLmFkZEJ1dHRvbigoYnRuKSA9PlxuICAgICAgICAgIGJ0blxuICAgICAgICAgICAgLnNldEJ1dHRvblRleHQoXCJSZW1vdmVcIilcbiAgICAgICAgICAgIC5vbkNsaWNrKCgpID0+IHtcbiAgICAgICAgICAgICAgdGhpcy5hc3NpZ25tZW50cy5zcGxpY2UoaW5kZXgsIDEpO1xuICAgICAgICAgICAgICBzZWN0aW9uLnJlbW92ZSgpO1xuICAgICAgICAgICAgICB0aGlzLnJlbnVtYmVyQXNzaWdubWVudHMoKTtcbiAgICAgICAgICAgIH0pXG4gICAgICAgICk7XG4gICAgfVxuICB9XG5cbiAgcmVudW1iZXJBc3NpZ25tZW50cygpIHtcbiAgICBjb25zdCBzZWN0aW9ucyA9IHRoaXMuY29udGVudEVsLnF1ZXJ5U2VsZWN0b3JBbGwoXCIuYXNzaWdubWVudC1zZWN0aW9uXCIpO1xuICAgIHNlY3Rpb25zLmZvckVhY2goKHNlY3Rpb24sIGluZGV4KSA9PiB7XG4gICAgICBjb25zdCBoZWFkZXIgPSBzZWN0aW9uLnF1ZXJ5U2VsZWN0b3IoXCJoM1wiKTtcbiAgICAgIGlmIChoZWFkZXIpIHtcbiAgICAgICAgaGVhZGVyLnRleHRDb250ZW50ID0gYEFzc2lnbm1lbnQgIyR7aW5kZXggKyAxfWA7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cblxuICBvbkNsb3NlKCkge1xuICAgIGNvbnN0IHsgY29udGVudEVsIH0gPSB0aGlzO1xuICAgIGNvbnRlbnRFbC5lbXB0eSgpO1xuICB9XG59IiwgIi8qKlxuICogRGF0YXZpZXcgZnVuY3Rpb25zIGZvciBUdWNrZXJzIFRvb2xzXG4gKiBUaGVzZSBmdW5jdGlvbnMgcHJvdmlkZSBlbmhhbmNlZCBwcm9jZXNzaW5nIGNhcGFiaWxpdGllcyBmb3IgY291cnNlIHZvY2FidWxhcnkgYW5kIGR1ZSBkYXRlc1xuICovXG5cbi8qKlxuICogUHJvY2Vzc2VzIGFuZCBkaXNwbGF5cyBjb3Vyc2Ugdm9jYWJ1bGFyeSBmcm9tIGFsbCBub3RlcyBhc3NvY2lhdGVkIHdpdGggYSBjb3Vyc2VcbiAqIEBwYXJhbSBkdiAtIFRoZSBkYXRhdmlldyBBUEkgb2JqZWN0XG4gKiBAcGFyYW0gY291cnNlSWQgLSBUaGUgY291cnNlIGlkZW50aWZpZXIgdG8gc2VhcmNoIGZvclxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcHJvY2Vzc0NvdXJzZVZvY2FidWxhcnkoZHY6IGFueSwgY291cnNlSWQ6IHN0cmluZykge1xuICAgIHRyeSB7XG4gICAgICAgIC8vIEZpbmQgYWxsIHBhZ2VzIHdpdGggdGhlIGNvdXJzZSBJRCB0YWdcbiAgICAgICAgY29uc3QgcGFnZXMgPSBkdi5wYWdlcyhjb3Vyc2VJZClcbiAgICAgICAgICAgIC5maWx0ZXIoKHA6IGFueSkgPT4gcC5maWxlLmV4dCA9PT0gXCJtZFwiICYmIHAuZmlsZS5uYW1lICE9PSBjb3Vyc2VJZClcbiAgICAgICAgICAgIC5tYXAoKHA6IGFueSkgPT4gKHtcbiAgICAgICAgICAgICAgICBuYW1lOiBwLmZpbGUubmFtZSxcbiAgICAgICAgICAgICAgICBwYXRoOiBwLmZpbGUucGF0aFxuICAgICAgICAgICAgfSkpO1xuXG4gICAgICAgIC8vIFByb2Nlc3MgZWFjaCBwYWdlIGFuZCBleHRyYWN0IHZvY2FidWxhcnlcbiAgICAgICAgZHYuaGVhZGVyKDEsIFwiQWxsIENvdXJzZSBWb2NhYnVsYXJ5XCIpO1xuICAgICAgICBcbiAgICAgICAgZm9yIChjb25zdCBwYWdlIG9mIHBhZ2VzKSB7XG4gICAgICAgICAgICBpZiAoIXBhZ2UucGF0aCkgY29udGludWU7XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIHRyeSB7ICAgXG4gICAgICAgICAgICAgICAgY29uc3QgZmlsZSA9IGF3YWl0IGR2LmFwcC52YXVsdC5nZXRGaWxlQnlQYXRoKHBhZ2UucGF0aCk7XG4gICAgICAgICAgICAgICAgY29uc3QgY29udGVudCA9IGF3YWl0IGR2LmFwcC52YXVsdC5yZWFkKGZpbGUpO1xuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgIC8vIEV4dHJhY3Qgdm9jYWJ1bGFyeSB1c2luZyByZWdleFxuICAgICAgICAgICAgICAgIGNvbnN0IHZvY2FiUmVnZXggPSAvXiMrIFZvY2FidWxhcnkuKlxcbigoPzouKj9cXG4pKj8pKD89XFxuXFxzKiN8JCkvbTtcbiAgICAgICAgICAgICAgICBjb25zdCB2b2NhYk1hdGNoZXMgPSBjb250ZW50Py5tYXRjaCh2b2NhYlJlZ2V4KTtcblxuICAgICAgICAgICAgICAgIGlmICh2b2NhYk1hdGNoZXMpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3Qgdm9jYWJEYXRhID0gdm9jYWJNYXRjaGVzWzFdLnRyaW0oKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgY2xlYW5lZFZvY2FiID0gdm9jYWJEYXRhXG4gICAgICAgICAgICAgICAgICAgICAgICAucmVwbGFjZSgvXFxbXFxbLio/XFxdXFxdL2csIFwiXCIpICAvLyBSZW1vdmUgd2lraWxpbmtzXG4gICAgICAgICAgICAgICAgICAgICAgICAudHJpbSgpXG4gICAgICAgICAgICAgICAgICAgICAgICAuc3BsaXQoXCJcXG5cIilcbiAgICAgICAgICAgICAgICAgICAgICAgIC5maWx0ZXIoKGxpbmU6IHN0cmluZykgPT4gbGluZS5zdGFydHNXaXRoKFwiLSBcIikpICAvLyBPbmx5IGxpbmVzIHN0YXJ0aW5nIHdpdGggXCItIFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAubWFwKChsaW5lOiBzdHJpbmcpID0+IGxpbmUuc3Vic3RyaW5nKDIpKSAgLy8gUmVtb3ZlIFwiLSBcIiBwcmVmaXhcbiAgICAgICAgICAgICAgICAgICAgICAgIC5maWx0ZXIoQm9vbGVhbik7ICAvLyBSZW1vdmUgZW1wdHkgZW50cmllc1xuXG4gICAgICAgICAgICAgICAgICAgIGlmIChjbGVhbmVkVm9jYWIubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgZHYuaGVhZGVyKDMsIGBbWyR7cGFnZS5uYW1lfV1dYCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBkdi5saXN0KGNsZWFuZWRWb2NhYik7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhgRXJyb3IgcHJvY2Vzc2luZyAke3BhZ2UucGF0aH06YCwgZSk7XG4gICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBpbiBWb2NhYnVsYXJ5IFByb2Nlc3Npbmc6XCIsIGVycm9yKTtcbiAgICB9XG59XG5cbi8qKlxuICogUHJvY2Vzc2VzIGFuZCBkaXNwbGF5cyBkdWUgZGF0ZXMgZnJvbSBhbGwgbm90ZXMgYXNzb2NpYXRlZCB3aXRoIGEgY291cnNlXG4gKiBAcGFyYW0gZHYgLSBUaGUgZGF0YXZpZXcgQVBJIG9iamVjdFxuICogQHBhcmFtIHNvdXJjZSAtIFRoZSB0YWcgb3IgcGF0aCB0byBzZWFyY2ggZm9yIGR1ZSBkYXRlc1xuICogQHBhcmFtIHN0YXJ0RGF0ZSAtIE9wdGlvbmFsIHN0YXJ0IGRhdGUgZm9yIGZpbHRlcmluZyAoWVlZWS1NTS1ERCBmb3JtYXQpXG4gKiBAcGFyYW0gZW5kRGF0ZSAtIE9wdGlvbmFsIGVuZCBkYXRlIGZvciBmaWx0ZXJpbmcgKFlZWVktTU0tREQgZm9ybWF0KVxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcHJvY2Vzc0R1ZURhdGVzKGR2OiBhbnksIHNvdXJjZTogc3RyaW5nLCBzdGFydERhdGU6IHN0cmluZyB8IG51bGwgPSBudWxsLCBlbmREYXRlOiBzdHJpbmcgfCBudWxsID0gbnVsbCkge1xuICAgIGZ1bmN0aW9uIGRlZHVwbGljYXRlRmlyc3RUd29Db2x1bW5zKGFycjogYW55W10pIHtcbiAgICAgICAgY29uc3Qgc2VlbiA9IG5ldyBTZXQoKTtcbiAgICAgICAgcmV0dXJuIGFyci5maWx0ZXIoKGVudHJ5OiBhbnkpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGtleSA9IEpTT04uc3RyaW5naWZ5KFtlbnRyeVswXSwgZW50cnlbMV1dKTtcbiAgICAgICAgICAgIHJldHVybiAhc2Vlbi5oYXMoa2V5KSAmJiBzZWVuLmFkZChrZXkpO1xuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvLyBJZiBubyBkYXRlIHJhbmdlIGlzIHNwZWNpZmllZCwgZGVmYXVsdCB0byBzaG93aW5nIGRhdGVzIHN0YXJ0aW5nIGZyb20geWVzdGVyZGF5XG4gICAgY29uc3QgZGVmYXVsdFN0YXJ0RGF0ZSA9ICh3aW5kb3cgYXMgYW55KS5tb21lbnQoKS5zdWJ0cmFjdCgxLCBcImRheVwiKS5mb3JtYXQoXCJZWVlZLU1NLUREXCIpO1xuICAgIGNvbnN0IHN0YXJ0ID0gc3RhcnREYXRlIHx8IGRlZmF1bHRTdGFydERhdGU7XG4gICAgY29uc3QgZW5kID0gZW5kRGF0ZSB8fCAod2luZG93IGFzIGFueSkubW9tZW50KCkuYWRkKDEsIFwieWVhclwiKS5mb3JtYXQoXCJZWVlZLU1NLUREXCIpOyAvLyBTaG93IGEgeWVhciBvZiBkYXRlcyBieSBkZWZhdWx0XG5cbiAgICBjb25zdCBwYWdlcyA9IGF3YWl0IGR2LnBhZ2VzKHNvdXJjZSlcbiAgICAgICAgLmZpbHRlcigocDogYW55KSA9PiBwLmZpbGUubmFtZSAhPT0gc291cmNlICYmIHAuZmlsZS5leHQgPT0gXCJtZFwiKTtcblxuICAgIGxldCBhbGxFbnRyaWVzOiBhbnlbXSA9IFtdO1xuXG4gICAgZm9yIChjb25zdCBwYWdlIG9mIHBhZ2VzLnZhbHVlcykge1xuICAgICAgICBpZiAoIXBhZ2U/LmZpbGU/LnBhdGgpIHsgcmV0dXJuIH1cbiAgICAgICAgY29uc3QgY29udGVudCA9IGF3YWl0IChkdi5hcHAudmF1bHQgYXMgYW55KS5jYWNoZWRSZWFkKChkdi5hcHAudmF1bHQgYXMgYW55KS5nZXRGaWxlQnlQYXRoKHBhZ2UuZmlsZT8ucGF0aCkpO1xuICAgICAgICBjb25zdCByZWdleCA9IC8jIER1ZSBEYXRlcyhbXFxzXFxTXSo/KSg/PVxcbiN8JCkvO1xuICAgICAgICBjb25zdCBtYXRjaGVzID0gY29udGVudD8ubWF0Y2gocmVnZXgpO1xuICAgICAgICBpZiAobWF0Y2hlcykge1xuICAgICAgICBjb25zdCB0YWJsZURhdGEgPSBtYXRjaGVzWzFdLnRyaW0oKTtcbiAgICAgICAgY29uc3QgbGluZXMgPSB0YWJsZURhdGEuc3BsaXQoXCJcXG5cIikuc2xpY2UoMSk7XG4gICAgICAgIGZvciAoY29uc3QgbGluZSBvZiBsaW5lcykge1xuICAgICAgICAgICAgbGV0IGZvcm1hdHRlZER1ZURhdGU6IHN0cmluZztcbiAgICAgICAgICAgIGNvbnN0IGNvbHVtbnMgPSBsaW5lXG4gICAgICAgICAgICAuc3BsaXQoXCJ8XCIpXG4gICAgICAgICAgICAubWFwKChjOiBzdHJpbmcpID0+IGMudHJpbSgpKVxuICAgICAgICAgICAgLmZpbHRlcigoYzogc3RyaW5nKSA9PiBjKTtcbiAgICAgICAgICAgIGxldCBbZHVlRGF0ZSwgYXNzaWdubWVudF0gPSBjb2x1bW5zO1xuICAgICAgICAgICAgaWYgKCFEYXRlLnBhcnNlKGR1ZURhdGUpIHx8IGFzc2lnbm1lbnQ/Lm1hdGNoKC9cdTI3MDUvKSkge1xuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBhc3NpZ25tZW50ID0gYXNzaWdubWVudD8ubWF0Y2goL1tBLVpdezN9LVswLTldezN9LylcbiAgICAgICAgICAgID8gYXNzaWdubWVudFxuICAgICAgICAgICAgOiBgIyR7cGFnZS5jb3Vyc2VfaWR9IC0gJHthc3NpZ25tZW50fWA7XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIGlmIChcbiAgICAgICAgICAgICh3aW5kb3cgYXMgYW55KS5tb21lbnQoZHVlRGF0ZSkuaXNCZXR3ZWVuKHN0YXJ0LCBlbmQsIHVuZGVmaW5lZCwgXCJbXVwiKSAgLy8gaW5jbHVkZSBlbmRwb2ludHNcbiAgICAgICAgICAgICkge1xuICAgICAgICAgICAgY29uc3QgdW5pcXVlUm93ID0gIWFsbEVudHJpZXMuc29tZShcbiAgICAgICAgICAgICAgICAoZTogYW55KSA9PlxuICAgICAgICAgICAgICAgIGVbMF0ubWF0Y2goKHdpbmRvdyBhcyBhbnkpLm1vbWVudChkdWVEYXRlKT8uZm9ybWF0KFwiWVlZWS1NTS1ERFwiKSkgJiZcbiAgICAgICAgICAgICAgICBlWzFdID09IGFzc2lnbm1lbnRcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgICBpZiAoYXNzaWdubWVudCAmJiB1bmlxdWVSb3cpIHtcbiAgICAgICAgICAgICAgICBpZiAoKHdpbmRvdyBhcyBhbnkpLm1vbWVudChkdWVEYXRlKT8uaXNCZWZvcmUoc3RhcnQpKSB7XG4gICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICAgICAgfSBlbHNlIGlmICgod2luZG93IGFzIGFueSkubW9tZW50KGR1ZURhdGUpLmlzQWZ0ZXIoKHdpbmRvdyBhcyBhbnkpLm1vbWVudCgpLnN1YnRyYWN0KDEsIFwid1wiKSkpIHtcbiAgICAgICAgICAgICAgICBmb3JtYXR0ZWREdWVEYXRlID0gYDxzcGFuIGNsYXNzPVwiZHVlIG9uZV93ZWVrXCI+JHsod2luZG93IGFzIGFueSkubW9tZW50KFxuICAgICAgICAgICAgICAgICAgICBkdWVEYXRlXG4gICAgICAgICAgICAgICAgKT8uZm9ybWF0KFwiWVlZWS1NTS1ERCBkZGRcIil9PC9zcGFuPmA7XG4gICAgICAgICAgICAgICAgfSBlbHNlIGlmICgod2luZG93IGFzIGFueSkubW9tZW50KGR1ZURhdGUpLmlzQWZ0ZXIoKHdpbmRvdyBhcyBhbnkpLm1vbWVudCgpLnN1YnRyYWN0KDIsIFwid1wiKSkpIHtcbiAgICAgICAgICAgICAgICBmb3JtYXR0ZWREdWVEYXRlID0gYDxzcGFuIGNsYXNzPVwiZHVlIHR3b193ZWVrc1wiPiR7KHdpbmRvdyBhcyBhbnkpLm1vbWVudChcbiAgICAgICAgICAgICAgICAgICAgZHVlRGF0ZVxuICAgICAgICAgICAgICAgICk/LmZvcm1hdChcIllZWVktTU0tREQgZGRkXCIpfTwvc3Bhbj5gO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgZm9ybWF0dGVkRHVlRGF0ZSA9ICh3aW5kb3cgYXMgYW55KS5tb21lbnQoZHVlRGF0ZSk/LmZvcm1hdChcIllZWVktTU0tREQgZGRkXCIpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBhbGxFbnRyaWVzLnB1c2goW1xuICAgICAgICAgICAgICAgIGR1ZURhdGUsXG4gICAgICAgICAgICAgICAgZm9ybWF0dGVkRHVlRGF0ZSxcbiAgICAgICAgICAgICAgICBhc3NpZ25tZW50LFxuICAgICAgICAgICAgICAgIGBbWyR7cGFnZT8uZmlsZT8ucGF0aH18JHtwYWdlPy5maWxlPy5uYW1lfV1dYCxcbiAgICAgICAgICAgICAgICBdKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgY29uc3Qgc29ydGVkUm93cyA9IGRlZHVwbGljYXRlRmlyc3RUd29Db2x1bW5zKGFsbEVudHJpZXNcbiAgICAgICAgLnNvcnQoKGE6IGFueSwgYjogYW55KSA9PiAod2luZG93IGFzIGFueSkubW9tZW50KGFbMF0pLnZhbHVlT2YoKSAtICh3aW5kb3cgYXMgYW55KS5tb21lbnQoYlswXSkudmFsdWVPZigpICkgXG4gICAgICAgIC5tYXAoKGE6IGFueSkgPT4gW2FbMV0sIGFbMl0sIGFbM11dKVxuICAgICk7XG4gICAgXG4gICAgY29uc3QgdGFibGUgPSBkdi5tYXJrZG93blRhYmxlKCBbXCJEdWUgRGF0ZVwiLCBcIlRhc2sgRGVzY3JpcHRpb25cIiwgXCJGaWxlXCJdLCBzb3J0ZWRSb3dzICk7XG4gICAgZHYuZWwoXCJ0YWJsZVwiLCB0YWJsZSk7XG59XG4iXSwKICAibWFwcGluZ3MiOiAiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUFBQSxtQkFBc0M7OztBQ0F0QyxzQkFBK0M7OztBQ2dCeEMsU0FBUyxRQUFRLE1BQXNCO0FBQzVDLFNBQU8sS0FDSixZQUFZLEVBQ1osS0FBSyxFQUNMLFVBQVUsS0FBSyxFQUNmLFFBQVEsb0JBQW9CLEVBQUUsRUFDOUIsUUFBUSxpQkFBaUIsRUFBRSxFQUMzQixRQUFRLFdBQVcsR0FBRyxFQUN0QixRQUFRLFlBQVksRUFBRTtBQUMzQjtBQWVPLFNBQVMsYUFBYSxZQUE2QjtBQUN4RCxRQUFNLFFBQVE7QUFDZCxNQUFJLENBQUMsV0FBVyxNQUFNLEtBQUs7QUFBRyxXQUFPO0FBRXJDLFFBQU0sT0FBTyxJQUFJLEtBQUssVUFBVTtBQUNoQyxRQUFNLFlBQVksS0FBSyxRQUFRO0FBRS9CLE1BQUksT0FBTyxjQUFjLFlBQVksTUFBTSxTQUFTO0FBQUcsV0FBTztBQUU5RCxTQUFPLGVBQWUsS0FBSyxZQUFZLEVBQUUsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUN2RDs7O0FEbkNPLElBQU0sbUJBQXlDO0FBQUEsRUFDcEQsZUFBZTtBQUFBLEVBQ2YsbUJBQW1CLElBQUksS0FBSyxFQUFFLFlBQVksRUFBRSxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsRUFDeEQsaUJBQWlCLElBQUksS0FBSyxJQUFJLEtBQUssRUFBRSxTQUFTLElBQUksS0FBSyxFQUFFLFNBQVMsSUFBSSxDQUFDLENBQUMsRUFBRSxZQUFZLEVBQUUsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLEVBQ3BHLFlBQVk7QUFBQSxFQUNaLG9CQUFvQjtBQUFBLEVBQ3BCLGdCQUFnQjtBQUFBLEVBQ2hCLHFCQUFxQjtBQUFBLEVBQ3JCLGdCQUFnQjtBQUNsQjtBQUVPLElBQU0seUJBQU4sY0FBcUMsaUNBQWlCO0FBQUEsRUFHM0QsWUFBWSxLQUFVLFFBQTRCO0FBQ2hELFVBQU0sS0FBSyxNQUFNO0FBQ2pCLFNBQUssU0FBUztBQUFBLEVBQ2hCO0FBQUEsRUFFQSxVQUFnQjtBQUNkLFVBQU0sRUFBRSxZQUFZLElBQUk7QUFFeEIsZ0JBQVksTUFBTTtBQUVsQixnQkFBWSxTQUFTLE1BQU0sRUFBRSxNQUFNLHlCQUF5QixDQUFDO0FBRTdELFFBQUksd0JBQVEsV0FBVyxFQUNwQixRQUFRLGdCQUFnQixFQUN4QixRQUFRLGdEQUFnRCxFQUN4RCxRQUFRLFVBQVEsS0FDZCxlQUFlLEdBQUcsRUFDbEIsU0FBUyxLQUFLLE9BQU8sU0FBUyxhQUFhLEVBQzNDLFNBQVMsQ0FBTyxVQUFVO0FBQ3pCLFdBQUssT0FBTyxTQUFTLGdCQUFnQjtBQUNyQyxZQUFNLEtBQUssT0FBTyxhQUFhO0FBQUEsSUFDakMsRUFBQyxDQUFDO0FBRU4sVUFBTSxtQkFBbUIsSUFBSSx3QkFBUSxXQUFXLEVBQzdDLFFBQVEscUJBQXFCLEVBQzdCLFFBQVEscUNBQXFDLEVBQzdDLFFBQVEsVUFBUSxLQUNkLGVBQWUsWUFBWSxFQUMzQixTQUFTLEtBQUssT0FBTyxTQUFTLGlCQUFpQixFQUMvQyxTQUFTLENBQU8sVUFBVTtBQUN6QixVQUFJLFNBQVMsQ0FBQyxhQUFhLEtBQUssR0FBRztBQUNqQyx5QkFBaUIsUUFBUSwyREFBMkQ7QUFBQSxNQUN0RixPQUFPO0FBQ0wseUJBQWlCLFFBQVEscUNBQXFDO0FBQUEsTUFDaEU7QUFDQSxXQUFLLE9BQU8sU0FBUyxvQkFBb0I7QUFDekMsWUFBTSxLQUFLLE9BQU8sYUFBYTtBQUFBLElBQ2pDLEVBQUMsQ0FBQztBQUVOLFVBQU0saUJBQWlCLElBQUksd0JBQVEsV0FBVyxFQUMzQyxRQUFRLG1CQUFtQixFQUMzQixRQUFRLG1DQUFtQyxFQUMzQyxRQUFRLFVBQVEsS0FDZCxlQUFlLFlBQVksRUFDM0IsU0FBUyxLQUFLLE9BQU8sU0FBUyxlQUFlLEVBQzdDLFNBQVMsQ0FBTyxVQUFVO0FBQ3pCLFVBQUksU0FBUyxDQUFDLGFBQWEsS0FBSyxHQUFHO0FBQ2pDLHVCQUFlLFFBQVEseURBQXlEO0FBQUEsTUFDbEYsT0FBTztBQUNMLHVCQUFlLFFBQVEsbUNBQW1DO0FBQUEsTUFDNUQ7QUFDQSxXQUFLLE9BQU8sU0FBUyxrQkFBa0I7QUFDdkMsWUFBTSxLQUFLLE9BQU8sYUFBYTtBQUFBLElBQ2pDLEVBQUMsQ0FBQztBQUVOLFFBQUksd0JBQVEsV0FBVyxFQUNwQixRQUFRLGFBQWEsRUFDckIsUUFBUSwwQkFBMEIsRUFDbEMsUUFBUSxVQUFRLEtBQ2QsZUFBZSxZQUFZLEVBQzNCLFNBQVMsS0FBSyxPQUFPLFNBQVMsVUFBVSxFQUN4QyxTQUFTLENBQU8sVUFBVTtBQUN6QixXQUFLLE9BQU8sU0FBUyxhQUFhO0FBQ2xDLFlBQU0sS0FBSyxPQUFPLGFBQWE7QUFBQSxJQUNqQyxFQUFDLENBQUM7QUFFTixRQUFJLHdCQUFRLFdBQVcsRUFDcEIsUUFBUSxxQkFBcUIsRUFDN0IsUUFBUSxtQ0FBbUMsRUFDM0MsUUFBUSxVQUFRLEtBQ2QsZUFBZSxHQUFHLEVBQ2xCLFNBQVMsS0FBSyxPQUFPLFNBQVMsa0JBQWtCLEVBQ2hELFNBQVMsQ0FBTyxVQUFVO0FBQ3pCLFdBQUssT0FBTyxTQUFTLHFCQUFxQjtBQUMxQyxZQUFNLEtBQUssT0FBTyxhQUFhO0FBQUEsSUFDakMsRUFBQyxDQUFDO0FBRU4sUUFBSSx3QkFBUSxXQUFXLEVBQ3BCLFFBQVEsaUJBQWlCLEVBQ3pCLFFBQVEsNkVBQTZFLEVBQ3JGLFFBQVEsVUFBUSxLQUNkLGVBQWUsZUFBZSxFQUM5QixTQUFTLEtBQUssT0FBTyxTQUFTLGNBQWMsRUFDNUMsU0FBUyxDQUFPLFVBQVU7QUFDekIsV0FBSyxPQUFPLFNBQVMsaUJBQWlCO0FBQ3RDLFlBQU0sS0FBSyxPQUFPLGFBQWE7QUFBQSxJQUNqQyxFQUFDLENBQUM7QUFFTixRQUFJLHdCQUFRLFdBQVcsRUFDcEIsUUFBUSx1QkFBdUIsRUFDL0IsUUFBUSxpRkFBaUYsRUFDekYsVUFBVSxZQUFVLE9BQ2xCLFNBQVMsS0FBSyxPQUFPLFNBQVMsbUJBQW1CLEVBQ2pELFNBQVMsQ0FBTyxVQUFVO0FBQ3pCLFdBQUssT0FBTyxTQUFTLHNCQUFzQjtBQUMzQyxZQUFNLEtBQUssT0FBTyxhQUFhO0FBQUEsSUFDakMsRUFBQyxDQUFDO0FBRU4sUUFBSSx3QkFBUSxXQUFXLEVBQ3BCLFFBQVEseUJBQXlCLEVBQ2pDLFFBQVEseURBQXlELEVBQ2pFLFFBQVEsVUFBUSxLQUNkLGVBQWUsZ0NBQWdDLEVBQy9DLFNBQVMsS0FBSyxPQUFPLFNBQVMsY0FBYyxFQUM1QyxTQUFTLENBQU8sVUFBVTtBQUN6QixXQUFLLE9BQU8sU0FBUyxpQkFBaUI7QUFDdEMsWUFBTSxLQUFLLE9BQU8sYUFBYTtBQUFBLElBQ2pDLEVBQUMsQ0FBQztBQUFBLEVBQ1I7QUFDRjs7O0FFMUlBLElBQUFDLG1CQUE0QjtBQVVyQixJQUFNLGtCQUFOLE1BQXNCO0FBQUEsRUFLM0IsWUFBWSxLQUFVLFVBQWdDO0FBQ3BELFNBQUssTUFBTTtBQUNYLFNBQUssV0FBVztBQUNoQixTQUFLLFdBQVc7QUFBQSxNQUNkLFNBQVM7QUFBQSxNQUNULFdBQVc7QUFBQSxRQUNULHFDQUFxQztBQUFBLFFBQ3JDLDJCQUEyQjtBQUFBLFFBQzNCLDRCQUE0QjtBQUFBLFFBQzVCLDhCQUE4QjtBQUFBLFFBQzlCLG9DQUFvQztBQUFBLFFBQ3BDLHVCQUF1QjtBQUFBLFFBQ3ZCLGlDQUFpQztBQUFBLFFBQ2pDLCtCQUErQjtBQUFBLE1BQ2pDO0FBQUEsTUFDQSxnQkFBZ0I7QUFBQSxNQUNoQixlQUFlO0FBQUEsSUFDakI7QUFBQSxFQUNGO0FBQUEsRUFFTSxtQkFBbUI7QUFBQTtBQUN2QixVQUFJO0FBRUYsY0FBTSxrQkFBa0IsS0FBSyxtQkFBbUI7QUFDaEQsWUFBSSxDQUFDLGlCQUFpQjtBQUNwQixjQUFJO0FBQUEsWUFDRjtBQUFBLFVBQ0Y7QUFDQSxrQkFBUTtBQUFBLFlBQ047QUFBQSxVQUNGO0FBQ0E7QUFBQSxRQUNGO0FBRUEsY0FBTSxxQkFBcUIsS0FBSyxzQkFBc0IsZUFBZTtBQUNyRSxZQUFJLENBQUMsb0JBQW9CO0FBQ3ZCLGNBQUk7QUFBQSxZQUNGO0FBQUEsVUFDRjtBQUNBLGtCQUFRO0FBQUEsWUFDTjtBQUFBLFVBQ0Y7QUFDQTtBQUFBLFFBQ0Y7QUFFQSxjQUFNLG1CQUFtQixHQUFHLHNCQUFzQixLQUFLLFNBQVM7QUFHaEUsWUFBSTtBQUNGLGdCQUFNLEtBQUssSUFBSSxNQUFNLGFBQWEsZ0JBQWdCO0FBQ2xELGtCQUFRLElBQUksNEJBQTRCLGtCQUFrQjtBQUFBLFFBQzVELFNBQVMsR0FBUDtBQUVBLGtCQUFRO0FBQUEsWUFDTiw4Q0FBOEM7QUFBQSxVQUNoRDtBQUFBLFFBQ0Y7QUFHQSxjQUFNLFVBQVU7QUFBQSxVQUNkO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxRQUNGO0FBQ0EsbUJBQVcsVUFBVSxTQUFTO0FBQzVCLGNBQUk7QUFDRixrQkFBTSxVQUFVLEdBQUcsb0JBQW9CO0FBQ3ZDLGtCQUFNLEtBQUssSUFBSSxNQUFNLGFBQWEsT0FBTztBQUN6QyxvQkFBUSxJQUFJLHlCQUF5QixTQUFTO0FBQUEsVUFDaEQsU0FBUyxHQUFQO0FBRUEsb0JBQVE7QUFBQSxjQUNOLGdDQUFnQyxvQkFBb0I7QUFBQSxZQUN0RDtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBR0EsY0FBTSxLQUFLLHVCQUF1QixnQkFBZ0I7QUFDbEQsY0FBTSxLQUFLLHVCQUF1QixnQkFBZ0I7QUFDbEQsY0FBTSxLQUFLLHdCQUF3QixnQkFBZ0I7QUFDbkQsY0FBTSxLQUFLLDJCQUEyQixnQkFBZ0I7QUFDdEQsY0FBTSxLQUFLLHNCQUFzQixnQkFBZ0I7QUFHakQsY0FBTSxLQUFLLGFBQWEsZ0JBQWdCO0FBR3hDLGNBQU0sS0FBSyx1QkFBdUIsZ0JBQWdCO0FBRWxELFlBQUksd0JBQU8saURBQWlEO0FBQzVELGdCQUFRLElBQUksZ0RBQWdEO0FBQUEsTUFDOUQsU0FBUyxPQUFQO0FBQ0EsZ0JBQVEsTUFBTSwrQkFBK0IsS0FBSztBQUNsRCxZQUFJLHdCQUFPLHdEQUF3RDtBQUFBLE1BQ3JFO0FBQUEsSUFDRjtBQUFBO0FBQUEsRUFFUSxxQkFBMEI7QUFFaEMsVUFBTSxnQkFBZ0I7QUFBQSxNQUNuQixLQUFLLElBQVksUUFBUSxRQUFRLG9CQUFvQjtBQUFBLE1BQ3JELEtBQUssSUFBWSxRQUFRLFFBQVEsV0FBVztBQUFBLE1BQzVDLEtBQUssSUFBWSxRQUFRLFVBQVUsb0JBQW9CO0FBQUEsTUFDdkQsS0FBSyxJQUFZLFFBQVEsVUFBVSxXQUFXO0FBQUEsSUFDakQ7QUFFQSxlQUFXLFFBQVEsZUFBZTtBQUNoQyxVQUFJLE1BQU07QUFDUixlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFFQSxXQUFPO0FBQUEsRUFDVDtBQUFBLEVBRVEsc0JBQXNCLGlCQUFxQztBQUNqRSxVQUFNLFdBQVcsZ0JBQWdCO0FBRWpDLFFBQUksQ0FBQyxVQUFVO0FBQ2IsY0FBUSxNQUFNLGtDQUFrQztBQUNoRCxhQUFPO0FBQUEsSUFDVDtBQUdBLFVBQU0sZ0JBQWdCO0FBQUEsTUFDcEIsU0FBUztBQUFBO0FBQUEsTUFDVCxTQUFTO0FBQUEsTUFDVCxTQUFTO0FBQUEsTUFDVCxTQUFTO0FBQUEsTUFDVCxTQUFTO0FBQUEsSUFDWDtBQUVBLGVBQVcsUUFBUSxlQUFlO0FBQ2hDLFVBQUksUUFBUSxPQUFPLFNBQVMsVUFBVTtBQUNwQyxlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFFQSxZQUFRO0FBQUEsTUFDTjtBQUFBLE1BQ0EsT0FBTyxLQUFLLFFBQVE7QUFBQSxJQUN0QjtBQUNBLFdBQU87QUFBQSxFQUNUO0FBQUEsRUFFTSx1QkFBdUIsVUFBa0I7QUFBQTtBQUM3QyxZQUFNLGVBQWUsR0FBRztBQUN4QixZQUFNLGtCQUFrQixLQUFLLFVBQVUsS0FBSyxVQUFVLE1BQU0sQ0FBQztBQUU3RCxVQUFJO0FBRUYsY0FBTSxtQkFDSixLQUFLLElBQUksTUFBTSxzQkFBc0IsWUFBWTtBQUNuRCxZQUFJLGtCQUFrQjtBQUVwQixnQkFBTSxPQUFPO0FBQ2IsZ0JBQU0sS0FBSyxJQUFJLE1BQU0sT0FBTyxNQUFNLGVBQWU7QUFDakQsa0JBQVEsSUFBSSw4QkFBOEIsY0FBYztBQUN4RDtBQUFBLFFBQ0Y7QUFHQSxjQUFNLEtBQUssSUFBSSxNQUFNLE9BQU8sY0FBYyxlQUFlO0FBQ3pELGdCQUFRLElBQUksOEJBQThCLGNBQWM7QUFBQSxNQUMxRCxTQUFTLEdBQVA7QUFDQSxZQUFJLHdCQUFPLG9DQUFvQyxjQUFjO0FBQzdELGdCQUFRLE1BQU0sb0NBQW9DLGlCQUFpQixDQUFDO0FBQUEsTUFDdEU7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVNLDBCQUE0QztBQUFBO0FBR2hELGNBQVEsSUFBSSwrQkFBK0I7QUFDM0MsYUFBTztBQUFBLElBQ1Q7QUFBQTtBQUFBLEVBRU0sa0JBQWtCO0FBQUE7QUFDdEIsVUFBSTtBQUVGLGdCQUFRLElBQUksb0JBQW9CO0FBR2hDLGNBQU0sa0JBQWtCLEtBQUssbUJBQW1CO0FBQ2hELFlBQUksQ0FBQyxpQkFBaUI7QUFDcEIsY0FBSTtBQUFBLFlBQ0Y7QUFBQSxVQUNGO0FBQ0Esa0JBQVE7QUFBQSxZQUNOO0FBQUEsVUFDRjtBQUNBO0FBQUEsUUFDRjtBQUVBLGNBQU0scUJBQXFCLEtBQUssc0JBQXNCLGVBQWU7QUFDckUsWUFBSSxDQUFDLG9CQUFvQjtBQUN2QixjQUFJO0FBQUEsWUFDRjtBQUFBLFVBQ0Y7QUFDQSxrQkFBUTtBQUFBLFlBQ047QUFBQSxVQUNGO0FBQ0E7QUFBQSxRQUNGO0FBRUEsY0FBTSxtQkFBbUIsR0FBRyxzQkFBc0IsS0FBSyxTQUFTO0FBR2hFLGNBQU0sS0FBSyx1QkFBdUIsZ0JBQWdCO0FBQ2xELGNBQU0sS0FBSyx1QkFBdUIsZ0JBQWdCO0FBQ2xELGNBQU0sS0FBSyx3QkFBd0IsZ0JBQWdCO0FBQ25ELGNBQU0sS0FBSywyQkFBMkIsZ0JBQWdCO0FBQ3RELGNBQU0sS0FBSyxzQkFBc0IsZ0JBQWdCO0FBR2pELGNBQU0sS0FBSyxhQUFhLGdCQUFnQjtBQUd4QyxjQUFNLEtBQUssdUJBQXVCLGdCQUFnQjtBQUVsRCxZQUFJLHdCQUFPLCtDQUErQztBQUMxRCxnQkFBUSxJQUFJLDhDQUE4QztBQUFBLE1BQzVELFNBQVMsT0FBUDtBQUNBLGdCQUFRLE1BQU0sNkJBQTZCLEtBQUs7QUFDaEQsWUFBSSx3QkFBTyxzREFBc0Q7QUFBQSxNQUNuRTtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRU0sdUJBQXVCLFVBQWtCO0FBQUE7QUFDN0MsWUFBTSxhQUFhLEdBQUc7QUFHdEIsWUFBTSx5QkFBeUIsS0FBSywrQkFBK0I7QUFDbkUsWUFBTSxLQUFLO0FBQUEsUUFDVCxHQUFHO0FBQUEsUUFDSDtBQUFBLE1BQ0Y7QUFHQSxZQUFNLHNCQUFzQixLQUFLLDRCQUE0QjtBQUM3RCxZQUFNLEtBQUs7QUFBQSxRQUNULEdBQUc7QUFBQSxRQUNIO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRU0sdUJBQXVCLFVBQWtCO0FBQUE7QUFDN0MsWUFBTSxhQUFhLEdBQUc7QUFHdEIsWUFBTSxpQkFBaUIsS0FBSyx1QkFBdUI7QUFDbkQsWUFBTSxLQUFLO0FBQUEsUUFDVCxHQUFHO0FBQUEsUUFDSDtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVNLHdCQUF3QixVQUFrQjtBQUFBO0FBQzlDLFlBQU0sY0FBYyxHQUFHO0FBR3ZCLFlBQU0sa0JBQWtCLEtBQUssd0JBQXdCO0FBQ3JELFlBQU0sS0FBSztBQUFBLFFBQ1QsR0FBRztBQUFBLFFBQ0g7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBO0FBQUEsRUFFTSwyQkFBMkIsVUFBa0I7QUFBQTtBQUNqRCxZQUFNLGlCQUFpQixHQUFHO0FBRzFCLFlBQU0scUJBQXFCLEtBQUssMkJBQTJCO0FBQzNELFlBQU0sS0FBSztBQUFBLFFBQ1QsR0FBRztBQUFBLFFBQ0g7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBO0FBQUEsRUFFTSxzQkFBc0IsVUFBa0I7QUFBQTtBQUM1QyxZQUFNLFlBQVksR0FBRztBQUdyQixZQUFNLG9CQUFvQixLQUFLLDBCQUEwQjtBQUN6RCxZQUFNLEtBQUs7QUFBQSxRQUNULEdBQUc7QUFBQSxRQUNIO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBV0EsbUJBQ0UsUUFDQSxVQUNBLGNBQ0EsWUFDQSxXQUNRO0FBQ1IsUUFBSSxhQUFhO0FBRWpCLFFBQUksT0FBTyxXQUFXLFlBQVksV0FBVyxRQUFRLE9BQU8sTUFBTTtBQUVoRSxZQUFNLFlBQVksT0FBTyxLQUFLLFVBQVUsR0FBRyxPQUFPLEtBQUssWUFBWSxHQUFHLENBQUM7QUFDdkUsWUFBTSxhQUFhLE9BQU87QUFHMUIsVUFBSSxnQkFBZ0IsWUFBWTtBQUU5QixxQkFBYSxHQUFHLGFBQWEscUJBQXFCLGdCQUFnQixtQkFBbUIsY0FBYyxZQUFZLGdCQUFnQixnQkFBZ0I7QUFBQSxNQUNqSixXQUFXLGNBQWM7QUFFdkIscUJBQWEsR0FBRyxhQUFhLHFCQUFxQixnQkFBZ0IsWUFBWSxrQkFBa0I7QUFBQSxNQUNsRyxXQUFXLFlBQVk7QUFFckIscUJBQWEsR0FBRyxhQUFhLG1CQUFtQixjQUFjLFlBQVksY0FBYztBQUFBLE1BQzFGLE9BQU87QUFFTCxxQkFBYSxHQUFHLGFBQWEsY0FBYztBQUFBLE1BQzdDO0FBQUEsSUFDRixPQUFPO0FBRUwsVUFBSSxnQkFBZ0IsWUFBWTtBQUM5QixxQkFBYSxXQUFXLHFCQUFxQixnQkFBZ0IsbUJBQW1CLGNBQWMsWUFBWSxnQkFBZ0IsZ0JBQWdCO0FBQUEsTUFDNUksV0FBVyxjQUFjO0FBQ3ZCLHFCQUFhLFdBQVcscUJBQXFCLGdCQUFnQixZQUFZLGtCQUFrQjtBQUFBLE1BQzdGLFdBQVcsWUFBWTtBQUNyQixxQkFBYSxXQUFXLG1CQUFtQixjQUFjLFlBQVksY0FBYztBQUFBLE1BQ3JGLE9BQU87QUFDTCxxQkFBYSxXQUFXLGNBQWM7QUFBQSxNQUN4QztBQUFBLElBQ0Y7QUFFQSxXQUFPO0FBQUEsRUFDVDtBQUFBLEVBRU0sa0JBQWtCLE1BQWMsU0FBaUI7QUFBQTtBQUNyRCxVQUFJO0FBRUYsY0FBTSxlQUFlLEtBQUssSUFBSSxNQUFNLHNCQUFzQixJQUFJO0FBQzlELFlBQUksY0FBYztBQUdoQixrQkFBUSxJQUFJLG9DQUFvQyxNQUFNO0FBQ3RELGdCQUFNLE9BQU87QUFDYixnQkFBTSxLQUFLLElBQUksTUFBTSxPQUFPLE1BQU0sT0FBTztBQUN6QztBQUFBLFFBQ0Y7QUFHQSxjQUFNLEtBQUssSUFBSSxNQUFNLE9BQU8sTUFBTSxPQUFPO0FBQ3pDLGdCQUFRLElBQUksMEJBQTBCLE1BQU07QUFBQSxNQUM5QyxTQUFTLEdBQVA7QUFDQSxZQUFJLHdCQUFPLGdDQUFnQyxNQUFNO0FBQ2pELGdCQUFRLE1BQU0sZ0NBQWdDLFNBQVMsQ0FBQztBQUFBLE1BQzFEO0FBQUEsSUFDRjtBQUFBO0FBQUEsRUFFRSxpQ0FBeUM7QUFDekMsVUFBTSxtQkFBbUIsS0FBSyxTQUFTO0FBRXZDLFFBQUksa0JBQWtCO0FBQ3BCLGFBQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BeUNQLEtBQUssU0FBUztBQUFBO0FBQUE7QUFBQSxNQUdkLEtBQUssU0FBUyxXQUFXLFFBQVEsUUFBUSxHQUFHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBWXBDLEtBQUssU0FBUztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQTZDeEIsT0FBTztBQUNMLGFBQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FrQkMsS0FBSyxTQUFTO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBZ0R4QjtBQUFBLEVBQ0Y7QUFBQSxFQUVBLDhCQUFzQztBQUNwQyxXQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFtQlQ7QUFBQSxFQUVBLHlCQUFpQztBQUMvQixXQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQTZDVCxLQUFLLFNBQVMsc0JBQ1Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFDQU1BO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBdURKO0FBQUEsRUFFQSwwQkFBa0M7QUFDaEMsV0FBTztBQUFBO0FBQUE7QUFBQSxFQUlULEtBQUssU0FBUyxzQkFDVjtBQUFBO0FBQUE7QUFBQTtBQUFBLG9DQUtBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQThCSjtBQUFBLEVBRUEsNkJBQXFDO0FBQ25DLFdBQU87QUFBQSxFQUVULEtBQUssU0FBUyxzQkFDVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUNBTUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUErQko7QUFBQSxFQUVBLDRCQUFvQztBQUNsQyxXQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQW1DVDtBQUFBLEVBRUEsNkJBQXFDO0FBQ25DLFdBQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBUVQ7QUFBQSxFQUVBLDBCQUFrQztBQUNoQyxXQUFPO0FBQUEsRUFDVDtBQUFBLEVBRU0sYUFBYSxVQUFrQjtBQUFBO0FBQ25DLFlBQU0sZ0JBQWdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQXlCdEIsWUFBTSxLQUFLLGtCQUFrQixHQUFHLHNCQUFzQixhQUFhO0FBQUEsSUFDckU7QUFBQTtBQUNGOzs7QUN4MUJBLElBQUFDLG1CQUFtQzs7O0FDRm5DLElBQUFDLG1CQUFvQztBQUU3QixJQUFNLGFBQU4sY0FBeUIsdUJBQU07QUFBQSxFQUlwQyxZQUFZLEtBQVUsVUFBMkM7QUFDL0QsVUFBTSxHQUFHO0FBQ1QsU0FBSyxXQUFXO0FBQUEsRUFDbEI7QUFBQSxFQUVBLFNBQVM7QUFDUCxVQUFNLEVBQUUsVUFBVSxJQUFJO0FBRXRCLGNBQVUsU0FBUyxNQUFNLEVBQUUsTUFBTSxjQUFjLENBQUM7QUFFaEQsUUFBSSx5QkFBUSxTQUFTLEVBQ2xCLFFBQVEsT0FBTyxFQUNmO0FBQUEsTUFBUSxDQUFDLFNBQ1IsS0FDRyxTQUFTLENBQUMsVUFBVTtBQUNuQixhQUFLLFNBQVM7QUFBQSxNQUNoQixDQUFDLEVBQ0EsUUFBUSxNQUFNO0FBQUEsSUFDbkI7QUFFRixRQUFJLHlCQUFRLFNBQVMsRUFDbEI7QUFBQSxNQUFVLENBQUMsUUFDVixJQUNHLGNBQWMsUUFBUSxFQUN0QixPQUFPLEVBQ1AsUUFBUSxNQUFNO0FBQ2IsYUFBSyxNQUFNO0FBQ1gsYUFBSyxTQUFTLEtBQUssVUFBVSxFQUFFO0FBQUEsTUFDakMsQ0FBQztBQUFBLElBQ0wsRUFDQztBQUFBLE1BQVUsQ0FBQyxRQUNWLElBQUksY0FBYyxRQUFRLEVBQUUsUUFBUSxNQUFNO0FBQ3hDLGFBQUssTUFBTTtBQUNYLGFBQUssU0FBUyxJQUFJO0FBQUEsTUFDcEIsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNKO0FBQUEsRUFFQSxVQUFVO0FBQ1IsVUFBTSxFQUFFLFVBQVUsSUFBSTtBQUN0QixjQUFVLE1BQU07QUFBQSxFQUNsQjtBQUNGO0FBRU8sSUFBTSxpQkFBTixjQUE2Qix1QkFBTTtBQUFBLEVBSXhDLFlBQVksS0FBVSxTQUFtQixVQUEyQztBQUNsRixVQUFNLEdBQUc7QUFDVCxTQUFLLFdBQVc7QUFHaEIsVUFBTSxrQkFBNkMsQ0FBQztBQUNwRCxZQUFRLFFBQVEsWUFBVTtBQUN4QixzQkFBZ0IsTUFBTSxJQUFJO0FBQUEsSUFDNUIsQ0FBQztBQUVELFNBQUssZUFBZSxlQUFlO0FBQUEsRUFDckM7QUFBQSxFQUVBLGVBQWUsU0FBb0M7QUFDakQsVUFBTSxFQUFFLFVBQVUsSUFBSTtBQUV0QixjQUFVLFNBQVMsTUFBTSxFQUFFLE1BQU0sZ0JBQWdCLENBQUM7QUFFbEQsUUFBSSxnQkFBZ0IsT0FBTyxLQUFLLE9BQU8sRUFBRSxDQUFDLEtBQUs7QUFFL0MsVUFBTSxXQUFXLFVBQVUsU0FBUyxRQUFRO0FBQzVDLFdBQU8sUUFBUSxPQUFPLEVBQUUsUUFBUSxDQUFDLENBQUMsS0FBSyxLQUFLLE1BQU07QUFDaEQsWUFBTSxTQUFTLFNBQVMsU0FBUyxVQUFVO0FBQUEsUUFDekMsT0FBTztBQUFBLFFBQ1AsTUFBTTtBQUFBLE1BQ1IsQ0FBQztBQUNELFVBQUksUUFBUSxlQUFlO0FBQ3pCLGVBQU8sV0FBVztBQUFBLE1BQ3BCO0FBQUEsSUFDRixDQUFDO0FBRUQsYUFBUyxpQkFBaUIsVUFBVSxDQUFDLFVBQVU7QUFDN0Msc0JBQWlCLE1BQU0sT0FBNkI7QUFDcEQsV0FBSyxTQUFTO0FBQUEsSUFDaEIsQ0FBQztBQUVELFFBQUkseUJBQVEsU0FBUyxFQUNsQjtBQUFBLE1BQVUsQ0FBQyxRQUNWLElBQ0csY0FBYyxRQUFRLEVBQ3RCLE9BQU8sRUFDUCxRQUFRLE1BQU07QUFDYixhQUFLLE1BQU07QUFDWCxhQUFLLFNBQVMsYUFBYTtBQUFBLE1BQzdCLENBQUM7QUFBQSxJQUNMLEVBQ0M7QUFBQSxNQUFVLENBQUMsUUFDVixJQUFJLGNBQWMsUUFBUSxFQUFFLFFBQVEsTUFBTTtBQUN4QyxhQUFLLE1BQU07QUFDWCxhQUFLLFNBQVMsSUFBSTtBQUFBLE1BQ3BCLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDSjtBQUFBLEVBRUEsU0FBUztBQUFBLEVBRVQ7QUFBQSxFQUVBLFVBQVU7QUFDUixVQUFNLEVBQUUsVUFBVSxJQUFJO0FBQ3RCLGNBQVUsTUFBTTtBQUFBLEVBQ2xCO0FBQ0Y7OztBRDVHTyxJQUFNLHVCQUFOLE1BQTJCO0FBQUEsRUFJaEMsWUFBWSxLQUFVLFVBQWdDO0FBQ3BELFNBQUssTUFBTTtBQUNYLFNBQUssV0FBVztBQUFBLEVBQ2xCO0FBQUEsRUFFTSx1QkFBdUI7QUFBQTtBQUMzQixVQUFJO0FBRUYsY0FBTSxnQkFBZ0IsTUFBTSxLQUFLLG9CQUFvQjtBQUVyRCxZQUFJLENBQUMsZUFBZTtBQUNsQixpQkFBTztBQUFBLFFBQ1Q7QUFHQSxjQUFNLGFBQWEsTUFBTSxLQUFLLDRCQUE0QixhQUFhO0FBR3ZFLGNBQU0sS0FBSyx5QkFBeUIsZUFBZSxVQUFVO0FBRzdELGNBQU0sS0FBSyx3QkFBd0IsVUFBVTtBQUU3QyxZQUFJLHdCQUFPLFdBQVcsY0FBYyxtQ0FBbUM7QUFDdkUsZ0JBQVE7QUFBQSxVQUNOLG1CQUFtQixjQUFjLGlCQUFpQjtBQUFBLFFBQ3BEO0FBRUEsZUFBTztBQUFBLE1BQ1QsU0FBUyxPQUFQO0FBQ0EsZ0JBQVEsTUFBTSwwQkFBMEIsS0FBSztBQUM3QyxZQUFJLHdCQUFPLDBCQUEwQixNQUFNLFNBQVM7QUFDcEQsZUFBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVjLHNCQUtKO0FBQUE7QUFyRFo7QUFzREksVUFBSTtBQUNGLGNBQU0sYUFBYSxNQUFNLEtBQUs7QUFBQSxVQUM1QjtBQUFBLFVBQ0E7QUFBQSxVQUNBLENBQUMsVUFBVSxNQUFNLEtBQUssRUFBRSxTQUFTO0FBQUEsVUFDakM7QUFBQSxRQUNGO0FBRUEsWUFBSSxDQUFDO0FBQVksaUJBQU87QUFFeEIsY0FBTSxlQUFlLE1BQU0sS0FBSztBQUFBLFVBQzlCO0FBQUEsVUFDQTtBQUFBLFVBQ0EsQ0FBQyxRQUFRLFVBQVUsVUFBVSxRQUFRO0FBQUEsUUFDdkM7QUFFQSxZQUFJLENBQUM7QUFBYyxpQkFBTztBQUUxQixjQUFNLGFBQWEsTUFBTSxLQUFLO0FBQUEsVUFDNUI7QUFBQSxVQUNBO0FBQUEsVUFDQSxDQUFDLFVBQVUsVUFBVSxLQUFLLE1BQU0sS0FBSyxDQUFDO0FBQUEsVUFDdEM7QUFBQSxRQUNGO0FBRUEsWUFBSSxDQUFDO0FBQVksaUJBQU87QUFFeEIsY0FBTSxhQUFXLGdCQUFXLE1BQU0sS0FBSyxFQUFFLENBQUMsTUFBekIsbUJBQTRCLFdBQVUsUUFBUSxVQUFVO0FBRXpFLGVBQU87QUFBQSxVQUNMO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsUUFDRjtBQUFBLE1BQ0YsU0FBUyxPQUFQO0FBQ0EsZ0JBQVEsTUFBTSx1Q0FBdUMsS0FBSztBQUMxRCxlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRWMscUJBQ1osT0FDQSxTQUNBLFdBQ0EsY0FDd0I7QUFBQTtBQUN4QixhQUFPLElBQUksUUFBUSxDQUFDLFlBQVk7QUFDOUIsY0FBTSxRQUFRLElBQUksV0FBVyxLQUFLLEtBQUssQ0FBQyxXQUFXO0FBQ2pELGNBQUksV0FBVyxNQUFNO0FBRW5CLG9CQUFRLElBQUk7QUFDWjtBQUFBLFVBQ0Y7QUFFQSxjQUFJLENBQUMsVUFBVSxNQUFNLEdBQUc7QUFDdEIsZ0JBQUksd0JBQU8sWUFBWTtBQUV2QixpQkFBSyxxQkFBcUIsT0FBTyxTQUFTLFdBQVcsWUFBWSxFQUM5RCxLQUFLLE9BQU87QUFDZjtBQUFBLFVBQ0Y7QUFFQSxrQkFBUSxPQUFPLEtBQUssQ0FBQztBQUFBLFFBQ3ZCLENBQUM7QUFHRCxjQUFNLFFBQVEsUUFBUSxLQUFLO0FBQzNCLGNBQU0sWUFBWSxNQUFNLFVBQVUsVUFBVTtBQUM1QyxrQkFBVSxRQUFRLE9BQU87QUFFekIsY0FBTSxLQUFLO0FBQUEsTUFDYixDQUFDO0FBQUEsSUFDSDtBQUFBO0FBQUEsRUFFYyxrQkFDWixPQUNBLFNBQ0EsU0FDd0I7QUFBQTtBQUN4QixhQUFPLElBQUksUUFBUSxDQUFDLFlBQVk7QUFDOUIsY0FBTSxRQUFRLElBQUksZUFBZSxLQUFLLEtBQUssU0FBUyxDQUFDLFdBQVc7QUFDOUQsY0FBSSxXQUFXLE1BQU07QUFFbkIsb0JBQVEsSUFBSTtBQUNaO0FBQUEsVUFDRjtBQUVBLGNBQUksUUFBUSxTQUFTLE1BQU0sR0FBRztBQUM1QixvQkFBUSxNQUFNO0FBQUEsVUFDaEIsT0FBTztBQUNMLGdCQUFJLHdCQUFPLHlCQUF5QixRQUFRLEtBQUssSUFBSSxHQUFHO0FBRXhELGlCQUFLLGtCQUFrQixPQUFPLFNBQVMsT0FBTyxFQUMzQyxLQUFLLE9BQU87QUFBQSxVQUNqQjtBQUFBLFFBQ0YsQ0FBQztBQUdELGNBQU0sUUFBUSxRQUFRLEtBQUs7QUFDM0IsY0FBTSxZQUFZLE1BQU0sVUFBVSxVQUFVO0FBQzVDLGtCQUFVLFFBQVEsT0FBTztBQUV6QixjQUFNLEtBQUs7QUFBQSxNQUNiLENBQUM7QUFBQSxJQUNIO0FBQUE7QUFBQSxFQUVjLDRCQUE0QixlQUt0QjtBQUFBO0FBQ2xCLFlBQU0sYUFBYSxHQUFHLGNBQWMsY0FBYyxjQUFjLGdCQUFnQixjQUFjO0FBRTlGLFVBQUk7QUFDRixjQUFNLEtBQUssSUFBSSxNQUFNLGFBQWEsVUFBVTtBQUM1QyxnQkFBUSxJQUFJLDBCQUEwQixZQUFZO0FBQ2xELGVBQU87QUFBQSxNQUNULFNBQVMsT0FBUDtBQUVBLGdCQUFRLElBQUksNENBQTRDLFlBQVk7QUFDcEUsZUFBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVjLHlCQUNaLGVBTUEsWUFDZTtBQUFBO0FBQ2YsWUFBTSxXQUFXLEdBQUcsY0FBYyxjQUFjO0FBQ2hELFlBQU0sVUFBVSxLQUFLLDhCQUE4QixhQUFhO0FBRWhFLFVBQUk7QUFDRixjQUFNLEtBQUssSUFBSSxNQUFNLE9BQU8sVUFBVSxPQUFPO0FBQzdDLGdCQUFRLElBQUksNEJBQTRCLFVBQVU7QUFBQSxNQUNwRCxTQUFTLE9BQVA7QUFDQSxnQkFBUSxNQUFNLG1DQUFtQyxPQUFPO0FBQ3hELGNBQU07QUFBQSxNQUNSO0FBQUEsSUFDRjtBQUFBO0FBQUEsRUFFYyx3QkFBd0IsWUFBbUM7QUFBQTtBQUN2RSxZQUFNLGtCQUFrQixHQUFHO0FBRTNCLFVBQUk7QUFDRixjQUFNLEtBQUssSUFBSSxNQUFNLGFBQWEsZUFBZTtBQUNqRCxnQkFBUSxJQUFJLCtCQUErQixpQkFBaUI7QUFBQSxNQUM5RCxTQUFTLE9BQVA7QUFFQSxnQkFBUSxJQUFJLHNDQUFzQyxpQkFBaUI7QUFBQSxNQUNyRTtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRVEsOEJBQThCLGVBSzNCO0FBRVQsVUFBTSxrQkFBa0IsSUFBSSxnQkFBZ0IsS0FBSyxLQUFLLEtBQUssUUFBUTtBQUNuRSxVQUFNLGtCQUFrQixnQkFBZ0IsK0JBQStCO0FBR3ZFLFdBQU8sZ0JBQ0osUUFBUSxxQkFBcUIsY0FBYyxVQUFVLEVBQ3JELFFBQVEsdUJBQXVCLGNBQWMsWUFBWSxFQUN6RCxRQUFRLHFCQUFxQixjQUFjLFVBQVUsRUFDckQsUUFBUSxtQkFBbUIsY0FBYyxRQUFRLEVBQ2pELFFBQVEsc0RBQXNELElBQUksS0FBSyxFQUFFLFlBQVksQ0FBQyxFQUN0RixRQUFRLHlEQUF5RCxJQUFJLEtBQUssRUFBRSxZQUFZLENBQUM7QUFBQSxFQUM5RjtBQUNGOzs7QUV0T0EsSUFBQUMsbUJBQTJCO0FBR3BCLElBQU0sc0JBQU4sTUFBMEI7QUFBQSxFQUcvQixZQUFZLEtBQVU7QUFDcEIsU0FBSyxNQUFNO0FBQUEsRUFDYjtBQUFBLEVBRUEsMEJBQTBCLFNBQTJCO0FBRW5ELFVBQU0sYUFBYTtBQUNuQixVQUFNLGVBQWUsbUNBQVMsTUFBTTtBQUVwQyxRQUFJLGNBQWM7QUFDaEIsWUFBTSxZQUFZLGFBQWEsQ0FBQyxFQUFFLEtBQUs7QUFDdkMsWUFBTSxlQUFlLFVBQ2xCLFFBQVEsZ0JBQWdCLEVBQUUsRUFDMUIsUUFBUSxjQUFjLEVBQUUsRUFDeEIsTUFBTSxJQUFJLEVBQ1YsSUFBSSxDQUFDLFNBQVMsS0FBSyxLQUFLLENBQUMsRUFDekIsT0FBTyxDQUFDLFNBQVMsS0FBSyxTQUFTLENBQUM7QUFFbkMsYUFBTztBQUFBLElBQ1Q7QUFFQSxXQUFPLENBQUM7QUFBQSxFQUNWO0FBQUEsRUFFTSw0QkFDSixVQUNtQztBQUFBO0FBQ25DLGNBQVEsSUFBSSxxQ0FBcUMsVUFBVTtBQUUzRCxVQUFJO0FBRUYsY0FBTSxjQUFjLE1BQU0sS0FBSyxnQkFBZ0IsUUFBUTtBQUV2RCxZQUFJLFlBQVksV0FBVyxHQUFHO0FBQzVCLGtCQUFRLElBQUksOEJBQThCLFVBQVU7QUFDcEQsaUJBQU8sQ0FBQztBQUFBLFFBQ1Y7QUFHQSxjQUFNLGlCQUEyQyxDQUFDO0FBRWxELG1CQUFXLFFBQVEsYUFBYTtBQUM5QixjQUFJO0FBQ0Ysa0JBQU0sVUFBVSxNQUFNLEtBQUssSUFBSSxNQUFNLEtBQUssSUFBSTtBQUM5QyxrQkFBTSxhQUFhLEtBQUssMEJBQTBCLE9BQU87QUFFekQsZ0JBQUksV0FBVyxTQUFTLEdBQUc7QUFDekIsNkJBQWUsS0FBSyxRQUFRLElBQUk7QUFBQSxZQUNsQztBQUFBLFVBQ0YsU0FBUyxPQUFQO0FBQ0Esb0JBQVEsTUFBTSxzQkFBc0IsS0FBSyxTQUFTLEtBQUs7QUFBQSxVQUN6RDtBQUFBLFFBQ0Y7QUFFQSxnQkFBUTtBQUFBLFVBQ04sNkJBQ0UsT0FBTyxLQUFLLGNBQWMsRUFBRSw0QkFDUjtBQUFBLFFBQ3hCO0FBQ0EsZUFBTztBQUFBLE1BQ1QsU0FBUyxPQUFQO0FBQ0EsZ0JBQVE7QUFBQSxVQUNOLDBDQUEwQztBQUFBLFVBQzFDO0FBQUEsUUFDRjtBQUNBLGVBQU8sQ0FBQztBQUFBLE1BQ1Y7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVNLGdCQUFnQixVQUFvQztBQUFBO0FBQ3hELFlBQU0sUUFBaUIsQ0FBQztBQUd4QixZQUFNLFFBQVEsS0FBSyxJQUFJLE1BQU0saUJBQWlCO0FBRTlDLGlCQUFXLFFBQVEsT0FBTztBQUV4QixZQUNFLEtBQUssS0FBSyxTQUFTLFFBQVEsTUFDMUIsTUFBTSxLQUFLLG9CQUFvQixNQUFNLFFBQVEsSUFDOUM7QUFDQSxnQkFBTSxLQUFLLElBQUk7QUFBQSxRQUNqQjtBQUFBLE1BQ0Y7QUFFQSxhQUFPO0FBQUEsSUFDVDtBQUFBO0FBQUEsRUFFYyxvQkFDWixNQUNBLFVBQ2tCO0FBQUE7QUFDbEIsVUFBSTtBQUNGLGNBQU0sVUFBVSxNQUFNLEtBQUssSUFBSSxNQUFNLEtBQUssSUFBSTtBQUM5QyxjQUFNLG1CQUFtQixRQUFRLE1BQU0sdUJBQXVCO0FBRTlELFlBQUksa0JBQWtCO0FBQ3BCLGdCQUFNLGNBQWMsaUJBQWlCLENBQUM7QUFFdEMsaUJBQ0UsWUFBWSxTQUFTLGNBQWMsVUFBVSxLQUM3QyxZQUFZLFNBQVMsYUFBYSxVQUFVO0FBQUEsUUFFaEQ7QUFFQSxlQUFPO0FBQUEsTUFDVCxTQUFTLE9BQVA7QUFDQSxnQkFBUTtBQUFBLFVBQ04sMEJBQTBCLEtBQUssMEJBQTBCO0FBQUEsVUFDekQ7QUFBQSxRQUNGO0FBQ0EsZUFBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVNLHdCQUNKLFVBQ0EsZ0JBQ2lCO0FBQUE7QUFDakIsWUFBTSxXQUFxQixDQUFDO0FBQzVCLFlBQU0sY0FBd0MsQ0FBQztBQUcvQyxpQkFBVyxDQUFDLFVBQVUsS0FBSyxLQUFLLE9BQU8sUUFBUSxjQUFjLEdBQUc7QUFDOUQsbUJBQVcsUUFBUSxPQUFPO0FBQ3hCLGNBQUksQ0FBQyxTQUFTLFNBQVMsSUFBSSxHQUFHO0FBQzVCLHFCQUFTLEtBQUssSUFBSTtBQUNsQix3QkFBWSxJQUFJLElBQUksQ0FBQztBQUFBLFVBQ3ZCO0FBQ0Esc0JBQVksSUFBSSxFQUFFLEtBQUssUUFBUTtBQUFBLFFBQ2pDO0FBQUEsTUFDRjtBQUdBLGVBQVMsS0FBSztBQUdkLFVBQUksVUFBVSx3QkFBd0I7QUFBQTtBQUFBO0FBQ3RDLGlCQUFXLHVCQUF1QixTQUFTO0FBQUE7QUFBQTtBQUUzQyxpQkFBVyxRQUFRLFVBQVU7QUFDM0IsbUJBQVcsTUFBTTtBQUFBO0FBQ2pCLG1CQUFXLGdCQUFnQixZQUFZLElBQUksRUFBRSxLQUFLLElBQUk7QUFBQTtBQUFBO0FBQ3RELG1CQUFXO0FBQUE7QUFBQTtBQUNYLG1CQUFXO0FBQUE7QUFBQTtBQUNYLG1CQUFXO0FBQUE7QUFBQTtBQUNYLG1CQUFXO0FBQUE7QUFBQTtBQUFBLE1BQ2I7QUFFQSxhQUFPO0FBQUEsSUFDVDtBQUFBO0FBQUEsRUFFTSwwQkFBMEIsVUFBaUM7QUFBQTtBQUMvRCxVQUFJO0FBQ0YsY0FBTSxpQkFBaUIsTUFBTSxLQUFLLDRCQUE0QixRQUFRO0FBRXRFLFlBQUksT0FBTyxLQUFLLGNBQWMsRUFBRSxXQUFXLEdBQUc7QUFDNUMsa0JBQVEsSUFBSSxtQ0FBbUMsVUFBVTtBQUN6RDtBQUFBLFFBQ0Y7QUFFQSxjQUFNLGVBQWUsTUFBTSxLQUFLO0FBQUEsVUFDOUI7QUFBQSxVQUNBO0FBQUEsUUFDRjtBQUdBLGNBQU0sV0FBVyxHQUFHO0FBQ3BCLGNBQU0sV0FBVyxXQUFXLFlBQVk7QUFFeEMsWUFBSTtBQUNGLGdCQUFNLEtBQUssSUFBSSxNQUFNLE9BQU8sVUFBVSxZQUFZO0FBQ2xELGtCQUFRLElBQUksa0NBQWtDLFVBQVU7QUFBQSxRQUMxRCxTQUFTLE9BQVA7QUFFQSxnQkFBTSxlQUFlLEtBQUssSUFBSSxNQUFNLHNCQUFzQixRQUFRO0FBQ2xFLGNBQUksZ0JBQWdCLHdCQUF3Qix3QkFBTztBQUNqRCxrQkFBTSxLQUFLLElBQUksTUFBTSxPQUFPLGNBQWMsWUFBWTtBQUN0RCxvQkFBUSxJQUFJLGtDQUFrQyxVQUFVO0FBQUEsVUFDMUQ7QUFBQSxRQUNGO0FBQUEsTUFDRixTQUFTLE9BQVA7QUFDQSxnQkFBUTtBQUFBLFVBQ04sOENBQThDO0FBQUEsVUFDOUM7QUFBQSxRQUNGO0FBQ0EsY0FBTTtBQUFBLE1BQ1I7QUFBQSxJQUNGO0FBQUE7QUFDRjs7O0FDck1BLElBQUFDLG1CQUEyQjtBQUdwQixJQUFNLGlCQUFOLE1BQXFCO0FBQUEsRUFHMUIsWUFBWSxLQUFVO0FBQ3BCLFNBQUssTUFBTTtBQUFBLEVBQ2I7QUFBQSxFQUVBLHNCQUNFLFNBQzZEO0FBRTdELFVBQU0sZ0JBQWdCO0FBQ3RCLFVBQU0sVUFBVSxtQ0FBUyxNQUFNO0FBRS9CLFFBQUksQ0FBQyxTQUFTO0FBQ1osYUFBTyxDQUFDO0FBQUEsSUFDVjtBQUVBLFVBQU0sa0JBQWtCLFFBQVEsQ0FBQztBQUNqQyxVQUFNLFdBQVcsQ0FBQztBQUdsQixVQUFNLGFBQWE7QUFDbkIsVUFBTSxlQUFlLGdCQUFnQixNQUFNLFVBQVU7QUFFckQsUUFBSSxjQUFjO0FBQ2hCLGlCQUFXLFNBQVMsY0FBYztBQUNoQyxjQUFNLE9BQU8sTUFDVixLQUFLLEVBQ0wsTUFBTSxJQUFJLEVBQ1YsT0FBTyxDQUFDLFFBQVEsSUFBSSxXQUFXLEdBQUcsQ0FBQztBQUN0QyxjQUFNLGFBQWEsS0FBSyxlQUFlLElBQUk7QUFDM0MsaUJBQVMsS0FBSyxHQUFHLFVBQVU7QUFBQSxNQUM3QjtBQUFBLElBQ0Y7QUFFQSxXQUFPO0FBQUEsRUFDVDtBQUFBLEVBRVEsZUFDTixNQUM2RDtBQUM3RCxRQUFJLEtBQUssU0FBUztBQUFHLGFBQU8sQ0FBQztBQUU3QixVQUFNLFdBQVcsQ0FBQztBQUVsQixhQUFTLElBQUksR0FBRyxJQUFJLEtBQUssUUFBUSxLQUFLO0FBRXBDLFlBQU0sTUFBTSxLQUFLLENBQUM7QUFDbEIsWUFBTSxVQUFVLElBQ2IsTUFBTSxHQUFHLEVBQ1QsSUFBSSxDQUFDLFFBQVEsSUFBSSxLQUFLLENBQUMsRUFDdkIsT0FBTyxDQUFDLFFBQVEsR0FBRztBQUV0QixVQUFJLFFBQVEsVUFBVSxHQUFHO0FBQ3ZCLGNBQU0sQ0FBQyxNQUFNLFlBQVksU0FBUyxTQUFTLElBQUk7QUFDL0MsWUFBSSxRQUFRLGNBQWMsS0FBSyxZQUFZLElBQUksR0FBRztBQUNoRCxtQkFBUyxLQUFLLEVBQUUsTUFBTSxZQUFZLE9BQU8sQ0FBQztBQUFBLFFBQzVDO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFFQSxXQUFPO0FBQUEsRUFDVDtBQUFBLEVBRVEsWUFBWSxZQUE2QjtBQUMvQyxVQUFNLFlBQVk7QUFDbEIsV0FBTyxVQUFVLEtBQUssVUFBVSxLQUFLLENBQUMsTUFBTSxLQUFLLE1BQU0sVUFBVSxDQUFDO0FBQUEsRUFDcEU7QUFBQSxFQUVNLHdCQUNKLFVBQ0EsV0FDQSxTQUdBO0FBQUE7QUFDQSxjQUFRLElBQUksaUNBQWlDLFVBQVU7QUFFdkQsVUFBSTtBQUVGLGNBQU0sY0FBYyxNQUFNLEtBQUssZ0JBQWdCLFFBQVE7QUFFdkQsWUFBSSxZQUFZLFdBQVcsR0FBRztBQUM1QixrQkFBUSxJQUFJLDhCQUE4QixVQUFVO0FBQ3BELGlCQUFPLENBQUM7QUFBQSxRQUNWO0FBR0EsY0FBTSxjQUtELENBQUM7QUFFTixtQkFBVyxRQUFRLGFBQWE7QUFDOUIsY0FBSTtBQUNGLGtCQUFNLFVBQVUsTUFBTSxLQUFLLElBQUksTUFBTSxLQUFLLElBQUk7QUFDOUMsa0JBQU0sV0FBVyxLQUFLLHNCQUFzQixPQUFPO0FBR25ELGtCQUFNLHFCQUFxQixTQUFTLElBQUksQ0FBQyxZQUFhLGlDQUNqRCxVQURpRDtBQUFBLGNBRXBELFFBQVEsS0FBSztBQUFBLFlBQ2YsRUFBRTtBQUVGLHdCQUFZLEtBQUssR0FBRyxrQkFBa0I7QUFBQSxVQUN4QyxTQUFTLE9BQVA7QUFDQSxvQkFBUSxNQUFNLHNCQUFzQixLQUFLLFNBQVMsS0FBSztBQUFBLFVBQ3pEO0FBQUEsUUFDRjtBQUdBLFlBQUksbUJBQW1CO0FBQ3ZCLFlBQUksYUFBYSxTQUFTO0FBQ3hCLDZCQUFtQixLQUFLO0FBQUEsWUFDdEI7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBR0EseUJBQWlCO0FBQUEsVUFDZixDQUFDLEdBQUcsTUFBTSxJQUFJLEtBQUssRUFBRSxJQUFJLEVBQUUsUUFBUSxJQUFJLElBQUksS0FBSyxFQUFFLElBQUksRUFBRSxRQUFRO0FBQUEsUUFDbEU7QUFFQSxnQkFBUTtBQUFBLFVBQ04sU0FBUyxpQkFBaUIsZ0NBQWdDO0FBQUEsUUFDNUQ7QUFDQSxlQUFPO0FBQUEsTUFDVCxTQUFTLE9BQVA7QUFDQSxnQkFBUSxNQUFNLHNDQUFzQyxhQUFhLEtBQUs7QUFDdEUsZUFBTyxDQUFDO0FBQUEsTUFDVjtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRWMsZ0JBQWdCLFVBQW9DO0FBQUE7QUFDaEUsWUFBTSxRQUFpQixDQUFDO0FBR3hCLFlBQU0sUUFBUSxLQUFLLElBQUksTUFBTSxpQkFBaUI7QUFFOUMsaUJBQVcsUUFBUSxPQUFPO0FBRXhCLFlBQ0UsS0FBSyxLQUFLLFNBQVMsUUFBUSxNQUMxQixNQUFNLEtBQUssb0JBQW9CLE1BQU0sUUFBUSxJQUM5QztBQUNBLGdCQUFNLEtBQUssSUFBSTtBQUFBLFFBQ2pCO0FBQUEsTUFDRjtBQUVBLGFBQU87QUFBQSxJQUNUO0FBQUE7QUFBQSxFQUVjLG9CQUNaLE1BQ0EsVUFDa0I7QUFBQTtBQUNsQixVQUFJO0FBQ0YsY0FBTSxVQUFVLE1BQU0sS0FBSyxJQUFJLE1BQU0sS0FBSyxJQUFJO0FBQzlDLGNBQU0sbUJBQW1CLFFBQVEsTUFBTSx1QkFBdUI7QUFFOUQsWUFBSSxrQkFBa0I7QUFDcEIsZ0JBQU0sY0FBYyxpQkFBaUIsQ0FBQztBQUV0QyxpQkFDRSxZQUFZLFNBQVMsY0FBYyxVQUFVLEtBQzdDLFlBQVksU0FBUyxhQUFhLFVBQVU7QUFBQSxRQUVoRDtBQUVBLGVBQU87QUFBQSxNQUNULFNBQVMsT0FBUDtBQUNBLGdCQUFRO0FBQUEsVUFDTiwwQkFBMEIsS0FBSywwQkFBMEI7QUFBQSxVQUN6RDtBQUFBLFFBQ0Y7QUFDQSxlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRVEsa0JBQ04sVUFNQSxXQUNBLFNBTUM7QUFDRCxXQUFPLFNBQVMsT0FBTyxDQUFDLFlBQVk7QUFDbEMsWUFBTSxjQUFjLElBQUksS0FBSyxRQUFRLElBQUksRUFBRSxRQUFRO0FBRW5ELFVBQUksYUFBYSxjQUFjLElBQUksS0FBSyxTQUFTLEVBQUUsUUFBUSxHQUFHO0FBQzVELGVBQU87QUFBQSxNQUNUO0FBRUEsVUFBSSxXQUFXLGNBQWMsSUFBSSxLQUFLLE9BQU8sRUFBRSxRQUFRLEdBQUc7QUFDeEQsZUFBTztBQUFBLE1BQ1Q7QUFFQSxhQUFPO0FBQUEsSUFDVCxDQUFDO0FBQUEsRUFDSDtBQUFBLEVBRU0sd0JBQ0osVUFDQSxVQU1pQjtBQUFBO0FBQ2pCLFVBQUksU0FBUyxXQUFXLEdBQUc7QUFDekIsZUFBTyx5QkFBeUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUNsQztBQUdBLFlBQU0sV0FBVyxTQUFTLE9BQU8sQ0FBQyxLQUFLLFlBQVk7QUFDakQsWUFBSSxDQUFDLElBQUksUUFBUSxNQUFNLEdBQUc7QUFDeEIsY0FBSSxRQUFRLE1BQU0sSUFBSSxDQUFDO0FBQUEsUUFDekI7QUFDQSxZQUFJLFFBQVEsTUFBTSxFQUFFLEtBQUssT0FBTztBQUNoQyxlQUFPO0FBQUEsTUFDVCxHQUFHLENBQUMsQ0FBb0M7QUFFeEMsVUFBSSxVQUFVLHlCQUF5QjtBQUFBO0FBQUE7QUFDdkMsaUJBQVcsc0JBQXNCLFNBQVM7QUFBQTtBQUFBO0FBRzFDLGlCQUFXLENBQUMsUUFBUSxLQUFLLEtBQUssT0FBTyxRQUFRLFFBQVEsR0FBRztBQUN0RCxtQkFBVyxNQUFNLE9BQU8sT0FBTyxDQUFDLEVBQUUsWUFBWSxJQUFJLE9BQU8sTUFBTSxDQUFDLE1BQzlELE1BQU07QUFBQTtBQUFBO0FBRVIsbUJBQVc7QUFBQTtBQUNYLG1CQUFXO0FBQUE7QUFFWCxtQkFBVyxRQUFRLE9BQU87QUFDeEIscUJBQVcsS0FBSyxLQUFLLFVBQVUsS0FBSyxnQkFBZ0IsS0FBSztBQUFBO0FBQUEsUUFDM0Q7QUFDQSxtQkFBVztBQUFBO0FBQUEsTUFDYjtBQUVBLGFBQU87QUFBQSxJQUNUO0FBQUE7QUFBQSxFQUVNLDBCQUNKLFVBQ0EsV0FDQSxTQUNlO0FBQUE7QUFDZixVQUFJO0FBQ0YsY0FBTSxXQUFXLE1BQU0sS0FBSztBQUFBLFVBQzFCO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxRQUNGO0FBRUEsY0FBTSxpQkFBaUIsTUFBTSxLQUFLO0FBQUEsVUFDaEM7QUFBQSxVQUNBO0FBQUEsUUFDRjtBQUdBLGNBQU0sV0FBVyxHQUFHO0FBQ3BCLGNBQU0sV0FBVyxXQUFXLFlBQVk7QUFFeEMsWUFBSTtBQUNGLGdCQUFNLEtBQUssSUFBSSxNQUFNLE9BQU8sVUFBVSxjQUFjO0FBQ3BELGtCQUFRLElBQUksbUNBQW1DLFVBQVU7QUFBQSxRQUMzRCxTQUFTLE9BQVA7QUFFQSxnQkFBTSxlQUFlLEtBQUssSUFBSSxNQUFNLHNCQUFzQixRQUFRO0FBQ2xFLGNBQUksZ0JBQWdCLHdCQUF3Qix3QkFBTztBQUNqRCxrQkFBTSxLQUFLLElBQUksTUFBTSxPQUFPLGNBQWMsY0FBYztBQUN4RCxvQkFBUSxJQUFJLG1DQUFtQyxVQUFVO0FBQUEsVUFDM0Q7QUFBQSxRQUNGO0FBQUEsTUFDRixTQUFTLE9BQVA7QUFDQSxnQkFBUTtBQUFBLFVBQ04sK0NBQStDO0FBQUEsVUFDL0M7QUFBQSxRQUNGO0FBQ0EsY0FBTTtBQUFBLE1BQ1I7QUFBQSxJQUNGO0FBQUE7QUFDRjs7O0FDelNBLElBQUFDLG1CQUEyQjtBQUVwQixJQUFNLHdCQUFOLE1BQTRCO0FBQUEsRUFHakMsWUFBWSxLQUFVO0FBQ3BCLFNBQUssTUFBTTtBQUFBLEVBQ2I7QUFBQSxFQUVNLHNCQUVKO0FBQUE7QUFDQSxjQUFRLElBQUkscUNBQXFDO0FBRWpELFVBQUk7QUFDRixjQUFNLFFBQVEsSUFBSSxLQUFLO0FBQ3ZCLGNBQU0sY0FBYyxNQUFNLFlBQVksRUFBRSxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBR3BELGNBQU0sUUFBUSxLQUFLLElBQUksTUFBTSxpQkFBaUI7QUFDOUMsY0FBTSxjQUF1QixDQUFDO0FBRTlCLG1CQUFXLFFBQVEsT0FBTztBQUN4QixnQkFBTSxXQUFXLEtBQUssb0JBQW9CLEtBQUssSUFBSTtBQUNuRCxjQUFJLGFBQWEsYUFBYTtBQUM1Qix3QkFBWSxLQUFLLElBQUk7QUFBQSxVQUN2QjtBQUFBLFFBQ0Y7QUFHQSxjQUFNLGFBQ0osQ0FBQztBQUVILG1CQUFXLFFBQVEsYUFBYTtBQUM5QixnQkFBTSxXQUFXLE1BQU0sS0FBSyxvQkFBb0IsSUFBSTtBQUNwRCxjQUFJLFVBQVU7QUFDWix1QkFBVyxLQUFLLFFBQVE7QUFBQSxVQUMxQjtBQUFBLFFBQ0Y7QUFFQSxnQkFBUSxJQUFJLFNBQVMsV0FBVyxzQ0FBc0M7QUFDdEUsZUFBTztBQUFBLE1BQ1QsU0FBUyxPQUFQO0FBQ0EsZ0JBQVEsTUFBTSxxQ0FBcUMsS0FBSztBQUN4RCxlQUFPLENBQUM7QUFBQSxNQUNWO0FBQUEsSUFDRjtBQUFBO0FBQUEsRUFFTSx5QkFDSixVQUNBLE1BQ2dEO0FBQUE7QUFDaEQsY0FBUSxJQUFJLCtCQUErQixvQkFBb0IsTUFBTTtBQUVyRSxVQUFJO0FBRUYsY0FBTSxjQUFjLE1BQU0sS0FBSyx1QkFBdUIsVUFBVSxJQUFJO0FBRXBFLGNBQU0sYUFBb0QsQ0FBQztBQUUzRCxtQkFBVyxRQUFRLGFBQWE7QUFDOUIsZ0JBQU0sVUFBVSxNQUFNLEtBQUssSUFBSSxNQUFNLEtBQUssSUFBSTtBQUM5QyxnQkFBTSxXQUFXLEtBQUssa0JBQWtCLE1BQU0sT0FBTztBQUVyRCxxQkFBVyxLQUFLO0FBQUEsWUFDZCxNQUFNLEtBQUs7QUFBQSxZQUNYLE1BQU07QUFBQSxVQUNSLENBQUM7QUFBQSxRQUNIO0FBRUEsZ0JBQVE7QUFBQSxVQUNOLFNBQVMsV0FBVyxnQ0FBZ0MsZUFBZTtBQUFBLFFBQ3JFO0FBQ0EsZUFBTztBQUFBLE1BQ1QsU0FBUyxPQUFQO0FBQ0EsZ0JBQVE7QUFBQSxVQUNOLHFDQUFxQyxlQUFlO0FBQUEsVUFDcEQ7QUFBQSxRQUNGO0FBQ0EsZUFBTyxDQUFDO0FBQUEsTUFDVjtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRVEsb0JBQW9CLFVBQWlDO0FBRTNELFVBQU0sWUFBWTtBQUNsQixVQUFNLFVBQVUsU0FBUyxNQUFNLFNBQVM7QUFDeEMsV0FBTyxVQUFVLFFBQVEsUUFBUSxTQUFTLENBQUMsSUFBSTtBQUFBLEVBQ2pEO0FBQUEsRUFFYyxvQkFDWixNQUNpRTtBQUFBO0FBQ2pFLFVBQUk7QUFDRixjQUFNLFVBQVUsTUFBTSxLQUFLLElBQUksTUFBTSxLQUFLLElBQUk7QUFHOUMsY0FBTSxXQUFXLEtBQUssa0JBQWtCLE1BQU0sT0FBTztBQUdyRCxjQUFNLFdBQ0osS0FBSywyQkFBMkIsT0FBTyxLQUN2QyxLQUFLLHdCQUF3QixLQUFLLElBQUk7QUFFeEMsZUFBTztBQUFBLFVBQ0wsTUFBTSxLQUFLO0FBQUEsVUFDWCxNQUFNO0FBQUEsVUFDTixRQUFRLFlBQVk7QUFBQSxRQUN0QjtBQUFBLE1BQ0YsU0FBUyxPQUFQO0FBQ0EsZ0JBQVEsTUFBTSx3QkFBd0IsS0FBSyxTQUFTLEtBQUs7QUFDekQsZUFBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVRLGtCQUFrQixNQUFhLFNBQXlCO0FBQzlELFVBQU0sT0FBTyxLQUFLLEtBQUssWUFBWTtBQUduQyxRQUNFLEtBQUssU0FBUyxPQUFPLEtBQ3JCLFFBQVEsU0FBUywwQkFBMEIsR0FDM0M7QUFDQSxhQUFPO0FBQUEsSUFDVDtBQUdBLFFBQUksS0FBSyxTQUFTLFNBQVMsS0FBSyxRQUFRLFNBQVMsWUFBWSxHQUFHO0FBQzlELFVBQUksUUFBUSxTQUFTLCtCQUErQixHQUFHO0FBQ3JELGVBQU87QUFBQSxNQUNUO0FBQ0EsVUFBSSxRQUFRLFNBQVMsc0JBQXNCLEdBQUc7QUFDNUMsZUFBTztBQUFBLE1BQ1Q7QUFDQSxVQUFJLFFBQVEsU0FBUyx1QkFBdUIsR0FBRztBQUM3QyxlQUFPO0FBQUEsTUFDVDtBQUNBLFVBQUksUUFBUSxTQUFTLDBCQUEwQixHQUFHO0FBQ2hELGVBQU87QUFBQSxNQUNUO0FBQ0EsYUFBTztBQUFBLElBQ1Q7QUFHQSxRQUFJLFFBQVEsU0FBUyxLQUFLLEtBQUssUUFBUSxNQUFNLGlCQUFpQixHQUFHO0FBQy9ELGFBQU87QUFBQSxJQUNUO0FBRUEsV0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUVRLDJCQUEyQixTQUFnQztBQUNqRSxVQUFNLGdCQUFnQjtBQUN0QixVQUFNLFFBQVEsUUFBUSxNQUFNLGFBQWE7QUFDekMsV0FBTyxRQUFRLE1BQU0sQ0FBQyxJQUFJO0FBQUEsRUFDNUI7QUFBQSxFQUVRLHdCQUF3QixVQUFpQztBQUMvRCxVQUFNLGdCQUFnQjtBQUN0QixVQUFNLFVBQVUsU0FBUyxNQUFNLGFBQWE7QUFDNUMsV0FBTyxVQUFVLFFBQVEsUUFBUSxTQUFTLENBQUMsSUFBSTtBQUFBLEVBQ2pEO0FBQUEsRUFFYyx1QkFDWixVQUNBLE1BQ2tCO0FBQUE7QUFDbEIsWUFBTSxRQUFpQixDQUFDO0FBR3hCLFlBQU0sV0FBVyxLQUFLLElBQUksTUFBTSxpQkFBaUI7QUFFakQsaUJBQVcsUUFBUSxVQUFVO0FBRTNCLFlBQ0UsS0FBSyxLQUFLLFNBQVMsUUFBUSxNQUMxQixNQUFNLEtBQUssb0JBQW9CLE1BQU0sUUFBUSxJQUM5QztBQUVBLGdCQUFNLFdBQVcsS0FBSyxvQkFBb0IsS0FBSyxJQUFJO0FBQ25ELGNBQUksYUFBYSxNQUFNO0FBQ3JCLGtCQUFNLEtBQUssSUFBSTtBQUFBLFVBQ2pCO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFFQSxhQUFPO0FBQUEsSUFDVDtBQUFBO0FBQUEsRUFFYyxvQkFDWixNQUNBLFVBQ2tCO0FBQUE7QUFDbEIsVUFBSTtBQUNGLGNBQU0sVUFBVSxNQUFNLEtBQUssSUFBSSxNQUFNLEtBQUssSUFBSTtBQUM5QyxlQUFPLEtBQUssMkJBQTJCLE9BQU8sTUFBTTtBQUFBLE1BQ3RELFNBQVMsT0FBUDtBQUNBLGdCQUFRO0FBQUEsVUFDTiwwQkFBMEIsS0FBSywwQkFBMEI7QUFBQSxVQUN6RDtBQUFBLFFBQ0Y7QUFDQSxlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRU0scUJBQXFCLE1BQWdDO0FBQUE7QUFDekQsWUFBTSxhQUFhLFFBQVEsSUFBSSxLQUFLLEVBQUUsWUFBWSxFQUFFLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFDaEUsWUFBTSxhQUFhLE1BQU0sS0FBSyx5QkFBeUIsSUFBSSxVQUFVO0FBRXJFLFVBQUksV0FBVyxXQUFXLEdBQUc7QUFDM0IsZUFBTywyQkFBMkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUNwQztBQUdBLFlBQU0sV0FBOEMsQ0FBQztBQUNyRCxZQUFNLFdBQThCLENBQUM7QUFFckMsaUJBQVcsWUFBWSxZQUFZO0FBQ2pDLFlBQUksU0FBUyxLQUFLLFNBQVMsVUFBVSxHQUFHO0FBRXRDLGdCQUFNLFlBQVksU0FBUyxLQUFLLE1BQU0sR0FBRztBQUN6QyxnQkFBTSxjQUFjLFVBQVUsVUFBVSxDQUFDLFNBQVMsS0FBSyxTQUFTLEdBQUcsQ0FBQztBQUNwRSxjQUFJLGVBQWUsR0FBRztBQUNwQixrQkFBTSxXQUFXLFVBQVUsV0FBVztBQUN0QyxnQkFBSSxDQUFDLFNBQVMsUUFBUSxHQUFHO0FBQ3ZCLHVCQUFTLFFBQVEsSUFBSSxDQUFDO0FBQUEsWUFDeEI7QUFDQSxxQkFBUyxRQUFRLEVBQUUsS0FBSyxRQUFRO0FBQUEsVUFDbEMsT0FBTztBQUNMLHFCQUFTLEtBQUssUUFBUTtBQUFBLFVBQ3hCO0FBQUEsUUFDRixPQUFPO0FBQ0wsbUJBQVMsS0FBSyxRQUFRO0FBQUEsUUFDeEI7QUFBQSxNQUNGO0FBRUEsVUFBSSxVQUFVLDJCQUEyQjtBQUFBO0FBQUE7QUFDekMsaUJBQVcscUJBQXFCLFdBQVc7QUFBQTtBQUFBO0FBRzNDLGlCQUFXLENBQUMsVUFBVSxnQkFBZ0IsS0FBSyxPQUFPLFFBQVEsUUFBUSxHQUFHO0FBQ25FLG1CQUFXLE1BQU07QUFBQTtBQUFBO0FBQ2pCLG1CQUFXO0FBQUE7QUFDWCxtQkFBVztBQUFBO0FBRVgsbUJBQVcsWUFBWSxrQkFBa0I7QUFDdkMscUJBQVcsS0FBSyxTQUFTLFVBQVUsU0FBUztBQUFBO0FBQUEsUUFDOUM7QUFDQSxtQkFBVztBQUFBO0FBQUEsTUFDYjtBQUdBLFVBQUksU0FBUyxTQUFTLEdBQUc7QUFDdkIsbUJBQVc7QUFBQTtBQUFBO0FBQ1gsbUJBQVc7QUFBQTtBQUNYLG1CQUFXO0FBQUE7QUFFWCxtQkFBVyxZQUFZLFVBQVU7QUFDL0IscUJBQVcsS0FBSyxTQUFTLFVBQVUsU0FBUztBQUFBO0FBQUEsUUFDOUM7QUFDQSxtQkFBVztBQUFBO0FBQUEsTUFDYjtBQUVBLGFBQU87QUFBQSxJQUNUO0FBQUE7QUFBQSxFQUVNLHVCQUF1QixNQUE4QjtBQUFBO0FBQ3pELFVBQUk7QUFDRixjQUFNLGFBQWEsUUFBUSxJQUFJLEtBQUssRUFBRSxZQUFZLEVBQUUsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUNoRSxjQUFNLGlCQUFpQixNQUFNLEtBQUsscUJBQXFCLFVBQVU7QUFHakUsY0FBTSxXQUFXLEdBQUc7QUFDcEIsY0FBTSxXQUFXLFNBQVM7QUFFMUIsWUFBSTtBQUNGLGdCQUFNLEtBQUssSUFBSSxNQUFNLE9BQU8sVUFBVSxjQUFjO0FBQ3BELGtCQUFRLElBQUksK0JBQStCLFVBQVU7QUFBQSxRQUN2RCxTQUFTLE9BQVA7QUFFQSxnQkFBTSxlQUFlLEtBQUssSUFBSSxNQUFNLHNCQUFzQixRQUFRO0FBQ2xFLGNBQUksZ0JBQWdCLHdCQUF3Qix3QkFBTztBQUNqRCxrQkFBTSxLQUFLLElBQUksTUFBTSxPQUFPLGNBQWMsY0FBYztBQUN4RCxvQkFBUSxJQUFJLCtCQUErQixVQUFVO0FBQUEsVUFDdkQ7QUFBQSxRQUNGO0FBQUEsTUFDRixTQUFTLE9BQVA7QUFDQSxnQkFBUSxNQUFNLG9DQUFvQyxTQUFTLEtBQUs7QUFDaEUsY0FBTTtBQUFBLE1BQ1I7QUFBQSxJQUNGO0FBQUE7QUFDRjs7O0FDclNBLElBQUFDLG1CQUF1RDtBQVVoRCxJQUFNLG1CQUFOLGNBQStCLHVCQUFNO0FBQUEsRUFNMUMsWUFDRSxLQUNBLFlBQ0EsVUFDQSxVQUNBO0FBQ0EsVUFBTSxHQUFHO0FBQ1QsU0FBSyxjQUFjLENBQUMsRUFBRSxNQUFNLElBQUksU0FBUyxJQUFJLE1BQU0sSUFBSSxRQUFRLElBQUksYUFBYSxHQUFHLENBQUM7QUFDcEYsU0FBSyxhQUFhO0FBQ2xCLFNBQUssV0FBVztBQUNoQixTQUFLLFdBQVc7QUFBQSxFQUNsQjtBQUFBLEVBRUEsU0FBUztBQUNQLFVBQU0sRUFBRSxVQUFVLElBQUk7QUFDdEIsY0FBVSxNQUFNO0FBQ2hCLGNBQVUsU0FBUyxpQ0FBaUM7QUFFcEQsY0FBVSxTQUFTLE1BQU0sRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBR2hFLFFBQUkseUJBQVEsU0FBUyxFQUNsQixRQUFRLFFBQVEsRUFDaEIsUUFBUSxHQUFHLEtBQUssZUFBZSxLQUFLLFdBQVcsRUFDL0MsWUFBWSxJQUFJO0FBR25CLFVBQU0sdUJBQXVCLFVBQVUsVUFBVSxFQUFFLEtBQUssd0JBQXdCLENBQUM7QUFHakYsU0FBSyxxQkFBcUIsc0JBQXNCLENBQUM7QUFHakQsUUFBSSx5QkFBUSxTQUFTLEVBQ2xCO0FBQUEsTUFBVSxDQUFDLFFBQ1YsSUFDRyxjQUFjLGdCQUFnQixFQUM5QixPQUFPLEVBQ1AsUUFBUSxNQUFNO0FBQ2IsY0FBTSxXQUFXLEtBQUssWUFBWTtBQUNsQyxhQUFLLFlBQVksS0FBSyxFQUFFLE1BQU0sSUFBSSxTQUFTLElBQUksTUFBTSxJQUFJLFFBQVEsSUFBSSxhQUFhLEdBQUcsQ0FBQztBQUN0RixhQUFLLHFCQUFxQixzQkFBc0IsUUFBUTtBQUFBLE1BQzFELENBQUM7QUFBQSxJQUNMO0FBR0YsUUFBSSx5QkFBUSxTQUFTLEVBQ2xCO0FBQUEsTUFBVSxDQUFDLFFBQ1YsSUFDRyxjQUFjLG9CQUFvQixFQUNsQyxPQUFPLEVBQ1AsUUFBUSxNQUFNO0FBRWIsY0FBTSxtQkFBbUIsS0FBSyxZQUFZO0FBQUEsVUFDeEMsQ0FBQyxNQUFNLEVBQUUsS0FBSyxLQUFLLE1BQU0sTUFBTSxFQUFFLFFBQVEsS0FBSyxNQUFNO0FBQUEsUUFDdEQ7QUFDQSxhQUFLLFNBQVMsa0JBQWtCLEtBQUssWUFBWSxLQUFLLFFBQVE7QUFDOUQsYUFBSyxNQUFNO0FBQUEsTUFDYixDQUFDO0FBQUEsSUFDTDtBQUFBLEVBQ0o7QUFBQSxFQUVBLHFCQUFxQixXQUF3QixPQUFlO0FBQzFELFVBQU0sVUFBVSxVQUFVLFVBQVUsRUFBRSxLQUFLLHFCQUFxQixDQUFDO0FBQ2pFLFlBQVEsU0FBUyxNQUFNLEVBQUUsTUFBTSxlQUFlLFFBQVEsSUFBSSxDQUFDO0FBRTNELFFBQUkseUJBQVEsT0FBTyxFQUNoQixRQUFRLGlCQUFpQixFQUN6QjtBQUFBLE1BQVEsQ0FBQyxTQUNSLEtBQ0csZUFBZSx1QkFBdUIsRUFDdEMsU0FBUyxLQUFLLFlBQVksS0FBSyxFQUFFLElBQUksRUFDckMsU0FBUyxDQUFDLFVBQVU7QUFDbkIsYUFBSyxZQUFZLEtBQUssRUFBRSxPQUFPO0FBQUEsTUFDakMsQ0FBQztBQUFBLElBQ0w7QUFFRixRQUFJLHlCQUFRLE9BQU8sRUFDaEIsUUFBUSxVQUFVLEVBQ2xCLFFBQVEsb0JBQW9CLEVBQzVCO0FBQUEsTUFBUSxDQUFDLFNBQ1IsS0FDRyxlQUFlLFlBQVksRUFDM0IsU0FBUyxLQUFLLFlBQVksS0FBSyxFQUFFLE9BQU8sRUFDeEMsU0FBUyxDQUFDLFVBQVU7QUFDbkIsYUFBSyxZQUFZLEtBQUssRUFBRSxVQUFVO0FBQUEsTUFDcEMsQ0FBQztBQUFBLElBQ0w7QUFFRixRQUFJLHlCQUFRLE9BQU8sRUFDaEIsUUFBUSxpQkFBaUIsRUFDekI7QUFBQSxNQUFRLENBQUMsU0FDUixLQUNHLGVBQWUsNEJBQTRCLEVBQzNDLFNBQVMsS0FBSyxZQUFZLEtBQUssRUFBRSxJQUFJLEVBQ3JDLFNBQVMsQ0FBQyxVQUFVO0FBQ25CLGFBQUssWUFBWSxLQUFLLEVBQUUsT0FBTztBQUFBLE1BQ2pDLENBQUM7QUFBQSxJQUNMO0FBRUYsUUFBSSx5QkFBUSxPQUFPLEVBQ2hCLFFBQVEsUUFBUSxFQUNoQjtBQUFBLE1BQVEsQ0FBQyxTQUNSLEtBQ0csZUFBZSxXQUFXLEVBQzFCLFNBQVMsS0FBSyxZQUFZLEtBQUssRUFBRSxNQUFNLEVBQ3ZDLFNBQVMsQ0FBQyxVQUFVO0FBQ25CLGFBQUssWUFBWSxLQUFLLEVBQUUsU0FBUztBQUFBLE1BQ25DLENBQUM7QUFBQSxJQUNMO0FBRUYsUUFBSSx5QkFBUSxPQUFPLEVBQ2hCLFFBQVEsYUFBYSxFQUNyQjtBQUFBLE1BQVksQ0FBQyxTQUNaLEtBQ0csZUFBZSw4QkFBOEIsRUFDN0MsU0FBUyxLQUFLLFlBQVksS0FBSyxFQUFFLFdBQVcsRUFDNUMsU0FBUyxDQUFDLFVBQVU7QUFDbkIsYUFBSyxZQUFZLEtBQUssRUFBRSxjQUFjO0FBQUEsTUFDeEMsQ0FBQztBQUFBLElBQ0w7QUFHRixRQUFJLEtBQUssWUFBWSxTQUFTLEdBQUc7QUFDL0IsVUFBSSx5QkFBUSxPQUFPLEVBQ2hCO0FBQUEsUUFBVSxDQUFDLFFBQ1YsSUFDRyxjQUFjLFFBQVEsRUFDdEIsUUFBUSxNQUFNO0FBQ2IsZUFBSyxZQUFZLE9BQU8sT0FBTyxDQUFDO0FBQ2hDLGtCQUFRLE9BQU87QUFDZixlQUFLLG9CQUFvQjtBQUFBLFFBQzNCLENBQUM7QUFBQSxNQUNMO0FBQUEsSUFDSjtBQUFBLEVBQ0Y7QUFBQSxFQUVBLHNCQUFzQjtBQUNwQixVQUFNLFdBQVcsS0FBSyxVQUFVLGlCQUFpQixxQkFBcUI7QUFDdEUsYUFBUyxRQUFRLENBQUMsU0FBUyxVQUFVO0FBQ25DLFlBQU0sU0FBUyxRQUFRLGNBQWMsSUFBSTtBQUN6QyxVQUFJLFFBQVE7QUFDVixlQUFPLGNBQWMsZUFBZSxRQUFRO0FBQUEsTUFDOUM7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNIO0FBQUEsRUFFQSxVQUFVO0FBQ1IsVUFBTSxFQUFFLFVBQVUsSUFBSTtBQUN0QixjQUFVLE1BQU07QUFBQSxFQUNsQjtBQUNGOzs7QUM3SkEsU0FBc0Isd0JBQXdCLElBQVMsVUFBa0I7QUFBQTtBQUNyRSxRQUFJO0FBRUEsWUFBTSxRQUFRLEdBQUcsTUFBTSxRQUFRLEVBQzFCLE9BQU8sQ0FBQyxNQUFXLEVBQUUsS0FBSyxRQUFRLFFBQVEsRUFBRSxLQUFLLFNBQVMsUUFBUSxFQUNsRSxJQUFJLENBQUMsT0FBWTtBQUFBLFFBQ2QsTUFBTSxFQUFFLEtBQUs7QUFBQSxRQUNiLE1BQU0sRUFBRSxLQUFLO0FBQUEsTUFDakIsRUFBRTtBQUdOLFNBQUcsT0FBTyxHQUFHLHVCQUF1QjtBQUVwQyxpQkFBVyxRQUFRLE9BQU87QUFDdEIsWUFBSSxDQUFDLEtBQUs7QUFBTTtBQUVoQixZQUFJO0FBQ0EsZ0JBQU0sT0FBTyxNQUFNLEdBQUcsSUFBSSxNQUFNLGNBQWMsS0FBSyxJQUFJO0FBQ3ZELGdCQUFNLFVBQVUsTUFBTSxHQUFHLElBQUksTUFBTSxLQUFLLElBQUk7QUFHNUMsZ0JBQU0sYUFBYTtBQUNuQixnQkFBTSxlQUFlLG1DQUFTLE1BQU07QUFFcEMsY0FBSSxjQUFjO0FBQ2Qsa0JBQU0sWUFBWSxhQUFhLENBQUMsRUFBRSxLQUFLO0FBQ3ZDLGtCQUFNLGVBQWUsVUFDaEIsUUFBUSxnQkFBZ0IsRUFBRSxFQUMxQixLQUFLLEVBQ0wsTUFBTSxJQUFJLEVBQ1YsT0FBTyxDQUFDLFNBQWlCLEtBQUssV0FBVyxJQUFJLENBQUMsRUFDOUMsSUFBSSxDQUFDLFNBQWlCLEtBQUssVUFBVSxDQUFDLENBQUMsRUFDdkMsT0FBTyxPQUFPO0FBRW5CLGdCQUFJLGFBQWEsU0FBUyxHQUFHO0FBQ3pCLGlCQUFHLE9BQU8sR0FBRyxLQUFLLEtBQUssUUFBUTtBQUMvQixpQkFBRyxLQUFLLFlBQVk7QUFBQSxZQUN4QjtBQUFBLFVBQ0o7QUFBQSxRQUVKLFNBQVMsR0FBUDtBQUNFLGtCQUFRLElBQUksb0JBQW9CLEtBQUssU0FBUyxDQUFDO0FBQy9DO0FBQUEsUUFDSjtBQUFBLE1BQ0o7QUFBQSxJQUVKLFNBQVMsT0FBUDtBQUNFLGNBQVEsTUFBTSxtQ0FBbUMsS0FBSztBQUFBLElBQzFEO0FBQUEsRUFDSjtBQUFBO0FBU0EsU0FBc0IsZ0JBQWdCLElBQVMsUUFBZ0IsWUFBMkIsTUFBTSxVQUF5QixNQUFNO0FBQUE7QUFwRS9IO0FBcUVJLGFBQVMsMkJBQTJCLEtBQVk7QUFDNUMsWUFBTSxPQUFPLG9CQUFJLElBQUk7QUFDckIsYUFBTyxJQUFJLE9BQU8sQ0FBQyxVQUFlO0FBQzlCLGNBQU0sTUFBTSxLQUFLLFVBQVUsQ0FBQyxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQy9DLGVBQU8sQ0FBQyxLQUFLLElBQUksR0FBRyxLQUFLLEtBQUssSUFBSSxHQUFHO0FBQUEsTUFDekMsQ0FBQztBQUFBLElBQ0w7QUFHQSxVQUFNLG1CQUFvQixPQUFlLE9BQU8sRUFBRSxTQUFTLEdBQUcsS0FBSyxFQUFFLE9BQU8sWUFBWTtBQUN4RixVQUFNLFFBQVEsYUFBYTtBQUMzQixVQUFNLE1BQU0sV0FBWSxPQUFlLE9BQU8sRUFBRSxJQUFJLEdBQUcsTUFBTSxFQUFFLE9BQU8sWUFBWTtBQUVsRixVQUFNLFFBQVEsTUFBTSxHQUFHLE1BQU0sTUFBTSxFQUM5QixPQUFPLENBQUMsTUFBVyxFQUFFLEtBQUssU0FBUyxVQUFVLEVBQUUsS0FBSyxPQUFPLElBQUk7QUFFcEUsUUFBSSxhQUFvQixDQUFDO0FBRXpCLGVBQVcsUUFBUSxNQUFNLFFBQVE7QUFDN0IsVUFBSSxHQUFDLGtDQUFNLFNBQU4sbUJBQVksT0FBTTtBQUFFO0FBQUEsTUFBTztBQUNoQyxZQUFNLFVBQVUsTUFBTyxHQUFHLElBQUksTUFBYyxXQUFZLEdBQUcsSUFBSSxNQUFjLGVBQWMsVUFBSyxTQUFMLG1CQUFXLElBQUksQ0FBQztBQUMzRyxZQUFNLFFBQVE7QUFDZCxZQUFNLFVBQVUsbUNBQVMsTUFBTTtBQUMvQixVQUFJLFNBQVM7QUFDYixjQUFNLFlBQVksUUFBUSxDQUFDLEVBQUUsS0FBSztBQUNsQyxjQUFNLFFBQVEsVUFBVSxNQUFNLElBQUksRUFBRSxNQUFNLENBQUM7QUFDM0MsbUJBQVcsUUFBUSxPQUFPO0FBQ3RCLGNBQUk7QUFDSixnQkFBTSxVQUFVLEtBQ2YsTUFBTSxHQUFHLEVBQ1QsSUFBSSxDQUFDLE1BQWMsRUFBRSxLQUFLLENBQUMsRUFDM0IsT0FBTyxDQUFDLE1BQWMsQ0FBQztBQUN4QixjQUFJLENBQUMsU0FBUyxVQUFVLElBQUk7QUFDNUIsY0FBSSxDQUFDLEtBQUssTUFBTSxPQUFPLE1BQUsseUNBQVksTUFBTSxPQUFNO0FBQ3BEO0FBQUEsVUFDQTtBQUNBLHdCQUFhLHlDQUFZLE1BQU0sd0JBQzdCLGFBQ0EsSUFBSSxLQUFLLGVBQWU7QUFFMUIsY0FDQyxPQUFlLE9BQU8sT0FBTyxFQUFFLFVBQVUsT0FBTyxLQUFLLFFBQVcsSUFBSSxHQUNuRTtBQUNGLGtCQUFNLFlBQVksQ0FBQyxXQUFXO0FBQUEsY0FDMUIsQ0FBQyxNQUFRO0FBakh6QixvQkFBQUM7QUFrSGdCLHlCQUFFLENBQUMsRUFBRSxPQUFPQSxNQUFBLE9BQWUsT0FBTyxPQUFPLE1BQTdCLGdCQUFBQSxJQUFnQyxPQUFPLGFBQWEsS0FDaEUsRUFBRSxDQUFDLEtBQUs7QUFBQTtBQUFBLFlBQ1o7QUFDQSxnQkFBSSxjQUFjLFdBQVc7QUFDekIsbUJBQUssWUFBZSxPQUFPLE9BQU8sTUFBN0IsbUJBQWdDLFNBQVMsUUFBUTtBQUN0RDtBQUFBLGNBQ0EsV0FBWSxPQUFlLE9BQU8sT0FBTyxFQUFFLFFBQVMsT0FBZSxPQUFPLEVBQUUsU0FBUyxHQUFHLEdBQUcsQ0FBQyxHQUFHO0FBQy9GLG1DQUFtQiwrQkFBK0IsWUFBZTtBQUFBLGtCQUM3RDtBQUFBLGdCQUNKLE1BRmtELG1CQUUvQyxPQUFPO0FBQUEsY0FDVixXQUFZLE9BQWUsT0FBTyxPQUFPLEVBQUUsUUFBUyxPQUFlLE9BQU8sRUFBRSxTQUFTLEdBQUcsR0FBRyxDQUFDLEdBQUc7QUFDL0YsbUNBQW1CLGdDQUFnQyxZQUFlO0FBQUEsa0JBQzlEO0FBQUEsZ0JBQ0osTUFGbUQsbUJBRWhELE9BQU87QUFBQSxjQUNWLE9BQU87QUFDUCxvQ0FBb0IsWUFBZSxPQUFPLE9BQU8sTUFBN0IsbUJBQWdDLE9BQU87QUFBQSxjQUMzRDtBQUNBLHlCQUFXLEtBQUs7QUFBQSxnQkFDaEI7QUFBQSxnQkFDQTtBQUFBLGdCQUNBO0FBQUEsZ0JBQ0EsTUFBSyxrQ0FBTSxTQUFOLG1CQUFZLFNBQVEsa0NBQU0sU0FBTixtQkFBWTtBQUFBLGNBQ3JDLENBQUM7QUFBQSxZQUNMO0FBQUEsVUFDQTtBQUFBLFFBQ0o7QUFBQSxNQUNBO0FBQUEsSUFDSjtBQUVBLFVBQU0sYUFBYTtBQUFBLE1BQTJCLFdBQ3pDLEtBQUssQ0FBQyxHQUFRLE1BQVksT0FBZSxPQUFPLEVBQUUsQ0FBQyxDQUFDLEVBQUUsUUFBUSxJQUFLLE9BQWUsT0FBTyxFQUFFLENBQUMsQ0FBQyxFQUFFLFFBQVEsQ0FBRSxFQUN6RyxJQUFJLENBQUMsTUFBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFBQSxJQUN2QztBQUVBLFVBQU0sUUFBUSxHQUFHLGNBQWUsQ0FBQyxZQUFZLG9CQUFvQixNQUFNLEdBQUcsVUFBVztBQUNyRixPQUFHLEdBQUcsU0FBUyxLQUFLO0FBQUEsRUFDeEI7QUFBQTs7O0FWdklBLElBQXFCLHFCQUFyQixjQUFnRCx3QkFBTztBQUFBLEVBUy9DLFNBQVM7QUFBQTtBQUNiLGNBQVEsSUFBSSw4QkFBOEI7QUFHMUMsWUFBTSxLQUFLLGFBQWE7QUFHeEIsV0FBSyxrQkFBa0IsSUFBSSxnQkFBZ0IsS0FBSyxLQUFLLEtBQUssUUFBUTtBQUNsRSxXQUFLLGVBQWUsSUFBSSxxQkFBcUIsS0FBSyxLQUFLLEtBQUssUUFBUTtBQUNwRSxXQUFLLHNCQUFzQixJQUFJLG9CQUFvQixLQUFLLEdBQUc7QUFDM0QsV0FBSyxpQkFBaUIsSUFBSSxlQUFlLEtBQUssR0FBRztBQUNqRCxXQUFLLHdCQUF3QixJQUFJLHNCQUFzQixLQUFLLEdBQUc7QUFDL0QsV0FBSyxvQkFBb0IsRUFBRSx5QkFBeUIsZ0JBQWdCO0FBR3BFLFdBQUssY0FBYyxJQUFJLHVCQUF1QixLQUFLLEtBQUssSUFBSSxDQUFDO0FBRzdELFdBQUssNkJBQTZCO0FBR2xDLFdBQUssV0FBVztBQUFBLFFBQ2QsSUFBSTtBQUFBLFFBQ0osTUFBTTtBQUFBLFFBQ04sVUFBVSxNQUFNO0FBQ2QsZUFBSyxnQkFBZ0IsaUJBQWlCO0FBQUEsUUFDeEM7QUFBQSxNQUNGLENBQUM7QUFFRCxXQUFLLFdBQVc7QUFBQSxRQUNkLElBQUk7QUFBQSxRQUNKLE1BQU07QUFBQSxRQUNOLFVBQVUsTUFBTTtBQUNkLGVBQUssZ0JBQWdCLGdCQUFnQjtBQUFBLFFBQ3ZDO0FBQUEsTUFDRixDQUFDO0FBSUQsV0FBSyxXQUFXO0FBQUEsUUFDZCxJQUFJO0FBQUEsUUFDSixNQUFNO0FBQUEsUUFDTixVQUFVLE1BQVk7QUFFcEIsZ0JBQU0sY0FBYyxLQUFLLElBQUksVUFBVSxjQUFjO0FBQ3JELGNBQUksV0FBVztBQUNmLGNBQUksYUFBYTtBQUdqQixjQUFJLGFBQWE7QUFDZixrQkFBTSxRQUFRLEtBQUssSUFBSSxjQUFjLGFBQWEsV0FBVztBQUM3RCxnQkFBSSxTQUFTLE1BQU0sYUFBYTtBQUM5Qix5QkFBVyxNQUFNLFlBQVksYUFBYTtBQUMxQywyQkFBYSxNQUFNLFlBQVksZUFBZSxNQUFNLFlBQVksU0FBUyxZQUFZO0FBQUEsWUFDdkY7QUFBQSxVQUNGO0FBR0EsY0FBSSxDQUFDLFVBQVU7QUFDYixrQkFBTSxtQkFBbUIsTUFBTSxLQUFLLGtCQUFrQixpQ0FBaUM7QUFDdkYsZ0JBQUksQ0FBQztBQUFrQjtBQUN2Qix1QkFBVztBQUNYLHlCQUFhO0FBQUEsVUFDZjtBQUdBLGNBQUk7QUFBQSxZQUNGLEtBQUs7QUFBQSxZQUNMO0FBQUEsWUFDQTtBQUFBLFlBQ0EsQ0FBTyxhQUFhQyxhQUFZQyxjQUFhO0FBRTNDLHlCQUFXLGNBQWMsYUFBYTtBQUNwQyxvQkFBSSxXQUFXLEtBQUssS0FBSyxNQUFNO0FBQUk7QUFHbkMsc0JBQU0sb0JBQW9CLEtBQUs7QUFBQSxrQkFDN0I7QUFBQSxrQkFDQUQ7QUFBQSxrQkFDQUM7QUFBQSxnQkFDRjtBQUNBLHNCQUFNLFdBQVcsR0FBR0EsZUFBYyxXQUFXLEtBQUssUUFBUSxpQkFBaUIsR0FBRztBQUM5RSxzQkFBTSxXQUFXLEdBQUdBLGFBQVk7QUFFaEMsb0JBQUk7QUFDRix3QkFBTSxLQUFLLElBQUksTUFBTSxPQUFPLFVBQVUsaUJBQWlCO0FBQ3ZELDBCQUFRLElBQUksNEJBQTRCLFVBQVU7QUFBQSxnQkFDcEQsU0FBUyxPQUFQO0FBQ0EsMEJBQVEsTUFBTSxrQ0FBa0MsYUFBYSxLQUFLO0FBQUEsZ0JBQ3BFO0FBQUEsY0FDRjtBQUFBLFlBQ0Y7QUFBQSxVQUNGLEVBQUUsS0FBSztBQUFBLFFBQ1Q7QUFBQSxNQUNGLENBQUM7QUFFRCxXQUFLLFdBQVc7QUFBQSxRQUNkLElBQUk7QUFBQSxRQUNKLE1BQU07QUFBQSxRQUNOLFVBQVUsTUFBWTtBQUNwQixnQkFBTSxXQUFXLE1BQU0sS0FBSztBQUFBLFlBQzFCO0FBQUEsVUFDRjtBQUNBLGNBQUksVUFBVTtBQUNaLGtCQUFNLEtBQUssb0JBQW9CLDBCQUEwQixRQUFRO0FBQUEsVUFDbkU7QUFBQSxRQUNGO0FBQUEsTUFDRixDQUFDO0FBRUQsV0FBSyxXQUFXO0FBQUEsUUFDZCxJQUFJO0FBQUEsUUFDSixNQUFNO0FBQUEsUUFDTixVQUFVLE1BQVk7QUFDcEIsZ0JBQU0sV0FBVyxNQUFNLEtBQUs7QUFBQSxZQUMxQjtBQUFBLFVBQ0Y7QUFDQSxjQUFJLFVBQVU7QUFDWixrQkFBTSxLQUFLLGVBQWUsMEJBQTBCLFFBQVE7QUFBQSxVQUM5RDtBQUFBLFFBQ0Y7QUFBQSxNQUNGLENBQUM7QUFFRCxXQUFLLFdBQVc7QUFBQSxRQUNkLElBQUk7QUFBQSxRQUNKLE1BQU07QUFBQSxRQUNOLFVBQVUsTUFBWTtBQUNwQixnQkFBTSxPQUFPLE1BQU0sS0FBSztBQUFBLFlBQ3RCO0FBQUEsVUFDRjtBQUNBLGdCQUFNLEtBQUssc0JBQXNCO0FBQUEsWUFDL0IsUUFBUTtBQUFBLFVBQ1Y7QUFBQSxRQUNGO0FBQUEsTUFDRixDQUFDO0FBR0QsV0FBSyxpQkFBaUIsRUFBRSxRQUFRLGVBQWU7QUFBQSxJQUNqRDtBQUFBO0FBQUEsRUFFYyxrQkFBa0IsU0FBeUM7QUFBQTtBQUN2RSxZQUFNLFdBQVcsT0FBTyxVQUFVLHNCQUFzQjtBQUN4RCxhQUFPLFdBQVcsU0FBUyxLQUFLLElBQUk7QUFBQSxJQUN0QztBQUFBO0FBQUEsRUFFYyxjQUFjLFNBQXlDO0FBQUE7QUFDbkUsWUFBTSxPQUFPO0FBQUEsUUFDWCxVQUFVO0FBQUEsTUFDWjtBQUNBLGFBQU8sT0FBTyxLQUFLLEtBQUssSUFBSTtBQUFBLElBQzlCO0FBQUE7QUFBQSxFQUVBLDhCQUE4QixZQUFpQixZQUFvQixVQUEwQjtBQUUzRixXQUFPO0FBQUEsYUFDRTtBQUFBLG1CQUNNLFdBQVcsUUFBUTtBQUFBLFlBQzFCLFdBQVc7QUFBQSxVQUNiLFdBQVcsVUFBVTtBQUFBO0FBQUEsV0FFcEIsSUFBSSxLQUFLLEVBQUUsWUFBWTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BSTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFJRixXQUFXLFVBQVU7QUFBQTtBQUFBO0FBQUEsRUFHdkIsV0FBVztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNRyxJQUFJLEtBQUssRUFBRSxZQUFZLEVBQUUsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLFdBQzFDLFdBQVc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFZbEIsV0FBVyxhQUFhLFdBQVc7QUFBQTtBQUFBLEVBRXJDO0FBQUEsRUFFQSxXQUFXO0FBQ1QsWUFBUSxJQUFJLGdDQUFnQztBQUFBLEVBQzlDO0FBQUEsRUFFTSwrQkFBK0I7QUFBQTtBQUdqQyxVQUFJO0FBRUYsWUFBSSxDQUFFLEtBQUssSUFBWSxTQUFTO0FBQzlCLFVBQUMsS0FBSyxJQUFZLFVBQVUsQ0FBQztBQUFBLFFBQy9CO0FBQ0EsWUFBSSxDQUFFLEtBQUssSUFBWSxRQUFRLGNBQWM7QUFDM0MsVUFBQyxLQUFLLElBQVksUUFBUSxlQUFlLENBQUM7QUFBQSxRQUM1QztBQUdBLFFBQUMsS0FBSyxJQUFZLFFBQVEsYUFBYSxhQUFhLENBQU8sS0FBVSxJQUFTLFNBQWM7QUFDMUYsaUJBQU8sS0FBSyxrQkFBa0IsS0FBSyxJQUFJLElBQUk7QUFBQSxRQUM3QztBQUVBLFFBQUMsS0FBSyxJQUFZLFFBQVEsYUFBYSxjQUFjLENBQU8sT0FBWTtBQUN0RSxpQkFBTyxLQUFLLG1CQUFtQixFQUFFO0FBQUEsUUFDbkM7QUFHQSxRQUFDLEtBQUssSUFBWSxRQUFRLGFBQWEsMEJBQTBCLENBQU8sSUFBUyxhQUFxQjtBQUNwRyxpQkFBTyx3QkFBd0IsSUFBSSxRQUFRO0FBQUEsUUFDN0M7QUFFQSxRQUFDLEtBQUssSUFBWSxRQUFRLGFBQWEsa0JBQWtCLENBQU8sSUFBUyxRQUFnQixZQUEyQixNQUFNLFVBQXlCLFNBQVM7QUFDMUosaUJBQU8sZ0JBQWdCLElBQUksUUFBUSxXQUFXLE9BQU87QUFBQSxRQUN2RDtBQUlBLGNBQU0sa0JBQXdCLEtBQUssSUFBWSxRQUFRLFVBQVUsb0JBQW9CO0FBQ3JGLFlBQUksbUJBQW1CLGdCQUFnQixhQUFhLGdCQUFnQixVQUFVLFdBQVc7QUFFdkYsY0FBSSxDQUFDLGdCQUFnQixVQUFVLFVBQVUsTUFBTTtBQUM3Qyw0QkFBZ0IsVUFBVSxVQUFVLE9BQU8sQ0FBQztBQUFBLFVBQzlDO0FBR0EsMEJBQWdCLFVBQVUsVUFBVSxLQUFLLFlBQVksSUFBSSxDQUFPLEtBQVUsSUFBUyxTQUFjO0FBQy9GLG1CQUFPLEtBQUssa0JBQWtCLEtBQUssSUFBSSxJQUFJO0FBQUEsVUFDN0M7QUFFQSwwQkFBZ0IsVUFBVSxVQUFVLEtBQUssYUFBYSxJQUFJLENBQU8sT0FBWTtBQUMzRSxtQkFBTyxLQUFLLG1CQUFtQixFQUFFO0FBQUEsVUFDbkM7QUFHQSwwQkFBZ0IsVUFBVSxVQUFVLEtBQUsseUJBQXlCLElBQUksQ0FBTyxJQUFTLGFBQXFCO0FBQ3pHLG1CQUFPLHdCQUF3QixJQUFJLFFBQVE7QUFBQSxVQUM3QztBQUVBLDBCQUFnQixVQUFVLFVBQVUsS0FBSyxpQkFBaUIsSUFBSSxDQUFPLElBQVMsUUFBZ0IsWUFBMkIsTUFBTSxVQUF5QixTQUFTO0FBQy9KLG1CQUFPLGdCQUFnQixJQUFJLFFBQVEsV0FBVyxPQUFPO0FBQUEsVUFDdkQ7QUFFQSxrQkFBUSxJQUFJLGlHQUFpRztBQUFBLFFBQy9HLE9BQU87QUFDTCxrQkFBUSxJQUFJLCtGQUErRjtBQUFBLFFBQzdHO0FBRUEsZ0JBQVEsSUFBSSx3REFBd0Q7QUFBQSxNQUN0RSxTQUFTLEdBQVA7QUFDQSxnQkFBUSxNQUFNLHFEQUFxRCxDQUFDO0FBQUEsTUFDdEU7QUFBQSxJQUNKO0FBQUE7QUFBQSxFQUVNLGtCQUFrQixLQUFVLElBQVMsTUFBYztBQUFBO0FBalMzRDtBQW1TSSxVQUFJLGVBQThCO0FBQ2xDLFVBQUksYUFBNEI7QUFDaEMsVUFBSSxTQUFTO0FBQ2IsVUFBSSxXQUFXO0FBQ2YsVUFBSSxhQUFhO0FBQ2pCLFVBQUksWUFBWTtBQUNoQixVQUFJLFNBQVM7QUFFYixVQUFJO0FBRUYsWUFBSSxNQUFNLEdBQUcsVUFBVSxHQUFHLE9BQU8sUUFBUTtBQUd2QyxnQkFBTSxjQUFjLElBQUksS0FBSztBQUM3QixnQkFBTSxjQUFjLFlBQVksWUFBWSxFQUFFLFNBQVM7QUFDdkQsZ0JBQU0sZUFBZSxZQUFZLFNBQVM7QUFDMUMsY0FBSSxrQkFBa0I7QUFHdEIsY0FBSSxnQkFBZ0IsS0FBSyxnQkFBZ0IsR0FBRztBQUMxQyw4QkFBa0I7QUFBQSxVQUNwQixXQUFXLGdCQUFnQixLQUFLLGdCQUFnQixHQUFHO0FBQ2pELDhCQUFrQjtBQUFBLFVBQ3BCLE9BQU87QUFDTCw4QkFBa0I7QUFBQSxVQUNwQjtBQUVBLGtCQUFRLElBQUkseUJBQXlCLG1CQUFtQixhQUFhO0FBR3JFLGdCQUFNLGNBQWMsSUFBSSxNQUFNLGlCQUFpQixFQUFFLE9BQU8sQ0FBQyxNQUFXO0FBQ2xFLGtCQUFNLFFBQVEsSUFBSSxjQUFjLGFBQWEsQ0FBQztBQUM5QyxnQkFBSSxDQUFDO0FBQU8scUJBQU87QUFHbkIsa0JBQU0sZUFBZSxVQUNsQixNQUFNLFFBQVEsTUFBTSxLQUFLLEtBQUssQ0FBQyxRQUFhLElBQUksUUFBUSxjQUFjLEtBQ3RFLE1BQU0sZUFBZSxNQUFNLFlBQVksZ0JBQWdCLFlBQ3ZELE1BQU0sZUFBZSxNQUFNLFlBQVksU0FDdEMsTUFBTSxRQUFRLE1BQU0sWUFBWSxJQUFJLElBQ2pDLE1BQU0sWUFBWSxLQUFLLFNBQVMsYUFBYSxJQUM3QyxNQUFNLFlBQVksU0FBUztBQUdsQyxtQkFBTztBQUFBLFVBQ1QsQ0FBQztBQUVELGtCQUFRLElBQUksU0FBUyxZQUFZLDJCQUEyQjtBQUc1RCxnQkFBTSx1QkFBdUIsWUFBWSxPQUFPLENBQUMsTUFBVztBQUMxRCxrQkFBTSxRQUFRLElBQUksY0FBYyxhQUFhLENBQUM7QUFDOUMsZ0JBQUksQ0FBQyxTQUFTLENBQUMsTUFBTTtBQUFhLHFCQUFPO0FBRXpDLGtCQUFNLGFBQWEsTUFBTSxZQUFZLGVBQWUsTUFBTSxZQUFZLGNBQWM7QUFDcEYsa0JBQU0sZUFBZSxNQUFNLFlBQVksaUJBQWlCLE1BQU0sWUFBWSxnQkFBZ0I7QUFFMUYsbUJBQVEsZUFBZSxlQUFlLGlCQUFpQjtBQUFBLFVBQ3pELENBQUM7QUFFRCxrQkFBUSxJQUFJLFNBQVMscUJBQXFCLCtCQUErQjtBQUV6RSxrQkFBUSxJQUFJLFNBQVMsWUFBWSwyQkFBMkIsbUJBQW1CLGFBQWE7QUFHNUYsZ0JBQU0sY0FBYyxxQkFBcUIsU0FBUyxJQUFJLHVCQUF1QjtBQUM3RSxnQkFBTSxnQkFBZ0IscUJBQXFCLFNBQVMsSUFDaEQsa0JBQWtCLG1CQUFtQixpQkFDckMsa0NBQWtDLFlBQVk7QUFFbEQsa0JBQVEsSUFBSSxXQUFXLFlBQVksZ0NBQWdDLGVBQWU7QUFFbEYsY0FBSSxZQUFZLFNBQVMsR0FBRztBQUMxQixxQkFBUyxNQUFNLEdBQUcsT0FBTztBQUFBLGNBQ3ZCLFlBQVksSUFBSSxDQUFDLE1BQVcsRUFBRSxRQUFRO0FBQUE7QUFBQSxjQUN0QztBQUFBO0FBQUEsY0FDQTtBQUFBLFlBQ0Y7QUFBQSxVQUNGLE9BQU87QUFFTCxxQkFBUyxNQUFNLEdBQUcsT0FBTyxPQUFPLGVBQWUsWUFBWTtBQUFBLFVBQzdEO0FBR0EsZ0JBQU0sbUJBQW1CLE1BQU0sR0FBRyxPQUFPLE9BQU8sNEJBQTRCLEVBQUU7QUFDOUUseUJBQWUsbUJBQW1CLG1CQUFtQjtBQUVyRCxnQkFBTSxpQkFBaUIsTUFBTSxHQUFHLE9BQU8sT0FBTywwQkFBMEIsRUFBRTtBQUMxRSx1QkFBYSxpQkFBaUIsaUJBQWlCO0FBRS9DLHNCQUFZLE1BQU0sR0FBRyxPQUFPO0FBQUEsWUFDMUIsQ0FBQyxVQUFVLFdBQVcsYUFBYSxZQUFZLFVBQVUsWUFBWSxRQUFRO0FBQUE7QUFBQSxZQUM3RSxDQUFDLFVBQVUsV0FBVyxhQUFhLFlBQVksVUFBVSxZQUFZLFFBQVE7QUFBQTtBQUFBLFlBQzdFO0FBQUEsVUFDRjtBQUdBLG1CQUFTO0FBQUEsUUFDWCxPQUFPO0FBRUwseUJBQWU7QUFDZix1QkFBYTtBQUNiLG1CQUFTO0FBQ1Qsc0JBQVk7QUFDWixtQkFBUztBQUFBLFFBQ1g7QUFBQSxNQUNGLFNBQVMsR0FBUDtBQUNBLGdCQUFRLE1BQU0sZ0NBQWdDLENBQUM7QUFFL0MsdUJBQWU7QUFDZixxQkFBYTtBQUNiLGlCQUFTO0FBQ1Qsb0JBQVk7QUFDWixpQkFBUztBQUFBLE1BQ1g7QUFJQSxVQUFJLE9BQU8sV0FBVyxZQUFZLFdBQVcsUUFBUyxPQUFlLFVBQVU7QUFFN0UsbUJBQVksT0FBZSxTQUFTLE1BQU0sS0FBSyxFQUFFLENBQUMsS0FBTSxPQUFlO0FBQ3ZFLHVCQUFlLFlBQWUsU0FBUyxNQUFNLEtBQUssRUFBRSxDQUFDLE1BQXRDLG1CQUF5QyxVQUFVLEdBQUcsT0FBTTtBQUFBLE1BQzdFLFdBQVcsT0FBTyxXQUFXLFVBQVU7QUFFckMsbUJBQVcsT0FBTyxNQUFNLEtBQUssRUFBRSxDQUFDLEtBQUs7QUFDckMsdUJBQWMsWUFBTyxNQUFNLEtBQUssRUFBRSxDQUFDLE1BQXJCLG1CQUF3QixVQUFVLEdBQUcsT0FBTTtBQUFBLE1BQzNELE9BQU87QUFFTCxtQkFBVztBQUNYLHFCQUFhO0FBQUEsTUFDZjtBQUVBLGFBQU87QUFBQSxRQUNMO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRU0sbUJBQW1CLElBQVM7QUFBQTtBQWxicEM7QUFtYkksVUFBSSxnQkFBZ0I7QUFDcEIsVUFBSSxTQUFTO0FBQ2IsVUFBSSxXQUFXO0FBQ2YsVUFBSSxhQUFhO0FBQ2pCLFVBQUksT0FBTztBQUVYLFVBQUk7QUFDRixZQUFJLE1BQU0sR0FBRyxVQUFVLEdBQUcsT0FBTyxRQUFRO0FBQ3ZDLDJCQUFnQixNQUFNLEdBQUcsT0FBTyxPQUFPLGtCQUFrQixFQUFFLE1BQUs7QUFFaEUsZ0JBQU0sY0FBYyxHQUFHLElBQUksTUFBTSxpQkFBaUIsRUFBRSxPQUFPLENBQUMsTUFBVztBQUNyRSxrQkFBTSxRQUFRLEdBQUcsSUFBSSxjQUFjLGFBQWEsQ0FBQztBQUNqRCxtQkFBTyxVQUNKLE1BQU0sUUFBUSxNQUFNLEtBQUssS0FBSyxDQUFDLFFBQWEsSUFBSSxRQUFRLGNBQWMsS0FDdEUsTUFBTSxlQUFlLE1BQU0sWUFBWSxnQkFBZ0IsWUFDdkQsTUFBTSxlQUFlLE1BQU0sWUFBWSxTQUN0QyxNQUFNLFFBQVEsTUFBTSxZQUFZLElBQUksSUFDakMsTUFBTSxZQUFZLEtBQUssU0FBUyxhQUFhLElBQzdDLE1BQU0sWUFBWSxTQUFTO0FBQUEsVUFFcEMsQ0FBQztBQUVELG1CQUFTLE1BQU0sR0FBRyxPQUFPO0FBQUEsWUFDdkIsTUFBTSxZQUFZLElBQUksQ0FBQyxNQUFXLEVBQUUsUUFBUTtBQUFBLFlBQzVDO0FBQUEsVUFDRjtBQUNBLGdCQUFNLGNBQWMsR0FBRyxJQUFJLE1BQU0sU0FBUyxFQUFFLE9BQU8sQ0FBQyxNQUFXLEVBQUUsY0FBYyxLQUFLLEVBQUUsSUFBSSxDQUFDLE1BQVcsRUFBRSxRQUFRO0FBQ2hILGlCQUFPLE1BQU0sR0FBRyxPQUFPLFVBQVUsYUFBYSxhQUFhLFVBQVU7QUFBQSxRQUN2RSxPQUFPO0FBRUwsMEJBQWdCO0FBQ2hCLG1CQUFTO0FBQ1QsaUJBQU87QUFBQSxRQUNUO0FBQUEsTUFDRixTQUFTLEdBQVA7QUFDQSxnQkFBUSxNQUFNLGlDQUFpQyxDQUFDO0FBRWhELHdCQUFnQjtBQUNoQixpQkFBUztBQUNULGVBQU87QUFBQSxNQUNUO0FBR0EsaUJBQVcsU0FBUyxPQUFPLE1BQU0sS0FBSyxFQUFFLENBQUMsS0FBSyxTQUFTO0FBQ3ZELG1CQUFhLFdBQVUsWUFBTyxNQUFNLEtBQUssRUFBRSxDQUFDLE1BQXJCLG1CQUF3QixVQUFVLEdBQUcsT0FBTSxRQUFTO0FBRTNFLGFBQU87QUFBQSxRQUNMO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVNLGVBQWU7QUFBQTtBQUNuQixXQUFLLFdBQVcsT0FBTyxPQUFPLENBQUMsR0FBRyxrQkFBa0IsTUFBTSxLQUFLLFNBQVMsQ0FBQztBQUFBLElBQzNFO0FBQUE7QUFBQSxFQUVNLGVBQWU7QUFBQTtBQUNuQixZQUFNLEtBQUssU0FBUyxLQUFLLFFBQVE7QUFBQSxJQUNuQztBQUFBO0FBQ0Y7IiwKICAibmFtZXMiOiBbImltcG9ydF9vYnNpZGlhbiIsICJpbXBvcnRfb2JzaWRpYW4iLCAiaW1wb3J0X29ic2lkaWFuIiwgImltcG9ydF9vYnNpZGlhbiIsICJpbXBvcnRfb2JzaWRpYW4iLCAiaW1wb3J0X29ic2lkaWFuIiwgImltcG9ydF9vYnNpZGlhbiIsICJpbXBvcnRfb2JzaWRpYW4iLCAiX2EiLCAiY291cnNlTmFtZSIsICJjb3Vyc2VJZCJdCn0K
