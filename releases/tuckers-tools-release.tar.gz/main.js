var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __async = (__this, __arguments, generator) => {
  return new Promise((resolve, reject) => {
    var fulfilled = (value) => {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    };
    var rejected = (value) => {
      try {
        step(generator.throw(value));
      } catch (e) {
        reject(e);
      }
    };
    var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
    step((generator = generator.apply(__this, __arguments)).next());
  });
};

// main.ts
var main_exports = {};
__export(main_exports, {
  default: () => TuckersToolsPlugin
});
module.exports = __toCommonJS(main_exports);
var import_obsidian2 = require("obsidian");

// settings.ts
var import_obsidian = require("obsidian");

// utils.ts
function validateDate(dateString) {
  const regex = /^\d{4}-\d{2}-\d{2}$/;
  if (!dateString.match(regex))
    return false;
  const date = new Date(dateString);
  const timestamp = date.getTime();
  if (typeof timestamp !== "number" || isNaN(timestamp))
    return false;
  return dateString === date.toISOString().split("T")[0];
}

// settings.ts
var DEFAULT_SETTINGS = {
  baseDirectory: "/",
  semesterStartDate: new Date().toISOString().split("T")[0],
  semesterEndDate: new Date(new Date().setMonth(new Date().getMonth() + 4)).toISOString().split("T")[0],
  schoolName: "University",
  schoolAbbreviation: "U",
  templateFolder: "Tuckers Tools",
  useEnhancedMetadata: false
};
var TuckersToolsSettingTab = class extends import_obsidian.PluginSettingTab {
  constructor(app, plugin) {
    super(app, plugin);
    this.plugin = plugin;
  }
  display() {
    const { containerEl } = this;
    containerEl.empty();
    containerEl.createEl("h2", { text: "Tuckers Tools Settings" });
    new import_obsidian.Setting(containerEl).setName("Base Directory").setDesc("Root directory for course content organization").addText((text) => text.setPlaceholder("/").setValue(this.plugin.settings.baseDirectory).onChange((value) => __async(this, null, function* () {
      this.plugin.settings.baseDirectory = value;
      yield this.plugin.saveSettings();
    })));
    const startDateSetting = new import_obsidian.Setting(containerEl).setName("Semester Start Date").setDesc("Start date for the current semester").addText((text) => text.setPlaceholder("YYYY-MM-DD").setValue(this.plugin.settings.semesterStartDate).onChange((value) => __async(this, null, function* () {
      if (value && !validateDate(value)) {
        startDateSetting.setDesc("Start date for the current semester (Invalid date format)");
      } else {
        startDateSetting.setDesc("Start date for the current semester");
      }
      this.plugin.settings.semesterStartDate = value;
      yield this.plugin.saveSettings();
    })));
    const endDateSetting = new import_obsidian.Setting(containerEl).setName("Semester End Date").setDesc("End date for the current semester").addText((text) => text.setPlaceholder("YYYY-MM-DD").setValue(this.plugin.settings.semesterEndDate).onChange((value) => __async(this, null, function* () {
      if (value && !validateDate(value)) {
        endDateSetting.setDesc("End date for the current semester (Invalid date format)");
      } else {
        endDateSetting.setDesc("End date for the current semester");
      }
      this.plugin.settings.semesterEndDate = value;
      yield this.plugin.saveSettings();
    })));
    new import_obsidian.Setting(containerEl).setName("School Name").setDesc("Name of your institution").addText((text) => text.setPlaceholder("University").setValue(this.plugin.settings.schoolName).onChange((value) => __async(this, null, function* () {
      this.plugin.settings.schoolName = value;
      yield this.plugin.saveSettings();
    })));
    new import_obsidian.Setting(containerEl).setName("School Abbreviation").setDesc("Abbreviation for your institution").addText((text) => text.setPlaceholder("U").setValue(this.plugin.settings.schoolAbbreviation).onChange((value) => __async(this, null, function* () {
      this.plugin.settings.schoolAbbreviation = value;
      yield this.plugin.saveSettings();
    })));
    new import_obsidian.Setting(containerEl).setName("Template Folder").setDesc("Subfolder within your Templater template folder for Tuckers Tools templates").addText((text) => text.setPlaceholder("Tuckers Tools").setValue(this.plugin.settings.templateFolder).onChange((value) => __async(this, null, function* () {
      this.plugin.settings.templateFolder = value;
      yield this.plugin.saveSettings();
    })));
    new import_obsidian.Setting(containerEl).setName("Use Enhanced Metadata").setDesc("Enable enhanced metadata fields for new notes (existing notes remain unchanged)").addToggle((toggle) => toggle.setValue(this.plugin.settings.useEnhancedMetadata).onChange((value) => __async(this, null, function* () {
      this.plugin.settings.useEnhancedMetadata = value;
      yield this.plugin.saveSettings();
    })));
  }
};

// templateManager.ts
var TemplateManager = class {
  constructor(app, settings) {
    this.app = app;
    this.settings = settings;
    this.manifest = {
      version: "1.0.0",
      templates: {
        "Courses/Create Course Homepage.md": "1.0.0",
        "Courses/Course Index.md": "1.0.0",
        "Modules/Create Module.md": "1.0.0",
        "Chapters/Create Chapter.md": "1.0.0",
        "Assignments/Create Assignment.md": "1.0.0",
        "Daily/Daily Note.md": "1.0.0",
        "Utilities/Vocabulary Entry.md": "1.0.0",
        "Utilities/Due Date Entry.md": "1.0.0"
      },
      plugin_version: "1.0.0",
      release_notes: "Initial release of Tuckers Tools templates"
    };
  }
  installTemplates() {
    return __async(this, null, function* () {
      const templaterPlugin = this.app.plugins.plugins["templater-obsidian"];
      if (!templaterPlugin) {
        console.error("Templater plugin not found");
        return;
      }
      const templaterSettings = templaterPlugin.settings;
      const templateFolderPath = templaterSettings["template_folder"];
      if (!templateFolderPath) {
        console.error("Template folder not configured in Templater settings");
        return;
      }
      const fullTemplatePath = `${templateFolderPath}/${this.settings.templateFolder}`;
      try {
        yield this.app.vault.createFolder(fullTemplatePath);
      } catch (e) {
      }
      const subdirs = ["Courses", "Modules", "Chapters", "Assignments", "Daily", "Utilities"];
      for (const subdir of subdirs) {
        try {
          yield this.app.vault.createFolder(`${fullTemplatePath}/${subdir}`);
        } catch (e) {
        }
      }
      yield this.installCourseTemplates(fullTemplatePath);
      yield this.installModuleTemplates(fullTemplatePath);
      yield this.installChapterTemplates(fullTemplatePath);
      yield this.installAssignmentTemplates(fullTemplatePath);
      yield this.installDailyTemplates(fullTemplatePath);
      yield this.installUtilityTemplates(fullTemplatePath);
      yield this.createREADME(fullTemplatePath);
      yield this.createTemplateManifest(fullTemplatePath);
      console.log("Tuckers Tools templates installed successfully");
    });
  }
  createTemplateManifest(basePath) {
    return __async(this, null, function* () {
      const manifestPath = `${basePath}/template-manifest.json`;
      const manifestContent = JSON.stringify(this.manifest, null, 2);
      try {
        const existingManifest = this.app.vault.getAbstractFileByPath(manifestPath);
        if (existingManifest) {
          return;
        }
        yield this.app.vault.create(manifestPath, manifestContent);
      } catch (e) {
        console.error(`Error creating template manifest ${manifestPath}:`, e);
      }
    });
  }
  checkForTemplateUpdates() {
    return __async(this, null, function* () {
      console.log("Checking for template updates");
      return false;
    });
  }
  updateTemplates() {
    return __async(this, null, function* () {
      console.log("Updating templates");
    });
  }
  installCourseTemplates(basePath) {
    return __async(this, null, function* () {
      const coursePath = `${basePath}/Courses`;
      const courseHomepageTemplate = this.generateCourseHomepageTemplate();
      yield this.writeTemplateFile(`${coursePath}/Create Course Homepage.md`, courseHomepageTemplate);
      const courseIndexTemplate = this.generateCourseIndexTemplate();
      yield this.writeTemplateFile(`${coursePath}/Course Index.md`, courseIndexTemplate);
    });
  }
  installModuleTemplates(basePath) {
    return __async(this, null, function* () {
      const modulePath = `${basePath}/Modules`;
      const moduleTemplate = this.generateModuleTemplate();
      yield this.writeTemplateFile(`${modulePath}/Create Module.md`, moduleTemplate);
    });
  }
  installChapterTemplates(basePath) {
    return __async(this, null, function* () {
      const chapterPath = `${basePath}/Chapters`;
      const chapterTemplate = this.generateChapterTemplate();
      yield this.writeTemplateFile(`${chapterPath}/Create Chapter.md`, chapterTemplate);
    });
  }
  installAssignmentTemplates(basePath) {
    return __async(this, null, function* () {
      const assignmentPath = `${basePath}/Assignments`;
      const assignmentTemplate = this.generateAssignmentTemplate();
      yield this.writeTemplateFile(`${assignmentPath}/Create Assignment.md`, assignmentTemplate);
    });
  }
  installDailyTemplates(basePath) {
    return __async(this, null, function* () {
      const dailyPath = `${basePath}/Daily`;
      const dailyNoteTemplate = this.generateDailyNoteTemplate();
      yield this.writeTemplateFile(`${dailyPath}/Daily Note.md`, dailyNoteTemplate);
    });
  }
  installUtilityTemplates(basePath) {
    return __async(this, null, function* () {
      const utilityPath = `${basePath}/Utilities`;
      const vocabTemplate = this.generateVocabularyTemplate();
      yield this.writeTemplateFile(`${utilityPath}/Vocabulary Entry.md`, vocabTemplate);
      const dueDateTemplate = this.generateDueDateTemplate();
      yield this.writeTemplateFile(`${utilityPath}/Due Date Entry.md`, dueDateTemplate);
    });
  }
  writeTemplateFile(path, content) {
    return __async(this, null, function* () {
      try {
        const existingFile = this.app.vault.getAbstractFileByPath(path);
        if (existingFile) {
          return;
        }
        yield this.app.vault.create(path, content);
      } catch (e) {
        console.error(`Error creating template file ${path}:`, e);
      }
    });
  }
  generateCourseHomepageTemplate() {
    return `---
${this.settings.useEnhancedMetadata ? `course_id: <% courseId %>
course_name: <% courseName %>
course_term: <% courseSeason %> <% courseYear %>
course_year: <% courseYear %>
course_semester: <% courseSeason %>
content_type: course_homepage
school: ${this.settings.schoolName}
school_abbreviation: ${this.settings.schoolAbbreviation}` : `course_id: <% courseId %>
title: <% courseName %>`}
created: <% tp.date.now("YYYY-MM-DD[T]HH:mm:ssZ") %>
tags: 
  - course_home
  - education
  - <% courseId %>
  - ${this.settings.schoolAbbreviation}/<% courseYear %>/<% courseSeason %>/<% courseId %>
---

<%*
const { exec } = require("child_process");
let courseName = await tp.system.prompt("Course Name (e.g. PSI-101 - Intro to Psych)")
let courseSeason = await tp.system.suggester(["Fall","Winter","Spring","Summer"],["Fall","Winter","Spring","Summer"], "Season")
let courseYear = await tp.system.prompt("Year")
let courseId = courseName.split(' - ')[0]
await tp.file.move(\`/\${courseYear}/\${courseSeason}/\${courseName}/\${courseName}\`)
try {await app.vault.createFolder(\`\${courseYear}/\${courseSeason}/\${courseName}/Attachments\`)} catch (e) {}
%>

# <% courseName %>

## Course Information
**Course ID**: <% courseId %>
**Term**: <% courseSeason %> <% courseYear %>
**School**: ${this.settings.schoolName}

## Instructor
**Name**: 
**Email**: 
**Office Hours**: 

## Course Description

## Learning Objectives

## Required Texts
\`\`\`meta-bind-js-view
{texts} as texts
---
const availableTexts = app.vault.getFiles().filter(file => file.extension == 'pdf').map(f => f?.name)
const escapeRegex = /[,"\`'()]/g;
options = availableTexts.map(t => \`option([[\${t.replace(escapeRegex,\`\\\\$1\`)}]], \${t.replace(escapeRegex,\`\\\\$1\`)})\` )
const str = \\\`INPUT[inlineListSuggester(\${options.join(", ")}):texts]\\\`
return engine.markdown.create(str)
\`\`\`

## Schedule

## Assignments

## Resources

## Vocabulary
\`\`\`dataviewjs
// Vocabulary aggregation code would go here
\`\`\`

## Due Dates
\`\`\`dataviewjs
// Due dates aggregation code would go here
\`\`\``;
  }
  generateCourseIndexTemplate() {
    return `---
content_type: course_index
tags:
  - index
---

# Course Index

## Modules

## Chapters

## Assignments

## Resources

## Vocabulary

## Due Dates`;
  }
  generateModuleTemplate() {
    return `---
${this.settings.useEnhancedMetadata ? `course_id: <% courseId %>
module_number: <% moduleNumber %>
week_number: <% weekNumber %>
class_day: <% dayOfWeek %>
content_type: module
parent_course: "[[<% course %>]]"` : `course_id: <% courseId %>
module_number: <% moduleNumber %>
week_number: <% weekNumber %>
class_day: <% dayOfWeek %>`}
created: <% tp.date.now("YYYY-MM-DD[T]HH:mm:ssZ") %>
tags:
  - education
  - <% courseId %>
  - module
---

<%*
const { season, moduleNumber, weekNumber, course, courseId, discipline, dayOfWeek } = await tp.user.new_module(app, tp, "2025");
let title = courseId
if (moduleNumber && weekNumber) { title = \`M\${moduleNumber}/W\${weekNumber}\`}
else if (moduleNumber) { title = \`M\${moduleNumber}\` } 
else if (weekNumber) { title = \`W\${weekNumber}\`}
%>

# [[<% course %>]] - <% title %> - <% dayOfWeek %>

## Learning Objectives

## Reading Assignment

## Lecture Notes

## Discussion Questions

## Assignments
| Date | Assignment | Status |
| ---- | ---------- | ------ |
|      |            |        |

## Vocabulary

## Additional Resources`;
  }
  generateChapterTemplate() {
    return `---
${this.settings.useEnhancedMetadata ? `course_id: <% courseId %>
chapter_number: <% chapterNumber %>
content_type: chapter
parent_course: "[[<% course %>]]"
text_reference: "[[<% text %>]]"` : `course_id: <% courseId %>
chapter_number: <% chapterNumber %>`}
created: <% tp.date.now("YYYY-MM-DD[T]HH:mm:ssZ") %>
tags:
  - education
  - <% courseId %>
  - chapter
---

<%*
const { chapterNumber, course, courseId, discipline, text} = await tp.user.new_chapter(tp);
%>

# [[<% text %>]] - Chapter <% chapterNumber %>

## Summary

## Key Concepts

## Vocabulary
- 

## Notes

## Discussion Questions

## Further Reading`;
  }
  generateAssignmentTemplate() {
    return `---
${this.settings.useEnhancedMetadata ? `course_id: <% courseId %>
assignment_type: <% assignmentType %>
due_date: <% dueDate %>
points: <% points %>
content_type: assignment
parent_course: "[[<% course %>]]"` : `course_id: <% courseId %>
assignment_type: <% assignmentType %>
due_date: <% dueDate %>`}
created: <% tp.date.now("YYYY-MM-DD[T]HH:mm:ssZ") %>
status: pending
tags:
  - education
  - <% courseId %>
  - assignment
---

# <% assignmentName %> - <% courseId %>

## Description

## Instructions

## Due Date
**Assigned**: <% tp.date.now("YYYY-MM-DD") %>
**Due**: <% dueDate %>

## Submission

## Grading Criteria

## Resources`;
  }
  generateDailyNoteTemplate() {
    return `---
content_type: daily_note
date: <% tp.date.now("YYYY-MM-DD") %>
tags:
  - daily
  - <% tp.date.now("YYYY") %>
  - <% tp.date.now("MM") %>
  - <% tp.date.now("DD") %>
---

# <% tp.date.now("YYYY-MM-DD - dddd") %>

<< [[<% tp.date.yesterday("YYYY-MM-DD") %>]] | [[<% tp.date.tomorrow("YYYY-MM-DD") %>]] >>

## Today's Focus

## Courses Worked On
- 

## Tasks Completed
- [ ] 

## Vocabulary Reviewed
- 

## Assignments Due
- 

## Learning Achievements

## Challenges

## Tomorrow's Plan

## Reflection`;
  }
  generateVocabularyTemplate() {
    return `## <% term %>
**Term**: <% term %>
**Part of Speech**: 
**Definition**: 
**Context**: 
**Examples**: 
**Related Terms**: 
**See Also**:`;
  }
  generateDueDateTemplate() {
    return `| <% dueDate %> | <% assignment %> | <% status %> |`;
  }
  createREADME(basePath) {
    return __async(this, null, function* () {
      const readmeContent = `# Tuckers Tools Templates

This directory contains templates for the Tuckers Tools Obsidian plugin.

## Template Categories

- **Courses**: Templates for creating and organizing courses
- **Modules**: Templates for course modules
- **Chapters**: Templates for chapter notes
- **Assignments**: Templates for assignments
- **Daily**: Templates for daily notes
- **Utilities**: Helper templates

## Usage

These templates are designed to work with the Tuckers Tools plugin. To use them:

1. Install the Tuckers Tools plugin
2. Configure your settings in the plugin settings tab
3. Use the "Insert Template" command to apply these templates to new notes

## Customization

Feel free to customize these templates to suit your needs. The plugin will not overwrite your changes when updating templates.`;
      yield this.writeTemplateFile(`${basePath}/README.md`, readmeContent);
    });
  }
};

// main.ts
var TuckersToolsPlugin = class extends import_obsidian2.Plugin {
  onload() {
    return __async(this, null, function* () {
      console.log("Loading Tuckers Tools plugin");
      yield this.loadSettings();
      this.templateManager = new TemplateManager(this.app, this.settings);
      this.addSettingTab(new TuckersToolsSettingTab(this.app, this));
      this.addCommand({
        id: "install-templates",
        name: "Install/Update Tuckers Tools Templates",
        callback: () => {
          this.templateManager.installTemplates();
        }
      });
      this.addCommand({
        id: "update-templates",
        name: "Update Tuckers Tools Templates",
        callback: () => {
          this.templateManager.updateTemplates();
        }
      });
      this.addStatusBarItem().setText("Tuckers Tools");
    });
  }
  onunload() {
    console.log("Unloading Tuckers Tools plugin");
  }
  loadSettings() {
    return __async(this, null, function* () {
      this.settings = Object.assign({}, DEFAULT_SETTINGS, yield this.loadData());
    });
  }
  saveSettings() {
    return __async(this, null, function* () {
      yield this.saveData(this.settings);
    });
  }
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsibWFpbi50cyIsICJzZXR0aW5ncy50cyIsICJ1dGlscy50cyIsICJ0ZW1wbGF0ZU1hbmFnZXIudHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbImltcG9ydCB7IFBsdWdpbiB9IGZyb20gJ29ic2lkaWFuJztcbmltcG9ydCB7IFR1Y2tlcnNUb29sc1NldHRpbmdzLCBERUZBVUxUX1NFVFRJTkdTLCBUdWNrZXJzVG9vbHNTZXR0aW5nVGFiIH0gZnJvbSAnLi9zZXR0aW5ncyc7XG5pbXBvcnQgeyBUZW1wbGF0ZU1hbmFnZXIgfSBmcm9tICcuL3RlbXBsYXRlTWFuYWdlcic7XG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFR1Y2tlcnNUb29sc1BsdWdpbiBleHRlbmRzIFBsdWdpbiB7XG4gIHNldHRpbmdzOiBUdWNrZXJzVG9vbHNTZXR0aW5ncztcbiAgdGVtcGxhdGVNYW5hZ2VyOiBUZW1wbGF0ZU1hbmFnZXI7XG5cbiAgYXN5bmMgb25sb2FkKCkge1xuICAgIGNvbnNvbGUubG9nKCdMb2FkaW5nIFR1Y2tlcnMgVG9vbHMgcGx1Z2luJyk7XG5cbiAgICAvLyBMb2FkIHNldHRpbmdzXG4gICAgYXdhaXQgdGhpcy5sb2FkU2V0dGluZ3MoKTtcblxuICAgIC8vIEluaXRpYWxpemUgdGVtcGxhdGUgbWFuYWdlclxuICAgIHRoaXMudGVtcGxhdGVNYW5hZ2VyID0gbmV3IFRlbXBsYXRlTWFuYWdlcih0aGlzLmFwcCwgdGhpcy5zZXR0aW5ncyk7XG5cbiAgICAvLyBBZGQgc2V0dGluZ3MgdGFiXG4gICAgdGhpcy5hZGRTZXR0aW5nVGFiKG5ldyBUdWNrZXJzVG9vbHNTZXR0aW5nVGFiKHRoaXMuYXBwLCB0aGlzKSk7XG5cbiAgICAvLyBBZGQgY29tbWFuZHNcbiAgICB0aGlzLmFkZENvbW1hbmQoe1xuICAgICAgaWQ6ICdpbnN0YWxsLXRlbXBsYXRlcycsXG4gICAgICBuYW1lOiAnSW5zdGFsbC9VcGRhdGUgVHVja2VycyBUb29scyBUZW1wbGF0ZXMnLFxuICAgICAgY2FsbGJhY2s6ICgpID0+IHtcbiAgICAgICAgdGhpcy50ZW1wbGF0ZU1hbmFnZXIuaW5zdGFsbFRlbXBsYXRlcygpO1xuICAgICAgfVxuICAgIH0pO1xuXG4gICAgdGhpcy5hZGRDb21tYW5kKHtcbiAgICAgIGlkOiAndXBkYXRlLXRlbXBsYXRlcycsXG4gICAgICBuYW1lOiAnVXBkYXRlIFR1Y2tlcnMgVG9vbHMgVGVtcGxhdGVzJyxcbiAgICAgIGNhbGxiYWNrOiAoKSA9PiB7XG4gICAgICAgIHRoaXMudGVtcGxhdGVNYW5hZ2VyLnVwZGF0ZVRlbXBsYXRlcygpO1xuICAgICAgfVxuICAgIH0pO1xuXG4gICAgLy8gQWRkIHN0YXR1cyBiYXIgaXRlbVxuICAgIHRoaXMuYWRkU3RhdHVzQmFySXRlbSgpLnNldFRleHQoJ1R1Y2tlcnMgVG9vbHMnKTtcbiAgfVxuXG4gIG9udW5sb2FkKCkge1xuICAgIGNvbnNvbGUubG9nKCdVbmxvYWRpbmcgVHVja2VycyBUb29scyBwbHVnaW4nKTtcbiAgfVxuXG4gIGFzeW5jIGxvYWRTZXR0aW5ncygpIHtcbiAgICB0aGlzLnNldHRpbmdzID0gT2JqZWN0LmFzc2lnbih7fSwgREVGQVVMVF9TRVRUSU5HUywgYXdhaXQgdGhpcy5sb2FkRGF0YSgpKTtcbiAgfVxuXG4gIGFzeW5jIHNhdmVTZXR0aW5ncygpIHtcbiAgICBhd2FpdCB0aGlzLnNhdmVEYXRhKHRoaXMuc2V0dGluZ3MpO1xuICB9XG59IiwgImltcG9ydCB7IEFwcCwgUGx1Z2luU2V0dGluZ1RhYiwgU2V0dGluZyB9IGZyb20gJ29ic2lkaWFuJztcbmltcG9ydCBUdWNrZXJzVG9vbHNQbHVnaW4gZnJvbSAnLi9tYWluJztcbmltcG9ydCB7IHZhbGlkYXRlRGF0ZSB9IGZyb20gJy4vdXRpbHMnO1xuXG5leHBvcnQgaW50ZXJmYWNlIFR1Y2tlcnNUb29sc1NldHRpbmdzIHtcbiAgYmFzZURpcmVjdG9yeTogc3RyaW5nO1xuICBzZW1lc3RlclN0YXJ0RGF0ZTogc3RyaW5nO1xuICBzZW1lc3RlckVuZERhdGU6IHN0cmluZztcbiAgc2Nob29sTmFtZTogc3RyaW5nO1xuICBzY2hvb2xBYmJyZXZpYXRpb246IHN0cmluZztcbiAgdGVtcGxhdGVGb2xkZXI6IHN0cmluZztcbiAgdXNlRW5oYW5jZWRNZXRhZGF0YTogYm9vbGVhbjtcbn1cblxuZXhwb3J0IGNvbnN0IERFRkFVTFRfU0VUVElOR1M6IFR1Y2tlcnNUb29sc1NldHRpbmdzID0ge1xuICBiYXNlRGlyZWN0b3J5OiAnLycsXG4gIHNlbWVzdGVyU3RhcnREYXRlOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc3BsaXQoJ1QnKVswXSxcbiAgc2VtZXN0ZXJFbmREYXRlOiBuZXcgRGF0ZShuZXcgRGF0ZSgpLnNldE1vbnRoKG5ldyBEYXRlKCkuZ2V0TW9udGgoKSArIDQpKS50b0lTT1N0cmluZygpLnNwbGl0KCdUJylbMF0sXG4gIHNjaG9vbE5hbWU6ICdVbml2ZXJzaXR5JyxcbiAgc2Nob29sQWJicmV2aWF0aW9uOiAnVScsXG4gIHRlbXBsYXRlRm9sZGVyOiAnVHVja2VycyBUb29scycsXG4gIHVzZUVuaGFuY2VkTWV0YWRhdGE6IGZhbHNlXG59XG5cbmV4cG9ydCBjbGFzcyBUdWNrZXJzVG9vbHNTZXR0aW5nVGFiIGV4dGVuZHMgUGx1Z2luU2V0dGluZ1RhYiB7XG4gIHBsdWdpbjogVHVja2Vyc1Rvb2xzUGx1Z2luO1xuXG4gIGNvbnN0cnVjdG9yKGFwcDogQXBwLCBwbHVnaW46IFR1Y2tlcnNUb29sc1BsdWdpbikge1xuICAgIHN1cGVyKGFwcCwgcGx1Z2luKTtcbiAgICB0aGlzLnBsdWdpbiA9IHBsdWdpbjtcbiAgfVxuXG4gIGRpc3BsYXkoKTogdm9pZCB7XG4gICAgY29uc3QgeyBjb250YWluZXJFbCB9ID0gdGhpcztcblxuICAgIGNvbnRhaW5lckVsLmVtcHR5KCk7XG5cbiAgICBjb250YWluZXJFbC5jcmVhdGVFbCgnaDInLCB7IHRleHQ6ICdUdWNrZXJzIFRvb2xzIFNldHRpbmdzJyB9KTtcblxuICAgIG5ldyBTZXR0aW5nKGNvbnRhaW5lckVsKVxuICAgICAgLnNldE5hbWUoJ0Jhc2UgRGlyZWN0b3J5JylcbiAgICAgIC5zZXREZXNjKCdSb290IGRpcmVjdG9yeSBmb3IgY291cnNlIGNvbnRlbnQgb3JnYW5pemF0aW9uJylcbiAgICAgIC5hZGRUZXh0KHRleHQgPT4gdGV4dFxuICAgICAgICAuc2V0UGxhY2Vob2xkZXIoJy8nKVxuICAgICAgICAuc2V0VmFsdWUodGhpcy5wbHVnaW4uc2V0dGluZ3MuYmFzZURpcmVjdG9yeSlcbiAgICAgICAgLm9uQ2hhbmdlKGFzeW5jICh2YWx1ZSkgPT4ge1xuICAgICAgICAgIHRoaXMucGx1Z2luLnNldHRpbmdzLmJhc2VEaXJlY3RvcnkgPSB2YWx1ZTtcbiAgICAgICAgICBhd2FpdCB0aGlzLnBsdWdpbi5zYXZlU2V0dGluZ3MoKTtcbiAgICAgICAgfSkpO1xuXG4gICAgY29uc3Qgc3RhcnREYXRlU2V0dGluZyA9IG5ldyBTZXR0aW5nKGNvbnRhaW5lckVsKVxuICAgICAgLnNldE5hbWUoJ1NlbWVzdGVyIFN0YXJ0IERhdGUnKVxuICAgICAgLnNldERlc2MoJ1N0YXJ0IGRhdGUgZm9yIHRoZSBjdXJyZW50IHNlbWVzdGVyJylcbiAgICAgIC5hZGRUZXh0KHRleHQgPT4gdGV4dFxuICAgICAgICAuc2V0UGxhY2Vob2xkZXIoJ1lZWVktTU0tREQnKVxuICAgICAgICAuc2V0VmFsdWUodGhpcy5wbHVnaW4uc2V0dGluZ3Muc2VtZXN0ZXJTdGFydERhdGUpXG4gICAgICAgIC5vbkNoYW5nZShhc3luYyAodmFsdWUpID0+IHtcbiAgICAgICAgICBpZiAodmFsdWUgJiYgIXZhbGlkYXRlRGF0ZSh2YWx1ZSkpIHtcbiAgICAgICAgICAgIHN0YXJ0RGF0ZVNldHRpbmcuc2V0RGVzYygnU3RhcnQgZGF0ZSBmb3IgdGhlIGN1cnJlbnQgc2VtZXN0ZXIgKEludmFsaWQgZGF0ZSBmb3JtYXQpJyk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHN0YXJ0RGF0ZVNldHRpbmcuc2V0RGVzYygnU3RhcnQgZGF0ZSBmb3IgdGhlIGN1cnJlbnQgc2VtZXN0ZXInKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgdGhpcy5wbHVnaW4uc2V0dGluZ3Muc2VtZXN0ZXJTdGFydERhdGUgPSB2YWx1ZTtcbiAgICAgICAgICBhd2FpdCB0aGlzLnBsdWdpbi5zYXZlU2V0dGluZ3MoKTtcbiAgICAgICAgfSkpO1xuXG4gICAgY29uc3QgZW5kRGF0ZVNldHRpbmcgPSBuZXcgU2V0dGluZyhjb250YWluZXJFbClcbiAgICAgIC5zZXROYW1lKCdTZW1lc3RlciBFbmQgRGF0ZScpXG4gICAgICAuc2V0RGVzYygnRW5kIGRhdGUgZm9yIHRoZSBjdXJyZW50IHNlbWVzdGVyJylcbiAgICAgIC5hZGRUZXh0KHRleHQgPT4gdGV4dFxuICAgICAgICAuc2V0UGxhY2Vob2xkZXIoJ1lZWVktTU0tREQnKVxuICAgICAgICAuc2V0VmFsdWUodGhpcy5wbHVnaW4uc2V0dGluZ3Muc2VtZXN0ZXJFbmREYXRlKVxuICAgICAgICAub25DaGFuZ2UoYXN5bmMgKHZhbHVlKSA9PiB7XG4gICAgICAgICAgaWYgKHZhbHVlICYmICF2YWxpZGF0ZURhdGUodmFsdWUpKSB7XG4gICAgICAgICAgICBlbmREYXRlU2V0dGluZy5zZXREZXNjKCdFbmQgZGF0ZSBmb3IgdGhlIGN1cnJlbnQgc2VtZXN0ZXIgKEludmFsaWQgZGF0ZSBmb3JtYXQpJyk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGVuZERhdGVTZXR0aW5nLnNldERlc2MoJ0VuZCBkYXRlIGZvciB0aGUgY3VycmVudCBzZW1lc3RlcicpO1xuICAgICAgICAgIH1cbiAgICAgICAgICB0aGlzLnBsdWdpbi5zZXR0aW5ncy5zZW1lc3RlckVuZERhdGUgPSB2YWx1ZTtcbiAgICAgICAgICBhd2FpdCB0aGlzLnBsdWdpbi5zYXZlU2V0dGluZ3MoKTtcbiAgICAgICAgfSkpO1xuXG4gICAgbmV3IFNldHRpbmcoY29udGFpbmVyRWwpXG4gICAgICAuc2V0TmFtZSgnU2Nob29sIE5hbWUnKVxuICAgICAgLnNldERlc2MoJ05hbWUgb2YgeW91ciBpbnN0aXR1dGlvbicpXG4gICAgICAuYWRkVGV4dCh0ZXh0ID0+IHRleHRcbiAgICAgICAgLnNldFBsYWNlaG9sZGVyKCdVbml2ZXJzaXR5JylcbiAgICAgICAgLnNldFZhbHVlKHRoaXMucGx1Z2luLnNldHRpbmdzLnNjaG9vbE5hbWUpXG4gICAgICAgIC5vbkNoYW5nZShhc3luYyAodmFsdWUpID0+IHtcbiAgICAgICAgICB0aGlzLnBsdWdpbi5zZXR0aW5ncy5zY2hvb2xOYW1lID0gdmFsdWU7XG4gICAgICAgICAgYXdhaXQgdGhpcy5wbHVnaW4uc2F2ZVNldHRpbmdzKCk7XG4gICAgICAgIH0pKTtcblxuICAgIG5ldyBTZXR0aW5nKGNvbnRhaW5lckVsKVxuICAgICAgLnNldE5hbWUoJ1NjaG9vbCBBYmJyZXZpYXRpb24nKVxuICAgICAgLnNldERlc2MoJ0FiYnJldmlhdGlvbiBmb3IgeW91ciBpbnN0aXR1dGlvbicpXG4gICAgICAuYWRkVGV4dCh0ZXh0ID0+IHRleHRcbiAgICAgICAgLnNldFBsYWNlaG9sZGVyKCdVJylcbiAgICAgICAgLnNldFZhbHVlKHRoaXMucGx1Z2luLnNldHRpbmdzLnNjaG9vbEFiYnJldmlhdGlvbilcbiAgICAgICAgLm9uQ2hhbmdlKGFzeW5jICh2YWx1ZSkgPT4ge1xuICAgICAgICAgIHRoaXMucGx1Z2luLnNldHRpbmdzLnNjaG9vbEFiYnJldmlhdGlvbiA9IHZhbHVlO1xuICAgICAgICAgIGF3YWl0IHRoaXMucGx1Z2luLnNhdmVTZXR0aW5ncygpO1xuICAgICAgICB9KSk7XG5cbiAgICBuZXcgU2V0dGluZyhjb250YWluZXJFbClcbiAgICAgIC5zZXROYW1lKCdUZW1wbGF0ZSBGb2xkZXInKVxuICAgICAgLnNldERlc2MoJ1N1YmZvbGRlciB3aXRoaW4geW91ciBUZW1wbGF0ZXIgdGVtcGxhdGUgZm9sZGVyIGZvciBUdWNrZXJzIFRvb2xzIHRlbXBsYXRlcycpXG4gICAgICAuYWRkVGV4dCh0ZXh0ID0+IHRleHRcbiAgICAgICAgLnNldFBsYWNlaG9sZGVyKCdUdWNrZXJzIFRvb2xzJylcbiAgICAgICAgLnNldFZhbHVlKHRoaXMucGx1Z2luLnNldHRpbmdzLnRlbXBsYXRlRm9sZGVyKVxuICAgICAgICAub25DaGFuZ2UoYXN5bmMgKHZhbHVlKSA9PiB7XG4gICAgICAgICAgdGhpcy5wbHVnaW4uc2V0dGluZ3MudGVtcGxhdGVGb2xkZXIgPSB2YWx1ZTtcbiAgICAgICAgICBhd2FpdCB0aGlzLnBsdWdpbi5zYXZlU2V0dGluZ3MoKTtcbiAgICAgICAgfSkpO1xuXG4gICAgbmV3IFNldHRpbmcoY29udGFpbmVyRWwpXG4gICAgICAuc2V0TmFtZSgnVXNlIEVuaGFuY2VkIE1ldGFkYXRhJylcbiAgICAgIC5zZXREZXNjKCdFbmFibGUgZW5oYW5jZWQgbWV0YWRhdGEgZmllbGRzIGZvciBuZXcgbm90ZXMgKGV4aXN0aW5nIG5vdGVzIHJlbWFpbiB1bmNoYW5nZWQpJylcbiAgICAgIC5hZGRUb2dnbGUodG9nZ2xlID0+IHRvZ2dsZVxuICAgICAgICAuc2V0VmFsdWUodGhpcy5wbHVnaW4uc2V0dGluZ3MudXNlRW5oYW5jZWRNZXRhZGF0YSlcbiAgICAgICAgLm9uQ2hhbmdlKGFzeW5jICh2YWx1ZSkgPT4ge1xuICAgICAgICAgIHRoaXMucGx1Z2luLnNldHRpbmdzLnVzZUVuaGFuY2VkTWV0YWRhdGEgPSB2YWx1ZTtcbiAgICAgICAgICBhd2FpdCB0aGlzLnBsdWdpbi5zYXZlU2V0dGluZ3MoKTtcbiAgICAgICAgfSkpO1xuICB9XG59IiwgIi8vIFV0aWxpdHkgZnVuY3Rpb25zIGZvciBUdWNrZXJzIFRvb2xzIHBsdWdpblxuXG5leHBvcnQgZnVuY3Rpb24gZm9ybWF0RGF0ZShkYXRlOiBEYXRlKTogc3RyaW5nIHtcbiAgcmV0dXJuIGRhdGUudG9JU09TdHJpbmcoKS5zcGxpdCgnVCcpWzBdO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gYWRkRGF5cyhkYXRlOiBEYXRlLCBkYXlzOiBudW1iZXIpOiBEYXRlIHtcbiAgY29uc3QgcmVzdWx0ID0gbmV3IERhdGUoZGF0ZSk7XG4gIHJlc3VsdC5zZXREYXRlKHJlc3VsdC5nZXREYXRlKCkgKyBkYXlzKTtcbiAgcmV0dXJuIHJlc3VsdDtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGlzQmV0d2VlbihkYXRlOiBEYXRlLCBzdGFydDogRGF0ZSwgZW5kOiBEYXRlKTogYm9vbGVhbiB7XG4gIHJldHVybiBkYXRlID49IHN0YXJ0ICYmIGRhdGUgPD0gZW5kO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gc2x1Z2lmeSh0ZXh0OiBzdHJpbmcpOiBzdHJpbmcge1xuICByZXR1cm4gdGV4dFxuICAgIC50b0xvd2VyQ2FzZSgpXG4gICAgLnRyaW0oKVxuICAgIC5ub3JtYWxpemUoJ05GRCcpXG4gICAgLnJlcGxhY2UoL1tcXHUwMzAwLVxcdTAzNmZdL2csICcnKVxuICAgIC5yZXBsYWNlKC9bXmEtejAtOVxccy1dL2csICcnKVxuICAgIC5yZXBsYWNlKC9bXFxzLV0rL2csICctJylcbiAgICAucmVwbGFjZSgvXi0rfC0rJC9nLCAnJyk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBnZXRDb3Vyc2VJZEZyb21QYXRoKHBhdGg6IHN0cmluZyk6IHN0cmluZyB8IG51bGwge1xuICAvLyBFeHRyYWN0IGNvdXJzZSBJRCBmcm9tIHBhdGggbGlrZSBcIjIwMjUvRmFsbC9QU0ktMTAxLy4uLlwiXG4gIGNvbnN0IHBhcnRzID0gcGF0aC5zcGxpdCgnLycpO1xuICBmb3IgKGNvbnN0IHBhcnQgb2YgcGFydHMpIHtcbiAgICBpZiAocGFydC5tYXRjaCgvXltBLVpdezIsNH0tXFxkezN9JC8pKSB7XG4gICAgICByZXR1cm4gcGFydDtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIG51bGw7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiB2YWxpZGF0ZURhdGUoZGF0ZVN0cmluZzogc3RyaW5nKTogYm9vbGVhbiB7XG4gIGNvbnN0IHJlZ2V4ID0gL15cXGR7NH0tXFxkezJ9LVxcZHsyfSQvO1xuICBpZiAoIWRhdGVTdHJpbmcubWF0Y2gocmVnZXgpKSByZXR1cm4gZmFsc2U7XG4gIFxuICBjb25zdCBkYXRlID0gbmV3IERhdGUoZGF0ZVN0cmluZyk7XG4gIGNvbnN0IHRpbWVzdGFtcCA9IGRhdGUuZ2V0VGltZSgpO1xuICBcbiAgaWYgKHR5cGVvZiB0aW1lc3RhbXAgIT09ICdudW1iZXInIHx8IGlzTmFOKHRpbWVzdGFtcCkpIHJldHVybiBmYWxzZTtcbiAgXG4gIHJldHVybiBkYXRlU3RyaW5nID09PSBkYXRlLnRvSVNPU3RyaW5nKCkuc3BsaXQoJ1QnKVswXTtcbn0iLCAiaW1wb3J0IHsgQXBwIH0gZnJvbSAnb2JzaWRpYW4nO1xuaW1wb3J0IHsgVHVja2Vyc1Rvb2xzU2V0dGluZ3MgfSBmcm9tICcuL3NldHRpbmdzJztcblxuaW50ZXJmYWNlIFRlbXBsYXRlTWFuaWZlc3Qge1xuICB2ZXJzaW9uOiBzdHJpbmc7XG4gIHRlbXBsYXRlczogUmVjb3JkPHN0cmluZywgc3RyaW5nPjtcbiAgcGx1Z2luX3ZlcnNpb246IHN0cmluZztcbiAgcmVsZWFzZV9ub3Rlczogc3RyaW5nO1xufVxuXG5leHBvcnQgY2xhc3MgVGVtcGxhdGVNYW5hZ2VyIHtcbiAgYXBwOiBBcHA7XG4gIHNldHRpbmdzOiBUdWNrZXJzVG9vbHNTZXR0aW5ncztcbiAgbWFuaWZlc3Q6IFRlbXBsYXRlTWFuaWZlc3Q7XG5cbiAgY29uc3RydWN0b3IoYXBwOiBBcHAsIHNldHRpbmdzOiBUdWNrZXJzVG9vbHNTZXR0aW5ncykge1xuICAgIHRoaXMuYXBwID0gYXBwO1xuICAgIHRoaXMuc2V0dGluZ3MgPSBzZXR0aW5ncztcbiAgICB0aGlzLm1hbmlmZXN0ID0ge1xuICAgICAgdmVyc2lvbjogXCIxLjAuMFwiLFxuICAgICAgdGVtcGxhdGVzOiB7XG4gICAgICAgIFwiQ291cnNlcy9DcmVhdGUgQ291cnNlIEhvbWVwYWdlLm1kXCI6IFwiMS4wLjBcIixcbiAgICAgICAgXCJDb3Vyc2VzL0NvdXJzZSBJbmRleC5tZFwiOiBcIjEuMC4wXCIsXG4gICAgICAgIFwiTW9kdWxlcy9DcmVhdGUgTW9kdWxlLm1kXCI6IFwiMS4wLjBcIixcbiAgICAgICAgXCJDaGFwdGVycy9DcmVhdGUgQ2hhcHRlci5tZFwiOiBcIjEuMC4wXCIsXG4gICAgICAgIFwiQXNzaWdubWVudHMvQ3JlYXRlIEFzc2lnbm1lbnQubWRcIjogXCIxLjAuMFwiLFxuICAgICAgICBcIkRhaWx5L0RhaWx5IE5vdGUubWRcIjogXCIxLjAuMFwiLFxuICAgICAgICBcIlV0aWxpdGllcy9Wb2NhYnVsYXJ5IEVudHJ5Lm1kXCI6IFwiMS4wLjBcIixcbiAgICAgICAgXCJVdGlsaXRpZXMvRHVlIERhdGUgRW50cnkubWRcIjogXCIxLjAuMFwiXG4gICAgICB9LFxuICAgICAgcGx1Z2luX3ZlcnNpb246IFwiMS4wLjBcIixcbiAgICAgIHJlbGVhc2Vfbm90ZXM6IFwiSW5pdGlhbCByZWxlYXNlIG9mIFR1Y2tlcnMgVG9vbHMgdGVtcGxhdGVzXCJcbiAgICB9O1xuICB9XG5cbiAgYXN5bmMgaW5zdGFsbFRlbXBsYXRlcygpIHtcbiAgICAvLyBHZXQgVGVtcGxhdGVyIHBsdWdpbiBzZXR0aW5ncyB0byBmaW5kIHRlbXBsYXRlIGZvbGRlclxuICAgIGNvbnN0IHRlbXBsYXRlclBsdWdpbiA9ICh0aGlzLmFwcCBhcyBhbnkpLnBsdWdpbnMucGx1Z2luc1sndGVtcGxhdGVyLW9ic2lkaWFuJ107XG4gICAgaWYgKCF0ZW1wbGF0ZXJQbHVnaW4pIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ1RlbXBsYXRlciBwbHVnaW4gbm90IGZvdW5kJyk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgY29uc3QgdGVtcGxhdGVyU2V0dGluZ3MgPSB0ZW1wbGF0ZXJQbHVnaW4uc2V0dGluZ3M7XG4gICAgY29uc3QgdGVtcGxhdGVGb2xkZXJQYXRoID0gdGVtcGxhdGVyU2V0dGluZ3NbJ3RlbXBsYXRlX2ZvbGRlciddO1xuXG4gICAgaWYgKCF0ZW1wbGF0ZUZvbGRlclBhdGgpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ1RlbXBsYXRlIGZvbGRlciBub3QgY29uZmlndXJlZCBpbiBUZW1wbGF0ZXIgc2V0dGluZ3MnKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBjb25zdCBmdWxsVGVtcGxhdGVQYXRoID0gYCR7dGVtcGxhdGVGb2xkZXJQYXRofS8ke3RoaXMuc2V0dGluZ3MudGVtcGxhdGVGb2xkZXJ9YDtcbiAgICBcbiAgICAvLyBDcmVhdGUgdGhlIG1haW4gdGVtcGxhdGUgZm9sZGVyIGlmIGl0IGRvZXNuJ3QgZXhpc3RcbiAgICB0cnkge1xuICAgICAgYXdhaXQgdGhpcy5hcHAudmF1bHQuY3JlYXRlRm9sZGVyKGZ1bGxUZW1wbGF0ZVBhdGgpO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIC8vIEZvbGRlciBtaWdodCBhbHJlYWR5IGV4aXN0LCB3aGljaCBpcyBmaW5lXG4gICAgfVxuXG4gICAgLy8gQ3JlYXRlIHN1YmRpcmVjdG9yaWVzXG4gICAgY29uc3Qgc3ViZGlycyA9IFsnQ291cnNlcycsICdNb2R1bGVzJywgJ0NoYXB0ZXJzJywgJ0Fzc2lnbm1lbnRzJywgJ0RhaWx5JywgJ1V0aWxpdGllcyddO1xuICAgIGZvciAoY29uc3Qgc3ViZGlyIG9mIHN1YmRpcnMpIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGF3YWl0IHRoaXMuYXBwLnZhdWx0LmNyZWF0ZUZvbGRlcihgJHtmdWxsVGVtcGxhdGVQYXRofS8ke3N1YmRpcn1gKTtcbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgLy8gRm9sZGVyIG1pZ2h0IGFscmVhZHkgZXhpc3QsIHdoaWNoIGlzIGZpbmVcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBJbnN0YWxsIHRlbXBsYXRlc1xuICAgIGF3YWl0IHRoaXMuaW5zdGFsbENvdXJzZVRlbXBsYXRlcyhmdWxsVGVtcGxhdGVQYXRoKTtcbiAgICBhd2FpdCB0aGlzLmluc3RhbGxNb2R1bGVUZW1wbGF0ZXMoZnVsbFRlbXBsYXRlUGF0aCk7XG4gICAgYXdhaXQgdGhpcy5pbnN0YWxsQ2hhcHRlclRlbXBsYXRlcyhmdWxsVGVtcGxhdGVQYXRoKTtcbiAgICBhd2FpdCB0aGlzLmluc3RhbGxBc3NpZ25tZW50VGVtcGxhdGVzKGZ1bGxUZW1wbGF0ZVBhdGgpO1xuICAgIGF3YWl0IHRoaXMuaW5zdGFsbERhaWx5VGVtcGxhdGVzKGZ1bGxUZW1wbGF0ZVBhdGgpO1xuICAgIGF3YWl0IHRoaXMuaW5zdGFsbFV0aWxpdHlUZW1wbGF0ZXMoZnVsbFRlbXBsYXRlUGF0aCk7XG4gICAgXG4gICAgLy8gQ3JlYXRlIFJFQURNRVxuICAgIGF3YWl0IHRoaXMuY3JlYXRlUkVBRE1FKGZ1bGxUZW1wbGF0ZVBhdGgpO1xuICAgIFxuICAgIC8vIENyZWF0ZSB0ZW1wbGF0ZSBtYW5pZmVzdFxuICAgIGF3YWl0IHRoaXMuY3JlYXRlVGVtcGxhdGVNYW5pZmVzdChmdWxsVGVtcGxhdGVQYXRoKTtcbiAgICBcbiAgICBjb25zb2xlLmxvZygnVHVja2VycyBUb29scyB0ZW1wbGF0ZXMgaW5zdGFsbGVkIHN1Y2Nlc3NmdWxseScpO1xuICB9XG5cbiAgYXN5bmMgY3JlYXRlVGVtcGxhdGVNYW5pZmVzdChiYXNlUGF0aDogc3RyaW5nKSB7XG4gICAgY29uc3QgbWFuaWZlc3RQYXRoID0gYCR7YmFzZVBhdGh9L3RlbXBsYXRlLW1hbmlmZXN0Lmpzb25gO1xuICAgIGNvbnN0IG1hbmlmZXN0Q29udGVudCA9IEpTT04uc3RyaW5naWZ5KHRoaXMubWFuaWZlc3QsIG51bGwsIDIpO1xuICAgIFxuICAgIHRyeSB7XG4gICAgICAvLyBDaGVjayBpZiBtYW5pZmVzdCBhbHJlYWR5IGV4aXN0c1xuICAgICAgY29uc3QgZXhpc3RpbmdNYW5pZmVzdCA9IHRoaXMuYXBwLnZhdWx0LmdldEFic3RyYWN0RmlsZUJ5UGF0aChtYW5pZmVzdFBhdGgpO1xuICAgICAgaWYgKGV4aXN0aW5nTWFuaWZlc3QpIHtcbiAgICAgICAgLy8gRm9yIG5vdywgd2Ugd29uJ3Qgb3ZlcndyaXRlIHRoZSBtYW5pZmVzdFxuICAgICAgICAvLyBJbiBhIHJlYWwgaW1wbGVtZW50YXRpb24sIHdlJ2QgY2hlY2sgdmVyc2lvbnMgYW5kIG9mZmVyIHRvIHVwZGF0ZVxuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBcbiAgICAgIC8vIENyZWF0ZSB0aGUgbWFuaWZlc3QgZmlsZVxuICAgICAgYXdhaXQgdGhpcy5hcHAudmF1bHQuY3JlYXRlKG1hbmlmZXN0UGF0aCwgbWFuaWZlc3RDb250ZW50KTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBjb25zb2xlLmVycm9yKGBFcnJvciBjcmVhdGluZyB0ZW1wbGF0ZSBtYW5pZmVzdCAke21hbmlmZXN0UGF0aH06YCwgZSk7XG4gICAgfVxuICB9XG5cbiAgYXN5bmMgY2hlY2tGb3JUZW1wbGF0ZVVwZGF0ZXMoKTogUHJvbWlzZTxib29sZWFuPiB7XG4gICAgLy8gVGhpcyB3b3VsZCBjaGVjayBpZiB0ZW1wbGF0ZXMgbmVlZCB0byBiZSB1cGRhdGVkXG4gICAgLy8gRm9yIG5vdywgd2UnbGwganVzdCByZXR1cm4gZmFsc2VcbiAgICBjb25zb2xlLmxvZyhcIkNoZWNraW5nIGZvciB0ZW1wbGF0ZSB1cGRhdGVzXCIpO1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuXG4gIGFzeW5jIHVwZGF0ZVRlbXBsYXRlcygpIHtcbiAgICAvLyBUaGlzIHdvdWxkIHVwZGF0ZSBleGlzdGluZyB0ZW1wbGF0ZXNcbiAgICAvLyBGb3Igbm93LCB3ZSdsbCBqdXN0IGxvZyB0aGF0IGl0IHdvdWxkIGJlIGNhbGxlZFxuICAgIGNvbnNvbGUubG9nKFwiVXBkYXRpbmcgdGVtcGxhdGVzXCIpO1xuICAgIFxuICAgIC8vIEluIGEgcmVhbCBpbXBsZW1lbnRhdGlvbiwgdGhpcyB3b3VsZDpcbiAgICAvLyAxLiBDaGVjayB0ZW1wbGF0ZSBtYW5pZmVzdCBmb3IgdmVyc2lvbiBpbmZvcm1hdGlvblxuICAgIC8vIDIuIENvbXBhcmUgd2l0aCBjdXJyZW50IHRlbXBsYXRlIHZlcnNpb25zXG4gICAgLy8gMy4gVXBkYXRlIHRlbXBsYXRlcyB0aGF0IGhhdmUgbmV3ZXIgdmVyc2lvbnNcbiAgICAvLyA0LiBQcmVzZXJ2ZSB1c2VyIGN1c3RvbWl6YXRpb25zXG4gIH1cblxuICBhc3luYyBpbnN0YWxsQ291cnNlVGVtcGxhdGVzKGJhc2VQYXRoOiBzdHJpbmcpIHtcbiAgICBjb25zdCBjb3Vyc2VQYXRoID0gYCR7YmFzZVBhdGh9L0NvdXJzZXNgO1xuICAgIFxuICAgIC8vIENyZWF0ZSBDb3Vyc2UgSG9tZXBhZ2UgdGVtcGxhdGVcbiAgICBjb25zdCBjb3Vyc2VIb21lcGFnZVRlbXBsYXRlID0gdGhpcy5nZW5lcmF0ZUNvdXJzZUhvbWVwYWdlVGVtcGxhdGUoKTtcbiAgICBhd2FpdCB0aGlzLndyaXRlVGVtcGxhdGVGaWxlKGAke2NvdXJzZVBhdGh9L0NyZWF0ZSBDb3Vyc2UgSG9tZXBhZ2UubWRgLCBjb3Vyc2VIb21lcGFnZVRlbXBsYXRlKTtcbiAgICBcbiAgICAvLyBDcmVhdGUgQ291cnNlIEluZGV4IHRlbXBsYXRlXG4gICAgY29uc3QgY291cnNlSW5kZXhUZW1wbGF0ZSA9IHRoaXMuZ2VuZXJhdGVDb3Vyc2VJbmRleFRlbXBsYXRlKCk7XG4gICAgYXdhaXQgdGhpcy53cml0ZVRlbXBsYXRlRmlsZShgJHtjb3Vyc2VQYXRofS9Db3Vyc2UgSW5kZXgubWRgLCBjb3Vyc2VJbmRleFRlbXBsYXRlKTtcbiAgfVxuXG4gIGFzeW5jIGluc3RhbGxNb2R1bGVUZW1wbGF0ZXMoYmFzZVBhdGg6IHN0cmluZykge1xuICAgIGNvbnN0IG1vZHVsZVBhdGggPSBgJHtiYXNlUGF0aH0vTW9kdWxlc2A7XG4gICAgXG4gICAgLy8gQ3JlYXRlIE1vZHVsZSB0ZW1wbGF0ZVxuICAgIGNvbnN0IG1vZHVsZVRlbXBsYXRlID0gdGhpcy5nZW5lcmF0ZU1vZHVsZVRlbXBsYXRlKCk7XG4gICAgYXdhaXQgdGhpcy53cml0ZVRlbXBsYXRlRmlsZShgJHttb2R1bGVQYXRofS9DcmVhdGUgTW9kdWxlLm1kYCwgbW9kdWxlVGVtcGxhdGUpO1xuICB9XG5cbiAgYXN5bmMgaW5zdGFsbENoYXB0ZXJUZW1wbGF0ZXMoYmFzZVBhdGg6IHN0cmluZykge1xuICAgIGNvbnN0IGNoYXB0ZXJQYXRoID0gYCR7YmFzZVBhdGh9L0NoYXB0ZXJzYDtcbiAgICBcbiAgICAvLyBDcmVhdGUgQ2hhcHRlciB0ZW1wbGF0ZVxuICAgIGNvbnN0IGNoYXB0ZXJUZW1wbGF0ZSA9IHRoaXMuZ2VuZXJhdGVDaGFwdGVyVGVtcGxhdGUoKTtcbiAgICBhd2FpdCB0aGlzLndyaXRlVGVtcGxhdGVGaWxlKGAke2NoYXB0ZXJQYXRofS9DcmVhdGUgQ2hhcHRlci5tZGAsIGNoYXB0ZXJUZW1wbGF0ZSk7XG4gIH1cblxuICBhc3luYyBpbnN0YWxsQXNzaWdubWVudFRlbXBsYXRlcyhiYXNlUGF0aDogc3RyaW5nKSB7XG4gICAgY29uc3QgYXNzaWdubWVudFBhdGggPSBgJHtiYXNlUGF0aH0vQXNzaWdubWVudHNgO1xuICAgIFxuICAgIC8vIENyZWF0ZSBBc3NpZ25tZW50IHRlbXBsYXRlXG4gICAgY29uc3QgYXNzaWdubWVudFRlbXBsYXRlID0gdGhpcy5nZW5lcmF0ZUFzc2lnbm1lbnRUZW1wbGF0ZSgpO1xuICAgIGF3YWl0IHRoaXMud3JpdGVUZW1wbGF0ZUZpbGUoYCR7YXNzaWdubWVudFBhdGh9L0NyZWF0ZSBBc3NpZ25tZW50Lm1kYCwgYXNzaWdubWVudFRlbXBsYXRlKTtcbiAgfVxuXG4gIGFzeW5jIGluc3RhbGxEYWlseVRlbXBsYXRlcyhiYXNlUGF0aDogc3RyaW5nKSB7XG4gICAgY29uc3QgZGFpbHlQYXRoID0gYCR7YmFzZVBhdGh9L0RhaWx5YDtcbiAgICBcbiAgICAvLyBDcmVhdGUgRGFpbHkgTm90ZSB0ZW1wbGF0ZVxuICAgIGNvbnN0IGRhaWx5Tm90ZVRlbXBsYXRlID0gdGhpcy5nZW5lcmF0ZURhaWx5Tm90ZVRlbXBsYXRlKCk7XG4gICAgYXdhaXQgdGhpcy53cml0ZVRlbXBsYXRlRmlsZShgJHtkYWlseVBhdGh9L0RhaWx5IE5vdGUubWRgLCBkYWlseU5vdGVUZW1wbGF0ZSk7XG4gIH1cblxuICBhc3luYyBpbnN0YWxsVXRpbGl0eVRlbXBsYXRlcyhiYXNlUGF0aDogc3RyaW5nKSB7XG4gICAgY29uc3QgdXRpbGl0eVBhdGggPSBgJHtiYXNlUGF0aH0vVXRpbGl0aWVzYDtcbiAgICBcbiAgICAvLyBDcmVhdGUgVm9jYWJ1bGFyeSBFbnRyeSB0ZW1wbGF0ZVxuICAgIGNvbnN0IHZvY2FiVGVtcGxhdGUgPSB0aGlzLmdlbmVyYXRlVm9jYWJ1bGFyeVRlbXBsYXRlKCk7XG4gICAgYXdhaXQgdGhpcy53cml0ZVRlbXBsYXRlRmlsZShgJHt1dGlsaXR5UGF0aH0vVm9jYWJ1bGFyeSBFbnRyeS5tZGAsIHZvY2FiVGVtcGxhdGUpO1xuICAgIFxuICAgIC8vIENyZWF0ZSBEdWUgRGF0ZSBFbnRyeSB0ZW1wbGF0ZVxuICAgIGNvbnN0IGR1ZURhdGVUZW1wbGF0ZSA9IHRoaXMuZ2VuZXJhdGVEdWVEYXRlVGVtcGxhdGUoKTtcbiAgICBhd2FpdCB0aGlzLndyaXRlVGVtcGxhdGVGaWxlKGAke3V0aWxpdHlQYXRofS9EdWUgRGF0ZSBFbnRyeS5tZGAsIGR1ZURhdGVUZW1wbGF0ZSk7XG4gIH1cblxuICBhc3luYyB3cml0ZVRlbXBsYXRlRmlsZShwYXRoOiBzdHJpbmcsIGNvbnRlbnQ6IHN0cmluZykge1xuICAgIHRyeSB7XG4gICAgICAvLyBDaGVjayBpZiBmaWxlIGFscmVhZHkgZXhpc3RzXG4gICAgICBjb25zdCBleGlzdGluZ0ZpbGUgPSB0aGlzLmFwcC52YXVsdC5nZXRBYnN0cmFjdEZpbGVCeVBhdGgocGF0aCk7XG4gICAgICBpZiAoZXhpc3RpbmdGaWxlKSB7XG4gICAgICAgIC8vIEZvciBub3csIHdlIHdvbid0IG92ZXJ3cml0ZSBleGlzdGluZyB0ZW1wbGF0ZXNcbiAgICAgICAgLy8gSW4gYSByZWFsIGltcGxlbWVudGF0aW9uLCB3ZSdkIGNoZWNrIHZlcnNpb25zIGFuZCBvZmZlciB0byB1cGRhdGVcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgXG4gICAgICAvLyBDcmVhdGUgdGhlIGZpbGVcbiAgICAgIGF3YWl0IHRoaXMuYXBwLnZhdWx0LmNyZWF0ZShwYXRoLCBjb250ZW50KTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBjb25zb2xlLmVycm9yKGBFcnJvciBjcmVhdGluZyB0ZW1wbGF0ZSBmaWxlICR7cGF0aH06YCwgZSk7XG4gICAgfVxuICB9XG5cbiAgZ2VuZXJhdGVDb3Vyc2VIb21lcGFnZVRlbXBsYXRlKCk6IHN0cmluZyB7XG4gICAgcmV0dXJuIGAtLS1cbiR7dGhpcy5zZXR0aW5ncy51c2VFbmhhbmNlZE1ldGFkYXRhID8gYGNvdXJzZV9pZDogPCUgY291cnNlSWQgJT5cbmNvdXJzZV9uYW1lOiA8JSBjb3Vyc2VOYW1lICU+XG5jb3Vyc2VfdGVybTogPCUgY291cnNlU2Vhc29uICU+IDwlIGNvdXJzZVllYXIgJT5cbmNvdXJzZV95ZWFyOiA8JSBjb3Vyc2VZZWFyICU+XG5jb3Vyc2Vfc2VtZXN0ZXI6IDwlIGNvdXJzZVNlYXNvbiAlPlxuY29udGVudF90eXBlOiBjb3Vyc2VfaG9tZXBhZ2VcbnNjaG9vbDogJHt0aGlzLnNldHRpbmdzLnNjaG9vbE5hbWV9XG5zY2hvb2xfYWJicmV2aWF0aW9uOiAke3RoaXMuc2V0dGluZ3Muc2Nob29sQWJicmV2aWF0aW9ufWAgOiBgY291cnNlX2lkOiA8JSBjb3Vyc2VJZCAlPlxudGl0bGU6IDwlIGNvdXJzZU5hbWUgJT5gfVxuY3JlYXRlZDogPCUgdHAuZGF0ZS5ub3coXCJZWVlZLU1NLUREW1RdSEg6bW06c3NaXCIpICU+XG50YWdzOiBcbiAgLSBjb3Vyc2VfaG9tZVxuICAtIGVkdWNhdGlvblxuICAtIDwlIGNvdXJzZUlkICU+XG4gIC0gJHt0aGlzLnNldHRpbmdzLnNjaG9vbEFiYnJldmlhdGlvbn0vPCUgY291cnNlWWVhciAlPi88JSBjb3Vyc2VTZWFzb24gJT4vPCUgY291cnNlSWQgJT5cbi0tLVxuXG48JSpcbmNvbnN0IHsgZXhlYyB9ID0gcmVxdWlyZShcImNoaWxkX3Byb2Nlc3NcIik7XG5sZXQgY291cnNlTmFtZSA9IGF3YWl0IHRwLnN5c3RlbS5wcm9tcHQoXCJDb3Vyc2UgTmFtZSAoZS5nLiBQU0ktMTAxIC0gSW50cm8gdG8gUHN5Y2gpXCIpXG5sZXQgY291cnNlU2Vhc29uID0gYXdhaXQgdHAuc3lzdGVtLnN1Z2dlc3RlcihbXCJGYWxsXCIsXCJXaW50ZXJcIixcIlNwcmluZ1wiLFwiU3VtbWVyXCJdLFtcIkZhbGxcIixcIldpbnRlclwiLFwiU3ByaW5nXCIsXCJTdW1tZXJcIl0sIFwiU2Vhc29uXCIpXG5sZXQgY291cnNlWWVhciA9IGF3YWl0IHRwLnN5c3RlbS5wcm9tcHQoXCJZZWFyXCIpXG5sZXQgY291cnNlSWQgPSBjb3Vyc2VOYW1lLnNwbGl0KCcgLSAnKVswXVxuYXdhaXQgdHAuZmlsZS5tb3ZlKFxcYC9cXCR7Y291cnNlWWVhcn0vXFwke2NvdXJzZVNlYXNvbn0vXFwke2NvdXJzZU5hbWV9L1xcJHtjb3Vyc2VOYW1lfVxcYClcbnRyeSB7YXdhaXQgYXBwLnZhdWx0LmNyZWF0ZUZvbGRlcihcXGBcXCR7Y291cnNlWWVhcn0vXFwke2NvdXJzZVNlYXNvbn0vXFwke2NvdXJzZU5hbWV9L0F0dGFjaG1lbnRzXFxgKX0gY2F0Y2ggKGUpIHt9XG4lPlxuXG4jIDwlIGNvdXJzZU5hbWUgJT5cblxuIyMgQ291cnNlIEluZm9ybWF0aW9uXG4qKkNvdXJzZSBJRCoqOiA8JSBjb3Vyc2VJZCAlPlxuKipUZXJtKio6IDwlIGNvdXJzZVNlYXNvbiAlPiA8JSBjb3Vyc2VZZWFyICU+XG4qKlNjaG9vbCoqOiAke3RoaXMuc2V0dGluZ3Muc2Nob29sTmFtZX1cblxuIyMgSW5zdHJ1Y3RvclxuKipOYW1lKio6IFxuKipFbWFpbCoqOiBcbioqT2ZmaWNlIEhvdXJzKio6IFxuXG4jIyBDb3Vyc2UgRGVzY3JpcHRpb25cblxuIyMgTGVhcm5pbmcgT2JqZWN0aXZlc1xuXG4jIyBSZXF1aXJlZCBUZXh0c1xuXFxgXFxgXFxgbWV0YS1iaW5kLWpzLXZpZXdcbnt0ZXh0c30gYXMgdGV4dHNcbi0tLVxuY29uc3QgYXZhaWxhYmxlVGV4dHMgPSBhcHAudmF1bHQuZ2V0RmlsZXMoKS5maWx0ZXIoZmlsZSA9PiBmaWxlLmV4dGVuc2lvbiA9PSAncGRmJykubWFwKGYgPT4gZj8ubmFtZSlcbmNvbnN0IGVzY2FwZVJlZ2V4ID0gL1ssXFxcIlxcYCcoKV0vZztcbm9wdGlvbnMgPSBhdmFpbGFibGVUZXh0cy5tYXAodCA9PiBcXGBvcHRpb24oW1tcXCR7dC5yZXBsYWNlKGVzY2FwZVJlZ2V4LFxcYFxcXFxcXFxcJDFcXGApfV1dLCBcXCR7dC5yZXBsYWNlKGVzY2FwZVJlZ2V4LFxcYFxcXFxcXFxcJDFcXGApfSlcXGAgKVxuY29uc3Qgc3RyID0gXFxcXFxcYElOUFVUW2lubGluZUxpc3RTdWdnZXN0ZXIoXFwke29wdGlvbnMuam9pbihcIiwgXCIpfSk6dGV4dHNdXFxcXFxcYFxucmV0dXJuIGVuZ2luZS5tYXJrZG93bi5jcmVhdGUoc3RyKVxuXFxgXFxgXFxgXG5cbiMjIFNjaGVkdWxlXG5cbiMjIEFzc2lnbm1lbnRzXG5cbiMjIFJlc291cmNlc1xuXG4jIyBWb2NhYnVsYXJ5XG5cXGBcXGBcXGBkYXRhdmlld2pzXG4vLyBWb2NhYnVsYXJ5IGFnZ3JlZ2F0aW9uIGNvZGUgd291bGQgZ28gaGVyZVxuXFxgXFxgXFxgXG5cbiMjIER1ZSBEYXRlc1xuXFxgXFxgXFxgZGF0YXZpZXdqc1xuLy8gRHVlIGRhdGVzIGFnZ3JlZ2F0aW9uIGNvZGUgd291bGQgZ28gaGVyZVxuXFxgXFxgXFxgYDtcbiAgfVxuXG4gIGdlbmVyYXRlQ291cnNlSW5kZXhUZW1wbGF0ZSgpOiBzdHJpbmcge1xuICAgIHJldHVybiBgLS0tXG5jb250ZW50X3R5cGU6IGNvdXJzZV9pbmRleFxudGFnczpcbiAgLSBpbmRleFxuLS0tXG5cbiMgQ291cnNlIEluZGV4XG5cbiMjIE1vZHVsZXNcblxuIyMgQ2hhcHRlcnNcblxuIyMgQXNzaWdubWVudHNcblxuIyMgUmVzb3VyY2VzXG5cbiMjIFZvY2FidWxhcnlcblxuIyMgRHVlIERhdGVzYDtcbiAgfVxuXG4gIGdlbmVyYXRlTW9kdWxlVGVtcGxhdGUoKTogc3RyaW5nIHtcbiAgICByZXR1cm4gYC0tLVxuJHt0aGlzLnNldHRpbmdzLnVzZUVuaGFuY2VkTWV0YWRhdGEgPyBgY291cnNlX2lkOiA8JSBjb3Vyc2VJZCAlPlxubW9kdWxlX251bWJlcjogPCUgbW9kdWxlTnVtYmVyICU+XG53ZWVrX251bWJlcjogPCUgd2Vla051bWJlciAlPlxuY2xhc3NfZGF5OiA8JSBkYXlPZldlZWsgJT5cbmNvbnRlbnRfdHlwZTogbW9kdWxlXG5wYXJlbnRfY291cnNlOiBcIltbPCUgY291cnNlICU+XV1cImAgOiBgY291cnNlX2lkOiA8JSBjb3Vyc2VJZCAlPlxubW9kdWxlX251bWJlcjogPCUgbW9kdWxlTnVtYmVyICU+XG53ZWVrX251bWJlcjogPCUgd2Vla051bWJlciAlPlxuY2xhc3NfZGF5OiA8JSBkYXlPZldlZWsgJT5gfVxuY3JlYXRlZDogPCUgdHAuZGF0ZS5ub3coXCJZWVlZLU1NLUREW1RdSEg6bW06c3NaXCIpICU+XG50YWdzOlxuICAtIGVkdWNhdGlvblxuICAtIDwlIGNvdXJzZUlkICU+XG4gIC0gbW9kdWxlXG4tLS1cblxuPCUqXG5jb25zdCB7IHNlYXNvbiwgbW9kdWxlTnVtYmVyLCB3ZWVrTnVtYmVyLCBjb3Vyc2UsIGNvdXJzZUlkLCBkaXNjaXBsaW5lLCBkYXlPZldlZWsgfSA9IGF3YWl0IHRwLnVzZXIubmV3X21vZHVsZShhcHAsIHRwLCBcIjIwMjVcIik7XG5sZXQgdGl0bGUgPSBjb3Vyc2VJZFxuaWYgKG1vZHVsZU51bWJlciAmJiB3ZWVrTnVtYmVyKSB7IHRpdGxlID0gXFxgTVxcJHttb2R1bGVOdW1iZXJ9L1dcXCR7d2Vla051bWJlcn1cXGB9XG5lbHNlIGlmIChtb2R1bGVOdW1iZXIpIHsgdGl0bGUgPSBcXGBNXFwke21vZHVsZU51bWJlcn1cXGAgfSBcbmVsc2UgaWYgKHdlZWtOdW1iZXIpIHsgdGl0bGUgPSBcXGBXXFwke3dlZWtOdW1iZXJ9XFxgfVxuJT5cblxuIyBbWzwlIGNvdXJzZSAlPl1dIC0gPCUgdGl0bGUgJT4gLSA8JSBkYXlPZldlZWsgJT5cblxuIyMgTGVhcm5pbmcgT2JqZWN0aXZlc1xuXG4jIyBSZWFkaW5nIEFzc2lnbm1lbnRcblxuIyMgTGVjdHVyZSBOb3Rlc1xuXG4jIyBEaXNjdXNzaW9uIFF1ZXN0aW9uc1xuXG4jIyBBc3NpZ25tZW50c1xufCBEYXRlIHwgQXNzaWdubWVudCB8IFN0YXR1cyB8XG58IC0tLS0gfCAtLS0tLS0tLS0tIHwgLS0tLS0tIHxcbnwgICAgICB8ICAgICAgICAgICAgfCAgICAgICAgfFxuXG4jIyBWb2NhYnVsYXJ5XG5cbiMjIEFkZGl0aW9uYWwgUmVzb3VyY2VzYDtcbiAgfVxuXG4gIGdlbmVyYXRlQ2hhcHRlclRlbXBsYXRlKCk6IHN0cmluZyB7XG4gICAgcmV0dXJuIGAtLS1cbiR7dGhpcy5zZXR0aW5ncy51c2VFbmhhbmNlZE1ldGFkYXRhID8gYGNvdXJzZV9pZDogPCUgY291cnNlSWQgJT5cbmNoYXB0ZXJfbnVtYmVyOiA8JSBjaGFwdGVyTnVtYmVyICU+XG5jb250ZW50X3R5cGU6IGNoYXB0ZXJcbnBhcmVudF9jb3Vyc2U6IFwiW1s8JSBjb3Vyc2UgJT5dXVwiXG50ZXh0X3JlZmVyZW5jZTogXCJbWzwlIHRleHQgJT5dXVwiYCA6IGBjb3Vyc2VfaWQ6IDwlIGNvdXJzZUlkICU+XG5jaGFwdGVyX251bWJlcjogPCUgY2hhcHRlck51bWJlciAlPmB9XG5jcmVhdGVkOiA8JSB0cC5kYXRlLm5vdyhcIllZWVktTU0tRERbVF1ISDptbTpzc1pcIikgJT5cbnRhZ3M6XG4gIC0gZWR1Y2F0aW9uXG4gIC0gPCUgY291cnNlSWQgJT5cbiAgLSBjaGFwdGVyXG4tLS1cblxuPCUqXG5jb25zdCB7IGNoYXB0ZXJOdW1iZXIsIGNvdXJzZSwgY291cnNlSWQsIGRpc2NpcGxpbmUsIHRleHR9ID0gYXdhaXQgdHAudXNlci5uZXdfY2hhcHRlcih0cCk7XG4lPlxuXG4jIFtbPCUgdGV4dCAlPl1dIC0gQ2hhcHRlciA8JSBjaGFwdGVyTnVtYmVyICU+XG5cbiMjIFN1bW1hcnlcblxuIyMgS2V5IENvbmNlcHRzXG5cbiMjIFZvY2FidWxhcnlcbi0gXG5cbiMjIE5vdGVzXG5cbiMjIERpc2N1c3Npb24gUXVlc3Rpb25zXG5cbiMjIEZ1cnRoZXIgUmVhZGluZ2A7XG4gIH1cblxuICBnZW5lcmF0ZUFzc2lnbm1lbnRUZW1wbGF0ZSgpOiBzdHJpbmcge1xuICAgIHJldHVybiBgLS0tXG4ke3RoaXMuc2V0dGluZ3MudXNlRW5oYW5jZWRNZXRhZGF0YSA/IGBjb3Vyc2VfaWQ6IDwlIGNvdXJzZUlkICU+XG5hc3NpZ25tZW50X3R5cGU6IDwlIGFzc2lnbm1lbnRUeXBlICU+XG5kdWVfZGF0ZTogPCUgZHVlRGF0ZSAlPlxucG9pbnRzOiA8JSBwb2ludHMgJT5cbmNvbnRlbnRfdHlwZTogYXNzaWdubWVudFxucGFyZW50X2NvdXJzZTogXCJbWzwlIGNvdXJzZSAlPl1dXCJgIDogYGNvdXJzZV9pZDogPCUgY291cnNlSWQgJT5cbmFzc2lnbm1lbnRfdHlwZTogPCUgYXNzaWdubWVudFR5cGUgJT5cbmR1ZV9kYXRlOiA8JSBkdWVEYXRlICU+YH1cbmNyZWF0ZWQ6IDwlIHRwLmRhdGUubm93KFwiWVlZWS1NTS1ERFtUXUhIOm1tOnNzWlwiKSAlPlxuc3RhdHVzOiBwZW5kaW5nXG50YWdzOlxuICAtIGVkdWNhdGlvblxuICAtIDwlIGNvdXJzZUlkICU+XG4gIC0gYXNzaWdubWVudFxuLS0tXG5cbiMgPCUgYXNzaWdubWVudE5hbWUgJT4gLSA8JSBjb3Vyc2VJZCAlPlxuXG4jIyBEZXNjcmlwdGlvblxuXG4jIyBJbnN0cnVjdGlvbnNcblxuIyMgRHVlIERhdGVcbioqQXNzaWduZWQqKjogPCUgdHAuZGF0ZS5ub3coXCJZWVlZLU1NLUREXCIpICU+XG4qKkR1ZSoqOiA8JSBkdWVEYXRlICU+XG5cbiMjIFN1Ym1pc3Npb25cblxuIyMgR3JhZGluZyBDcml0ZXJpYVxuXG4jIyBSZXNvdXJjZXNgO1xuICB9XG5cbiAgZ2VuZXJhdGVEYWlseU5vdGVUZW1wbGF0ZSgpOiBzdHJpbmcge1xuICAgIHJldHVybiBgLS0tXG5jb250ZW50X3R5cGU6IGRhaWx5X25vdGVcbmRhdGU6IDwlIHRwLmRhdGUubm93KFwiWVlZWS1NTS1ERFwiKSAlPlxudGFnczpcbiAgLSBkYWlseVxuICAtIDwlIHRwLmRhdGUubm93KFwiWVlZWVwiKSAlPlxuICAtIDwlIHRwLmRhdGUubm93KFwiTU1cIikgJT5cbiAgLSA8JSB0cC5kYXRlLm5vdyhcIkREXCIpICU+XG4tLS1cblxuIyA8JSB0cC5kYXRlLm5vdyhcIllZWVktTU0tREQgLSBkZGRkXCIpICU+XG5cbjw8IFtbPCUgdHAuZGF0ZS55ZXN0ZXJkYXkoXCJZWVlZLU1NLUREXCIpICU+XV0gfCBbWzwlIHRwLmRhdGUudG9tb3Jyb3coXCJZWVlZLU1NLUREXCIpICU+XV0gPj5cblxuIyMgVG9kYXkncyBGb2N1c1xuXG4jIyBDb3Vyc2VzIFdvcmtlZCBPblxuLSBcblxuIyMgVGFza3MgQ29tcGxldGVkXG4tIFsgXSBcblxuIyMgVm9jYWJ1bGFyeSBSZXZpZXdlZFxuLSBcblxuIyMgQXNzaWdubWVudHMgRHVlXG4tIFxuXG4jIyBMZWFybmluZyBBY2hpZXZlbWVudHNcblxuIyMgQ2hhbGxlbmdlc1xuXG4jIyBUb21vcnJvdydzIFBsYW5cblxuIyMgUmVmbGVjdGlvbmA7XG4gIH1cblxuICBnZW5lcmF0ZVZvY2FidWxhcnlUZW1wbGF0ZSgpOiBzdHJpbmcge1xuICAgIHJldHVybiBgIyMgPCUgdGVybSAlPlxuKipUZXJtKio6IDwlIHRlcm0gJT5cbioqUGFydCBvZiBTcGVlY2gqKjogXG4qKkRlZmluaXRpb24qKjogXG4qKkNvbnRleHQqKjogXG4qKkV4YW1wbGVzKio6IFxuKipSZWxhdGVkIFRlcm1zKio6IFxuKipTZWUgQWxzbyoqOmA7XG4gIH1cblxuICBnZW5lcmF0ZUR1ZURhdGVUZW1wbGF0ZSgpOiBzdHJpbmcge1xuICAgIHJldHVybiBgfCA8JSBkdWVEYXRlICU+IHwgPCUgYXNzaWdubWVudCAlPiB8IDwlIHN0YXR1cyAlPiB8YDtcbiAgfVxuXG4gIGFzeW5jIGNyZWF0ZVJFQURNRShiYXNlUGF0aDogc3RyaW5nKSB7XG4gICAgY29uc3QgcmVhZG1lQ29udGVudCA9IGAjIFR1Y2tlcnMgVG9vbHMgVGVtcGxhdGVzXG5cblRoaXMgZGlyZWN0b3J5IGNvbnRhaW5zIHRlbXBsYXRlcyBmb3IgdGhlIFR1Y2tlcnMgVG9vbHMgT2JzaWRpYW4gcGx1Z2luLlxuXG4jIyBUZW1wbGF0ZSBDYXRlZ29yaWVzXG5cbi0gKipDb3Vyc2VzKio6IFRlbXBsYXRlcyBmb3IgY3JlYXRpbmcgYW5kIG9yZ2FuaXppbmcgY291cnNlc1xuLSAqKk1vZHVsZXMqKjogVGVtcGxhdGVzIGZvciBjb3Vyc2UgbW9kdWxlc1xuLSAqKkNoYXB0ZXJzKio6IFRlbXBsYXRlcyBmb3IgY2hhcHRlciBub3Rlc1xuLSAqKkFzc2lnbm1lbnRzKio6IFRlbXBsYXRlcyBmb3IgYXNzaWdubWVudHNcbi0gKipEYWlseSoqOiBUZW1wbGF0ZXMgZm9yIGRhaWx5IG5vdGVzXG4tICoqVXRpbGl0aWVzKio6IEhlbHBlciB0ZW1wbGF0ZXNcblxuIyMgVXNhZ2VcblxuVGhlc2UgdGVtcGxhdGVzIGFyZSBkZXNpZ25lZCB0byB3b3JrIHdpdGggdGhlIFR1Y2tlcnMgVG9vbHMgcGx1Z2luLiBUbyB1c2UgdGhlbTpcblxuMS4gSW5zdGFsbCB0aGUgVHVja2VycyBUb29scyBwbHVnaW5cbjIuIENvbmZpZ3VyZSB5b3VyIHNldHRpbmdzIGluIHRoZSBwbHVnaW4gc2V0dGluZ3MgdGFiXG4zLiBVc2UgdGhlIFwiSW5zZXJ0IFRlbXBsYXRlXCIgY29tbWFuZCB0byBhcHBseSB0aGVzZSB0ZW1wbGF0ZXMgdG8gbmV3IG5vdGVzXG5cbiMjIEN1c3RvbWl6YXRpb25cblxuRmVlbCBmcmVlIHRvIGN1c3RvbWl6ZSB0aGVzZSB0ZW1wbGF0ZXMgdG8gc3VpdCB5b3VyIG5lZWRzLiBUaGUgcGx1Z2luIHdpbGwgbm90IG92ZXJ3cml0ZSB5b3VyIGNoYW5nZXMgd2hlbiB1cGRhdGluZyB0ZW1wbGF0ZXMuYDtcblxuICAgIGF3YWl0IHRoaXMud3JpdGVUZW1wbGF0ZUZpbGUoYCR7YmFzZVBhdGh9L1JFQURNRS5tZGAsIHJlYWRtZUNvbnRlbnQpO1xuICB9XG59Il0sCiAgIm1hcHBpbmdzIjogIjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBQUFBLG1CQUF1Qjs7O0FDQXZCLHNCQUErQzs7O0FDc0N4QyxTQUFTLGFBQWEsWUFBNkI7QUFDeEQsUUFBTSxRQUFRO0FBQ2QsTUFBSSxDQUFDLFdBQVcsTUFBTSxLQUFLO0FBQUcsV0FBTztBQUVyQyxRQUFNLE9BQU8sSUFBSSxLQUFLLFVBQVU7QUFDaEMsUUFBTSxZQUFZLEtBQUssUUFBUTtBQUUvQixNQUFJLE9BQU8sY0FBYyxZQUFZLE1BQU0sU0FBUztBQUFHLFdBQU87QUFFOUQsU0FBTyxlQUFlLEtBQUssWUFBWSxFQUFFLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFDdkQ7OztBRGxDTyxJQUFNLG1CQUF5QztBQUFBLEVBQ3BELGVBQWU7QUFBQSxFQUNmLG1CQUFtQixJQUFJLEtBQUssRUFBRSxZQUFZLEVBQUUsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLEVBQ3hELGlCQUFpQixJQUFJLEtBQUssSUFBSSxLQUFLLEVBQUUsU0FBUyxJQUFJLEtBQUssRUFBRSxTQUFTLElBQUksQ0FBQyxDQUFDLEVBQUUsWUFBWSxFQUFFLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFBQSxFQUNwRyxZQUFZO0FBQUEsRUFDWixvQkFBb0I7QUFBQSxFQUNwQixnQkFBZ0I7QUFBQSxFQUNoQixxQkFBcUI7QUFDdkI7QUFFTyxJQUFNLHlCQUFOLGNBQXFDLGlDQUFpQjtBQUFBLEVBRzNELFlBQVksS0FBVSxRQUE0QjtBQUNoRCxVQUFNLEtBQUssTUFBTTtBQUNqQixTQUFLLFNBQVM7QUFBQSxFQUNoQjtBQUFBLEVBRUEsVUFBZ0I7QUFDZCxVQUFNLEVBQUUsWUFBWSxJQUFJO0FBRXhCLGdCQUFZLE1BQU07QUFFbEIsZ0JBQVksU0FBUyxNQUFNLEVBQUUsTUFBTSx5QkFBeUIsQ0FBQztBQUU3RCxRQUFJLHdCQUFRLFdBQVcsRUFDcEIsUUFBUSxnQkFBZ0IsRUFDeEIsUUFBUSxnREFBZ0QsRUFDeEQsUUFBUSxVQUFRLEtBQ2QsZUFBZSxHQUFHLEVBQ2xCLFNBQVMsS0FBSyxPQUFPLFNBQVMsYUFBYSxFQUMzQyxTQUFTLENBQU8sVUFBVTtBQUN6QixXQUFLLE9BQU8sU0FBUyxnQkFBZ0I7QUFDckMsWUFBTSxLQUFLLE9BQU8sYUFBYTtBQUFBLElBQ2pDLEVBQUMsQ0FBQztBQUVOLFVBQU0sbUJBQW1CLElBQUksd0JBQVEsV0FBVyxFQUM3QyxRQUFRLHFCQUFxQixFQUM3QixRQUFRLHFDQUFxQyxFQUM3QyxRQUFRLFVBQVEsS0FDZCxlQUFlLFlBQVksRUFDM0IsU0FBUyxLQUFLLE9BQU8sU0FBUyxpQkFBaUIsRUFDL0MsU0FBUyxDQUFPLFVBQVU7QUFDekIsVUFBSSxTQUFTLENBQUMsYUFBYSxLQUFLLEdBQUc7QUFDakMseUJBQWlCLFFBQVEsMkRBQTJEO0FBQUEsTUFDdEYsT0FBTztBQUNMLHlCQUFpQixRQUFRLHFDQUFxQztBQUFBLE1BQ2hFO0FBQ0EsV0FBSyxPQUFPLFNBQVMsb0JBQW9CO0FBQ3pDLFlBQU0sS0FBSyxPQUFPLGFBQWE7QUFBQSxJQUNqQyxFQUFDLENBQUM7QUFFTixVQUFNLGlCQUFpQixJQUFJLHdCQUFRLFdBQVcsRUFDM0MsUUFBUSxtQkFBbUIsRUFDM0IsUUFBUSxtQ0FBbUMsRUFDM0MsUUFBUSxVQUFRLEtBQ2QsZUFBZSxZQUFZLEVBQzNCLFNBQVMsS0FBSyxPQUFPLFNBQVMsZUFBZSxFQUM3QyxTQUFTLENBQU8sVUFBVTtBQUN6QixVQUFJLFNBQVMsQ0FBQyxhQUFhLEtBQUssR0FBRztBQUNqQyx1QkFBZSxRQUFRLHlEQUF5RDtBQUFBLE1BQ2xGLE9BQU87QUFDTCx1QkFBZSxRQUFRLG1DQUFtQztBQUFBLE1BQzVEO0FBQ0EsV0FBSyxPQUFPLFNBQVMsa0JBQWtCO0FBQ3ZDLFlBQU0sS0FBSyxPQUFPLGFBQWE7QUFBQSxJQUNqQyxFQUFDLENBQUM7QUFFTixRQUFJLHdCQUFRLFdBQVcsRUFDcEIsUUFBUSxhQUFhLEVBQ3JCLFFBQVEsMEJBQTBCLEVBQ2xDLFFBQVEsVUFBUSxLQUNkLGVBQWUsWUFBWSxFQUMzQixTQUFTLEtBQUssT0FBTyxTQUFTLFVBQVUsRUFDeEMsU0FBUyxDQUFPLFVBQVU7QUFDekIsV0FBSyxPQUFPLFNBQVMsYUFBYTtBQUNsQyxZQUFNLEtBQUssT0FBTyxhQUFhO0FBQUEsSUFDakMsRUFBQyxDQUFDO0FBRU4sUUFBSSx3QkFBUSxXQUFXLEVBQ3BCLFFBQVEscUJBQXFCLEVBQzdCLFFBQVEsbUNBQW1DLEVBQzNDLFFBQVEsVUFBUSxLQUNkLGVBQWUsR0FBRyxFQUNsQixTQUFTLEtBQUssT0FBTyxTQUFTLGtCQUFrQixFQUNoRCxTQUFTLENBQU8sVUFBVTtBQUN6QixXQUFLLE9BQU8sU0FBUyxxQkFBcUI7QUFDMUMsWUFBTSxLQUFLLE9BQU8sYUFBYTtBQUFBLElBQ2pDLEVBQUMsQ0FBQztBQUVOLFFBQUksd0JBQVEsV0FBVyxFQUNwQixRQUFRLGlCQUFpQixFQUN6QixRQUFRLDZFQUE2RSxFQUNyRixRQUFRLFVBQVEsS0FDZCxlQUFlLGVBQWUsRUFDOUIsU0FBUyxLQUFLLE9BQU8sU0FBUyxjQUFjLEVBQzVDLFNBQVMsQ0FBTyxVQUFVO0FBQ3pCLFdBQUssT0FBTyxTQUFTLGlCQUFpQjtBQUN0QyxZQUFNLEtBQUssT0FBTyxhQUFhO0FBQUEsSUFDakMsRUFBQyxDQUFDO0FBRU4sUUFBSSx3QkFBUSxXQUFXLEVBQ3BCLFFBQVEsdUJBQXVCLEVBQy9CLFFBQVEsaUZBQWlGLEVBQ3pGLFVBQVUsWUFBVSxPQUNsQixTQUFTLEtBQUssT0FBTyxTQUFTLG1CQUFtQixFQUNqRCxTQUFTLENBQU8sVUFBVTtBQUN6QixXQUFLLE9BQU8sU0FBUyxzQkFBc0I7QUFDM0MsWUFBTSxLQUFLLE9BQU8sYUFBYTtBQUFBLElBQ2pDLEVBQUMsQ0FBQztBQUFBLEVBQ1I7QUFDRjs7O0FFbkhPLElBQU0sa0JBQU4sTUFBc0I7QUFBQSxFQUszQixZQUFZLEtBQVUsVUFBZ0M7QUFDcEQsU0FBSyxNQUFNO0FBQ1gsU0FBSyxXQUFXO0FBQ2hCLFNBQUssV0FBVztBQUFBLE1BQ2QsU0FBUztBQUFBLE1BQ1QsV0FBVztBQUFBLFFBQ1QscUNBQXFDO0FBQUEsUUFDckMsMkJBQTJCO0FBQUEsUUFDM0IsNEJBQTRCO0FBQUEsUUFDNUIsOEJBQThCO0FBQUEsUUFDOUIsb0NBQW9DO0FBQUEsUUFDcEMsdUJBQXVCO0FBQUEsUUFDdkIsaUNBQWlDO0FBQUEsUUFDakMsK0JBQStCO0FBQUEsTUFDakM7QUFBQSxNQUNBLGdCQUFnQjtBQUFBLE1BQ2hCLGVBQWU7QUFBQSxJQUNqQjtBQUFBLEVBQ0Y7QUFBQSxFQUVNLG1CQUFtQjtBQUFBO0FBRXZCLFlBQU0sa0JBQW1CLEtBQUssSUFBWSxRQUFRLFFBQVEsb0JBQW9CO0FBQzlFLFVBQUksQ0FBQyxpQkFBaUI7QUFDcEIsZ0JBQVEsTUFBTSw0QkFBNEI7QUFDMUM7QUFBQSxNQUNGO0FBRUEsWUFBTSxvQkFBb0IsZ0JBQWdCO0FBQzFDLFlBQU0scUJBQXFCLGtCQUFrQixpQkFBaUI7QUFFOUQsVUFBSSxDQUFDLG9CQUFvQjtBQUN2QixnQkFBUSxNQUFNLHNEQUFzRDtBQUNwRTtBQUFBLE1BQ0Y7QUFFQSxZQUFNLG1CQUFtQixHQUFHLHNCQUFzQixLQUFLLFNBQVM7QUFHaEUsVUFBSTtBQUNGLGNBQU0sS0FBSyxJQUFJLE1BQU0sYUFBYSxnQkFBZ0I7QUFBQSxNQUNwRCxTQUFTLEdBQVA7QUFBQSxNQUVGO0FBR0EsWUFBTSxVQUFVLENBQUMsV0FBVyxXQUFXLFlBQVksZUFBZSxTQUFTLFdBQVc7QUFDdEYsaUJBQVcsVUFBVSxTQUFTO0FBQzVCLFlBQUk7QUFDRixnQkFBTSxLQUFLLElBQUksTUFBTSxhQUFhLEdBQUcsb0JBQW9CLFFBQVE7QUFBQSxRQUNuRSxTQUFTLEdBQVA7QUFBQSxRQUVGO0FBQUEsTUFDRjtBQUdBLFlBQU0sS0FBSyx1QkFBdUIsZ0JBQWdCO0FBQ2xELFlBQU0sS0FBSyx1QkFBdUIsZ0JBQWdCO0FBQ2xELFlBQU0sS0FBSyx3QkFBd0IsZ0JBQWdCO0FBQ25ELFlBQU0sS0FBSywyQkFBMkIsZ0JBQWdCO0FBQ3RELFlBQU0sS0FBSyxzQkFBc0IsZ0JBQWdCO0FBQ2pELFlBQU0sS0FBSyx3QkFBd0IsZ0JBQWdCO0FBR25ELFlBQU0sS0FBSyxhQUFhLGdCQUFnQjtBQUd4QyxZQUFNLEtBQUssdUJBQXVCLGdCQUFnQjtBQUVsRCxjQUFRLElBQUksZ0RBQWdEO0FBQUEsSUFDOUQ7QUFBQTtBQUFBLEVBRU0sdUJBQXVCLFVBQWtCO0FBQUE7QUFDN0MsWUFBTSxlQUFlLEdBQUc7QUFDeEIsWUFBTSxrQkFBa0IsS0FBSyxVQUFVLEtBQUssVUFBVSxNQUFNLENBQUM7QUFFN0QsVUFBSTtBQUVGLGNBQU0sbUJBQW1CLEtBQUssSUFBSSxNQUFNLHNCQUFzQixZQUFZO0FBQzFFLFlBQUksa0JBQWtCO0FBR3BCO0FBQUEsUUFDRjtBQUdBLGNBQU0sS0FBSyxJQUFJLE1BQU0sT0FBTyxjQUFjLGVBQWU7QUFBQSxNQUMzRCxTQUFTLEdBQVA7QUFDQSxnQkFBUSxNQUFNLG9DQUFvQyxpQkFBaUIsQ0FBQztBQUFBLE1BQ3RFO0FBQUEsSUFDRjtBQUFBO0FBQUEsRUFFTSwwQkFBNEM7QUFBQTtBQUdoRCxjQUFRLElBQUksK0JBQStCO0FBQzNDLGFBQU87QUFBQSxJQUNUO0FBQUE7QUFBQSxFQUVNLGtCQUFrQjtBQUFBO0FBR3RCLGNBQVEsSUFBSSxvQkFBb0I7QUFBQSxJQU9sQztBQUFBO0FBQUEsRUFFTSx1QkFBdUIsVUFBa0I7QUFBQTtBQUM3QyxZQUFNLGFBQWEsR0FBRztBQUd0QixZQUFNLHlCQUF5QixLQUFLLCtCQUErQjtBQUNuRSxZQUFNLEtBQUssa0JBQWtCLEdBQUcsd0NBQXdDLHNCQUFzQjtBQUc5RixZQUFNLHNCQUFzQixLQUFLLDRCQUE0QjtBQUM3RCxZQUFNLEtBQUssa0JBQWtCLEdBQUcsOEJBQThCLG1CQUFtQjtBQUFBLElBQ25GO0FBQUE7QUFBQSxFQUVNLHVCQUF1QixVQUFrQjtBQUFBO0FBQzdDLFlBQU0sYUFBYSxHQUFHO0FBR3RCLFlBQU0saUJBQWlCLEtBQUssdUJBQXVCO0FBQ25ELFlBQU0sS0FBSyxrQkFBa0IsR0FBRywrQkFBK0IsY0FBYztBQUFBLElBQy9FO0FBQUE7QUFBQSxFQUVNLHdCQUF3QixVQUFrQjtBQUFBO0FBQzlDLFlBQU0sY0FBYyxHQUFHO0FBR3ZCLFlBQU0sa0JBQWtCLEtBQUssd0JBQXdCO0FBQ3JELFlBQU0sS0FBSyxrQkFBa0IsR0FBRyxpQ0FBaUMsZUFBZTtBQUFBLElBQ2xGO0FBQUE7QUFBQSxFQUVNLDJCQUEyQixVQUFrQjtBQUFBO0FBQ2pELFlBQU0saUJBQWlCLEdBQUc7QUFHMUIsWUFBTSxxQkFBcUIsS0FBSywyQkFBMkI7QUFDM0QsWUFBTSxLQUFLLGtCQUFrQixHQUFHLHVDQUF1QyxrQkFBa0I7QUFBQSxJQUMzRjtBQUFBO0FBQUEsRUFFTSxzQkFBc0IsVUFBa0I7QUFBQTtBQUM1QyxZQUFNLFlBQVksR0FBRztBQUdyQixZQUFNLG9CQUFvQixLQUFLLDBCQUEwQjtBQUN6RCxZQUFNLEtBQUssa0JBQWtCLEdBQUcsMkJBQTJCLGlCQUFpQjtBQUFBLElBQzlFO0FBQUE7QUFBQSxFQUVNLHdCQUF3QixVQUFrQjtBQUFBO0FBQzlDLFlBQU0sY0FBYyxHQUFHO0FBR3ZCLFlBQU0sZ0JBQWdCLEtBQUssMkJBQTJCO0FBQ3RELFlBQU0sS0FBSyxrQkFBa0IsR0FBRyxtQ0FBbUMsYUFBYTtBQUdoRixZQUFNLGtCQUFrQixLQUFLLHdCQUF3QjtBQUNyRCxZQUFNLEtBQUssa0JBQWtCLEdBQUcsaUNBQWlDLGVBQWU7QUFBQSxJQUNsRjtBQUFBO0FBQUEsRUFFTSxrQkFBa0IsTUFBYyxTQUFpQjtBQUFBO0FBQ3JELFVBQUk7QUFFRixjQUFNLGVBQWUsS0FBSyxJQUFJLE1BQU0sc0JBQXNCLElBQUk7QUFDOUQsWUFBSSxjQUFjO0FBR2hCO0FBQUEsUUFDRjtBQUdBLGNBQU0sS0FBSyxJQUFJLE1BQU0sT0FBTyxNQUFNLE9BQU87QUFBQSxNQUMzQyxTQUFTLEdBQVA7QUFDQSxnQkFBUSxNQUFNLGdDQUFnQyxTQUFTLENBQUM7QUFBQSxNQUMxRDtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRUEsaUNBQXlDO0FBQ3ZDLFdBQU87QUFBQSxFQUNULEtBQUssU0FBUyxzQkFBc0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNNUIsS0FBSyxTQUFTO0FBQUEsdUJBQ0QsS0FBSyxTQUFTLHVCQUF1QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BT3RELEtBQUssU0FBUztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWtCTixLQUFLLFNBQVM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQXFDMUI7QUFBQSxFQUVBLDhCQUFzQztBQUNwQyxXQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFtQlQ7QUFBQSxFQUVBLHlCQUFpQztBQUMvQixXQUFPO0FBQUEsRUFDVCxLQUFLLFNBQVMsc0JBQXNCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQ0FLRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBcUNuQztBQUFBLEVBRUEsMEJBQWtDO0FBQ2hDLFdBQU87QUFBQSxFQUNULEtBQUssU0FBUyxzQkFBc0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQ0FJRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQTJCbEM7QUFBQSxFQUVBLDZCQUFxQztBQUNuQyxXQUFPO0FBQUEsRUFDVCxLQUFLLFNBQVMsc0JBQXNCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQ0FLRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUEwQm5DO0FBQUEsRUFFQSw0QkFBb0M7QUFDbEMsV0FBTztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFtQ1Q7QUFBQSxFQUVBLDZCQUFxQztBQUNuQyxXQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVFUO0FBQUEsRUFFQSwwQkFBa0M7QUFDaEMsV0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUVNLGFBQWEsVUFBa0I7QUFBQTtBQUNuQyxZQUFNLGdCQUFnQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUF5QnRCLFlBQU0sS0FBSyxrQkFBa0IsR0FBRyxzQkFBc0IsYUFBYTtBQUFBLElBQ3JFO0FBQUE7QUFDRjs7O0FIdmVBLElBQXFCLHFCQUFyQixjQUFnRCx3QkFBTztBQUFBLEVBSS9DLFNBQVM7QUFBQTtBQUNiLGNBQVEsSUFBSSw4QkFBOEI7QUFHMUMsWUFBTSxLQUFLLGFBQWE7QUFHeEIsV0FBSyxrQkFBa0IsSUFBSSxnQkFBZ0IsS0FBSyxLQUFLLEtBQUssUUFBUTtBQUdsRSxXQUFLLGNBQWMsSUFBSSx1QkFBdUIsS0FBSyxLQUFLLElBQUksQ0FBQztBQUc3RCxXQUFLLFdBQVc7QUFBQSxRQUNkLElBQUk7QUFBQSxRQUNKLE1BQU07QUFBQSxRQUNOLFVBQVUsTUFBTTtBQUNkLGVBQUssZ0JBQWdCLGlCQUFpQjtBQUFBLFFBQ3hDO0FBQUEsTUFDRixDQUFDO0FBRUQsV0FBSyxXQUFXO0FBQUEsUUFDZCxJQUFJO0FBQUEsUUFDSixNQUFNO0FBQUEsUUFDTixVQUFVLE1BQU07QUFDZCxlQUFLLGdCQUFnQixnQkFBZ0I7QUFBQSxRQUN2QztBQUFBLE1BQ0YsQ0FBQztBQUdELFdBQUssaUJBQWlCLEVBQUUsUUFBUSxlQUFlO0FBQUEsSUFDakQ7QUFBQTtBQUFBLEVBRUEsV0FBVztBQUNULFlBQVEsSUFBSSxnQ0FBZ0M7QUFBQSxFQUM5QztBQUFBLEVBRU0sZUFBZTtBQUFBO0FBQ25CLFdBQUssV0FBVyxPQUFPLE9BQU8sQ0FBQyxHQUFHLGtCQUFrQixNQUFNLEtBQUssU0FBUyxDQUFDO0FBQUEsSUFDM0U7QUFBQTtBQUFBLEVBRU0sZUFBZTtBQUFBO0FBQ25CLFlBQU0sS0FBSyxTQUFTLEtBQUssUUFBUTtBQUFBLElBQ25DO0FBQUE7QUFDRjsiLAogICJuYW1lcyI6IFsiaW1wb3J0X29ic2lkaWFuIl0KfQo=
