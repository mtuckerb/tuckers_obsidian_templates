var __defProp = Object.defineProperty;
var __defProps = Object.defineProperties;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getOwnPropSymbols = Object.getOwnPropertySymbols;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __propIsEnum = Object.prototype.propertyIsEnumerable;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __spreadValues = (a, b) => {
  for (var prop in b || (b = {}))
    if (__hasOwnProp.call(b, prop))
      __defNormalProp(a, prop, b[prop]);
  if (__getOwnPropSymbols)
    for (var prop of __getOwnPropSymbols(b)) {
      if (__propIsEnum.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    }
  return a;
};
var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __async = (__this, __arguments, generator) => {
  return new Promise((resolve, reject) => {
    var fulfilled = (value) => {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    };
    var rejected = (value) => {
      try {
        step(generator.throw(value));
      } catch (e) {
        reject(e);
      }
    };
    var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
    step((generator = generator.apply(__this, __arguments)).next());
  });
};

// main.ts
var main_exports = {};
__export(main_exports, {
  default: () => TuckersToolsPlugin
});
module.exports = __toCommonJS(main_exports);
var import_obsidian9 = require("obsidian");

// settings.ts
var import_obsidian = require("obsidian");

// utils.ts
function slugify(text) {
  return text.toLowerCase().trim().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9\s-]/g, "").replace(/[\s-]+/g, "-").replace(/^-+|-+$/g, "");
}
function validateDate(dateString) {
  const regex = /^\d{4}-\d{2}-\d{2}$/;
  if (!dateString.match(regex))
    return false;
  const date = new Date(dateString);
  const timestamp = date.getTime();
  if (typeof timestamp !== "number" || isNaN(timestamp))
    return false;
  return dateString === date.toISOString().split("T")[0];
}

// settings.ts
var DEFAULT_SETTINGS = {
  baseDirectory: "/",
  semesterStartDate: new Date().toISOString().split("T")[0],
  semesterEndDate: new Date(new Date().setMonth(new Date().getMonth() + 4)).toISOString().split("T")[0],
  schoolName: "University",
  schoolAbbreviation: "U",
  templateFolder: "Tuckers Tools",
  useEnhancedMetadata: false,
  dataviewJsPath: "/Supporting/dataview-functions"
};
var TuckersToolsSettingTab = class extends import_obsidian.PluginSettingTab {
  constructor(app, plugin) {
    super(app, plugin);
    this.plugin = plugin;
  }
  display() {
    const { containerEl } = this;
    containerEl.empty();
    containerEl.createEl("h2", { text: "Tuckers Tools Settings" });
    new import_obsidian.Setting(containerEl).setName("Base Directory").setDesc("Root directory for course content organization").addText((text) => text.setPlaceholder("/").setValue(this.plugin.settings.baseDirectory).onChange((value) => __async(this, null, function* () {
      this.plugin.settings.baseDirectory = value;
      yield this.plugin.saveSettings();
    })));
    const startDateSetting = new import_obsidian.Setting(containerEl).setName("Semester Start Date").setDesc("Start date for the current semester").addText((text) => text.setPlaceholder("YYYY-MM-DD").setValue(this.plugin.settings.semesterStartDate).onChange((value) => __async(this, null, function* () {
      if (value && !validateDate(value)) {
        startDateSetting.setDesc("Start date for the current semester (Invalid date format)");
      } else {
        startDateSetting.setDesc("Start date for the current semester");
      }
      this.plugin.settings.semesterStartDate = value;
      yield this.plugin.saveSettings();
    })));
    const endDateSetting = new import_obsidian.Setting(containerEl).setName("Semester End Date").setDesc("End date for the current semester").addText((text) => text.setPlaceholder("YYYY-MM-DD").setValue(this.plugin.settings.semesterEndDate).onChange((value) => __async(this, null, function* () {
      if (value && !validateDate(value)) {
        endDateSetting.setDesc("End date for the current semester (Invalid date format)");
      } else {
        endDateSetting.setDesc("End date for the current semester");
      }
      this.plugin.settings.semesterEndDate = value;
      yield this.plugin.saveSettings();
    })));
    new import_obsidian.Setting(containerEl).setName("School Name").setDesc("Name of your institution").addText((text) => text.setPlaceholder("University").setValue(this.plugin.settings.schoolName).onChange((value) => __async(this, null, function* () {
      this.plugin.settings.schoolName = value;
      yield this.plugin.saveSettings();
    })));
    new import_obsidian.Setting(containerEl).setName("School Abbreviation").setDesc("Abbreviation for your institution").addText((text) => text.setPlaceholder("U").setValue(this.plugin.settings.schoolAbbreviation).onChange((value) => __async(this, null, function* () {
      this.plugin.settings.schoolAbbreviation = value;
      yield this.plugin.saveSettings();
    })));
    new import_obsidian.Setting(containerEl).setName("Template Folder").setDesc("Subfolder within your Templater template folder for Tuckers Tools templates").addText((text) => text.setPlaceholder("Tuckers Tools").setValue(this.plugin.settings.templateFolder).onChange((value) => __async(this, null, function* () {
      this.plugin.settings.templateFolder = value;
      yield this.plugin.saveSettings();
    })));
    new import_obsidian.Setting(containerEl).setName("Use Enhanced Metadata").setDesc("Enable enhanced metadata fields for new notes (existing notes remain unchanged)").addToggle((toggle) => toggle.setValue(this.plugin.settings.useEnhancedMetadata).onChange((value) => __async(this, null, function* () {
      this.plugin.settings.useEnhancedMetadata = value;
      yield this.plugin.saveSettings();
    })));
    new import_obsidian.Setting(containerEl).setName("Dataview Functions Path").setDesc("Path to the dataview functions file (without extension)").addText((text) => text.setPlaceholder("/Supporting/dataview-functions").setValue(this.plugin.settings.dataviewJsPath).onChange((value) => __async(this, null, function* () {
      this.plugin.settings.dataviewJsPath = value;
      yield this.plugin.saveSettings();
    })));
  }
};

// templateManager.ts
var import_obsidian2 = require("obsidian");
var TemplateManager = class {
  constructor(app, settings) {
    this.app = app;
    this.settings = settings;
    this.manifest = {
      version: "1.0.0",
      templates: {
        "Courses/Create Course Homepage.md": "1.0.0",
        "Courses/Course Index.md": "1.0.0",
        "Modules/Create Module.md": "1.0.0",
        "Chapters/Create Chapter.md": "1.0.0",
        "Assignments/Create Assignment.md": "1.0.0",
        "Daily/Daily Note.md": "1.0.0",
        "Utilities/Vocabulary Entry.md": "1.0.0",
        "Utilities/Due Date Entry.md": "1.0.0"
      },
      plugin_version: "1.0.0",
      release_notes: "Initial release of Tuckers Tools templates"
    };
  }
  installTemplates() {
    return __async(this, null, function* () {
      try {
        const templaterPlugin = this.getTemplaterPlugin();
        if (!templaterPlugin) {
          new import_obsidian2.Notice(
            "Templater plugin not found. Please install and enable the Templater plugin first."
          );
          console.error(
            "Templater plugin not found. Please install and enable the Templater plugin first."
          );
          return;
        }
        const templateFolderPath = this.getTemplateFolderPath(templaterPlugin);
        if (!templateFolderPath) {
          new import_obsidian2.Notice(
            "Template folder not configured in Templater settings. Please configure it in Templater settings first."
          );
          console.error(
            "Template folder not configured in Templater settings. Please configure it in Templater settings first."
          );
          return;
        }
        const fullTemplatePath = `${templateFolderPath}/${this.settings.templateFolder}`;
        try {
          yield this.app.vault.createFolder(fullTemplatePath);
          console.log(`Created template folder: ${fullTemplatePath}`);
        } catch (e) {
          console.log(
            `Template folder already exists or created: ${fullTemplatePath}`
          );
        }
        const subdirs = [
          "Courses",
          "Modules",
          "Chapters",
          "Assignments",
          "Daily",
          "Utilities"
        ];
        for (const subdir of subdirs) {
          try {
            const subPath = `${fullTemplatePath}/${subdir}`;
            yield this.app.vault.createFolder(subPath);
            console.log(`Created subdirectory: ${subPath}`);
          } catch (e) {
            console.log(
              `Subdirectory already exists: ${fullTemplatePath}/${subdir}`
            );
          }
        }
        yield this.installCourseTemplates(fullTemplatePath);
        yield this.installModuleTemplates(fullTemplatePath);
        yield this.installChapterTemplates(fullTemplatePath);
        yield this.installAssignmentTemplates(fullTemplatePath);
        yield this.installDailyTemplates(fullTemplatePath);
        yield this.installUtilityTemplates(fullTemplatePath);
        yield this.createREADME(fullTemplatePath);
        yield this.createTemplateManifest(fullTemplatePath);
        new import_obsidian2.Notice("Tuckers Tools templates installed successfully!");
        console.log("Tuckers Tools templates installed successfully");
      } catch (error) {
        console.error("Error installing templates:", error);
        new import_obsidian2.Notice("Error installing templates. Check console for details.");
      }
    });
  }
  getTemplaterPlugin() {
    const possiblePaths = [
      this.app.plugins.plugins["templater-obsidian"],
      this.app.plugins.plugins["templater"],
      this.app.plugins.getPlugin("templater-obsidian"),
      this.app.plugins.getPlugin("templater")
    ];
    for (const path of possiblePaths) {
      if (path) {
        return path;
      }
    }
    return null;
  }
  getTemplateFolderPath(templaterPlugin) {
    const settings = templaterPlugin.settings;
    if (!settings) {
      console.error("Templater plugin has no settings");
      return null;
    }
    const possiblePaths = [
      settings.templates_folder,
      // Changed from template_folder to match actual setting
      settings.template_folder,
      settings.templateFolder,
      settings.templateFolderPath,
      settings.folder
    ];
    for (const path of possiblePaths) {
      if (path && typeof path === "string") {
        return path;
      }
    }
    console.error(
      "Template folder not found in Templater settings. Available settings:",
      Object.keys(settings)
    );
    return null;
  }
  createTemplateManifest(basePath) {
    return __async(this, null, function* () {
      const manifestPath = `${basePath}/template-manifest.json`;
      const manifestContent = JSON.stringify(this.manifest, null, 2);
      try {
        const existingManifest = this.app.vault.getAbstractFileByPath(manifestPath);
        if (existingManifest) {
          const file = existingManifest;
          yield this.app.vault.modify(file, manifestContent);
          console.log(`Updated template manifest: ${manifestPath}`);
          return;
        }
        yield this.app.vault.create(manifestPath, manifestContent);
        console.log(`Created template manifest: ${manifestPath}`);
      } catch (e) {
        new import_obsidian2.Notice(`Error creating template manifest ${manifestPath}`);
        console.error(`Error creating template manifest ${manifestPath}:`, e);
      }
    });
  }
  checkForTemplateUpdates() {
    return __async(this, null, function* () {
      console.log("Checking for template updates");
      return false;
    });
  }
  updateTemplates() {
    return __async(this, null, function* () {
      try {
        console.log("Updating templates");
        const templaterPlugin = this.getTemplaterPlugin();
        if (!templaterPlugin) {
          new import_obsidian2.Notice(
            "Templater plugin not found. Please install and enable the Templater plugin first."
          );
          console.error(
            "Templater plugin not found. Please install and enable the Templater plugin first."
          );
          return;
        }
        const templateFolderPath = this.getTemplateFolderPath(templaterPlugin);
        if (!templateFolderPath) {
          new import_obsidian2.Notice(
            "Template folder not configured in Templater settings. Please configure it in Templater settings first."
          );
          console.error(
            "Template folder not configured in Templater settings. Please configure it in Templater settings first."
          );
          return;
        }
        const fullTemplatePath = `${templateFolderPath}/${this.settings.templateFolder}`;
        yield this.installCourseTemplates(fullTemplatePath);
        yield this.installModuleTemplates(fullTemplatePath);
        yield this.installChapterTemplates(fullTemplatePath);
        yield this.installAssignmentTemplates(fullTemplatePath);
        yield this.installDailyTemplates(fullTemplatePath);
        yield this.installUtilityTemplates(fullTemplatePath);
        yield this.createREADME(fullTemplatePath);
        yield this.createTemplateManifest(fullTemplatePath);
        new import_obsidian2.Notice("Tuckers Tools templates updated successfully!");
        console.log("Tuckers Tools templates updated successfully");
      } catch (error) {
        console.error("Error updating templates:", error);
        new import_obsidian2.Notice("Error updating templates. Check console for details.");
      }
    });
  }
  installCourseTemplates(basePath) {
    return __async(this, null, function* () {
      const coursePath = `${basePath}/Courses`;
      const courseHomepageTemplate = this.generateCourseHomepageTemplate();
      yield this.writeTemplateFile(
        `${coursePath}/Create Course Homepage.md`,
        courseHomepageTemplate
      );
      const courseIndexTemplate = this.generateCourseIndexTemplate();
      yield this.writeTemplateFile(
        `${coursePath}/Course Index.md`,
        courseIndexTemplate
      );
    });
  }
  installModuleTemplates(basePath) {
    return __async(this, null, function* () {
      const modulePath = `${basePath}/Modules`;
      const moduleTemplate = this.generateModuleTemplate();
      yield this.writeTemplateFile(
        `${modulePath}/Create Module.md`,
        moduleTemplate
      );
    });
  }
  installChapterTemplates(basePath) {
    return __async(this, null, function* () {
      const chapterPath = `${basePath}/Chapters`;
      const chapterTemplate = this.generateChapterTemplate();
      yield this.writeTemplateFile(
        `${chapterPath}/Create Chapter.md`,
        chapterTemplate
      );
    });
  }
  installAssignmentTemplates(basePath) {
    return __async(this, null, function* () {
      const assignmentPath = `${basePath}/Assignments`;
      const assignmentTemplate = this.generateAssignmentTemplate();
      yield this.writeTemplateFile(
        `${assignmentPath}/Create Assignment.md`,
        assignmentTemplate
      );
    });
  }
  installDailyTemplates(basePath) {
    return __async(this, null, function* () {
      const dailyPath = `${basePath}/Daily`;
      const dailyNoteTemplate = this.generateDailyNoteTemplate();
      yield this.writeTemplateFile(
        `${dailyPath}/Daily Note.md`,
        dailyNoteTemplate
      );
    });
  }
  installUtilityTemplates(basePath) {
    return __async(this, null, function* () {
      const utilityPath = `${basePath}/Utilities`;
      const vocabTemplate = this.generateVocabularyTemplate();
      yield this.writeTemplateFile(
        `${utilityPath}/Vocabulary Entry.md`,
        vocabTemplate
      );
      const dueDateTemplate = this.generateDueDateTemplate();
      yield this.writeTemplateFile(
        `${utilityPath}/Due Date Entry.md`,
        dueDateTemplate
      );
    });
  }
  writeTemplateFile(path, content) {
    return __async(this, null, function* () {
      try {
        const existingFile = this.app.vault.getAbstractFileByPath(path);
        if (existingFile) {
          console.log(`Updating existing template file: ${path}`);
          const file = existingFile;
          yield this.app.vault.modify(file, content);
          return;
        }
        yield this.app.vault.create(path, content);
        console.log(`Created template file: ${path}`);
      } catch (e) {
        new import_obsidian2.Notice(`Error creating template file ${path}`);
        console.error(`Error creating template file ${path}:`, e);
      }
    });
  }
  generateCourseHomepageTemplate() {
    const enhancedMetadata = this.settings.useEnhancedMetadata;
    if (enhancedMetadata) {
      let template = `<%*
// Tuckers Tools Course Creation
// For best experience, use the plugin command: Command Palette \u2192 'Create New Course'

let courseName = "New Course";
let courseSeason = "Fall"; 
let courseYear = new Date().getFullYear().toString();
let courseId = "COURSE_ID";

// Try to use system prompts, with graceful fallback
try {
  if (tp && tp.system && tp.system.prompt) {
    courseName = await tp.system.prompt("Course Name (e.g. SWO-250 - Course Title)") || courseName;
    courseId = courseName.split(' - ')[0] || courseName.replace(/[^a-zA-Z0-9]/g, "_");
    courseSeason = await tp.system.suggester(["Fall","Winter","Spring","Summer"],["Fall","Winter","Spring","Summer"], "Season") || courseSeason;
    courseYear = await tp.system.prompt("Year") || courseYear;
  } else {
    console.log("System prompts not available, use the plugin command instead");
  }
} catch (e) {
  console.error("Error with system prompts:", e.message);
  console.log("Use the plugin command: Command Palette \u2192 'Create New Course'");
}

// Move file to appropriate location
await tp.file.move(\`/\${courseYear}/\${courseSeason}/\${courseName}/\${courseName}\`);

// Create attachments folder
try {
  await app.vault.createFolder(\`/\${courseYear}/\${courseSeason}/\${courseName}/Attachments\`);
} catch (e) {
  // Folder might already exist
}
%>---
course_id: <% courseId %>
course_season: <% courseSeason %>
course_year: <% courseYear %>
created: <% tp.date.now("YYYY-MM-DD[T]HH:mm:ssZ") %>
tags: 
  - <% courseId %>
  - ${this.settings.schoolAbbreviation}/<% courseYear %>/<% courseSeason %>/<% courseId %>/
  - course_home
  - education
  - ${this.settings.schoolName.replace(/\s+/g, "_")}
banner:
cssclasses:
  - whiteboard-course
---


# <% courseName %>

## Course Information
**Course**: <% courseName %>
**Course ID**: <% courseId %>
**Term**: <% courseSeason %> <% courseYear %>
**School**: ${this.settings.schoolName}

## Instructor
**Name**: \`INPUT[text:instructor_name]\`
**Email**: \`INPUT[text:instructor_email]\`
**Office Hours**: \`INPUT[text:instructor_office_hours]\`
**Office Location**: \`INPUT[text:instructor_office_location]\`

## Course Description
\`INPUT[textArea:course_description]\`

## Learning Objectives
\`INPUT[textArea:learning_objectives]\`

## Required Texts
\`\`\`meta-bind-js-view
{texts} as texts
---
const availableTexts = app.vault.getFiles().filter(file => file.extension == 'pdf').map(f => f?.name)
const escapeRegex = /[,\`'()]/g;
options = availableTexts.map(t => \`option([[\${t.replace(escapeRegex,"$1")}]], \${t.replace(escapeRegex,"$1")})\` )
const str = \`\\\`INPUT[inlineListSuggester(\${options.join(", ")}):texts]\\\`\`
return engine.markdown.create(str)
\`\`\`

## Course Schedule
\`INPUT[textArea:course_schedule]\`

## Resources
\`INPUT[textArea:resources]\`

## Vocabulary
\`\`\`dataviewjs
const {processCourseVocabulary} = app.plugins.getPlugin("tuckers-tools")?.dataviewFunctions || require("${this.settings.dataviewJsPath || "/Supporting/dataview-functions"}");
processCourseVocabulary(dv, '<% courseId %>');
\`\`\`

## Due Dates
\`\`\`dataviewjs
const {processDueDates} = app.plugins.getPlugin("tuckers-tools")?.dataviewFunctions || require("${this.settings.dataviewJsPath || "/Supporting/dataview-functions"}");
processDueDates(dv,'#<% courseId %>');
\`\`\`

## Class Materials
\`INPUT[textArea:class_materials]\`

## Classmates
\`INPUT[textArea:classmates]\``;
      return template;
    } else {
      let template = `<%*
// Tuckers Tools Course Creation
// For best experience, use the plugin command: Command Palette \u2192 'Create New Course'

let courseName = "New Course";
let courseSeason = "Fall"; 
let courseYear = new Date().getFullYear().toString();
let courseId = "COURSE_ID";

// Try to use system prompts, with graceful fallback
try {
  if (tp && tp.system && tp.system.prompt) {
    courseName = await tp.system.prompt("Course Name (e.g. SWO-250 - Course Title)") || courseName;
    courseId = courseName.split(' - ')[0] || courseName.replace(/[^a-zA-Z0-9]/g, "_");
    courseSeason = await tp.system.suggester(["Fall","Winter","Spring","Summer"],["Fall","Winter","Spring","Summer"], "Season") || courseSeason;
    courseYear = await tp.system.prompt("Year") || courseYear;
  } else {
    console.log("System prompts not available, use the plugin command instead");
  }
} catch (e) {
  console.error("Error with system prompts:", e.message);
  console.log("Use the plugin command: Command Palette \u2192 'Create New Course'");
}

// Move file to appropriate location
await tp.file.move(\`/\${courseYear}/\${courseSeason}/\${courseName}/\${courseName}\`);

// Create attachments folder
try {
  await app.vault.createFolder(\`/\${courseYear}/\${courseSeason}/\${courseName}/Attachments\`);
} catch (e) {
  // Folder might already exist
}
%>---
course_id: <% courseId %>
course_name: <% courseName %>
course_season: <% courseSeason %>
course_year: <% courseYear %>
created: <% tp.date.now("YYYY-MM-DD[T]HH:mm:ssZ") %>
tags:
  - <% courseId %>
  - course_home
  - education
---

# <% courseName %>

## Course Information
**Course ID**: <% courseId %>
**Term**: <% courseSeason %> <% courseYear %>
**School**: ${this.settings.schoolName}

## Instructor
**Name**: \`INPUT[text:instructor_name]\`
**Email**: \`INPUT[text:instructor_email]\`
**Office Hours**: \`INPUT[text:instructor_office_hours]\`
**Office Location**: \`INPUT[text:instructor_office_location]\`

## Course Description
\`INPUT[textArea:course_description]\`

## Learning Objectives
\`INPUT[textArea:learning_objectives]\`

## Required Texts
\`\`\`meta-bind-js-view
{texts} as texts
---
const availableTexts = app.vault.getFiles().filter(file => file.extension == 'pdf').map(f => f?.name)
const escapeRegex = /[,\`'()]/g;
options = availableTexts.map(t => \`option([[\${t.replace(escapeRegex,"$1")}]], \${t.replace(escapeRegex,"$1")})\` )
const str = '\\\`INPUT[inlineListSuggester(\${options.join(", ")}):texts]\\\`\\'
return engine.markdown.create(str)
\`\`\`

## Schedule
\`INPUT[textArea:course_schedule]\`

## Assignments
\`INPUT[textArea:assignments]\`

## Resources
\`INPUT[textArea:resources]\`

## Vocabulary
\`\`\`dataviewjs
const {processCourseVocabulary} = app.plugins.getPlugin("tuckers-tools")?.dataviewFunctions || require("${this.settings.dataviewJsPath || "/Supporting/dataview-functions"}");
processCourseVocabulary(dv, '<% courseId %>');
\`\`\`

## Due Dates
\`\`\`dataviewjs
const {processDueDates} = app.plugins.getPlugin("tuckers-tools")?.dataviewFunctions || require("${this.settings.dataviewJsPath || "/Supporting/dataview-functions"}");
processDueDates(dv,'#<% courseId %>');
\`\`\``;
      return template;
    }
  }
  generateCourseIndexTemplate() {
    return `---
content_type: course_index
tags:
  - index
---

# Course Index

## Modules

## Chapters

## Assignments

## Resources

## Vocabulary

## Due Dates`;
  }
  generateModuleTemplate() {
    return `<%*
const { season, moduleNumber, weekNumber, course, courseId, discipline, dayOfWeek } = await tp.user.new_module(app, tp, "2025");
let title = courseId
if (moduleNumber && weekNumber) { title = \`M\${moduleNumber}/W\${weekNumber}\`}
else if (moduleNumber) { title = \`M\${moduleNumber}\` } 
else if (weekNumber) { title = \`W\${weekNumber}\`}
%>---
${this.settings.useEnhancedMetadata ? `course_id: <% courseId %>
module_number: <% moduleNumber %>
week_number: <% weekNumber %>
class_day: <% dayOfWeek %>
content_type: module
parent_course: "[[<% course %>]]"` : `course_id: <% courseId %>
module_number: <% moduleNumber %>
week_number: <% weekNumber %>
class_day: <% dayOfWeek %>`}
created: <% tp.date.now("YYYY-MM-DD[T]HH:mm:ssZ") %>
tags:
  - education
  - <% courseId %>
  - module
---


# [[<% course %>]] - <% title %> - <% dayOfWeek %>

## Due Dates
| Date | Assignment |
| ---- | ---------- |
|      |            |
|      |            |
|      |            |

\`\`\`dataviewjs
const {processDueDates} = require("${this.settings.dataviewJsPath || "/Supporting/dataview-functions"}");
processDueDates(dv,'#<% courseId %>');
\`\`\`

## Learning Objectives

## Reading Assignment

## Lecture Notes

## Discussion Questions

## Vocabulary

\`\`\`dataviewjs
const {processCourseVocabulary} = require("${this.settings.dataviewJsPath || "/Supporting/dataview-functions"}");
processCourseVocabulary(dv, '<% courseId %>');
\`\`\`

## Additional Resources`;
  }
  generateChapterTemplate() {
    return `<%*
const { chapterNumber, course, courseId, discipline, text} = await tp.user.new_chapter(tp);
%>---
${this.settings.useEnhancedMetadata ? `course_id: <% courseId %>
chapter_number: <% chapterNumber %>
content_type: chapter
parent_course: "[[<% course %>]]"
text_reference: "[[<% text %>]]"` : `course_id: <% courseId %>
chapter_number: <% chapterNumber %>`}
created: <% tp.date.now("YYYY-MM-DD[T]HH:mm:ssZ") %>
tags:
  - education
  - <% courseId %>
  - chapter
---


# [[<% text %>]] - Chapter <% chapterNumber %>

## Reading Assignment
- **Textbook**: [[<% text %>]]
- **Chapter**: <% chapterNumber %>
- **Pages**: 

## Summary

## Key Concepts

## Vocabulary
- 

## Notes

## Discussion Questions

## Further Reading`;
  }
  generateAssignmentTemplate() {
    return `---
${this.settings.useEnhancedMetadata ? `course_id: <% courseId %>
assignment_type: <% assignmentType %>
due_date: <% dueDate %>
points: <% points %>
content_type: assignment
parent_course: "[[<% course %>]]"` : `course_id: <% courseId %>
assignment_type: <% assignmentType %>
due_date: <% dueDate %>`}
created: <% tp.date.now("YYYY-MM-DD[T]HH:mm:ssZ") %>
status: pending
tags:
  - education
  - <% courseId %>
  - assignment
---

# <% assignmentName %> - <% courseId %>

## Description

## Instructions

## Due Date
**Assigned**: <% tp.date.now("YYYY-MM-DD") %>
**Due**: <% dueDate %>

## Submission

## Grading Criteria

## Resources

# Due Dates
| <% dueDate %> | <% assignmentName %> | pending |
`;
  }
  generateDailyNoteTemplate() {
    return `---
content_type: daily_note
date: <% tp.date.now("YYYY-MM-DD") %>
tags:
  - daily
  - <% tp.date.now("YYYY") %>
  - <% tp.date.now("MM") %>
  - <% tp.date.now("DD") %>
---

# <% tp.date.now("YYYY-MM-DD - dddd") %>

<< [[<% tp.date.yesterday("YYYY-MM-DD") %>]] | [[<% tp.date.tomorrow("YYYY-MM-DD") %>]] >>

## Today's Focus

## Courses Worked On
- 

## Tasks Completed
- [ ] 

## Vocabulary Reviewed
- 

## Assignments Due
- 

## Learning Achievements

## Challenges

## Tomorrow's Plan

## Reflection`;
  }
  generateVocabularyTemplate() {
    return `## <% term %>
**Term**: <% term %>
**Part of Speech**: 
**Definition**: 
**Context**: 
**Examples**: 
**Related Terms**: 
**See Also**:`;
  }
  generateDueDateTemplate() {
    return `| <% dueDate %> | <% assignment %> | <% status %> |`;
  }
  createREADME(basePath) {
    return __async(this, null, function* () {
      const readmeContent = `# Tuckers Tools Templates

This directory contains templates for the Tuckers Tools Obsidian plugin.

## Template Categories

- **Courses**: Templates for creating and organizing courses
- **Modules**: Templates for course modules
- **Chapters**: Templates for chapter notes
- **Assignments**: Templates for assignments
- **Daily**: Templates for daily notes
- **Utilities**: Helper templates

## Usage

These templates are designed to work with the Tuckers Tools plugin. To use them:

1. Install the Tuckers Tools plugin
2. Configure your settings in the plugin settings tab
3. Use the "Insert Template" command to apply these templates to new notes

## Customization

Feel free to customize these templates to suit your needs. The plugin will not overwrite your changes when updating templates.`;
      yield this.writeTemplateFile(`${basePath}/README.md`, readmeContent);
    });
  }
};

// courseWizard.ts
var import_obsidian4 = require("obsidian");

// inputModal.ts
var import_obsidian3 = require("obsidian");
var InputModal = class extends import_obsidian3.Modal {
  constructor(app, onSubmit) {
    super(app);
    this.onSubmit = onSubmit;
  }
  onOpen() {
    const { contentEl } = this;
    contentEl.createEl("h2", { text: "Enter Value" });
    new import_obsidian3.Setting(contentEl).setName("Value").addText(
      (text) => text.onChange((value) => {
        this.result = value;
      }).inputEl.focus()
    );
    new import_obsidian3.Setting(contentEl).addButton(
      (btn) => btn.setButtonText("Submit").setCta().onClick(() => {
        this.close();
        this.onSubmit(this.result || "");
      })
    ).addButton(
      (btn) => btn.setButtonText("Cancel").onClick(() => {
        this.close();
        this.onSubmit(null);
      })
    );
  }
  onClose() {
    const { contentEl } = this;
    contentEl.empty();
  }
};
var SuggesterModal = class extends import_obsidian3.Modal {
  constructor(app, options, onSubmit) {
    super(app);
    this.onSubmit = onSubmit;
    const dropdownOptions = {};
    options.forEach((option) => {
      dropdownOptions[option] = option;
    });
    this.createDropdown(dropdownOptions);
  }
  createDropdown(options) {
    const { contentEl } = this;
    contentEl.createEl("h2", { text: "Select Option" });
    let selectedValue = Object.keys(options)[0] || null;
    const dropdown = contentEl.createEl("select");
    Object.entries(options).forEach(([key, value]) => {
      const option = dropdown.createEl("option", {
        value: key,
        text: value
      });
      if (key === selectedValue) {
        option.selected = true;
      }
    });
    dropdown.addEventListener("change", (event) => {
      selectedValue = event.target.value;
      this.result = selectedValue;
    });
    new import_obsidian3.Setting(contentEl).addButton(
      (btn) => btn.setButtonText("Submit").setCta().onClick(() => {
        this.close();
        this.onSubmit(selectedValue);
      })
    ).addButton(
      (btn) => btn.setButtonText("Cancel").onClick(() => {
        this.close();
        this.onSubmit(null);
      })
    );
  }
  onOpen() {
  }
  onClose() {
    const { contentEl } = this;
    contentEl.empty();
  }
};

// courseWizard.ts
var CourseCreationWizard = class {
  constructor(app, settings) {
    this.app = app;
    this.settings = settings;
  }
  createCourseHomepage() {
    return __async(this, null, function* () {
      try {
        const courseDetails = yield this.promptCourseDetails();
        if (!courseDetails) {
          return false;
        }
        const folderPath = yield this.createCourseFolderStructure(courseDetails);
        yield this.createCourseHomepageNote(courseDetails, folderPath);
        yield this.createAttachmentsFolder(folderPath);
        new import_obsidian4.Notice(`Course "${courseDetails.courseName}" created successfully!`);
        console.log(
          `Course created: ${courseDetails.courseName} at ${folderPath}`
        );
        return true;
      } catch (error) {
        console.error("Error creating course:", error);
        new import_obsidian4.Notice(`Error creating course: ${error.message}`);
        return false;
      }
    });
  }
  promptCourseDetails() {
    return __async(this, null, function* () {
      var _a;
      try {
        const courseName = yield this.promptWithValidation(
          "Course Name",
          "Enter course name (e.g., PSI-101 - Intro to Psychology)",
          (value) => value.trim().length > 0,
          "Course name is required"
        );
        if (!courseName)
          return null;
        const courseSeason = yield this.promptWithOptions(
          "Season",
          "Select semester/season",
          ["Fall", "Winter", "Spring", "Summer"]
        );
        if (!courseSeason)
          return null;
        const courseYear = yield this.promptWithValidation(
          "Year",
          "Enter academic year (e.g., 2025)",
          (value) => /^\d{4}$/.test(value.trim()),
          "Please enter a valid 4-digit year"
        );
        if (!courseYear)
          return null;
        const courseId = ((_a = courseName.split(" - ")[0]) == null ? void 0 : _a.trim()) || slugify(courseName);
        return {
          courseName,
          courseSeason,
          courseYear,
          courseId
        };
      } catch (error) {
        console.error("Error prompting for course details:", error);
        return null;
      }
    });
  }
  promptWithValidation(title, message, validator, errorMessage) {
    return __async(this, null, function* () {
      return new Promise((resolve) => {
        const modal = new InputModal(this.app, (result) => {
          if (result === null) {
            resolve(null);
            return;
          }
          if (!validator(result)) {
            new import_obsidian4.Notice(errorMessage);
            this.promptWithValidation(title, message, validator, errorMessage).then(resolve);
            return;
          }
          resolve(result.trim());
        });
        modal.titleEl.setText(title);
        const messageEl = modal.contentEl.createDiv();
        messageEl.setText(message);
        modal.open();
      });
    });
  }
  promptWithOptions(title, message, options) {
    return __async(this, null, function* () {
      return new Promise((resolve) => {
        const modal = new SuggesterModal(this.app, options, (result) => {
          if (result === null) {
            resolve(null);
            return;
          }
          if (options.includes(result)) {
            resolve(result);
          } else {
            new import_obsidian4.Notice(`Please select one of: ${options.join(", ")}`);
            this.promptWithOptions(title, message, options).then(resolve);
          }
        });
        modal.titleEl.setText(title);
        const messageEl = modal.contentEl.createDiv();
        messageEl.setText(message);
        modal.open();
      });
    });
  }
  createCourseFolderStructure(courseDetails) {
    return __async(this, null, function* () {
      const folderPath = `${courseDetails.courseYear}/${courseDetails.courseSeason}/${courseDetails.courseName}`;
      try {
        yield this.app.vault.createFolder(folderPath);
        console.log(`Created course folder: ${folderPath}`);
        return folderPath;
      } catch (error) {
        console.log(`Course folder already exists or created: ${folderPath}`);
        return folderPath;
      }
    });
  }
  createCourseHomepageNote(courseDetails, folderPath) {
    return __async(this, null, function* () {
      const notePath = `${folderPath}/${courseDetails.courseName}.md`;
      const content = this.generateCourseHomepageContent(courseDetails);
      try {
        yield this.app.vault.create(notePath, content);
        console.log(`Created course homepage: ${notePath}`);
      } catch (error) {
        console.error(`Error creating course homepage: ${error}`);
        throw error;
      }
    });
  }
  createAttachmentsFolder(folderPath) {
    return __async(this, null, function* () {
      const attachmentsPath = `${folderPath}/Attachments`;
      try {
        yield this.app.vault.createFolder(attachmentsPath);
        console.log(`Created attachments folder: ${attachmentsPath}`);
      } catch (error) {
        console.log(`Attachments folder already exists: ${attachmentsPath}`);
      }
    });
  }
  generateCourseHomepageContent(courseDetails) {
    const templateManager = new TemplateManager(this.app, this.settings);
    const templateContent = templateManager.generateCourseHomepageTemplate();
    return templateContent.replace(/<% courseName %>/g, courseDetails.courseName).replace(/<% courseSeason %>/g, courseDetails.courseSeason).replace(/<% courseYear %>/g, courseDetails.courseYear).replace(/<% courseId %>/g, courseDetails.courseId).replace(/<% tp\.date\.now\("YYYY-MM-DD\[T\]HH:mm:ssZ"\) %>/g, new Date().toISOString()).replace(/<% tp\.date\.now\("YYYY-MM-DD\[T\]hh:mm:SSSSZZ"\) %>/g, new Date().toISOString());
  }
};

// vocabulary.ts
var import_obsidian5 = require("obsidian");
var VocabularyExtractor = class {
  constructor(app) {
    this.app = app;
  }
  extractVocabularyFromNote(content) {
    const vocabRegex = /^#+ Vocabulary.*\n((?:.*?\n)*?)(?=^\s*#\s|$)/m;
    const vocabMatches = content == null ? void 0 : content.match(vocabRegex);
    if (vocabMatches) {
      const vocabData = vocabMatches[1].trim();
      const cleanedVocab = vocabData.replace(/\[\[.*?\]\]/g, "").replace(/^\s*-\s*/gm, "").split("\n").map((term) => term.trim()).filter((term) => term.length > 0);
      return cleanedVocab;
    }
    return [];
  }
  extractVocabularyFromCourse(courseId) {
    return __async(this, null, function* () {
      console.log(`Extracting vocabulary for course: ${courseId}`);
      try {
        const courseNotes = yield this.findCourseNotes(courseId);
        if (courseNotes.length === 0) {
          console.log(`No notes found for course: ${courseId}`);
          return {};
        }
        const vocabularyData = {};
        for (const note of courseNotes) {
          try {
            const content = yield this.app.vault.read(note);
            const vocabulary = this.extractVocabularyFromNote(content);
            if (vocabulary.length > 0) {
              vocabularyData[note.basename] = vocabulary;
            }
          } catch (error) {
            console.error(`Error reading note ${note.path}:`, error);
          }
        }
        console.log(
          `Extracted vocabulary from ${Object.keys(vocabularyData).length} notes for course: ${courseId}`
        );
        return vocabularyData;
      } catch (error) {
        console.error(
          `Error extracting vocabulary for course ${courseId}:`,
          error
        );
        return {};
      }
    });
  }
  findCourseNotes(courseId) {
    return __async(this, null, function* () {
      const notes = [];
      const files = this.app.vault.getMarkdownFiles();
      for (const file of files) {
        if (file.path.includes(courseId) || (yield this.noteBelongsToCourse(file, courseId))) {
          notes.push(file);
        }
      }
      return notes;
    });
  }
  noteBelongsToCourse(file, courseId) {
    return __async(this, null, function* () {
      try {
        const content = yield this.app.vault.read(file);
        const frontmatterMatch = content.match(/^---\n([\s\S]*?)\n---/);
        if (frontmatterMatch) {
          const frontmatter = frontmatterMatch[1];
          return frontmatter.includes(`course_id: ${courseId}`) || frontmatter.includes(`course_id:${courseId}`);
        }
        return false;
      } catch (error) {
        console.error(
          `Error checking if note ${file.path} belongs to course ${courseId}:`,
          error
        );
        return false;
      }
    });
  }
  generateVocabularyIndex(courseId, vocabularyData) {
    return __async(this, null, function* () {
      const allTerms = [];
      const termSources = {};
      for (const [noteName, terms] of Object.entries(vocabularyData)) {
        for (const term of terms) {
          if (!allTerms.includes(term)) {
            allTerms.push(term);
            termSources[term] = [];
          }
          termSources[term].push(noteName);
        }
      }
      allTerms.sort();
      let content = `# Vocabulary Index - ${courseId}

`;
      content += `Total unique terms: ${allTerms.length}

`;
      for (const term of allTerms) {
        content += `## ${term}
`;
        content += `**Sources:** ${termSources[term].join(", ")}

`;
        content += `**Definition:**

`;
        content += `**Context:**

`;
        content += `**Examples:**

`;
        content += `---

`;
      }
      return content;
    });
  }
  createVocabularyIndexFile(courseId) {
    return __async(this, null, function* () {
      try {
        const vocabularyData = yield this.extractVocabularyFromCourse(courseId);
        if (Object.keys(vocabularyData).length === 0) {
          console.log(`No vocabulary found for course: ${courseId}`);
          return;
        }
        const indexContent = yield this.generateVocabularyIndex(
          courseId,
          vocabularyData
        );
        const fileName = `${courseId} - Vocabulary Index.md`;
        const filePath = `Courses/${courseId}/${fileName}`;
        try {
          yield this.app.vault.create(filePath, indexContent);
          console.log(`Created vocabulary index file: ${filePath}`);
        } catch (error) {
          const existingFile = this.app.vault.getAbstractFileByPath(filePath);
          if (existingFile && existingFile instanceof import_obsidian5.TFile) {
            yield this.app.vault.modify(existingFile, indexContent);
            console.log(`Updated vocabulary index file: ${filePath}`);
          }
        }
      } catch (error) {
        console.error(
          `Error creating vocabulary index for course ${courseId}:`,
          error
        );
        throw error;
      }
    });
  }
};

// dueDates.ts
var import_obsidian6 = require("obsidian");
var DueDatesParser = class {
  constructor(app) {
    this.app = app;
  }
  parseDueDatesFromNote(content) {
    const dueDatesRegex = /# Due Dates[\s\S]*?(?=\n#|$)/;
    const matches = content == null ? void 0 : content.match(dueDatesRegex);
    if (!matches) {
      return [];
    }
    const dueDatesSection = matches[0];
    const dueDates = [];
    const tableRegex = /\|[\s\S]*?\n/g;
    const tableMatches = dueDatesSection.match(tableRegex);
    if (tableMatches) {
      for (const table of tableMatches) {
        const rows = table.trim().split("\n").filter((row) => row.startsWith("|"));
        const parsedRows = this.parseTableRows(rows);
        dueDates.push(...parsedRows);
      }
    }
    return dueDates;
  }
  parseTableRows(rows) {
    if (rows.length < 2)
      return [];
    const dueDates = [];
    for (let i = 1; i < rows.length; i++) {
      const row = rows[i];
      const columns = row.split("|").map((col) => col.trim()).filter((col) => col);
      if (columns.length >= 2) {
        const [date, assignment, status = "pending"] = columns;
        if (date && assignment && this.isValidDate(date)) {
          dueDates.push({ date, assignment, status });
        }
      }
    }
    return dueDates;
  }
  isValidDate(dateString) {
    const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
    return dateRegex.test(dateString) && !isNaN(Date.parse(dateString));
  }
  parseDueDatesFromCourse(courseId, startDate, endDate) {
    return __async(this, null, function* () {
      console.log(`Parsing due dates for course: ${courseId}`);
      try {
        const courseNotes = yield this.findCourseNotes(courseId);
        if (courseNotes.length === 0) {
          console.log(`No notes found for course: ${courseId}`);
          return [];
        }
        const allDueDates = [];
        for (const note of courseNotes) {
          try {
            const content = yield this.app.vault.read(note);
            const dueDates = this.parseDueDatesFromNote(content);
            const dueDatesWithSource = dueDates.map((dueDate) => __spreadProps(__spreadValues({}, dueDate), {
              source: note.basename
            }));
            allDueDates.push(...dueDatesWithSource);
          } catch (error) {
            console.error(`Error reading note ${note.path}:`, error);
          }
        }
        let filteredDueDates = allDueDates;
        if (startDate || endDate) {
          filteredDueDates = this.filterByDateRange(
            allDueDates,
            startDate,
            endDate
          );
        }
        filteredDueDates.sort(
          (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()
        );
        console.log(
          `Found ${filteredDueDates.length} due dates for course: ${courseId}`
        );
        return filteredDueDates;
      } catch (error) {
        console.error(`Error parsing due dates for course ${courseId}:`, error);
        return [];
      }
    });
  }
  findCourseNotes(courseId) {
    return __async(this, null, function* () {
      const notes = [];
      const files = this.app.vault.getMarkdownFiles();
      for (const file of files) {
        if (file.path.includes(courseId) || (yield this.noteBelongsToCourse(file, courseId))) {
          notes.push(file);
        }
      }
      return notes;
    });
  }
  noteBelongsToCourse(file, courseId) {
    return __async(this, null, function* () {
      try {
        const content = yield this.app.vault.read(file);
        const frontmatterMatch = content.match(/^---\n([\s\S]*?)\n---/);
        if (frontmatterMatch) {
          const frontmatter = frontmatterMatch[1];
          return frontmatter.includes(`course_id: ${courseId}`) || frontmatter.includes(`course_id:${courseId}`);
        }
        return false;
      } catch (error) {
        console.error(
          `Error checking if note ${file.path} belongs to course ${courseId}:`,
          error
        );
        return false;
      }
    });
  }
  filterByDateRange(dueDates, startDate, endDate) {
    return dueDates.filter((dueDate) => {
      const dueDateTime = new Date(dueDate.date).getTime();
      if (startDate && dueDateTime < new Date(startDate).getTime()) {
        return false;
      }
      if (endDate && dueDateTime > new Date(endDate).getTime()) {
        return false;
      }
      return true;
    });
  }
  generateDueDatesSummary(courseId, dueDates) {
    return __async(this, null, function* () {
      if (dueDates.length === 0) {
        return `# Due Dates Summary - ${courseId}

No due dates found.
`;
      }
      const byStatus = dueDates.reduce((acc, dueDate) => {
        if (!acc[dueDate.status]) {
          acc[dueDate.status] = [];
        }
        acc[dueDate.status].push(dueDate);
        return acc;
      }, {});
      let content = `# Due Dates Summary - ${courseId}

`;
      content += `Total assignments: ${dueDates.length}

`;
      for (const [status, items] of Object.entries(byStatus)) {
        content += `## ${status.charAt(0).toUpperCase() + status.slice(1)} (${items.length})

`;
        content += `| Date | Assignment | Source |
`;
        content += `| ---- | ---------- | ------ |
`;
        for (const item of items) {
          content += `| ${item.date} | ${item.assignment} | ${item.source} |
`;
        }
        content += `
`;
      }
      return content;
    });
  }
  createDueDatesSummaryFile(courseId, startDate, endDate) {
    return __async(this, null, function* () {
      try {
        const dueDates = yield this.parseDueDatesFromCourse(
          courseId,
          startDate,
          endDate
        );
        const summaryContent = yield this.generateDueDatesSummary(
          courseId,
          dueDates
        );
        const fileName = `${courseId} - Due Dates Summary.md`;
        const filePath = `Courses/${courseId}/${fileName}`;
        try {
          yield this.app.vault.create(filePath, summaryContent);
          console.log(`Created due dates summary file: ${filePath}`);
        } catch (error) {
          const existingFile = this.app.vault.getAbstractFileByPath(filePath);
          if (existingFile && existingFile instanceof import_obsidian6.TFile) {
            yield this.app.vault.modify(existingFile, summaryContent);
            console.log(`Updated due dates summary file: ${filePath}`);
          }
        }
      } catch (error) {
        console.error(
          `Error creating due dates summary for course ${courseId}:`,
          error
        );
        throw error;
      }
    });
  }
};

// dailyNotes.ts
var import_obsidian7 = require("obsidian");
var DailyNotesIntegration = class {
  constructor(app) {
    this.app = app;
  }
  getTodaysActivities() {
    return __async(this, null, function* () {
      console.log("Getting today's academic activities");
      try {
        const today = new Date();
        const todayString = today.toISOString().split("T")[0];
        const files = this.app.vault.getMarkdownFiles();
        const todaysFiles = [];
        for (const file of files) {
          const fileDate = this.extractDateFromPath(file.path);
          if (fileDate === todayString) {
            todaysFiles.push(file);
          }
        }
        const activities = [];
        for (const file of todaysFiles) {
          const activity = yield this.analyzeFileActivity(file);
          if (activity) {
            activities.push(activity);
          }
        }
        console.log(`Found ${activities.length} academic activities for today`);
        return activities;
      } catch (error) {
        console.error("Error getting today's activities:", error);
        return [];
      }
    });
  }
  getCourseActivityForDate(courseId, date) {
    return __async(this, null, function* () {
      console.log(`Getting activity for course ${courseId} on date ${date}`);
      try {
        const courseFiles = yield this.findCourseFilesForDate(courseId, date);
        const activities = [];
        for (const file of courseFiles) {
          const content = yield this.app.vault.read(file);
          const fileType = this.determineFileType(file, content);
          activities.push({
            file: file.basename,
            type: fileType
          });
        }
        console.log(
          `Found ${activities.length} activities for course ${courseId} on ${date}`
        );
        return activities;
      } catch (error) {
        console.error(
          `Error getting course activity for ${courseId} on ${date}:`,
          error
        );
        return [];
      }
    });
  }
  extractDateFromPath(filePath) {
    const dateRegex = /(\d{4}-\d{2}-\d{2})/g;
    const matches = filePath.match(dateRegex);
    return matches ? matches[matches.length - 1] : null;
  }
  analyzeFileActivity(file) {
    return __async(this, null, function* () {
      try {
        const content = yield this.app.vault.read(file);
        const fileType = this.determineFileType(file, content);
        const courseId = this.extractCourseIdFromContent(content) || this.extractCourseIdFromPath(file.path);
        return {
          file: file.basename,
          type: fileType,
          course: courseId || void 0
        };
      } catch (error) {
        console.error(`Error analyzing file ${file.path}:`, error);
        return null;
      }
    });
  }
  determineFileType(file, content) {
    const path = file.path.toLowerCase();
    if (path.includes("daily") || content.includes("content_type: daily_note")) {
      return "daily_note";
    }
    if (path.includes("courses") || content.includes("course_id:")) {
      if (content.includes("content_type: course_homepage")) {
        return "course_homepage";
      }
      if (content.includes("content_type: module")) {
        return "module";
      }
      if (content.includes("content_type: chapter")) {
        return "chapter";
      }
      if (content.includes("content_type: assignment")) {
        return "assignment";
      }
      return "course_note";
    }
    if (content.includes("## ") && content.match(/^\*\*Term\*\*:/m)) {
      return "vocabulary_entry";
    }
    return "other";
  }
  extractCourseIdFromContent(content) {
    const courseIdRegex = /course_id:\s*([A-Z]{2,4}-\d{3})/;
    const match = content.match(courseIdRegex);
    return match ? match[1] : null;
  }
  extractCourseIdFromPath(filePath) {
    const courseIdRegex = /([A-Z]{2,4}-\d{3})/g;
    const matches = filePath.match(courseIdRegex);
    return matches ? matches[matches.length - 1] : null;
  }
  findCourseFilesForDate(courseId, date) {
    return __async(this, null, function* () {
      const files = [];
      const allFiles = this.app.vault.getMarkdownFiles();
      for (const file of allFiles) {
        if (file.path.includes(courseId) || (yield this.fileBelongsToCourse(file, courseId))) {
          const fileDate = this.extractDateFromPath(file.path);
          if (fileDate === date) {
            files.push(file);
          }
        }
      }
      return files;
    });
  }
  fileBelongsToCourse(file, courseId) {
    return __async(this, null, function* () {
      try {
        const content = yield this.app.vault.read(file);
        return this.extractCourseIdFromContent(content) === courseId;
      } catch (error) {
        console.error(
          `Error checking if file ${file.path} belongs to course ${courseId}:`,
          error
        );
        return false;
      }
    });
  }
  generateDailySummary(date) {
    return __async(this, null, function* () {
      const targetDate = date || new Date().toISOString().split("T")[0];
      const activities = yield this.getCourseActivityForDate("", targetDate);
      if (activities.length === 0) {
        return `# Academic Activities - ${targetDate}

No academic activities recorded for this date.
`;
      }
      const byCourse = {};
      const noCourse = [];
      for (const activity of activities) {
        if (activity.file.includes("Courses/")) {
          const pathParts = activity.file.split("/");
          const courseIndex = pathParts.findIndex((part) => part.includes("-"));
          if (courseIndex >= 0) {
            const courseId = pathParts[courseIndex];
            if (!byCourse[courseId]) {
              byCourse[courseId] = [];
            }
            byCourse[courseId].push(activity);
          } else {
            noCourse.push(activity);
          }
        } else {
          noCourse.push(activity);
        }
      }
      let content = `# Academic Activities - ${targetDate}

`;
      content += `Total activities: ${activities.length}

`;
      for (const [courseId, courseActivities] of Object.entries(byCourse)) {
        content += `## ${courseId}

`;
        content += `| File | Type |
`;
        content += `| ---- | ---- |
`;
        for (const activity of courseActivities) {
          content += `| ${activity.file} | ${activity.type} |
`;
        }
        content += `
`;
      }
      if (noCourse.length > 0) {
        content += `## Other Activities

`;
        content += `| File | Type |
`;
        content += `| ---- | ---- |
`;
        for (const activity of noCourse) {
          content += `| ${activity.file} | ${activity.type} |
`;
        }
        content += `
`;
      }
      return content;
    });
  }
  createDailySummaryFile(date) {
    return __async(this, null, function* () {
      try {
        const targetDate = date || new Date().toISOString().split("T")[0];
        const summaryContent = yield this.generateDailySummary(targetDate);
        const fileName = `${targetDate} - Academic Summary.md`;
        const filePath = `Daily/${fileName}`;
        try {
          yield this.app.vault.create(filePath, summaryContent);
          console.log(`Created daily summary file: ${filePath}`);
        } catch (error) {
          const existingFile = this.app.vault.getAbstractFileByPath(filePath);
          if (existingFile && existingFile instanceof import_obsidian7.TFile) {
            yield this.app.vault.modify(existingFile, summaryContent);
            console.log(`Updated daily summary file: ${filePath}`);
          }
        }
      } catch (error) {
        console.error(`Error creating daily summary for ${date}:`, error);
        throw error;
      }
    });
  }
};

// assignmentsModal.ts
var import_obsidian8 = require("obsidian");
var AssignmentsModal = class extends import_obsidian8.Modal {
  constructor(app, courseName, courseId, onSubmit) {
    super(app);
    this.assignments = [{ name: "", dueDate: "", type: "", points: "", description: "" }];
    this.courseName = courseName;
    this.courseId = courseId;
    this.onSubmit = onSubmit;
  }
  onOpen() {
    const { contentEl } = this;
    contentEl.empty();
    contentEl.addClass("tuckers-tools-assignments-modal");
    contentEl.createEl("h2", { text: "Create Multiple Assignments" });
    new import_obsidian8.Setting(contentEl).setName("Course").setDesc(`${this.courseName} (${this.courseId})`).setDisabled(true);
    const assignmentsContainer = contentEl.createDiv({ cls: "assignments-container" });
    this.addAssignmentSection(assignmentsContainer, 0);
    new import_obsidian8.Setting(contentEl).addButton(
      (btn) => btn.setButtonText("Add Assignment").setCta().onClick(() => {
        const newIndex = this.assignments.length;
        this.assignments.push({ name: "", dueDate: "", type: "", points: "", description: "" });
        this.addAssignmentSection(assignmentsContainer, newIndex);
      })
    );
    new import_obsidian8.Setting(contentEl).addButton(
      (btn) => btn.setButtonText("Create Assignments").setCta().onClick(() => {
        const validAssignments = this.assignments.filter(
          (a) => a.name.trim() !== "" || a.dueDate.trim() !== ""
        );
        this.onSubmit(validAssignments, this.courseName, this.courseId);
        this.close();
      })
    );
  }
  addAssignmentSection(container, index) {
    const section = container.createDiv({ cls: "assignment-section" });
    section.createEl("h3", { text: `Assignment #${index + 1}` });
    new import_obsidian8.Setting(section).setName("Assignment Name").addText(
      (text) => text.setPlaceholder("Enter assignment name").setValue(this.assignments[index].name).onChange((value) => {
        this.assignments[index].name = value;
      })
    );
    new import_obsidian8.Setting(section).setName("Due Date").setDesc("Format: YYYY-MM-DD").addText(
      (text) => text.setPlaceholder("2024-01-15").setValue(this.assignments[index].dueDate).onChange((value) => {
        this.assignments[index].dueDate = value;
      })
    );
    new import_obsidian8.Setting(section).setName("Assignment Type").addText(
      (text) => text.setPlaceholder("e.g., Homework, Quiz, Exam").setValue(this.assignments[index].type).onChange((value) => {
        this.assignments[index].type = value;
      })
    );
    new import_obsidian8.Setting(section).setName("Points").addText(
      (text) => text.setPlaceholder("e.g., 100").setValue(this.assignments[index].points).onChange((value) => {
        this.assignments[index].points = value;
      })
    );
    new import_obsidian8.Setting(section).setName("Description").addTextArea(
      (text) => text.setPlaceholder("Enter assignment description").setValue(this.assignments[index].description).onChange((value) => {
        this.assignments[index].description = value;
      })
    );
    if (this.assignments.length > 1) {
      new import_obsidian8.Setting(section).addButton(
        (btn) => btn.setButtonText("Remove").onClick(() => {
          this.assignments.splice(index, 1);
          section.remove();
          this.renumberAssignments();
        })
      );
    }
  }
  renumberAssignments() {
    const sections = this.contentEl.querySelectorAll(".assignment-section");
    sections.forEach((section, index) => {
      const header = section.querySelector("h3");
      if (header) {
        header.textContent = `Assignment #${index + 1}`;
      }
    });
  }
  onClose() {
    const { contentEl } = this;
    contentEl.empty();
  }
};

// Supporting/dataview-functions.ts
function processCourseVocabulary(dv, courseId) {
  return __async(this, null, function* () {
    try {
      const pages = dv.pages(courseId).filter((p) => p.file.ext === "md" && p.file.name !== courseId).map((p) => ({
        name: p.file.name,
        path: p.file.path
      }));
      dv.header(1, "All Course Vocabulary");
      for (const page of pages) {
        if (!page.path)
          continue;
        try {
          const file = yield dv.app.vault.getFileByPath(page.path);
          const content = yield dv.app.vault.read(file);
          const vocabRegex = /^#+ Vocabulary.*\n((?:.*?\n)*?)(?=\n\s*#|$)/m;
          const vocabMatches = content == null ? void 0 : content.match(vocabRegex);
          if (vocabMatches) {
            const vocabData = vocabMatches[1].trim();
            const cleanedVocab = vocabData.replace(/\[\[.*?\]\]/g, "").trim().split("\n").filter((line) => line.startsWith("- ")).map((line) => line.substring(2)).filter(Boolean);
            if (cleanedVocab.length > 0) {
              dv.header(3, `[[${page.name}]]`);
              dv.list(cleanedVocab);
            }
          }
        } catch (e) {
          console.log(`Error processing ${page.path}:`, e);
          continue;
        }
      }
    } catch (error) {
      console.error("Error in Vocabulary Processing:", error);
    }
  });
}
function processDueDates(dv, source, startDate = null, endDate = null) {
  return __async(this, null, function* () {
    var _a, _b, _c, _d, _e, _f, _g, _h;
    function deduplicateFirstTwoColumns(arr) {
      const seen = /* @__PURE__ */ new Set();
      return arr.filter((entry) => {
        const key = JSON.stringify([entry[0], entry[1]]);
        return !seen.has(key) && seen.add(key);
      });
    }
    const defaultStartDate = window.moment().subtract(1, "day").format("YYYY-MM-DD");
    const start = startDate || defaultStartDate;
    const end = endDate || window.moment().add(1, "year").format("YYYY-MM-DD");
    const pages = yield dv.pages(source).filter((p) => p.file.name !== source && p.file.ext == "md");
    let allEntries = [];
    for (const page of pages.values) {
      if (!((_a = page == null ? void 0 : page.file) == null ? void 0 : _a.path)) {
        return;
      }
      const content = yield dv.app.vault.cachedRead(dv.app.vault.getFileByPath((_b = page.file) == null ? void 0 : _b.path));
      const regex = /# Due Dates([\s\S]*?)(?=\n#|$)/;
      const matches = content == null ? void 0 : content.match(regex);
      if (matches) {
        const tableData = matches[1].trim();
        const lines = tableData.split("\n").slice(1);
        for (const line of lines) {
          let formattedDueDate;
          const columns = line.split("|").map((c) => c.trim()).filter((c) => c);
          let [dueDate, assignment] = columns;
          if (!Date.parse(dueDate) || (assignment == null ? void 0 : assignment.match(/✅/))) {
            continue;
          }
          assignment = (assignment == null ? void 0 : assignment.match(/[A-Z]{3}-[0-9]{3}/)) ? assignment : `#${page.course_id} - ${assignment}`;
          if (window.moment(dueDate).isBetween(start, end, void 0, "[]")) {
            const uniqueRow = !allEntries.some(
              (e) => {
                var _a2;
                return e[0].match((_a2 = window.moment(dueDate)) == null ? void 0 : _a2.format("YYYY-MM-DD")) && e[1] == assignment;
              }
            );
            if (assignment && uniqueRow) {
              if ((_c = window.moment(dueDate)) == null ? void 0 : _c.isBefore(start)) {
                continue;
              } else if (window.moment(dueDate).isAfter(window.moment().subtract(1, "w"))) {
                formattedDueDate = `<span class="due one_week">${(_d = window.moment(
                  dueDate
                )) == null ? void 0 : _d.format("YYYY-MM-DD ddd")}</span>`;
              } else if (window.moment(dueDate).isAfter(window.moment().subtract(2, "w"))) {
                formattedDueDate = `<span class="due two_weeks">${(_e = window.moment(
                  dueDate
                )) == null ? void 0 : _e.format("YYYY-MM-DD ddd")}</span>`;
              } else {
                formattedDueDate = (_f = window.moment(dueDate)) == null ? void 0 : _f.format("YYYY-MM-DD ddd");
              }
              allEntries.push([
                dueDate,
                formattedDueDate,
                assignment,
                `[[${(_g = page == null ? void 0 : page.file) == null ? void 0 : _g.path}|${(_h = page == null ? void 0 : page.file) == null ? void 0 : _h.name}]]`
              ]);
            }
          }
        }
      }
    }
    const sortedRows = deduplicateFirstTwoColumns(
      allEntries.sort((a, b) => window.moment(a[0]).valueOf() - window.moment(b[0]).valueOf()).map((a) => [a[1], a[2], a[3]])
    );
    const table = dv.markdownTable(["Due Date", "Task Description", "File"], sortedRows);
    dv.el("table", table);
  });
}

// main.ts
var TuckersToolsPlugin = class extends import_obsidian9.Plugin {
  onload() {
    return __async(this, null, function* () {
      console.log("Loading Tuckers Tools plugin");
      yield this.loadSettings();
      this.templateManager = new TemplateManager(this.app, this.settings);
      this.courseWizard = new CourseCreationWizard(this.app, this.settings);
      this.vocabularyExtractor = new VocabularyExtractor(this.app);
      this.dueDatesParser = new DueDatesParser(this.app);
      this.dailyNotesIntegration = new DailyNotesIntegration(this.app);
      this.dataviewFunctions = { processCourseVocabulary, processDueDates };
      this.addSettingTab(new TuckersToolsSettingTab(this.app, this));
      this.initializeTemplaterFunctions();
      this.addCommand({
        id: "install-templates",
        name: "Install/Update Tuckers Tools Templates",
        callback: () => {
          this.templateManager.installTemplates();
        }
      });
      this.addCommand({
        id: "update-templates",
        name: "Update Tuckers Tools Templates",
        callback: () => {
          this.templateManager.updateTemplates();
        }
      });
      this.addCommand({
        id: "create-multiple-assignments",
        name: "Create Multiple Assignments for Course",
        callback: () => __async(this, null, function* () {
          const currentFile = this.app.workspace.getActiveFile();
          let courseId = "";
          let courseName = "";
          if (currentFile) {
            const cache = this.app.metadataCache.getFileCache(currentFile);
            if (cache && cache.frontmatter) {
              courseId = cache.frontmatter.course_id || "";
              courseName = cache.frontmatter.course_name || cache.frontmatter.title || currentFile.basename;
            }
          }
          if (!courseId) {
            const promptedCourseId = yield this.promptForCourseId("Enter course ID for assignments");
            if (!promptedCourseId)
              return;
            courseId = promptedCourseId;
            courseName = courseId;
          }
          new AssignmentsModal(
            this.app,
            courseName,
            courseId,
            (assignments, courseName2, courseId2) => __async(this, null, function* () {
              for (const assignment of assignments) {
                if (assignment.name.trim() === "")
                  continue;
                const assignmentContent = this.generateAssignmentFileContent(
                  assignment,
                  courseName2,
                  courseId2
                );
                const fileName = `${courseId2} - ${assignment.name.replace(/[<>:"/\\|?*]/g, "_")}.md`;
                const filePath = `${courseId2}/${fileName}`;
                try {
                  yield this.app.vault.create(filePath, assignmentContent);
                  console.log(`Created assignment file: ${filePath}`);
                } catch (error) {
                  console.error(`Error creating assignment file ${filePath}:`, error);
                }
              }
            })
          ).open();
        })
      });
      this.addCommand({
        id: "extract-vocabulary",
        name: "Extract Course Vocabulary",
        callback: () => __async(this, null, function* () {
          const courseId = yield this.promptForCourseId(
            "Enter course ID to extract vocabulary from"
          );
          if (courseId) {
            yield this.vocabularyExtractor.createVocabularyIndexFile(courseId);
          }
        })
      });
      this.addCommand({
        id: "generate-due-dates-summary",
        name: "Generate Due Dates Summary",
        callback: () => __async(this, null, function* () {
          const courseId = yield this.promptForCourseId(
            "Enter course ID to generate due dates summary for"
          );
          if (courseId) {
            yield this.dueDatesParser.createDueDatesSummaryFile(courseId);
          }
        })
      });
      this.addCommand({
        id: "generate-daily-summary",
        name: "Generate Daily Academic Summary",
        callback: () => __async(this, null, function* () {
          const date = yield this.promptForDate(
            "Enter date (YYYY-MM-DD) or leave empty for today"
          );
          yield this.dailyNotesIntegration.createDailySummaryFile(
            date || void 0
          );
        })
      });
      this.addStatusBarItem().setText("Tuckers Tools");
    });
  }
  promptForCourseId(message) {
    return __async(this, null, function* () {
      const courseId = prompt(message + "\n\nExample: PSI-101");
      return courseId ? courseId.trim() : null;
    });
  }
  promptForDate(message) {
    return __async(this, null, function* () {
      const date = prompt(
        message + "\n\nExample: 2025-01-15 or leave empty for today"
      );
      return date ? date.trim() : null;
    });
  }
  generateAssignmentFileContent(assignment, courseName, courseId) {
    return `---
course_id: ${courseId}
assignment_type: ${assignment.type || "Assignment"}
due_date: ${assignment.dueDate}
points: ${assignment.points || ""}
content_type: assignment
created: ${new Date().toISOString()}
status: pending
tags:
  - education
  - ${courseId}
  - assignment
---

# ${assignment.name} - ${courseId}

## Description
${assignment.description}

## Instructions


## Due Date
**Assigned**: ${new Date().toISOString().split("T")[0]}
**Due**: ${assignment.dueDate}

## Submission


## Grading Criteria


## Resources


# Due Dates
| ${assignment.dueDate} | ${assignment.name} | pending |
`;
  }
  onunload() {
    console.log("Unloading Tuckers Tools plugin");
  }
  initializeTemplaterFunctions() {
    return __async(this, null, function* () {
      const templaterPlugin = this.app.plugins.getPlugin("templater-obsidian");
      if (!templaterPlugin) {
        console.log("Templater plugin not found. Course templates will not work properly.");
        return;
      }
      try {
        if (templaterPlugin && templaterPlugin.templater) {
          if (!templaterPlugin.templater.functions) {
            templaterPlugin.templater.functions = {};
          }
          templaterPlugin.templater.functions["new_module"] = (app, tp, year) => __async(this, null, function* () {
            return this.newModuleFunction(app, tp, year);
          });
          if (!templaterPlugin.templater.functions.user) {
            templaterPlugin.templater.functions.user = {};
          }
          templaterPlugin.templater.functions.user["new_module"] = (app, tp, year) => __async(this, null, function* () {
            return this.newModuleFunction(app, tp, year);
          });
          templaterPlugin.templater.functions["new_chapter"] = (tp) => __async(this, null, function* () {
            return this.newChapterFunction(tp);
          });
          templaterPlugin.templater.functions.user["new_chapter"] = (tp) => __async(this, null, function* () {
            return this.newChapterFunction(tp);
          });
          console.log("Tuckers Tools templater functions registered successfully");
        } else {
          console.error("Could not register templater functions - templater object not found");
        }
      } catch (e) {
        console.error("Error registering templater functions:", e);
      }
    });
  }
  newModuleFunction(app, tp, year) {
    return __async(this, null, function* () {
      var _a;
      let moduleNumber = "";
      let weekNumber = "";
      let course = "";
      let courseId = "";
      let discipline = "GEN";
      let dayOfWeek = "";
      try {
        if (tp && tp.system && tp.system.prompt) {
          const tempModuleNumber = yield tp.system.prompt("Module Number (optional)", "");
          moduleNumber = tempModuleNumber ? tempModuleNumber : null;
          const tempWeekNumber = yield tp.system.prompt("Week Number (optional)", "");
          weekNumber = tempWeekNumber ? tempWeekNumber : null;
          course = yield tp.system.suggester(
            () => app.vault.getMarkdownFiles().filter((f) => f.path.includes("Courses")).map((f) => f.basename),
            app.vault.getMarkdownFiles().filter((f) => f.path.includes("Courses"))
          );
          dayOfWeek = yield tp.system.suggester(
            ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
            ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
            "Day of Week"
          );
        } else {
          moduleNumber = null;
          weekNumber = null;
          course = "New Course";
          dayOfWeek = "Monday";
        }
      } catch (e) {
        console.error("Error in new_module prompts:", e);
        moduleNumber = null;
        weekNumber = null;
        course = "New Course";
        dayOfWeek = "Monday";
      }
      courseId = course ? course.split(" - ")[0] || course : "";
      discipline = course ? ((_a = course.split(" - ")[0]) == null ? void 0 : _a.substring(0, 3)) || "GEN" : "GEN";
      return {
        season: "Fall",
        // This would normally be dynamically determined
        moduleNumber,
        weekNumber,
        course,
        courseId,
        discipline,
        dayOfWeek
      };
    });
  }
  newChapterFunction(tp) {
    return __async(this, null, function* () {
      var _a;
      let chapterNumber = "";
      let course = "";
      let courseId = "";
      let discipline = "GEN";
      let text = "";
      try {
        if (tp && tp.system && tp.system.prompt) {
          chapterNumber = (yield tp.system.prompt("Chapter Number", "")) || "";
          course = yield tp.system.suggester(
            () => tp.app.vault.getMarkdownFiles().filter((f) => f.path.includes("Courses")).map((f) => f.basename),
            tp.app.vault.getMarkdownFiles().filter((f) => f.path.includes("Courses"))
          );
          const textOptions = tp.app.vault.getFiles().filter((f) => f.extension === "pdf").map((f) => f.basename);
          text = yield tp.system.suggester(textOptions, textOptions, "Textbook");
        } else {
          chapterNumber = "";
          course = "New Course";
          text = "New Textbook";
        }
      } catch (e) {
        console.error("Error in new_chapter prompts:", e);
        chapterNumber = "";
        course = "New Course";
        text = "New Textbook";
      }
      courseId = course ? course.split(" - ")[0] || course : "";
      discipline = course ? ((_a = course.split(" - ")[0]) == null ? void 0 : _a.substring(0, 3)) || "GEN" : "GEN";
      return {
        chapterNumber,
        course,
        courseId,
        discipline,
        text
      };
    });
  }
  loadSettings() {
    return __async(this, null, function* () {
      this.settings = Object.assign({}, DEFAULT_SETTINGS, yield this.loadData());
    });
  }
  saveSettings() {
    return __async(this, null, function* () {
      yield this.saveData(this.settings);
    });
  }
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsibWFpbi50cyIsICJzZXR0aW5ncy50cyIsICJ1dGlscy50cyIsICJ0ZW1wbGF0ZU1hbmFnZXIudHMiLCAiY291cnNlV2l6YXJkLnRzIiwgImlucHV0TW9kYWwudHMiLCAidm9jYWJ1bGFyeS50cyIsICJkdWVEYXRlcy50cyIsICJkYWlseU5vdGVzLnRzIiwgImFzc2lnbm1lbnRzTW9kYWwudHMiLCAiU3VwcG9ydGluZy9kYXRhdmlldy1mdW5jdGlvbnMudHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbImltcG9ydCB7IFBsdWdpbiwgTm90aWNlLCBURmlsZSB9IGZyb20gXCJvYnNpZGlhblwiXG5pbXBvcnQge1xuICBUdWNrZXJzVG9vbHNTZXR0aW5ncyxcbiAgREVGQVVMVF9TRVRUSU5HUyxcbiAgVHVja2Vyc1Rvb2xzU2V0dGluZ1RhYlxufSBmcm9tIFwiLi9zZXR0aW5nc1wiXG5pbXBvcnQgeyBUZW1wbGF0ZU1hbmFnZXIgfSBmcm9tIFwiLi90ZW1wbGF0ZU1hbmFnZXJcIlxuaW1wb3J0IHsgQ291cnNlQ3JlYXRpb25XaXphcmQgfSBmcm9tIFwiLi9jb3Vyc2VXaXphcmRcIlxuaW1wb3J0IHsgVm9jYWJ1bGFyeUV4dHJhY3RvciB9IGZyb20gXCIuL3ZvY2FidWxhcnlcIlxuaW1wb3J0IHsgRHVlRGF0ZXNQYXJzZXIgfSBmcm9tIFwiLi9kdWVEYXRlc1wiXG5pbXBvcnQgeyBEYWlseU5vdGVzSW50ZWdyYXRpb24gfSBmcm9tIFwiLi9kYWlseU5vdGVzXCJcbmltcG9ydCB7IEFzc2lnbm1lbnRzTW9kYWwgfSBmcm9tIFwiLi9hc3NpZ25tZW50c01vZGFsXCJcblxuaW1wb3J0IHsgcHJvY2Vzc0NvdXJzZVZvY2FidWxhcnksIHByb2Nlc3NEdWVEYXRlcyB9IGZyb20gXCIuL1N1cHBvcnRpbmcvZGF0YXZpZXctZnVuY3Rpb25zXCI7XG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFR1Y2tlcnNUb29sc1BsdWdpbiBleHRlbmRzIFBsdWdpbiB7XG4gIHNldHRpbmdzOiBUdWNrZXJzVG9vbHNTZXR0aW5nc1xuICB0ZW1wbGF0ZU1hbmFnZXI6IFRlbXBsYXRlTWFuYWdlclxuICBjb3Vyc2VXaXphcmQ6IENvdXJzZUNyZWF0aW9uV2l6YXJkXG4gIHZvY2FidWxhcnlFeHRyYWN0b3I6IFZvY2FidWxhcnlFeHRyYWN0b3JcbiAgZHVlRGF0ZXNQYXJzZXI6IER1ZURhdGVzUGFyc2VyXG4gIGRhaWx5Tm90ZXNJbnRlZ3JhdGlvbjogRGFpbHlOb3Rlc0ludGVncmF0aW9uXG4gIGRhdGF2aWV3RnVuY3Rpb25zOiBhbnk7XG5cbiAgYXN5bmMgb25sb2FkKCkge1xuICAgIGNvbnNvbGUubG9nKFwiTG9hZGluZyBUdWNrZXJzIFRvb2xzIHBsdWdpblwiKVxuXG4gICAgLy8gTG9hZCBzZXR0aW5nc1xuICAgIGF3YWl0IHRoaXMubG9hZFNldHRpbmdzKClcblxuICAgIC8vIEluaXRpYWxpemUgY29tcG9uZW50c1xuICAgIHRoaXMudGVtcGxhdGVNYW5hZ2VyID0gbmV3IFRlbXBsYXRlTWFuYWdlcih0aGlzLmFwcCwgdGhpcy5zZXR0aW5ncylcbiAgICB0aGlzLmNvdXJzZVdpemFyZCA9IG5ldyBDb3Vyc2VDcmVhdGlvbldpemFyZCh0aGlzLmFwcCwgdGhpcy5zZXR0aW5ncylcbiAgICB0aGlzLnZvY2FidWxhcnlFeHRyYWN0b3IgPSBuZXcgVm9jYWJ1bGFyeUV4dHJhY3Rvcih0aGlzLmFwcClcbiAgICB0aGlzLmR1ZURhdGVzUGFyc2VyID0gbmV3IER1ZURhdGVzUGFyc2VyKHRoaXMuYXBwKVxuICAgIHRoaXMuZGFpbHlOb3Rlc0ludGVncmF0aW9uID0gbmV3IERhaWx5Tm90ZXNJbnRlZ3JhdGlvbih0aGlzLmFwcClcbiAgICB0aGlzLmRhdGF2aWV3RnVuY3Rpb25zID0geyBwcm9jZXNzQ291cnNlVm9jYWJ1bGFyeSwgcHJvY2Vzc0R1ZURhdGVzIH07XG5cbiAgICAvLyBBZGQgc2V0dGluZ3MgdGFiXG4gICAgdGhpcy5hZGRTZXR0aW5nVGFiKG5ldyBUdWNrZXJzVG9vbHNTZXR0aW5nVGFiKHRoaXMuYXBwLCB0aGlzKSlcblxuICAgIC8vIEluaXRpYWxpemUgdGVtcGxhdGVyIGZ1bmN0aW9ucyBpZiB0ZW1wbGF0ZXIgaXMgYXZhaWxhYmxlXG4gICAgdGhpcy5pbml0aWFsaXplVGVtcGxhdGVyRnVuY3Rpb25zKClcblxuICAgIC8vIEFkZCBjb21tYW5kc1xuICAgIHRoaXMuYWRkQ29tbWFuZCh7XG4gICAgICBpZDogXCJpbnN0YWxsLXRlbXBsYXRlc1wiLFxuICAgICAgbmFtZTogXCJJbnN0YWxsL1VwZGF0ZSBUdWNrZXJzIFRvb2xzIFRlbXBsYXRlc1wiLFxuICAgICAgY2FsbGJhY2s6ICgpID0+IHtcbiAgICAgICAgdGhpcy50ZW1wbGF0ZU1hbmFnZXIuaW5zdGFsbFRlbXBsYXRlcygpXG4gICAgICB9XG4gICAgfSlcblxuICAgIHRoaXMuYWRkQ29tbWFuZCh7XG4gICAgICBpZDogXCJ1cGRhdGUtdGVtcGxhdGVzXCIsXG4gICAgICBuYW1lOiBcIlVwZGF0ZSBUdWNrZXJzIFRvb2xzIFRlbXBsYXRlc1wiLFxuICAgICAgY2FsbGJhY2s6ICgpID0+IHtcbiAgICAgICAgdGhpcy50ZW1wbGF0ZU1hbmFnZXIudXBkYXRlVGVtcGxhdGVzKClcbiAgICAgIH1cbiAgICB9KVxuXG4gICAgLy8gQ291cnNlIGNyZWF0aW9uIGlzIGhhbmRsZWQgYnkgVGVtcGxhdGVyIHRlbXBsYXRlcyAtIG5vIGN1c3RvbSBjb21tYW5kIG5lZWRlZFxuXG4gICAgdGhpcy5hZGRDb21tYW5kKHtcbiAgICAgIGlkOiBcImNyZWF0ZS1tdWx0aXBsZS1hc3NpZ25tZW50c1wiLFxuICAgICAgbmFtZTogXCJDcmVhdGUgTXVsdGlwbGUgQXNzaWdubWVudHMgZm9yIENvdXJzZVwiLFxuICAgICAgY2FsbGJhY2s6IGFzeW5jICgpID0+IHtcbiAgICAgICAgLy8gR2V0IHRoZSBjdXJyZW50IGNvdXJzZSBjb250ZXh0IG9yIHByb21wdCBmb3IgaXRcbiAgICAgICAgY29uc3QgY3VycmVudEZpbGUgPSB0aGlzLmFwcC53b3Jrc3BhY2UuZ2V0QWN0aXZlRmlsZSgpO1xuICAgICAgICBsZXQgY291cnNlSWQgPSBcIlwiO1xuICAgICAgICBsZXQgY291cnNlTmFtZSA9IFwiXCI7XG5cbiAgICAgICAgLy8gVHJ5IHRvIGRldGVybWluZSB0aGUgY291cnNlIGZyb20gdGhlIGN1cnJlbnQgZmlsZVxuICAgICAgICBpZiAoY3VycmVudEZpbGUpIHtcbiAgICAgICAgICBjb25zdCBjYWNoZSA9IHRoaXMuYXBwLm1ldGFkYXRhQ2FjaGUuZ2V0RmlsZUNhY2hlKGN1cnJlbnRGaWxlKTtcbiAgICAgICAgICBpZiAoY2FjaGUgJiYgY2FjaGUuZnJvbnRtYXR0ZXIpIHtcbiAgICAgICAgICAgIGNvdXJzZUlkID0gY2FjaGUuZnJvbnRtYXR0ZXIuY291cnNlX2lkIHx8IFwiXCI7XG4gICAgICAgICAgICBjb3Vyc2VOYW1lID0gY2FjaGUuZnJvbnRtYXR0ZXIuY291cnNlX25hbWUgfHwgY2FjaGUuZnJvbnRtYXR0ZXIudGl0bGUgfHwgY3VycmVudEZpbGUuYmFzZW5hbWU7XG4gICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgLy8gSWYgd2UgY291bGRuJ3QgZGV0ZXJtaW5lIHRoZSBjb3Vyc2UsIHByb21wdCBmb3IgaXRcbiAgICAgICAgaWYgKCFjb3Vyc2VJZCkge1xuICAgICAgICAgIGNvbnN0IHByb21wdGVkQ291cnNlSWQgPSBhd2FpdCB0aGlzLnByb21wdEZvckNvdXJzZUlkKFwiRW50ZXIgY291cnNlIElEIGZvciBhc3NpZ25tZW50c1wiKTtcbiAgICAgICAgICBpZiAoIXByb21wdGVkQ291cnNlSWQpIHJldHVybjtcbiAgICAgICAgICBjb3Vyc2VJZCA9IHByb21wdGVkQ291cnNlSWQ7XG4gICAgICAgICAgY291cnNlTmFtZSA9IGNvdXJzZUlkOyAvLyBGYWxsYmFjayBpZiB3ZSBkb24ndCBoYXZlIGEgYmV0dGVyIG5hbWVcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIFNob3cgdGhlIGFzc2lnbm1lbnRzIG1vZGFsXG4gICAgICAgIG5ldyBBc3NpZ25tZW50c01vZGFsKFxuICAgICAgICAgIHRoaXMuYXBwLFxuICAgICAgICAgIGNvdXJzZU5hbWUsXG4gICAgICAgICAgY291cnNlSWQsXG4gICAgICAgICAgYXN5bmMgKGFzc2lnbm1lbnRzLCBjb3Vyc2VOYW1lLCBjb3Vyc2VJZCkgPT4ge1xuICAgICAgICAgICAgLy8gUHJvY2VzcyB0aGUgYXNzaWdubWVudHMgLSBmb3Igbm93LCB3ZSdsbCBjcmVhdGUgaW5kaXZpZHVhbCBhc3NpZ25tZW50IGZpbGVzXG4gICAgICAgICAgICBmb3IgKGNvbnN0IGFzc2lnbm1lbnQgb2YgYXNzaWdubWVudHMpIHtcbiAgICAgICAgICAgICAgaWYgKGFzc2lnbm1lbnQubmFtZS50cmltKCkgPT09IFwiXCIpIGNvbnRpbnVlOyAvLyBTa2lwIGVtcHR5IGFzc2lnbm1lbnRzXG5cbiAgICAgICAgICAgICAgLy8gQ3JlYXRlIGFuIGFzc2lnbm1lbnQgZmlsZVxuICAgICAgICAgICAgICBjb25zdCBhc3NpZ25tZW50Q29udGVudCA9IHRoaXMuZ2VuZXJhdGVBc3NpZ25tZW50RmlsZUNvbnRlbnQoXG4gICAgICAgICAgICAgICAgYXNzaWdubWVudCxcbiAgICAgICAgICAgICAgICBjb3Vyc2VOYW1lLFxuICAgICAgICAgICAgICAgIGNvdXJzZUlkXG4gICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgIGNvbnN0IGZpbGVOYW1lID0gYCR7Y291cnNlSWR9IC0gJHthc3NpZ25tZW50Lm5hbWUucmVwbGFjZSgvWzw+OlwiL1xcXFx8PypdL2csIFwiX1wiKX0ubWRgO1xuICAgICAgICAgICAgICBjb25zdCBmaWxlUGF0aCA9IGAke2NvdXJzZUlkfS8ke2ZpbGVOYW1lfWA7XG5cbiAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBhd2FpdCB0aGlzLmFwcC52YXVsdC5jcmVhdGUoZmlsZVBhdGgsIGFzc2lnbm1lbnRDb250ZW50KTtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhgQ3JlYXRlZCBhc3NpZ25tZW50IGZpbGU6ICR7ZmlsZVBhdGh9YCk7XG4gICAgICAgICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihgRXJyb3IgY3JlYXRpbmcgYXNzaWdubWVudCBmaWxlICR7ZmlsZVBhdGh9OmAsIGVycm9yKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgKS5vcGVuKCk7XG4gICAgICB9XG4gICAgfSlcblxuICAgIHRoaXMuYWRkQ29tbWFuZCh7XG4gICAgICBpZDogXCJleHRyYWN0LXZvY2FidWxhcnlcIixcbiAgICAgIG5hbWU6IFwiRXh0cmFjdCBDb3Vyc2UgVm9jYWJ1bGFyeVwiLFxuICAgICAgY2FsbGJhY2s6IGFzeW5jICgpID0+IHtcbiAgICAgICAgY29uc3QgY291cnNlSWQgPSBhd2FpdCB0aGlzLnByb21wdEZvckNvdXJzZUlkKFxuICAgICAgICAgIFwiRW50ZXIgY291cnNlIElEIHRvIGV4dHJhY3Qgdm9jYWJ1bGFyeSBmcm9tXCJcbiAgICAgICAgKVxuICAgICAgICBpZiAoY291cnNlSWQpIHtcbiAgICAgICAgICBhd2FpdCB0aGlzLnZvY2FidWxhcnlFeHRyYWN0b3IuY3JlYXRlVm9jYWJ1bGFyeUluZGV4RmlsZShjb3Vyc2VJZClcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0pXG5cbiAgICB0aGlzLmFkZENvbW1hbmQoe1xuICAgICAgaWQ6IFwiZ2VuZXJhdGUtZHVlLWRhdGVzLXN1bW1hcnlcIixcbiAgICAgIG5hbWU6IFwiR2VuZXJhdGUgRHVlIERhdGVzIFN1bW1hcnlcIixcbiAgICAgIGNhbGxiYWNrOiBhc3luYyAoKSA9PiB7XG4gICAgICAgIGNvbnN0IGNvdXJzZUlkID0gYXdhaXQgdGhpcy5wcm9tcHRGb3JDb3Vyc2VJZChcbiAgICAgICAgICBcIkVudGVyIGNvdXJzZSBJRCB0byBnZW5lcmF0ZSBkdWUgZGF0ZXMgc3VtbWFyeSBmb3JcIlxuICAgICAgICApXG4gICAgICAgIGlmIChjb3Vyc2VJZCkge1xuICAgICAgICAgIGF3YWl0IHRoaXMuZHVlRGF0ZXNQYXJzZXIuY3JlYXRlRHVlRGF0ZXNTdW1tYXJ5RmlsZShjb3Vyc2VJZClcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0pXG5cbiAgICB0aGlzLmFkZENvbW1hbmQoe1xuICAgICAgaWQ6IFwiZ2VuZXJhdGUtZGFpbHktc3VtbWFyeVwiLFxuICAgICAgbmFtZTogXCJHZW5lcmF0ZSBEYWlseSBBY2FkZW1pYyBTdW1tYXJ5XCIsXG4gICAgICBjYWxsYmFjazogYXN5bmMgKCkgPT4ge1xuICAgICAgICBjb25zdCBkYXRlID0gYXdhaXQgdGhpcy5wcm9tcHRGb3JEYXRlKFxuICAgICAgICAgIFwiRW50ZXIgZGF0ZSAoWVlZWS1NTS1ERCkgb3IgbGVhdmUgZW1wdHkgZm9yIHRvZGF5XCJcbiAgICAgICAgKVxuICAgICAgICBhd2FpdCB0aGlzLmRhaWx5Tm90ZXNJbnRlZ3JhdGlvbi5jcmVhdGVEYWlseVN1bW1hcnlGaWxlKFxuICAgICAgICAgIGRhdGUgfHwgdW5kZWZpbmVkXG4gICAgICAgIClcbiAgICAgIH1cbiAgICB9KVxuXG4gICAgLy8gQWRkIHN0YXR1cyBiYXIgaXRlbVxuICAgIHRoaXMuYWRkU3RhdHVzQmFySXRlbSgpLnNldFRleHQoXCJUdWNrZXJzIFRvb2xzXCIpXG4gIH1cblxuICBwcml2YXRlIGFzeW5jIHByb21wdEZvckNvdXJzZUlkKG1lc3NhZ2U6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nIHwgbnVsbD4ge1xuICAgIGNvbnN0IGNvdXJzZUlkID0gcHJvbXB0KG1lc3NhZ2UgKyBcIlxcblxcbkV4YW1wbGU6IFBTSS0xMDFcIilcbiAgICByZXR1cm4gY291cnNlSWQgPyBjb3Vyc2VJZC50cmltKCkgOiBudWxsXG4gIH1cblxuICBwcml2YXRlIGFzeW5jIHByb21wdEZvckRhdGUobWVzc2FnZTogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmcgfCBudWxsPiB7XG4gICAgY29uc3QgZGF0ZSA9IHByb21wdChcbiAgICAgIG1lc3NhZ2UgKyBcIlxcblxcbkV4YW1wbGU6IDIwMjUtMDEtMTUgb3IgbGVhdmUgZW1wdHkgZm9yIHRvZGF5XCJcbiAgICApXG4gICAgcmV0dXJuIGRhdGUgPyBkYXRlLnRyaW0oKSA6IG51bGxcbiAgfVxuXG4gIGdlbmVyYXRlQXNzaWdubWVudEZpbGVDb250ZW50KGFzc2lnbm1lbnQ6IGFueSwgY291cnNlTmFtZTogc3RyaW5nLCBjb3Vyc2VJZDogc3RyaW5nKTogc3RyaW5nIHtcbiAgICAvLyBDcmVhdGUgdGhlIGFzc2lnbm1lbnQgZmlsZSBjb250ZW50IHVzaW5nIHRoZSBhc3NpZ25tZW50IHRlbXBsYXRlIHN0cnVjdHVyZVxuICAgIHJldHVybiBgLS0tXG5jb3Vyc2VfaWQ6ICR7Y291cnNlSWR9XG5hc3NpZ25tZW50X3R5cGU6ICR7YXNzaWdubWVudC50eXBlIHx8IFwiQXNzaWdubWVudFwifVxuZHVlX2RhdGU6ICR7YXNzaWdubWVudC5kdWVEYXRlfVxucG9pbnRzOiAke2Fzc2lnbm1lbnQucG9pbnRzIHx8IFwiXCJ9XG5jb250ZW50X3R5cGU6IGFzc2lnbm1lbnRcbmNyZWF0ZWQ6ICR7bmV3IERhdGUoKS50b0lTT1N0cmluZygpfVxuc3RhdHVzOiBwZW5kaW5nXG50YWdzOlxuICAtIGVkdWNhdGlvblxuICAtICR7Y291cnNlSWR9XG4gIC0gYXNzaWdubWVudFxuLS0tXG5cbiMgJHthc3NpZ25tZW50Lm5hbWV9IC0gJHtjb3Vyc2VJZH1cblxuIyMgRGVzY3JpcHRpb25cbiR7YXNzaWdubWVudC5kZXNjcmlwdGlvbn1cblxuIyMgSW5zdHJ1Y3Rpb25zXG5cblxuIyMgRHVlIERhdGVcbioqQXNzaWduZWQqKjogJHtuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc3BsaXQoJ1QnKVswXX1cbioqRHVlKio6ICR7YXNzaWdubWVudC5kdWVEYXRlfVxuXG4jIyBTdWJtaXNzaW9uXG5cblxuIyMgR3JhZGluZyBDcml0ZXJpYVxuXG5cbiMjIFJlc291cmNlc1xuXG5cbiMgRHVlIERhdGVzXG58ICR7YXNzaWdubWVudC5kdWVEYXRlfSB8ICR7YXNzaWdubWVudC5uYW1lfSB8IHBlbmRpbmcgfFxuYDtcbiAgfVxuXG4gIG9udW5sb2FkKCkge1xuICAgIGNvbnNvbGUubG9nKFwiVW5sb2FkaW5nIFR1Y2tlcnMgVG9vbHMgcGx1Z2luXCIpXG4gIH1cblxuICBhc3luYyBpbml0aWFsaXplVGVtcGxhdGVyRnVuY3Rpb25zKCkge1xuICAgIC8vIENoZWNrIGlmIFRlbXBsYXRlciBwbHVnaW4gaXMgYXZhaWxhYmxlXG4gICAgY29uc3QgdGVtcGxhdGVyUGx1Z2luID0gKHRoaXMuYXBwIGFzIGFueSkucGx1Z2lucy5nZXRQbHVnaW4oXCJ0ZW1wbGF0ZXItb2JzaWRpYW5cIik7XG4gICAgaWYgKCF0ZW1wbGF0ZXJQbHVnaW4pIHtcbiAgICAgIGNvbnNvbGUubG9nKFwiVGVtcGxhdGVyIHBsdWdpbiBub3QgZm91bmQuIENvdXJzZSB0ZW1wbGF0ZXMgd2lsbCBub3Qgd29yayBwcm9wZXJseS5cIik7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgLy8gUmVnaXN0ZXIgdXNlciBmdW5jdGlvbnMgd2l0aCBUZW1wbGF0ZXJcbiAgICB0cnkge1xuICAgICAgLy8gVHJ5IHRvIGFkZCBmdW5jdGlvbnMgdmlhIGRpZmZlcmVudCBtZXRob2RzIGRlcGVuZGluZyBvbiB0aGUgVGVtcGxhdGVyIHZlcnNpb25cbiAgICAgIGlmICh0ZW1wbGF0ZXJQbHVnaW4gJiYgdGVtcGxhdGVyUGx1Z2luLnRlbXBsYXRlcikge1xuICAgICAgICAvLyBDcmVhdGUgYSB1c2VyIGZ1bmN0aW9uIG1hbmFnZXIgb2JqZWN0IGlmIGl0IGRvZXNuJ3QgZXhpc3RcbiAgICAgICAgaWYgKCF0ZW1wbGF0ZXJQbHVnaW4udGVtcGxhdGVyLmZ1bmN0aW9ucykge1xuICAgICAgICAgIHRlbXBsYXRlclBsdWdpbi50ZW1wbGF0ZXIuZnVuY3Rpb25zID0ge307XG4gICAgICAgIH1cblxuICAgICAgICAvLyBBZGQgb3VyIGN1c3RvbSBmdW5jdGlvbnMgdG8gYm90aCB0aGUgdGVtcGxhdGVyIGZ1bmN0aW9ucyBvYmplY3QgYW5kIHRwLnVzZXIgbmFtZXNwYWNlXG4gICAgICAgIHRlbXBsYXRlclBsdWdpbi50ZW1wbGF0ZXIuZnVuY3Rpb25zW1wibmV3X21vZHVsZVwiXSA9IGFzeW5jIChhcHA6IGFueSwgdHA6IGFueSwgeWVhcjogYW55KSA9PiB7XG4gICAgICAgICAgcmV0dXJuIHRoaXMubmV3TW9kdWxlRnVuY3Rpb24oYXBwLCB0cCwgeWVhcik7XG4gICAgICAgIH07XG4gICAgICAgIFxuICAgICAgICAvLyBBbHNvIGFkZCB0byB0cC51c2VyIG5hbWVzcGFjZSBmb3IgZGlyZWN0IGFjY2Vzc1xuICAgICAgICBpZiAoIXRlbXBsYXRlclBsdWdpbi50ZW1wbGF0ZXIuZnVuY3Rpb25zLnVzZXIpIHtcbiAgICAgICAgICB0ZW1wbGF0ZXJQbHVnaW4udGVtcGxhdGVyLmZ1bmN0aW9ucy51c2VyID0ge307XG4gICAgICAgIH1cbiAgICAgICAgdGVtcGxhdGVyUGx1Z2luLnRlbXBsYXRlci5mdW5jdGlvbnMudXNlcltcIm5ld19tb2R1bGVcIl0gPSBhc3luYyAoYXBwOiBhbnksIHRwOiBhbnksIHllYXI6IGFueSkgPT4ge1xuICAgICAgICAgIHJldHVybiB0aGlzLm5ld01vZHVsZUZ1bmN0aW9uKGFwcCwgdHAsIHllYXIpO1xuICAgICAgICB9O1xuXG4gICAgICAgIHRlbXBsYXRlclBsdWdpbi50ZW1wbGF0ZXIuZnVuY3Rpb25zW1wibmV3X2NoYXB0ZXJcIl0gPSBhc3luYyAodHA6IGFueSkgPT4ge1xuICAgICAgICAgIHJldHVybiB0aGlzLm5ld0NoYXB0ZXJGdW5jdGlvbih0cCk7XG4gICAgICAgIH07XG4gICAgICAgIFxuICAgICAgICAvLyBBbHNvIGFkZCBuZXdfY2hhcHRlciB0byB0cC51c2VyIG5hbWVzcGFjZVxuICAgICAgICB0ZW1wbGF0ZXJQbHVnaW4udGVtcGxhdGVyLmZ1bmN0aW9ucy51c2VyW1wibmV3X2NoYXB0ZXJcIl0gPSBhc3luYyAodHA6IGFueSkgPT4ge1xuICAgICAgICAgIHJldHVybiB0aGlzLm5ld0NoYXB0ZXJGdW5jdGlvbih0cCk7XG4gICAgICAgIH07XG5cbiAgICAgICAgY29uc29sZS5sb2coXCJUdWNrZXJzIFRvb2xzIHRlbXBsYXRlciBmdW5jdGlvbnMgcmVnaXN0ZXJlZCBzdWNjZXNzZnVsbHlcIik7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjb25zb2xlLmVycm9yKFwiQ291bGQgbm90IHJlZ2lzdGVyIHRlbXBsYXRlciBmdW5jdGlvbnMgLSB0ZW1wbGF0ZXIgb2JqZWN0IG5vdCBmb3VuZFwiKTtcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgcmVnaXN0ZXJpbmcgdGVtcGxhdGVyIGZ1bmN0aW9uczpcIiwgZSk7XG4gICAgfVxuICB9XG5cbiAgYXN5bmMgbmV3TW9kdWxlRnVuY3Rpb24oYXBwOiBhbnksIHRwOiBhbnksIHllYXI6IHN0cmluZykge1xuICAgIC8vIFByb21wdCB1c2VyIGZvciBtb2R1bGUgZGV0YWlsc1xuICAgIGxldCBtb2R1bGVOdW1iZXI6IHN0cmluZyB8IG51bGwgPSBcIlwiO1xuICAgIGxldCB3ZWVrTnVtYmVyOiBzdHJpbmcgfCBudWxsID0gXCJcIjtcbiAgICBsZXQgY291cnNlID0gXCJcIjtcbiAgICBsZXQgY291cnNlSWQgPSBcIlwiO1xuICAgIGxldCBkaXNjaXBsaW5lID0gXCJHRU5cIjtcbiAgICBsZXQgZGF5T2ZXZWVrID0gXCJcIjtcblxuICAgIHRyeSB7XG4gICAgICAvLyBBdHRlbXB0IHByb21wdHMgd2l0aCBmYWxsYmFja1xuICAgICAgaWYgKHRwICYmIHRwLnN5c3RlbSAmJiB0cC5zeXN0ZW0ucHJvbXB0KSB7XG4gICAgICAgIGNvbnN0IHRlbXBNb2R1bGVOdW1iZXIgPSBhd2FpdCB0cC5zeXN0ZW0ucHJvbXB0KFwiTW9kdWxlIE51bWJlciAob3B0aW9uYWwpXCIsIFwiXCIpO1xuICAgICAgICBtb2R1bGVOdW1iZXIgPSB0ZW1wTW9kdWxlTnVtYmVyID8gdGVtcE1vZHVsZU51bWJlciA6IG51bGw7XG4gICAgICAgIFxuICAgICAgICBjb25zdCB0ZW1wV2Vla051bWJlciA9IGF3YWl0IHRwLnN5c3RlbS5wcm9tcHQoXCJXZWVrIE51bWJlciAob3B0aW9uYWwpXCIsIFwiXCIpO1xuICAgICAgICB3ZWVrTnVtYmVyID0gdGVtcFdlZWtOdW1iZXIgPyB0ZW1wV2Vla051bWJlciA6IG51bGw7XG4gICAgICAgIFxuICAgICAgICBjb3Vyc2UgPSBhd2FpdCB0cC5zeXN0ZW0uc3VnZ2VzdGVyKFxuICAgICAgICAgICgpID0+IGFwcC52YXVsdC5nZXRNYXJrZG93bkZpbGVzKCkuZmlsdGVyKChmOiBhbnkpID0+IGYucGF0aC5pbmNsdWRlcyhcIkNvdXJzZXNcIikpLm1hcCgoZjogYW55KSA9PiBmLmJhc2VuYW1lKSxcbiAgICAgICAgICBhcHAudmF1bHQuZ2V0TWFya2Rvd25GaWxlcygpLmZpbHRlcigoZjogYW55KSA9PiBmLnBhdGguaW5jbHVkZXMoXCJDb3Vyc2VzXCIpKVxuICAgICAgICApO1xuICAgICAgICBcbiAgICAgICAgZGF5T2ZXZWVrID0gYXdhaXQgdHAuc3lzdGVtLnN1Z2dlc3RlcihcbiAgICAgICAgICBbXCJNb25kYXlcIiwgXCJUdWVzZGF5XCIsIFwiV2VkbmVzZGF5XCIsIFwiVGh1cnNkYXlcIiwgXCJGcmlkYXlcIiwgXCJTYXR1cmRheVwiLCBcIlN1bmRheVwiXSxcbiAgICAgICAgICBbXCJNb25kYXlcIiwgXCJUdWVzZGF5XCIsIFwiV2VkbmVzZGF5XCIsIFwiVGh1cnNkYXlcIiwgXCJGcmlkYXlcIiwgXCJTYXR1cmRheVwiLCBcIlN1bmRheVwiXSxcbiAgICAgICAgICBcIkRheSBvZiBXZWVrXCJcbiAgICAgICAgKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIC8vIEZhbGxiYWNrIHZhbHVlc1xuICAgICAgICBtb2R1bGVOdW1iZXIgPSBudWxsO1xuICAgICAgICB3ZWVrTnVtYmVyID0gbnVsbDtcbiAgICAgICAgY291cnNlID0gXCJOZXcgQ291cnNlXCI7XG4gICAgICAgIGRheU9mV2VlayA9IFwiTW9uZGF5XCI7XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGluIG5ld19tb2R1bGUgcHJvbXB0czpcIiwgZSk7XG4gICAgICAvLyBEZWZhdWx0IHZhbHVlcyBvbiBlcnJvclxuICAgICAgbW9kdWxlTnVtYmVyID0gbnVsbDtcbiAgICAgIHdlZWtOdW1iZXIgPSBudWxsO1xuICAgICAgY291cnNlID0gXCJOZXcgQ291cnNlXCI7XG4gICAgICBkYXlPZldlZWsgPSBcIk1vbmRheVwiO1xuICAgIH1cblxuICAgIC8vIENhbGN1bGF0ZSBkZXJpdmVkIHZhbHVlc1xuICAgIGNvdXJzZUlkID0gY291cnNlID8gY291cnNlLnNwbGl0KFwiIC0gXCIpWzBdIHx8IGNvdXJzZSA6IFwiXCI7XG4gICAgZGlzY2lwbGluZSA9IGNvdXJzZSA/IChjb3Vyc2Uuc3BsaXQoXCIgLSBcIilbMF0/LnN1YnN0cmluZygwLCAzKSB8fCBcIkdFTlwiKSA6IFwiR0VOXCI7XG5cbiAgICByZXR1cm4ge1xuICAgICAgc2Vhc29uOiBcIkZhbGxcIiwgLy8gVGhpcyB3b3VsZCBub3JtYWxseSBiZSBkeW5hbWljYWxseSBkZXRlcm1pbmVkXG4gICAgICBtb2R1bGVOdW1iZXI6IG1vZHVsZU51bWJlcixcbiAgICAgIHdlZWtOdW1iZXI6IHdlZWtOdW1iZXIsXG4gICAgICBjb3Vyc2UsXG4gICAgICBjb3Vyc2VJZCxcbiAgICAgIGRpc2NpcGxpbmUsXG4gICAgICBkYXlPZldlZWtcbiAgICB9O1xuICB9XG5cbiAgYXN5bmMgbmV3Q2hhcHRlckZ1bmN0aW9uKHRwOiBhbnkpIHtcbiAgICBsZXQgY2hhcHRlck51bWJlciA9IFwiXCI7XG4gICAgbGV0IGNvdXJzZSA9IFwiXCI7XG4gICAgbGV0IGNvdXJzZUlkID0gXCJcIjtcbiAgICBsZXQgZGlzY2lwbGluZSA9IFwiR0VOXCI7XG4gICAgbGV0IHRleHQgPSBcIlwiO1xuXG4gICAgdHJ5IHtcbiAgICAgIGlmICh0cCAmJiB0cC5zeXN0ZW0gJiYgdHAuc3lzdGVtLnByb21wdCkge1xuICAgICAgICBjaGFwdGVyTnVtYmVyID0gYXdhaXQgdHAuc3lzdGVtLnByb21wdChcIkNoYXB0ZXIgTnVtYmVyXCIsIFwiXCIpIHx8IFwiXCI7XG4gICAgICAgIGNvdXJzZSA9IGF3YWl0IHRwLnN5c3RlbS5zdWdnZXN0ZXIoXG4gICAgICAgICAgKCkgPT4gdHAuYXBwLnZhdWx0LmdldE1hcmtkb3duRmlsZXMoKS5maWx0ZXIoKGY6IGFueSkgPT4gZi5wYXRoLmluY2x1ZGVzKFwiQ291cnNlc1wiKSkubWFwKChmOiBhbnkpID0+IGYuYmFzZW5hbWUpLFxuICAgICAgICAgIHRwLmFwcC52YXVsdC5nZXRNYXJrZG93bkZpbGVzKCkuZmlsdGVyKChmOiBhbnkpID0+IGYucGF0aC5pbmNsdWRlcyhcIkNvdXJzZXNcIikpXG4gICAgICAgICk7XG4gICAgICAgIGNvbnN0IHRleHRPcHRpb25zID0gdHAuYXBwLnZhdWx0LmdldEZpbGVzKCkuZmlsdGVyKChmOiBhbnkpID0+IGYuZXh0ZW5zaW9uID09PSBcInBkZlwiKS5tYXAoKGY6IGFueSkgPT4gZi5iYXNlbmFtZSk7XG4gICAgICAgIHRleHQgPSBhd2FpdCB0cC5zeXN0ZW0uc3VnZ2VzdGVyKHRleHRPcHRpb25zLCB0ZXh0T3B0aW9ucywgXCJUZXh0Ym9va1wiKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIC8vIEZhbGxiYWNrIHZhbHVlc1xuICAgICAgICBjaGFwdGVyTnVtYmVyID0gXCJcIjtcbiAgICAgICAgY291cnNlID0gXCJOZXcgQ291cnNlXCI7XG4gICAgICAgIHRleHQgPSBcIk5ldyBUZXh0Ym9va1wiO1xuICAgICAgfVxuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBpbiBuZXdfY2hhcHRlciBwcm9tcHRzOlwiLCBlKTtcbiAgICAgIC8vIERlZmF1bHQgdmFsdWVzIG9uIGVycm9yXG4gICAgICBjaGFwdGVyTnVtYmVyID0gXCJcIjtcbiAgICAgIGNvdXJzZSA9IFwiTmV3IENvdXJzZVwiO1xuICAgICAgdGV4dCA9IFwiTmV3IFRleHRib29rXCI7XG4gICAgfVxuXG4gICAgLy8gQ2FsY3VsYXRlIGRlcml2ZWQgdmFsdWVzXG4gICAgY291cnNlSWQgPSBjb3Vyc2UgPyBjb3Vyc2Uuc3BsaXQoXCIgLSBcIilbMF0gfHwgY291cnNlIDogXCJcIjtcbiAgICBkaXNjaXBsaW5lID0gY291cnNlID8gKGNvdXJzZS5zcGxpdChcIiAtIFwiKVswXT8uc3Vic3RyaW5nKDAsIDMpIHx8IFwiR0VOXCIpIDogXCJHRU5cIjtcblxuICAgIHJldHVybiB7XG4gICAgICBjaGFwdGVyTnVtYmVyLFxuICAgICAgY291cnNlLFxuICAgICAgY291cnNlSWQsXG4gICAgICBkaXNjaXBsaW5lLFxuICAgICAgdGV4dFxuICAgIH07XG4gIH1cblxuICBhc3luYyBsb2FkU2V0dGluZ3MoKSB7XG4gICAgdGhpcy5zZXR0aW5ncyA9IE9iamVjdC5hc3NpZ24oe30sIERFRkFVTFRfU0VUVElOR1MsIGF3YWl0IHRoaXMubG9hZERhdGEoKSlcbiAgfVxuXG4gIGFzeW5jIHNhdmVTZXR0aW5ncygpIHtcbiAgICBhd2FpdCB0aGlzLnNhdmVEYXRhKHRoaXMuc2V0dGluZ3MpXG4gIH1cbn1cbiIsICJpbXBvcnQgeyBBcHAsIFBsdWdpblNldHRpbmdUYWIsIFNldHRpbmcgfSBmcm9tICdvYnNpZGlhbic7XG5pbXBvcnQgVHVja2Vyc1Rvb2xzUGx1Z2luIGZyb20gJy4vbWFpbic7XG5pbXBvcnQgeyB2YWxpZGF0ZURhdGUgfSBmcm9tICcuL3V0aWxzJztcblxuZXhwb3J0IGludGVyZmFjZSBUdWNrZXJzVG9vbHNTZXR0aW5ncyB7XG4gIGJhc2VEaXJlY3Rvcnk6IHN0cmluZztcbiAgc2VtZXN0ZXJTdGFydERhdGU6IHN0cmluZztcbiAgc2VtZXN0ZXJFbmREYXRlOiBzdHJpbmc7XG4gIHNjaG9vbE5hbWU6IHN0cmluZztcbiAgc2Nob29sQWJicmV2aWF0aW9uOiBzdHJpbmc7XG4gIHRlbXBsYXRlRm9sZGVyOiBzdHJpbmc7XG4gIHVzZUVuaGFuY2VkTWV0YWRhdGE6IGJvb2xlYW47XG4gIGRhdGF2aWV3SnNQYXRoOiBzdHJpbmc7XG59XG5cbmV4cG9ydCBjb25zdCBERUZBVUxUX1NFVFRJTkdTOiBUdWNrZXJzVG9vbHNTZXR0aW5ncyA9IHtcbiAgYmFzZURpcmVjdG9yeTogJy8nLFxuICBzZW1lc3RlclN0YXJ0RGF0ZTogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNwbGl0KCdUJylbMF0sXG4gIHNlbWVzdGVyRW5kRGF0ZTogbmV3IERhdGUobmV3IERhdGUoKS5zZXRNb250aChuZXcgRGF0ZSgpLmdldE1vbnRoKCkgKyA0KSkudG9JU09TdHJpbmcoKS5zcGxpdCgnVCcpWzBdLFxuICBzY2hvb2xOYW1lOiAnVW5pdmVyc2l0eScsXG4gIHNjaG9vbEFiYnJldmlhdGlvbjogJ1UnLFxuICB0ZW1wbGF0ZUZvbGRlcjogJ1R1Y2tlcnMgVG9vbHMnLFxuICB1c2VFbmhhbmNlZE1ldGFkYXRhOiBmYWxzZSxcbiAgZGF0YXZpZXdKc1BhdGg6ICcvU3VwcG9ydGluZy9kYXRhdmlldy1mdW5jdGlvbnMnXG59XG5cbmV4cG9ydCBjbGFzcyBUdWNrZXJzVG9vbHNTZXR0aW5nVGFiIGV4dGVuZHMgUGx1Z2luU2V0dGluZ1RhYiB7XG4gIHBsdWdpbjogVHVja2Vyc1Rvb2xzUGx1Z2luO1xuXG4gIGNvbnN0cnVjdG9yKGFwcDogQXBwLCBwbHVnaW46IFR1Y2tlcnNUb29sc1BsdWdpbikge1xuICAgIHN1cGVyKGFwcCwgcGx1Z2luKTtcbiAgICB0aGlzLnBsdWdpbiA9IHBsdWdpbjtcbiAgfVxuXG4gIGRpc3BsYXkoKTogdm9pZCB7XG4gICAgY29uc3QgeyBjb250YWluZXJFbCB9ID0gdGhpcztcblxuICAgIGNvbnRhaW5lckVsLmVtcHR5KCk7XG5cbiAgICBjb250YWluZXJFbC5jcmVhdGVFbCgnaDInLCB7IHRleHQ6ICdUdWNrZXJzIFRvb2xzIFNldHRpbmdzJyB9KTtcblxuICAgIG5ldyBTZXR0aW5nKGNvbnRhaW5lckVsKVxuICAgICAgLnNldE5hbWUoJ0Jhc2UgRGlyZWN0b3J5JylcbiAgICAgIC5zZXREZXNjKCdSb290IGRpcmVjdG9yeSBmb3IgY291cnNlIGNvbnRlbnQgb3JnYW5pemF0aW9uJylcbiAgICAgIC5hZGRUZXh0KHRleHQgPT4gdGV4dFxuICAgICAgICAuc2V0UGxhY2Vob2xkZXIoJy8nKVxuICAgICAgICAuc2V0VmFsdWUodGhpcy5wbHVnaW4uc2V0dGluZ3MuYmFzZURpcmVjdG9yeSlcbiAgICAgICAgLm9uQ2hhbmdlKGFzeW5jICh2YWx1ZSkgPT4ge1xuICAgICAgICAgIHRoaXMucGx1Z2luLnNldHRpbmdzLmJhc2VEaXJlY3RvcnkgPSB2YWx1ZTtcbiAgICAgICAgICBhd2FpdCB0aGlzLnBsdWdpbi5zYXZlU2V0dGluZ3MoKTtcbiAgICAgICAgfSkpO1xuXG4gICAgY29uc3Qgc3RhcnREYXRlU2V0dGluZyA9IG5ldyBTZXR0aW5nKGNvbnRhaW5lckVsKVxuICAgICAgLnNldE5hbWUoJ1NlbWVzdGVyIFN0YXJ0IERhdGUnKVxuICAgICAgLnNldERlc2MoJ1N0YXJ0IGRhdGUgZm9yIHRoZSBjdXJyZW50IHNlbWVzdGVyJylcbiAgICAgIC5hZGRUZXh0KHRleHQgPT4gdGV4dFxuICAgICAgICAuc2V0UGxhY2Vob2xkZXIoJ1lZWVktTU0tREQnKVxuICAgICAgICAuc2V0VmFsdWUodGhpcy5wbHVnaW4uc2V0dGluZ3Muc2VtZXN0ZXJTdGFydERhdGUpXG4gICAgICAgIC5vbkNoYW5nZShhc3luYyAodmFsdWUpID0+IHtcbiAgICAgICAgICBpZiAodmFsdWUgJiYgIXZhbGlkYXRlRGF0ZSh2YWx1ZSkpIHtcbiAgICAgICAgICAgIHN0YXJ0RGF0ZVNldHRpbmcuc2V0RGVzYygnU3RhcnQgZGF0ZSBmb3IgdGhlIGN1cnJlbnQgc2VtZXN0ZXIgKEludmFsaWQgZGF0ZSBmb3JtYXQpJyk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHN0YXJ0RGF0ZVNldHRpbmcuc2V0RGVzYygnU3RhcnQgZGF0ZSBmb3IgdGhlIGN1cnJlbnQgc2VtZXN0ZXInKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgdGhpcy5wbHVnaW4uc2V0dGluZ3Muc2VtZXN0ZXJTdGFydERhdGUgPSB2YWx1ZTtcbiAgICAgICAgICBhd2FpdCB0aGlzLnBsdWdpbi5zYXZlU2V0dGluZ3MoKTtcbiAgICAgICAgfSkpO1xuXG4gICAgY29uc3QgZW5kRGF0ZVNldHRpbmcgPSBuZXcgU2V0dGluZyhjb250YWluZXJFbClcbiAgICAgIC5zZXROYW1lKCdTZW1lc3RlciBFbmQgRGF0ZScpXG4gICAgICAuc2V0RGVzYygnRW5kIGRhdGUgZm9yIHRoZSBjdXJyZW50IHNlbWVzdGVyJylcbiAgICAgIC5hZGRUZXh0KHRleHQgPT4gdGV4dFxuICAgICAgICAuc2V0UGxhY2Vob2xkZXIoJ1lZWVktTU0tREQnKVxuICAgICAgICAuc2V0VmFsdWUodGhpcy5wbHVnaW4uc2V0dGluZ3Muc2VtZXN0ZXJFbmREYXRlKVxuICAgICAgICAub25DaGFuZ2UoYXN5bmMgKHZhbHVlKSA9PiB7XG4gICAgICAgICAgaWYgKHZhbHVlICYmICF2YWxpZGF0ZURhdGUodmFsdWUpKSB7XG4gICAgICAgICAgICBlbmREYXRlU2V0dGluZy5zZXREZXNjKCdFbmQgZGF0ZSBmb3IgdGhlIGN1cnJlbnQgc2VtZXN0ZXIgKEludmFsaWQgZGF0ZSBmb3JtYXQpJyk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGVuZERhdGVTZXR0aW5nLnNldERlc2MoJ0VuZCBkYXRlIGZvciB0aGUgY3VycmVudCBzZW1lc3RlcicpO1xuICAgICAgICAgIH1cbiAgICAgICAgICB0aGlzLnBsdWdpbi5zZXR0aW5ncy5zZW1lc3RlckVuZERhdGUgPSB2YWx1ZTtcbiAgICAgICAgICBhd2FpdCB0aGlzLnBsdWdpbi5zYXZlU2V0dGluZ3MoKTtcbiAgICAgICAgfSkpO1xuXG4gICAgbmV3IFNldHRpbmcoY29udGFpbmVyRWwpXG4gICAgICAuc2V0TmFtZSgnU2Nob29sIE5hbWUnKVxuICAgICAgLnNldERlc2MoJ05hbWUgb2YgeW91ciBpbnN0aXR1dGlvbicpXG4gICAgICAuYWRkVGV4dCh0ZXh0ID0+IHRleHRcbiAgICAgICAgLnNldFBsYWNlaG9sZGVyKCdVbml2ZXJzaXR5JylcbiAgICAgICAgLnNldFZhbHVlKHRoaXMucGx1Z2luLnNldHRpbmdzLnNjaG9vbE5hbWUpXG4gICAgICAgIC5vbkNoYW5nZShhc3luYyAodmFsdWUpID0+IHtcbiAgICAgICAgICB0aGlzLnBsdWdpbi5zZXR0aW5ncy5zY2hvb2xOYW1lID0gdmFsdWU7XG4gICAgICAgICAgYXdhaXQgdGhpcy5wbHVnaW4uc2F2ZVNldHRpbmdzKCk7XG4gICAgICAgIH0pKTtcblxuICAgIG5ldyBTZXR0aW5nKGNvbnRhaW5lckVsKVxuICAgICAgLnNldE5hbWUoJ1NjaG9vbCBBYmJyZXZpYXRpb24nKVxuICAgICAgLnNldERlc2MoJ0FiYnJldmlhdGlvbiBmb3IgeW91ciBpbnN0aXR1dGlvbicpXG4gICAgICAuYWRkVGV4dCh0ZXh0ID0+IHRleHRcbiAgICAgICAgLnNldFBsYWNlaG9sZGVyKCdVJylcbiAgICAgICAgLnNldFZhbHVlKHRoaXMucGx1Z2luLnNldHRpbmdzLnNjaG9vbEFiYnJldmlhdGlvbilcbiAgICAgICAgLm9uQ2hhbmdlKGFzeW5jICh2YWx1ZSkgPT4ge1xuICAgICAgICAgIHRoaXMucGx1Z2luLnNldHRpbmdzLnNjaG9vbEFiYnJldmlhdGlvbiA9IHZhbHVlO1xuICAgICAgICAgIGF3YWl0IHRoaXMucGx1Z2luLnNhdmVTZXR0aW5ncygpO1xuICAgICAgICB9KSk7XG5cbiAgICBuZXcgU2V0dGluZyhjb250YWluZXJFbClcbiAgICAgIC5zZXROYW1lKCdUZW1wbGF0ZSBGb2xkZXInKVxuICAgICAgLnNldERlc2MoJ1N1YmZvbGRlciB3aXRoaW4geW91ciBUZW1wbGF0ZXIgdGVtcGxhdGUgZm9sZGVyIGZvciBUdWNrZXJzIFRvb2xzIHRlbXBsYXRlcycpXG4gICAgICAuYWRkVGV4dCh0ZXh0ID0+IHRleHRcbiAgICAgICAgLnNldFBsYWNlaG9sZGVyKCdUdWNrZXJzIFRvb2xzJylcbiAgICAgICAgLnNldFZhbHVlKHRoaXMucGx1Z2luLnNldHRpbmdzLnRlbXBsYXRlRm9sZGVyKVxuICAgICAgICAub25DaGFuZ2UoYXN5bmMgKHZhbHVlKSA9PiB7XG4gICAgICAgICAgdGhpcy5wbHVnaW4uc2V0dGluZ3MudGVtcGxhdGVGb2xkZXIgPSB2YWx1ZTtcbiAgICAgICAgICBhd2FpdCB0aGlzLnBsdWdpbi5zYXZlU2V0dGluZ3MoKTtcbiAgICAgICAgfSkpO1xuXG4gICAgbmV3IFNldHRpbmcoY29udGFpbmVyRWwpXG4gICAgICAuc2V0TmFtZSgnVXNlIEVuaGFuY2VkIE1ldGFkYXRhJylcbiAgICAgIC5zZXREZXNjKCdFbmFibGUgZW5oYW5jZWQgbWV0YWRhdGEgZmllbGRzIGZvciBuZXcgbm90ZXMgKGV4aXN0aW5nIG5vdGVzIHJlbWFpbiB1bmNoYW5nZWQpJylcbiAgICAgIC5hZGRUb2dnbGUodG9nZ2xlID0+IHRvZ2dsZVxuICAgICAgICAuc2V0VmFsdWUodGhpcy5wbHVnaW4uc2V0dGluZ3MudXNlRW5oYW5jZWRNZXRhZGF0YSlcbiAgICAgICAgLm9uQ2hhbmdlKGFzeW5jICh2YWx1ZSkgPT4ge1xuICAgICAgICAgIHRoaXMucGx1Z2luLnNldHRpbmdzLnVzZUVuaGFuY2VkTWV0YWRhdGEgPSB2YWx1ZTtcbiAgICAgICAgICBhd2FpdCB0aGlzLnBsdWdpbi5zYXZlU2V0dGluZ3MoKTtcbiAgICAgICAgfSkpO1xuXG4gICAgbmV3IFNldHRpbmcoY29udGFpbmVyRWwpXG4gICAgICAuc2V0TmFtZSgnRGF0YXZpZXcgRnVuY3Rpb25zIFBhdGgnKVxuICAgICAgLnNldERlc2MoJ1BhdGggdG8gdGhlIGRhdGF2aWV3IGZ1bmN0aW9ucyBmaWxlICh3aXRob3V0IGV4dGVuc2lvbiknKVxuICAgICAgLmFkZFRleHQodGV4dCA9PiB0ZXh0XG4gICAgICAgIC5zZXRQbGFjZWhvbGRlcignL1N1cHBvcnRpbmcvZGF0YXZpZXctZnVuY3Rpb25zJylcbiAgICAgICAgLnNldFZhbHVlKHRoaXMucGx1Z2luLnNldHRpbmdzLmRhdGF2aWV3SnNQYXRoKVxuICAgICAgICAub25DaGFuZ2UoYXN5bmMgKHZhbHVlKSA9PiB7XG4gICAgICAgICAgdGhpcy5wbHVnaW4uc2V0dGluZ3MuZGF0YXZpZXdKc1BhdGggPSB2YWx1ZTtcbiAgICAgICAgICBhd2FpdCB0aGlzLnBsdWdpbi5zYXZlU2V0dGluZ3MoKTtcbiAgICAgICAgfSkpO1xuICB9XG59IiwgIi8vIFV0aWxpdHkgZnVuY3Rpb25zIGZvciBUdWNrZXJzIFRvb2xzIHBsdWdpblxuXG5leHBvcnQgZnVuY3Rpb24gZm9ybWF0RGF0ZShkYXRlOiBEYXRlKTogc3RyaW5nIHtcbiAgcmV0dXJuIGRhdGUudG9JU09TdHJpbmcoKS5zcGxpdChcIlRcIilbMF1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGFkZERheXMoZGF0ZTogRGF0ZSwgZGF5czogbnVtYmVyKTogRGF0ZSB7XG4gIGNvbnN0IHJlc3VsdCA9IG5ldyBEYXRlKGRhdGUpXG4gIHJlc3VsdC5zZXREYXRlKHJlc3VsdC5nZXREYXRlKCkgKyBkYXlzKVxuICByZXR1cm4gcmVzdWx0XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBpc0JldHdlZW4oZGF0ZTogRGF0ZSwgc3RhcnQ6IERhdGUsIGVuZDogRGF0ZSk6IGJvb2xlYW4ge1xuICByZXR1cm4gZGF0ZSA+PSBzdGFydCAmJiBkYXRlIDw9IGVuZFxufVxuXG5leHBvcnQgZnVuY3Rpb24gc2x1Z2lmeSh0ZXh0OiBzdHJpbmcpOiBzdHJpbmcge1xuICByZXR1cm4gdGV4dFxuICAgIC50b0xvd2VyQ2FzZSgpXG4gICAgLnRyaW0oKVxuICAgIC5ub3JtYWxpemUoXCJORkRcIilcbiAgICAucmVwbGFjZSgvW1xcdTAzMDAtXFx1MDM2Zl0vZywgXCJcIilcbiAgICAucmVwbGFjZSgvW15hLXowLTlcXHMtXS9nLCBcIlwiKVxuICAgIC5yZXBsYWNlKC9bXFxzLV0rL2csIFwiLVwiKVxuICAgIC5yZXBsYWNlKC9eLSt8LSskL2csIFwiXCIpXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBnZXRDb3Vyc2VJZEZyb21QYXRoKHBhdGg6IHN0cmluZyk6IHN0cmluZyB8IG51bGwge1xuICAvLyBFeHRyYWN0IGNvdXJzZSBJRCBmcm9tIHBhdGggbGlrZSBcIjIwMjUvRmFsbC9QU0ktMTAxLy4uLlwiIG9yIGZpbGVuYW1lIFwiUFNJLTEwMSAtIEludHJvIHRvIFBzeWNoLm1kXCJcbiAgY29uc3QgcGFydHMgPSBwYXRoLnNwbGl0KFwiL1wiKVxuICBmb3IgKGNvbnN0IHBhcnQgb2YgcGFydHMpIHtcbiAgICAvLyBMb29rIGZvciBjb3Vyc2UgSUQgcGF0dGVybiBpbiBlYWNoIHBhdGggc2VnbWVudFxuICAgIGNvbnN0IG1hdGNoID0gcGFydC5tYXRjaCgvKFtBLVpdezIsNH0tXFxkezN9KS8pXG4gICAgaWYgKG1hdGNoKSB7XG4gICAgICByZXR1cm4gbWF0Y2hbMV1cbiAgICB9XG4gIH1cbiAgcmV0dXJuIG51bGxcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHZhbGlkYXRlRGF0ZShkYXRlU3RyaW5nOiBzdHJpbmcpOiBib29sZWFuIHtcbiAgY29uc3QgcmVnZXggPSAvXlxcZHs0fS1cXGR7Mn0tXFxkezJ9JC9cbiAgaWYgKCFkYXRlU3RyaW5nLm1hdGNoKHJlZ2V4KSkgcmV0dXJuIGZhbHNlXG5cbiAgY29uc3QgZGF0ZSA9IG5ldyBEYXRlKGRhdGVTdHJpbmcpXG4gIGNvbnN0IHRpbWVzdGFtcCA9IGRhdGUuZ2V0VGltZSgpXG5cbiAgaWYgKHR5cGVvZiB0aW1lc3RhbXAgIT09IFwibnVtYmVyXCIgfHwgaXNOYU4odGltZXN0YW1wKSkgcmV0dXJuIGZhbHNlXG5cbiAgcmV0dXJuIGRhdGVTdHJpbmcgPT09IGRhdGUudG9JU09TdHJpbmcoKS5zcGxpdChcIlRcIilbMF1cbn1cbiIsICJpbXBvcnQgeyBBcHAsIE5vdGljZSB9IGZyb20gXCJvYnNpZGlhblwiXG5pbXBvcnQgeyBUdWNrZXJzVG9vbHNTZXR0aW5ncyB9IGZyb20gXCIuL3NldHRpbmdzXCJcblxuaW50ZXJmYWNlIFRlbXBsYXRlTWFuaWZlc3Qge1xuICB2ZXJzaW9uOiBzdHJpbmdcbiAgdGVtcGxhdGVzOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+XG4gIHBsdWdpbl92ZXJzaW9uOiBzdHJpbmdcbiAgcmVsZWFzZV9ub3Rlczogc3RyaW5nXG59XG5cbmV4cG9ydCBjbGFzcyBUZW1wbGF0ZU1hbmFnZXIge1xuICBhcHA6IEFwcFxuICBzZXR0aW5nczogVHVja2Vyc1Rvb2xzU2V0dGluZ3NcbiAgbWFuaWZlc3Q6IFRlbXBsYXRlTWFuaWZlc3RcblxuICBjb25zdHJ1Y3RvcihhcHA6IEFwcCwgc2V0dGluZ3M6IFR1Y2tlcnNUb29sc1NldHRpbmdzKSB7XG4gICAgdGhpcy5hcHAgPSBhcHBcbiAgICB0aGlzLnNldHRpbmdzID0gc2V0dGluZ3NcbiAgICB0aGlzLm1hbmlmZXN0ID0ge1xuICAgICAgdmVyc2lvbjogXCIxLjAuMFwiLFxuICAgICAgdGVtcGxhdGVzOiB7XG4gICAgICAgIFwiQ291cnNlcy9DcmVhdGUgQ291cnNlIEhvbWVwYWdlLm1kXCI6IFwiMS4wLjBcIixcbiAgICAgICAgXCJDb3Vyc2VzL0NvdXJzZSBJbmRleC5tZFwiOiBcIjEuMC4wXCIsXG4gICAgICAgIFwiTW9kdWxlcy9DcmVhdGUgTW9kdWxlLm1kXCI6IFwiMS4wLjBcIixcbiAgICAgICAgXCJDaGFwdGVycy9DcmVhdGUgQ2hhcHRlci5tZFwiOiBcIjEuMC4wXCIsXG4gICAgICAgIFwiQXNzaWdubWVudHMvQ3JlYXRlIEFzc2lnbm1lbnQubWRcIjogXCIxLjAuMFwiLFxuICAgICAgICBcIkRhaWx5L0RhaWx5IE5vdGUubWRcIjogXCIxLjAuMFwiLFxuICAgICAgICBcIlV0aWxpdGllcy9Wb2NhYnVsYXJ5IEVudHJ5Lm1kXCI6IFwiMS4wLjBcIixcbiAgICAgICAgXCJVdGlsaXRpZXMvRHVlIERhdGUgRW50cnkubWRcIjogXCIxLjAuMFwiXG4gICAgICB9LFxuICAgICAgcGx1Z2luX3ZlcnNpb246IFwiMS4wLjBcIixcbiAgICAgIHJlbGVhc2Vfbm90ZXM6IFwiSW5pdGlhbCByZWxlYXNlIG9mIFR1Y2tlcnMgVG9vbHMgdGVtcGxhdGVzXCJcbiAgICB9XG4gIH1cblxuICBhc3luYyBpbnN0YWxsVGVtcGxhdGVzKCkge1xuICAgIHRyeSB7XG4gICAgICAvLyBHZXQgVGVtcGxhdGVyIHBsdWdpbiBzZXR0aW5ncyB0byBmaW5kIHRlbXBsYXRlIGZvbGRlclxuICAgICAgY29uc3QgdGVtcGxhdGVyUGx1Z2luID0gdGhpcy5nZXRUZW1wbGF0ZXJQbHVnaW4oKVxuICAgICAgaWYgKCF0ZW1wbGF0ZXJQbHVnaW4pIHtcbiAgICAgICAgbmV3IE5vdGljZShcbiAgICAgICAgICBcIlRlbXBsYXRlciBwbHVnaW4gbm90IGZvdW5kLiBQbGVhc2UgaW5zdGFsbCBhbmQgZW5hYmxlIHRoZSBUZW1wbGF0ZXIgcGx1Z2luIGZpcnN0LlwiXG4gICAgICAgIClcbiAgICAgICAgY29uc29sZS5lcnJvcihcbiAgICAgICAgICBcIlRlbXBsYXRlciBwbHVnaW4gbm90IGZvdW5kLiBQbGVhc2UgaW5zdGFsbCBhbmQgZW5hYmxlIHRoZSBUZW1wbGF0ZXIgcGx1Z2luIGZpcnN0LlwiXG4gICAgICAgIClcbiAgICAgICAgcmV0dXJuXG4gICAgICB9XG5cbiAgICAgIGNvbnN0IHRlbXBsYXRlRm9sZGVyUGF0aCA9IHRoaXMuZ2V0VGVtcGxhdGVGb2xkZXJQYXRoKHRlbXBsYXRlclBsdWdpbilcbiAgICAgIGlmICghdGVtcGxhdGVGb2xkZXJQYXRoKSB7XG4gICAgICAgIG5ldyBOb3RpY2UoXG4gICAgICAgICAgXCJUZW1wbGF0ZSBmb2xkZXIgbm90IGNvbmZpZ3VyZWQgaW4gVGVtcGxhdGVyIHNldHRpbmdzLiBQbGVhc2UgY29uZmlndXJlIGl0IGluIFRlbXBsYXRlciBzZXR0aW5ncyBmaXJzdC5cIlxuICAgICAgICApXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXG4gICAgICAgICAgXCJUZW1wbGF0ZSBmb2xkZXIgbm90IGNvbmZpZ3VyZWQgaW4gVGVtcGxhdGVyIHNldHRpbmdzLiBQbGVhc2UgY29uZmlndXJlIGl0IGluIFRlbXBsYXRlciBzZXR0aW5ncyBmaXJzdC5cIlxuICAgICAgICApXG4gICAgICAgIHJldHVyblxuICAgICAgfVxuXG4gICAgICBjb25zdCBmdWxsVGVtcGxhdGVQYXRoID0gYCR7dGVtcGxhdGVGb2xkZXJQYXRofS8ke3RoaXMuc2V0dGluZ3MudGVtcGxhdGVGb2xkZXJ9YFxuXG4gICAgICAvLyBDcmVhdGUgdGhlIG1haW4gdGVtcGxhdGUgZm9sZGVyIGlmIGl0IGRvZXNuJ3QgZXhpc3RcbiAgICAgIHRyeSB7XG4gICAgICAgIGF3YWl0IHRoaXMuYXBwLnZhdWx0LmNyZWF0ZUZvbGRlcihmdWxsVGVtcGxhdGVQYXRoKVxuICAgICAgICBjb25zb2xlLmxvZyhgQ3JlYXRlZCB0ZW1wbGF0ZSBmb2xkZXI6ICR7ZnVsbFRlbXBsYXRlUGF0aH1gKVxuICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAvLyBGb2xkZXIgbWlnaHQgYWxyZWFkeSBleGlzdCwgd2hpY2ggaXMgZmluZVxuICAgICAgICBjb25zb2xlLmxvZyhcbiAgICAgICAgICBgVGVtcGxhdGUgZm9sZGVyIGFscmVhZHkgZXhpc3RzIG9yIGNyZWF0ZWQ6ICR7ZnVsbFRlbXBsYXRlUGF0aH1gXG4gICAgICAgIClcbiAgICAgIH1cblxuICAgICAgLy8gQ3JlYXRlIHN1YmRpcmVjdG9yaWVzXG4gICAgICBjb25zdCBzdWJkaXJzID0gW1xuICAgICAgICBcIkNvdXJzZXNcIixcbiAgICAgICAgXCJNb2R1bGVzXCIsXG4gICAgICAgIFwiQ2hhcHRlcnNcIixcbiAgICAgICAgXCJBc3NpZ25tZW50c1wiLFxuICAgICAgICBcIkRhaWx5XCIsXG4gICAgICAgIFwiVXRpbGl0aWVzXCJcbiAgICAgIF1cbiAgICAgIGZvciAoY29uc3Qgc3ViZGlyIG9mIHN1YmRpcnMpIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBjb25zdCBzdWJQYXRoID0gYCR7ZnVsbFRlbXBsYXRlUGF0aH0vJHtzdWJkaXJ9YFxuICAgICAgICAgIGF3YWl0IHRoaXMuYXBwLnZhdWx0LmNyZWF0ZUZvbGRlcihzdWJQYXRoKVxuICAgICAgICAgIGNvbnNvbGUubG9nKGBDcmVhdGVkIHN1YmRpcmVjdG9yeTogJHtzdWJQYXRofWApXG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAvLyBGb2xkZXIgbWlnaHQgYWxyZWFkeSBleGlzdCwgd2hpY2ggaXMgZmluZVxuICAgICAgICAgIGNvbnNvbGUubG9nKFxuICAgICAgICAgICAgYFN1YmRpcmVjdG9yeSBhbHJlYWR5IGV4aXN0czogJHtmdWxsVGVtcGxhdGVQYXRofS8ke3N1YmRpcn1gXG4gICAgICAgICAgKVxuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIC8vIEluc3RhbGwgdGVtcGxhdGVzXG4gICAgICBhd2FpdCB0aGlzLmluc3RhbGxDb3Vyc2VUZW1wbGF0ZXMoZnVsbFRlbXBsYXRlUGF0aClcbiAgICAgIGF3YWl0IHRoaXMuaW5zdGFsbE1vZHVsZVRlbXBsYXRlcyhmdWxsVGVtcGxhdGVQYXRoKVxuICAgICAgYXdhaXQgdGhpcy5pbnN0YWxsQ2hhcHRlclRlbXBsYXRlcyhmdWxsVGVtcGxhdGVQYXRoKVxuICAgICAgYXdhaXQgdGhpcy5pbnN0YWxsQXNzaWdubWVudFRlbXBsYXRlcyhmdWxsVGVtcGxhdGVQYXRoKVxuICAgICAgYXdhaXQgdGhpcy5pbnN0YWxsRGFpbHlUZW1wbGF0ZXMoZnVsbFRlbXBsYXRlUGF0aClcbiAgICAgIGF3YWl0IHRoaXMuaW5zdGFsbFV0aWxpdHlUZW1wbGF0ZXMoZnVsbFRlbXBsYXRlUGF0aClcblxuICAgICAgLy8gQ3JlYXRlIFJFQURNRVxuICAgICAgYXdhaXQgdGhpcy5jcmVhdGVSRUFETUUoZnVsbFRlbXBsYXRlUGF0aClcblxuICAgICAgLy8gQ3JlYXRlIHRlbXBsYXRlIG1hbmlmZXN0XG4gICAgICBhd2FpdCB0aGlzLmNyZWF0ZVRlbXBsYXRlTWFuaWZlc3QoZnVsbFRlbXBsYXRlUGF0aClcblxuICAgICAgbmV3IE5vdGljZShcIlR1Y2tlcnMgVG9vbHMgdGVtcGxhdGVzIGluc3RhbGxlZCBzdWNjZXNzZnVsbHkhXCIpXG4gICAgICBjb25zb2xlLmxvZyhcIlR1Y2tlcnMgVG9vbHMgdGVtcGxhdGVzIGluc3RhbGxlZCBzdWNjZXNzZnVsbHlcIilcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGluc3RhbGxpbmcgdGVtcGxhdGVzOlwiLCBlcnJvcilcbiAgICAgIG5ldyBOb3RpY2UoXCJFcnJvciBpbnN0YWxsaW5nIHRlbXBsYXRlcy4gQ2hlY2sgY29uc29sZSBmb3IgZGV0YWlscy5cIilcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGdldFRlbXBsYXRlclBsdWdpbigpOiBhbnkge1xuICAgIC8vIFRyeSBtdWx0aXBsZSB3YXlzIHRvIGFjY2VzcyB0aGUgVGVtcGxhdGVyIHBsdWdpblxuICAgIGNvbnN0IHBvc3NpYmxlUGF0aHMgPSBbXG4gICAgICAodGhpcy5hcHAgYXMgYW55KS5wbHVnaW5zLnBsdWdpbnNbXCJ0ZW1wbGF0ZXItb2JzaWRpYW5cIl0sXG4gICAgICAodGhpcy5hcHAgYXMgYW55KS5wbHVnaW5zLnBsdWdpbnNbXCJ0ZW1wbGF0ZXJcIl0sXG4gICAgICAodGhpcy5hcHAgYXMgYW55KS5wbHVnaW5zLmdldFBsdWdpbihcInRlbXBsYXRlci1vYnNpZGlhblwiKSxcbiAgICAgICh0aGlzLmFwcCBhcyBhbnkpLnBsdWdpbnMuZ2V0UGx1Z2luKFwidGVtcGxhdGVyXCIpXG4gICAgXVxuXG4gICAgZm9yIChjb25zdCBwYXRoIG9mIHBvc3NpYmxlUGF0aHMpIHtcbiAgICAgIGlmIChwYXRoKSB7XG4gICAgICAgIHJldHVybiBwYXRoXG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIG51bGxcbiAgfVxuXG4gIHByaXZhdGUgZ2V0VGVtcGxhdGVGb2xkZXJQYXRoKHRlbXBsYXRlclBsdWdpbjogYW55KTogc3RyaW5nIHwgbnVsbCB7XG4gICAgY29uc3Qgc2V0dGluZ3MgPSB0ZW1wbGF0ZXJQbHVnaW4uc2V0dGluZ3NcblxuICAgIGlmICghc2V0dGluZ3MpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJUZW1wbGF0ZXIgcGx1Z2luIGhhcyBubyBzZXR0aW5nc1wiKVxuICAgICAgcmV0dXJuIG51bGxcbiAgICB9XG5cbiAgICAvLyBUcnkgZGlmZmVyZW50IHBvc3NpYmxlIHByb3BlcnR5IG5hbWVzIGZvciB0ZW1wbGF0ZSBmb2xkZXJcbiAgICBjb25zdCBwb3NzaWJsZVBhdGhzID0gW1xuICAgICAgc2V0dGluZ3MudGVtcGxhdGVzX2ZvbGRlciwgIC8vIENoYW5nZWQgZnJvbSB0ZW1wbGF0ZV9mb2xkZXIgdG8gbWF0Y2ggYWN0dWFsIHNldHRpbmdcbiAgICAgIHNldHRpbmdzLnRlbXBsYXRlX2ZvbGRlcixcbiAgICAgIHNldHRpbmdzLnRlbXBsYXRlRm9sZGVyLFxuICAgICAgc2V0dGluZ3MudGVtcGxhdGVGb2xkZXJQYXRoLFxuICAgICAgc2V0dGluZ3MuZm9sZGVyXG4gICAgXVxuXG4gICAgZm9yIChjb25zdCBwYXRoIG9mIHBvc3NpYmxlUGF0aHMpIHtcbiAgICAgIGlmIChwYXRoICYmIHR5cGVvZiBwYXRoID09PSBcInN0cmluZ1wiKSB7XG4gICAgICAgIHJldHVybiBwYXRoXG4gICAgICB9XG4gICAgfVxuXG4gICAgY29uc29sZS5lcnJvcihcbiAgICAgIFwiVGVtcGxhdGUgZm9sZGVyIG5vdCBmb3VuZCBpbiBUZW1wbGF0ZXIgc2V0dGluZ3MuIEF2YWlsYWJsZSBzZXR0aW5nczpcIixcbiAgICAgIE9iamVjdC5rZXlzKHNldHRpbmdzKVxuICAgIClcbiAgICByZXR1cm4gbnVsbFxuICB9XG5cbiAgYXN5bmMgY3JlYXRlVGVtcGxhdGVNYW5pZmVzdChiYXNlUGF0aDogc3RyaW5nKSB7XG4gICAgY29uc3QgbWFuaWZlc3RQYXRoID0gYCR7YmFzZVBhdGh9L3RlbXBsYXRlLW1hbmlmZXN0Lmpzb25gXG4gICAgY29uc3QgbWFuaWZlc3RDb250ZW50ID0gSlNPTi5zdHJpbmdpZnkodGhpcy5tYW5pZmVzdCwgbnVsbCwgMilcblxuICAgIHRyeSB7XG4gICAgICAvLyBDaGVjayBpZiBtYW5pZmVzdCBhbHJlYWR5IGV4aXN0c1xuICAgICAgY29uc3QgZXhpc3RpbmdNYW5pZmVzdCA9XG4gICAgICAgIHRoaXMuYXBwLnZhdWx0LmdldEFic3RyYWN0RmlsZUJ5UGF0aChtYW5pZmVzdFBhdGgpXG4gICAgICBpZiAoZXhpc3RpbmdNYW5pZmVzdCkge1xuICAgICAgICAvLyBVcGRhdGUgdGhlIGV4aXN0aW5nIG1hbmlmZXN0XG4gICAgICAgIGNvbnN0IGZpbGUgPSBleGlzdGluZ01hbmlmZXN0IGFzIGltcG9ydChcIm9ic2lkaWFuXCIpLlRGaWxlXG4gICAgICAgIGF3YWl0IHRoaXMuYXBwLnZhdWx0Lm1vZGlmeShmaWxlLCBtYW5pZmVzdENvbnRlbnQpXG4gICAgICAgIGNvbnNvbGUubG9nKGBVcGRhdGVkIHRlbXBsYXRlIG1hbmlmZXN0OiAke21hbmlmZXN0UGF0aH1gKVxuICAgICAgICByZXR1cm5cbiAgICAgIH1cblxuICAgICAgLy8gQ3JlYXRlIHRoZSBtYW5pZmVzdCBmaWxlXG4gICAgICBhd2FpdCB0aGlzLmFwcC52YXVsdC5jcmVhdGUobWFuaWZlc3RQYXRoLCBtYW5pZmVzdENvbnRlbnQpXG4gICAgICBjb25zb2xlLmxvZyhgQ3JlYXRlZCB0ZW1wbGF0ZSBtYW5pZmVzdDogJHttYW5pZmVzdFBhdGh9YClcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBuZXcgTm90aWNlKGBFcnJvciBjcmVhdGluZyB0ZW1wbGF0ZSBtYW5pZmVzdCAke21hbmlmZXN0UGF0aH1gKVxuICAgICAgY29uc29sZS5lcnJvcihgRXJyb3IgY3JlYXRpbmcgdGVtcGxhdGUgbWFuaWZlc3QgJHttYW5pZmVzdFBhdGh9OmAsIGUpXG4gICAgfVxuICB9XG5cbiAgYXN5bmMgY2hlY2tGb3JUZW1wbGF0ZVVwZGF0ZXMoKTogUHJvbWlzZTxib29sZWFuPiB7XG4gICAgLy8gVGhpcyB3b3VsZCBjaGVjayBpZiB0ZW1wbGF0ZXMgbmVlZCB0byBiZSB1cGRhdGVkXG4gICAgLy8gRm9yIG5vdywgd2UnbGwganVzdCByZXR1cm4gZmFsc2VcbiAgICBjb25zb2xlLmxvZyhcIkNoZWNraW5nIGZvciB0ZW1wbGF0ZSB1cGRhdGVzXCIpXG4gICAgcmV0dXJuIGZhbHNlXG4gIH1cblxuICBhc3luYyB1cGRhdGVUZW1wbGF0ZXMoKSB7XG4gICAgdHJ5IHtcbiAgICAgIC8vIFRoaXMgd291bGQgdXBkYXRlIGV4aXN0aW5nIHRlbXBsYXRlc1xuICAgICAgY29uc29sZS5sb2coXCJVcGRhdGluZyB0ZW1wbGF0ZXNcIilcblxuICAgICAgLy8gR2V0IFRlbXBsYXRlciBwbHVnaW4gc2V0dGluZ3MgdG8gZmluZCB0ZW1wbGF0ZSBmb2xkZXJcbiAgICAgIGNvbnN0IHRlbXBsYXRlclBsdWdpbiA9IHRoaXMuZ2V0VGVtcGxhdGVyUGx1Z2luKClcbiAgICAgIGlmICghdGVtcGxhdGVyUGx1Z2luKSB7XG4gICAgICAgIG5ldyBOb3RpY2UoXG4gICAgICAgICAgXCJUZW1wbGF0ZXIgcGx1Z2luIG5vdCBmb3VuZC4gUGxlYXNlIGluc3RhbGwgYW5kIGVuYWJsZSB0aGUgVGVtcGxhdGVyIHBsdWdpbiBmaXJzdC5cIlxuICAgICAgICApXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXG4gICAgICAgICAgXCJUZW1wbGF0ZXIgcGx1Z2luIG5vdCBmb3VuZC4gUGxlYXNlIGluc3RhbGwgYW5kIGVuYWJsZSB0aGUgVGVtcGxhdGVyIHBsdWdpbiBmaXJzdC5cIlxuICAgICAgICApXG4gICAgICAgIHJldHVyblxuICAgICAgfVxuXG4gICAgICBjb25zdCB0ZW1wbGF0ZUZvbGRlclBhdGggPSB0aGlzLmdldFRlbXBsYXRlRm9sZGVyUGF0aCh0ZW1wbGF0ZXJQbHVnaW4pXG4gICAgICBpZiAoIXRlbXBsYXRlRm9sZGVyUGF0aCkge1xuICAgICAgICBuZXcgTm90aWNlKFxuICAgICAgICAgIFwiVGVtcGxhdGUgZm9sZGVyIG5vdCBjb25maWd1cmVkIGluIFRlbXBsYXRlciBzZXR0aW5ncy4gUGxlYXNlIGNvbmZpZ3VyZSBpdCBpbiBUZW1wbGF0ZXIgc2V0dGluZ3MgZmlyc3QuXCJcbiAgICAgICAgKVxuICAgICAgICBjb25zb2xlLmVycm9yKFxuICAgICAgICAgIFwiVGVtcGxhdGUgZm9sZGVyIG5vdCBjb25maWd1cmVkIGluIFRlbXBsYXRlciBzZXR0aW5ncy4gUGxlYXNlIGNvbmZpZ3VyZSBpdCBpbiBUZW1wbGF0ZXIgc2V0dGluZ3MgZmlyc3QuXCJcbiAgICAgICAgKVxuICAgICAgICByZXR1cm5cbiAgICAgIH1cblxuICAgICAgY29uc3QgZnVsbFRlbXBsYXRlUGF0aCA9IGAke3RlbXBsYXRlRm9sZGVyUGF0aH0vJHt0aGlzLnNldHRpbmdzLnRlbXBsYXRlRm9sZGVyfWBcblxuICAgICAgLy8gVXBkYXRlIHRlbXBsYXRlcyAodGhpcyB3aWxsIG92ZXJ3cml0ZSBleGlzdGluZyBvbmVzKVxuICAgICAgYXdhaXQgdGhpcy5pbnN0YWxsQ291cnNlVGVtcGxhdGVzKGZ1bGxUZW1wbGF0ZVBhdGgpXG4gICAgICBhd2FpdCB0aGlzLmluc3RhbGxNb2R1bGVUZW1wbGF0ZXMoZnVsbFRlbXBsYXRlUGF0aClcbiAgICAgIGF3YWl0IHRoaXMuaW5zdGFsbENoYXB0ZXJUZW1wbGF0ZXMoZnVsbFRlbXBsYXRlUGF0aClcbiAgICAgIGF3YWl0IHRoaXMuaW5zdGFsbEFzc2lnbm1lbnRUZW1wbGF0ZXMoZnVsbFRlbXBsYXRlUGF0aClcbiAgICAgIGF3YWl0IHRoaXMuaW5zdGFsbERhaWx5VGVtcGxhdGVzKGZ1bGxUZW1wbGF0ZVBhdGgpXG4gICAgICBhd2FpdCB0aGlzLmluc3RhbGxVdGlsaXR5VGVtcGxhdGVzKGZ1bGxUZW1wbGF0ZVBhdGgpXG5cbiAgICAgIC8vIFVwZGF0ZSBSRUFETUVcbiAgICAgIGF3YWl0IHRoaXMuY3JlYXRlUkVBRE1FKGZ1bGxUZW1wbGF0ZVBhdGgpXG5cbiAgICAgIC8vIFVwZGF0ZSB0ZW1wbGF0ZSBtYW5pZmVzdFxuICAgICAgYXdhaXQgdGhpcy5jcmVhdGVUZW1wbGF0ZU1hbmlmZXN0KGZ1bGxUZW1wbGF0ZVBhdGgpXG5cbiAgICAgIG5ldyBOb3RpY2UoXCJUdWNrZXJzIFRvb2xzIHRlbXBsYXRlcyB1cGRhdGVkIHN1Y2Nlc3NmdWxseSFcIilcbiAgICAgIGNvbnNvbGUubG9nKFwiVHVja2VycyBUb29scyB0ZW1wbGF0ZXMgdXBkYXRlZCBzdWNjZXNzZnVsbHlcIilcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHVwZGF0aW5nIHRlbXBsYXRlczpcIiwgZXJyb3IpXG4gICAgICBuZXcgTm90aWNlKFwiRXJyb3IgdXBkYXRpbmcgdGVtcGxhdGVzLiBDaGVjayBjb25zb2xlIGZvciBkZXRhaWxzLlwiKVxuICAgIH1cbiAgfVxuXG4gIGFzeW5jIGluc3RhbGxDb3Vyc2VUZW1wbGF0ZXMoYmFzZVBhdGg6IHN0cmluZykge1xuICAgIGNvbnN0IGNvdXJzZVBhdGggPSBgJHtiYXNlUGF0aH0vQ291cnNlc2BcblxuICAgIC8vIENyZWF0ZSBDb3Vyc2UgSG9tZXBhZ2UgdGVtcGxhdGVcbiAgICBjb25zdCBjb3Vyc2VIb21lcGFnZVRlbXBsYXRlID0gdGhpcy5nZW5lcmF0ZUNvdXJzZUhvbWVwYWdlVGVtcGxhdGUoKVxuICAgIGF3YWl0IHRoaXMud3JpdGVUZW1wbGF0ZUZpbGUoXG4gICAgICBgJHtjb3Vyc2VQYXRofS9DcmVhdGUgQ291cnNlIEhvbWVwYWdlLm1kYCxcbiAgICAgIGNvdXJzZUhvbWVwYWdlVGVtcGxhdGVcbiAgICApXG5cbiAgICAvLyBDcmVhdGUgQ291cnNlIEluZGV4IHRlbXBsYXRlXG4gICAgY29uc3QgY291cnNlSW5kZXhUZW1wbGF0ZSA9IHRoaXMuZ2VuZXJhdGVDb3Vyc2VJbmRleFRlbXBsYXRlKClcbiAgICBhd2FpdCB0aGlzLndyaXRlVGVtcGxhdGVGaWxlKFxuICAgICAgYCR7Y291cnNlUGF0aH0vQ291cnNlIEluZGV4Lm1kYCxcbiAgICAgIGNvdXJzZUluZGV4VGVtcGxhdGVcbiAgICApXG4gIH1cblxuICBhc3luYyBpbnN0YWxsTW9kdWxlVGVtcGxhdGVzKGJhc2VQYXRoOiBzdHJpbmcpIHtcbiAgICBjb25zdCBtb2R1bGVQYXRoID0gYCR7YmFzZVBhdGh9L01vZHVsZXNgXG5cbiAgICAvLyBDcmVhdGUgTW9kdWxlIHRlbXBsYXRlXG4gICAgY29uc3QgbW9kdWxlVGVtcGxhdGUgPSB0aGlzLmdlbmVyYXRlTW9kdWxlVGVtcGxhdGUoKVxuICAgIGF3YWl0IHRoaXMud3JpdGVUZW1wbGF0ZUZpbGUoXG4gICAgICBgJHttb2R1bGVQYXRofS9DcmVhdGUgTW9kdWxlLm1kYCxcbiAgICAgIG1vZHVsZVRlbXBsYXRlXG4gICAgKVxuICB9XG5cbiAgYXN5bmMgaW5zdGFsbENoYXB0ZXJUZW1wbGF0ZXMoYmFzZVBhdGg6IHN0cmluZykge1xuICAgIGNvbnN0IGNoYXB0ZXJQYXRoID0gYCR7YmFzZVBhdGh9L0NoYXB0ZXJzYFxuXG4gICAgLy8gQ3JlYXRlIENoYXB0ZXIgdGVtcGxhdGVcbiAgICBjb25zdCBjaGFwdGVyVGVtcGxhdGUgPSB0aGlzLmdlbmVyYXRlQ2hhcHRlclRlbXBsYXRlKClcbiAgICBhd2FpdCB0aGlzLndyaXRlVGVtcGxhdGVGaWxlKFxuICAgICAgYCR7Y2hhcHRlclBhdGh9L0NyZWF0ZSBDaGFwdGVyLm1kYCxcbiAgICAgIGNoYXB0ZXJUZW1wbGF0ZVxuICAgIClcbiAgfVxuXG4gIGFzeW5jIGluc3RhbGxBc3NpZ25tZW50VGVtcGxhdGVzKGJhc2VQYXRoOiBzdHJpbmcpIHtcbiAgICBjb25zdCBhc3NpZ25tZW50UGF0aCA9IGAke2Jhc2VQYXRofS9Bc3NpZ25tZW50c2BcblxuICAgIC8vIENyZWF0ZSBBc3NpZ25tZW50IHRlbXBsYXRlXG4gICAgY29uc3QgYXNzaWdubWVudFRlbXBsYXRlID0gdGhpcy5nZW5lcmF0ZUFzc2lnbm1lbnRUZW1wbGF0ZSgpXG4gICAgYXdhaXQgdGhpcy53cml0ZVRlbXBsYXRlRmlsZShcbiAgICAgIGAke2Fzc2lnbm1lbnRQYXRofS9DcmVhdGUgQXNzaWdubWVudC5tZGAsXG4gICAgICBhc3NpZ25tZW50VGVtcGxhdGVcbiAgICApXG4gIH1cblxuICBhc3luYyBpbnN0YWxsRGFpbHlUZW1wbGF0ZXMoYmFzZVBhdGg6IHN0cmluZykge1xuICAgIGNvbnN0IGRhaWx5UGF0aCA9IGAke2Jhc2VQYXRofS9EYWlseWBcblxuICAgIC8vIENyZWF0ZSBEYWlseSBOb3RlIHRlbXBsYXRlXG4gICAgY29uc3QgZGFpbHlOb3RlVGVtcGxhdGUgPSB0aGlzLmdlbmVyYXRlRGFpbHlOb3RlVGVtcGxhdGUoKVxuICAgIGF3YWl0IHRoaXMud3JpdGVUZW1wbGF0ZUZpbGUoXG4gICAgICBgJHtkYWlseVBhdGh9L0RhaWx5IE5vdGUubWRgLFxuICAgICAgZGFpbHlOb3RlVGVtcGxhdGVcbiAgICApXG4gIH1cblxuICBhc3luYyBpbnN0YWxsVXRpbGl0eVRlbXBsYXRlcyhiYXNlUGF0aDogc3RyaW5nKSB7XG4gICAgY29uc3QgdXRpbGl0eVBhdGggPSBgJHtiYXNlUGF0aH0vVXRpbGl0aWVzYFxuXG4gICAgLy8gQ3JlYXRlIFZvY2FidWxhcnkgRW50cnkgdGVtcGxhdGVcbiAgICBjb25zdCB2b2NhYlRlbXBsYXRlID0gdGhpcy5nZW5lcmF0ZVZvY2FidWxhcnlUZW1wbGF0ZSgpXG4gICAgYXdhaXQgdGhpcy53cml0ZVRlbXBsYXRlRmlsZShcbiAgICAgIGAke3V0aWxpdHlQYXRofS9Wb2NhYnVsYXJ5IEVudHJ5Lm1kYCxcbiAgICAgIHZvY2FiVGVtcGxhdGVcbiAgICApXG5cbiAgICAvLyBDcmVhdGUgRHVlIERhdGUgRW50cnkgdGVtcGxhdGVcbiAgICBjb25zdCBkdWVEYXRlVGVtcGxhdGUgPSB0aGlzLmdlbmVyYXRlRHVlRGF0ZVRlbXBsYXRlKClcbiAgICBhd2FpdCB0aGlzLndyaXRlVGVtcGxhdGVGaWxlKFxuICAgICAgYCR7dXRpbGl0eVBhdGh9L0R1ZSBEYXRlIEVudHJ5Lm1kYCxcbiAgICAgIGR1ZURhdGVUZW1wbGF0ZVxuICAgIClcbiAgfVxuXG4gIGFzeW5jIHdyaXRlVGVtcGxhdGVGaWxlKHBhdGg6IHN0cmluZywgY29udGVudDogc3RyaW5nKSB7XG4gICAgdHJ5IHtcbiAgICAgIC8vIENoZWNrIGlmIGZpbGUgYWxyZWFkeSBleGlzdHNcbiAgICAgIGNvbnN0IGV4aXN0aW5nRmlsZSA9IHRoaXMuYXBwLnZhdWx0LmdldEFic3RyYWN0RmlsZUJ5UGF0aChwYXRoKVxuICAgICAgaWYgKGV4aXN0aW5nRmlsZSkge1xuICAgICAgICAvLyBGb3Igbm93LCB3ZSdsbCB1cGRhdGUgZXhpc3RpbmcgdGVtcGxhdGVzXG4gICAgICAgIC8vIEluIGEgcmVhbCBpbXBsZW1lbnRhdGlvbiwgd2UnZCBjaGVjayB2ZXJzaW9ucyBhbmQgb2ZmZXIgdG8gdXBkYXRlXG4gICAgICAgIGNvbnNvbGUubG9nKGBVcGRhdGluZyBleGlzdGluZyB0ZW1wbGF0ZSBmaWxlOiAke3BhdGh9YClcbiAgICAgICAgY29uc3QgZmlsZSA9IGV4aXN0aW5nRmlsZSBhcyBpbXBvcnQoXCJvYnNpZGlhblwiKS5URmlsZVxuICAgICAgICBhd2FpdCB0aGlzLmFwcC52YXVsdC5tb2RpZnkoZmlsZSwgY29udGVudClcbiAgICAgICAgcmV0dXJuXG4gICAgICB9XG5cbiAgICAgIC8vIENyZWF0ZSB0aGUgZmlsZVxuICAgICAgYXdhaXQgdGhpcy5hcHAudmF1bHQuY3JlYXRlKHBhdGgsIGNvbnRlbnQpXG4gICAgICBjb25zb2xlLmxvZyhgQ3JlYXRlZCB0ZW1wbGF0ZSBmaWxlOiAke3BhdGh9YClcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBuZXcgTm90aWNlKGBFcnJvciBjcmVhdGluZyB0ZW1wbGF0ZSBmaWxlICR7cGF0aH1gKVxuICAgICAgY29uc29sZS5lcnJvcihgRXJyb3IgY3JlYXRpbmcgdGVtcGxhdGUgZmlsZSAke3BhdGh9OmAsIGUpXG4gICAgfVxuICB9XG5cbiAgZ2VuZXJhdGVDb3Vyc2VIb21lcGFnZVRlbXBsYXRlKCk6IHN0cmluZyB7XG4gICAgY29uc3QgZW5oYW5jZWRNZXRhZGF0YSA9IHRoaXMuc2V0dGluZ3MudXNlRW5oYW5jZWRNZXRhZGF0YTtcbiAgICBcbiAgICBpZiAoZW5oYW5jZWRNZXRhZGF0YSkge1xuICAgICAgbGV0IHRlbXBsYXRlID0gYDwlKlxuLy8gVHVja2VycyBUb29scyBDb3Vyc2UgQ3JlYXRpb25cbi8vIEZvciBiZXN0IGV4cGVyaWVuY2UsIHVzZSB0aGUgcGx1Z2luIGNvbW1hbmQ6IENvbW1hbmQgUGFsZXR0ZSBcdTIxOTIgJ0NyZWF0ZSBOZXcgQ291cnNlJ1xuXG5sZXQgY291cnNlTmFtZSA9IFwiTmV3IENvdXJzZVwiO1xubGV0IGNvdXJzZVNlYXNvbiA9IFwiRmFsbFwiOyBcbmxldCBjb3Vyc2VZZWFyID0gbmV3IERhdGUoKS5nZXRGdWxsWWVhcigpLnRvU3RyaW5nKCk7XG5sZXQgY291cnNlSWQgPSBcIkNPVVJTRV9JRFwiO1xuXG4vLyBUcnkgdG8gdXNlIHN5c3RlbSBwcm9tcHRzLCB3aXRoIGdyYWNlZnVsIGZhbGxiYWNrXG50cnkge1xuICBpZiAodHAgJiYgdHAuc3lzdGVtICYmIHRwLnN5c3RlbS5wcm9tcHQpIHtcbiAgICBjb3Vyc2VOYW1lID0gYXdhaXQgdHAuc3lzdGVtLnByb21wdChcIkNvdXJzZSBOYW1lIChlLmcuIFNXTy0yNTAgLSBDb3Vyc2UgVGl0bGUpXCIpIHx8IGNvdXJzZU5hbWU7XG4gICAgY291cnNlSWQgPSBjb3Vyc2VOYW1lLnNwbGl0KCcgLSAnKVswXSB8fCBjb3Vyc2VOYW1lLnJlcGxhY2UoL1teYS16QS1aMC05XS9nLCBcIl9cIik7XG4gICAgY291cnNlU2Vhc29uID0gYXdhaXQgdHAuc3lzdGVtLnN1Z2dlc3RlcihbXCJGYWxsXCIsXCJXaW50ZXJcIixcIlNwcmluZ1wiLFwiU3VtbWVyXCJdLFtcIkZhbGxcIixcIldpbnRlclwiLFwiU3ByaW5nXCIsXCJTdW1tZXJcIl0sIFwiU2Vhc29uXCIpIHx8IGNvdXJzZVNlYXNvbjtcbiAgICBjb3Vyc2VZZWFyID0gYXdhaXQgdHAuc3lzdGVtLnByb21wdChcIlllYXJcIikgfHwgY291cnNlWWVhcjtcbiAgfSBlbHNlIHtcbiAgICBjb25zb2xlLmxvZyhcIlN5c3RlbSBwcm9tcHRzIG5vdCBhdmFpbGFibGUsIHVzZSB0aGUgcGx1Z2luIGNvbW1hbmQgaW5zdGVhZFwiKTtcbiAgfVxufSBjYXRjaCAoZSkge1xuICBjb25zb2xlLmVycm9yKFwiRXJyb3Igd2l0aCBzeXN0ZW0gcHJvbXB0czpcIiwgZS5tZXNzYWdlKTtcbiAgY29uc29sZS5sb2coXCJVc2UgdGhlIHBsdWdpbiBjb21tYW5kOiBDb21tYW5kIFBhbGV0dGUgXHUyMTkyICdDcmVhdGUgTmV3IENvdXJzZSdcIik7XG59XG5cbi8vIE1vdmUgZmlsZSB0byBhcHByb3ByaWF0ZSBsb2NhdGlvblxuYXdhaXQgdHAuZmlsZS5tb3ZlKFxcYC9cXCR7Y291cnNlWWVhcn0vXFwke2NvdXJzZVNlYXNvbn0vXFwke2NvdXJzZU5hbWV9L1xcJHtjb3Vyc2VOYW1lfVxcYCk7XG5cbi8vIENyZWF0ZSBhdHRhY2htZW50cyBmb2xkZXJcbnRyeSB7XG4gIGF3YWl0IGFwcC52YXVsdC5jcmVhdGVGb2xkZXIoXFxgL1xcJHtjb3Vyc2VZZWFyfS9cXCR7Y291cnNlU2Vhc29ufS9cXCR7Y291cnNlTmFtZX0vQXR0YWNobWVudHNcXGApO1xufSBjYXRjaCAoZSkge1xuICAvLyBGb2xkZXIgbWlnaHQgYWxyZWFkeSBleGlzdFxufVxuJT4tLS1cbmNvdXJzZV9pZDogPCUgY291cnNlSWQgJT5cbmNvdXJzZV9zZWFzb246IDwlIGNvdXJzZVNlYXNvbiAlPlxuY291cnNlX3llYXI6IDwlIGNvdXJzZVllYXIgJT5cbmNyZWF0ZWQ6IDwlIHRwLmRhdGUubm93KFwiWVlZWS1NTS1ERFtUXUhIOm1tOnNzWlwiKSAlPlxudGFnczogXG4gIC0gPCUgY291cnNlSWQgJT5cbiAgLSAke3RoaXMuc2V0dGluZ3Muc2Nob29sQWJicmV2aWF0aW9ufS88JSBjb3Vyc2VZZWFyICU+LzwlIGNvdXJzZVNlYXNvbiAlPi88JSBjb3Vyc2VJZCAlPi9cbiAgLSBjb3Vyc2VfaG9tZVxuICAtIGVkdWNhdGlvblxuICAtICR7dGhpcy5zZXR0aW5ncy5zY2hvb2xOYW1lLnJlcGxhY2UoL1xccysvZywgJ18nKX1cbmJhbm5lcjpcbmNzc2NsYXNzZXM6XG4gIC0gd2hpdGVib2FyZC1jb3Vyc2Vcbi0tLVxuXG5cbiMgPCUgY291cnNlTmFtZSAlPlxuXG4jIyBDb3Vyc2UgSW5mb3JtYXRpb25cbioqQ291cnNlKio6IDwlIGNvdXJzZU5hbWUgJT5cbioqQ291cnNlIElEKio6IDwlIGNvdXJzZUlkICU+XG4qKlRlcm0qKjogPCUgY291cnNlU2Vhc29uICU+IDwlIGNvdXJzZVllYXIgJT5cbioqU2Nob29sKio6ICR7dGhpcy5zZXR0aW5ncy5zY2hvb2xOYW1lfVxuXG4jIyBJbnN0cnVjdG9yXG4qKk5hbWUqKjogXFxgSU5QVVRbdGV4dDppbnN0cnVjdG9yX25hbWVdXFxgXG4qKkVtYWlsKio6IFxcYElOUFVUW3RleHQ6aW5zdHJ1Y3Rvcl9lbWFpbF1cXGBcbioqT2ZmaWNlIEhvdXJzKio6IFxcYElOUFVUW3RleHQ6aW5zdHJ1Y3Rvcl9vZmZpY2VfaG91cnNdXFxgXG4qKk9mZmljZSBMb2NhdGlvbioqOiBcXGBJTlBVVFt0ZXh0Omluc3RydWN0b3Jfb2ZmaWNlX2xvY2F0aW9uXVxcYFxuXG4jIyBDb3Vyc2UgRGVzY3JpcHRpb25cblxcYElOUFVUW3RleHRBcmVhOmNvdXJzZV9kZXNjcmlwdGlvbl1cXGBcblxuIyMgTGVhcm5pbmcgT2JqZWN0aXZlc1xuXFxgSU5QVVRbdGV4dEFyZWE6bGVhcm5pbmdfb2JqZWN0aXZlc11cXGBcblxuIyMgUmVxdWlyZWQgVGV4dHNcblxcYFxcYFxcYG1ldGEtYmluZC1qcy12aWV3XG57dGV4dHN9IGFzIHRleHRzXG4tLS1cbmNvbnN0IGF2YWlsYWJsZVRleHRzID0gYXBwLnZhdWx0LmdldEZpbGVzKCkuZmlsdGVyKGZpbGUgPT4gZmlsZS5leHRlbnNpb24gPT0gJ3BkZicpLm1hcChmID0+IGY/Lm5hbWUpXG5jb25zdCBlc2NhcGVSZWdleCA9IC9bLFxcYCcoKV0vZztcbm9wdGlvbnMgPSBhdmFpbGFibGVUZXh0cy5tYXAodCA9PiBcXGBvcHRpb24oW1tcXCR7dC5yZXBsYWNlKGVzY2FwZVJlZ2V4LFwiXFwkMVwiKX1dXSwgXFwke3QucmVwbGFjZShlc2NhcGVSZWdleCxcIlxcJDFcIil9KVxcYCApXG5jb25zdCBzdHIgPSBcXGBcXFxcXFxgSU5QVVRbaW5saW5lTGlzdFN1Z2dlc3RlcihcXCR7b3B0aW9ucy5qb2luKFwiLCBcIil9KTp0ZXh0c11cXFxcXFxgXFxgXG5yZXR1cm4gZW5naW5lLm1hcmtkb3duLmNyZWF0ZShzdHIpXG5cXGBcXGBcXGBcblxuIyMgQ291cnNlIFNjaGVkdWxlXG5cXGBJTlBVVFt0ZXh0QXJlYTpjb3Vyc2Vfc2NoZWR1bGVdXFxgXG5cbiMjIFJlc291cmNlc1xuXFxgSU5QVVRbdGV4dEFyZWE6cmVzb3VyY2VzXVxcYFxuXG4jIyBWb2NhYnVsYXJ5XG5cXGBcXGBcXGBkYXRhdmlld2pzXG5jb25zdCB7cHJvY2Vzc0NvdXJzZVZvY2FidWxhcnl9ID0gYXBwLnBsdWdpbnMuZ2V0UGx1Z2luKFwidHVja2Vycy10b29sc1wiKT8uZGF0YXZpZXdGdW5jdGlvbnMgfHwgcmVxdWlyZShcIiR7dGhpcy5zZXR0aW5ncy5kYXRhdmlld0pzUGF0aCB8fCBcIi9TdXBwb3J0aW5nL2RhdGF2aWV3LWZ1bmN0aW9uc1wifVwiKTtcbnByb2Nlc3NDb3Vyc2VWb2NhYnVsYXJ5KGR2LCAnPCUgY291cnNlSWQgJT4nKTtcblxcYFxcYFxcYFxuXG4jIyBEdWUgRGF0ZXNcblxcYFxcYFxcYGRhdGF2aWV3anNcbmNvbnN0IHtwcm9jZXNzRHVlRGF0ZXN9ID0gYXBwLnBsdWdpbnMuZ2V0UGx1Z2luKFwidHVja2Vycy10b29sc1wiKT8uZGF0YXZpZXdGdW5jdGlvbnMgfHwgcmVxdWlyZShcIiR7dGhpcy5zZXR0aW5ncy5kYXRhdmlld0pzUGF0aCB8fCBcIi9TdXBwb3J0aW5nL2RhdGF2aWV3LWZ1bmN0aW9uc1wifVwiKTtcbnByb2Nlc3NEdWVEYXRlcyhkdiwnIzwlIGNvdXJzZUlkICU+Jyk7XG5cXGBcXGBcXGBcblxuIyMgQ2xhc3MgTWF0ZXJpYWxzXG5cXGBJTlBVVFt0ZXh0QXJlYTpjbGFzc19tYXRlcmlhbHNdXFxgXG5cbiMjIENsYXNzbWF0ZXNcblxcYElOUFVUW3RleHRBcmVhOmNsYXNzbWF0ZXNdXFxgYDtcbiAgICAgIFxuICAgICAgICAgcmV0dXJuIHRlbXBsYXRlO1xuICAgIH0gZWxzZSB7XG4gICAgICBsZXQgdGVtcGxhdGUgPSBgPCUqXG4vLyBUdWNrZXJzIFRvb2xzIENvdXJzZSBDcmVhdGlvblxuLy8gRm9yIGJlc3QgZXhwZXJpZW5jZSwgdXNlIHRoZSBwbHVnaW4gY29tbWFuZDogQ29tbWFuZCBQYWxldHRlIFx1MjE5MiAnQ3JlYXRlIE5ldyBDb3Vyc2UnXG5cbmxldCBjb3Vyc2VOYW1lID0gXCJOZXcgQ291cnNlXCI7XG5sZXQgY291cnNlU2Vhc29uID0gXCJGYWxsXCI7IFxubGV0IGNvdXJzZVllYXIgPSBuZXcgRGF0ZSgpLmdldEZ1bGxZZWFyKCkudG9TdHJpbmcoKTtcbmxldCBjb3Vyc2VJZCA9IFwiQ09VUlNFX0lEXCI7XG5cbi8vIFRyeSB0byB1c2Ugc3lzdGVtIHByb21wdHMsIHdpdGggZ3JhY2VmdWwgZmFsbGJhY2tcbnRyeSB7XG4gIGlmICh0cCAmJiB0cC5zeXN0ZW0gJiYgdHAuc3lzdGVtLnByb21wdCkge1xuICAgIGNvdXJzZU5hbWUgPSBhd2FpdCB0cC5zeXN0ZW0ucHJvbXB0KFwiQ291cnNlIE5hbWUgKGUuZy4gU1dPLTI1MCAtIENvdXJzZSBUaXRsZSlcIikgfHwgY291cnNlTmFtZTtcbiAgICBjb3Vyc2VJZCA9IGNvdXJzZU5hbWUuc3BsaXQoJyAtICcpWzBdIHx8IGNvdXJzZU5hbWUucmVwbGFjZSgvW15hLXpBLVowLTldL2csIFwiX1wiKTtcbiAgICBjb3Vyc2VTZWFzb24gPSBhd2FpdCB0cC5zeXN0ZW0uc3VnZ2VzdGVyKFtcIkZhbGxcIixcIldpbnRlclwiLFwiU3ByaW5nXCIsXCJTdW1tZXJcIl0sW1wiRmFsbFwiLFwiV2ludGVyXCIsXCJTcHJpbmdcIixcIlN1bW1lclwiXSwgXCJTZWFzb25cIikgfHwgY291cnNlU2Vhc29uO1xuICAgIGNvdXJzZVllYXIgPSBhd2FpdCB0cC5zeXN0ZW0ucHJvbXB0KFwiWWVhclwiKSB8fCBjb3Vyc2VZZWFyO1xuICB9IGVsc2Uge1xuICAgIGNvbnNvbGUubG9nKFwiU3lzdGVtIHByb21wdHMgbm90IGF2YWlsYWJsZSwgdXNlIHRoZSBwbHVnaW4gY29tbWFuZCBpbnN0ZWFkXCIpO1xuICB9XG59IGNhdGNoIChlKSB7XG4gIGNvbnNvbGUuZXJyb3IoXCJFcnJvciB3aXRoIHN5c3RlbSBwcm9tcHRzOlwiLCBlLm1lc3NhZ2UpO1xuICBjb25zb2xlLmxvZyhcIlVzZSB0aGUgcGx1Z2luIGNvbW1hbmQ6IENvbW1hbmQgUGFsZXR0ZSBcdTIxOTIgJ0NyZWF0ZSBOZXcgQ291cnNlJ1wiKTtcbn1cblxuLy8gTW92ZSBmaWxlIHRvIGFwcHJvcHJpYXRlIGxvY2F0aW9uXG5hd2FpdCB0cC5maWxlLm1vdmUoXFxgL1xcJHtjb3Vyc2VZZWFyfS9cXCR7Y291cnNlU2Vhc29ufS9cXCR7Y291cnNlTmFtZX0vXFwke2NvdXJzZU5hbWV9XFxgKTtcblxuLy8gQ3JlYXRlIGF0dGFjaG1lbnRzIGZvbGRlclxudHJ5IHtcbiAgYXdhaXQgYXBwLnZhdWx0LmNyZWF0ZUZvbGRlcihcXGAvXFwke2NvdXJzZVllYXJ9L1xcJHtjb3Vyc2VTZWFzb259L1xcJHtjb3Vyc2VOYW1lfS9BdHRhY2htZW50c1xcYCk7XG59IGNhdGNoIChlKSB7XG4gIC8vIEZvbGRlciBtaWdodCBhbHJlYWR5IGV4aXN0XG59XG4lPi0tLVxuY291cnNlX2lkOiA8JSBjb3Vyc2VJZCAlPlxuY291cnNlX25hbWU6IDwlIGNvdXJzZU5hbWUgJT5cbmNvdXJzZV9zZWFzb246IDwlIGNvdXJzZVNlYXNvbiAlPlxuY291cnNlX3llYXI6IDwlIGNvdXJzZVllYXIgJT5cbmNyZWF0ZWQ6IDwlIHRwLmRhdGUubm93KFwiWVlZWS1NTS1ERFtUXUhIOm1tOnNzWlwiKSAlPlxudGFnczpcbiAgLSA8JSBjb3Vyc2VJZCAlPlxuICAtIGNvdXJzZV9ob21lXG4gIC0gZWR1Y2F0aW9uXG4tLS1cblxuIyA8JSBjb3Vyc2VOYW1lICU+XG5cbiMjIENvdXJzZSBJbmZvcm1hdGlvblxuKipDb3Vyc2UgSUQqKjogPCUgY291cnNlSWQgJT5cbioqVGVybSoqOiA8JSBjb3Vyc2VTZWFzb24gJT4gPCUgY291cnNlWWVhciAlPlxuKipTY2hvb2wqKjogJHt0aGlzLnNldHRpbmdzLnNjaG9vbE5hbWV9XG5cbiMjIEluc3RydWN0b3JcbioqTmFtZSoqOiBcXGBJTlBVVFt0ZXh0Omluc3RydWN0b3JfbmFtZV1cXGBcbioqRW1haWwqKjogXFxgSU5QVVRbdGV4dDppbnN0cnVjdG9yX2VtYWlsXVxcYFxuKipPZmZpY2UgSG91cnMqKjogXFxgSU5QVVRbdGV4dDppbnN0cnVjdG9yX29mZmljZV9ob3Vyc11cXGBcbioqT2ZmaWNlIExvY2F0aW9uKio6IFxcYElOUFVUW3RleHQ6aW5zdHJ1Y3Rvcl9vZmZpY2VfbG9jYXRpb25dXFxgXG5cbiMjIENvdXJzZSBEZXNjcmlwdGlvblxuXFxgSU5QVVRbdGV4dEFyZWE6Y291cnNlX2Rlc2NyaXB0aW9uXVxcYFxuXG4jIyBMZWFybmluZyBPYmplY3RpdmVzXG5cXGBJTlBVVFt0ZXh0QXJlYTpsZWFybmluZ19vYmplY3RpdmVzXVxcYFxuXG4jIyBSZXF1aXJlZCBUZXh0c1xuXFxgXFxgXFxgbWV0YS1iaW5kLWpzLXZpZXdcbnt0ZXh0c30gYXMgdGV4dHNcbi0tLVxuY29uc3QgYXZhaWxhYmxlVGV4dHMgPSBhcHAudmF1bHQuZ2V0RmlsZXMoKS5maWx0ZXIoZmlsZSA9PiBmaWxlLmV4dGVuc2lvbiA9PSAncGRmJykubWFwKGYgPT4gZj8ubmFtZSlcbmNvbnN0IGVzY2FwZVJlZ2V4ID0gL1ssXFxgJygpXS9nO1xub3B0aW9ucyA9IGF2YWlsYWJsZVRleHRzLm1hcCh0ID0+IFxcYG9wdGlvbihbW1xcJHt0LnJlcGxhY2UoZXNjYXBlUmVnZXgsXCJcXCQxXCIpfV1dLCBcXCR7dC5yZXBsYWNlKGVzY2FwZVJlZ2V4LFwiXFwkMVwiKX0pXFxgIClcbmNvbnN0IHN0ciA9IFxcJ1xcXFxcXGBJTlBVVFtpbmxpbmVMaXN0U3VnZ2VzdGVyKFxcJHtvcHRpb25zLmpvaW4oXCIsIFwiKX0pOnRleHRzXVxcXFxcXGBcXFxcJ1xucmV0dXJuIGVuZ2luZS5tYXJrZG93bi5jcmVhdGUoc3RyKVxuXFxgXFxgXFxgXG5cbiMjIFNjaGVkdWxlXG5cXGBJTlBVVFt0ZXh0QXJlYTpjb3Vyc2Vfc2NoZWR1bGVdXFxgXG5cbiMjIEFzc2lnbm1lbnRzXG5cXGBJTlBVVFt0ZXh0QXJlYTphc3NpZ25tZW50c11cXGBcblxuIyMgUmVzb3VyY2VzXG5cXGBJTlBVVFt0ZXh0QXJlYTpyZXNvdXJjZXNdXFxgXG5cbiMjIFZvY2FidWxhcnlcblxcYFxcYFxcYGRhdGF2aWV3anNcbmNvbnN0IHtwcm9jZXNzQ291cnNlVm9jYWJ1bGFyeX0gPSBhcHAucGx1Z2lucy5nZXRQbHVnaW4oXCJ0dWNrZXJzLXRvb2xzXCIpPy5kYXRhdmlld0Z1bmN0aW9ucyB8fCByZXF1aXJlKFwiJHt0aGlzLnNldHRpbmdzLmRhdGF2aWV3SnNQYXRoIHx8IFwiL1N1cHBvcnRpbmcvZGF0YXZpZXctZnVuY3Rpb25zXCJ9XCIpO1xucHJvY2Vzc0NvdXJzZVZvY2FidWxhcnkoZHYsICc8JSBjb3Vyc2VJZCAlPicpO1xuXFxgXFxgXFxgXG5cbiMjIER1ZSBEYXRlc1xuXFxgXFxgXFxgZGF0YXZpZXdqc1xuY29uc3Qge3Byb2Nlc3NEdWVEYXRlc30gPSBhcHAucGx1Z2lucy5nZXRQbHVnaW4oXCJ0dWNrZXJzLXRvb2xzXCIpPy5kYXRhdmlld0Z1bmN0aW9ucyB8fCByZXF1aXJlKFwiJHt0aGlzLnNldHRpbmdzLmRhdGF2aWV3SnNQYXRoIHx8IFwiL1N1cHBvcnRpbmcvZGF0YXZpZXctZnVuY3Rpb25zXCJ9XCIpO1xucHJvY2Vzc0R1ZURhdGVzKGR2LCcjPCUgY291cnNlSWQgJT4nKTtcblxcYFxcYFxcYGA7XG4gICAgICBcbiAgICAgIFxuICAgICAgcmV0dXJuIHRlbXBsYXRlO1xuICAgIH1cbiAgfVxuXG4gIGdlbmVyYXRlQ291cnNlSW5kZXhUZW1wbGF0ZSgpOiBzdHJpbmcge1xuICAgIHJldHVybiBgLS0tXG5jb250ZW50X3R5cGU6IGNvdXJzZV9pbmRleFxudGFnczpcbiAgLSBpbmRleFxuLS0tXG5cbiMgQ291cnNlIEluZGV4XG5cbiMjIE1vZHVsZXNcblxuIyMgQ2hhcHRlcnNcblxuIyMgQXNzaWdubWVudHNcblxuIyMgUmVzb3VyY2VzXG5cbiMjIFZvY2FidWxhcnlcblxuIyMgRHVlIERhdGVzYFxuICB9XG5cbiAgZ2VuZXJhdGVNb2R1bGVUZW1wbGF0ZSgpOiBzdHJpbmcge1xuICAgIHJldHVybiBgPCUqXG5jb25zdCB7IHNlYXNvbiwgbW9kdWxlTnVtYmVyLCB3ZWVrTnVtYmVyLCBjb3Vyc2UsIGNvdXJzZUlkLCBkaXNjaXBsaW5lLCBkYXlPZldlZWsgfSA9IGF3YWl0IHRwLnVzZXIubmV3X21vZHVsZShhcHAsIHRwLCBcIjIwMjVcIik7XG5sZXQgdGl0bGUgPSBjb3Vyc2VJZFxuaWYgKG1vZHVsZU51bWJlciAmJiB3ZWVrTnVtYmVyKSB7IHRpdGxlID0gXFxgTVxcJHttb2R1bGVOdW1iZXJ9L1dcXCR7d2Vla051bWJlcn1cXGB9XG5lbHNlIGlmIChtb2R1bGVOdW1iZXIpIHsgdGl0bGUgPSBcXGBNXFwke21vZHVsZU51bWJlcn1cXGAgfSBcbmVsc2UgaWYgKHdlZWtOdW1iZXIpIHsgdGl0bGUgPSBcXGBXXFwke3dlZWtOdW1iZXJ9XFxgfVxuJT4tLS1cbiR7XG4gIHRoaXMuc2V0dGluZ3MudXNlRW5oYW5jZWRNZXRhZGF0YVxuICAgID8gYGNvdXJzZV9pZDogPCUgY291cnNlSWQgJT5cbm1vZHVsZV9udW1iZXI6IDwlIG1vZHVsZU51bWJlciAlPlxud2Vla19udW1iZXI6IDwlIHdlZWtOdW1iZXIgJT5cbmNsYXNzX2RheTogPCUgZGF5T2ZXZWVrICU+XG5jb250ZW50X3R5cGU6IG1vZHVsZVxucGFyZW50X2NvdXJzZTogXCJbWzwlIGNvdXJzZSAlPl1dXCJgXG4gICAgOiBgY291cnNlX2lkOiA8JSBjb3Vyc2VJZCAlPlxubW9kdWxlX251bWJlcjogPCUgbW9kdWxlTnVtYmVyICU+XG53ZWVrX251bWJlcjogPCUgd2Vla051bWJlciAlPlxuY2xhc3NfZGF5OiA8JSBkYXlPZldlZWsgJT5gXG59XG5jcmVhdGVkOiA8JSB0cC5kYXRlLm5vdyhcIllZWVktTU0tRERbVF1ISDptbTpzc1pcIikgJT5cbnRhZ3M6XG4gIC0gZWR1Y2F0aW9uXG4gIC0gPCUgY291cnNlSWQgJT5cbiAgLSBtb2R1bGVcbi0tLVxuXG5cbiMgW1s8JSBjb3Vyc2UgJT5dXSAtIDwlIHRpdGxlICU+IC0gPCUgZGF5T2ZXZWVrICU+XG5cbiMjIER1ZSBEYXRlc1xufCBEYXRlIHwgQXNzaWdubWVudCB8XG58IC0tLS0gfCAtLS0tLS0tLS0tIHxcbnwgICAgICB8ICAgICAgICAgICAgfFxufCAgICAgIHwgICAgICAgICAgICB8XG58ICAgICAgfCAgICAgICAgICAgIHxcblxuXFxgXFxgXFxgZGF0YXZpZXdqc1xuY29uc3Qge3Byb2Nlc3NEdWVEYXRlc30gPSByZXF1aXJlKFwiJHt0aGlzLnNldHRpbmdzLmRhdGF2aWV3SnNQYXRoIHx8IFwiL1N1cHBvcnRpbmcvZGF0YXZpZXctZnVuY3Rpb25zXCJ9XCIpO1xucHJvY2Vzc0R1ZURhdGVzKGR2LCcjPCUgY291cnNlSWQgJT4nKTtcblxcYFxcYFxcYFxuXG4jIyBMZWFybmluZyBPYmplY3RpdmVzXG5cbiMjIFJlYWRpbmcgQXNzaWdubWVudFxuXG4jIyBMZWN0dXJlIE5vdGVzXG5cbiMjIERpc2N1c3Npb24gUXVlc3Rpb25zXG5cbiMjIFZvY2FidWxhcnlcblxuXFxgXFxgXFxgZGF0YXZpZXdqc1xuY29uc3Qge3Byb2Nlc3NDb3Vyc2VWb2NhYnVsYXJ5fSA9IHJlcXVpcmUoXCIke3RoaXMuc2V0dGluZ3MuZGF0YXZpZXdKc1BhdGggfHwgXCIvU3VwcG9ydGluZy9kYXRhdmlldy1mdW5jdGlvbnNcIn1cIik7XG5wcm9jZXNzQ291cnNlVm9jYWJ1bGFyeShkdiwgJzwlIGNvdXJzZUlkICU+Jyk7XG5cXGBcXGBcXGBcblxuIyMgQWRkaXRpb25hbCBSZXNvdXJjZXNgXG4gIH1cblxuICBnZW5lcmF0ZUNoYXB0ZXJUZW1wbGF0ZSgpOiBzdHJpbmcge1xuICAgIHJldHVybiBgPCUqXG5jb25zdCB7IGNoYXB0ZXJOdW1iZXIsIGNvdXJzZSwgY291cnNlSWQsIGRpc2NpcGxpbmUsIHRleHR9ID0gYXdhaXQgdHAudXNlci5uZXdfY2hhcHRlcih0cCk7XG4lPi0tLVxuJHtcbiAgdGhpcy5zZXR0aW5ncy51c2VFbmhhbmNlZE1ldGFkYXRhXG4gICAgPyBgY291cnNlX2lkOiA8JSBjb3Vyc2VJZCAlPlxuY2hhcHRlcl9udW1iZXI6IDwlIGNoYXB0ZXJOdW1iZXIgJT5cbmNvbnRlbnRfdHlwZTogY2hhcHRlclxucGFyZW50X2NvdXJzZTogXCJbWzwlIGNvdXJzZSAlPl1dXCJcbnRleHRfcmVmZXJlbmNlOiBcIltbPCUgdGV4dCAlPl1dXCJgXG4gICAgOiBgY291cnNlX2lkOiA8JSBjb3Vyc2VJZCAlPlxuY2hhcHRlcl9udW1iZXI6IDwlIGNoYXB0ZXJOdW1iZXIgJT5gXG59XG5jcmVhdGVkOiA8JSB0cC5kYXRlLm5vdyhcIllZWVktTU0tRERbVF1ISDptbTpzc1pcIikgJT5cbnRhZ3M6XG4gIC0gZWR1Y2F0aW9uXG4gIC0gPCUgY291cnNlSWQgJT5cbiAgLSBjaGFwdGVyXG4tLS1cblxuXG4jIFtbPCUgdGV4dCAlPl1dIC0gQ2hhcHRlciA8JSBjaGFwdGVyTnVtYmVyICU+XG5cbiMjIFJlYWRpbmcgQXNzaWdubWVudFxuLSAqKlRleHRib29rKio6IFtbPCUgdGV4dCAlPl1dXG4tICoqQ2hhcHRlcioqOiA8JSBjaGFwdGVyTnVtYmVyICU+XG4tICoqUGFnZXMqKjogXG5cbiMjIFN1bW1hcnlcblxuIyMgS2V5IENvbmNlcHRzXG5cbiMjIFZvY2FidWxhcnlcbi0gXG5cbiMjIE5vdGVzXG5cbiMjIERpc2N1c3Npb24gUXVlc3Rpb25zXG5cbiMjIEZ1cnRoZXIgUmVhZGluZ2BcbiAgfVxuXG4gIGdlbmVyYXRlQXNzaWdubWVudFRlbXBsYXRlKCk6IHN0cmluZyB7XG4gICAgcmV0dXJuIGAtLS1cbiR7XG4gIHRoaXMuc2V0dGluZ3MudXNlRW5oYW5jZWRNZXRhZGF0YVxuICAgID8gYGNvdXJzZV9pZDogPCUgY291cnNlSWQgJT5cbmFzc2lnbm1lbnRfdHlwZTogPCUgYXNzaWdubWVudFR5cGUgJT5cbmR1ZV9kYXRlOiA8JSBkdWVEYXRlICU+XG5wb2ludHM6IDwlIHBvaW50cyAlPlxuY29udGVudF90eXBlOiBhc3NpZ25tZW50XG5wYXJlbnRfY291cnNlOiBcIltbPCUgY291cnNlICU+XV1cImBcbiAgICA6IGBjb3Vyc2VfaWQ6IDwlIGNvdXJzZUlkICU+XG5hc3NpZ25tZW50X3R5cGU6IDwlIGFzc2lnbm1lbnRUeXBlICU+XG5kdWVfZGF0ZTogPCUgZHVlRGF0ZSAlPmBcbn1cbmNyZWF0ZWQ6IDwlIHRwLmRhdGUubm93KFwiWVlZWS1NTS1ERFtUXUhIOm1tOnNzWlwiKSAlPlxuc3RhdHVzOiBwZW5kaW5nXG50YWdzOlxuICAtIGVkdWNhdGlvblxuICAtIDwlIGNvdXJzZUlkICU+XG4gIC0gYXNzaWdubWVudFxuLS0tXG5cbiMgPCUgYXNzaWdubWVudE5hbWUgJT4gLSA8JSBjb3Vyc2VJZCAlPlxuXG4jIyBEZXNjcmlwdGlvblxuXG4jIyBJbnN0cnVjdGlvbnNcblxuIyMgRHVlIERhdGVcbioqQXNzaWduZWQqKjogPCUgdHAuZGF0ZS5ub3coXCJZWVlZLU1NLUREXCIpICU+XG4qKkR1ZSoqOiA8JSBkdWVEYXRlICU+XG5cbiMjIFN1Ym1pc3Npb25cblxuIyMgR3JhZGluZyBDcml0ZXJpYVxuXG4jIyBSZXNvdXJjZXNcblxuIyBEdWUgRGF0ZXNcbnwgPCUgZHVlRGF0ZSAlPiB8IDwlIGFzc2lnbm1lbnROYW1lICU+IHwgcGVuZGluZyB8XG5gXG4gIH1cblxuICBnZW5lcmF0ZURhaWx5Tm90ZVRlbXBsYXRlKCk6IHN0cmluZyB7XG4gICAgcmV0dXJuIGAtLS1cbmNvbnRlbnRfdHlwZTogZGFpbHlfbm90ZVxuZGF0ZTogPCUgdHAuZGF0ZS5ub3coXCJZWVlZLU1NLUREXCIpICU+XG50YWdzOlxuICAtIGRhaWx5XG4gIC0gPCUgdHAuZGF0ZS5ub3coXCJZWVlZXCIpICU+XG4gIC0gPCUgdHAuZGF0ZS5ub3coXCJNTVwiKSAlPlxuICAtIDwlIHRwLmRhdGUubm93KFwiRERcIikgJT5cbi0tLVxuXG4jIDwlIHRwLmRhdGUubm93KFwiWVlZWS1NTS1ERCAtIGRkZGRcIikgJT5cblxuPDwgW1s8JSB0cC5kYXRlLnllc3RlcmRheShcIllZWVktTU0tRERcIikgJT5dXSB8IFtbPCUgdHAuZGF0ZS50b21vcnJvdyhcIllZWVktTU0tRERcIikgJT5dXSA+PlxuXG4jIyBUb2RheSdzIEZvY3VzXG5cbiMjIENvdXJzZXMgV29ya2VkIE9uXG4tIFxuXG4jIyBUYXNrcyBDb21wbGV0ZWRcbi0gWyBdIFxuXG4jIyBWb2NhYnVsYXJ5IFJldmlld2VkXG4tIFxuXG4jIyBBc3NpZ25tZW50cyBEdWVcbi0gXG5cbiMjIExlYXJuaW5nIEFjaGlldmVtZW50c1xuXG4jIyBDaGFsbGVuZ2VzXG5cbiMjIFRvbW9ycm93J3MgUGxhblxuXG4jIyBSZWZsZWN0aW9uYFxuICB9XG5cbiAgZ2VuZXJhdGVWb2NhYnVsYXJ5VGVtcGxhdGUoKTogc3RyaW5nIHtcbiAgICByZXR1cm4gYCMjIDwlIHRlcm0gJT5cbioqVGVybSoqOiA8JSB0ZXJtICU+XG4qKlBhcnQgb2YgU3BlZWNoKio6IFxuKipEZWZpbml0aW9uKio6IFxuKipDb250ZXh0Kio6IFxuKipFeGFtcGxlcyoqOiBcbioqUmVsYXRlZCBUZXJtcyoqOiBcbioqU2VlIEFsc28qKjpgXG4gIH1cblxuICBnZW5lcmF0ZUR1ZURhdGVUZW1wbGF0ZSgpOiBzdHJpbmcge1xuICAgIHJldHVybiBgfCA8JSBkdWVEYXRlICU+IHwgPCUgYXNzaWdubWVudCAlPiB8IDwlIHN0YXR1cyAlPiB8YFxuICB9XG5cbiAgYXN5bmMgY3JlYXRlUkVBRE1FKGJhc2VQYXRoOiBzdHJpbmcpIHtcbiAgICBjb25zdCByZWFkbWVDb250ZW50ID0gYCMgVHVja2VycyBUb29scyBUZW1wbGF0ZXNcblxuVGhpcyBkaXJlY3RvcnkgY29udGFpbnMgdGVtcGxhdGVzIGZvciB0aGUgVHVja2VycyBUb29scyBPYnNpZGlhbiBwbHVnaW4uXG5cbiMjIFRlbXBsYXRlIENhdGVnb3JpZXNcblxuLSAqKkNvdXJzZXMqKjogVGVtcGxhdGVzIGZvciBjcmVhdGluZyBhbmQgb3JnYW5pemluZyBjb3Vyc2VzXG4tICoqTW9kdWxlcyoqOiBUZW1wbGF0ZXMgZm9yIGNvdXJzZSBtb2R1bGVzXG4tICoqQ2hhcHRlcnMqKjogVGVtcGxhdGVzIGZvciBjaGFwdGVyIG5vdGVzXG4tICoqQXNzaWdubWVudHMqKjogVGVtcGxhdGVzIGZvciBhc3NpZ25tZW50c1xuLSAqKkRhaWx5Kio6IFRlbXBsYXRlcyBmb3IgZGFpbHkgbm90ZXNcbi0gKipVdGlsaXRpZXMqKjogSGVscGVyIHRlbXBsYXRlc1xuXG4jIyBVc2FnZVxuXG5UaGVzZSB0ZW1wbGF0ZXMgYXJlIGRlc2lnbmVkIHRvIHdvcmsgd2l0aCB0aGUgVHVja2VycyBUb29scyBwbHVnaW4uIFRvIHVzZSB0aGVtOlxuXG4xLiBJbnN0YWxsIHRoZSBUdWNrZXJzIFRvb2xzIHBsdWdpblxuMi4gQ29uZmlndXJlIHlvdXIgc2V0dGluZ3MgaW4gdGhlIHBsdWdpbiBzZXR0aW5ncyB0YWJcbjMuIFVzZSB0aGUgXCJJbnNlcnQgVGVtcGxhdGVcIiBjb21tYW5kIHRvIGFwcGx5IHRoZXNlIHRlbXBsYXRlcyB0byBuZXcgbm90ZXNcblxuIyMgQ3VzdG9taXphdGlvblxuXG5GZWVsIGZyZWUgdG8gY3VzdG9taXplIHRoZXNlIHRlbXBsYXRlcyB0byBzdWl0IHlvdXIgbmVlZHMuIFRoZSBwbHVnaW4gd2lsbCBub3Qgb3ZlcndyaXRlIHlvdXIgY2hhbmdlcyB3aGVuIHVwZGF0aW5nIHRlbXBsYXRlcy5gXG5cbiAgICBhd2FpdCB0aGlzLndyaXRlVGVtcGxhdGVGaWxlKGAke2Jhc2VQYXRofS9SRUFETUUubWRgLCByZWFkbWVDb250ZW50KVxuICB9XG59XG4iLCAiLy8gQ291cnNlIGNyZWF0aW9uIHdpemFyZCBmb3IgVHVja2VycyBUb29scyBwbHVnaW5cblxuaW1wb3J0IHsgQXBwLCBOb3RpY2UsIFRGaWxlIH0gZnJvbSBcIm9ic2lkaWFuXCJcbmltcG9ydCB7IFR1Y2tlcnNUb29sc1NldHRpbmdzIH0gZnJvbSBcIi4vc2V0dGluZ3NcIlxuaW1wb3J0IHsgc2x1Z2lmeSB9IGZyb20gXCIuL3V0aWxzXCJcbmltcG9ydCB7IElucHV0TW9kYWwsIFN1Z2dlc3Rlck1vZGFsIH0gZnJvbSBcIi4vaW5wdXRNb2RhbFwiXG5pbXBvcnQgeyBUZW1wbGF0ZU1hbmFnZXIgfSBmcm9tIFwiLi90ZW1wbGF0ZU1hbmFnZXJcIlxuXG5leHBvcnQgY2xhc3MgQ291cnNlQ3JlYXRpb25XaXphcmQge1xuICBhcHA6IEFwcFxuICBzZXR0aW5nczogVHVja2Vyc1Rvb2xzU2V0dGluZ3NcblxuICBjb25zdHJ1Y3RvcihhcHA6IEFwcCwgc2V0dGluZ3M6IFR1Y2tlcnNUb29sc1NldHRpbmdzKSB7XG4gICAgdGhpcy5hcHAgPSBhcHBcbiAgICB0aGlzLnNldHRpbmdzID0gc2V0dGluZ3NcbiAgfVxuXG4gIGFzeW5jIGNyZWF0ZUNvdXJzZUhvbWVwYWdlKCkge1xuICAgIHRyeSB7XG4gICAgICAvLyBQcm9tcHQgdXNlciBmb3IgY291cnNlIGRldGFpbHNcbiAgICAgIGNvbnN0IGNvdXJzZURldGFpbHMgPSBhd2FpdCB0aGlzLnByb21wdENvdXJzZURldGFpbHMoKVxuXG4gICAgICBpZiAoIWNvdXJzZURldGFpbHMpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlIC8vIFVzZXIgY2FuY2VsbGVkXG4gICAgICB9XG5cbiAgICAgIC8vIENyZWF0ZSBmb2xkZXIgc3RydWN0dXJlXG4gICAgICBjb25zdCBmb2xkZXJQYXRoID0gYXdhaXQgdGhpcy5jcmVhdGVDb3Vyc2VGb2xkZXJTdHJ1Y3R1cmUoY291cnNlRGV0YWlscylcblxuICAgICAgLy8gR2VuZXJhdGUgY291cnNlIGhvbWVwYWdlIG5vdGVcbiAgICAgIGF3YWl0IHRoaXMuY3JlYXRlQ291cnNlSG9tZXBhZ2VOb3RlKGNvdXJzZURldGFpbHMsIGZvbGRlclBhdGgpXG5cbiAgICAgIC8vIENyZWF0ZSBhdHRhY2htZW50cyBmb2xkZXJcbiAgICAgIGF3YWl0IHRoaXMuY3JlYXRlQXR0YWNobWVudHNGb2xkZXIoZm9sZGVyUGF0aClcblxuICAgICAgbmV3IE5vdGljZShgQ291cnNlIFwiJHtjb3Vyc2VEZXRhaWxzLmNvdXJzZU5hbWV9XCIgY3JlYXRlZCBzdWNjZXNzZnVsbHkhYClcbiAgICAgIGNvbnNvbGUubG9nKFxuICAgICAgICBgQ291cnNlIGNyZWF0ZWQ6ICR7Y291cnNlRGV0YWlscy5jb3Vyc2VOYW1lfSBhdCAke2ZvbGRlclBhdGh9YFxuICAgICAgKVxuXG4gICAgICByZXR1cm4gdHJ1ZVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgY3JlYXRpbmcgY291cnNlOlwiLCBlcnJvcilcbiAgICAgIG5ldyBOb3RpY2UoYEVycm9yIGNyZWF0aW5nIGNvdXJzZTogJHtlcnJvci5tZXNzYWdlfWApXG4gICAgICByZXR1cm4gZmFsc2VcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIHByb21wdENvdXJzZURldGFpbHMoKTogUHJvbWlzZTx7XG4gICAgY291cnNlTmFtZTogc3RyaW5nXG4gICAgY291cnNlU2Vhc29uOiBzdHJpbmdcbiAgICBjb3Vyc2VZZWFyOiBzdHJpbmdcbiAgICBjb3Vyc2VJZDogc3RyaW5nXG4gIH0gfCBudWxsPiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGNvdXJzZU5hbWUgPSBhd2FpdCB0aGlzLnByb21wdFdpdGhWYWxpZGF0aW9uKFxuICAgICAgICBcIkNvdXJzZSBOYW1lXCIsXG4gICAgICAgIFwiRW50ZXIgY291cnNlIG5hbWUgKGUuZy4sIFBTSS0xMDEgLSBJbnRybyB0byBQc3ljaG9sb2d5KVwiLFxuICAgICAgICAodmFsdWUpID0+IHZhbHVlLnRyaW0oKS5sZW5ndGggPiAwLFxuICAgICAgICBcIkNvdXJzZSBuYW1lIGlzIHJlcXVpcmVkXCJcbiAgICAgIClcblxuICAgICAgaWYgKCFjb3Vyc2VOYW1lKSByZXR1cm4gbnVsbFxuXG4gICAgICBjb25zdCBjb3Vyc2VTZWFzb24gPSBhd2FpdCB0aGlzLnByb21wdFdpdGhPcHRpb25zKFxuICAgICAgICBcIlNlYXNvblwiLFxuICAgICAgICBcIlNlbGVjdCBzZW1lc3Rlci9zZWFzb25cIixcbiAgICAgICAgW1wiRmFsbFwiLCBcIldpbnRlclwiLCBcIlNwcmluZ1wiLCBcIlN1bW1lclwiXVxuICAgICAgKVxuXG4gICAgICBpZiAoIWNvdXJzZVNlYXNvbikgcmV0dXJuIG51bGxcblxuICAgICAgY29uc3QgY291cnNlWWVhciA9IGF3YWl0IHRoaXMucHJvbXB0V2l0aFZhbGlkYXRpb24oXG4gICAgICAgIFwiWWVhclwiLFxuICAgICAgICBcIkVudGVyIGFjYWRlbWljIHllYXIgKGUuZy4sIDIwMjUpXCIsXG4gICAgICAgICh2YWx1ZSkgPT4gL15cXGR7NH0kLy50ZXN0KHZhbHVlLnRyaW0oKSksXG4gICAgICAgIFwiUGxlYXNlIGVudGVyIGEgdmFsaWQgNC1kaWdpdCB5ZWFyXCJcbiAgICAgIClcblxuICAgICAgaWYgKCFjb3Vyc2VZZWFyKSByZXR1cm4gbnVsbFxuXG4gICAgICBjb25zdCBjb3Vyc2VJZCA9IGNvdXJzZU5hbWUuc3BsaXQoXCIgLSBcIilbMF0/LnRyaW0oKSB8fCBzbHVnaWZ5KGNvdXJzZU5hbWUpXG5cbiAgICAgIHJldHVybiB7XG4gICAgICAgIGNvdXJzZU5hbWUsXG4gICAgICAgIGNvdXJzZVNlYXNvbixcbiAgICAgICAgY291cnNlWWVhcixcbiAgICAgICAgY291cnNlSWRcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHByb21wdGluZyBmb3IgY291cnNlIGRldGFpbHM6XCIsIGVycm9yKVxuICAgICAgcmV0dXJuIG51bGxcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIHByb21wdFdpdGhWYWxpZGF0aW9uKFxuICAgIHRpdGxlOiBzdHJpbmcsXG4gICAgbWVzc2FnZTogc3RyaW5nLFxuICAgIHZhbGlkYXRvcjogKHZhbHVlOiBzdHJpbmcpID0+IGJvb2xlYW4sXG4gICAgZXJyb3JNZXNzYWdlOiBzdHJpbmdcbiAgKTogUHJvbWlzZTxzdHJpbmcgfCBudWxsPiB7XG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG4gICAgICBjb25zdCBtb2RhbCA9IG5ldyBJbnB1dE1vZGFsKHRoaXMuYXBwLCAocmVzdWx0KSA9PiB7XG4gICAgICAgIGlmIChyZXN1bHQgPT09IG51bGwpIHtcbiAgICAgICAgICAvLyBVc2VyIGNhbmNlbGxlZFxuICAgICAgICAgIHJlc29sdmUobnVsbCk7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKCF2YWxpZGF0b3IocmVzdWx0KSkge1xuICAgICAgICAgIG5ldyBOb3RpY2UoZXJyb3JNZXNzYWdlKTtcbiAgICAgICAgICAvLyBSZWN1cnNpdmVseSBjYWxsIGFnYWluIGlmIHZhbGlkYXRpb24gZmFpbHNcbiAgICAgICAgICB0aGlzLnByb21wdFdpdGhWYWxpZGF0aW9uKHRpdGxlLCBtZXNzYWdlLCB2YWxpZGF0b3IsIGVycm9yTWVzc2FnZSlcbiAgICAgICAgICAgIC50aGVuKHJlc29sdmUpO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIHJlc29sdmUocmVzdWx0LnRyaW0oKSk7XG4gICAgICB9KTtcblxuICAgICAgLy8gU2V0IHRoZSB0aXRsZSBhbmQgbWVzc2FnZSBkaWZmZXJlbnRseSBzaW5jZSBvdXIgbW9kYWwgaXMgc2ltcGxlXG4gICAgICBtb2RhbC50aXRsZUVsLnNldFRleHQodGl0bGUpO1xuICAgICAgY29uc3QgbWVzc2FnZUVsID0gbW9kYWwuY29udGVudEVsLmNyZWF0ZURpdigpO1xuICAgICAgbWVzc2FnZUVsLnNldFRleHQobWVzc2FnZSk7XG5cbiAgICAgIG1vZGFsLm9wZW4oKTtcbiAgICB9KTtcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgcHJvbXB0V2l0aE9wdGlvbnMoXG4gICAgdGl0bGU6IHN0cmluZyxcbiAgICBtZXNzYWdlOiBzdHJpbmcsXG4gICAgb3B0aW9uczogc3RyaW5nW11cbiAgKTogUHJvbWlzZTxzdHJpbmcgfCBudWxsPiB7XG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG4gICAgICBjb25zdCBtb2RhbCA9IG5ldyBTdWdnZXN0ZXJNb2RhbCh0aGlzLmFwcCwgb3B0aW9ucywgKHJlc3VsdCkgPT4ge1xuICAgICAgICBpZiAocmVzdWx0ID09PSBudWxsKSB7XG4gICAgICAgICAgLy8gVXNlciBjYW5jZWxsZWRcbiAgICAgICAgICByZXNvbHZlKG51bGwpO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChvcHRpb25zLmluY2x1ZGVzKHJlc3VsdCkpIHtcbiAgICAgICAgICByZXNvbHZlKHJlc3VsdCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgbmV3IE5vdGljZShgUGxlYXNlIHNlbGVjdCBvbmUgb2Y6ICR7b3B0aW9ucy5qb2luKFwiLCBcIil9YCk7XG4gICAgICAgICAgLy8gUmVjdXJzaXZlbHkgY2FsbCBhZ2FpbiBpZiBjaG9pY2UgaXMgaW52YWxpZFxuICAgICAgICAgIHRoaXMucHJvbXB0V2l0aE9wdGlvbnModGl0bGUsIG1lc3NhZ2UsIG9wdGlvbnMpXG4gICAgICAgICAgICAudGhlbihyZXNvbHZlKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG5cbiAgICAgIC8vIFNldCB0aGUgdGl0bGVcbiAgICAgIG1vZGFsLnRpdGxlRWwuc2V0VGV4dCh0aXRsZSk7XG4gICAgICBjb25zdCBtZXNzYWdlRWwgPSBtb2RhbC5jb250ZW50RWwuY3JlYXRlRGl2KCk7XG4gICAgICBtZXNzYWdlRWwuc2V0VGV4dChtZXNzYWdlKTtcblxuICAgICAgbW9kYWwub3BlbigpO1xuICAgIH0pO1xuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBjcmVhdGVDb3Vyc2VGb2xkZXJTdHJ1Y3R1cmUoY291cnNlRGV0YWlsczoge1xuICAgIGNvdXJzZU5hbWU6IHN0cmluZ1xuICAgIGNvdXJzZVNlYXNvbjogc3RyaW5nXG4gICAgY291cnNlWWVhcjogc3RyaW5nXG4gICAgY291cnNlSWQ6IHN0cmluZ1xuICB9KTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgICBjb25zdCBmb2xkZXJQYXRoID0gYCR7Y291cnNlRGV0YWlscy5jb3Vyc2VZZWFyfS8ke2NvdXJzZURldGFpbHMuY291cnNlU2Vhc29ufS8ke2NvdXJzZURldGFpbHMuY291cnNlTmFtZX1gXG5cbiAgICB0cnkge1xuICAgICAgYXdhaXQgdGhpcy5hcHAudmF1bHQuY3JlYXRlRm9sZGVyKGZvbGRlclBhdGgpXG4gICAgICBjb25zb2xlLmxvZyhgQ3JlYXRlZCBjb3Vyc2UgZm9sZGVyOiAke2ZvbGRlclBhdGh9YClcbiAgICAgIHJldHVybiBmb2xkZXJQYXRoXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIC8vIEZvbGRlciBtaWdodCBhbHJlYWR5IGV4aXN0LCB3aGljaCBpcyBmaW5lIGZvciBub3dcbiAgICAgIGNvbnNvbGUubG9nKGBDb3Vyc2UgZm9sZGVyIGFscmVhZHkgZXhpc3RzIG9yIGNyZWF0ZWQ6ICR7Zm9sZGVyUGF0aH1gKVxuICAgICAgcmV0dXJuIGZvbGRlclBhdGhcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIGNyZWF0ZUNvdXJzZUhvbWVwYWdlTm90ZShcbiAgICBjb3Vyc2VEZXRhaWxzOiB7XG4gICAgICBjb3Vyc2VOYW1lOiBzdHJpbmdcbiAgICAgIGNvdXJzZVNlYXNvbjogc3RyaW5nXG4gICAgICBjb3Vyc2VZZWFyOiBzdHJpbmdcbiAgICAgIGNvdXJzZUlkOiBzdHJpbmdcbiAgICB9LFxuICAgIGZvbGRlclBhdGg6IHN0cmluZ1xuICApOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBjb25zdCBub3RlUGF0aCA9IGAke2ZvbGRlclBhdGh9LyR7Y291cnNlRGV0YWlscy5jb3Vyc2VOYW1lfS5tZGBcbiAgICBjb25zdCBjb250ZW50ID0gdGhpcy5nZW5lcmF0ZUNvdXJzZUhvbWVwYWdlQ29udGVudChjb3Vyc2VEZXRhaWxzKVxuXG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IHRoaXMuYXBwLnZhdWx0LmNyZWF0ZShub3RlUGF0aCwgY29udGVudClcbiAgICAgIGNvbnNvbGUubG9nKGBDcmVhdGVkIGNvdXJzZSBob21lcGFnZTogJHtub3RlUGF0aH1gKVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKGBFcnJvciBjcmVhdGluZyBjb3Vyc2UgaG9tZXBhZ2U6ICR7ZXJyb3J9YClcbiAgICAgIHRocm93IGVycm9yXG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBjcmVhdGVBdHRhY2htZW50c0ZvbGRlcihmb2xkZXJQYXRoOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBjb25zdCBhdHRhY2htZW50c1BhdGggPSBgJHtmb2xkZXJQYXRofS9BdHRhY2htZW50c2BcblxuICAgIHRyeSB7XG4gICAgICBhd2FpdCB0aGlzLmFwcC52YXVsdC5jcmVhdGVGb2xkZXIoYXR0YWNobWVudHNQYXRoKVxuICAgICAgY29uc29sZS5sb2coYENyZWF0ZWQgYXR0YWNobWVudHMgZm9sZGVyOiAke2F0dGFjaG1lbnRzUGF0aH1gKVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAvLyBGb2xkZXIgbWlnaHQgYWxyZWFkeSBleGlzdCwgd2hpY2ggaXMgZmluZVxuICAgICAgY29uc29sZS5sb2coYEF0dGFjaG1lbnRzIGZvbGRlciBhbHJlYWR5IGV4aXN0czogJHthdHRhY2htZW50c1BhdGh9YClcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGdlbmVyYXRlQ291cnNlSG9tZXBhZ2VDb250ZW50KGNvdXJzZURldGFpbHM6IHtcbiAgICBjb3Vyc2VOYW1lOiBzdHJpbmdcbiAgICBjb3Vyc2VTZWFzb246IHN0cmluZ1xuICAgIGNvdXJzZVllYXI6IHN0cmluZ1xuICAgIGNvdXJzZUlkOiBzdHJpbmdcbiAgfSk6IHN0cmluZyB7XG4gICAgLy8gVXNlIHRoZSB0ZW1wbGF0ZU1hbmFnZXIgdG8gZ2V0IHRoZSB0ZW1wbGF0ZSBjb250ZW50IGFuZCByZXBsYWNlIHZhbHVlc1xuICAgIGNvbnN0IHRlbXBsYXRlTWFuYWdlciA9IG5ldyBUZW1wbGF0ZU1hbmFnZXIodGhpcy5hcHAsIHRoaXMuc2V0dGluZ3MpO1xuICAgIGNvbnN0IHRlbXBsYXRlQ29udGVudCA9IHRlbXBsYXRlTWFuYWdlci5nZW5lcmF0ZUNvdXJzZUhvbWVwYWdlVGVtcGxhdGUoKTtcbiAgICBcbiAgICAvLyBSZXBsYWNlIHRlbXBsYXRlIHZhcmlhYmxlcyB3aXRoIGFjdHVhbCB2YWx1ZXNcbiAgICByZXR1cm4gdGVtcGxhdGVDb250ZW50XG4gICAgICAucmVwbGFjZSgvPCUgY291cnNlTmFtZSAlPi9nLCBjb3Vyc2VEZXRhaWxzLmNvdXJzZU5hbWUpXG4gICAgICAucmVwbGFjZSgvPCUgY291cnNlU2Vhc29uICU+L2csIGNvdXJzZURldGFpbHMuY291cnNlU2Vhc29uKVxuICAgICAgLnJlcGxhY2UoLzwlIGNvdXJzZVllYXIgJT4vZywgY291cnNlRGV0YWlscy5jb3Vyc2VZZWFyKVxuICAgICAgLnJlcGxhY2UoLzwlIGNvdXJzZUlkICU+L2csIGNvdXJzZURldGFpbHMuY291cnNlSWQpXG4gICAgICAucmVwbGFjZSgvPCUgdHBcXC5kYXRlXFwubm93XFwoXCJZWVlZLU1NLUREXFxbVFxcXUhIOm1tOnNzWlwiXFwpICU+L2csIG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSlcbiAgICAgIC5yZXBsYWNlKC88JSB0cFxcLmRhdGVcXC5ub3dcXChcIllZWVktTU0tRERcXFtUXFxdaGg6bW06U1NTU1paXCJcXCkgJT4vZywgbmV3IERhdGUoKS50b0lTT1N0cmluZygpKTtcbiAgfVxufVxuIiwgImltcG9ydCB7IEFwcCwgTW9kYWwsIFNldHRpbmcgfSBmcm9tIFwib2JzaWRpYW5cIjtcblxuZXhwb3J0IGNsYXNzIElucHV0TW9kYWwgZXh0ZW5kcyBNb2RhbCB7XG4gIHJlc3VsdDogc3RyaW5nIHwgbnVsbDtcbiAgb25TdWJtaXQ6IChyZXN1bHQ6IHN0cmluZyB8IG51bGwpID0+IHZvaWQ7XG5cbiAgY29uc3RydWN0b3IoYXBwOiBBcHAsIG9uU3VibWl0OiAocmVzdWx0OiBzdHJpbmcgfCBudWxsKSA9PiB2b2lkKSB7XG4gICAgc3VwZXIoYXBwKTtcbiAgICB0aGlzLm9uU3VibWl0ID0gb25TdWJtaXQ7XG4gIH1cblxuICBvbk9wZW4oKSB7XG4gICAgY29uc3QgeyBjb250ZW50RWwgfSA9IHRoaXM7XG5cbiAgICBjb250ZW50RWwuY3JlYXRlRWwoXCJoMlwiLCB7IHRleHQ6IFwiRW50ZXIgVmFsdWVcIiB9KTtcblxuICAgIG5ldyBTZXR0aW5nKGNvbnRlbnRFbClcbiAgICAgIC5zZXROYW1lKFwiVmFsdWVcIilcbiAgICAgIC5hZGRUZXh0KCh0ZXh0KSA9PiBcbiAgICAgICAgdGV4dFxuICAgICAgICAgIC5vbkNoYW5nZSgodmFsdWUpID0+IHtcbiAgICAgICAgICAgIHRoaXMucmVzdWx0ID0gdmFsdWU7XG4gICAgICAgICAgfSlcbiAgICAgICAgICAuaW5wdXRFbC5mb2N1cygpXG4gICAgICApO1xuXG4gICAgbmV3IFNldHRpbmcoY29udGVudEVsKVxuICAgICAgLmFkZEJ1dHRvbigoYnRuKSA9PlxuICAgICAgICBidG5cbiAgICAgICAgICAuc2V0QnV0dG9uVGV4dChcIlN1Ym1pdFwiKVxuICAgICAgICAgIC5zZXRDdGEoKVxuICAgICAgICAgIC5vbkNsaWNrKCgpID0+IHtcbiAgICAgICAgICAgIHRoaXMuY2xvc2UoKTtcbiAgICAgICAgICAgIHRoaXMub25TdWJtaXQodGhpcy5yZXN1bHQgfHwgXCJcIik7XG4gICAgICAgICAgfSlcbiAgICAgIClcbiAgICAgIC5hZGRCdXR0b24oKGJ0bikgPT5cbiAgICAgICAgYnRuLnNldEJ1dHRvblRleHQoXCJDYW5jZWxcIikub25DbGljaygoKSA9PiB7XG4gICAgICAgICAgdGhpcy5jbG9zZSgpO1xuICAgICAgICAgIHRoaXMub25TdWJtaXQobnVsbCk7XG4gICAgICAgIH0pXG4gICAgICApO1xuICB9XG5cbiAgb25DbG9zZSgpIHtcbiAgICBjb25zdCB7IGNvbnRlbnRFbCB9ID0gdGhpcztcbiAgICBjb250ZW50RWwuZW1wdHkoKTtcbiAgfVxufVxuXG5leHBvcnQgY2xhc3MgU3VnZ2VzdGVyTW9kYWwgZXh0ZW5kcyBNb2RhbCB7XG4gIHJlc3VsdDogc3RyaW5nIHwgbnVsbDtcbiAgb25TdWJtaXQ6IChyZXN1bHQ6IHN0cmluZyB8IG51bGwpID0+IHZvaWQ7XG5cbiAgY29uc3RydWN0b3IoYXBwOiBBcHAsIG9wdGlvbnM6IHN0cmluZ1tdLCBvblN1Ym1pdDogKHJlc3VsdDogc3RyaW5nIHwgbnVsbCkgPT4gdm9pZCkge1xuICAgIHN1cGVyKGFwcCk7XG4gICAgdGhpcy5vblN1Ym1pdCA9IG9uU3VibWl0O1xuXG4gICAgLy8gQ3JlYXRlIGEgZHJvcGRvd24gd2l0aCB0aGUgcHJvdmlkZWQgb3B0aW9uc1xuICAgIGNvbnN0IGRyb3Bkb3duT3B0aW9uczogeyBba2V5OiBzdHJpbmddOiBzdHJpbmcgfSA9IHt9O1xuICAgIG9wdGlvbnMuZm9yRWFjaChvcHRpb24gPT4ge1xuICAgICAgZHJvcGRvd25PcHRpb25zW29wdGlvbl0gPSBvcHRpb247XG4gICAgfSk7XG4gICAgXG4gICAgdGhpcy5jcmVhdGVEcm9wZG93bihkcm9wZG93bk9wdGlvbnMpO1xuICB9XG5cbiAgY3JlYXRlRHJvcGRvd24ob3B0aW9uczogeyBba2V5OiBzdHJpbmddOiBzdHJpbmcgfSkge1xuICAgIGNvbnN0IHsgY29udGVudEVsIH0gPSB0aGlzO1xuXG4gICAgY29udGVudEVsLmNyZWF0ZUVsKFwiaDJcIiwgeyB0ZXh0OiBcIlNlbGVjdCBPcHRpb25cIiB9KTtcblxuICAgIGxldCBzZWxlY3RlZFZhbHVlID0gT2JqZWN0LmtleXMob3B0aW9ucylbMF0gfHwgbnVsbDsgLy8gRGVmYXVsdCB0byBmaXJzdCBvcHRpb24gb3IgbnVsbFxuXG4gICAgY29uc3QgZHJvcGRvd24gPSBjb250ZW50RWwuY3JlYXRlRWwoXCJzZWxlY3RcIik7XG4gICAgT2JqZWN0LmVudHJpZXMob3B0aW9ucykuZm9yRWFjaCgoW2tleSwgdmFsdWVdKSA9PiB7XG4gICAgICBjb25zdCBvcHRpb24gPSBkcm9wZG93bi5jcmVhdGVFbChcIm9wdGlvblwiLCB7XG4gICAgICAgIHZhbHVlOiBrZXksXG4gICAgICAgIHRleHQ6IHZhbHVlXG4gICAgICB9KTtcbiAgICAgIGlmIChrZXkgPT09IHNlbGVjdGVkVmFsdWUpIHtcbiAgICAgICAgb3B0aW9uLnNlbGVjdGVkID0gdHJ1ZTtcbiAgICAgIH1cbiAgICB9KTtcblxuICAgIGRyb3Bkb3duLmFkZEV2ZW50TGlzdGVuZXIoXCJjaGFuZ2VcIiwgKGV2ZW50KSA9PiB7XG4gICAgICBzZWxlY3RlZFZhbHVlID0gKGV2ZW50LnRhcmdldCBhcyBIVE1MU2VsZWN0RWxlbWVudCkudmFsdWU7XG4gICAgICB0aGlzLnJlc3VsdCA9IHNlbGVjdGVkVmFsdWU7XG4gICAgfSk7XG5cbiAgICBuZXcgU2V0dGluZyhjb250ZW50RWwpXG4gICAgICAuYWRkQnV0dG9uKChidG4pID0+XG4gICAgICAgIGJ0blxuICAgICAgICAgIC5zZXRCdXR0b25UZXh0KFwiU3VibWl0XCIpXG4gICAgICAgICAgLnNldEN0YSgpXG4gICAgICAgICAgLm9uQ2xpY2soKCkgPT4ge1xuICAgICAgICAgICAgdGhpcy5jbG9zZSgpO1xuICAgICAgICAgICAgdGhpcy5vblN1Ym1pdChzZWxlY3RlZFZhbHVlKTtcbiAgICAgICAgICB9KVxuICAgICAgKVxuICAgICAgLmFkZEJ1dHRvbigoYnRuKSA9PlxuICAgICAgICBidG4uc2V0QnV0dG9uVGV4dChcIkNhbmNlbFwiKS5vbkNsaWNrKCgpID0+IHtcbiAgICAgICAgICB0aGlzLmNsb3NlKCk7XG4gICAgICAgICAgdGhpcy5vblN1Ym1pdChudWxsKTtcbiAgICAgICAgfSlcbiAgICAgICk7XG4gIH1cblxuICBvbk9wZW4oKSB7XG4gICAgLy8gVGhlIGRyb3Bkb3duIGlzIGFscmVhZHkgY3JlYXRlZCBpbiBjb25zdHJ1Y3RvclxuICB9XG5cbiAgb25DbG9zZSgpIHtcbiAgICBjb25zdCB7IGNvbnRlbnRFbCB9ID0gdGhpcztcbiAgICBjb250ZW50RWwuZW1wdHkoKTtcbiAgfVxufSIsICIvLyBWb2NhYnVsYXJ5IGV4dHJhY3Rpb24gZm9yIFR1Y2tlcnMgVG9vbHMgcGx1Z2luXG5cbmltcG9ydCB7IEFwcCwgVEZpbGUgfSBmcm9tIFwib2JzaWRpYW5cIlxuaW1wb3J0IHsgZ2V0Q291cnNlSWRGcm9tUGF0aCB9IGZyb20gXCIuL3V0aWxzXCJcblxuZXhwb3J0IGNsYXNzIFZvY2FidWxhcnlFeHRyYWN0b3Ige1xuICBhcHA6IEFwcFxuXG4gIGNvbnN0cnVjdG9yKGFwcDogQXBwKSB7XG4gICAgdGhpcy5hcHAgPSBhcHBcbiAgfVxuXG4gIGV4dHJhY3RWb2NhYnVsYXJ5RnJvbU5vdGUoY29udGVudDogc3RyaW5nKTogc3RyaW5nW10ge1xuICAgIC8vIEV4dHJhY3Qgdm9jYWJ1bGFyeSBzZWN0aW9uIGZyb20gbm90ZSBjb250ZW50XG4gICAgY29uc3Qgdm9jYWJSZWdleCA9IC9eIysgVm9jYWJ1bGFyeS4qXFxuKCg/Oi4qP1xcbikqPykoPz1eXFxzKiNcXHN8JCkvbVxuICAgIGNvbnN0IHZvY2FiTWF0Y2hlcyA9IGNvbnRlbnQ/Lm1hdGNoKHZvY2FiUmVnZXgpXG5cbiAgICBpZiAodm9jYWJNYXRjaGVzKSB7XG4gICAgICBjb25zdCB2b2NhYkRhdGEgPSB2b2NhYk1hdGNoZXNbMV0udHJpbSgpXG4gICAgICBjb25zdCBjbGVhbmVkVm9jYWIgPSB2b2NhYkRhdGFcbiAgICAgICAgLnJlcGxhY2UoL1xcW1xcWy4qP1xcXVxcXS9nLCBcIlwiKSAvLyBSZW1vdmUgd2lraWxpbmtzXG4gICAgICAgIC5yZXBsYWNlKC9eXFxzKi1cXHMqL2dtLCBcIlwiKSAvLyBSZW1vdmUgYnVsbGV0IHBvaW50c1xuICAgICAgICAuc3BsaXQoXCJcXG5cIilcbiAgICAgICAgLm1hcCgodGVybSkgPT4gdGVybS50cmltKCkpXG4gICAgICAgIC5maWx0ZXIoKHRlcm0pID0+IHRlcm0ubGVuZ3RoID4gMClcblxuICAgICAgcmV0dXJuIGNsZWFuZWRWb2NhYlxuICAgIH1cblxuICAgIHJldHVybiBbXVxuICB9XG5cbiAgYXN5bmMgZXh0cmFjdFZvY2FidWxhcnlGcm9tQ291cnNlKFxuICAgIGNvdXJzZUlkOiBzdHJpbmdcbiAgKTogUHJvbWlzZTxSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT4+IHtcbiAgICBjb25zb2xlLmxvZyhgRXh0cmFjdGluZyB2b2NhYnVsYXJ5IGZvciBjb3Vyc2U6ICR7Y291cnNlSWR9YClcblxuICAgIHRyeSB7XG4gICAgICAvLyBGaW5kIGFsbCBub3RlcyByZWxhdGVkIHRvIHRoZSBjb3Vyc2VcbiAgICAgIGNvbnN0IGNvdXJzZU5vdGVzID0gYXdhaXQgdGhpcy5maW5kQ291cnNlTm90ZXMoY291cnNlSWQpXG5cbiAgICAgIGlmIChjb3Vyc2VOb3Rlcy5sZW5ndGggPT09IDApIHtcbiAgICAgICAgY29uc29sZS5sb2coYE5vIG5vdGVzIGZvdW5kIGZvciBjb3Vyc2U6ICR7Y291cnNlSWR9YClcbiAgICAgICAgcmV0dXJuIHt9XG4gICAgICB9XG5cbiAgICAgIC8vIEV4dHJhY3Qgdm9jYWJ1bGFyeSBmcm9tIGVhY2ggbm90ZVxuICAgICAgY29uc3Qgdm9jYWJ1bGFyeURhdGE6IFJlY29yZDxzdHJpbmcsIHN0cmluZ1tdPiA9IHt9XG5cbiAgICAgIGZvciAoY29uc3Qgbm90ZSBvZiBjb3Vyc2VOb3Rlcykge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGNvbnN0IGNvbnRlbnQgPSBhd2FpdCB0aGlzLmFwcC52YXVsdC5yZWFkKG5vdGUpXG4gICAgICAgICAgY29uc3Qgdm9jYWJ1bGFyeSA9IHRoaXMuZXh0cmFjdFZvY2FidWxhcnlGcm9tTm90ZShjb250ZW50KVxuXG4gICAgICAgICAgaWYgKHZvY2FidWxhcnkubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgdm9jYWJ1bGFyeURhdGFbbm90ZS5iYXNlbmFtZV0gPSB2b2NhYnVsYXJ5XG4gICAgICAgICAgfVxuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIHJlYWRpbmcgbm90ZSAke25vdGUucGF0aH06YCwgZXJyb3IpXG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgY29uc29sZS5sb2coXG4gICAgICAgIGBFeHRyYWN0ZWQgdm9jYWJ1bGFyeSBmcm9tICR7XG4gICAgICAgICAgT2JqZWN0LmtleXModm9jYWJ1bGFyeURhdGEpLmxlbmd0aFxuICAgICAgICB9IG5vdGVzIGZvciBjb3Vyc2U6ICR7Y291cnNlSWR9YFxuICAgICAgKVxuICAgICAgcmV0dXJuIHZvY2FidWxhcnlEYXRhXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXG4gICAgICAgIGBFcnJvciBleHRyYWN0aW5nIHZvY2FidWxhcnkgZm9yIGNvdXJzZSAke2NvdXJzZUlkfTpgLFxuICAgICAgICBlcnJvclxuICAgICAgKVxuICAgICAgcmV0dXJuIHt9XG4gICAgfVxuICB9XG5cbiAgYXN5bmMgZmluZENvdXJzZU5vdGVzKGNvdXJzZUlkOiBzdHJpbmcpOiBQcm9taXNlPFRGaWxlW10+IHtcbiAgICBjb25zdCBub3RlczogVEZpbGVbXSA9IFtdXG5cbiAgICAvLyBHZXQgYWxsIG1hcmtkb3duIGZpbGVzIGluIHRoZSB2YXVsdFxuICAgIGNvbnN0IGZpbGVzID0gdGhpcy5hcHAudmF1bHQuZ2V0TWFya2Rvd25GaWxlcygpXG5cbiAgICBmb3IgKGNvbnN0IGZpbGUgb2YgZmlsZXMpIHtcbiAgICAgIC8vIENoZWNrIGlmIHRoZSBmaWxlIHBhdGggY29udGFpbnMgdGhlIGNvdXJzZSBJRFxuICAgICAgaWYgKFxuICAgICAgICBmaWxlLnBhdGguaW5jbHVkZXMoY291cnNlSWQpIHx8XG4gICAgICAgIChhd2FpdCB0aGlzLm5vdGVCZWxvbmdzVG9Db3Vyc2UoZmlsZSwgY291cnNlSWQpKVxuICAgICAgKSB7XG4gICAgICAgIG5vdGVzLnB1c2goZmlsZSlcbiAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gbm90ZXNcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgbm90ZUJlbG9uZ3NUb0NvdXJzZShcbiAgICBmaWxlOiBURmlsZSxcbiAgICBjb3Vyc2VJZDogc3RyaW5nXG4gICk6IFByb21pc2U8Ym9vbGVhbj4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBjb250ZW50ID0gYXdhaXQgdGhpcy5hcHAudmF1bHQucmVhZChmaWxlKVxuICAgICAgY29uc3QgZnJvbnRtYXR0ZXJNYXRjaCA9IGNvbnRlbnQubWF0Y2goL14tLS1cXG4oW1xcc1xcU10qPylcXG4tLS0vKVxuXG4gICAgICBpZiAoZnJvbnRtYXR0ZXJNYXRjaCkge1xuICAgICAgICBjb25zdCBmcm9udG1hdHRlciA9IGZyb250bWF0dGVyTWF0Y2hbMV1cbiAgICAgICAgLy8gQ2hlY2sgaWYgY291cnNlX2lkIGlzIGluIHRoZSBmcm9udG1hdHRlclxuICAgICAgICByZXR1cm4gKFxuICAgICAgICAgIGZyb250bWF0dGVyLmluY2x1ZGVzKGBjb3Vyc2VfaWQ6ICR7Y291cnNlSWR9YCkgfHxcbiAgICAgICAgICBmcm9udG1hdHRlci5pbmNsdWRlcyhgY291cnNlX2lkOiR7Y291cnNlSWR9YClcbiAgICAgICAgKVxuICAgICAgfVxuXG4gICAgICByZXR1cm4gZmFsc2VcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihcbiAgICAgICAgYEVycm9yIGNoZWNraW5nIGlmIG5vdGUgJHtmaWxlLnBhdGh9IGJlbG9uZ3MgdG8gY291cnNlICR7Y291cnNlSWR9OmAsXG4gICAgICAgIGVycm9yXG4gICAgICApXG4gICAgICByZXR1cm4gZmFsc2VcbiAgICB9XG4gIH1cblxuICBhc3luYyBnZW5lcmF0ZVZvY2FidWxhcnlJbmRleChcbiAgICBjb3Vyc2VJZDogc3RyaW5nLFxuICAgIHZvY2FidWxhcnlEYXRhOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT5cbiAgKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgICBjb25zdCBhbGxUZXJtczogc3RyaW5nW10gPSBbXVxuICAgIGNvbnN0IHRlcm1Tb3VyY2VzOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT4gPSB7fVxuXG4gICAgLy8gQ29sbGVjdCBhbGwgdW5pcXVlIHRlcm1zIGFuZCB0aGVpciBzb3VyY2VzXG4gICAgZm9yIChjb25zdCBbbm90ZU5hbWUsIHRlcm1zXSBvZiBPYmplY3QuZW50cmllcyh2b2NhYnVsYXJ5RGF0YSkpIHtcbiAgICAgIGZvciAoY29uc3QgdGVybSBvZiB0ZXJtcykge1xuICAgICAgICBpZiAoIWFsbFRlcm1zLmluY2x1ZGVzKHRlcm0pKSB7XG4gICAgICAgICAgYWxsVGVybXMucHVzaCh0ZXJtKVxuICAgICAgICAgIHRlcm1Tb3VyY2VzW3Rlcm1dID0gW11cbiAgICAgICAgfVxuICAgICAgICB0ZXJtU291cmNlc1t0ZXJtXS5wdXNoKG5vdGVOYW1lKVxuICAgICAgfVxuICAgIH1cblxuICAgIC8vIFNvcnQgdGVybXMgYWxwaGFiZXRpY2FsbHlcbiAgICBhbGxUZXJtcy5zb3J0KClcblxuICAgIC8vIEdlbmVyYXRlIG1hcmtkb3duIGNvbnRlbnRcbiAgICBsZXQgY29udGVudCA9IGAjIFZvY2FidWxhcnkgSW5kZXggLSAke2NvdXJzZUlkfVxcblxcbmBcbiAgICBjb250ZW50ICs9IGBUb3RhbCB1bmlxdWUgdGVybXM6ICR7YWxsVGVybXMubGVuZ3RofVxcblxcbmBcblxuICAgIGZvciAoY29uc3QgdGVybSBvZiBhbGxUZXJtcykge1xuICAgICAgY29udGVudCArPSBgIyMgJHt0ZXJtfVxcbmBcbiAgICAgIGNvbnRlbnQgKz0gYCoqU291cmNlczoqKiAke3Rlcm1Tb3VyY2VzW3Rlcm1dLmpvaW4oXCIsIFwiKX1cXG5cXG5gXG4gICAgICBjb250ZW50ICs9IGAqKkRlZmluaXRpb246KipcXG5cXG5gXG4gICAgICBjb250ZW50ICs9IGAqKkNvbnRleHQ6KipcXG5cXG5gXG4gICAgICBjb250ZW50ICs9IGAqKkV4YW1wbGVzOioqXFxuXFxuYFxuICAgICAgY29udGVudCArPSBgLS0tXFxuXFxuYFxuICAgIH1cblxuICAgIHJldHVybiBjb250ZW50XG4gIH1cblxuICBhc3luYyBjcmVhdGVWb2NhYnVsYXJ5SW5kZXhGaWxlKGNvdXJzZUlkOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3Qgdm9jYWJ1bGFyeURhdGEgPSBhd2FpdCB0aGlzLmV4dHJhY3RWb2NhYnVsYXJ5RnJvbUNvdXJzZShjb3Vyc2VJZClcblxuICAgICAgaWYgKE9iamVjdC5rZXlzKHZvY2FidWxhcnlEYXRhKS5sZW5ndGggPT09IDApIHtcbiAgICAgICAgY29uc29sZS5sb2coYE5vIHZvY2FidWxhcnkgZm91bmQgZm9yIGNvdXJzZTogJHtjb3Vyc2VJZH1gKVxuICAgICAgICByZXR1cm5cbiAgICAgIH1cblxuICAgICAgY29uc3QgaW5kZXhDb250ZW50ID0gYXdhaXQgdGhpcy5nZW5lcmF0ZVZvY2FidWxhcnlJbmRleChcbiAgICAgICAgY291cnNlSWQsXG4gICAgICAgIHZvY2FidWxhcnlEYXRhXG4gICAgICApXG5cbiAgICAgIC8vIENyZWF0ZSB0aGUgaW5kZXggZmlsZVxuICAgICAgY29uc3QgZmlsZU5hbWUgPSBgJHtjb3Vyc2VJZH0gLSBWb2NhYnVsYXJ5IEluZGV4Lm1kYFxuICAgICAgY29uc3QgZmlsZVBhdGggPSBgQ291cnNlcy8ke2NvdXJzZUlkfS8ke2ZpbGVOYW1lfWBcblxuICAgICAgdHJ5IHtcbiAgICAgICAgYXdhaXQgdGhpcy5hcHAudmF1bHQuY3JlYXRlKGZpbGVQYXRoLCBpbmRleENvbnRlbnQpXG4gICAgICAgIGNvbnNvbGUubG9nKGBDcmVhdGVkIHZvY2FidWxhcnkgaW5kZXggZmlsZTogJHtmaWxlUGF0aH1gKVxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgLy8gRmlsZSBtaWdodCBhbHJlYWR5IGV4aXN0LCB0cnkgdG8gdXBkYXRlIGl0XG4gICAgICAgIGNvbnN0IGV4aXN0aW5nRmlsZSA9IHRoaXMuYXBwLnZhdWx0LmdldEFic3RyYWN0RmlsZUJ5UGF0aChmaWxlUGF0aClcbiAgICAgICAgaWYgKGV4aXN0aW5nRmlsZSAmJiBleGlzdGluZ0ZpbGUgaW5zdGFuY2VvZiBURmlsZSkge1xuICAgICAgICAgIGF3YWl0IHRoaXMuYXBwLnZhdWx0Lm1vZGlmeShleGlzdGluZ0ZpbGUsIGluZGV4Q29udGVudClcbiAgICAgICAgICBjb25zb2xlLmxvZyhgVXBkYXRlZCB2b2NhYnVsYXJ5IGluZGV4IGZpbGU6ICR7ZmlsZVBhdGh9YClcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFxuICAgICAgICBgRXJyb3IgY3JlYXRpbmcgdm9jYWJ1bGFyeSBpbmRleCBmb3IgY291cnNlICR7Y291cnNlSWR9OmAsXG4gICAgICAgIGVycm9yXG4gICAgICApXG4gICAgICB0aHJvdyBlcnJvclxuICAgIH1cbiAgfVxufVxuIiwgImltcG9ydCB7IEFwcCwgVEZpbGUgfSBmcm9tIFwib2JzaWRpYW5cIlxuaW1wb3J0IHsgaXNCZXR3ZWVuIH0gZnJvbSBcIi4vdXRpbHNcIlxuXG5leHBvcnQgY2xhc3MgRHVlRGF0ZXNQYXJzZXIge1xuICBhcHA6IEFwcFxuXG4gIGNvbnN0cnVjdG9yKGFwcDogQXBwKSB7XG4gICAgdGhpcy5hcHAgPSBhcHBcbiAgfVxuXG4gIHBhcnNlRHVlRGF0ZXNGcm9tTm90ZShcbiAgICBjb250ZW50OiBzdHJpbmdcbiAgKTogQXJyYXk8eyBkYXRlOiBzdHJpbmc7IGFzc2lnbm1lbnQ6IHN0cmluZzsgc3RhdHVzOiBzdHJpbmcgfT4ge1xuICAgIC8vIEV4dHJhY3QgZHVlIGRhdGVzIHNlY3Rpb24gZnJvbSBub3RlIGNvbnRlbnRcbiAgICBjb25zdCBkdWVEYXRlc1JlZ2V4ID0gLyMgRHVlIERhdGVzW1xcc1xcU10qPyg/PVxcbiN8JCkvXG4gICAgY29uc3QgbWF0Y2hlcyA9IGNvbnRlbnQ/Lm1hdGNoKGR1ZURhdGVzUmVnZXgpXG5cbiAgICBpZiAoIW1hdGNoZXMpIHtcbiAgICAgIHJldHVybiBbXVxuICAgIH1cblxuICAgIGNvbnN0IGR1ZURhdGVzU2VjdGlvbiA9IG1hdGNoZXNbMF1cbiAgICBjb25zdCBkdWVEYXRlcyA9IFtdXG5cbiAgICAvLyBMb29rIGZvciBtYXJrZG93biB0YWJsZXMgaW4gdGhlIGR1ZSBkYXRlcyBzZWN0aW9uXG4gICAgY29uc3QgdGFibGVSZWdleCA9IC9cXHxbXFxzXFxTXSo/XFxuL2dcbiAgICBjb25zdCB0YWJsZU1hdGNoZXMgPSBkdWVEYXRlc1NlY3Rpb24ubWF0Y2godGFibGVSZWdleClcblxuICAgIGlmICh0YWJsZU1hdGNoZXMpIHtcbiAgICAgIGZvciAoY29uc3QgdGFibGUgb2YgdGFibGVNYXRjaGVzKSB7XG4gICAgICAgIGNvbnN0IHJvd3MgPSB0YWJsZVxuICAgICAgICAgIC50cmltKClcbiAgICAgICAgICAuc3BsaXQoXCJcXG5cIilcbiAgICAgICAgICAuZmlsdGVyKChyb3cpID0+IHJvdy5zdGFydHNXaXRoKFwifFwiKSlcbiAgICAgICAgY29uc3QgcGFyc2VkUm93cyA9IHRoaXMucGFyc2VUYWJsZVJvd3Mocm93cylcbiAgICAgICAgZHVlRGF0ZXMucHVzaCguLi5wYXJzZWRSb3dzKVxuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBkdWVEYXRlc1xuICB9XG5cbiAgcHJpdmF0ZSBwYXJzZVRhYmxlUm93cyhcbiAgICByb3dzOiBzdHJpbmdbXVxuICApOiBBcnJheTx7IGRhdGU6IHN0cmluZzsgYXNzaWdubWVudDogc3RyaW5nOyBzdGF0dXM6IHN0cmluZyB9PiB7XG4gICAgaWYgKHJvd3MubGVuZ3RoIDwgMikgcmV0dXJuIFtdIC8vIE5lZWQgYXQgbGVhc3QgaGVhZGVyICsgMSBkYXRhIHJvd1xuXG4gICAgY29uc3QgZHVlRGF0ZXMgPSBbXVxuXG4gICAgZm9yIChsZXQgaSA9IDE7IGkgPCByb3dzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAvLyBTa2lwIGhlYWRlciByb3dcbiAgICAgIGNvbnN0IHJvdyA9IHJvd3NbaV1cbiAgICAgIGNvbnN0IGNvbHVtbnMgPSByb3dcbiAgICAgICAgLnNwbGl0KFwifFwiKVxuICAgICAgICAubWFwKChjb2wpID0+IGNvbC50cmltKCkpXG4gICAgICAgIC5maWx0ZXIoKGNvbCkgPT4gY29sKVxuXG4gICAgICBpZiAoY29sdW1ucy5sZW5ndGggPj0gMikge1xuICAgICAgICBjb25zdCBbZGF0ZSwgYXNzaWdubWVudCwgc3RhdHVzID0gXCJwZW5kaW5nXCJdID0gY29sdW1uc1xuICAgICAgICBpZiAoZGF0ZSAmJiBhc3NpZ25tZW50ICYmIHRoaXMuaXNWYWxpZERhdGUoZGF0ZSkpIHtcbiAgICAgICAgICBkdWVEYXRlcy5wdXNoKHsgZGF0ZSwgYXNzaWdubWVudCwgc3RhdHVzIH0pXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gZHVlRGF0ZXNcbiAgfVxuXG4gIHByaXZhdGUgaXNWYWxpZERhdGUoZGF0ZVN0cmluZzogc3RyaW5nKTogYm9vbGVhbiB7XG4gICAgY29uc3QgZGF0ZVJlZ2V4ID0gL15cXGR7NH0tXFxkezJ9LVxcZHsyfSQvXG4gICAgcmV0dXJuIGRhdGVSZWdleC50ZXN0KGRhdGVTdHJpbmcpICYmICFpc05hTihEYXRlLnBhcnNlKGRhdGVTdHJpbmcpKVxuICB9XG5cbiAgYXN5bmMgcGFyc2VEdWVEYXRlc0Zyb21Db3Vyc2UoXG4gICAgY291cnNlSWQ6IHN0cmluZyxcbiAgICBzdGFydERhdGU/OiBzdHJpbmcsXG4gICAgZW5kRGF0ZT86IHN0cmluZ1xuICApOiBQcm9taXNlPFxuICAgIEFycmF5PHsgZGF0ZTogc3RyaW5nOyBhc3NpZ25tZW50OiBzdHJpbmc7IHN0YXR1czogc3RyaW5nOyBzb3VyY2U6IHN0cmluZyB9PlxuICA+IHtcbiAgICBjb25zb2xlLmxvZyhgUGFyc2luZyBkdWUgZGF0ZXMgZm9yIGNvdXJzZTogJHtjb3Vyc2VJZH1gKVxuXG4gICAgdHJ5IHtcbiAgICAgIC8vIEZpbmQgYWxsIG5vdGVzIHJlbGF0ZWQgdG8gdGhlIGNvdXJzZVxuICAgICAgY29uc3QgY291cnNlTm90ZXMgPSBhd2FpdCB0aGlzLmZpbmRDb3Vyc2VOb3Rlcyhjb3Vyc2VJZClcblxuICAgICAgaWYgKGNvdXJzZU5vdGVzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICBjb25zb2xlLmxvZyhgTm8gbm90ZXMgZm91bmQgZm9yIGNvdXJzZTogJHtjb3Vyc2VJZH1gKVxuICAgICAgICByZXR1cm4gW11cbiAgICAgIH1cblxuICAgICAgLy8gUGFyc2UgZHVlIGRhdGVzIGZyb20gZWFjaCBub3RlXG4gICAgICBjb25zdCBhbGxEdWVEYXRlczogQXJyYXk8e1xuICAgICAgICBkYXRlOiBzdHJpbmdcbiAgICAgICAgYXNzaWdubWVudDogc3RyaW5nXG4gICAgICAgIHN0YXR1czogc3RyaW5nXG4gICAgICAgIHNvdXJjZTogc3RyaW5nXG4gICAgICB9PiA9IFtdXG5cbiAgICAgIGZvciAoY29uc3Qgbm90ZSBvZiBjb3Vyc2VOb3Rlcykge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGNvbnN0IGNvbnRlbnQgPSBhd2FpdCB0aGlzLmFwcC52YXVsdC5yZWFkKG5vdGUpXG4gICAgICAgICAgY29uc3QgZHVlRGF0ZXMgPSB0aGlzLnBhcnNlRHVlRGF0ZXNGcm9tTm90ZShjb250ZW50KVxuXG4gICAgICAgICAgLy8gQWRkIHNvdXJjZSBpbmZvcm1hdGlvblxuICAgICAgICAgIGNvbnN0IGR1ZURhdGVzV2l0aFNvdXJjZSA9IGR1ZURhdGVzLm1hcCgoZHVlRGF0ZSkgPT4gKHtcbiAgICAgICAgICAgIC4uLmR1ZURhdGUsXG4gICAgICAgICAgICBzb3VyY2U6IG5vdGUuYmFzZW5hbWVcbiAgICAgICAgICB9KSlcblxuICAgICAgICAgIGFsbER1ZURhdGVzLnB1c2goLi4uZHVlRGF0ZXNXaXRoU291cmNlKVxuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIHJlYWRpbmcgbm90ZSAke25vdGUucGF0aH06YCwgZXJyb3IpXG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgLy8gRmlsdGVyIGJ5IGRhdGUgcmFuZ2UgaWYgcHJvdmlkZWRcbiAgICAgIGxldCBmaWx0ZXJlZER1ZURhdGVzID0gYWxsRHVlRGF0ZXNcbiAgICAgIGlmIChzdGFydERhdGUgfHwgZW5kRGF0ZSkge1xuICAgICAgICBmaWx0ZXJlZER1ZURhdGVzID0gdGhpcy5maWx0ZXJCeURhdGVSYW5nZShcbiAgICAgICAgICBhbGxEdWVEYXRlcyxcbiAgICAgICAgICBzdGFydERhdGUsXG4gICAgICAgICAgZW5kRGF0ZVxuICAgICAgICApXG4gICAgICB9XG5cbiAgICAgIC8vIFNvcnQgYnkgZGF0ZVxuICAgICAgZmlsdGVyZWREdWVEYXRlcy5zb3J0KFxuICAgICAgICAoYSwgYikgPT4gbmV3IERhdGUoYS5kYXRlKS5nZXRUaW1lKCkgLSBuZXcgRGF0ZShiLmRhdGUpLmdldFRpbWUoKVxuICAgICAgKVxuXG4gICAgICBjb25zb2xlLmxvZyhcbiAgICAgICAgYEZvdW5kICR7ZmlsdGVyZWREdWVEYXRlcy5sZW5ndGh9IGR1ZSBkYXRlcyBmb3IgY291cnNlOiAke2NvdXJzZUlkfWBcbiAgICAgIClcbiAgICAgIHJldHVybiBmaWx0ZXJlZER1ZURhdGVzXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIHBhcnNpbmcgZHVlIGRhdGVzIGZvciBjb3Vyc2UgJHtjb3Vyc2VJZH06YCwgZXJyb3IpXG4gICAgICByZXR1cm4gW11cbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIGZpbmRDb3Vyc2VOb3Rlcyhjb3Vyc2VJZDogc3RyaW5nKTogUHJvbWlzZTxURmlsZVtdPiB7XG4gICAgY29uc3Qgbm90ZXM6IFRGaWxlW10gPSBbXVxuXG4gICAgLy8gR2V0IGFsbCBtYXJrZG93biBmaWxlcyBpbiB0aGUgdmF1bHRcbiAgICBjb25zdCBmaWxlcyA9IHRoaXMuYXBwLnZhdWx0LmdldE1hcmtkb3duRmlsZXMoKVxuXG4gICAgZm9yIChjb25zdCBmaWxlIG9mIGZpbGVzKSB7XG4gICAgICAvLyBDaGVjayBpZiB0aGUgZmlsZSBwYXRoIGNvbnRhaW5zIHRoZSBjb3Vyc2UgSUQgb3IgYmVsb25ncyB0byB0aGUgY291cnNlXG4gICAgICBpZiAoXG4gICAgICAgIGZpbGUucGF0aC5pbmNsdWRlcyhjb3Vyc2VJZCkgfHxcbiAgICAgICAgKGF3YWl0IHRoaXMubm90ZUJlbG9uZ3NUb0NvdXJzZShmaWxlLCBjb3Vyc2VJZCkpXG4gICAgICApIHtcbiAgICAgICAgbm90ZXMucHVzaChmaWxlKVxuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBub3Rlc1xuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBub3RlQmVsb25nc1RvQ291cnNlKFxuICAgIGZpbGU6IFRGaWxlLFxuICAgIGNvdXJzZUlkOiBzdHJpbmdcbiAgKTogUHJvbWlzZTxib29sZWFuPiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGNvbnRlbnQgPSBhd2FpdCB0aGlzLmFwcC52YXVsdC5yZWFkKGZpbGUpXG4gICAgICBjb25zdCBmcm9udG1hdHRlck1hdGNoID0gY29udGVudC5tYXRjaCgvXi0tLVxcbihbXFxzXFxTXSo/KVxcbi0tLS8pXG5cbiAgICAgIGlmIChmcm9udG1hdHRlck1hdGNoKSB7XG4gICAgICAgIGNvbnN0IGZyb250bWF0dGVyID0gZnJvbnRtYXR0ZXJNYXRjaFsxXVxuICAgICAgICAvLyBDaGVjayBpZiBjb3Vyc2VfaWQgaXMgaW4gdGhlIGZyb250bWF0dGVyXG4gICAgICAgIHJldHVybiAoXG4gICAgICAgICAgZnJvbnRtYXR0ZXIuaW5jbHVkZXMoYGNvdXJzZV9pZDogJHtjb3Vyc2VJZH1gKSB8fFxuICAgICAgICAgIGZyb250bWF0dGVyLmluY2x1ZGVzKGBjb3Vyc2VfaWQ6JHtjb3Vyc2VJZH1gKVxuICAgICAgICApXG4gICAgICB9XG5cbiAgICAgIHJldHVybiBmYWxzZVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFxuICAgICAgICBgRXJyb3IgY2hlY2tpbmcgaWYgbm90ZSAke2ZpbGUucGF0aH0gYmVsb25ncyB0byBjb3Vyc2UgJHtjb3Vyc2VJZH06YCxcbiAgICAgICAgZXJyb3JcbiAgICAgIClcbiAgICAgIHJldHVybiBmYWxzZVxuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgZmlsdGVyQnlEYXRlUmFuZ2UoXG4gICAgZHVlRGF0ZXM6IEFycmF5PHtcbiAgICAgIGRhdGU6IHN0cmluZ1xuICAgICAgYXNzaWdubWVudDogc3RyaW5nXG4gICAgICBzdGF0dXM6IHN0cmluZ1xuICAgICAgc291cmNlOiBzdHJpbmdcbiAgICB9PixcbiAgICBzdGFydERhdGU/OiBzdHJpbmcsXG4gICAgZW5kRGF0ZT86IHN0cmluZ1xuICApOiBBcnJheTx7XG4gICAgZGF0ZTogc3RyaW5nXG4gICAgYXNzaWdubWVudDogc3RyaW5nXG4gICAgc3RhdHVzOiBzdHJpbmdcbiAgICBzb3VyY2U6IHN0cmluZ1xuICB9PiB7XG4gICAgcmV0dXJuIGR1ZURhdGVzLmZpbHRlcigoZHVlRGF0ZSkgPT4ge1xuICAgICAgY29uc3QgZHVlRGF0ZVRpbWUgPSBuZXcgRGF0ZShkdWVEYXRlLmRhdGUpLmdldFRpbWUoKVxuXG4gICAgICBpZiAoc3RhcnREYXRlICYmIGR1ZURhdGVUaW1lIDwgbmV3IERhdGUoc3RhcnREYXRlKS5nZXRUaW1lKCkpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlXG4gICAgICB9XG5cbiAgICAgIGlmIChlbmREYXRlICYmIGR1ZURhdGVUaW1lID4gbmV3IERhdGUoZW5kRGF0ZSkuZ2V0VGltZSgpKSB7XG4gICAgICAgIHJldHVybiBmYWxzZVxuICAgICAgfVxuXG4gICAgICByZXR1cm4gdHJ1ZVxuICAgIH0pXG4gIH1cblxuICBhc3luYyBnZW5lcmF0ZUR1ZURhdGVzU3VtbWFyeShcbiAgICBjb3Vyc2VJZDogc3RyaW5nLFxuICAgIGR1ZURhdGVzOiBBcnJheTx7XG4gICAgICBkYXRlOiBzdHJpbmdcbiAgICAgIGFzc2lnbm1lbnQ6IHN0cmluZ1xuICAgICAgc3RhdHVzOiBzdHJpbmdcbiAgICAgIHNvdXJjZTogc3RyaW5nXG4gICAgfT5cbiAgKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgICBpZiAoZHVlRGF0ZXMubGVuZ3RoID09PSAwKSB7XG4gICAgICByZXR1cm4gYCMgRHVlIERhdGVzIFN1bW1hcnkgLSAke2NvdXJzZUlkfVxcblxcbk5vIGR1ZSBkYXRlcyBmb3VuZC5cXG5gXG4gICAgfVxuXG4gICAgLy8gR3JvdXAgYnkgc3RhdHVzXG4gICAgY29uc3QgYnlTdGF0dXMgPSBkdWVEYXRlcy5yZWR1Y2UoKGFjYywgZHVlRGF0ZSkgPT4ge1xuICAgICAgaWYgKCFhY2NbZHVlRGF0ZS5zdGF0dXNdKSB7XG4gICAgICAgIGFjY1tkdWVEYXRlLnN0YXR1c10gPSBbXVxuICAgICAgfVxuICAgICAgYWNjW2R1ZURhdGUuc3RhdHVzXS5wdXNoKGR1ZURhdGUpXG4gICAgICByZXR1cm4gYWNjXG4gICAgfSwge30gYXMgUmVjb3JkPHN0cmluZywgdHlwZW9mIGR1ZURhdGVzPilcblxuICAgIGxldCBjb250ZW50ID0gYCMgRHVlIERhdGVzIFN1bW1hcnkgLSAke2NvdXJzZUlkfVxcblxcbmBcbiAgICBjb250ZW50ICs9IGBUb3RhbCBhc3NpZ25tZW50czogJHtkdWVEYXRlcy5sZW5ndGh9XFxuXFxuYFxuXG4gICAgLy8gQWRkIHN1bW1hcnkgYnkgc3RhdHVzXG4gICAgZm9yIChjb25zdCBbc3RhdHVzLCBpdGVtc10gb2YgT2JqZWN0LmVudHJpZXMoYnlTdGF0dXMpKSB7XG4gICAgICBjb250ZW50ICs9IGAjIyAke3N0YXR1cy5jaGFyQXQoMCkudG9VcHBlckNhc2UoKSArIHN0YXR1cy5zbGljZSgxKX0gKCR7XG4gICAgICAgIGl0ZW1zLmxlbmd0aFxuICAgICAgfSlcXG5cXG5gXG4gICAgICBjb250ZW50ICs9IGB8IERhdGUgfCBBc3NpZ25tZW50IHwgU291cmNlIHxcXG5gXG4gICAgICBjb250ZW50ICs9IGB8IC0tLS0gfCAtLS0tLS0tLS0tIHwgLS0tLS0tIHxcXG5gXG5cbiAgICAgIGZvciAoY29uc3QgaXRlbSBvZiBpdGVtcykge1xuICAgICAgICBjb250ZW50ICs9IGB8ICR7aXRlbS5kYXRlfSB8ICR7aXRlbS5hc3NpZ25tZW50fSB8ICR7aXRlbS5zb3VyY2V9IHxcXG5gXG4gICAgICB9XG4gICAgICBjb250ZW50ICs9IGBcXG5gXG4gICAgfVxuXG4gICAgcmV0dXJuIGNvbnRlbnRcbiAgfVxuXG4gIGFzeW5jIGNyZWF0ZUR1ZURhdGVzU3VtbWFyeUZpbGUoXG4gICAgY291cnNlSWQ6IHN0cmluZyxcbiAgICBzdGFydERhdGU/OiBzdHJpbmcsXG4gICAgZW5kRGF0ZT86IHN0cmluZ1xuICApOiBQcm9taXNlPHZvaWQ+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgZHVlRGF0ZXMgPSBhd2FpdCB0aGlzLnBhcnNlRHVlRGF0ZXNGcm9tQ291cnNlKFxuICAgICAgICBjb3Vyc2VJZCxcbiAgICAgICAgc3RhcnREYXRlLFxuICAgICAgICBlbmREYXRlXG4gICAgICApXG5cbiAgICAgIGNvbnN0IHN1bW1hcnlDb250ZW50ID0gYXdhaXQgdGhpcy5nZW5lcmF0ZUR1ZURhdGVzU3VtbWFyeShcbiAgICAgICAgY291cnNlSWQsXG4gICAgICAgIGR1ZURhdGVzXG4gICAgICApXG5cbiAgICAgIC8vIENyZWF0ZSB0aGUgc3VtbWFyeSBmaWxlXG4gICAgICBjb25zdCBmaWxlTmFtZSA9IGAke2NvdXJzZUlkfSAtIER1ZSBEYXRlcyBTdW1tYXJ5Lm1kYFxuICAgICAgY29uc3QgZmlsZVBhdGggPSBgQ291cnNlcy8ke2NvdXJzZUlkfS8ke2ZpbGVOYW1lfWBcblxuICAgICAgdHJ5IHtcbiAgICAgICAgYXdhaXQgdGhpcy5hcHAudmF1bHQuY3JlYXRlKGZpbGVQYXRoLCBzdW1tYXJ5Q29udGVudClcbiAgICAgICAgY29uc29sZS5sb2coYENyZWF0ZWQgZHVlIGRhdGVzIHN1bW1hcnkgZmlsZTogJHtmaWxlUGF0aH1gKVxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgLy8gRmlsZSBtaWdodCBhbHJlYWR5IGV4aXN0LCB0cnkgdG8gdXBkYXRlIGl0XG4gICAgICAgIGNvbnN0IGV4aXN0aW5nRmlsZSA9IHRoaXMuYXBwLnZhdWx0LmdldEFic3RyYWN0RmlsZUJ5UGF0aChmaWxlUGF0aClcbiAgICAgICAgaWYgKGV4aXN0aW5nRmlsZSAmJiBleGlzdGluZ0ZpbGUgaW5zdGFuY2VvZiBURmlsZSkge1xuICAgICAgICAgIGF3YWl0IHRoaXMuYXBwLnZhdWx0Lm1vZGlmeShleGlzdGluZ0ZpbGUsIHN1bW1hcnlDb250ZW50KVxuICAgICAgICAgIGNvbnNvbGUubG9nKGBVcGRhdGVkIGR1ZSBkYXRlcyBzdW1tYXJ5IGZpbGU6ICR7ZmlsZVBhdGh9YClcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFxuICAgICAgICBgRXJyb3IgY3JlYXRpbmcgZHVlIGRhdGVzIHN1bW1hcnkgZm9yIGNvdXJzZSAke2NvdXJzZUlkfTpgLFxuICAgICAgICBlcnJvclxuICAgICAgKVxuICAgICAgdGhyb3cgZXJyb3JcbiAgICB9XG4gIH1cbn1cbiIsICIvLyBEYWlseSBub3RlcyBpbnRlZ3JhdGlvbiBmb3IgVHVja2VycyBUb29scyBwbHVnaW5cblxuaW1wb3J0IHsgQXBwLCBURmlsZSB9IGZyb20gXCJvYnNpZGlhblwiXG5cbmV4cG9ydCBjbGFzcyBEYWlseU5vdGVzSW50ZWdyYXRpb24ge1xuICBhcHA6IEFwcFxuXG4gIGNvbnN0cnVjdG9yKGFwcDogQXBwKSB7XG4gICAgdGhpcy5hcHAgPSBhcHBcbiAgfVxuXG4gIGFzeW5jIGdldFRvZGF5c0FjdGl2aXRpZXMoKTogUHJvbWlzZTxcbiAgICBBcnJheTx7IGZpbGU6IHN0cmluZzsgdHlwZTogc3RyaW5nOyBjb3Vyc2U/OiBzdHJpbmcgfT5cbiAgPiB7XG4gICAgY29uc29sZS5sb2coXCJHZXR0aW5nIHRvZGF5J3MgYWNhZGVtaWMgYWN0aXZpdGllc1wiKVxuXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHRvZGF5ID0gbmV3IERhdGUoKVxuICAgICAgY29uc3QgdG9kYXlTdHJpbmcgPSB0b2RheS50b0lTT1N0cmluZygpLnNwbGl0KFwiVFwiKVswXVxuXG4gICAgICAvLyBGaW5kIGZpbGVzIGNyZWF0ZWQgb3IgbW9kaWZpZWQgdG9kYXlcbiAgICAgIGNvbnN0IGZpbGVzID0gdGhpcy5hcHAudmF1bHQuZ2V0TWFya2Rvd25GaWxlcygpXG4gICAgICBjb25zdCB0b2RheXNGaWxlczogVEZpbGVbXSA9IFtdXG5cbiAgICAgIGZvciAoY29uc3QgZmlsZSBvZiBmaWxlcykge1xuICAgICAgICBjb25zdCBmaWxlRGF0ZSA9IHRoaXMuZXh0cmFjdERhdGVGcm9tUGF0aChmaWxlLnBhdGgpXG4gICAgICAgIGlmIChmaWxlRGF0ZSA9PT0gdG9kYXlTdHJpbmcpIHtcbiAgICAgICAgICB0b2RheXNGaWxlcy5wdXNoKGZpbGUpXG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgLy8gQW5hbHl6ZSBhY3Rpdml0aWVzXG4gICAgICBjb25zdCBhY3Rpdml0aWVzOiBBcnJheTx7IGZpbGU6IHN0cmluZzsgdHlwZTogc3RyaW5nOyBjb3Vyc2U/OiBzdHJpbmcgfT4gPVxuICAgICAgICBbXVxuXG4gICAgICBmb3IgKGNvbnN0IGZpbGUgb2YgdG9kYXlzRmlsZXMpIHtcbiAgICAgICAgY29uc3QgYWN0aXZpdHkgPSBhd2FpdCB0aGlzLmFuYWx5emVGaWxlQWN0aXZpdHkoZmlsZSlcbiAgICAgICAgaWYgKGFjdGl2aXR5KSB7XG4gICAgICAgICAgYWN0aXZpdGllcy5wdXNoKGFjdGl2aXR5KVxuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIGNvbnNvbGUubG9nKGBGb3VuZCAke2FjdGl2aXRpZXMubGVuZ3RofSBhY2FkZW1pYyBhY3Rpdml0aWVzIGZvciB0b2RheWApXG4gICAgICByZXR1cm4gYWN0aXZpdGllc1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZ2V0dGluZyB0b2RheSdzIGFjdGl2aXRpZXM6XCIsIGVycm9yKVxuICAgICAgcmV0dXJuIFtdXG4gICAgfVxuICB9XG5cbiAgYXN5bmMgZ2V0Q291cnNlQWN0aXZpdHlGb3JEYXRlKFxuICAgIGNvdXJzZUlkOiBzdHJpbmcsXG4gICAgZGF0ZTogc3RyaW5nXG4gICk6IFByb21pc2U8QXJyYXk8eyBmaWxlOiBzdHJpbmc7IHR5cGU6IHN0cmluZyB9Pj4ge1xuICAgIGNvbnNvbGUubG9nKGBHZXR0aW5nIGFjdGl2aXR5IGZvciBjb3Vyc2UgJHtjb3Vyc2VJZH0gb24gZGF0ZSAke2RhdGV9YClcblxuICAgIHRyeSB7XG4gICAgICAvLyBGaW5kIGZpbGVzIHJlbGF0ZWQgdG8gdGhlIGNvdXJzZSBtb2RpZmllZCBvbiB0aGUgZGF0ZVxuICAgICAgY29uc3QgY291cnNlRmlsZXMgPSBhd2FpdCB0aGlzLmZpbmRDb3Vyc2VGaWxlc0ZvckRhdGUoY291cnNlSWQsIGRhdGUpXG5cbiAgICAgIGNvbnN0IGFjdGl2aXRpZXM6IEFycmF5PHsgZmlsZTogc3RyaW5nOyB0eXBlOiBzdHJpbmcgfT4gPSBbXVxuXG4gICAgICBmb3IgKGNvbnN0IGZpbGUgb2YgY291cnNlRmlsZXMpIHtcbiAgICAgICAgY29uc3QgY29udGVudCA9IGF3YWl0IHRoaXMuYXBwLnZhdWx0LnJlYWQoZmlsZSlcbiAgICAgICAgY29uc3QgZmlsZVR5cGUgPSB0aGlzLmRldGVybWluZUZpbGVUeXBlKGZpbGUsIGNvbnRlbnQpXG5cbiAgICAgICAgYWN0aXZpdGllcy5wdXNoKHtcbiAgICAgICAgICBmaWxlOiBmaWxlLmJhc2VuYW1lLFxuICAgICAgICAgIHR5cGU6IGZpbGVUeXBlXG4gICAgICAgIH0pXG4gICAgICB9XG5cbiAgICAgIGNvbnNvbGUubG9nKFxuICAgICAgICBgRm91bmQgJHthY3Rpdml0aWVzLmxlbmd0aH0gYWN0aXZpdGllcyBmb3IgY291cnNlICR7Y291cnNlSWR9IG9uICR7ZGF0ZX1gXG4gICAgICApXG4gICAgICByZXR1cm4gYWN0aXZpdGllc1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFxuICAgICAgICBgRXJyb3IgZ2V0dGluZyBjb3Vyc2UgYWN0aXZpdHkgZm9yICR7Y291cnNlSWR9IG9uICR7ZGF0ZX06YCxcbiAgICAgICAgZXJyb3JcbiAgICAgIClcbiAgICAgIHJldHVybiBbXVxuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgZXh0cmFjdERhdGVGcm9tUGF0aChmaWxlUGF0aDogc3RyaW5nKTogc3RyaW5nIHwgbnVsbCB7XG4gICAgLy8gVHJ5IHRvIGV4dHJhY3QgZGF0ZSBmcm9tIGZpbGUgcGF0aCAoZS5nLiwgXCJEYWlseS8yMDI1LTAxLTE1Lm1kXCIgLT4gXCIyMDI1LTAxLTE1XCIpXG4gICAgY29uc3QgZGF0ZVJlZ2V4ID0gLyhcXGR7NH0tXFxkezJ9LVxcZHsyfSkvZ1xuICAgIGNvbnN0IG1hdGNoZXMgPSBmaWxlUGF0aC5tYXRjaChkYXRlUmVnZXgpXG4gICAgcmV0dXJuIG1hdGNoZXMgPyBtYXRjaGVzW21hdGNoZXMubGVuZ3RoIC0gMV0gOiBudWxsXG4gIH1cblxuICBwcml2YXRlIGFzeW5jIGFuYWx5emVGaWxlQWN0aXZpdHkoXG4gICAgZmlsZTogVEZpbGVcbiAgKTogUHJvbWlzZTx7IGZpbGU6IHN0cmluZzsgdHlwZTogc3RyaW5nOyBjb3Vyc2U/OiBzdHJpbmcgfSB8IG51bGw+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgY29udGVudCA9IGF3YWl0IHRoaXMuYXBwLnZhdWx0LnJlYWQoZmlsZSlcblxuICAgICAgLy8gRGV0ZXJtaW5lIGZpbGUgdHlwZSBiYXNlZCBvbiBjb250ZW50IGFuZCBwYXRoXG4gICAgICBjb25zdCBmaWxlVHlwZSA9IHRoaXMuZGV0ZXJtaW5lRmlsZVR5cGUoZmlsZSwgY29udGVudClcblxuICAgICAgLy8gRXh0cmFjdCBjb3Vyc2UgSUQgaWYgYXBwbGljYWJsZVxuICAgICAgY29uc3QgY291cnNlSWQgPVxuICAgICAgICB0aGlzLmV4dHJhY3RDb3Vyc2VJZEZyb21Db250ZW50KGNvbnRlbnQpIHx8XG4gICAgICAgIHRoaXMuZXh0cmFjdENvdXJzZUlkRnJvbVBhdGgoZmlsZS5wYXRoKVxuXG4gICAgICByZXR1cm4ge1xuICAgICAgICBmaWxlOiBmaWxlLmJhc2VuYW1lLFxuICAgICAgICB0eXBlOiBmaWxlVHlwZSxcbiAgICAgICAgY291cnNlOiBjb3Vyc2VJZCB8fCB1bmRlZmluZWRcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihgRXJyb3IgYW5hbHl6aW5nIGZpbGUgJHtmaWxlLnBhdGh9OmAsIGVycm9yKVxuICAgICAgcmV0dXJuIG51bGxcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGRldGVybWluZUZpbGVUeXBlKGZpbGU6IFRGaWxlLCBjb250ZW50OiBzdHJpbmcpOiBzdHJpbmcge1xuICAgIGNvbnN0IHBhdGggPSBmaWxlLnBhdGgudG9Mb3dlckNhc2UoKVxuXG4gICAgLy8gQ2hlY2sgZm9yIGRhaWx5IG5vdGVzXG4gICAgaWYgKFxuICAgICAgcGF0aC5pbmNsdWRlcyhcImRhaWx5XCIpIHx8XG4gICAgICBjb250ZW50LmluY2x1ZGVzKFwiY29udGVudF90eXBlOiBkYWlseV9ub3RlXCIpXG4gICAgKSB7XG4gICAgICByZXR1cm4gXCJkYWlseV9ub3RlXCJcbiAgICB9XG5cbiAgICAvLyBDaGVjayBmb3IgY291cnNlLXJlbGF0ZWQgZmlsZXNcbiAgICBpZiAocGF0aC5pbmNsdWRlcyhcImNvdXJzZXNcIikgfHwgY29udGVudC5pbmNsdWRlcyhcImNvdXJzZV9pZDpcIikpIHtcbiAgICAgIGlmIChjb250ZW50LmluY2x1ZGVzKFwiY29udGVudF90eXBlOiBjb3Vyc2VfaG9tZXBhZ2VcIikpIHtcbiAgICAgICAgcmV0dXJuIFwiY291cnNlX2hvbWVwYWdlXCJcbiAgICAgIH1cbiAgICAgIGlmIChjb250ZW50LmluY2x1ZGVzKFwiY29udGVudF90eXBlOiBtb2R1bGVcIikpIHtcbiAgICAgICAgcmV0dXJuIFwibW9kdWxlXCJcbiAgICAgIH1cbiAgICAgIGlmIChjb250ZW50LmluY2x1ZGVzKFwiY29udGVudF90eXBlOiBjaGFwdGVyXCIpKSB7XG4gICAgICAgIHJldHVybiBcImNoYXB0ZXJcIlxuICAgICAgfVxuICAgICAgaWYgKGNvbnRlbnQuaW5jbHVkZXMoXCJjb250ZW50X3R5cGU6IGFzc2lnbm1lbnRcIikpIHtcbiAgICAgICAgcmV0dXJuIFwiYXNzaWdubWVudFwiXG4gICAgICB9XG4gICAgICByZXR1cm4gXCJjb3Vyc2Vfbm90ZVwiXG4gICAgfVxuXG4gICAgLy8gQ2hlY2sgZm9yIHZvY2FidWxhcnkgZW50cmllc1xuICAgIGlmIChjb250ZW50LmluY2x1ZGVzKFwiIyMgXCIpICYmIGNvbnRlbnQubWF0Y2goL15cXCpcXCpUZXJtXFwqXFwqOi9tKSkge1xuICAgICAgcmV0dXJuIFwidm9jYWJ1bGFyeV9lbnRyeVwiXG4gICAgfVxuXG4gICAgcmV0dXJuIFwib3RoZXJcIlxuICB9XG5cbiAgcHJpdmF0ZSBleHRyYWN0Q291cnNlSWRGcm9tQ29udGVudChjb250ZW50OiBzdHJpbmcpOiBzdHJpbmcgfCBudWxsIHtcbiAgICBjb25zdCBjb3Vyc2VJZFJlZ2V4ID0gL2NvdXJzZV9pZDpcXHMqKFtBLVpdezIsNH0tXFxkezN9KS9cbiAgICBjb25zdCBtYXRjaCA9IGNvbnRlbnQubWF0Y2goY291cnNlSWRSZWdleClcbiAgICByZXR1cm4gbWF0Y2ggPyBtYXRjaFsxXSA6IG51bGxcbiAgfVxuXG4gIHByaXZhdGUgZXh0cmFjdENvdXJzZUlkRnJvbVBhdGgoZmlsZVBhdGg6IHN0cmluZyk6IHN0cmluZyB8IG51bGwge1xuICAgIGNvbnN0IGNvdXJzZUlkUmVnZXggPSAvKFtBLVpdezIsNH0tXFxkezN9KS9nXG4gICAgY29uc3QgbWF0Y2hlcyA9IGZpbGVQYXRoLm1hdGNoKGNvdXJzZUlkUmVnZXgpXG4gICAgcmV0dXJuIG1hdGNoZXMgPyBtYXRjaGVzW21hdGNoZXMubGVuZ3RoIC0gMV0gOiBudWxsXG4gIH1cblxuICBwcml2YXRlIGFzeW5jIGZpbmRDb3Vyc2VGaWxlc0ZvckRhdGUoXG4gICAgY291cnNlSWQ6IHN0cmluZyxcbiAgICBkYXRlOiBzdHJpbmdcbiAgKTogUHJvbWlzZTxURmlsZVtdPiB7XG4gICAgY29uc3QgZmlsZXM6IFRGaWxlW10gPSBbXVxuXG4gICAgLy8gR2V0IGFsbCBmaWxlcyBhbmQgZmlsdGVyIGJ5IGNvdXJzZSBJRCBhbmQgZGF0ZVxuICAgIGNvbnN0IGFsbEZpbGVzID0gdGhpcy5hcHAudmF1bHQuZ2V0TWFya2Rvd25GaWxlcygpXG5cbiAgICBmb3IgKGNvbnN0IGZpbGUgb2YgYWxsRmlsZXMpIHtcbiAgICAgIC8vIENoZWNrIGlmIGZpbGUgYmVsb25ncyB0byB0aGUgY291cnNlXG4gICAgICBpZiAoXG4gICAgICAgIGZpbGUucGF0aC5pbmNsdWRlcyhjb3Vyc2VJZCkgfHxcbiAgICAgICAgKGF3YWl0IHRoaXMuZmlsZUJlbG9uZ3NUb0NvdXJzZShmaWxlLCBjb3Vyc2VJZCkpXG4gICAgICApIHtcbiAgICAgICAgLy8gQ2hlY2sgaWYgZmlsZSB3YXMgbW9kaWZpZWQgb24gdGhlIHNwZWNpZmllZCBkYXRlXG4gICAgICAgIGNvbnN0IGZpbGVEYXRlID0gdGhpcy5leHRyYWN0RGF0ZUZyb21QYXRoKGZpbGUucGF0aClcbiAgICAgICAgaWYgKGZpbGVEYXRlID09PSBkYXRlKSB7XG4gICAgICAgICAgZmlsZXMucHVzaChmaWxlKVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIGZpbGVzXG4gIH1cblxuICBwcml2YXRlIGFzeW5jIGZpbGVCZWxvbmdzVG9Db3Vyc2UoXG4gICAgZmlsZTogVEZpbGUsXG4gICAgY291cnNlSWQ6IHN0cmluZ1xuICApOiBQcm9taXNlPGJvb2xlYW4+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgY29udGVudCA9IGF3YWl0IHRoaXMuYXBwLnZhdWx0LnJlYWQoZmlsZSlcbiAgICAgIHJldHVybiB0aGlzLmV4dHJhY3RDb3Vyc2VJZEZyb21Db250ZW50KGNvbnRlbnQpID09PSBjb3Vyc2VJZFxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFxuICAgICAgICBgRXJyb3IgY2hlY2tpbmcgaWYgZmlsZSAke2ZpbGUucGF0aH0gYmVsb25ncyB0byBjb3Vyc2UgJHtjb3Vyc2VJZH06YCxcbiAgICAgICAgZXJyb3JcbiAgICAgIClcbiAgICAgIHJldHVybiBmYWxzZVxuICAgIH1cbiAgfVxuXG4gIGFzeW5jIGdlbmVyYXRlRGFpbHlTdW1tYXJ5KGRhdGU/OiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz4ge1xuICAgIGNvbnN0IHRhcmdldERhdGUgPSBkYXRlIHx8IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zcGxpdChcIlRcIilbMF1cbiAgICBjb25zdCBhY3Rpdml0aWVzID0gYXdhaXQgdGhpcy5nZXRDb3Vyc2VBY3Rpdml0eUZvckRhdGUoXCJcIiwgdGFyZ2V0RGF0ZSlcblxuICAgIGlmIChhY3Rpdml0aWVzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgcmV0dXJuIGAjIEFjYWRlbWljIEFjdGl2aXRpZXMgLSAke3RhcmdldERhdGV9XFxuXFxuTm8gYWNhZGVtaWMgYWN0aXZpdGllcyByZWNvcmRlZCBmb3IgdGhpcyBkYXRlLlxcbmBcbiAgICB9XG5cbiAgICAvLyBHcm91cCBhY3Rpdml0aWVzIGJ5IGNvdXJzZVxuICAgIGNvbnN0IGJ5Q291cnNlOiBSZWNvcmQ8c3RyaW5nLCB0eXBlb2YgYWN0aXZpdGllcz4gPSB7fVxuICAgIGNvbnN0IG5vQ291cnNlOiB0eXBlb2YgYWN0aXZpdGllcyA9IFtdXG5cbiAgICBmb3IgKGNvbnN0IGFjdGl2aXR5IG9mIGFjdGl2aXRpZXMpIHtcbiAgICAgIGlmIChhY3Rpdml0eS5maWxlLmluY2x1ZGVzKFwiQ291cnNlcy9cIikpIHtcbiAgICAgICAgLy8gRXh0cmFjdCBjb3Vyc2UgSUQgZnJvbSBwYXRoXG4gICAgICAgIGNvbnN0IHBhdGhQYXJ0cyA9IGFjdGl2aXR5LmZpbGUuc3BsaXQoXCIvXCIpXG4gICAgICAgIGNvbnN0IGNvdXJzZUluZGV4ID0gcGF0aFBhcnRzLmZpbmRJbmRleCgocGFydCkgPT4gcGFydC5pbmNsdWRlcyhcIi1cIikpXG4gICAgICAgIGlmIChjb3Vyc2VJbmRleCA+PSAwKSB7XG4gICAgICAgICAgY29uc3QgY291cnNlSWQgPSBwYXRoUGFydHNbY291cnNlSW5kZXhdXG4gICAgICAgICAgaWYgKCFieUNvdXJzZVtjb3Vyc2VJZF0pIHtcbiAgICAgICAgICAgIGJ5Q291cnNlW2NvdXJzZUlkXSA9IFtdXG4gICAgICAgICAgfVxuICAgICAgICAgIGJ5Q291cnNlW2NvdXJzZUlkXS5wdXNoKGFjdGl2aXR5KVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIG5vQ291cnNlLnB1c2goYWN0aXZpdHkpXG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIG5vQ291cnNlLnB1c2goYWN0aXZpdHkpXG4gICAgICB9XG4gICAgfVxuXG4gICAgbGV0IGNvbnRlbnQgPSBgIyBBY2FkZW1pYyBBY3Rpdml0aWVzIC0gJHt0YXJnZXREYXRlfVxcblxcbmBcbiAgICBjb250ZW50ICs9IGBUb3RhbCBhY3Rpdml0aWVzOiAke2FjdGl2aXRpZXMubGVuZ3RofVxcblxcbmBcblxuICAgIC8vIEFkZCBhY3Rpdml0aWVzIGJ5IGNvdXJzZVxuICAgIGZvciAoY29uc3QgW2NvdXJzZUlkLCBjb3Vyc2VBY3Rpdml0aWVzXSBvZiBPYmplY3QuZW50cmllcyhieUNvdXJzZSkpIHtcbiAgICAgIGNvbnRlbnQgKz0gYCMjICR7Y291cnNlSWR9XFxuXFxuYFxuICAgICAgY29udGVudCArPSBgfCBGaWxlIHwgVHlwZSB8XFxuYFxuICAgICAgY29udGVudCArPSBgfCAtLS0tIHwgLS0tLSB8XFxuYFxuXG4gICAgICBmb3IgKGNvbnN0IGFjdGl2aXR5IG9mIGNvdXJzZUFjdGl2aXRpZXMpIHtcbiAgICAgICAgY29udGVudCArPSBgfCAke2FjdGl2aXR5LmZpbGV9IHwgJHthY3Rpdml0eS50eXBlfSB8XFxuYFxuICAgICAgfVxuICAgICAgY29udGVudCArPSBgXFxuYFxuICAgIH1cblxuICAgIC8vIEFkZCBhY3Rpdml0aWVzIHdpdGhvdXQgc3BlY2lmaWMgY291cnNlXG4gICAgaWYgKG5vQ291cnNlLmxlbmd0aCA+IDApIHtcbiAgICAgIGNvbnRlbnQgKz0gYCMjIE90aGVyIEFjdGl2aXRpZXNcXG5cXG5gXG4gICAgICBjb250ZW50ICs9IGB8IEZpbGUgfCBUeXBlIHxcXG5gXG4gICAgICBjb250ZW50ICs9IGB8IC0tLS0gfCAtLS0tIHxcXG5gXG5cbiAgICAgIGZvciAoY29uc3QgYWN0aXZpdHkgb2Ygbm9Db3Vyc2UpIHtcbiAgICAgICAgY29udGVudCArPSBgfCAke2FjdGl2aXR5LmZpbGV9IHwgJHthY3Rpdml0eS50eXBlfSB8XFxuYFxuICAgICAgfVxuICAgICAgY29udGVudCArPSBgXFxuYFxuICAgIH1cblxuICAgIHJldHVybiBjb250ZW50XG4gIH1cblxuICBhc3luYyBjcmVhdGVEYWlseVN1bW1hcnlGaWxlKGRhdGU/OiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgdGFyZ2V0RGF0ZSA9IGRhdGUgfHwgbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNwbGl0KFwiVFwiKVswXVxuICAgICAgY29uc3Qgc3VtbWFyeUNvbnRlbnQgPSBhd2FpdCB0aGlzLmdlbmVyYXRlRGFpbHlTdW1tYXJ5KHRhcmdldERhdGUpXG5cbiAgICAgIC8vIENyZWF0ZSB0aGUgc3VtbWFyeSBmaWxlXG4gICAgICBjb25zdCBmaWxlTmFtZSA9IGAke3RhcmdldERhdGV9IC0gQWNhZGVtaWMgU3VtbWFyeS5tZGBcbiAgICAgIGNvbnN0IGZpbGVQYXRoID0gYERhaWx5LyR7ZmlsZU5hbWV9YFxuXG4gICAgICB0cnkge1xuICAgICAgICBhd2FpdCB0aGlzLmFwcC52YXVsdC5jcmVhdGUoZmlsZVBhdGgsIHN1bW1hcnlDb250ZW50KVxuICAgICAgICBjb25zb2xlLmxvZyhgQ3JlYXRlZCBkYWlseSBzdW1tYXJ5IGZpbGU6ICR7ZmlsZVBhdGh9YClcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIC8vIEZpbGUgbWlnaHQgYWxyZWFkeSBleGlzdCwgdHJ5IHRvIHVwZGF0ZSBpdFxuICAgICAgICBjb25zdCBleGlzdGluZ0ZpbGUgPSB0aGlzLmFwcC52YXVsdC5nZXRBYnN0cmFjdEZpbGVCeVBhdGgoZmlsZVBhdGgpXG4gICAgICAgIGlmIChleGlzdGluZ0ZpbGUgJiYgZXhpc3RpbmdGaWxlIGluc3RhbmNlb2YgVEZpbGUpIHtcbiAgICAgICAgICBhd2FpdCB0aGlzLmFwcC52YXVsdC5tb2RpZnkoZXhpc3RpbmdGaWxlLCBzdW1tYXJ5Q29udGVudClcbiAgICAgICAgICBjb25zb2xlLmxvZyhgVXBkYXRlZCBkYWlseSBzdW1tYXJ5IGZpbGU6ICR7ZmlsZVBhdGh9YClcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKGBFcnJvciBjcmVhdGluZyBkYWlseSBzdW1tYXJ5IGZvciAke2RhdGV9OmAsIGVycm9yKVxuICAgICAgdGhyb3cgZXJyb3JcbiAgICB9XG4gIH1cbn1cbiIsICJpbXBvcnQgeyBBcHAsIE1vZGFsLCBTZXR0aW5nLCBUZXh0QXJlYUNvbXBvbmVudCB9IGZyb20gXCJvYnNpZGlhblwiO1xuXG5pbnRlcmZhY2UgQXNzaWdubWVudCB7XG4gIG5hbWU6IHN0cmluZztcbiAgZHVlRGF0ZTogc3RyaW5nO1xuICB0eXBlOiBzdHJpbmc7XG4gIHBvaW50czogc3RyaW5nO1xuICBkZXNjcmlwdGlvbjogc3RyaW5nO1xufVxuXG5leHBvcnQgY2xhc3MgQXNzaWdubWVudHNNb2RhbCBleHRlbmRzIE1vZGFsIHtcbiAgYXNzaWdubWVudHM6IEFzc2lnbm1lbnRbXTtcbiAgY291cnNlTmFtZTogc3RyaW5nO1xuICBjb3Vyc2VJZDogc3RyaW5nO1xuICBvblN1Ym1pdDogKGFzc2lnbm1lbnRzOiBBc3NpZ25tZW50W10sIGNvdXJzZU5hbWU6IHN0cmluZywgY291cnNlSWQ6IHN0cmluZykgPT4gdm9pZDtcblxuICBjb25zdHJ1Y3RvcihcbiAgICBhcHA6IEFwcCxcbiAgICBjb3Vyc2VOYW1lOiBzdHJpbmcsXG4gICAgY291cnNlSWQ6IHN0cmluZyxcbiAgICBvblN1Ym1pdDogKGFzc2lnbm1lbnRzOiBBc3NpZ25tZW50W10sIGNvdXJzZU5hbWU6IHN0cmluZywgY291cnNlSWQ6IHN0cmluZykgPT4gdm9pZFxuICApIHtcbiAgICBzdXBlcihhcHApO1xuICAgIHRoaXMuYXNzaWdubWVudHMgPSBbeyBuYW1lOiBcIlwiLCBkdWVEYXRlOiBcIlwiLCB0eXBlOiBcIlwiLCBwb2ludHM6IFwiXCIsIGRlc2NyaXB0aW9uOiBcIlwiIH1dO1xuICAgIHRoaXMuY291cnNlTmFtZSA9IGNvdXJzZU5hbWU7XG4gICAgdGhpcy5jb3Vyc2VJZCA9IGNvdXJzZUlkO1xuICAgIHRoaXMub25TdWJtaXQgPSBvblN1Ym1pdDtcbiAgfVxuXG4gIG9uT3BlbigpIHtcbiAgICBjb25zdCB7IGNvbnRlbnRFbCB9ID0gdGhpcztcbiAgICBjb250ZW50RWwuZW1wdHkoKTtcbiAgICBjb250ZW50RWwuYWRkQ2xhc3MoXCJ0dWNrZXJzLXRvb2xzLWFzc2lnbm1lbnRzLW1vZGFsXCIpO1xuXG4gICAgY29udGVudEVsLmNyZWF0ZUVsKFwiaDJcIiwgeyB0ZXh0OiBcIkNyZWF0ZSBNdWx0aXBsZSBBc3NpZ25tZW50c1wiIH0pO1xuXG4gICAgLy8gQ291cnNlIGluZm9ybWF0aW9uIGRpc3BsYXlcbiAgICBuZXcgU2V0dGluZyhjb250ZW50RWwpXG4gICAgICAuc2V0TmFtZShcIkNvdXJzZVwiKVxuICAgICAgLnNldERlc2MoYCR7dGhpcy5jb3Vyc2VOYW1lfSAoJHt0aGlzLmNvdXJzZUlkfSlgKVxuICAgICAgLnNldERpc2FibGVkKHRydWUpO1xuXG4gICAgLy8gQ29udGFpbmVyIGZvciBhc3NpZ25tZW50IGxpc3RcbiAgICBjb25zdCBhc3NpZ25tZW50c0NvbnRhaW5lciA9IGNvbnRlbnRFbC5jcmVhdGVEaXYoeyBjbHM6IFwiYXNzaWdubWVudHMtY29udGFpbmVyXCIgfSk7XG5cbiAgICAvLyBBZGQgZmlyc3QgYXNzaWdubWVudFxuICAgIHRoaXMuYWRkQXNzaWdubWVudFNlY3Rpb24oYXNzaWdubWVudHNDb250YWluZXIsIDApO1xuXG4gICAgLy8gQWRkIGFzc2lnbm1lbnQgYnV0dG9uXG4gICAgbmV3IFNldHRpbmcoY29udGVudEVsKVxuICAgICAgLmFkZEJ1dHRvbigoYnRuKSA9PlxuICAgICAgICBidG5cbiAgICAgICAgICAuc2V0QnV0dG9uVGV4dChcIkFkZCBBc3NpZ25tZW50XCIpXG4gICAgICAgICAgLnNldEN0YSgpXG4gICAgICAgICAgLm9uQ2xpY2soKCkgPT4ge1xuICAgICAgICAgICAgY29uc3QgbmV3SW5kZXggPSB0aGlzLmFzc2lnbm1lbnRzLmxlbmd0aDtcbiAgICAgICAgICAgIHRoaXMuYXNzaWdubWVudHMucHVzaCh7IG5hbWU6IFwiXCIsIGR1ZURhdGU6IFwiXCIsIHR5cGU6IFwiXCIsIHBvaW50czogXCJcIiwgZGVzY3JpcHRpb246IFwiXCIgfSk7XG4gICAgICAgICAgICB0aGlzLmFkZEFzc2lnbm1lbnRTZWN0aW9uKGFzc2lnbm1lbnRzQ29udGFpbmVyLCBuZXdJbmRleCk7XG4gICAgICAgICAgfSlcbiAgICAgICk7XG5cbiAgICAvLyBTdWJtaXQgYnV0dG9uXG4gICAgbmV3IFNldHRpbmcoY29udGVudEVsKVxuICAgICAgLmFkZEJ1dHRvbigoYnRuKSA9PlxuICAgICAgICBidG5cbiAgICAgICAgICAuc2V0QnV0dG9uVGV4dChcIkNyZWF0ZSBBc3NpZ25tZW50c1wiKVxuICAgICAgICAgIC5zZXRDdGEoKVxuICAgICAgICAgIC5vbkNsaWNrKCgpID0+IHtcbiAgICAgICAgICAgIC8vIEZpbHRlciBvdXQgZW1wdHkgYXNzaWdubWVudHNcbiAgICAgICAgICAgIGNvbnN0IHZhbGlkQXNzaWdubWVudHMgPSB0aGlzLmFzc2lnbm1lbnRzLmZpbHRlcihcbiAgICAgICAgICAgICAgKGEpID0+IGEubmFtZS50cmltKCkgIT09IFwiXCIgfHwgYS5kdWVEYXRlLnRyaW0oKSAhPT0gXCJcIlxuICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIHRoaXMub25TdWJtaXQodmFsaWRBc3NpZ25tZW50cywgdGhpcy5jb3Vyc2VOYW1lLCB0aGlzLmNvdXJzZUlkKTtcbiAgICAgICAgICAgIHRoaXMuY2xvc2UoKTtcbiAgICAgICAgICB9KVxuICAgICAgKTtcbiAgfVxuXG4gIGFkZEFzc2lnbm1lbnRTZWN0aW9uKGNvbnRhaW5lcjogSFRNTEVsZW1lbnQsIGluZGV4OiBudW1iZXIpIHtcbiAgICBjb25zdCBzZWN0aW9uID0gY29udGFpbmVyLmNyZWF0ZURpdih7IGNsczogXCJhc3NpZ25tZW50LXNlY3Rpb25cIiB9KTtcbiAgICBzZWN0aW9uLmNyZWF0ZUVsKFwiaDNcIiwgeyB0ZXh0OiBgQXNzaWdubWVudCAjJHtpbmRleCArIDF9YCB9KTtcblxuICAgIG5ldyBTZXR0aW5nKHNlY3Rpb24pXG4gICAgICAuc2V0TmFtZShcIkFzc2lnbm1lbnQgTmFtZVwiKVxuICAgICAgLmFkZFRleHQoKHRleHQpID0+XG4gICAgICAgIHRleHRcbiAgICAgICAgICAuc2V0UGxhY2Vob2xkZXIoXCJFbnRlciBhc3NpZ25tZW50IG5hbWVcIilcbiAgICAgICAgICAuc2V0VmFsdWUodGhpcy5hc3NpZ25tZW50c1tpbmRleF0ubmFtZSlcbiAgICAgICAgICAub25DaGFuZ2UoKHZhbHVlKSA9PiB7XG4gICAgICAgICAgICB0aGlzLmFzc2lnbm1lbnRzW2luZGV4XS5uYW1lID0gdmFsdWU7XG4gICAgICAgICAgfSlcbiAgICAgICk7XG5cbiAgICBuZXcgU2V0dGluZyhzZWN0aW9uKVxuICAgICAgLnNldE5hbWUoXCJEdWUgRGF0ZVwiKVxuICAgICAgLnNldERlc2MoXCJGb3JtYXQ6IFlZWVktTU0tRERcIilcbiAgICAgIC5hZGRUZXh0KCh0ZXh0KSA9PlxuICAgICAgICB0ZXh0XG4gICAgICAgICAgLnNldFBsYWNlaG9sZGVyKFwiMjAyNC0wMS0xNVwiKVxuICAgICAgICAgIC5zZXRWYWx1ZSh0aGlzLmFzc2lnbm1lbnRzW2luZGV4XS5kdWVEYXRlKVxuICAgICAgICAgIC5vbkNoYW5nZSgodmFsdWUpID0+IHtcbiAgICAgICAgICAgIHRoaXMuYXNzaWdubWVudHNbaW5kZXhdLmR1ZURhdGUgPSB2YWx1ZTtcbiAgICAgICAgICB9KVxuICAgICAgKTtcblxuICAgIG5ldyBTZXR0aW5nKHNlY3Rpb24pXG4gICAgICAuc2V0TmFtZShcIkFzc2lnbm1lbnQgVHlwZVwiKVxuICAgICAgLmFkZFRleHQoKHRleHQpID0+XG4gICAgICAgIHRleHRcbiAgICAgICAgICAuc2V0UGxhY2Vob2xkZXIoXCJlLmcuLCBIb21ld29yaywgUXVpeiwgRXhhbVwiKVxuICAgICAgICAgIC5zZXRWYWx1ZSh0aGlzLmFzc2lnbm1lbnRzW2luZGV4XS50eXBlKVxuICAgICAgICAgIC5vbkNoYW5nZSgodmFsdWUpID0+IHtcbiAgICAgICAgICAgIHRoaXMuYXNzaWdubWVudHNbaW5kZXhdLnR5cGUgPSB2YWx1ZTtcbiAgICAgICAgICB9KVxuICAgICAgKTtcblxuICAgIG5ldyBTZXR0aW5nKHNlY3Rpb24pXG4gICAgICAuc2V0TmFtZShcIlBvaW50c1wiKVxuICAgICAgLmFkZFRleHQoKHRleHQpID0+XG4gICAgICAgIHRleHRcbiAgICAgICAgICAuc2V0UGxhY2Vob2xkZXIoXCJlLmcuLCAxMDBcIilcbiAgICAgICAgICAuc2V0VmFsdWUodGhpcy5hc3NpZ25tZW50c1tpbmRleF0ucG9pbnRzKVxuICAgICAgICAgIC5vbkNoYW5nZSgodmFsdWUpID0+IHtcbiAgICAgICAgICAgIHRoaXMuYXNzaWdubWVudHNbaW5kZXhdLnBvaW50cyA9IHZhbHVlO1xuICAgICAgICAgIH0pXG4gICAgICApO1xuXG4gICAgbmV3IFNldHRpbmcoc2VjdGlvbilcbiAgICAgIC5zZXROYW1lKFwiRGVzY3JpcHRpb25cIilcbiAgICAgIC5hZGRUZXh0QXJlYSgodGV4dCkgPT5cbiAgICAgICAgdGV4dFxuICAgICAgICAgIC5zZXRQbGFjZWhvbGRlcihcIkVudGVyIGFzc2lnbm1lbnQgZGVzY3JpcHRpb25cIilcbiAgICAgICAgICAuc2V0VmFsdWUodGhpcy5hc3NpZ25tZW50c1tpbmRleF0uZGVzY3JpcHRpb24pXG4gICAgICAgICAgLm9uQ2hhbmdlKCh2YWx1ZSkgPT4ge1xuICAgICAgICAgICAgdGhpcy5hc3NpZ25tZW50c1tpbmRleF0uZGVzY3JpcHRpb24gPSB2YWx1ZTtcbiAgICAgICAgICB9KVxuICAgICAgKTtcblxuICAgIC8vIEFkZCByZW1vdmUgYnV0dG9uIGlmIHRoZXJlJ3MgbW9yZSB0aGFuIG9uZSBhc3NpZ25tZW50XG4gICAgaWYgKHRoaXMuYXNzaWdubWVudHMubGVuZ3RoID4gMSkge1xuICAgICAgbmV3IFNldHRpbmcoc2VjdGlvbilcbiAgICAgICAgLmFkZEJ1dHRvbigoYnRuKSA9PlxuICAgICAgICAgIGJ0blxuICAgICAgICAgICAgLnNldEJ1dHRvblRleHQoXCJSZW1vdmVcIilcbiAgICAgICAgICAgIC5vbkNsaWNrKCgpID0+IHtcbiAgICAgICAgICAgICAgdGhpcy5hc3NpZ25tZW50cy5zcGxpY2UoaW5kZXgsIDEpO1xuICAgICAgICAgICAgICBzZWN0aW9uLnJlbW92ZSgpO1xuICAgICAgICAgICAgICB0aGlzLnJlbnVtYmVyQXNzaWdubWVudHMoKTtcbiAgICAgICAgICAgIH0pXG4gICAgICAgICk7XG4gICAgfVxuICB9XG5cbiAgcmVudW1iZXJBc3NpZ25tZW50cygpIHtcbiAgICBjb25zdCBzZWN0aW9ucyA9IHRoaXMuY29udGVudEVsLnF1ZXJ5U2VsZWN0b3JBbGwoXCIuYXNzaWdubWVudC1zZWN0aW9uXCIpO1xuICAgIHNlY3Rpb25zLmZvckVhY2goKHNlY3Rpb24sIGluZGV4KSA9PiB7XG4gICAgICBjb25zdCBoZWFkZXIgPSBzZWN0aW9uLnF1ZXJ5U2VsZWN0b3IoXCJoM1wiKTtcbiAgICAgIGlmIChoZWFkZXIpIHtcbiAgICAgICAgaGVhZGVyLnRleHRDb250ZW50ID0gYEFzc2lnbm1lbnQgIyR7aW5kZXggKyAxfWA7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cblxuICBvbkNsb3NlKCkge1xuICAgIGNvbnN0IHsgY29udGVudEVsIH0gPSB0aGlzO1xuICAgIGNvbnRlbnRFbC5lbXB0eSgpO1xuICB9XG59IiwgIi8qKlxuICogRGF0YXZpZXcgZnVuY3Rpb25zIGZvciBUdWNrZXJzIFRvb2xzXG4gKiBUaGVzZSBmdW5jdGlvbnMgcHJvdmlkZSBlbmhhbmNlZCBwcm9jZXNzaW5nIGNhcGFiaWxpdGllcyBmb3IgY291cnNlIHZvY2FidWxhcnkgYW5kIGR1ZSBkYXRlc1xuICovXG5cbi8qKlxuICogUHJvY2Vzc2VzIGFuZCBkaXNwbGF5cyBjb3Vyc2Ugdm9jYWJ1bGFyeSBmcm9tIGFsbCBub3RlcyBhc3NvY2lhdGVkIHdpdGggYSBjb3Vyc2VcbiAqIEBwYXJhbSBkdiAtIFRoZSBkYXRhdmlldyBBUEkgb2JqZWN0XG4gKiBAcGFyYW0gY291cnNlSWQgLSBUaGUgY291cnNlIGlkZW50aWZpZXIgdG8gc2VhcmNoIGZvclxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcHJvY2Vzc0NvdXJzZVZvY2FidWxhcnkoZHY6IGFueSwgY291cnNlSWQ6IHN0cmluZykge1xuICAgIHRyeSB7XG4gICAgICAgIC8vIEZpbmQgYWxsIHBhZ2VzIHdpdGggdGhlIGNvdXJzZSBJRCB0YWdcbiAgICAgICAgY29uc3QgcGFnZXMgPSBkdi5wYWdlcyhjb3Vyc2VJZClcbiAgICAgICAgICAgIC5maWx0ZXIoKHA6IGFueSkgPT4gcC5maWxlLmV4dCA9PT0gXCJtZFwiICYmIHAuZmlsZS5uYW1lICE9PSBjb3Vyc2VJZClcbiAgICAgICAgICAgIC5tYXAoKHA6IGFueSkgPT4gKHtcbiAgICAgICAgICAgICAgICBuYW1lOiBwLmZpbGUubmFtZSxcbiAgICAgICAgICAgICAgICBwYXRoOiBwLmZpbGUucGF0aFxuICAgICAgICAgICAgfSkpO1xuXG4gICAgICAgIC8vIFByb2Nlc3MgZWFjaCBwYWdlIGFuZCBleHRyYWN0IHZvY2FidWxhcnlcbiAgICAgICAgZHYuaGVhZGVyKDEsIFwiQWxsIENvdXJzZSBWb2NhYnVsYXJ5XCIpO1xuICAgICAgICBcbiAgICAgICAgZm9yIChjb25zdCBwYWdlIG9mIHBhZ2VzKSB7XG4gICAgICAgICAgICBpZiAoIXBhZ2UucGF0aCkgY29udGludWU7XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIHRyeSB7ICAgXG4gICAgICAgICAgICAgICAgY29uc3QgZmlsZSA9IGF3YWl0IGR2LmFwcC52YXVsdC5nZXRGaWxlQnlQYXRoKHBhZ2UucGF0aCk7XG4gICAgICAgICAgICAgICAgY29uc3QgY29udGVudCA9IGF3YWl0IGR2LmFwcC52YXVsdC5yZWFkKGZpbGUpO1xuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgIC8vIEV4dHJhY3Qgdm9jYWJ1bGFyeSB1c2luZyByZWdleFxuICAgICAgICAgICAgICAgIGNvbnN0IHZvY2FiUmVnZXggPSAvXiMrIFZvY2FidWxhcnkuKlxcbigoPzouKj9cXG4pKj8pKD89XFxuXFxzKiN8JCkvbTtcbiAgICAgICAgICAgICAgICBjb25zdCB2b2NhYk1hdGNoZXMgPSBjb250ZW50Py5tYXRjaCh2b2NhYlJlZ2V4KTtcblxuICAgICAgICAgICAgICAgIGlmICh2b2NhYk1hdGNoZXMpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3Qgdm9jYWJEYXRhID0gdm9jYWJNYXRjaGVzWzFdLnRyaW0oKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgY2xlYW5lZFZvY2FiID0gdm9jYWJEYXRhXG4gICAgICAgICAgICAgICAgICAgICAgICAucmVwbGFjZSgvXFxbXFxbLio/XFxdXFxdL2csIFwiXCIpICAvLyBSZW1vdmUgd2lraWxpbmtzXG4gICAgICAgICAgICAgICAgICAgICAgICAudHJpbSgpXG4gICAgICAgICAgICAgICAgICAgICAgICAuc3BsaXQoXCJcXG5cIilcbiAgICAgICAgICAgICAgICAgICAgICAgIC5maWx0ZXIoKGxpbmU6IHN0cmluZykgPT4gbGluZS5zdGFydHNXaXRoKFwiLSBcIikpICAvLyBPbmx5IGxpbmVzIHN0YXJ0aW5nIHdpdGggXCItIFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAubWFwKChsaW5lOiBzdHJpbmcpID0+IGxpbmUuc3Vic3RyaW5nKDIpKSAgLy8gUmVtb3ZlIFwiLSBcIiBwcmVmaXhcbiAgICAgICAgICAgICAgICAgICAgICAgIC5maWx0ZXIoQm9vbGVhbik7ICAvLyBSZW1vdmUgZW1wdHkgZW50cmllc1xuXG4gICAgICAgICAgICAgICAgICAgIGlmIChjbGVhbmVkVm9jYWIubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgZHYuaGVhZGVyKDMsIGBbWyR7cGFnZS5uYW1lfV1dYCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBkdi5saXN0KGNsZWFuZWRWb2NhYik7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhgRXJyb3IgcHJvY2Vzc2luZyAke3BhZ2UucGF0aH06YCwgZSk7XG4gICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBpbiBWb2NhYnVsYXJ5IFByb2Nlc3Npbmc6XCIsIGVycm9yKTtcbiAgICB9XG59XG5cbi8qKlxuICogUHJvY2Vzc2VzIGFuZCBkaXNwbGF5cyBkdWUgZGF0ZXMgZnJvbSBhbGwgbm90ZXMgYXNzb2NpYXRlZCB3aXRoIGEgY291cnNlXG4gKiBAcGFyYW0gZHYgLSBUaGUgZGF0YXZpZXcgQVBJIG9iamVjdFxuICogQHBhcmFtIHNvdXJjZSAtIFRoZSB0YWcgb3IgcGF0aCB0byBzZWFyY2ggZm9yIGR1ZSBkYXRlc1xuICogQHBhcmFtIHN0YXJ0RGF0ZSAtIE9wdGlvbmFsIHN0YXJ0IGRhdGUgZm9yIGZpbHRlcmluZyAoWVlZWS1NTS1ERCBmb3JtYXQpXG4gKiBAcGFyYW0gZW5kRGF0ZSAtIE9wdGlvbmFsIGVuZCBkYXRlIGZvciBmaWx0ZXJpbmcgKFlZWVktTU0tREQgZm9ybWF0KVxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcHJvY2Vzc0R1ZURhdGVzKGR2OiBhbnksIHNvdXJjZTogc3RyaW5nLCBzdGFydERhdGU6IHN0cmluZyB8IG51bGwgPSBudWxsLCBlbmREYXRlOiBzdHJpbmcgfCBudWxsID0gbnVsbCkge1xuICAgIGZ1bmN0aW9uIGRlZHVwbGljYXRlRmlyc3RUd29Db2x1bW5zKGFycjogYW55W10pIHtcbiAgICAgICAgY29uc3Qgc2VlbiA9IG5ldyBTZXQoKTtcbiAgICAgICAgcmV0dXJuIGFyci5maWx0ZXIoKGVudHJ5OiBhbnkpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGtleSA9IEpTT04uc3RyaW5naWZ5KFtlbnRyeVswXSwgZW50cnlbMV1dKTtcbiAgICAgICAgICAgIHJldHVybiAhc2Vlbi5oYXMoa2V5KSAmJiBzZWVuLmFkZChrZXkpO1xuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvLyBJZiBubyBkYXRlIHJhbmdlIGlzIHNwZWNpZmllZCwgZGVmYXVsdCB0byBzaG93aW5nIGRhdGVzIHN0YXJ0aW5nIGZyb20geWVzdGVyZGF5XG4gICAgY29uc3QgZGVmYXVsdFN0YXJ0RGF0ZSA9ICh3aW5kb3cgYXMgYW55KS5tb21lbnQoKS5zdWJ0cmFjdCgxLCBcImRheVwiKS5mb3JtYXQoXCJZWVlZLU1NLUREXCIpO1xuICAgIGNvbnN0IHN0YXJ0ID0gc3RhcnREYXRlIHx8IGRlZmF1bHRTdGFydERhdGU7XG4gICAgY29uc3QgZW5kID0gZW5kRGF0ZSB8fCAod2luZG93IGFzIGFueSkubW9tZW50KCkuYWRkKDEsIFwieWVhclwiKS5mb3JtYXQoXCJZWVlZLU1NLUREXCIpOyAvLyBTaG93IGEgeWVhciBvZiBkYXRlcyBieSBkZWZhdWx0XG5cbiAgICBjb25zdCBwYWdlcyA9IGF3YWl0IGR2LnBhZ2VzKHNvdXJjZSlcbiAgICAgICAgLmZpbHRlcigocDogYW55KSA9PiBwLmZpbGUubmFtZSAhPT0gc291cmNlICYmIHAuZmlsZS5leHQgPT0gXCJtZFwiKTtcblxuICAgIGxldCBhbGxFbnRyaWVzOiBhbnlbXSA9IFtdO1xuXG4gICAgZm9yIChjb25zdCBwYWdlIG9mIHBhZ2VzLnZhbHVlcykge1xuICAgICAgICBpZiAoIXBhZ2U/LmZpbGU/LnBhdGgpIHsgcmV0dXJuIH1cbiAgICAgICAgY29uc3QgY29udGVudCA9IGF3YWl0IChkdi5hcHAudmF1bHQgYXMgYW55KS5jYWNoZWRSZWFkKChkdi5hcHAudmF1bHQgYXMgYW55KS5nZXRGaWxlQnlQYXRoKHBhZ2UuZmlsZT8ucGF0aCkpO1xuICAgICAgICBjb25zdCByZWdleCA9IC8jIER1ZSBEYXRlcyhbXFxzXFxTXSo/KSg/PVxcbiN8JCkvO1xuICAgICAgICBjb25zdCBtYXRjaGVzID0gY29udGVudD8ubWF0Y2gocmVnZXgpO1xuICAgICAgICBpZiAobWF0Y2hlcykge1xuICAgICAgICBjb25zdCB0YWJsZURhdGEgPSBtYXRjaGVzWzFdLnRyaW0oKTtcbiAgICAgICAgY29uc3QgbGluZXMgPSB0YWJsZURhdGEuc3BsaXQoXCJcXG5cIikuc2xpY2UoMSk7XG4gICAgICAgIGZvciAoY29uc3QgbGluZSBvZiBsaW5lcykge1xuICAgICAgICAgICAgbGV0IGZvcm1hdHRlZER1ZURhdGU6IHN0cmluZztcbiAgICAgICAgICAgIGNvbnN0IGNvbHVtbnMgPSBsaW5lXG4gICAgICAgICAgICAuc3BsaXQoXCJ8XCIpXG4gICAgICAgICAgICAubWFwKChjOiBzdHJpbmcpID0+IGMudHJpbSgpKVxuICAgICAgICAgICAgLmZpbHRlcigoYzogc3RyaW5nKSA9PiBjKTtcbiAgICAgICAgICAgIGxldCBbZHVlRGF0ZSwgYXNzaWdubWVudF0gPSBjb2x1bW5zO1xuICAgICAgICAgICAgaWYgKCFEYXRlLnBhcnNlKGR1ZURhdGUpIHx8IGFzc2lnbm1lbnQ/Lm1hdGNoKC9cdTI3MDUvKSkge1xuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBhc3NpZ25tZW50ID0gYXNzaWdubWVudD8ubWF0Y2goL1tBLVpdezN9LVswLTldezN9LylcbiAgICAgICAgICAgID8gYXNzaWdubWVudFxuICAgICAgICAgICAgOiBgIyR7cGFnZS5jb3Vyc2VfaWR9IC0gJHthc3NpZ25tZW50fWA7XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIGlmIChcbiAgICAgICAgICAgICh3aW5kb3cgYXMgYW55KS5tb21lbnQoZHVlRGF0ZSkuaXNCZXR3ZWVuKHN0YXJ0LCBlbmQsIHVuZGVmaW5lZCwgXCJbXVwiKSAgLy8gaW5jbHVkZSBlbmRwb2ludHNcbiAgICAgICAgICAgICkge1xuICAgICAgICAgICAgY29uc3QgdW5pcXVlUm93ID0gIWFsbEVudHJpZXMuc29tZShcbiAgICAgICAgICAgICAgICAoZTogYW55KSA9PlxuICAgICAgICAgICAgICAgIGVbMF0ubWF0Y2goKHdpbmRvdyBhcyBhbnkpLm1vbWVudChkdWVEYXRlKT8uZm9ybWF0KFwiWVlZWS1NTS1ERFwiKSkgJiZcbiAgICAgICAgICAgICAgICBlWzFdID09IGFzc2lnbm1lbnRcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgICBpZiAoYXNzaWdubWVudCAmJiB1bmlxdWVSb3cpIHtcbiAgICAgICAgICAgICAgICBpZiAoKHdpbmRvdyBhcyBhbnkpLm1vbWVudChkdWVEYXRlKT8uaXNCZWZvcmUoc3RhcnQpKSB7XG4gICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICAgICAgfSBlbHNlIGlmICgod2luZG93IGFzIGFueSkubW9tZW50KGR1ZURhdGUpLmlzQWZ0ZXIoKHdpbmRvdyBhcyBhbnkpLm1vbWVudCgpLnN1YnRyYWN0KDEsIFwid1wiKSkpIHtcbiAgICAgICAgICAgICAgICBmb3JtYXR0ZWREdWVEYXRlID0gYDxzcGFuIGNsYXNzPVwiZHVlIG9uZV93ZWVrXCI+JHsod2luZG93IGFzIGFueSkubW9tZW50KFxuICAgICAgICAgICAgICAgICAgICBkdWVEYXRlXG4gICAgICAgICAgICAgICAgKT8uZm9ybWF0KFwiWVlZWS1NTS1ERCBkZGRcIil9PC9zcGFuPmA7XG4gICAgICAgICAgICAgICAgfSBlbHNlIGlmICgod2luZG93IGFzIGFueSkubW9tZW50KGR1ZURhdGUpLmlzQWZ0ZXIoKHdpbmRvdyBhcyBhbnkpLm1vbWVudCgpLnN1YnRyYWN0KDIsIFwid1wiKSkpIHtcbiAgICAgICAgICAgICAgICBmb3JtYXR0ZWREdWVEYXRlID0gYDxzcGFuIGNsYXNzPVwiZHVlIHR3b193ZWVrc1wiPiR7KHdpbmRvdyBhcyBhbnkpLm1vbWVudChcbiAgICAgICAgICAgICAgICAgICAgZHVlRGF0ZVxuICAgICAgICAgICAgICAgICk/LmZvcm1hdChcIllZWVktTU0tREQgZGRkXCIpfTwvc3Bhbj5gO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgZm9ybWF0dGVkRHVlRGF0ZSA9ICh3aW5kb3cgYXMgYW55KS5tb21lbnQoZHVlRGF0ZSk/LmZvcm1hdChcIllZWVktTU0tREQgZGRkXCIpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBhbGxFbnRyaWVzLnB1c2goW1xuICAgICAgICAgICAgICAgIGR1ZURhdGUsXG4gICAgICAgICAgICAgICAgZm9ybWF0dGVkRHVlRGF0ZSxcbiAgICAgICAgICAgICAgICBhc3NpZ25tZW50LFxuICAgICAgICAgICAgICAgIGBbWyR7cGFnZT8uZmlsZT8ucGF0aH18JHtwYWdlPy5maWxlPy5uYW1lfV1dYCxcbiAgICAgICAgICAgICAgICBdKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgY29uc3Qgc29ydGVkUm93cyA9IGRlZHVwbGljYXRlRmlyc3RUd29Db2x1bW5zKGFsbEVudHJpZXNcbiAgICAgICAgLnNvcnQoKGE6IGFueSwgYjogYW55KSA9PiAod2luZG93IGFzIGFueSkubW9tZW50KGFbMF0pLnZhbHVlT2YoKSAtICh3aW5kb3cgYXMgYW55KS5tb21lbnQoYlswXSkudmFsdWVPZigpICkgXG4gICAgICAgIC5tYXAoKGE6IGFueSkgPT4gW2FbMV0sIGFbMl0sIGFbM11dKVxuICAgICk7XG4gICAgXG4gICAgY29uc3QgdGFibGUgPSBkdi5tYXJrZG93blRhYmxlKCBbXCJEdWUgRGF0ZVwiLCBcIlRhc2sgRGVzY3JpcHRpb25cIiwgXCJGaWxlXCJdLCBzb3J0ZWRSb3dzICk7XG4gICAgZHYuZWwoXCJ0YWJsZVwiLCB0YWJsZSk7XG59XG4iXSwKICAibWFwcGluZ3MiOiAiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUFBQSxtQkFBc0M7OztBQ0F0QyxzQkFBK0M7OztBQ2dCeEMsU0FBUyxRQUFRLE1BQXNCO0FBQzVDLFNBQU8sS0FDSixZQUFZLEVBQ1osS0FBSyxFQUNMLFVBQVUsS0FBSyxFQUNmLFFBQVEsb0JBQW9CLEVBQUUsRUFDOUIsUUFBUSxpQkFBaUIsRUFBRSxFQUMzQixRQUFRLFdBQVcsR0FBRyxFQUN0QixRQUFRLFlBQVksRUFBRTtBQUMzQjtBQWVPLFNBQVMsYUFBYSxZQUE2QjtBQUN4RCxRQUFNLFFBQVE7QUFDZCxNQUFJLENBQUMsV0FBVyxNQUFNLEtBQUs7QUFBRyxXQUFPO0FBRXJDLFFBQU0sT0FBTyxJQUFJLEtBQUssVUFBVTtBQUNoQyxRQUFNLFlBQVksS0FBSyxRQUFRO0FBRS9CLE1BQUksT0FBTyxjQUFjLFlBQVksTUFBTSxTQUFTO0FBQUcsV0FBTztBQUU5RCxTQUFPLGVBQWUsS0FBSyxZQUFZLEVBQUUsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUN2RDs7O0FEbkNPLElBQU0sbUJBQXlDO0FBQUEsRUFDcEQsZUFBZTtBQUFBLEVBQ2YsbUJBQW1CLElBQUksS0FBSyxFQUFFLFlBQVksRUFBRSxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsRUFDeEQsaUJBQWlCLElBQUksS0FBSyxJQUFJLEtBQUssRUFBRSxTQUFTLElBQUksS0FBSyxFQUFFLFNBQVMsSUFBSSxDQUFDLENBQUMsRUFBRSxZQUFZLEVBQUUsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLEVBQ3BHLFlBQVk7QUFBQSxFQUNaLG9CQUFvQjtBQUFBLEVBQ3BCLGdCQUFnQjtBQUFBLEVBQ2hCLHFCQUFxQjtBQUFBLEVBQ3JCLGdCQUFnQjtBQUNsQjtBQUVPLElBQU0seUJBQU4sY0FBcUMsaUNBQWlCO0FBQUEsRUFHM0QsWUFBWSxLQUFVLFFBQTRCO0FBQ2hELFVBQU0sS0FBSyxNQUFNO0FBQ2pCLFNBQUssU0FBUztBQUFBLEVBQ2hCO0FBQUEsRUFFQSxVQUFnQjtBQUNkLFVBQU0sRUFBRSxZQUFZLElBQUk7QUFFeEIsZ0JBQVksTUFBTTtBQUVsQixnQkFBWSxTQUFTLE1BQU0sRUFBRSxNQUFNLHlCQUF5QixDQUFDO0FBRTdELFFBQUksd0JBQVEsV0FBVyxFQUNwQixRQUFRLGdCQUFnQixFQUN4QixRQUFRLGdEQUFnRCxFQUN4RCxRQUFRLFVBQVEsS0FDZCxlQUFlLEdBQUcsRUFDbEIsU0FBUyxLQUFLLE9BQU8sU0FBUyxhQUFhLEVBQzNDLFNBQVMsQ0FBTyxVQUFVO0FBQ3pCLFdBQUssT0FBTyxTQUFTLGdCQUFnQjtBQUNyQyxZQUFNLEtBQUssT0FBTyxhQUFhO0FBQUEsSUFDakMsRUFBQyxDQUFDO0FBRU4sVUFBTSxtQkFBbUIsSUFBSSx3QkFBUSxXQUFXLEVBQzdDLFFBQVEscUJBQXFCLEVBQzdCLFFBQVEscUNBQXFDLEVBQzdDLFFBQVEsVUFBUSxLQUNkLGVBQWUsWUFBWSxFQUMzQixTQUFTLEtBQUssT0FBTyxTQUFTLGlCQUFpQixFQUMvQyxTQUFTLENBQU8sVUFBVTtBQUN6QixVQUFJLFNBQVMsQ0FBQyxhQUFhLEtBQUssR0FBRztBQUNqQyx5QkFBaUIsUUFBUSwyREFBMkQ7QUFBQSxNQUN0RixPQUFPO0FBQ0wseUJBQWlCLFFBQVEscUNBQXFDO0FBQUEsTUFDaEU7QUFDQSxXQUFLLE9BQU8sU0FBUyxvQkFBb0I7QUFDekMsWUFBTSxLQUFLLE9BQU8sYUFBYTtBQUFBLElBQ2pDLEVBQUMsQ0FBQztBQUVOLFVBQU0saUJBQWlCLElBQUksd0JBQVEsV0FBVyxFQUMzQyxRQUFRLG1CQUFtQixFQUMzQixRQUFRLG1DQUFtQyxFQUMzQyxRQUFRLFVBQVEsS0FDZCxlQUFlLFlBQVksRUFDM0IsU0FBUyxLQUFLLE9BQU8sU0FBUyxlQUFlLEVBQzdDLFNBQVMsQ0FBTyxVQUFVO0FBQ3pCLFVBQUksU0FBUyxDQUFDLGFBQWEsS0FBSyxHQUFHO0FBQ2pDLHVCQUFlLFFBQVEseURBQXlEO0FBQUEsTUFDbEYsT0FBTztBQUNMLHVCQUFlLFFBQVEsbUNBQW1DO0FBQUEsTUFDNUQ7QUFDQSxXQUFLLE9BQU8sU0FBUyxrQkFBa0I7QUFDdkMsWUFBTSxLQUFLLE9BQU8sYUFBYTtBQUFBLElBQ2pDLEVBQUMsQ0FBQztBQUVOLFFBQUksd0JBQVEsV0FBVyxFQUNwQixRQUFRLGFBQWEsRUFDckIsUUFBUSwwQkFBMEIsRUFDbEMsUUFBUSxVQUFRLEtBQ2QsZUFBZSxZQUFZLEVBQzNCLFNBQVMsS0FBSyxPQUFPLFNBQVMsVUFBVSxFQUN4QyxTQUFTLENBQU8sVUFBVTtBQUN6QixXQUFLLE9BQU8sU0FBUyxhQUFhO0FBQ2xDLFlBQU0sS0FBSyxPQUFPLGFBQWE7QUFBQSxJQUNqQyxFQUFDLENBQUM7QUFFTixRQUFJLHdCQUFRLFdBQVcsRUFDcEIsUUFBUSxxQkFBcUIsRUFDN0IsUUFBUSxtQ0FBbUMsRUFDM0MsUUFBUSxVQUFRLEtBQ2QsZUFBZSxHQUFHLEVBQ2xCLFNBQVMsS0FBSyxPQUFPLFNBQVMsa0JBQWtCLEVBQ2hELFNBQVMsQ0FBTyxVQUFVO0FBQ3pCLFdBQUssT0FBTyxTQUFTLHFCQUFxQjtBQUMxQyxZQUFNLEtBQUssT0FBTyxhQUFhO0FBQUEsSUFDakMsRUFBQyxDQUFDO0FBRU4sUUFBSSx3QkFBUSxXQUFXLEVBQ3BCLFFBQVEsaUJBQWlCLEVBQ3pCLFFBQVEsNkVBQTZFLEVBQ3JGLFFBQVEsVUFBUSxLQUNkLGVBQWUsZUFBZSxFQUM5QixTQUFTLEtBQUssT0FBTyxTQUFTLGNBQWMsRUFDNUMsU0FBUyxDQUFPLFVBQVU7QUFDekIsV0FBSyxPQUFPLFNBQVMsaUJBQWlCO0FBQ3RDLFlBQU0sS0FBSyxPQUFPLGFBQWE7QUFBQSxJQUNqQyxFQUFDLENBQUM7QUFFTixRQUFJLHdCQUFRLFdBQVcsRUFDcEIsUUFBUSx1QkFBdUIsRUFDL0IsUUFBUSxpRkFBaUYsRUFDekYsVUFBVSxZQUFVLE9BQ2xCLFNBQVMsS0FBSyxPQUFPLFNBQVMsbUJBQW1CLEVBQ2pELFNBQVMsQ0FBTyxVQUFVO0FBQ3pCLFdBQUssT0FBTyxTQUFTLHNCQUFzQjtBQUMzQyxZQUFNLEtBQUssT0FBTyxhQUFhO0FBQUEsSUFDakMsRUFBQyxDQUFDO0FBRU4sUUFBSSx3QkFBUSxXQUFXLEVBQ3BCLFFBQVEseUJBQXlCLEVBQ2pDLFFBQVEseURBQXlELEVBQ2pFLFFBQVEsVUFBUSxLQUNkLGVBQWUsZ0NBQWdDLEVBQy9DLFNBQVMsS0FBSyxPQUFPLFNBQVMsY0FBYyxFQUM1QyxTQUFTLENBQU8sVUFBVTtBQUN6QixXQUFLLE9BQU8sU0FBUyxpQkFBaUI7QUFDdEMsWUFBTSxLQUFLLE9BQU8sYUFBYTtBQUFBLElBQ2pDLEVBQUMsQ0FBQztBQUFBLEVBQ1I7QUFDRjs7O0FFMUlBLElBQUFDLG1CQUE0QjtBQVVyQixJQUFNLGtCQUFOLE1BQXNCO0FBQUEsRUFLM0IsWUFBWSxLQUFVLFVBQWdDO0FBQ3BELFNBQUssTUFBTTtBQUNYLFNBQUssV0FBVztBQUNoQixTQUFLLFdBQVc7QUFBQSxNQUNkLFNBQVM7QUFBQSxNQUNULFdBQVc7QUFBQSxRQUNULHFDQUFxQztBQUFBLFFBQ3JDLDJCQUEyQjtBQUFBLFFBQzNCLDRCQUE0QjtBQUFBLFFBQzVCLDhCQUE4QjtBQUFBLFFBQzlCLG9DQUFvQztBQUFBLFFBQ3BDLHVCQUF1QjtBQUFBLFFBQ3ZCLGlDQUFpQztBQUFBLFFBQ2pDLCtCQUErQjtBQUFBLE1BQ2pDO0FBQUEsTUFDQSxnQkFBZ0I7QUFBQSxNQUNoQixlQUFlO0FBQUEsSUFDakI7QUFBQSxFQUNGO0FBQUEsRUFFTSxtQkFBbUI7QUFBQTtBQUN2QixVQUFJO0FBRUYsY0FBTSxrQkFBa0IsS0FBSyxtQkFBbUI7QUFDaEQsWUFBSSxDQUFDLGlCQUFpQjtBQUNwQixjQUFJO0FBQUEsWUFDRjtBQUFBLFVBQ0Y7QUFDQSxrQkFBUTtBQUFBLFlBQ047QUFBQSxVQUNGO0FBQ0E7QUFBQSxRQUNGO0FBRUEsY0FBTSxxQkFBcUIsS0FBSyxzQkFBc0IsZUFBZTtBQUNyRSxZQUFJLENBQUMsb0JBQW9CO0FBQ3ZCLGNBQUk7QUFBQSxZQUNGO0FBQUEsVUFDRjtBQUNBLGtCQUFRO0FBQUEsWUFDTjtBQUFBLFVBQ0Y7QUFDQTtBQUFBLFFBQ0Y7QUFFQSxjQUFNLG1CQUFtQixHQUFHLHNCQUFzQixLQUFLLFNBQVM7QUFHaEUsWUFBSTtBQUNGLGdCQUFNLEtBQUssSUFBSSxNQUFNLGFBQWEsZ0JBQWdCO0FBQ2xELGtCQUFRLElBQUksNEJBQTRCLGtCQUFrQjtBQUFBLFFBQzVELFNBQVMsR0FBUDtBQUVBLGtCQUFRO0FBQUEsWUFDTiw4Q0FBOEM7QUFBQSxVQUNoRDtBQUFBLFFBQ0Y7QUFHQSxjQUFNLFVBQVU7QUFBQSxVQUNkO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxRQUNGO0FBQ0EsbUJBQVcsVUFBVSxTQUFTO0FBQzVCLGNBQUk7QUFDRixrQkFBTSxVQUFVLEdBQUcsb0JBQW9CO0FBQ3ZDLGtCQUFNLEtBQUssSUFBSSxNQUFNLGFBQWEsT0FBTztBQUN6QyxvQkFBUSxJQUFJLHlCQUF5QixTQUFTO0FBQUEsVUFDaEQsU0FBUyxHQUFQO0FBRUEsb0JBQVE7QUFBQSxjQUNOLGdDQUFnQyxvQkFBb0I7QUFBQSxZQUN0RDtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBR0EsY0FBTSxLQUFLLHVCQUF1QixnQkFBZ0I7QUFDbEQsY0FBTSxLQUFLLHVCQUF1QixnQkFBZ0I7QUFDbEQsY0FBTSxLQUFLLHdCQUF3QixnQkFBZ0I7QUFDbkQsY0FBTSxLQUFLLDJCQUEyQixnQkFBZ0I7QUFDdEQsY0FBTSxLQUFLLHNCQUFzQixnQkFBZ0I7QUFDakQsY0FBTSxLQUFLLHdCQUF3QixnQkFBZ0I7QUFHbkQsY0FBTSxLQUFLLGFBQWEsZ0JBQWdCO0FBR3hDLGNBQU0sS0FBSyx1QkFBdUIsZ0JBQWdCO0FBRWxELFlBQUksd0JBQU8saURBQWlEO0FBQzVELGdCQUFRLElBQUksZ0RBQWdEO0FBQUEsTUFDOUQsU0FBUyxPQUFQO0FBQ0EsZ0JBQVEsTUFBTSwrQkFBK0IsS0FBSztBQUNsRCxZQUFJLHdCQUFPLHdEQUF3RDtBQUFBLE1BQ3JFO0FBQUEsSUFDRjtBQUFBO0FBQUEsRUFFUSxxQkFBMEI7QUFFaEMsVUFBTSxnQkFBZ0I7QUFBQSxNQUNuQixLQUFLLElBQVksUUFBUSxRQUFRLG9CQUFvQjtBQUFBLE1BQ3JELEtBQUssSUFBWSxRQUFRLFFBQVEsV0FBVztBQUFBLE1BQzVDLEtBQUssSUFBWSxRQUFRLFVBQVUsb0JBQW9CO0FBQUEsTUFDdkQsS0FBSyxJQUFZLFFBQVEsVUFBVSxXQUFXO0FBQUEsSUFDakQ7QUFFQSxlQUFXLFFBQVEsZUFBZTtBQUNoQyxVQUFJLE1BQU07QUFDUixlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFFQSxXQUFPO0FBQUEsRUFDVDtBQUFBLEVBRVEsc0JBQXNCLGlCQUFxQztBQUNqRSxVQUFNLFdBQVcsZ0JBQWdCO0FBRWpDLFFBQUksQ0FBQyxVQUFVO0FBQ2IsY0FBUSxNQUFNLGtDQUFrQztBQUNoRCxhQUFPO0FBQUEsSUFDVDtBQUdBLFVBQU0sZ0JBQWdCO0FBQUEsTUFDcEIsU0FBUztBQUFBO0FBQUEsTUFDVCxTQUFTO0FBQUEsTUFDVCxTQUFTO0FBQUEsTUFDVCxTQUFTO0FBQUEsTUFDVCxTQUFTO0FBQUEsSUFDWDtBQUVBLGVBQVcsUUFBUSxlQUFlO0FBQ2hDLFVBQUksUUFBUSxPQUFPLFNBQVMsVUFBVTtBQUNwQyxlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFFQSxZQUFRO0FBQUEsTUFDTjtBQUFBLE1BQ0EsT0FBTyxLQUFLLFFBQVE7QUFBQSxJQUN0QjtBQUNBLFdBQU87QUFBQSxFQUNUO0FBQUEsRUFFTSx1QkFBdUIsVUFBa0I7QUFBQTtBQUM3QyxZQUFNLGVBQWUsR0FBRztBQUN4QixZQUFNLGtCQUFrQixLQUFLLFVBQVUsS0FBSyxVQUFVLE1BQU0sQ0FBQztBQUU3RCxVQUFJO0FBRUYsY0FBTSxtQkFDSixLQUFLLElBQUksTUFBTSxzQkFBc0IsWUFBWTtBQUNuRCxZQUFJLGtCQUFrQjtBQUVwQixnQkFBTSxPQUFPO0FBQ2IsZ0JBQU0sS0FBSyxJQUFJLE1BQU0sT0FBTyxNQUFNLGVBQWU7QUFDakQsa0JBQVEsSUFBSSw4QkFBOEIsY0FBYztBQUN4RDtBQUFBLFFBQ0Y7QUFHQSxjQUFNLEtBQUssSUFBSSxNQUFNLE9BQU8sY0FBYyxlQUFlO0FBQ3pELGdCQUFRLElBQUksOEJBQThCLGNBQWM7QUFBQSxNQUMxRCxTQUFTLEdBQVA7QUFDQSxZQUFJLHdCQUFPLG9DQUFvQyxjQUFjO0FBQzdELGdCQUFRLE1BQU0sb0NBQW9DLGlCQUFpQixDQUFDO0FBQUEsTUFDdEU7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVNLDBCQUE0QztBQUFBO0FBR2hELGNBQVEsSUFBSSwrQkFBK0I7QUFDM0MsYUFBTztBQUFBLElBQ1Q7QUFBQTtBQUFBLEVBRU0sa0JBQWtCO0FBQUE7QUFDdEIsVUFBSTtBQUVGLGdCQUFRLElBQUksb0JBQW9CO0FBR2hDLGNBQU0sa0JBQWtCLEtBQUssbUJBQW1CO0FBQ2hELFlBQUksQ0FBQyxpQkFBaUI7QUFDcEIsY0FBSTtBQUFBLFlBQ0Y7QUFBQSxVQUNGO0FBQ0Esa0JBQVE7QUFBQSxZQUNOO0FBQUEsVUFDRjtBQUNBO0FBQUEsUUFDRjtBQUVBLGNBQU0scUJBQXFCLEtBQUssc0JBQXNCLGVBQWU7QUFDckUsWUFBSSxDQUFDLG9CQUFvQjtBQUN2QixjQUFJO0FBQUEsWUFDRjtBQUFBLFVBQ0Y7QUFDQSxrQkFBUTtBQUFBLFlBQ047QUFBQSxVQUNGO0FBQ0E7QUFBQSxRQUNGO0FBRUEsY0FBTSxtQkFBbUIsR0FBRyxzQkFBc0IsS0FBSyxTQUFTO0FBR2hFLGNBQU0sS0FBSyx1QkFBdUIsZ0JBQWdCO0FBQ2xELGNBQU0sS0FBSyx1QkFBdUIsZ0JBQWdCO0FBQ2xELGNBQU0sS0FBSyx3QkFBd0IsZ0JBQWdCO0FBQ25ELGNBQU0sS0FBSywyQkFBMkIsZ0JBQWdCO0FBQ3RELGNBQU0sS0FBSyxzQkFBc0IsZ0JBQWdCO0FBQ2pELGNBQU0sS0FBSyx3QkFBd0IsZ0JBQWdCO0FBR25ELGNBQU0sS0FBSyxhQUFhLGdCQUFnQjtBQUd4QyxjQUFNLEtBQUssdUJBQXVCLGdCQUFnQjtBQUVsRCxZQUFJLHdCQUFPLCtDQUErQztBQUMxRCxnQkFBUSxJQUFJLDhDQUE4QztBQUFBLE1BQzVELFNBQVMsT0FBUDtBQUNBLGdCQUFRLE1BQU0sNkJBQTZCLEtBQUs7QUFDaEQsWUFBSSx3QkFBTyxzREFBc0Q7QUFBQSxNQUNuRTtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRU0sdUJBQXVCLFVBQWtCO0FBQUE7QUFDN0MsWUFBTSxhQUFhLEdBQUc7QUFHdEIsWUFBTSx5QkFBeUIsS0FBSywrQkFBK0I7QUFDbkUsWUFBTSxLQUFLO0FBQUEsUUFDVCxHQUFHO0FBQUEsUUFDSDtBQUFBLE1BQ0Y7QUFHQSxZQUFNLHNCQUFzQixLQUFLLDRCQUE0QjtBQUM3RCxZQUFNLEtBQUs7QUFBQSxRQUNULEdBQUc7QUFBQSxRQUNIO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRU0sdUJBQXVCLFVBQWtCO0FBQUE7QUFDN0MsWUFBTSxhQUFhLEdBQUc7QUFHdEIsWUFBTSxpQkFBaUIsS0FBSyx1QkFBdUI7QUFDbkQsWUFBTSxLQUFLO0FBQUEsUUFDVCxHQUFHO0FBQUEsUUFDSDtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVNLHdCQUF3QixVQUFrQjtBQUFBO0FBQzlDLFlBQU0sY0FBYyxHQUFHO0FBR3ZCLFlBQU0sa0JBQWtCLEtBQUssd0JBQXdCO0FBQ3JELFlBQU0sS0FBSztBQUFBLFFBQ1QsR0FBRztBQUFBLFFBQ0g7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBO0FBQUEsRUFFTSwyQkFBMkIsVUFBa0I7QUFBQTtBQUNqRCxZQUFNLGlCQUFpQixHQUFHO0FBRzFCLFlBQU0scUJBQXFCLEtBQUssMkJBQTJCO0FBQzNELFlBQU0sS0FBSztBQUFBLFFBQ1QsR0FBRztBQUFBLFFBQ0g7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBO0FBQUEsRUFFTSxzQkFBc0IsVUFBa0I7QUFBQTtBQUM1QyxZQUFNLFlBQVksR0FBRztBQUdyQixZQUFNLG9CQUFvQixLQUFLLDBCQUEwQjtBQUN6RCxZQUFNLEtBQUs7QUFBQSxRQUNULEdBQUc7QUFBQSxRQUNIO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRU0sd0JBQXdCLFVBQWtCO0FBQUE7QUFDOUMsWUFBTSxjQUFjLEdBQUc7QUFHdkIsWUFBTSxnQkFBZ0IsS0FBSywyQkFBMkI7QUFDdEQsWUFBTSxLQUFLO0FBQUEsUUFDVCxHQUFHO0FBQUEsUUFDSDtBQUFBLE1BQ0Y7QUFHQSxZQUFNLGtCQUFrQixLQUFLLHdCQUF3QjtBQUNyRCxZQUFNLEtBQUs7QUFBQSxRQUNULEdBQUc7QUFBQSxRQUNIO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRU0sa0JBQWtCLE1BQWMsU0FBaUI7QUFBQTtBQUNyRCxVQUFJO0FBRUYsY0FBTSxlQUFlLEtBQUssSUFBSSxNQUFNLHNCQUFzQixJQUFJO0FBQzlELFlBQUksY0FBYztBQUdoQixrQkFBUSxJQUFJLG9DQUFvQyxNQUFNO0FBQ3RELGdCQUFNLE9BQU87QUFDYixnQkFBTSxLQUFLLElBQUksTUFBTSxPQUFPLE1BQU0sT0FBTztBQUN6QztBQUFBLFFBQ0Y7QUFHQSxjQUFNLEtBQUssSUFBSSxNQUFNLE9BQU8sTUFBTSxPQUFPO0FBQ3pDLGdCQUFRLElBQUksMEJBQTBCLE1BQU07QUFBQSxNQUM5QyxTQUFTLEdBQVA7QUFDQSxZQUFJLHdCQUFPLGdDQUFnQyxNQUFNO0FBQ2pELGdCQUFRLE1BQU0sZ0NBQWdDLFNBQVMsQ0FBQztBQUFBLE1BQzFEO0FBQUEsSUFDRjtBQUFBO0FBQUEsRUFFQSxpQ0FBeUM7QUFDdkMsVUFBTSxtQkFBbUIsS0FBSyxTQUFTO0FBRXZDLFFBQUksa0JBQWtCO0FBQ3BCLFVBQUksV0FBVztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1Bd0NmLEtBQUssU0FBUztBQUFBO0FBQUE7QUFBQSxNQUdkLEtBQUssU0FBUyxXQUFXLFFBQVEsUUFBUSxHQUFHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FhcEMsS0FBSyxTQUFTO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBHQWlDOEUsS0FBSyxTQUFTLGtCQUFrQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrR0FNeEMsS0FBSyxTQUFTLGtCQUFrQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFVekgsYUFBTztBQUFBLElBQ1osT0FBTztBQUNMLFVBQUksV0FBVztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FrRFAsS0FBSyxTQUFTO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBHQW9DOEUsS0FBSyxTQUFTLGtCQUFrQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrR0FNeEMsS0FBSyxTQUFTLGtCQUFrQjtBQUFBO0FBQUE7QUFLNUgsYUFBTztBQUFBLElBQ1Q7QUFBQSxFQUNGO0FBQUEsRUFFQSw4QkFBc0M7QUFDcEMsV0FBTztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBbUJUO0FBQUEsRUFFQSx5QkFBaUM7QUFDL0IsV0FBTztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBUVQsS0FBSyxTQUFTLHNCQUNWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQ0FNQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFDQXVCK0IsS0FBSyxTQUFTLGtCQUFrQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw2Q0FleEIsS0FBSyxTQUFTLGtCQUFrQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFLM0U7QUFBQSxFQUVBLDBCQUFrQztBQUNoQyxXQUFPO0FBQUE7QUFBQTtBQUFBLEVBSVQsS0FBSyxTQUFTLHNCQUNWO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0NBS0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBOEJKO0FBQUEsRUFFQSw2QkFBcUM7QUFDbkMsV0FBTztBQUFBLEVBRVQsS0FBSyxTQUFTLHNCQUNWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQ0FNQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQStCSjtBQUFBLEVBRUEsNEJBQW9DO0FBQ2xDLFdBQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBbUNUO0FBQUEsRUFFQSw2QkFBcUM7QUFDbkMsV0FBTztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFRVDtBQUFBLEVBRUEsMEJBQWtDO0FBQ2hDLFdBQU87QUFBQSxFQUNUO0FBQUEsRUFFTSxhQUFhLFVBQWtCO0FBQUE7QUFDbkMsWUFBTSxnQkFBZ0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBeUJ0QixZQUFNLEtBQUssa0JBQWtCLEdBQUcsc0JBQXNCLGFBQWE7QUFBQSxJQUNyRTtBQUFBO0FBQ0Y7OztBQzN5QkEsSUFBQUMsbUJBQW1DOzs7QUNGbkMsSUFBQUMsbUJBQW9DO0FBRTdCLElBQU0sYUFBTixjQUF5Qix1QkFBTTtBQUFBLEVBSXBDLFlBQVksS0FBVSxVQUEyQztBQUMvRCxVQUFNLEdBQUc7QUFDVCxTQUFLLFdBQVc7QUFBQSxFQUNsQjtBQUFBLEVBRUEsU0FBUztBQUNQLFVBQU0sRUFBRSxVQUFVLElBQUk7QUFFdEIsY0FBVSxTQUFTLE1BQU0sRUFBRSxNQUFNLGNBQWMsQ0FBQztBQUVoRCxRQUFJLHlCQUFRLFNBQVMsRUFDbEIsUUFBUSxPQUFPLEVBQ2Y7QUFBQSxNQUFRLENBQUMsU0FDUixLQUNHLFNBQVMsQ0FBQyxVQUFVO0FBQ25CLGFBQUssU0FBUztBQUFBLE1BQ2hCLENBQUMsRUFDQSxRQUFRLE1BQU07QUFBQSxJQUNuQjtBQUVGLFFBQUkseUJBQVEsU0FBUyxFQUNsQjtBQUFBLE1BQVUsQ0FBQyxRQUNWLElBQ0csY0FBYyxRQUFRLEVBQ3RCLE9BQU8sRUFDUCxRQUFRLE1BQU07QUFDYixhQUFLLE1BQU07QUFDWCxhQUFLLFNBQVMsS0FBSyxVQUFVLEVBQUU7QUFBQSxNQUNqQyxDQUFDO0FBQUEsSUFDTCxFQUNDO0FBQUEsTUFBVSxDQUFDLFFBQ1YsSUFBSSxjQUFjLFFBQVEsRUFBRSxRQUFRLE1BQU07QUFDeEMsYUFBSyxNQUFNO0FBQ1gsYUFBSyxTQUFTLElBQUk7QUFBQSxNQUNwQixDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0o7QUFBQSxFQUVBLFVBQVU7QUFDUixVQUFNLEVBQUUsVUFBVSxJQUFJO0FBQ3RCLGNBQVUsTUFBTTtBQUFBLEVBQ2xCO0FBQ0Y7QUFFTyxJQUFNLGlCQUFOLGNBQTZCLHVCQUFNO0FBQUEsRUFJeEMsWUFBWSxLQUFVLFNBQW1CLFVBQTJDO0FBQ2xGLFVBQU0sR0FBRztBQUNULFNBQUssV0FBVztBQUdoQixVQUFNLGtCQUE2QyxDQUFDO0FBQ3BELFlBQVEsUUFBUSxZQUFVO0FBQ3hCLHNCQUFnQixNQUFNLElBQUk7QUFBQSxJQUM1QixDQUFDO0FBRUQsU0FBSyxlQUFlLGVBQWU7QUFBQSxFQUNyQztBQUFBLEVBRUEsZUFBZSxTQUFvQztBQUNqRCxVQUFNLEVBQUUsVUFBVSxJQUFJO0FBRXRCLGNBQVUsU0FBUyxNQUFNLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQztBQUVsRCxRQUFJLGdCQUFnQixPQUFPLEtBQUssT0FBTyxFQUFFLENBQUMsS0FBSztBQUUvQyxVQUFNLFdBQVcsVUFBVSxTQUFTLFFBQVE7QUFDNUMsV0FBTyxRQUFRLE9BQU8sRUFBRSxRQUFRLENBQUMsQ0FBQyxLQUFLLEtBQUssTUFBTTtBQUNoRCxZQUFNLFNBQVMsU0FBUyxTQUFTLFVBQVU7QUFBQSxRQUN6QyxPQUFPO0FBQUEsUUFDUCxNQUFNO0FBQUEsTUFDUixDQUFDO0FBQ0QsVUFBSSxRQUFRLGVBQWU7QUFDekIsZUFBTyxXQUFXO0FBQUEsTUFDcEI7QUFBQSxJQUNGLENBQUM7QUFFRCxhQUFTLGlCQUFpQixVQUFVLENBQUMsVUFBVTtBQUM3QyxzQkFBaUIsTUFBTSxPQUE2QjtBQUNwRCxXQUFLLFNBQVM7QUFBQSxJQUNoQixDQUFDO0FBRUQsUUFBSSx5QkFBUSxTQUFTLEVBQ2xCO0FBQUEsTUFBVSxDQUFDLFFBQ1YsSUFDRyxjQUFjLFFBQVEsRUFDdEIsT0FBTyxFQUNQLFFBQVEsTUFBTTtBQUNiLGFBQUssTUFBTTtBQUNYLGFBQUssU0FBUyxhQUFhO0FBQUEsTUFDN0IsQ0FBQztBQUFBLElBQ0wsRUFDQztBQUFBLE1BQVUsQ0FBQyxRQUNWLElBQUksY0FBYyxRQUFRLEVBQUUsUUFBUSxNQUFNO0FBQ3hDLGFBQUssTUFBTTtBQUNYLGFBQUssU0FBUyxJQUFJO0FBQUEsTUFDcEIsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNKO0FBQUEsRUFFQSxTQUFTO0FBQUEsRUFFVDtBQUFBLEVBRUEsVUFBVTtBQUNSLFVBQU0sRUFBRSxVQUFVLElBQUk7QUFDdEIsY0FBVSxNQUFNO0FBQUEsRUFDbEI7QUFDRjs7O0FENUdPLElBQU0sdUJBQU4sTUFBMkI7QUFBQSxFQUloQyxZQUFZLEtBQVUsVUFBZ0M7QUFDcEQsU0FBSyxNQUFNO0FBQ1gsU0FBSyxXQUFXO0FBQUEsRUFDbEI7QUFBQSxFQUVNLHVCQUF1QjtBQUFBO0FBQzNCLFVBQUk7QUFFRixjQUFNLGdCQUFnQixNQUFNLEtBQUssb0JBQW9CO0FBRXJELFlBQUksQ0FBQyxlQUFlO0FBQ2xCLGlCQUFPO0FBQUEsUUFDVDtBQUdBLGNBQU0sYUFBYSxNQUFNLEtBQUssNEJBQTRCLGFBQWE7QUFHdkUsY0FBTSxLQUFLLHlCQUF5QixlQUFlLFVBQVU7QUFHN0QsY0FBTSxLQUFLLHdCQUF3QixVQUFVO0FBRTdDLFlBQUksd0JBQU8sV0FBVyxjQUFjLG1DQUFtQztBQUN2RSxnQkFBUTtBQUFBLFVBQ04sbUJBQW1CLGNBQWMsaUJBQWlCO0FBQUEsUUFDcEQ7QUFFQSxlQUFPO0FBQUEsTUFDVCxTQUFTLE9BQVA7QUFDQSxnQkFBUSxNQUFNLDBCQUEwQixLQUFLO0FBQzdDLFlBQUksd0JBQU8sMEJBQTBCLE1BQU0sU0FBUztBQUNwRCxlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRWMsc0JBS0o7QUFBQTtBQXJEWjtBQXNESSxVQUFJO0FBQ0YsY0FBTSxhQUFhLE1BQU0sS0FBSztBQUFBLFVBQzVCO0FBQUEsVUFDQTtBQUFBLFVBQ0EsQ0FBQyxVQUFVLE1BQU0sS0FBSyxFQUFFLFNBQVM7QUFBQSxVQUNqQztBQUFBLFFBQ0Y7QUFFQSxZQUFJLENBQUM7QUFBWSxpQkFBTztBQUV4QixjQUFNLGVBQWUsTUFBTSxLQUFLO0FBQUEsVUFDOUI7QUFBQSxVQUNBO0FBQUEsVUFDQSxDQUFDLFFBQVEsVUFBVSxVQUFVLFFBQVE7QUFBQSxRQUN2QztBQUVBLFlBQUksQ0FBQztBQUFjLGlCQUFPO0FBRTFCLGNBQU0sYUFBYSxNQUFNLEtBQUs7QUFBQSxVQUM1QjtBQUFBLFVBQ0E7QUFBQSxVQUNBLENBQUMsVUFBVSxVQUFVLEtBQUssTUFBTSxLQUFLLENBQUM7QUFBQSxVQUN0QztBQUFBLFFBQ0Y7QUFFQSxZQUFJLENBQUM7QUFBWSxpQkFBTztBQUV4QixjQUFNLGFBQVcsZ0JBQVcsTUFBTSxLQUFLLEVBQUUsQ0FBQyxNQUF6QixtQkFBNEIsV0FBVSxRQUFRLFVBQVU7QUFFekUsZUFBTztBQUFBLFVBQ0w7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxRQUNGO0FBQUEsTUFDRixTQUFTLE9BQVA7QUFDQSxnQkFBUSxNQUFNLHVDQUF1QyxLQUFLO0FBQzFELGVBQU87QUFBQSxNQUNUO0FBQUEsSUFDRjtBQUFBO0FBQUEsRUFFYyxxQkFDWixPQUNBLFNBQ0EsV0FDQSxjQUN3QjtBQUFBO0FBQ3hCLGFBQU8sSUFBSSxRQUFRLENBQUMsWUFBWTtBQUM5QixjQUFNLFFBQVEsSUFBSSxXQUFXLEtBQUssS0FBSyxDQUFDLFdBQVc7QUFDakQsY0FBSSxXQUFXLE1BQU07QUFFbkIsb0JBQVEsSUFBSTtBQUNaO0FBQUEsVUFDRjtBQUVBLGNBQUksQ0FBQyxVQUFVLE1BQU0sR0FBRztBQUN0QixnQkFBSSx3QkFBTyxZQUFZO0FBRXZCLGlCQUFLLHFCQUFxQixPQUFPLFNBQVMsV0FBVyxZQUFZLEVBQzlELEtBQUssT0FBTztBQUNmO0FBQUEsVUFDRjtBQUVBLGtCQUFRLE9BQU8sS0FBSyxDQUFDO0FBQUEsUUFDdkIsQ0FBQztBQUdELGNBQU0sUUFBUSxRQUFRLEtBQUs7QUFDM0IsY0FBTSxZQUFZLE1BQU0sVUFBVSxVQUFVO0FBQzVDLGtCQUFVLFFBQVEsT0FBTztBQUV6QixjQUFNLEtBQUs7QUFBQSxNQUNiLENBQUM7QUFBQSxJQUNIO0FBQUE7QUFBQSxFQUVjLGtCQUNaLE9BQ0EsU0FDQSxTQUN3QjtBQUFBO0FBQ3hCLGFBQU8sSUFBSSxRQUFRLENBQUMsWUFBWTtBQUM5QixjQUFNLFFBQVEsSUFBSSxlQUFlLEtBQUssS0FBSyxTQUFTLENBQUMsV0FBVztBQUM5RCxjQUFJLFdBQVcsTUFBTTtBQUVuQixvQkFBUSxJQUFJO0FBQ1o7QUFBQSxVQUNGO0FBRUEsY0FBSSxRQUFRLFNBQVMsTUFBTSxHQUFHO0FBQzVCLG9CQUFRLE1BQU07QUFBQSxVQUNoQixPQUFPO0FBQ0wsZ0JBQUksd0JBQU8seUJBQXlCLFFBQVEsS0FBSyxJQUFJLEdBQUc7QUFFeEQsaUJBQUssa0JBQWtCLE9BQU8sU0FBUyxPQUFPLEVBQzNDLEtBQUssT0FBTztBQUFBLFVBQ2pCO0FBQUEsUUFDRixDQUFDO0FBR0QsY0FBTSxRQUFRLFFBQVEsS0FBSztBQUMzQixjQUFNLFlBQVksTUFBTSxVQUFVLFVBQVU7QUFDNUMsa0JBQVUsUUFBUSxPQUFPO0FBRXpCLGNBQU0sS0FBSztBQUFBLE1BQ2IsQ0FBQztBQUFBLElBQ0g7QUFBQTtBQUFBLEVBRWMsNEJBQTRCLGVBS3RCO0FBQUE7QUFDbEIsWUFBTSxhQUFhLEdBQUcsY0FBYyxjQUFjLGNBQWMsZ0JBQWdCLGNBQWM7QUFFOUYsVUFBSTtBQUNGLGNBQU0sS0FBSyxJQUFJLE1BQU0sYUFBYSxVQUFVO0FBQzVDLGdCQUFRLElBQUksMEJBQTBCLFlBQVk7QUFDbEQsZUFBTztBQUFBLE1BQ1QsU0FBUyxPQUFQO0FBRUEsZ0JBQVEsSUFBSSw0Q0FBNEMsWUFBWTtBQUNwRSxlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRWMseUJBQ1osZUFNQSxZQUNlO0FBQUE7QUFDZixZQUFNLFdBQVcsR0FBRyxjQUFjLGNBQWM7QUFDaEQsWUFBTSxVQUFVLEtBQUssOEJBQThCLGFBQWE7QUFFaEUsVUFBSTtBQUNGLGNBQU0sS0FBSyxJQUFJLE1BQU0sT0FBTyxVQUFVLE9BQU87QUFDN0MsZ0JBQVEsSUFBSSw0QkFBNEIsVUFBVTtBQUFBLE1BQ3BELFNBQVMsT0FBUDtBQUNBLGdCQUFRLE1BQU0sbUNBQW1DLE9BQU87QUFDeEQsY0FBTTtBQUFBLE1BQ1I7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVjLHdCQUF3QixZQUFtQztBQUFBO0FBQ3ZFLFlBQU0sa0JBQWtCLEdBQUc7QUFFM0IsVUFBSTtBQUNGLGNBQU0sS0FBSyxJQUFJLE1BQU0sYUFBYSxlQUFlO0FBQ2pELGdCQUFRLElBQUksK0JBQStCLGlCQUFpQjtBQUFBLE1BQzlELFNBQVMsT0FBUDtBQUVBLGdCQUFRLElBQUksc0NBQXNDLGlCQUFpQjtBQUFBLE1BQ3JFO0FBQUEsSUFDRjtBQUFBO0FBQUEsRUFFUSw4QkFBOEIsZUFLM0I7QUFFVCxVQUFNLGtCQUFrQixJQUFJLGdCQUFnQixLQUFLLEtBQUssS0FBSyxRQUFRO0FBQ25FLFVBQU0sa0JBQWtCLGdCQUFnQiwrQkFBK0I7QUFHdkUsV0FBTyxnQkFDSixRQUFRLHFCQUFxQixjQUFjLFVBQVUsRUFDckQsUUFBUSx1QkFBdUIsY0FBYyxZQUFZLEVBQ3pELFFBQVEscUJBQXFCLGNBQWMsVUFBVSxFQUNyRCxRQUFRLG1CQUFtQixjQUFjLFFBQVEsRUFDakQsUUFBUSxzREFBc0QsSUFBSSxLQUFLLEVBQUUsWUFBWSxDQUFDLEVBQ3RGLFFBQVEseURBQXlELElBQUksS0FBSyxFQUFFLFlBQVksQ0FBQztBQUFBLEVBQzlGO0FBQ0Y7OztBRXRPQSxJQUFBQyxtQkFBMkI7QUFHcEIsSUFBTSxzQkFBTixNQUEwQjtBQUFBLEVBRy9CLFlBQVksS0FBVTtBQUNwQixTQUFLLE1BQU07QUFBQSxFQUNiO0FBQUEsRUFFQSwwQkFBMEIsU0FBMkI7QUFFbkQsVUFBTSxhQUFhO0FBQ25CLFVBQU0sZUFBZSxtQ0FBUyxNQUFNO0FBRXBDLFFBQUksY0FBYztBQUNoQixZQUFNLFlBQVksYUFBYSxDQUFDLEVBQUUsS0FBSztBQUN2QyxZQUFNLGVBQWUsVUFDbEIsUUFBUSxnQkFBZ0IsRUFBRSxFQUMxQixRQUFRLGNBQWMsRUFBRSxFQUN4QixNQUFNLElBQUksRUFDVixJQUFJLENBQUMsU0FBUyxLQUFLLEtBQUssQ0FBQyxFQUN6QixPQUFPLENBQUMsU0FBUyxLQUFLLFNBQVMsQ0FBQztBQUVuQyxhQUFPO0FBQUEsSUFDVDtBQUVBLFdBQU8sQ0FBQztBQUFBLEVBQ1Y7QUFBQSxFQUVNLDRCQUNKLFVBQ21DO0FBQUE7QUFDbkMsY0FBUSxJQUFJLHFDQUFxQyxVQUFVO0FBRTNELFVBQUk7QUFFRixjQUFNLGNBQWMsTUFBTSxLQUFLLGdCQUFnQixRQUFRO0FBRXZELFlBQUksWUFBWSxXQUFXLEdBQUc7QUFDNUIsa0JBQVEsSUFBSSw4QkFBOEIsVUFBVTtBQUNwRCxpQkFBTyxDQUFDO0FBQUEsUUFDVjtBQUdBLGNBQU0saUJBQTJDLENBQUM7QUFFbEQsbUJBQVcsUUFBUSxhQUFhO0FBQzlCLGNBQUk7QUFDRixrQkFBTSxVQUFVLE1BQU0sS0FBSyxJQUFJLE1BQU0sS0FBSyxJQUFJO0FBQzlDLGtCQUFNLGFBQWEsS0FBSywwQkFBMEIsT0FBTztBQUV6RCxnQkFBSSxXQUFXLFNBQVMsR0FBRztBQUN6Qiw2QkFBZSxLQUFLLFFBQVEsSUFBSTtBQUFBLFlBQ2xDO0FBQUEsVUFDRixTQUFTLE9BQVA7QUFDQSxvQkFBUSxNQUFNLHNCQUFzQixLQUFLLFNBQVMsS0FBSztBQUFBLFVBQ3pEO0FBQUEsUUFDRjtBQUVBLGdCQUFRO0FBQUEsVUFDTiw2QkFDRSxPQUFPLEtBQUssY0FBYyxFQUFFLDRCQUNSO0FBQUEsUUFDeEI7QUFDQSxlQUFPO0FBQUEsTUFDVCxTQUFTLE9BQVA7QUFDQSxnQkFBUTtBQUFBLFVBQ04sMENBQTBDO0FBQUEsVUFDMUM7QUFBQSxRQUNGO0FBQ0EsZUFBTyxDQUFDO0FBQUEsTUFDVjtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRU0sZ0JBQWdCLFVBQW9DO0FBQUE7QUFDeEQsWUFBTSxRQUFpQixDQUFDO0FBR3hCLFlBQU0sUUFBUSxLQUFLLElBQUksTUFBTSxpQkFBaUI7QUFFOUMsaUJBQVcsUUFBUSxPQUFPO0FBRXhCLFlBQ0UsS0FBSyxLQUFLLFNBQVMsUUFBUSxNQUMxQixNQUFNLEtBQUssb0JBQW9CLE1BQU0sUUFBUSxJQUM5QztBQUNBLGdCQUFNLEtBQUssSUFBSTtBQUFBLFFBQ2pCO0FBQUEsTUFDRjtBQUVBLGFBQU87QUFBQSxJQUNUO0FBQUE7QUFBQSxFQUVjLG9CQUNaLE1BQ0EsVUFDa0I7QUFBQTtBQUNsQixVQUFJO0FBQ0YsY0FBTSxVQUFVLE1BQU0sS0FBSyxJQUFJLE1BQU0sS0FBSyxJQUFJO0FBQzlDLGNBQU0sbUJBQW1CLFFBQVEsTUFBTSx1QkFBdUI7QUFFOUQsWUFBSSxrQkFBa0I7QUFDcEIsZ0JBQU0sY0FBYyxpQkFBaUIsQ0FBQztBQUV0QyxpQkFDRSxZQUFZLFNBQVMsY0FBYyxVQUFVLEtBQzdDLFlBQVksU0FBUyxhQUFhLFVBQVU7QUFBQSxRQUVoRDtBQUVBLGVBQU87QUFBQSxNQUNULFNBQVMsT0FBUDtBQUNBLGdCQUFRO0FBQUEsVUFDTiwwQkFBMEIsS0FBSywwQkFBMEI7QUFBQSxVQUN6RDtBQUFBLFFBQ0Y7QUFDQSxlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRU0sd0JBQ0osVUFDQSxnQkFDaUI7QUFBQTtBQUNqQixZQUFNLFdBQXFCLENBQUM7QUFDNUIsWUFBTSxjQUF3QyxDQUFDO0FBRy9DLGlCQUFXLENBQUMsVUFBVSxLQUFLLEtBQUssT0FBTyxRQUFRLGNBQWMsR0FBRztBQUM5RCxtQkFBVyxRQUFRLE9BQU87QUFDeEIsY0FBSSxDQUFDLFNBQVMsU0FBUyxJQUFJLEdBQUc7QUFDNUIscUJBQVMsS0FBSyxJQUFJO0FBQ2xCLHdCQUFZLElBQUksSUFBSSxDQUFDO0FBQUEsVUFDdkI7QUFDQSxzQkFBWSxJQUFJLEVBQUUsS0FBSyxRQUFRO0FBQUEsUUFDakM7QUFBQSxNQUNGO0FBR0EsZUFBUyxLQUFLO0FBR2QsVUFBSSxVQUFVLHdCQUF3QjtBQUFBO0FBQUE7QUFDdEMsaUJBQVcsdUJBQXVCLFNBQVM7QUFBQTtBQUFBO0FBRTNDLGlCQUFXLFFBQVEsVUFBVTtBQUMzQixtQkFBVyxNQUFNO0FBQUE7QUFDakIsbUJBQVcsZ0JBQWdCLFlBQVksSUFBSSxFQUFFLEtBQUssSUFBSTtBQUFBO0FBQUE7QUFDdEQsbUJBQVc7QUFBQTtBQUFBO0FBQ1gsbUJBQVc7QUFBQTtBQUFBO0FBQ1gsbUJBQVc7QUFBQTtBQUFBO0FBQ1gsbUJBQVc7QUFBQTtBQUFBO0FBQUEsTUFDYjtBQUVBLGFBQU87QUFBQSxJQUNUO0FBQUE7QUFBQSxFQUVNLDBCQUEwQixVQUFpQztBQUFBO0FBQy9ELFVBQUk7QUFDRixjQUFNLGlCQUFpQixNQUFNLEtBQUssNEJBQTRCLFFBQVE7QUFFdEUsWUFBSSxPQUFPLEtBQUssY0FBYyxFQUFFLFdBQVcsR0FBRztBQUM1QyxrQkFBUSxJQUFJLG1DQUFtQyxVQUFVO0FBQ3pEO0FBQUEsUUFDRjtBQUVBLGNBQU0sZUFBZSxNQUFNLEtBQUs7QUFBQSxVQUM5QjtBQUFBLFVBQ0E7QUFBQSxRQUNGO0FBR0EsY0FBTSxXQUFXLEdBQUc7QUFDcEIsY0FBTSxXQUFXLFdBQVcsWUFBWTtBQUV4QyxZQUFJO0FBQ0YsZ0JBQU0sS0FBSyxJQUFJLE1BQU0sT0FBTyxVQUFVLFlBQVk7QUFDbEQsa0JBQVEsSUFBSSxrQ0FBa0MsVUFBVTtBQUFBLFFBQzFELFNBQVMsT0FBUDtBQUVBLGdCQUFNLGVBQWUsS0FBSyxJQUFJLE1BQU0sc0JBQXNCLFFBQVE7QUFDbEUsY0FBSSxnQkFBZ0Isd0JBQXdCLHdCQUFPO0FBQ2pELGtCQUFNLEtBQUssSUFBSSxNQUFNLE9BQU8sY0FBYyxZQUFZO0FBQ3RELG9CQUFRLElBQUksa0NBQWtDLFVBQVU7QUFBQSxVQUMxRDtBQUFBLFFBQ0Y7QUFBQSxNQUNGLFNBQVMsT0FBUDtBQUNBLGdCQUFRO0FBQUEsVUFDTiw4Q0FBOEM7QUFBQSxVQUM5QztBQUFBLFFBQ0Y7QUFDQSxjQUFNO0FBQUEsTUFDUjtBQUFBLElBQ0Y7QUFBQTtBQUNGOzs7QUNyTUEsSUFBQUMsbUJBQTJCO0FBR3BCLElBQU0saUJBQU4sTUFBcUI7QUFBQSxFQUcxQixZQUFZLEtBQVU7QUFDcEIsU0FBSyxNQUFNO0FBQUEsRUFDYjtBQUFBLEVBRUEsc0JBQ0UsU0FDNkQ7QUFFN0QsVUFBTSxnQkFBZ0I7QUFDdEIsVUFBTSxVQUFVLG1DQUFTLE1BQU07QUFFL0IsUUFBSSxDQUFDLFNBQVM7QUFDWixhQUFPLENBQUM7QUFBQSxJQUNWO0FBRUEsVUFBTSxrQkFBa0IsUUFBUSxDQUFDO0FBQ2pDLFVBQU0sV0FBVyxDQUFDO0FBR2xCLFVBQU0sYUFBYTtBQUNuQixVQUFNLGVBQWUsZ0JBQWdCLE1BQU0sVUFBVTtBQUVyRCxRQUFJLGNBQWM7QUFDaEIsaUJBQVcsU0FBUyxjQUFjO0FBQ2hDLGNBQU0sT0FBTyxNQUNWLEtBQUssRUFDTCxNQUFNLElBQUksRUFDVixPQUFPLENBQUMsUUFBUSxJQUFJLFdBQVcsR0FBRyxDQUFDO0FBQ3RDLGNBQU0sYUFBYSxLQUFLLGVBQWUsSUFBSTtBQUMzQyxpQkFBUyxLQUFLLEdBQUcsVUFBVTtBQUFBLE1BQzdCO0FBQUEsSUFDRjtBQUVBLFdBQU87QUFBQSxFQUNUO0FBQUEsRUFFUSxlQUNOLE1BQzZEO0FBQzdELFFBQUksS0FBSyxTQUFTO0FBQUcsYUFBTyxDQUFDO0FBRTdCLFVBQU0sV0FBVyxDQUFDO0FBRWxCLGFBQVMsSUFBSSxHQUFHLElBQUksS0FBSyxRQUFRLEtBQUs7QUFFcEMsWUFBTSxNQUFNLEtBQUssQ0FBQztBQUNsQixZQUFNLFVBQVUsSUFDYixNQUFNLEdBQUcsRUFDVCxJQUFJLENBQUMsUUFBUSxJQUFJLEtBQUssQ0FBQyxFQUN2QixPQUFPLENBQUMsUUFBUSxHQUFHO0FBRXRCLFVBQUksUUFBUSxVQUFVLEdBQUc7QUFDdkIsY0FBTSxDQUFDLE1BQU0sWUFBWSxTQUFTLFNBQVMsSUFBSTtBQUMvQyxZQUFJLFFBQVEsY0FBYyxLQUFLLFlBQVksSUFBSSxHQUFHO0FBQ2hELG1CQUFTLEtBQUssRUFBRSxNQUFNLFlBQVksT0FBTyxDQUFDO0FBQUEsUUFDNUM7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUVBLFdBQU87QUFBQSxFQUNUO0FBQUEsRUFFUSxZQUFZLFlBQTZCO0FBQy9DLFVBQU0sWUFBWTtBQUNsQixXQUFPLFVBQVUsS0FBSyxVQUFVLEtBQUssQ0FBQyxNQUFNLEtBQUssTUFBTSxVQUFVLENBQUM7QUFBQSxFQUNwRTtBQUFBLEVBRU0sd0JBQ0osVUFDQSxXQUNBLFNBR0E7QUFBQTtBQUNBLGNBQVEsSUFBSSxpQ0FBaUMsVUFBVTtBQUV2RCxVQUFJO0FBRUYsY0FBTSxjQUFjLE1BQU0sS0FBSyxnQkFBZ0IsUUFBUTtBQUV2RCxZQUFJLFlBQVksV0FBVyxHQUFHO0FBQzVCLGtCQUFRLElBQUksOEJBQThCLFVBQVU7QUFDcEQsaUJBQU8sQ0FBQztBQUFBLFFBQ1Y7QUFHQSxjQUFNLGNBS0QsQ0FBQztBQUVOLG1CQUFXLFFBQVEsYUFBYTtBQUM5QixjQUFJO0FBQ0Ysa0JBQU0sVUFBVSxNQUFNLEtBQUssSUFBSSxNQUFNLEtBQUssSUFBSTtBQUM5QyxrQkFBTSxXQUFXLEtBQUssc0JBQXNCLE9BQU87QUFHbkQsa0JBQU0scUJBQXFCLFNBQVMsSUFBSSxDQUFDLFlBQWEsaUNBQ2pELFVBRGlEO0FBQUEsY0FFcEQsUUFBUSxLQUFLO0FBQUEsWUFDZixFQUFFO0FBRUYsd0JBQVksS0FBSyxHQUFHLGtCQUFrQjtBQUFBLFVBQ3hDLFNBQVMsT0FBUDtBQUNBLG9CQUFRLE1BQU0sc0JBQXNCLEtBQUssU0FBUyxLQUFLO0FBQUEsVUFDekQ7QUFBQSxRQUNGO0FBR0EsWUFBSSxtQkFBbUI7QUFDdkIsWUFBSSxhQUFhLFNBQVM7QUFDeEIsNkJBQW1CLEtBQUs7QUFBQSxZQUN0QjtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFHQSx5QkFBaUI7QUFBQSxVQUNmLENBQUMsR0FBRyxNQUFNLElBQUksS0FBSyxFQUFFLElBQUksRUFBRSxRQUFRLElBQUksSUFBSSxLQUFLLEVBQUUsSUFBSSxFQUFFLFFBQVE7QUFBQSxRQUNsRTtBQUVBLGdCQUFRO0FBQUEsVUFDTixTQUFTLGlCQUFpQixnQ0FBZ0M7QUFBQSxRQUM1RDtBQUNBLGVBQU87QUFBQSxNQUNULFNBQVMsT0FBUDtBQUNBLGdCQUFRLE1BQU0sc0NBQXNDLGFBQWEsS0FBSztBQUN0RSxlQUFPLENBQUM7QUFBQSxNQUNWO0FBQUEsSUFDRjtBQUFBO0FBQUEsRUFFYyxnQkFBZ0IsVUFBb0M7QUFBQTtBQUNoRSxZQUFNLFFBQWlCLENBQUM7QUFHeEIsWUFBTSxRQUFRLEtBQUssSUFBSSxNQUFNLGlCQUFpQjtBQUU5QyxpQkFBVyxRQUFRLE9BQU87QUFFeEIsWUFDRSxLQUFLLEtBQUssU0FBUyxRQUFRLE1BQzFCLE1BQU0sS0FBSyxvQkFBb0IsTUFBTSxRQUFRLElBQzlDO0FBQ0EsZ0JBQU0sS0FBSyxJQUFJO0FBQUEsUUFDakI7QUFBQSxNQUNGO0FBRUEsYUFBTztBQUFBLElBQ1Q7QUFBQTtBQUFBLEVBRWMsb0JBQ1osTUFDQSxVQUNrQjtBQUFBO0FBQ2xCLFVBQUk7QUFDRixjQUFNLFVBQVUsTUFBTSxLQUFLLElBQUksTUFBTSxLQUFLLElBQUk7QUFDOUMsY0FBTSxtQkFBbUIsUUFBUSxNQUFNLHVCQUF1QjtBQUU5RCxZQUFJLGtCQUFrQjtBQUNwQixnQkFBTSxjQUFjLGlCQUFpQixDQUFDO0FBRXRDLGlCQUNFLFlBQVksU0FBUyxjQUFjLFVBQVUsS0FDN0MsWUFBWSxTQUFTLGFBQWEsVUFBVTtBQUFBLFFBRWhEO0FBRUEsZUFBTztBQUFBLE1BQ1QsU0FBUyxPQUFQO0FBQ0EsZ0JBQVE7QUFBQSxVQUNOLDBCQUEwQixLQUFLLDBCQUEwQjtBQUFBLFVBQ3pEO0FBQUEsUUFDRjtBQUNBLGVBQU87QUFBQSxNQUNUO0FBQUEsSUFDRjtBQUFBO0FBQUEsRUFFUSxrQkFDTixVQU1BLFdBQ0EsU0FNQztBQUNELFdBQU8sU0FBUyxPQUFPLENBQUMsWUFBWTtBQUNsQyxZQUFNLGNBQWMsSUFBSSxLQUFLLFFBQVEsSUFBSSxFQUFFLFFBQVE7QUFFbkQsVUFBSSxhQUFhLGNBQWMsSUFBSSxLQUFLLFNBQVMsRUFBRSxRQUFRLEdBQUc7QUFDNUQsZUFBTztBQUFBLE1BQ1Q7QUFFQSxVQUFJLFdBQVcsY0FBYyxJQUFJLEtBQUssT0FBTyxFQUFFLFFBQVEsR0FBRztBQUN4RCxlQUFPO0FBQUEsTUFDVDtBQUVBLGFBQU87QUFBQSxJQUNULENBQUM7QUFBQSxFQUNIO0FBQUEsRUFFTSx3QkFDSixVQUNBLFVBTWlCO0FBQUE7QUFDakIsVUFBSSxTQUFTLFdBQVcsR0FBRztBQUN6QixlQUFPLHlCQUF5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BQ2xDO0FBR0EsWUFBTSxXQUFXLFNBQVMsT0FBTyxDQUFDLEtBQUssWUFBWTtBQUNqRCxZQUFJLENBQUMsSUFBSSxRQUFRLE1BQU0sR0FBRztBQUN4QixjQUFJLFFBQVEsTUFBTSxJQUFJLENBQUM7QUFBQSxRQUN6QjtBQUNBLFlBQUksUUFBUSxNQUFNLEVBQUUsS0FBSyxPQUFPO0FBQ2hDLGVBQU87QUFBQSxNQUNULEdBQUcsQ0FBQyxDQUFvQztBQUV4QyxVQUFJLFVBQVUseUJBQXlCO0FBQUE7QUFBQTtBQUN2QyxpQkFBVyxzQkFBc0IsU0FBUztBQUFBO0FBQUE7QUFHMUMsaUJBQVcsQ0FBQyxRQUFRLEtBQUssS0FBSyxPQUFPLFFBQVEsUUFBUSxHQUFHO0FBQ3RELG1CQUFXLE1BQU0sT0FBTyxPQUFPLENBQUMsRUFBRSxZQUFZLElBQUksT0FBTyxNQUFNLENBQUMsTUFDOUQsTUFBTTtBQUFBO0FBQUE7QUFFUixtQkFBVztBQUFBO0FBQ1gsbUJBQVc7QUFBQTtBQUVYLG1CQUFXLFFBQVEsT0FBTztBQUN4QixxQkFBVyxLQUFLLEtBQUssVUFBVSxLQUFLLGdCQUFnQixLQUFLO0FBQUE7QUFBQSxRQUMzRDtBQUNBLG1CQUFXO0FBQUE7QUFBQSxNQUNiO0FBRUEsYUFBTztBQUFBLElBQ1Q7QUFBQTtBQUFBLEVBRU0sMEJBQ0osVUFDQSxXQUNBLFNBQ2U7QUFBQTtBQUNmLFVBQUk7QUFDRixjQUFNLFdBQVcsTUFBTSxLQUFLO0FBQUEsVUFDMUI7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFFBQ0Y7QUFFQSxjQUFNLGlCQUFpQixNQUFNLEtBQUs7QUFBQSxVQUNoQztBQUFBLFVBQ0E7QUFBQSxRQUNGO0FBR0EsY0FBTSxXQUFXLEdBQUc7QUFDcEIsY0FBTSxXQUFXLFdBQVcsWUFBWTtBQUV4QyxZQUFJO0FBQ0YsZ0JBQU0sS0FBSyxJQUFJLE1BQU0sT0FBTyxVQUFVLGNBQWM7QUFDcEQsa0JBQVEsSUFBSSxtQ0FBbUMsVUFBVTtBQUFBLFFBQzNELFNBQVMsT0FBUDtBQUVBLGdCQUFNLGVBQWUsS0FBSyxJQUFJLE1BQU0sc0JBQXNCLFFBQVE7QUFDbEUsY0FBSSxnQkFBZ0Isd0JBQXdCLHdCQUFPO0FBQ2pELGtCQUFNLEtBQUssSUFBSSxNQUFNLE9BQU8sY0FBYyxjQUFjO0FBQ3hELG9CQUFRLElBQUksbUNBQW1DLFVBQVU7QUFBQSxVQUMzRDtBQUFBLFFBQ0Y7QUFBQSxNQUNGLFNBQVMsT0FBUDtBQUNBLGdCQUFRO0FBQUEsVUFDTiwrQ0FBK0M7QUFBQSxVQUMvQztBQUFBLFFBQ0Y7QUFDQSxjQUFNO0FBQUEsTUFDUjtBQUFBLElBQ0Y7QUFBQTtBQUNGOzs7QUN6U0EsSUFBQUMsbUJBQTJCO0FBRXBCLElBQU0sd0JBQU4sTUFBNEI7QUFBQSxFQUdqQyxZQUFZLEtBQVU7QUFDcEIsU0FBSyxNQUFNO0FBQUEsRUFDYjtBQUFBLEVBRU0sc0JBRUo7QUFBQTtBQUNBLGNBQVEsSUFBSSxxQ0FBcUM7QUFFakQsVUFBSTtBQUNGLGNBQU0sUUFBUSxJQUFJLEtBQUs7QUFDdkIsY0FBTSxjQUFjLE1BQU0sWUFBWSxFQUFFLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFHcEQsY0FBTSxRQUFRLEtBQUssSUFBSSxNQUFNLGlCQUFpQjtBQUM5QyxjQUFNLGNBQXVCLENBQUM7QUFFOUIsbUJBQVcsUUFBUSxPQUFPO0FBQ3hCLGdCQUFNLFdBQVcsS0FBSyxvQkFBb0IsS0FBSyxJQUFJO0FBQ25ELGNBQUksYUFBYSxhQUFhO0FBQzVCLHdCQUFZLEtBQUssSUFBSTtBQUFBLFVBQ3ZCO0FBQUEsUUFDRjtBQUdBLGNBQU0sYUFDSixDQUFDO0FBRUgsbUJBQVcsUUFBUSxhQUFhO0FBQzlCLGdCQUFNLFdBQVcsTUFBTSxLQUFLLG9CQUFvQixJQUFJO0FBQ3BELGNBQUksVUFBVTtBQUNaLHVCQUFXLEtBQUssUUFBUTtBQUFBLFVBQzFCO0FBQUEsUUFDRjtBQUVBLGdCQUFRLElBQUksU0FBUyxXQUFXLHNDQUFzQztBQUN0RSxlQUFPO0FBQUEsTUFDVCxTQUFTLE9BQVA7QUFDQSxnQkFBUSxNQUFNLHFDQUFxQyxLQUFLO0FBQ3hELGVBQU8sQ0FBQztBQUFBLE1BQ1Y7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVNLHlCQUNKLFVBQ0EsTUFDZ0Q7QUFBQTtBQUNoRCxjQUFRLElBQUksK0JBQStCLG9CQUFvQixNQUFNO0FBRXJFLFVBQUk7QUFFRixjQUFNLGNBQWMsTUFBTSxLQUFLLHVCQUF1QixVQUFVLElBQUk7QUFFcEUsY0FBTSxhQUFvRCxDQUFDO0FBRTNELG1CQUFXLFFBQVEsYUFBYTtBQUM5QixnQkFBTSxVQUFVLE1BQU0sS0FBSyxJQUFJLE1BQU0sS0FBSyxJQUFJO0FBQzlDLGdCQUFNLFdBQVcsS0FBSyxrQkFBa0IsTUFBTSxPQUFPO0FBRXJELHFCQUFXLEtBQUs7QUFBQSxZQUNkLE1BQU0sS0FBSztBQUFBLFlBQ1gsTUFBTTtBQUFBLFVBQ1IsQ0FBQztBQUFBLFFBQ0g7QUFFQSxnQkFBUTtBQUFBLFVBQ04sU0FBUyxXQUFXLGdDQUFnQyxlQUFlO0FBQUEsUUFDckU7QUFDQSxlQUFPO0FBQUEsTUFDVCxTQUFTLE9BQVA7QUFDQSxnQkFBUTtBQUFBLFVBQ04scUNBQXFDLGVBQWU7QUFBQSxVQUNwRDtBQUFBLFFBQ0Y7QUFDQSxlQUFPLENBQUM7QUFBQSxNQUNWO0FBQUEsSUFDRjtBQUFBO0FBQUEsRUFFUSxvQkFBb0IsVUFBaUM7QUFFM0QsVUFBTSxZQUFZO0FBQ2xCLFVBQU0sVUFBVSxTQUFTLE1BQU0sU0FBUztBQUN4QyxXQUFPLFVBQVUsUUFBUSxRQUFRLFNBQVMsQ0FBQyxJQUFJO0FBQUEsRUFDakQ7QUFBQSxFQUVjLG9CQUNaLE1BQ2lFO0FBQUE7QUFDakUsVUFBSTtBQUNGLGNBQU0sVUFBVSxNQUFNLEtBQUssSUFBSSxNQUFNLEtBQUssSUFBSTtBQUc5QyxjQUFNLFdBQVcsS0FBSyxrQkFBa0IsTUFBTSxPQUFPO0FBR3JELGNBQU0sV0FDSixLQUFLLDJCQUEyQixPQUFPLEtBQ3ZDLEtBQUssd0JBQXdCLEtBQUssSUFBSTtBQUV4QyxlQUFPO0FBQUEsVUFDTCxNQUFNLEtBQUs7QUFBQSxVQUNYLE1BQU07QUFBQSxVQUNOLFFBQVEsWUFBWTtBQUFBLFFBQ3RCO0FBQUEsTUFDRixTQUFTLE9BQVA7QUFDQSxnQkFBUSxNQUFNLHdCQUF3QixLQUFLLFNBQVMsS0FBSztBQUN6RCxlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRVEsa0JBQWtCLE1BQWEsU0FBeUI7QUFDOUQsVUFBTSxPQUFPLEtBQUssS0FBSyxZQUFZO0FBR25DLFFBQ0UsS0FBSyxTQUFTLE9BQU8sS0FDckIsUUFBUSxTQUFTLDBCQUEwQixHQUMzQztBQUNBLGFBQU87QUFBQSxJQUNUO0FBR0EsUUFBSSxLQUFLLFNBQVMsU0FBUyxLQUFLLFFBQVEsU0FBUyxZQUFZLEdBQUc7QUFDOUQsVUFBSSxRQUFRLFNBQVMsK0JBQStCLEdBQUc7QUFDckQsZUFBTztBQUFBLE1BQ1Q7QUFDQSxVQUFJLFFBQVEsU0FBUyxzQkFBc0IsR0FBRztBQUM1QyxlQUFPO0FBQUEsTUFDVDtBQUNBLFVBQUksUUFBUSxTQUFTLHVCQUF1QixHQUFHO0FBQzdDLGVBQU87QUFBQSxNQUNUO0FBQ0EsVUFBSSxRQUFRLFNBQVMsMEJBQTBCLEdBQUc7QUFDaEQsZUFBTztBQUFBLE1BQ1Q7QUFDQSxhQUFPO0FBQUEsSUFDVDtBQUdBLFFBQUksUUFBUSxTQUFTLEtBQUssS0FBSyxRQUFRLE1BQU0saUJBQWlCLEdBQUc7QUFDL0QsYUFBTztBQUFBLElBQ1Q7QUFFQSxXQUFPO0FBQUEsRUFDVDtBQUFBLEVBRVEsMkJBQTJCLFNBQWdDO0FBQ2pFLFVBQU0sZ0JBQWdCO0FBQ3RCLFVBQU0sUUFBUSxRQUFRLE1BQU0sYUFBYTtBQUN6QyxXQUFPLFFBQVEsTUFBTSxDQUFDLElBQUk7QUFBQSxFQUM1QjtBQUFBLEVBRVEsd0JBQXdCLFVBQWlDO0FBQy9ELFVBQU0sZ0JBQWdCO0FBQ3RCLFVBQU0sVUFBVSxTQUFTLE1BQU0sYUFBYTtBQUM1QyxXQUFPLFVBQVUsUUFBUSxRQUFRLFNBQVMsQ0FBQyxJQUFJO0FBQUEsRUFDakQ7QUFBQSxFQUVjLHVCQUNaLFVBQ0EsTUFDa0I7QUFBQTtBQUNsQixZQUFNLFFBQWlCLENBQUM7QUFHeEIsWUFBTSxXQUFXLEtBQUssSUFBSSxNQUFNLGlCQUFpQjtBQUVqRCxpQkFBVyxRQUFRLFVBQVU7QUFFM0IsWUFDRSxLQUFLLEtBQUssU0FBUyxRQUFRLE1BQzFCLE1BQU0sS0FBSyxvQkFBb0IsTUFBTSxRQUFRLElBQzlDO0FBRUEsZ0JBQU0sV0FBVyxLQUFLLG9CQUFvQixLQUFLLElBQUk7QUFDbkQsY0FBSSxhQUFhLE1BQU07QUFDckIsa0JBQU0sS0FBSyxJQUFJO0FBQUEsVUFDakI7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUVBLGFBQU87QUFBQSxJQUNUO0FBQUE7QUFBQSxFQUVjLG9CQUNaLE1BQ0EsVUFDa0I7QUFBQTtBQUNsQixVQUFJO0FBQ0YsY0FBTSxVQUFVLE1BQU0sS0FBSyxJQUFJLE1BQU0sS0FBSyxJQUFJO0FBQzlDLGVBQU8sS0FBSywyQkFBMkIsT0FBTyxNQUFNO0FBQUEsTUFDdEQsU0FBUyxPQUFQO0FBQ0EsZ0JBQVE7QUFBQSxVQUNOLDBCQUEwQixLQUFLLDBCQUEwQjtBQUFBLFVBQ3pEO0FBQUEsUUFDRjtBQUNBLGVBQU87QUFBQSxNQUNUO0FBQUEsSUFDRjtBQUFBO0FBQUEsRUFFTSxxQkFBcUIsTUFBZ0M7QUFBQTtBQUN6RCxZQUFNLGFBQWEsUUFBUSxJQUFJLEtBQUssRUFBRSxZQUFZLEVBQUUsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUNoRSxZQUFNLGFBQWEsTUFBTSxLQUFLLHlCQUF5QixJQUFJLFVBQVU7QUFFckUsVUFBSSxXQUFXLFdBQVcsR0FBRztBQUMzQixlQUFPLDJCQUEyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BQ3BDO0FBR0EsWUFBTSxXQUE4QyxDQUFDO0FBQ3JELFlBQU0sV0FBOEIsQ0FBQztBQUVyQyxpQkFBVyxZQUFZLFlBQVk7QUFDakMsWUFBSSxTQUFTLEtBQUssU0FBUyxVQUFVLEdBQUc7QUFFdEMsZ0JBQU0sWUFBWSxTQUFTLEtBQUssTUFBTSxHQUFHO0FBQ3pDLGdCQUFNLGNBQWMsVUFBVSxVQUFVLENBQUMsU0FBUyxLQUFLLFNBQVMsR0FBRyxDQUFDO0FBQ3BFLGNBQUksZUFBZSxHQUFHO0FBQ3BCLGtCQUFNLFdBQVcsVUFBVSxXQUFXO0FBQ3RDLGdCQUFJLENBQUMsU0FBUyxRQUFRLEdBQUc7QUFDdkIsdUJBQVMsUUFBUSxJQUFJLENBQUM7QUFBQSxZQUN4QjtBQUNBLHFCQUFTLFFBQVEsRUFBRSxLQUFLLFFBQVE7QUFBQSxVQUNsQyxPQUFPO0FBQ0wscUJBQVMsS0FBSyxRQUFRO0FBQUEsVUFDeEI7QUFBQSxRQUNGLE9BQU87QUFDTCxtQkFBUyxLQUFLLFFBQVE7QUFBQSxRQUN4QjtBQUFBLE1BQ0Y7QUFFQSxVQUFJLFVBQVUsMkJBQTJCO0FBQUE7QUFBQTtBQUN6QyxpQkFBVyxxQkFBcUIsV0FBVztBQUFBO0FBQUE7QUFHM0MsaUJBQVcsQ0FBQyxVQUFVLGdCQUFnQixLQUFLLE9BQU8sUUFBUSxRQUFRLEdBQUc7QUFDbkUsbUJBQVcsTUFBTTtBQUFBO0FBQUE7QUFDakIsbUJBQVc7QUFBQTtBQUNYLG1CQUFXO0FBQUE7QUFFWCxtQkFBVyxZQUFZLGtCQUFrQjtBQUN2QyxxQkFBVyxLQUFLLFNBQVMsVUFBVSxTQUFTO0FBQUE7QUFBQSxRQUM5QztBQUNBLG1CQUFXO0FBQUE7QUFBQSxNQUNiO0FBR0EsVUFBSSxTQUFTLFNBQVMsR0FBRztBQUN2QixtQkFBVztBQUFBO0FBQUE7QUFDWCxtQkFBVztBQUFBO0FBQ1gsbUJBQVc7QUFBQTtBQUVYLG1CQUFXLFlBQVksVUFBVTtBQUMvQixxQkFBVyxLQUFLLFNBQVMsVUFBVSxTQUFTO0FBQUE7QUFBQSxRQUM5QztBQUNBLG1CQUFXO0FBQUE7QUFBQSxNQUNiO0FBRUEsYUFBTztBQUFBLElBQ1Q7QUFBQTtBQUFBLEVBRU0sdUJBQXVCLE1BQThCO0FBQUE7QUFDekQsVUFBSTtBQUNGLGNBQU0sYUFBYSxRQUFRLElBQUksS0FBSyxFQUFFLFlBQVksRUFBRSxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQ2hFLGNBQU0saUJBQWlCLE1BQU0sS0FBSyxxQkFBcUIsVUFBVTtBQUdqRSxjQUFNLFdBQVcsR0FBRztBQUNwQixjQUFNLFdBQVcsU0FBUztBQUUxQixZQUFJO0FBQ0YsZ0JBQU0sS0FBSyxJQUFJLE1BQU0sT0FBTyxVQUFVLGNBQWM7QUFDcEQsa0JBQVEsSUFBSSwrQkFBK0IsVUFBVTtBQUFBLFFBQ3ZELFNBQVMsT0FBUDtBQUVBLGdCQUFNLGVBQWUsS0FBSyxJQUFJLE1BQU0sc0JBQXNCLFFBQVE7QUFDbEUsY0FBSSxnQkFBZ0Isd0JBQXdCLHdCQUFPO0FBQ2pELGtCQUFNLEtBQUssSUFBSSxNQUFNLE9BQU8sY0FBYyxjQUFjO0FBQ3hELG9CQUFRLElBQUksK0JBQStCLFVBQVU7QUFBQSxVQUN2RDtBQUFBLFFBQ0Y7QUFBQSxNQUNGLFNBQVMsT0FBUDtBQUNBLGdCQUFRLE1BQU0sb0NBQW9DLFNBQVMsS0FBSztBQUNoRSxjQUFNO0FBQUEsTUFDUjtBQUFBLElBQ0Y7QUFBQTtBQUNGOzs7QUNyU0EsSUFBQUMsbUJBQXVEO0FBVWhELElBQU0sbUJBQU4sY0FBK0IsdUJBQU07QUFBQSxFQU0xQyxZQUNFLEtBQ0EsWUFDQSxVQUNBLFVBQ0E7QUFDQSxVQUFNLEdBQUc7QUFDVCxTQUFLLGNBQWMsQ0FBQyxFQUFFLE1BQU0sSUFBSSxTQUFTLElBQUksTUFBTSxJQUFJLFFBQVEsSUFBSSxhQUFhLEdBQUcsQ0FBQztBQUNwRixTQUFLLGFBQWE7QUFDbEIsU0FBSyxXQUFXO0FBQ2hCLFNBQUssV0FBVztBQUFBLEVBQ2xCO0FBQUEsRUFFQSxTQUFTO0FBQ1AsVUFBTSxFQUFFLFVBQVUsSUFBSTtBQUN0QixjQUFVLE1BQU07QUFDaEIsY0FBVSxTQUFTLGlDQUFpQztBQUVwRCxjQUFVLFNBQVMsTUFBTSxFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFHaEUsUUFBSSx5QkFBUSxTQUFTLEVBQ2xCLFFBQVEsUUFBUSxFQUNoQixRQUFRLEdBQUcsS0FBSyxlQUFlLEtBQUssV0FBVyxFQUMvQyxZQUFZLElBQUk7QUFHbkIsVUFBTSx1QkFBdUIsVUFBVSxVQUFVLEVBQUUsS0FBSyx3QkFBd0IsQ0FBQztBQUdqRixTQUFLLHFCQUFxQixzQkFBc0IsQ0FBQztBQUdqRCxRQUFJLHlCQUFRLFNBQVMsRUFDbEI7QUFBQSxNQUFVLENBQUMsUUFDVixJQUNHLGNBQWMsZ0JBQWdCLEVBQzlCLE9BQU8sRUFDUCxRQUFRLE1BQU07QUFDYixjQUFNLFdBQVcsS0FBSyxZQUFZO0FBQ2xDLGFBQUssWUFBWSxLQUFLLEVBQUUsTUFBTSxJQUFJLFNBQVMsSUFBSSxNQUFNLElBQUksUUFBUSxJQUFJLGFBQWEsR0FBRyxDQUFDO0FBQ3RGLGFBQUsscUJBQXFCLHNCQUFzQixRQUFRO0FBQUEsTUFDMUQsQ0FBQztBQUFBLElBQ0w7QUFHRixRQUFJLHlCQUFRLFNBQVMsRUFDbEI7QUFBQSxNQUFVLENBQUMsUUFDVixJQUNHLGNBQWMsb0JBQW9CLEVBQ2xDLE9BQU8sRUFDUCxRQUFRLE1BQU07QUFFYixjQUFNLG1CQUFtQixLQUFLLFlBQVk7QUFBQSxVQUN4QyxDQUFDLE1BQU0sRUFBRSxLQUFLLEtBQUssTUFBTSxNQUFNLEVBQUUsUUFBUSxLQUFLLE1BQU07QUFBQSxRQUN0RDtBQUNBLGFBQUssU0FBUyxrQkFBa0IsS0FBSyxZQUFZLEtBQUssUUFBUTtBQUM5RCxhQUFLLE1BQU07QUFBQSxNQUNiLENBQUM7QUFBQSxJQUNMO0FBQUEsRUFDSjtBQUFBLEVBRUEscUJBQXFCLFdBQXdCLE9BQWU7QUFDMUQsVUFBTSxVQUFVLFVBQVUsVUFBVSxFQUFFLEtBQUsscUJBQXFCLENBQUM7QUFDakUsWUFBUSxTQUFTLE1BQU0sRUFBRSxNQUFNLGVBQWUsUUFBUSxJQUFJLENBQUM7QUFFM0QsUUFBSSx5QkFBUSxPQUFPLEVBQ2hCLFFBQVEsaUJBQWlCLEVBQ3pCO0FBQUEsTUFBUSxDQUFDLFNBQ1IsS0FDRyxlQUFlLHVCQUF1QixFQUN0QyxTQUFTLEtBQUssWUFBWSxLQUFLLEVBQUUsSUFBSSxFQUNyQyxTQUFTLENBQUMsVUFBVTtBQUNuQixhQUFLLFlBQVksS0FBSyxFQUFFLE9BQU87QUFBQSxNQUNqQyxDQUFDO0FBQUEsSUFDTDtBQUVGLFFBQUkseUJBQVEsT0FBTyxFQUNoQixRQUFRLFVBQVUsRUFDbEIsUUFBUSxvQkFBb0IsRUFDNUI7QUFBQSxNQUFRLENBQUMsU0FDUixLQUNHLGVBQWUsWUFBWSxFQUMzQixTQUFTLEtBQUssWUFBWSxLQUFLLEVBQUUsT0FBTyxFQUN4QyxTQUFTLENBQUMsVUFBVTtBQUNuQixhQUFLLFlBQVksS0FBSyxFQUFFLFVBQVU7QUFBQSxNQUNwQyxDQUFDO0FBQUEsSUFDTDtBQUVGLFFBQUkseUJBQVEsT0FBTyxFQUNoQixRQUFRLGlCQUFpQixFQUN6QjtBQUFBLE1BQVEsQ0FBQyxTQUNSLEtBQ0csZUFBZSw0QkFBNEIsRUFDM0MsU0FBUyxLQUFLLFlBQVksS0FBSyxFQUFFLElBQUksRUFDckMsU0FBUyxDQUFDLFVBQVU7QUFDbkIsYUFBSyxZQUFZLEtBQUssRUFBRSxPQUFPO0FBQUEsTUFDakMsQ0FBQztBQUFBLElBQ0w7QUFFRixRQUFJLHlCQUFRLE9BQU8sRUFDaEIsUUFBUSxRQUFRLEVBQ2hCO0FBQUEsTUFBUSxDQUFDLFNBQ1IsS0FDRyxlQUFlLFdBQVcsRUFDMUIsU0FBUyxLQUFLLFlBQVksS0FBSyxFQUFFLE1BQU0sRUFDdkMsU0FBUyxDQUFDLFVBQVU7QUFDbkIsYUFBSyxZQUFZLEtBQUssRUFBRSxTQUFTO0FBQUEsTUFDbkMsQ0FBQztBQUFBLElBQ0w7QUFFRixRQUFJLHlCQUFRLE9BQU8sRUFDaEIsUUFBUSxhQUFhLEVBQ3JCO0FBQUEsTUFBWSxDQUFDLFNBQ1osS0FDRyxlQUFlLDhCQUE4QixFQUM3QyxTQUFTLEtBQUssWUFBWSxLQUFLLEVBQUUsV0FBVyxFQUM1QyxTQUFTLENBQUMsVUFBVTtBQUNuQixhQUFLLFlBQVksS0FBSyxFQUFFLGNBQWM7QUFBQSxNQUN4QyxDQUFDO0FBQUEsSUFDTDtBQUdGLFFBQUksS0FBSyxZQUFZLFNBQVMsR0FBRztBQUMvQixVQUFJLHlCQUFRLE9BQU8sRUFDaEI7QUFBQSxRQUFVLENBQUMsUUFDVixJQUNHLGNBQWMsUUFBUSxFQUN0QixRQUFRLE1BQU07QUFDYixlQUFLLFlBQVksT0FBTyxPQUFPLENBQUM7QUFDaEMsa0JBQVEsT0FBTztBQUNmLGVBQUssb0JBQW9CO0FBQUEsUUFDM0IsQ0FBQztBQUFBLE1BQ0w7QUFBQSxJQUNKO0FBQUEsRUFDRjtBQUFBLEVBRUEsc0JBQXNCO0FBQ3BCLFVBQU0sV0FBVyxLQUFLLFVBQVUsaUJBQWlCLHFCQUFxQjtBQUN0RSxhQUFTLFFBQVEsQ0FBQyxTQUFTLFVBQVU7QUFDbkMsWUFBTSxTQUFTLFFBQVEsY0FBYyxJQUFJO0FBQ3pDLFVBQUksUUFBUTtBQUNWLGVBQU8sY0FBYyxlQUFlLFFBQVE7QUFBQSxNQUM5QztBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0g7QUFBQSxFQUVBLFVBQVU7QUFDUixVQUFNLEVBQUUsVUFBVSxJQUFJO0FBQ3RCLGNBQVUsTUFBTTtBQUFBLEVBQ2xCO0FBQ0Y7OztBQzdKQSxTQUFzQix3QkFBd0IsSUFBUyxVQUFrQjtBQUFBO0FBQ3JFLFFBQUk7QUFFQSxZQUFNLFFBQVEsR0FBRyxNQUFNLFFBQVEsRUFDMUIsT0FBTyxDQUFDLE1BQVcsRUFBRSxLQUFLLFFBQVEsUUFBUSxFQUFFLEtBQUssU0FBUyxRQUFRLEVBQ2xFLElBQUksQ0FBQyxPQUFZO0FBQUEsUUFDZCxNQUFNLEVBQUUsS0FBSztBQUFBLFFBQ2IsTUFBTSxFQUFFLEtBQUs7QUFBQSxNQUNqQixFQUFFO0FBR04sU0FBRyxPQUFPLEdBQUcsdUJBQXVCO0FBRXBDLGlCQUFXLFFBQVEsT0FBTztBQUN0QixZQUFJLENBQUMsS0FBSztBQUFNO0FBRWhCLFlBQUk7QUFDQSxnQkFBTSxPQUFPLE1BQU0sR0FBRyxJQUFJLE1BQU0sY0FBYyxLQUFLLElBQUk7QUFDdkQsZ0JBQU0sVUFBVSxNQUFNLEdBQUcsSUFBSSxNQUFNLEtBQUssSUFBSTtBQUc1QyxnQkFBTSxhQUFhO0FBQ25CLGdCQUFNLGVBQWUsbUNBQVMsTUFBTTtBQUVwQyxjQUFJLGNBQWM7QUFDZCxrQkFBTSxZQUFZLGFBQWEsQ0FBQyxFQUFFLEtBQUs7QUFDdkMsa0JBQU0sZUFBZSxVQUNoQixRQUFRLGdCQUFnQixFQUFFLEVBQzFCLEtBQUssRUFDTCxNQUFNLElBQUksRUFDVixPQUFPLENBQUMsU0FBaUIsS0FBSyxXQUFXLElBQUksQ0FBQyxFQUM5QyxJQUFJLENBQUMsU0FBaUIsS0FBSyxVQUFVLENBQUMsQ0FBQyxFQUN2QyxPQUFPLE9BQU87QUFFbkIsZ0JBQUksYUFBYSxTQUFTLEdBQUc7QUFDekIsaUJBQUcsT0FBTyxHQUFHLEtBQUssS0FBSyxRQUFRO0FBQy9CLGlCQUFHLEtBQUssWUFBWTtBQUFBLFlBQ3hCO0FBQUEsVUFDSjtBQUFBLFFBRUosU0FBUyxHQUFQO0FBQ0Usa0JBQVEsSUFBSSxvQkFBb0IsS0FBSyxTQUFTLENBQUM7QUFDL0M7QUFBQSxRQUNKO0FBQUEsTUFDSjtBQUFBLElBRUosU0FBUyxPQUFQO0FBQ0UsY0FBUSxNQUFNLG1DQUFtQyxLQUFLO0FBQUEsSUFDMUQ7QUFBQSxFQUNKO0FBQUE7QUFTQSxTQUFzQixnQkFBZ0IsSUFBUyxRQUFnQixZQUEyQixNQUFNLFVBQXlCLE1BQU07QUFBQTtBQXBFL0g7QUFxRUksYUFBUywyQkFBMkIsS0FBWTtBQUM1QyxZQUFNLE9BQU8sb0JBQUksSUFBSTtBQUNyQixhQUFPLElBQUksT0FBTyxDQUFDLFVBQWU7QUFDOUIsY0FBTSxNQUFNLEtBQUssVUFBVSxDQUFDLE1BQU0sQ0FBQyxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFDL0MsZUFBTyxDQUFDLEtBQUssSUFBSSxHQUFHLEtBQUssS0FBSyxJQUFJLEdBQUc7QUFBQSxNQUN6QyxDQUFDO0FBQUEsSUFDTDtBQUdBLFVBQU0sbUJBQW9CLE9BQWUsT0FBTyxFQUFFLFNBQVMsR0FBRyxLQUFLLEVBQUUsT0FBTyxZQUFZO0FBQ3hGLFVBQU0sUUFBUSxhQUFhO0FBQzNCLFVBQU0sTUFBTSxXQUFZLE9BQWUsT0FBTyxFQUFFLElBQUksR0FBRyxNQUFNLEVBQUUsT0FBTyxZQUFZO0FBRWxGLFVBQU0sUUFBUSxNQUFNLEdBQUcsTUFBTSxNQUFNLEVBQzlCLE9BQU8sQ0FBQyxNQUFXLEVBQUUsS0FBSyxTQUFTLFVBQVUsRUFBRSxLQUFLLE9BQU8sSUFBSTtBQUVwRSxRQUFJLGFBQW9CLENBQUM7QUFFekIsZUFBVyxRQUFRLE1BQU0sUUFBUTtBQUM3QixVQUFJLEdBQUMsa0NBQU0sU0FBTixtQkFBWSxPQUFNO0FBQUU7QUFBQSxNQUFPO0FBQ2hDLFlBQU0sVUFBVSxNQUFPLEdBQUcsSUFBSSxNQUFjLFdBQVksR0FBRyxJQUFJLE1BQWMsZUFBYyxVQUFLLFNBQUwsbUJBQVcsSUFBSSxDQUFDO0FBQzNHLFlBQU0sUUFBUTtBQUNkLFlBQU0sVUFBVSxtQ0FBUyxNQUFNO0FBQy9CLFVBQUksU0FBUztBQUNiLGNBQU0sWUFBWSxRQUFRLENBQUMsRUFBRSxLQUFLO0FBQ2xDLGNBQU0sUUFBUSxVQUFVLE1BQU0sSUFBSSxFQUFFLE1BQU0sQ0FBQztBQUMzQyxtQkFBVyxRQUFRLE9BQU87QUFDdEIsY0FBSTtBQUNKLGdCQUFNLFVBQVUsS0FDZixNQUFNLEdBQUcsRUFDVCxJQUFJLENBQUMsTUFBYyxFQUFFLEtBQUssQ0FBQyxFQUMzQixPQUFPLENBQUMsTUFBYyxDQUFDO0FBQ3hCLGNBQUksQ0FBQyxTQUFTLFVBQVUsSUFBSTtBQUM1QixjQUFJLENBQUMsS0FBSyxNQUFNLE9BQU8sTUFBSyx5Q0FBWSxNQUFNLE9BQU07QUFDcEQ7QUFBQSxVQUNBO0FBQ0Esd0JBQWEseUNBQVksTUFBTSx3QkFDN0IsYUFDQSxJQUFJLEtBQUssZUFBZTtBQUUxQixjQUNDLE9BQWUsT0FBTyxPQUFPLEVBQUUsVUFBVSxPQUFPLEtBQUssUUFBVyxJQUFJLEdBQ25FO0FBQ0Ysa0JBQU0sWUFBWSxDQUFDLFdBQVc7QUFBQSxjQUMxQixDQUFDLE1BQVE7QUFqSHpCLG9CQUFBQztBQWtIZ0IseUJBQUUsQ0FBQyxFQUFFLE9BQU9BLE1BQUEsT0FBZSxPQUFPLE9BQU8sTUFBN0IsZ0JBQUFBLElBQWdDLE9BQU8sYUFBYSxLQUNoRSxFQUFFLENBQUMsS0FBSztBQUFBO0FBQUEsWUFDWjtBQUNBLGdCQUFJLGNBQWMsV0FBVztBQUN6QixtQkFBSyxZQUFlLE9BQU8sT0FBTyxNQUE3QixtQkFBZ0MsU0FBUyxRQUFRO0FBQ3REO0FBQUEsY0FDQSxXQUFZLE9BQWUsT0FBTyxPQUFPLEVBQUUsUUFBUyxPQUFlLE9BQU8sRUFBRSxTQUFTLEdBQUcsR0FBRyxDQUFDLEdBQUc7QUFDL0YsbUNBQW1CLCtCQUErQixZQUFlO0FBQUEsa0JBQzdEO0FBQUEsZ0JBQ0osTUFGa0QsbUJBRS9DLE9BQU87QUFBQSxjQUNWLFdBQVksT0FBZSxPQUFPLE9BQU8sRUFBRSxRQUFTLE9BQWUsT0FBTyxFQUFFLFNBQVMsR0FBRyxHQUFHLENBQUMsR0FBRztBQUMvRixtQ0FBbUIsZ0NBQWdDLFlBQWU7QUFBQSxrQkFDOUQ7QUFBQSxnQkFDSixNQUZtRCxtQkFFaEQsT0FBTztBQUFBLGNBQ1YsT0FBTztBQUNQLG9DQUFvQixZQUFlLE9BQU8sT0FBTyxNQUE3QixtQkFBZ0MsT0FBTztBQUFBLGNBQzNEO0FBQ0EseUJBQVcsS0FBSztBQUFBLGdCQUNoQjtBQUFBLGdCQUNBO0FBQUEsZ0JBQ0E7QUFBQSxnQkFDQSxNQUFLLGtDQUFNLFNBQU4sbUJBQVksU0FBUSxrQ0FBTSxTQUFOLG1CQUFZO0FBQUEsY0FDckMsQ0FBQztBQUFBLFlBQ0w7QUFBQSxVQUNBO0FBQUEsUUFDSjtBQUFBLE1BQ0E7QUFBQSxJQUNKO0FBRUEsVUFBTSxhQUFhO0FBQUEsTUFBMkIsV0FDekMsS0FBSyxDQUFDLEdBQVEsTUFBWSxPQUFlLE9BQU8sRUFBRSxDQUFDLENBQUMsRUFBRSxRQUFRLElBQUssT0FBZSxPQUFPLEVBQUUsQ0FBQyxDQUFDLEVBQUUsUUFBUSxDQUFFLEVBQ3pHLElBQUksQ0FBQyxNQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsRUFBRSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUFBLElBQ3ZDO0FBRUEsVUFBTSxRQUFRLEdBQUcsY0FBZSxDQUFDLFlBQVksb0JBQW9CLE1BQU0sR0FBRyxVQUFXO0FBQ3JGLE9BQUcsR0FBRyxTQUFTLEtBQUs7QUFBQSxFQUN4QjtBQUFBOzs7QVZ2SUEsSUFBcUIscUJBQXJCLGNBQWdELHdCQUFPO0FBQUEsRUFTL0MsU0FBUztBQUFBO0FBQ2IsY0FBUSxJQUFJLDhCQUE4QjtBQUcxQyxZQUFNLEtBQUssYUFBYTtBQUd4QixXQUFLLGtCQUFrQixJQUFJLGdCQUFnQixLQUFLLEtBQUssS0FBSyxRQUFRO0FBQ2xFLFdBQUssZUFBZSxJQUFJLHFCQUFxQixLQUFLLEtBQUssS0FBSyxRQUFRO0FBQ3BFLFdBQUssc0JBQXNCLElBQUksb0JBQW9CLEtBQUssR0FBRztBQUMzRCxXQUFLLGlCQUFpQixJQUFJLGVBQWUsS0FBSyxHQUFHO0FBQ2pELFdBQUssd0JBQXdCLElBQUksc0JBQXNCLEtBQUssR0FBRztBQUMvRCxXQUFLLG9CQUFvQixFQUFFLHlCQUF5QixnQkFBZ0I7QUFHcEUsV0FBSyxjQUFjLElBQUksdUJBQXVCLEtBQUssS0FBSyxJQUFJLENBQUM7QUFHN0QsV0FBSyw2QkFBNkI7QUFHbEMsV0FBSyxXQUFXO0FBQUEsUUFDZCxJQUFJO0FBQUEsUUFDSixNQUFNO0FBQUEsUUFDTixVQUFVLE1BQU07QUFDZCxlQUFLLGdCQUFnQixpQkFBaUI7QUFBQSxRQUN4QztBQUFBLE1BQ0YsQ0FBQztBQUVELFdBQUssV0FBVztBQUFBLFFBQ2QsSUFBSTtBQUFBLFFBQ0osTUFBTTtBQUFBLFFBQ04sVUFBVSxNQUFNO0FBQ2QsZUFBSyxnQkFBZ0IsZ0JBQWdCO0FBQUEsUUFDdkM7QUFBQSxNQUNGLENBQUM7QUFJRCxXQUFLLFdBQVc7QUFBQSxRQUNkLElBQUk7QUFBQSxRQUNKLE1BQU07QUFBQSxRQUNOLFVBQVUsTUFBWTtBQUVwQixnQkFBTSxjQUFjLEtBQUssSUFBSSxVQUFVLGNBQWM7QUFDckQsY0FBSSxXQUFXO0FBQ2YsY0FBSSxhQUFhO0FBR2pCLGNBQUksYUFBYTtBQUNmLGtCQUFNLFFBQVEsS0FBSyxJQUFJLGNBQWMsYUFBYSxXQUFXO0FBQzdELGdCQUFJLFNBQVMsTUFBTSxhQUFhO0FBQzlCLHlCQUFXLE1BQU0sWUFBWSxhQUFhO0FBQzFDLDJCQUFhLE1BQU0sWUFBWSxlQUFlLE1BQU0sWUFBWSxTQUFTLFlBQVk7QUFBQSxZQUN2RjtBQUFBLFVBQ0Y7QUFHQSxjQUFJLENBQUMsVUFBVTtBQUNiLGtCQUFNLG1CQUFtQixNQUFNLEtBQUssa0JBQWtCLGlDQUFpQztBQUN2RixnQkFBSSxDQUFDO0FBQWtCO0FBQ3ZCLHVCQUFXO0FBQ1gseUJBQWE7QUFBQSxVQUNmO0FBR0EsY0FBSTtBQUFBLFlBQ0YsS0FBSztBQUFBLFlBQ0w7QUFBQSxZQUNBO0FBQUEsWUFDQSxDQUFPLGFBQWFDLGFBQVlDLGNBQWE7QUFFM0MseUJBQVcsY0FBYyxhQUFhO0FBQ3BDLG9CQUFJLFdBQVcsS0FBSyxLQUFLLE1BQU07QUFBSTtBQUduQyxzQkFBTSxvQkFBb0IsS0FBSztBQUFBLGtCQUM3QjtBQUFBLGtCQUNBRDtBQUFBLGtCQUNBQztBQUFBLGdCQUNGO0FBQ0Esc0JBQU0sV0FBVyxHQUFHQSxlQUFjLFdBQVcsS0FBSyxRQUFRLGlCQUFpQixHQUFHO0FBQzlFLHNCQUFNLFdBQVcsR0FBR0EsYUFBWTtBQUVoQyxvQkFBSTtBQUNGLHdCQUFNLEtBQUssSUFBSSxNQUFNLE9BQU8sVUFBVSxpQkFBaUI7QUFDdkQsMEJBQVEsSUFBSSw0QkFBNEIsVUFBVTtBQUFBLGdCQUNwRCxTQUFTLE9BQVA7QUFDQSwwQkFBUSxNQUFNLGtDQUFrQyxhQUFhLEtBQUs7QUFBQSxnQkFDcEU7QUFBQSxjQUNGO0FBQUEsWUFDRjtBQUFBLFVBQ0YsRUFBRSxLQUFLO0FBQUEsUUFDVDtBQUFBLE1BQ0YsQ0FBQztBQUVELFdBQUssV0FBVztBQUFBLFFBQ2QsSUFBSTtBQUFBLFFBQ0osTUFBTTtBQUFBLFFBQ04sVUFBVSxNQUFZO0FBQ3BCLGdCQUFNLFdBQVcsTUFBTSxLQUFLO0FBQUEsWUFDMUI7QUFBQSxVQUNGO0FBQ0EsY0FBSSxVQUFVO0FBQ1osa0JBQU0sS0FBSyxvQkFBb0IsMEJBQTBCLFFBQVE7QUFBQSxVQUNuRTtBQUFBLFFBQ0Y7QUFBQSxNQUNGLENBQUM7QUFFRCxXQUFLLFdBQVc7QUFBQSxRQUNkLElBQUk7QUFBQSxRQUNKLE1BQU07QUFBQSxRQUNOLFVBQVUsTUFBWTtBQUNwQixnQkFBTSxXQUFXLE1BQU0sS0FBSztBQUFBLFlBQzFCO0FBQUEsVUFDRjtBQUNBLGNBQUksVUFBVTtBQUNaLGtCQUFNLEtBQUssZUFBZSwwQkFBMEIsUUFBUTtBQUFBLFVBQzlEO0FBQUEsUUFDRjtBQUFBLE1BQ0YsQ0FBQztBQUVELFdBQUssV0FBVztBQUFBLFFBQ2QsSUFBSTtBQUFBLFFBQ0osTUFBTTtBQUFBLFFBQ04sVUFBVSxNQUFZO0FBQ3BCLGdCQUFNLE9BQU8sTUFBTSxLQUFLO0FBQUEsWUFDdEI7QUFBQSxVQUNGO0FBQ0EsZ0JBQU0sS0FBSyxzQkFBc0I7QUFBQSxZQUMvQixRQUFRO0FBQUEsVUFDVjtBQUFBLFFBQ0Y7QUFBQSxNQUNGLENBQUM7QUFHRCxXQUFLLGlCQUFpQixFQUFFLFFBQVEsZUFBZTtBQUFBLElBQ2pEO0FBQUE7QUFBQSxFQUVjLGtCQUFrQixTQUF5QztBQUFBO0FBQ3ZFLFlBQU0sV0FBVyxPQUFPLFVBQVUsc0JBQXNCO0FBQ3hELGFBQU8sV0FBVyxTQUFTLEtBQUssSUFBSTtBQUFBLElBQ3RDO0FBQUE7QUFBQSxFQUVjLGNBQWMsU0FBeUM7QUFBQTtBQUNuRSxZQUFNLE9BQU87QUFBQSxRQUNYLFVBQVU7QUFBQSxNQUNaO0FBQ0EsYUFBTyxPQUFPLEtBQUssS0FBSyxJQUFJO0FBQUEsSUFDOUI7QUFBQTtBQUFBLEVBRUEsOEJBQThCLFlBQWlCLFlBQW9CLFVBQTBCO0FBRTNGLFdBQU87QUFBQSxhQUNFO0FBQUEsbUJBQ00sV0FBVyxRQUFRO0FBQUEsWUFDMUIsV0FBVztBQUFBLFVBQ2IsV0FBVyxVQUFVO0FBQUE7QUFBQSxXQUVwQixJQUFJLEtBQUssRUFBRSxZQUFZO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFJNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUlGLFdBQVcsVUFBVTtBQUFBO0FBQUE7QUFBQSxFQUd2QixXQUFXO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU1HLElBQUksS0FBSyxFQUFFLFlBQVksRUFBRSxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsV0FDMUMsV0FBVztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQVlsQixXQUFXLGFBQWEsV0FBVztBQUFBO0FBQUEsRUFFckM7QUFBQSxFQUVBLFdBQVc7QUFDVCxZQUFRLElBQUksZ0NBQWdDO0FBQUEsRUFDOUM7QUFBQSxFQUVNLCtCQUErQjtBQUFBO0FBRW5DLFlBQU0sa0JBQW1CLEtBQUssSUFBWSxRQUFRLFVBQVUsb0JBQW9CO0FBQ2hGLFVBQUksQ0FBQyxpQkFBaUI7QUFDcEIsZ0JBQVEsSUFBSSxzRUFBc0U7QUFDbEY7QUFBQSxNQUNGO0FBR0EsVUFBSTtBQUVGLFlBQUksbUJBQW1CLGdCQUFnQixXQUFXO0FBRWhELGNBQUksQ0FBQyxnQkFBZ0IsVUFBVSxXQUFXO0FBQ3hDLDRCQUFnQixVQUFVLFlBQVksQ0FBQztBQUFBLFVBQ3pDO0FBR0EsMEJBQWdCLFVBQVUsVUFBVSxZQUFZLElBQUksQ0FBTyxLQUFVLElBQVMsU0FBYztBQUMxRixtQkFBTyxLQUFLLGtCQUFrQixLQUFLLElBQUksSUFBSTtBQUFBLFVBQzdDO0FBR0EsY0FBSSxDQUFDLGdCQUFnQixVQUFVLFVBQVUsTUFBTTtBQUM3Qyw0QkFBZ0IsVUFBVSxVQUFVLE9BQU8sQ0FBQztBQUFBLFVBQzlDO0FBQ0EsMEJBQWdCLFVBQVUsVUFBVSxLQUFLLFlBQVksSUFBSSxDQUFPLEtBQVUsSUFBUyxTQUFjO0FBQy9GLG1CQUFPLEtBQUssa0JBQWtCLEtBQUssSUFBSSxJQUFJO0FBQUEsVUFDN0M7QUFFQSwwQkFBZ0IsVUFBVSxVQUFVLGFBQWEsSUFBSSxDQUFPLE9BQVk7QUFDdEUsbUJBQU8sS0FBSyxtQkFBbUIsRUFBRTtBQUFBLFVBQ25DO0FBR0EsMEJBQWdCLFVBQVUsVUFBVSxLQUFLLGFBQWEsSUFBSSxDQUFPLE9BQVk7QUFDM0UsbUJBQU8sS0FBSyxtQkFBbUIsRUFBRTtBQUFBLFVBQ25DO0FBRUEsa0JBQVEsSUFBSSwyREFBMkQ7QUFBQSxRQUN6RSxPQUFPO0FBQ0wsa0JBQVEsTUFBTSxxRUFBcUU7QUFBQSxRQUNyRjtBQUFBLE1BQ0YsU0FBUyxHQUFQO0FBQ0EsZ0JBQVEsTUFBTSwwQ0FBMEMsQ0FBQztBQUFBLE1BQzNEO0FBQUEsSUFDRjtBQUFBO0FBQUEsRUFFTSxrQkFBa0IsS0FBVSxJQUFTLE1BQWM7QUFBQTtBQTdRM0Q7QUErUUksVUFBSSxlQUE4QjtBQUNsQyxVQUFJLGFBQTRCO0FBQ2hDLFVBQUksU0FBUztBQUNiLFVBQUksV0FBVztBQUNmLFVBQUksYUFBYTtBQUNqQixVQUFJLFlBQVk7QUFFaEIsVUFBSTtBQUVGLFlBQUksTUFBTSxHQUFHLFVBQVUsR0FBRyxPQUFPLFFBQVE7QUFDdkMsZ0JBQU0sbUJBQW1CLE1BQU0sR0FBRyxPQUFPLE9BQU8sNEJBQTRCLEVBQUU7QUFDOUUseUJBQWUsbUJBQW1CLG1CQUFtQjtBQUVyRCxnQkFBTSxpQkFBaUIsTUFBTSxHQUFHLE9BQU8sT0FBTywwQkFBMEIsRUFBRTtBQUMxRSx1QkFBYSxpQkFBaUIsaUJBQWlCO0FBRS9DLG1CQUFTLE1BQU0sR0FBRyxPQUFPO0FBQUEsWUFDdkIsTUFBTSxJQUFJLE1BQU0saUJBQWlCLEVBQUUsT0FBTyxDQUFDLE1BQVcsRUFBRSxLQUFLLFNBQVMsU0FBUyxDQUFDLEVBQUUsSUFBSSxDQUFDLE1BQVcsRUFBRSxRQUFRO0FBQUEsWUFDNUcsSUFBSSxNQUFNLGlCQUFpQixFQUFFLE9BQU8sQ0FBQyxNQUFXLEVBQUUsS0FBSyxTQUFTLFNBQVMsQ0FBQztBQUFBLFVBQzVFO0FBRUEsc0JBQVksTUFBTSxHQUFHLE9BQU87QUFBQSxZQUMxQixDQUFDLFVBQVUsV0FBVyxhQUFhLFlBQVksVUFBVSxZQUFZLFFBQVE7QUFBQSxZQUM3RSxDQUFDLFVBQVUsV0FBVyxhQUFhLFlBQVksVUFBVSxZQUFZLFFBQVE7QUFBQSxZQUM3RTtBQUFBLFVBQ0Y7QUFBQSxRQUNGLE9BQU87QUFFTCx5QkFBZTtBQUNmLHVCQUFhO0FBQ2IsbUJBQVM7QUFDVCxzQkFBWTtBQUFBLFFBQ2Q7QUFBQSxNQUNGLFNBQVMsR0FBUDtBQUNBLGdCQUFRLE1BQU0sZ0NBQWdDLENBQUM7QUFFL0MsdUJBQWU7QUFDZixxQkFBYTtBQUNiLGlCQUFTO0FBQ1Qsb0JBQVk7QUFBQSxNQUNkO0FBR0EsaUJBQVcsU0FBUyxPQUFPLE1BQU0sS0FBSyxFQUFFLENBQUMsS0FBSyxTQUFTO0FBQ3ZELG1CQUFhLFdBQVUsWUFBTyxNQUFNLEtBQUssRUFBRSxDQUFDLE1BQXJCLG1CQUF3QixVQUFVLEdBQUcsT0FBTSxRQUFTO0FBRTNFLGFBQU87QUFBQSxRQUNMLFFBQVE7QUFBQTtBQUFBLFFBQ1I7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVNLG1CQUFtQixJQUFTO0FBQUE7QUF4VXBDO0FBeVVJLFVBQUksZ0JBQWdCO0FBQ3BCLFVBQUksU0FBUztBQUNiLFVBQUksV0FBVztBQUNmLFVBQUksYUFBYTtBQUNqQixVQUFJLE9BQU87QUFFWCxVQUFJO0FBQ0YsWUFBSSxNQUFNLEdBQUcsVUFBVSxHQUFHLE9BQU8sUUFBUTtBQUN2QywyQkFBZ0IsTUFBTSxHQUFHLE9BQU8sT0FBTyxrQkFBa0IsRUFBRSxNQUFLO0FBQ2hFLG1CQUFTLE1BQU0sR0FBRyxPQUFPO0FBQUEsWUFDdkIsTUFBTSxHQUFHLElBQUksTUFBTSxpQkFBaUIsRUFBRSxPQUFPLENBQUMsTUFBVyxFQUFFLEtBQUssU0FBUyxTQUFTLENBQUMsRUFBRSxJQUFJLENBQUMsTUFBVyxFQUFFLFFBQVE7QUFBQSxZQUMvRyxHQUFHLElBQUksTUFBTSxpQkFBaUIsRUFBRSxPQUFPLENBQUMsTUFBVyxFQUFFLEtBQUssU0FBUyxTQUFTLENBQUM7QUFBQSxVQUMvRTtBQUNBLGdCQUFNLGNBQWMsR0FBRyxJQUFJLE1BQU0sU0FBUyxFQUFFLE9BQU8sQ0FBQyxNQUFXLEVBQUUsY0FBYyxLQUFLLEVBQUUsSUFBSSxDQUFDLE1BQVcsRUFBRSxRQUFRO0FBQ2hILGlCQUFPLE1BQU0sR0FBRyxPQUFPLFVBQVUsYUFBYSxhQUFhLFVBQVU7QUFBQSxRQUN2RSxPQUFPO0FBRUwsMEJBQWdCO0FBQ2hCLG1CQUFTO0FBQ1QsaUJBQU87QUFBQSxRQUNUO0FBQUEsTUFDRixTQUFTLEdBQVA7QUFDQSxnQkFBUSxNQUFNLGlDQUFpQyxDQUFDO0FBRWhELHdCQUFnQjtBQUNoQixpQkFBUztBQUNULGVBQU87QUFBQSxNQUNUO0FBR0EsaUJBQVcsU0FBUyxPQUFPLE1BQU0sS0FBSyxFQUFFLENBQUMsS0FBSyxTQUFTO0FBQ3ZELG1CQUFhLFdBQVUsWUFBTyxNQUFNLEtBQUssRUFBRSxDQUFDLE1BQXJCLG1CQUF3QixVQUFVLEdBQUcsT0FBTSxRQUFTO0FBRTNFLGFBQU87QUFBQSxRQUNMO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVNLGVBQWU7QUFBQTtBQUNuQixXQUFLLFdBQVcsT0FBTyxPQUFPLENBQUMsR0FBRyxrQkFBa0IsTUFBTSxLQUFLLFNBQVMsQ0FBQztBQUFBLElBQzNFO0FBQUE7QUFBQSxFQUVNLGVBQWU7QUFBQTtBQUNuQixZQUFNLEtBQUssU0FBUyxLQUFLLFFBQVE7QUFBQSxJQUNuQztBQUFBO0FBQ0Y7IiwKICAibmFtZXMiOiBbImltcG9ydF9vYnNpZGlhbiIsICJpbXBvcnRfb2JzaWRpYW4iLCAiaW1wb3J0X29ic2lkaWFuIiwgImltcG9ydF9vYnNpZGlhbiIsICJpbXBvcnRfb2JzaWRpYW4iLCAiaW1wb3J0X29ic2lkaWFuIiwgImltcG9ydF9vYnNpZGlhbiIsICJpbXBvcnRfb2JzaWRpYW4iLCAiX2EiLCAiY291cnNlTmFtZSIsICJjb3Vyc2VJZCJdCn0K
