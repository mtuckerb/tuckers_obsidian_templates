var __defProp = Object.defineProperty;
var __defProps = Object.defineProperties;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getOwnPropSymbols = Object.getOwnPropertySymbols;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __propIsEnum = Object.prototype.propertyIsEnumerable;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __spreadValues = (a, b) => {
  for (var prop in b || (b = {}))
    if (__hasOwnProp.call(b, prop))
      __defNormalProp(a, prop, b[prop]);
  if (__getOwnPropSymbols)
    for (var prop of __getOwnPropSymbols(b)) {
      if (__propIsEnum.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    }
  return a;
};
var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __async = (__this, __arguments, generator) => {
  return new Promise((resolve, reject) => {
    var fulfilled = (value) => {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    };
    var rejected = (value) => {
      try {
        step(generator.throw(value));
      } catch (e) {
        reject(e);
      }
    };
    var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
    step((generator = generator.apply(__this, __arguments)).next());
  });
};

// main.ts
var main_exports = {};
__export(main_exports, {
  default: () => TuckersToolsPlugin
});
module.exports = __toCommonJS(main_exports);
var import_obsidian9 = require("obsidian");

// settings.ts
var import_obsidian = require("obsidian");

// utils.ts
function slugify(text) {
  return text.toLowerCase().trim().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9\s-]/g, "").replace(/[\s-]+/g, "-").replace(/^-+|-+$/g, "");
}
function validateDate(dateString) {
  const regex = /^\d{4}-\d{2}-\d{2}$/;
  if (!dateString.match(regex))
    return false;
  const date = new Date(dateString);
  const timestamp = date.getTime();
  if (typeof timestamp !== "number" || isNaN(timestamp))
    return false;
  return dateString === date.toISOString().split("T")[0];
}

// settings.ts
var DEFAULT_SETTINGS = {
  baseDirectory: "/",
  semesterStartDate: new Date().toISOString().split("T")[0],
  semesterEndDate: new Date(new Date().setMonth(new Date().getMonth() + 4)).toISOString().split("T")[0],
  schoolName: "University",
  schoolAbbreviation: "U",
  templateFolder: "Tuckers Tools",
  useEnhancedMetadata: false,
  dataviewJsPath: "/Supporting/dataview-functions"
};
var TuckersToolsSettingTab = class extends import_obsidian.PluginSettingTab {
  constructor(app, plugin) {
    super(app, plugin);
    this.plugin = plugin;
  }
  display() {
    const { containerEl } = this;
    containerEl.empty();
    containerEl.createEl("h2", { text: "Tuckers Tools Settings" });
    new import_obsidian.Setting(containerEl).setName("Base Directory").setDesc("Root directory for course content organization").addText((text) => text.setPlaceholder("/").setValue(this.plugin.settings.baseDirectory).onChange((value) => __async(this, null, function* () {
      this.plugin.settings.baseDirectory = value;
      yield this.plugin.saveSettings();
    })));
    const startDateSetting = new import_obsidian.Setting(containerEl).setName("Semester Start Date").setDesc("Start date for the current semester").addText((text) => text.setPlaceholder("YYYY-MM-DD").setValue(this.plugin.settings.semesterStartDate).onChange((value) => __async(this, null, function* () {
      if (value && !validateDate(value)) {
        startDateSetting.setDesc("Start date for the current semester (Invalid date format)");
      } else {
        startDateSetting.setDesc("Start date for the current semester");
      }
      this.plugin.settings.semesterStartDate = value;
      yield this.plugin.saveSettings();
    })));
    const endDateSetting = new import_obsidian.Setting(containerEl).setName("Semester End Date").setDesc("End date for the current semester").addText((text) => text.setPlaceholder("YYYY-MM-DD").setValue(this.plugin.settings.semesterEndDate).onChange((value) => __async(this, null, function* () {
      if (value && !validateDate(value)) {
        endDateSetting.setDesc("End date for the current semester (Invalid date format)");
      } else {
        endDateSetting.setDesc("End date for the current semester");
      }
      this.plugin.settings.semesterEndDate = value;
      yield this.plugin.saveSettings();
    })));
    new import_obsidian.Setting(containerEl).setName("School Name").setDesc("Name of your institution").addText((text) => text.setPlaceholder("University").setValue(this.plugin.settings.schoolName).onChange((value) => __async(this, null, function* () {
      this.plugin.settings.schoolName = value;
      yield this.plugin.saveSettings();
    })));
    new import_obsidian.Setting(containerEl).setName("School Abbreviation").setDesc("Abbreviation for your institution").addText((text) => text.setPlaceholder("U").setValue(this.plugin.settings.schoolAbbreviation).onChange((value) => __async(this, null, function* () {
      this.plugin.settings.schoolAbbreviation = value;
      yield this.plugin.saveSettings();
    })));
    new import_obsidian.Setting(containerEl).setName("Template Folder").setDesc("Subfolder within your Templater template folder for Tuckers Tools templates").addText((text) => text.setPlaceholder("Tuckers Tools").setValue(this.plugin.settings.templateFolder).onChange((value) => __async(this, null, function* () {
      this.plugin.settings.templateFolder = value;
      yield this.plugin.saveSettings();
    })));
    new import_obsidian.Setting(containerEl).setName("Use Enhanced Metadata").setDesc("Enable enhanced metadata fields for new notes (existing notes remain unchanged)").addToggle((toggle) => toggle.setValue(this.plugin.settings.useEnhancedMetadata).onChange((value) => __async(this, null, function* () {
      this.plugin.settings.useEnhancedMetadata = value;
      yield this.plugin.saveSettings();
    })));
    new import_obsidian.Setting(containerEl).setName("Dataview Functions Path").setDesc("Path to the dataview functions file (without extension)").addText((text) => text.setPlaceholder("/Supporting/dataview-functions").setValue(this.plugin.settings.dataviewJsPath).onChange((value) => __async(this, null, function* () {
      this.plugin.settings.dataviewJsPath = value;
      yield this.plugin.saveSettings();
    })));
  }
};

// templateManager.ts
var import_obsidian2 = require("obsidian");
var TemplateManager = class {
  constructor(app, settings) {
    this.app = app;
    this.settings = settings;
    this.manifest = {
      version: "1.0.0",
      templates: {
        "Courses/Create Course Homepage.md": "1.0.0",
        "Courses/Course Index.md": "1.0.0",
        "Modules/Create Module.md": "1.0.0",
        "Chapters/Create Chapter.md": "1.0.0",
        "Assignments/Create Assignment.md": "1.0.0",
        "Daily/Daily Note.md": "1.0.0",
        "Utilities/Vocabulary Entry.md": "1.0.0",
        "Utilities/Due Date Entry.md": "1.0.0"
      },
      plugin_version: "1.0.0",
      release_notes: "Initial release of Tuckers Tools templates"
    };
  }
  installTemplates() {
    return __async(this, null, function* () {
      try {
        const templaterPlugin = this.getTemplaterPlugin();
        if (!templaterPlugin) {
          new import_obsidian2.Notice(
            "Templater plugin not found. Please install and enable the Templater plugin first."
          );
          console.error(
            "Templater plugin not found. Please install and enable the Templater plugin first."
          );
          return;
        }
        const templateFolderPath = this.getTemplateFolderPath(templaterPlugin);
        if (!templateFolderPath) {
          new import_obsidian2.Notice(
            "Template folder not configured in Templater settings. Please configure it in Templater settings first."
          );
          console.error(
            "Template folder not configured in Templater settings. Please configure it in Templater settings first."
          );
          return;
        }
        const fullTemplatePath = `${templateFolderPath}/${this.settings.templateFolder}`;
        try {
          yield this.app.vault.createFolder(fullTemplatePath);
          console.log(`Created template folder: ${fullTemplatePath}`);
        } catch (e) {
          console.log(
            `Template folder already exists or created: ${fullTemplatePath}`
          );
        }
        const subdirs = [
          "Courses",
          "Modules",
          "Chapters",
          "Assignments",
          "Daily",
          "Utilities"
        ];
        for (const subdir of subdirs) {
          try {
            const subPath = `${fullTemplatePath}/${subdir}`;
            yield this.app.vault.createFolder(subPath);
            console.log(`Created subdirectory: ${subPath}`);
          } catch (e) {
            console.log(
              `Subdirectory already exists: ${fullTemplatePath}/${subdir}`
            );
          }
        }
        yield this.installCourseTemplates(fullTemplatePath);
        yield this.installModuleTemplates(fullTemplatePath);
        yield this.installChapterTemplates(fullTemplatePath);
        yield this.installAssignmentTemplates(fullTemplatePath);
        yield this.installDailyTemplates(fullTemplatePath);
        yield this.installUtilityTemplates(fullTemplatePath);
        yield this.createREADME(fullTemplatePath);
        yield this.createTemplateManifest(fullTemplatePath);
        new import_obsidian2.Notice("Tuckers Tools templates installed successfully!");
        console.log("Tuckers Tools templates installed successfully");
      } catch (error) {
        console.error("Error installing templates:", error);
        new import_obsidian2.Notice("Error installing templates. Check console for details.");
      }
    });
  }
  getTemplaterPlugin() {
    const possiblePaths = [
      this.app.plugins.plugins["templater-obsidian"],
      this.app.plugins.plugins["templater"],
      this.app.plugins.getPlugin("templater-obsidian"),
      this.app.plugins.getPlugin("templater")
    ];
    for (const path of possiblePaths) {
      if (path) {
        return path;
      }
    }
    return null;
  }
  getTemplateFolderPath(templaterPlugin) {
    const settings = templaterPlugin.settings;
    if (!settings) {
      console.error("Templater plugin has no settings");
      return null;
    }
    const possiblePaths = [
      settings.templates_folder,
      // Changed from template_folder to match actual setting
      settings.template_folder,
      settings.templateFolder,
      settings.templateFolderPath,
      settings.folder
    ];
    for (const path of possiblePaths) {
      if (path && typeof path === "string") {
        return path;
      }
    }
    console.error(
      "Template folder not found in Templater settings. Available settings:",
      Object.keys(settings)
    );
    return null;
  }
  createTemplateManifest(basePath) {
    return __async(this, null, function* () {
      const manifestPath = `${basePath}/template-manifest.json`;
      const manifestContent = JSON.stringify(this.manifest, null, 2);
      try {
        const existingManifest = this.app.vault.getAbstractFileByPath(manifestPath);
        if (existingManifest) {
          const file = existingManifest;
          yield this.app.vault.modify(file, manifestContent);
          console.log(`Updated template manifest: ${manifestPath}`);
          return;
        }
        yield this.app.vault.create(manifestPath, manifestContent);
        console.log(`Created template manifest: ${manifestPath}`);
      } catch (e) {
        new import_obsidian2.Notice(`Error creating template manifest ${manifestPath}`);
        console.error(`Error creating template manifest ${manifestPath}:`, e);
      }
    });
  }
  checkForTemplateUpdates() {
    return __async(this, null, function* () {
      console.log("Checking for template updates");
      return false;
    });
  }
  updateTemplates() {
    return __async(this, null, function* () {
      try {
        console.log("Updating templates");
        const templaterPlugin = this.getTemplaterPlugin();
        if (!templaterPlugin) {
          new import_obsidian2.Notice(
            "Templater plugin not found. Please install and enable the Templater plugin first."
          );
          console.error(
            "Templater plugin not found. Please install and enable the Templater plugin first."
          );
          return;
        }
        const templateFolderPath = this.getTemplateFolderPath(templaterPlugin);
        if (!templateFolderPath) {
          new import_obsidian2.Notice(
            "Template folder not configured in Templater settings. Please configure it in Templater settings first."
          );
          console.error(
            "Template folder not configured in Templater settings. Please configure it in Templater settings first."
          );
          return;
        }
        const fullTemplatePath = `${templateFolderPath}/${this.settings.templateFolder}`;
        yield this.installCourseTemplates(fullTemplatePath);
        yield this.installModuleTemplates(fullTemplatePath);
        yield this.installChapterTemplates(fullTemplatePath);
        yield this.installAssignmentTemplates(fullTemplatePath);
        yield this.installDailyTemplates(fullTemplatePath);
        yield this.installUtilityTemplates(fullTemplatePath);
        yield this.createREADME(fullTemplatePath);
        yield this.createTemplateManifest(fullTemplatePath);
        new import_obsidian2.Notice("Tuckers Tools templates updated successfully!");
        console.log("Tuckers Tools templates updated successfully");
      } catch (error) {
        console.error("Error updating templates:", error);
        new import_obsidian2.Notice("Error updating templates. Check console for details.");
      }
    });
  }
  installCourseTemplates(basePath) {
    return __async(this, null, function* () {
      const coursePath = `${basePath}/Courses`;
      const courseHomepageTemplate = this.generateCourseHomepageTemplate();
      yield this.writeTemplateFile(
        `${coursePath}/Create Course Homepage.md`,
        courseHomepageTemplate
      );
      const courseIndexTemplate = this.generateCourseIndexTemplate();
      yield this.writeTemplateFile(
        `${coursePath}/Course Index.md`,
        courseIndexTemplate
      );
    });
  }
  installModuleTemplates(basePath) {
    return __async(this, null, function* () {
      const modulePath = `${basePath}/Modules`;
      const moduleTemplate = this.generateModuleTemplate();
      yield this.writeTemplateFile(
        `${modulePath}/Create Module.md`,
        moduleTemplate
      );
    });
  }
  installChapterTemplates(basePath) {
    return __async(this, null, function* () {
      const chapterPath = `${basePath}/Chapters`;
      const chapterTemplate = this.generateChapterTemplate();
      yield this.writeTemplateFile(
        `${chapterPath}/Create Chapter.md`,
        chapterTemplate
      );
    });
  }
  installAssignmentTemplates(basePath) {
    return __async(this, null, function* () {
      const assignmentPath = `${basePath}/Assignments`;
      const assignmentTemplate = this.generateAssignmentTemplate();
      yield this.writeTemplateFile(
        `${assignmentPath}/Create Assignment.md`,
        assignmentTemplate
      );
    });
  }
  installDailyTemplates(basePath) {
    return __async(this, null, function* () {
      const dailyPath = `${basePath}/Daily`;
      const dailyNoteTemplate = this.generateDailyNoteTemplate();
      yield this.writeTemplateFile(
        `${dailyPath}/Daily Note.md`,
        dailyNoteTemplate
      );
    });
  }
  installUtilityTemplates(basePath) {
    return __async(this, null, function* () {
      const utilityPath = `${basePath}/Utilities`;
      const vocabTemplate = this.generateVocabularyTemplate();
      yield this.writeTemplateFile(
        `${utilityPath}/Vocabulary Entry.md`,
        vocabTemplate
      );
      const dueDateTemplate = this.generateDueDateTemplate();
      yield this.writeTemplateFile(
        `${utilityPath}/Due Date Entry.md`,
        dueDateTemplate
      );
    });
  }
  writeTemplateFile(path, content) {
    return __async(this, null, function* () {
      try {
        const existingFile = this.app.vault.getAbstractFileByPath(path);
        if (existingFile) {
          console.log(`Updating existing template file: ${path}`);
          const file = existingFile;
          yield this.app.vault.modify(file, content);
          return;
        }
        yield this.app.vault.create(path, content);
        console.log(`Created template file: ${path}`);
      } catch (e) {
        new import_obsidian2.Notice(`Error creating template file ${path}`);
        console.error(`Error creating template file ${path}:`, e);
      }
    });
  }
  generateCourseHomepageTemplate() {
    const enhancedMetadata = this.settings.useEnhancedMetadata;
    if (enhancedMetadata) {
      let template = `<%*
// Tuckers Tools Course Creation
// For best experience, use the plugin command: Command Palette \u2192 'Create New Course'

let courseName = "New Course";
let courseSeason = "Fall"; 
let courseYear = new Date().getFullYear().toString();
let courseId = "COURSE_ID";

// Try to use system prompts, with graceful fallback
try {
  if (tp && tp.system && tp.system.prompt) {
    courseName = await tp.system.prompt("Course Name (e.g. SWO-250 - Course Title)") || courseName;
    courseId = courseName.split(' - ')[0] || courseName.replace(/[^a-zA-Z0-9]/g, "_");
    courseSeason = await tp.system.suggester(["Fall","Winter","Spring","Summer"],["Fall","Winter","Spring","Summer"], "Season") || courseSeason;
    courseYear = await tp.system.prompt("Year") || courseYear;
  } else {
    console.log("System prompts not available, use the plugin command instead");
  }
} catch (e) {
  console.error("Error with system prompts:", e.message);
  console.log("Use the plugin command: Command Palette \u2192 'Create New Course'");
}

// Move file to appropriate location
await tp.file.move(\`/\${courseYear}/\${courseSeason}/\${courseName}/\${courseName}\`);

// Create attachments folder
try {
  await app.vault.createFolder(\`/\${courseYear}/\${courseSeason}/\${courseName}/Attachments\`);
} catch (e) {
  // Folder might already exist
}
%>---
course_id: <% courseId %>
course_season: <% courseSeason %>
course_year: <% courseYear %>
created: <% tp.date.now("YYYY-MM-DD[T]HH:mm:ssZ") %>
contentType: Course
tags: 
  - <% courseId %>
  - ${this.settings.schoolAbbreviation}/<% courseYear %>/<% courseSeason %>/<% courseId %>/
  - course_home
  - education
  - ${this.settings.schoolName.replace(/\s+/g, "_")}
banner:
cssclasses:
  - whiteboard-course
---


# <% courseName %>

## Course Information
**Course**: <% courseName %>
**Course ID**: <% courseId %>
**Term**: <% courseSeason %> <% courseYear %>
**School**: ${this.settings.schoolName}

## Instructor
**Name**: \`INPUT[text:instructor_name]\`
**Email**: \`INPUT[text:instructor_email]\`
**Office Hours**: \`INPUT[text:instructor_office_hours]\`
**Office Location**: \`INPUT[text:instructor_office_location]\`

## Course Description
\`INPUT[textArea:course_description]\`

## Learning Objectives
\`INPUT[textArea:learning_objectives]\`

## Required Texts
\`\`\`meta-bind-js-view
{texts} as texts
---
const availableTexts = app.vault.getFiles().filter(file => file.extension == 'pdf').map(f => f?.name)
const escapeRegex = /[,\`'()]/g;
options = availableTexts.map(t => \`option([[\${t.replace(escapeRegex,"$1")}]], \${t.replace(escapeRegex,"$1")})\` )
const str = \`\\\`INPUT[inlineListSuggester(\${options.join(", ")}):texts]\\\`\`
return engine.markdown.create(str)
\`\`\`

## Course Schedule
\`INPUT[textArea:course_schedule]\`

## Resources
\`INPUT[textArea:resources]\`

## Vocabulary
\`\`\`dataviewjs
const {processCourseVocabulary} = app.plugins.getPlugin("tuckers-tools")?.dataviewFunctions || require("${this.settings.dataviewJsPath || "/Supporting/dataview-functions"}");
processCourseVocabulary(dv, '<% courseId %>');
\`\`\`

## Due Dates
\`\`\`dataviewjs
const {processDueDates} = app.plugins.getPlugin("tuckers-tools")?.dataviewFunctions || require("${this.settings.dataviewJsPath || "/Supporting/dataview-functions"}");
processDueDates(dv,'#<% courseId %>');
\`\`\`

## Class Materials
\`INPUT[textArea:class_materials]\`

## Classmates
\`INPUT[textArea:classmates]\``;
      return template;
    } else {
      let template = `<%*
// Tuckers Tools Course Creation
// For best experience, use the plugin command: Command Palette \u2192 'Create New Course'

let courseName = "New Course";
let courseSeason = "Fall"; 
let courseYear = new Date().getFullYear().toString();
let courseId = "COURSE_ID";

// Try to use system prompts, with graceful fallback
try {
  if (tp && tp.system && tp.system.prompt) {
    courseName = await tp.system.prompt("Course Name (e.g. SWO-250 - Course Title)") || courseName;
    courseId = courseName.split(' - ')[0] || courseName.replace(/[^a-zA-Z0-9]/g, "_");
    courseSeason = await tp.system.suggester(["Fall","Winter","Spring","Summer"],["Fall","Winter","Spring","Summer"], "Season") || courseSeason;
    courseYear = await tp.system.prompt("Year") || courseYear;
  } else {
    console.log("System prompts not available, use the plugin command instead");
  }
} catch (e) {
  console.error("Error with system prompts:", e.message);
  console.log("Use the plugin command: Command Palette \u2192 'Create New Course'");
}

// Move file to appropriate location
await tp.file.move(\`/\${courseYear}/\${courseSeason}/\${courseName}/\${courseName}\`);

// Create attachments folder
try {
  await app.vault.createFolder(\`/\${courseYear}/\${courseSeason}/\${courseName}/Attachments\`);
} catch (e) {
  // Folder might already exist
}
%>---
course_id: <% courseId %>
course_name: <% courseName %>
course_season: <% courseSeason %>
course_year: <% courseYear %>
created: <% tp.date.now("YYYY-MM-DD[T]HH:mm:ssZ") %>
tags:
  - <% courseId %>
  - course_home
  - education
---

# <% courseName %>

## Course Information
**Course ID**: <% courseId %>
**Term**: <% courseSeason %> <% courseYear %>
**School**: ${this.settings.schoolName}

## Instructor
**Name**: \`INPUT[text:instructor_name]\`
**Email**: \`INPUT[text:instructor_email]\`
**Office Hours**: \`INPUT[text:instructor_office_hours]\`
**Office Location**: \`INPUT[text:instructor_office_location]\`

## Course Description
\`INPUT[textArea:course_description]\`

## Learning Objectives
\`INPUT[textArea:learning_objectives]\`

## Required Texts
\`\`\`meta-bind-js-view
{texts} as texts
---
const availableTexts = app.vault.getFiles().filter(file => file.extension == 'pdf').map(f => f?.name)
const escapeRegex = /[,\`'()]/g;
options = availableTexts.map(t => \`option([[\${t.replace(escapeRegex,"$1")}]], \${t.replace(escapeRegex,"$1")})\` )
const str = '\\\`INPUT[inlineListSuggester(\${options.join(", ")}):texts]\\\`\\'
return engine.markdown.create(str)
\`\`\`

## Schedule
\`INPUT[textArea:course_schedule]\`

## Assignments
\`INPUT[textArea:assignments]\`

## Resources
\`INPUT[textArea:resources]\`

## Vocabulary
\`\`\`dataviewjs
const {processCourseVocabulary} = app.plugins.getPlugin("tuckers-tools")?.dataviewFunctions || require("${this.settings.dataviewJsPath || "/Supporting/dataview-functions"}");
processCourseVocabulary(dv, '<% courseId %>');
\`\`\`

## Due Dates
\`\`\`dataviewjs
const {processDueDates} = app.plugins.getPlugin("tuckers-tools")?.dataviewFunctions || require("${this.settings.dataviewJsPath || "/Supporting/dataview-functions"}");
processDueDates(dv,'#<% courseId %>');
\`\`\``;
      return template;
    }
  }
  generateCourseIndexTemplate() {
    return `---
content_type: course_index
tags:
  - index
---

# Course Index

## Modules

## Chapters

## Assignments

## Resources

## Vocabulary

## Due Dates`;
  }
  generateModuleTemplate() {
    return `<%*
const { season, moduleNumber, weekNumber, course, courseId, discipline, dayOfWeek } = await tp.user.new_module(app, tp, "2025");
let title = courseId
if (moduleNumber && weekNumber) { title = \`M\${moduleNumber}/W\${weekNumber}\`}
else if (moduleNumber) { title = \`M\${moduleNumber}\` } 
else if (weekNumber) { title = \`W\${weekNumber}\`}
%>---
${this.settings.useEnhancedMetadata ? `course_id: <% courseId %>
module_number: <% moduleNumber %>
week_number: <% weekNumber %>
class_day: <% dayOfWeek %>
content_type: module
parent_course: "[[<% course %>]]"` : `course_id: <% courseId %>
module_number: <% moduleNumber %>
week_number: <% weekNumber %>
class_day: <% dayOfWeek %>`}
created: <% tp.date.now("YYYY-MM-DD[T]HH:mm:ssZ") %>
tags:
  - education
  - <% courseId %>
  - module
---


# [[<% course %>]] - <% title %> - <% dayOfWeek %>

## Due Dates
| Date | Assignment |
| ---- | ---------- |
|      |            |
|      |            |
|      |            |

\`\`\`dataviewjs
const {processDueDates} = require("${this.settings.dataviewJsPath || "/Supporting/dataview-functions"}");
processDueDates(dv,'#<% courseId %>');
\`\`\`

## Learning Objectives

## Reading Assignment

## Lecture Notes

## Discussion Questions

## Vocabulary

\`\`\`dataviewjs
const {processCourseVocabulary} = require("${this.settings.dataviewJsPath || "/Supporting/dataview-functions"}");
processCourseVocabulary(dv, '<% courseId %>');
\`\`\`

## Additional Resources`;
  }
  generateChapterTemplate() {
    return `<%*
const { chapterNumber, course, courseId, discipline, text} = await tp.user.new_chapter(tp);
%>---
${this.settings.useEnhancedMetadata ? `course_id: <% courseId %>
chapter_number: <% chapterNumber %>
content_type: chapter
parent_course: "[[<% course %>]]"
text_reference: "[[<% text %>]]"` : `course_id: <% courseId %>
chapter_number: <% chapterNumber %>`}
created: <% tp.date.now("YYYY-MM-DD[T]HH:mm:ssZ") %>
tags:
  - education
  - <% courseId %>
  - chapter
---


# [[<% text %>]] - Chapter <% chapterNumber %>

## Reading Assignment
- **Textbook**: [[<% text %>]]
- **Chapter**: <% chapterNumber %>
- **Pages**: 

## Summary

## Key Concepts

## Vocabulary
- 

## Notes

## Discussion Questions

## Further Reading`;
  }
  generateAssignmentTemplate() {
    return `---
${this.settings.useEnhancedMetadata ? `course_id: <% courseId %>
assignment_type: <% assignmentType %>
due_date: <% dueDate %>
points: <% points %>
content_type: assignment
parent_course: "[[<% course %>]]"` : `course_id: <% courseId %>
assignment_type: <% assignmentType %>
due_date: <% dueDate %>`}
created: <% tp.date.now("YYYY-MM-DD[T]HH:mm:ssZ") %>
status: pending
tags:
  - education
  - <% courseId %>
  - assignment
---

# <% assignmentName %> - <% courseId %>

## Description

## Instructions

## Due Date
**Assigned**: <% tp.date.now("YYYY-MM-DD") %>
**Due**: <% dueDate %>

## Submission

## Grading Criteria

## Resources

# Due Dates
| <% dueDate %> | <% assignmentName %> | pending |
`;
  }
  generateDailyNoteTemplate() {
    return `---
content_type: daily_note
date: <% tp.date.now("YYYY-MM-DD") %>
tags:
  - daily
  - <% tp.date.now("YYYY") %>
  - <% tp.date.now("MM") %>
  - <% tp.date.now("DD") %>
---

# <% tp.date.now("YYYY-MM-DD - dddd") %>

<< [[<% tp.date.yesterday("YYYY-MM-DD") %>]] | [[<% tp.date.tomorrow("YYYY-MM-DD") %>]] >>

## Today's Focus

## Courses Worked On
- 

## Tasks Completed
- [ ] 

## Vocabulary Reviewed
- 

## Assignments Due
- 

## Learning Achievements

## Challenges

## Tomorrow's Plan

## Reflection`;
  }
  generateVocabularyTemplate() {
    return `## <% term %>
**Term**: <% term %>
**Part of Speech**: 
**Definition**: 
**Context**: 
**Examples**: 
**Related Terms**: 
**See Also**:`;
  }
  generateDueDateTemplate() {
    return `| <% dueDate %> | <% assignment %> | <% status %> |`;
  }
  createREADME(basePath) {
    return __async(this, null, function* () {
      const readmeContent = `# Tuckers Tools Templates

This directory contains templates for the Tuckers Tools Obsidian plugin.

## Template Categories

- **Courses**: Templates for creating and organizing courses
- **Modules**: Templates for course modules
- **Chapters**: Templates for chapter notes
- **Assignments**: Templates for assignments
- **Daily**: Templates for daily notes
- **Utilities**: Helper templates

## Usage

These templates are designed to work with the Tuckers Tools plugin. To use them:

1. Install the Tuckers Tools plugin
2. Configure your settings in the plugin settings tab
3. Use the "Insert Template" command to apply these templates to new notes

## Customization

Feel free to customize these templates to suit your needs. The plugin will not overwrite your changes when updating templates.`;
      yield this.writeTemplateFile(`${basePath}/README.md`, readmeContent);
    });
  }
};

// courseWizard.ts
var import_obsidian4 = require("obsidian");

// inputModal.ts
var import_obsidian3 = require("obsidian");
var InputModal = class extends import_obsidian3.Modal {
  constructor(app, onSubmit) {
    super(app);
    this.onSubmit = onSubmit;
  }
  onOpen() {
    const { contentEl } = this;
    contentEl.createEl("h2", { text: "Enter Value" });
    new import_obsidian3.Setting(contentEl).setName("Value").addText(
      (text) => text.onChange((value) => {
        this.result = value;
      }).inputEl.focus()
    );
    new import_obsidian3.Setting(contentEl).addButton(
      (btn) => btn.setButtonText("Submit").setCta().onClick(() => {
        this.close();
        this.onSubmit(this.result || "");
      })
    ).addButton(
      (btn) => btn.setButtonText("Cancel").onClick(() => {
        this.close();
        this.onSubmit(null);
      })
    );
  }
  onClose() {
    const { contentEl } = this;
    contentEl.empty();
  }
};
var SuggesterModal = class extends import_obsidian3.Modal {
  constructor(app, options, onSubmit) {
    super(app);
    this.onSubmit = onSubmit;
    const dropdownOptions = {};
    options.forEach((option) => {
      dropdownOptions[option] = option;
    });
    this.createDropdown(dropdownOptions);
  }
  createDropdown(options) {
    const { contentEl } = this;
    contentEl.createEl("h2", { text: "Select Option" });
    let selectedValue = Object.keys(options)[0] || null;
    const dropdown = contentEl.createEl("select");
    Object.entries(options).forEach(([key, value]) => {
      const option = dropdown.createEl("option", {
        value: key,
        text: value
      });
      if (key === selectedValue) {
        option.selected = true;
      }
    });
    dropdown.addEventListener("change", (event) => {
      selectedValue = event.target.value;
      this.result = selectedValue;
    });
    new import_obsidian3.Setting(contentEl).addButton(
      (btn) => btn.setButtonText("Submit").setCta().onClick(() => {
        this.close();
        this.onSubmit(selectedValue);
      })
    ).addButton(
      (btn) => btn.setButtonText("Cancel").onClick(() => {
        this.close();
        this.onSubmit(null);
      })
    );
  }
  onOpen() {
  }
  onClose() {
    const { contentEl } = this;
    contentEl.empty();
  }
};

// courseWizard.ts
var CourseCreationWizard = class {
  constructor(app, settings) {
    this.app = app;
    this.settings = settings;
  }
  createCourseHomepage() {
    return __async(this, null, function* () {
      try {
        const courseDetails = yield this.promptCourseDetails();
        if (!courseDetails) {
          return false;
        }
        const folderPath = yield this.createCourseFolderStructure(courseDetails);
        yield this.createCourseHomepageNote(courseDetails, folderPath);
        yield this.createAttachmentsFolder(folderPath);
        new import_obsidian4.Notice(`Course "${courseDetails.courseName}" created successfully!`);
        console.log(
          `Course created: ${courseDetails.courseName} at ${folderPath}`
        );
        return true;
      } catch (error) {
        console.error("Error creating course:", error);
        new import_obsidian4.Notice(`Error creating course: ${error.message}`);
        return false;
      }
    });
  }
  promptCourseDetails() {
    return __async(this, null, function* () {
      var _a;
      try {
        const courseName = yield this.promptWithValidation(
          "Course Name",
          "Enter course name (e.g., PSI-101 - Intro to Psychology)",
          (value) => value.trim().length > 0,
          "Course name is required"
        );
        if (!courseName)
          return null;
        const courseSeason = yield this.promptWithOptions(
          "Season",
          "Select semester/season",
          ["Fall", "Winter", "Spring", "Summer"]
        );
        if (!courseSeason)
          return null;
        const courseYear = yield this.promptWithValidation(
          "Year",
          "Enter academic year (e.g., 2025)",
          (value) => /^\d{4}$/.test(value.trim()),
          "Please enter a valid 4-digit year"
        );
        if (!courseYear)
          return null;
        const courseId = ((_a = courseName.split(" - ")[0]) == null ? void 0 : _a.trim()) || slugify(courseName);
        return {
          courseName,
          courseSeason,
          courseYear,
          courseId
        };
      } catch (error) {
        console.error("Error prompting for course details:", error);
        return null;
      }
    });
  }
  promptWithValidation(title, message, validator, errorMessage) {
    return __async(this, null, function* () {
      return new Promise((resolve) => {
        const modal = new InputModal(this.app, (result) => {
          if (result === null) {
            resolve(null);
            return;
          }
          if (!validator(result)) {
            new import_obsidian4.Notice(errorMessage);
            this.promptWithValidation(title, message, validator, errorMessage).then(resolve);
            return;
          }
          resolve(result.trim());
        });
        modal.titleEl.setText(title);
        const messageEl = modal.contentEl.createDiv();
        messageEl.setText(message);
        modal.open();
      });
    });
  }
  promptWithOptions(title, message, options) {
    return __async(this, null, function* () {
      return new Promise((resolve) => {
        const modal = new SuggesterModal(this.app, options, (result) => {
          if (result === null) {
            resolve(null);
            return;
          }
          if (options.includes(result)) {
            resolve(result);
          } else {
            new import_obsidian4.Notice(`Please select one of: ${options.join(", ")}`);
            this.promptWithOptions(title, message, options).then(resolve);
          }
        });
        modal.titleEl.setText(title);
        const messageEl = modal.contentEl.createDiv();
        messageEl.setText(message);
        modal.open();
      });
    });
  }
  createCourseFolderStructure(courseDetails) {
    return __async(this, null, function* () {
      const folderPath = `${courseDetails.courseYear}/${courseDetails.courseSeason}/${courseDetails.courseName}`;
      try {
        yield this.app.vault.createFolder(folderPath);
        console.log(`Created course folder: ${folderPath}`);
        return folderPath;
      } catch (error) {
        console.log(`Course folder already exists or created: ${folderPath}`);
        return folderPath;
      }
    });
  }
  createCourseHomepageNote(courseDetails, folderPath) {
    return __async(this, null, function* () {
      const notePath = `${folderPath}/${courseDetails.courseName}.md`;
      const content = this.generateCourseHomepageContent(courseDetails);
      try {
        yield this.app.vault.create(notePath, content);
        console.log(`Created course homepage: ${notePath}`);
      } catch (error) {
        console.error(`Error creating course homepage: ${error}`);
        throw error;
      }
    });
  }
  createAttachmentsFolder(folderPath) {
    return __async(this, null, function* () {
      const attachmentsPath = `${folderPath}/Attachments`;
      try {
        yield this.app.vault.createFolder(attachmentsPath);
        console.log(`Created attachments folder: ${attachmentsPath}`);
      } catch (error) {
        console.log(`Attachments folder already exists: ${attachmentsPath}`);
      }
    });
  }
  generateCourseHomepageContent(courseDetails) {
    const templateManager = new TemplateManager(this.app, this.settings);
    const templateContent = templateManager.generateCourseHomepageTemplate();
    return templateContent.replace(/<% courseName %>/g, courseDetails.courseName).replace(/<% courseSeason %>/g, courseDetails.courseSeason).replace(/<% courseYear %>/g, courseDetails.courseYear).replace(/<% courseId %>/g, courseDetails.courseId).replace(/<% tp\.date\.now\("YYYY-MM-DD\[T\]HH:mm:ssZ"\) %>/g, new Date().toISOString()).replace(/<% tp\.date\.now\("YYYY-MM-DD\[T\]hh:mm:SSSSZZ"\) %>/g, new Date().toISOString());
  }
};

// vocabulary.ts
var import_obsidian5 = require("obsidian");
var VocabularyExtractor = class {
  constructor(app) {
    this.app = app;
  }
  extractVocabularyFromNote(content) {
    const vocabRegex = /^#+ Vocabulary.*\n((?:.*?\n)*?)(?=^\s*#\s|$)/m;
    const vocabMatches = content == null ? void 0 : content.match(vocabRegex);
    if (vocabMatches) {
      const vocabData = vocabMatches[1].trim();
      const cleanedVocab = vocabData.replace(/\[\[.*?\]\]/g, "").replace(/^\s*-\s*/gm, "").split("\n").map((term) => term.trim()).filter((term) => term.length > 0);
      return cleanedVocab;
    }
    return [];
  }
  extractVocabularyFromCourse(courseId) {
    return __async(this, null, function* () {
      console.log(`Extracting vocabulary for course: ${courseId}`);
      try {
        const courseNotes = yield this.findCourseNotes(courseId);
        if (courseNotes.length === 0) {
          console.log(`No notes found for course: ${courseId}`);
          return {};
        }
        const vocabularyData = {};
        for (const note of courseNotes) {
          try {
            const content = yield this.app.vault.read(note);
            const vocabulary = this.extractVocabularyFromNote(content);
            if (vocabulary.length > 0) {
              vocabularyData[note.basename] = vocabulary;
            }
          } catch (error) {
            console.error(`Error reading note ${note.path}:`, error);
          }
        }
        console.log(
          `Extracted vocabulary from ${Object.keys(vocabularyData).length} notes for course: ${courseId}`
        );
        return vocabularyData;
      } catch (error) {
        console.error(
          `Error extracting vocabulary for course ${courseId}:`,
          error
        );
        return {};
      }
    });
  }
  findCourseNotes(courseId) {
    return __async(this, null, function* () {
      const notes = [];
      const files = this.app.vault.getMarkdownFiles();
      for (const file of files) {
        if (file.path.includes(courseId) || (yield this.noteBelongsToCourse(file, courseId))) {
          notes.push(file);
        }
      }
      return notes;
    });
  }
  noteBelongsToCourse(file, courseId) {
    return __async(this, null, function* () {
      try {
        const content = yield this.app.vault.read(file);
        const frontmatterMatch = content.match(/^---\n([\s\S]*?)\n---/);
        if (frontmatterMatch) {
          const frontmatter = frontmatterMatch[1];
          return frontmatter.includes(`course_id: ${courseId}`) || frontmatter.includes(`course_id:${courseId}`);
        }
        return false;
      } catch (error) {
        console.error(
          `Error checking if note ${file.path} belongs to course ${courseId}:`,
          error
        );
        return false;
      }
    });
  }
  generateVocabularyIndex(courseId, vocabularyData) {
    return __async(this, null, function* () {
      const allTerms = [];
      const termSources = {};
      for (const [noteName, terms] of Object.entries(vocabularyData)) {
        for (const term of terms) {
          if (!allTerms.includes(term)) {
            allTerms.push(term);
            termSources[term] = [];
          }
          termSources[term].push(noteName);
        }
      }
      allTerms.sort();
      let content = `# Vocabulary Index - ${courseId}

`;
      content += `Total unique terms: ${allTerms.length}

`;
      for (const term of allTerms) {
        content += `## ${term}
`;
        content += `**Sources:** ${termSources[term].join(", ")}

`;
        content += `**Definition:**

`;
        content += `**Context:**

`;
        content += `**Examples:**

`;
        content += `---

`;
      }
      return content;
    });
  }
  createVocabularyIndexFile(courseId) {
    return __async(this, null, function* () {
      try {
        const vocabularyData = yield this.extractVocabularyFromCourse(courseId);
        if (Object.keys(vocabularyData).length === 0) {
          console.log(`No vocabulary found for course: ${courseId}`);
          return;
        }
        const indexContent = yield this.generateVocabularyIndex(
          courseId,
          vocabularyData
        );
        const fileName = `${courseId} - Vocabulary Index.md`;
        const filePath = `Courses/${courseId}/${fileName}`;
        try {
          yield this.app.vault.create(filePath, indexContent);
          console.log(`Created vocabulary index file: ${filePath}`);
        } catch (error) {
          const existingFile = this.app.vault.getAbstractFileByPath(filePath);
          if (existingFile && existingFile instanceof import_obsidian5.TFile) {
            yield this.app.vault.modify(existingFile, indexContent);
            console.log(`Updated vocabulary index file: ${filePath}`);
          }
        }
      } catch (error) {
        console.error(
          `Error creating vocabulary index for course ${courseId}:`,
          error
        );
        throw error;
      }
    });
  }
};

// dueDates.ts
var import_obsidian6 = require("obsidian");
var DueDatesParser = class {
  constructor(app) {
    this.app = app;
  }
  parseDueDatesFromNote(content) {
    const dueDatesRegex = /# Due Dates[\s\S]*?(?=\n#|$)/;
    const matches = content == null ? void 0 : content.match(dueDatesRegex);
    if (!matches) {
      return [];
    }
    const dueDatesSection = matches[0];
    const dueDates = [];
    const tableRegex = /\|[\s\S]*?\n/g;
    const tableMatches = dueDatesSection.match(tableRegex);
    if (tableMatches) {
      for (const table of tableMatches) {
        const rows = table.trim().split("\n").filter((row) => row.startsWith("|"));
        const parsedRows = this.parseTableRows(rows);
        dueDates.push(...parsedRows);
      }
    }
    return dueDates;
  }
  parseTableRows(rows) {
    if (rows.length < 2)
      return [];
    const dueDates = [];
    for (let i = 1; i < rows.length; i++) {
      const row = rows[i];
      const columns = row.split("|").map((col) => col.trim()).filter((col) => col);
      if (columns.length >= 2) {
        const [date, assignment, status = "pending"] = columns;
        if (date && assignment && this.isValidDate(date)) {
          dueDates.push({ date, assignment, status });
        }
      }
    }
    return dueDates;
  }
  isValidDate(dateString) {
    const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
    return dateRegex.test(dateString) && !isNaN(Date.parse(dateString));
  }
  parseDueDatesFromCourse(courseId, startDate, endDate) {
    return __async(this, null, function* () {
      console.log(`Parsing due dates for course: ${courseId}`);
      try {
        const courseNotes = yield this.findCourseNotes(courseId);
        if (courseNotes.length === 0) {
          console.log(`No notes found for course: ${courseId}`);
          return [];
        }
        const allDueDates = [];
        for (const note of courseNotes) {
          try {
            const content = yield this.app.vault.read(note);
            const dueDates = this.parseDueDatesFromNote(content);
            const dueDatesWithSource = dueDates.map((dueDate) => __spreadProps(__spreadValues({}, dueDate), {
              source: note.basename
            }));
            allDueDates.push(...dueDatesWithSource);
          } catch (error) {
            console.error(`Error reading note ${note.path}:`, error);
          }
        }
        let filteredDueDates = allDueDates;
        if (startDate || endDate) {
          filteredDueDates = this.filterByDateRange(
            allDueDates,
            startDate,
            endDate
          );
        }
        filteredDueDates.sort(
          (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()
        );
        console.log(
          `Found ${filteredDueDates.length} due dates for course: ${courseId}`
        );
        return filteredDueDates;
      } catch (error) {
        console.error(`Error parsing due dates for course ${courseId}:`, error);
        return [];
      }
    });
  }
  findCourseNotes(courseId) {
    return __async(this, null, function* () {
      const notes = [];
      const files = this.app.vault.getMarkdownFiles();
      for (const file of files) {
        if (file.path.includes(courseId) || (yield this.noteBelongsToCourse(file, courseId))) {
          notes.push(file);
        }
      }
      return notes;
    });
  }
  noteBelongsToCourse(file, courseId) {
    return __async(this, null, function* () {
      try {
        const content = yield this.app.vault.read(file);
        const frontmatterMatch = content.match(/^---\n([\s\S]*?)\n---/);
        if (frontmatterMatch) {
          const frontmatter = frontmatterMatch[1];
          return frontmatter.includes(`course_id: ${courseId}`) || frontmatter.includes(`course_id:${courseId}`);
        }
        return false;
      } catch (error) {
        console.error(
          `Error checking if note ${file.path} belongs to course ${courseId}:`,
          error
        );
        return false;
      }
    });
  }
  filterByDateRange(dueDates, startDate, endDate) {
    return dueDates.filter((dueDate) => {
      const dueDateTime = new Date(dueDate.date).getTime();
      if (startDate && dueDateTime < new Date(startDate).getTime()) {
        return false;
      }
      if (endDate && dueDateTime > new Date(endDate).getTime()) {
        return false;
      }
      return true;
    });
  }
  generateDueDatesSummary(courseId, dueDates) {
    return __async(this, null, function* () {
      if (dueDates.length === 0) {
        return `# Due Dates Summary - ${courseId}

No due dates found.
`;
      }
      const byStatus = dueDates.reduce((acc, dueDate) => {
        if (!acc[dueDate.status]) {
          acc[dueDate.status] = [];
        }
        acc[dueDate.status].push(dueDate);
        return acc;
      }, {});
      let content = `# Due Dates Summary - ${courseId}

`;
      content += `Total assignments: ${dueDates.length}

`;
      for (const [status, items] of Object.entries(byStatus)) {
        content += `## ${status.charAt(0).toUpperCase() + status.slice(1)} (${items.length})

`;
        content += `| Date | Assignment | Source |
`;
        content += `| ---- | ---------- | ------ |
`;
        for (const item of items) {
          content += `| ${item.date} | ${item.assignment} | ${item.source} |
`;
        }
        content += `
`;
      }
      return content;
    });
  }
  createDueDatesSummaryFile(courseId, startDate, endDate) {
    return __async(this, null, function* () {
      try {
        const dueDates = yield this.parseDueDatesFromCourse(
          courseId,
          startDate,
          endDate
        );
        const summaryContent = yield this.generateDueDatesSummary(
          courseId,
          dueDates
        );
        const fileName = `${courseId} - Due Dates Summary.md`;
        const filePath = `Courses/${courseId}/${fileName}`;
        try {
          yield this.app.vault.create(filePath, summaryContent);
          console.log(`Created due dates summary file: ${filePath}`);
        } catch (error) {
          const existingFile = this.app.vault.getAbstractFileByPath(filePath);
          if (existingFile && existingFile instanceof import_obsidian6.TFile) {
            yield this.app.vault.modify(existingFile, summaryContent);
            console.log(`Updated due dates summary file: ${filePath}`);
          }
        }
      } catch (error) {
        console.error(
          `Error creating due dates summary for course ${courseId}:`,
          error
        );
        throw error;
      }
    });
  }
};

// dailyNotes.ts
var import_obsidian7 = require("obsidian");
var DailyNotesIntegration = class {
  constructor(app) {
    this.app = app;
  }
  getTodaysActivities() {
    return __async(this, null, function* () {
      console.log("Getting today's academic activities");
      try {
        const today = new Date();
        const todayString = today.toISOString().split("T")[0];
        const files = this.app.vault.getMarkdownFiles();
        const todaysFiles = [];
        for (const file of files) {
          const fileDate = this.extractDateFromPath(file.path);
          if (fileDate === todayString) {
            todaysFiles.push(file);
          }
        }
        const activities = [];
        for (const file of todaysFiles) {
          const activity = yield this.analyzeFileActivity(file);
          if (activity) {
            activities.push(activity);
          }
        }
        console.log(`Found ${activities.length} academic activities for today`);
        return activities;
      } catch (error) {
        console.error("Error getting today's activities:", error);
        return [];
      }
    });
  }
  getCourseActivityForDate(courseId, date) {
    return __async(this, null, function* () {
      console.log(`Getting activity for course ${courseId} on date ${date}`);
      try {
        const courseFiles = yield this.findCourseFilesForDate(courseId, date);
        const activities = [];
        for (const file of courseFiles) {
          const content = yield this.app.vault.read(file);
          const fileType = this.determineFileType(file, content);
          activities.push({
            file: file.basename,
            type: fileType
          });
        }
        console.log(
          `Found ${activities.length} activities for course ${courseId} on ${date}`
        );
        return activities;
      } catch (error) {
        console.error(
          `Error getting course activity for ${courseId} on ${date}:`,
          error
        );
        return [];
      }
    });
  }
  extractDateFromPath(filePath) {
    const dateRegex = /(\d{4}-\d{2}-\d{2})/g;
    const matches = filePath.match(dateRegex);
    return matches ? matches[matches.length - 1] : null;
  }
  analyzeFileActivity(file) {
    return __async(this, null, function* () {
      try {
        const content = yield this.app.vault.read(file);
        const fileType = this.determineFileType(file, content);
        const courseId = this.extractCourseIdFromContent(content) || this.extractCourseIdFromPath(file.path);
        return {
          file: file.basename,
          type: fileType,
          course: courseId || void 0
        };
      } catch (error) {
        console.error(`Error analyzing file ${file.path}:`, error);
        return null;
      }
    });
  }
  determineFileType(file, content) {
    const path = file.path.toLowerCase();
    if (path.includes("daily") || content.includes("content_type: daily_note")) {
      return "daily_note";
    }
    if (path.includes("courses") || content.includes("course_id:")) {
      if (content.includes("content_type: course_homepage")) {
        return "course_homepage";
      }
      if (content.includes("content_type: module")) {
        return "module";
      }
      if (content.includes("content_type: chapter")) {
        return "chapter";
      }
      if (content.includes("content_type: assignment")) {
        return "assignment";
      }
      return "course_note";
    }
    if (content.includes("## ") && content.match(/^\*\*Term\*\*:/m)) {
      return "vocabulary_entry";
    }
    return "other";
  }
  extractCourseIdFromContent(content) {
    const courseIdRegex = /course_id:\s*([A-Z]{2,4}-\d{3})/;
    const match = content.match(courseIdRegex);
    return match ? match[1] : null;
  }
  extractCourseIdFromPath(filePath) {
    const courseIdRegex = /([A-Z]{2,4}-\d{3})/g;
    const matches = filePath.match(courseIdRegex);
    return matches ? matches[matches.length - 1] : null;
  }
  findCourseFilesForDate(courseId, date) {
    return __async(this, null, function* () {
      const files = [];
      const allFiles = this.app.vault.getMarkdownFiles();
      for (const file of allFiles) {
        if (file.path.includes(courseId) || (yield this.fileBelongsToCourse(file, courseId))) {
          const fileDate = this.extractDateFromPath(file.path);
          if (fileDate === date) {
            files.push(file);
          }
        }
      }
      return files;
    });
  }
  fileBelongsToCourse(file, courseId) {
    return __async(this, null, function* () {
      try {
        const content = yield this.app.vault.read(file);
        return this.extractCourseIdFromContent(content) === courseId;
      } catch (error) {
        console.error(
          `Error checking if file ${file.path} belongs to course ${courseId}:`,
          error
        );
        return false;
      }
    });
  }
  generateDailySummary(date) {
    return __async(this, null, function* () {
      const targetDate = date || new Date().toISOString().split("T")[0];
      const activities = yield this.getCourseActivityForDate("", targetDate);
      if (activities.length === 0) {
        return `# Academic Activities - ${targetDate}

No academic activities recorded for this date.
`;
      }
      const byCourse = {};
      const noCourse = [];
      for (const activity of activities) {
        if (activity.file.includes("Courses/")) {
          const pathParts = activity.file.split("/");
          const courseIndex = pathParts.findIndex((part) => part.includes("-"));
          if (courseIndex >= 0) {
            const courseId = pathParts[courseIndex];
            if (!byCourse[courseId]) {
              byCourse[courseId] = [];
            }
            byCourse[courseId].push(activity);
          } else {
            noCourse.push(activity);
          }
        } else {
          noCourse.push(activity);
        }
      }
      let content = `# Academic Activities - ${targetDate}

`;
      content += `Total activities: ${activities.length}

`;
      for (const [courseId, courseActivities] of Object.entries(byCourse)) {
        content += `## ${courseId}

`;
        content += `| File | Type |
`;
        content += `| ---- | ---- |
`;
        for (const activity of courseActivities) {
          content += `| ${activity.file} | ${activity.type} |
`;
        }
        content += `
`;
      }
      if (noCourse.length > 0) {
        content += `## Other Activities

`;
        content += `| File | Type |
`;
        content += `| ---- | ---- |
`;
        for (const activity of noCourse) {
          content += `| ${activity.file} | ${activity.type} |
`;
        }
        content += `
`;
      }
      return content;
    });
  }
  createDailySummaryFile(date) {
    return __async(this, null, function* () {
      try {
        const targetDate = date || new Date().toISOString().split("T")[0];
        const summaryContent = yield this.generateDailySummary(targetDate);
        const fileName = `${targetDate} - Academic Summary.md`;
        const filePath = `Daily/${fileName}`;
        try {
          yield this.app.vault.create(filePath, summaryContent);
          console.log(`Created daily summary file: ${filePath}`);
        } catch (error) {
          const existingFile = this.app.vault.getAbstractFileByPath(filePath);
          if (existingFile && existingFile instanceof import_obsidian7.TFile) {
            yield this.app.vault.modify(existingFile, summaryContent);
            console.log(`Updated daily summary file: ${filePath}`);
          }
        }
      } catch (error) {
        console.error(`Error creating daily summary for ${date}:`, error);
        throw error;
      }
    });
  }
};

// assignmentsModal.ts
var import_obsidian8 = require("obsidian");
var AssignmentsModal = class extends import_obsidian8.Modal {
  constructor(app, courseName, courseId, onSubmit) {
    super(app);
    this.assignments = [{ name: "", dueDate: "", type: "", points: "", description: "" }];
    this.courseName = courseName;
    this.courseId = courseId;
    this.onSubmit = onSubmit;
  }
  onOpen() {
    const { contentEl } = this;
    contentEl.empty();
    contentEl.addClass("tuckers-tools-assignments-modal");
    contentEl.createEl("h2", { text: "Create Multiple Assignments" });
    new import_obsidian8.Setting(contentEl).setName("Course").setDesc(`${this.courseName} (${this.courseId})`).setDisabled(true);
    const assignmentsContainer = contentEl.createDiv({ cls: "assignments-container" });
    this.addAssignmentSection(assignmentsContainer, 0);
    new import_obsidian8.Setting(contentEl).addButton(
      (btn) => btn.setButtonText("Add Assignment").setCta().onClick(() => {
        const newIndex = this.assignments.length;
        this.assignments.push({ name: "", dueDate: "", type: "", points: "", description: "" });
        this.addAssignmentSection(assignmentsContainer, newIndex);
      })
    );
    new import_obsidian8.Setting(contentEl).addButton(
      (btn) => btn.setButtonText("Create Assignments").setCta().onClick(() => {
        const validAssignments = this.assignments.filter(
          (a) => a.name.trim() !== "" || a.dueDate.trim() !== ""
        );
        this.onSubmit(validAssignments, this.courseName, this.courseId);
        this.close();
      })
    );
  }
  addAssignmentSection(container, index) {
    const section = container.createDiv({ cls: "assignment-section" });
    section.createEl("h3", { text: `Assignment #${index + 1}` });
    new import_obsidian8.Setting(section).setName("Assignment Name").addText(
      (text) => text.setPlaceholder("Enter assignment name").setValue(this.assignments[index].name).onChange((value) => {
        this.assignments[index].name = value;
      })
    );
    new import_obsidian8.Setting(section).setName("Due Date").setDesc("Format: YYYY-MM-DD").addText(
      (text) => text.setPlaceholder("2024-01-15").setValue(this.assignments[index].dueDate).onChange((value) => {
        this.assignments[index].dueDate = value;
      })
    );
    new import_obsidian8.Setting(section).setName("Assignment Type").addText(
      (text) => text.setPlaceholder("e.g., Homework, Quiz, Exam").setValue(this.assignments[index].type).onChange((value) => {
        this.assignments[index].type = value;
      })
    );
    new import_obsidian8.Setting(section).setName("Points").addText(
      (text) => text.setPlaceholder("e.g., 100").setValue(this.assignments[index].points).onChange((value) => {
        this.assignments[index].points = value;
      })
    );
    new import_obsidian8.Setting(section).setName("Description").addTextArea(
      (text) => text.setPlaceholder("Enter assignment description").setValue(this.assignments[index].description).onChange((value) => {
        this.assignments[index].description = value;
      })
    );
    if (this.assignments.length > 1) {
      new import_obsidian8.Setting(section).addButton(
        (btn) => btn.setButtonText("Remove").onClick(() => {
          this.assignments.splice(index, 1);
          section.remove();
          this.renumberAssignments();
        })
      );
    }
  }
  renumberAssignments() {
    const sections = this.contentEl.querySelectorAll(".assignment-section");
    sections.forEach((section, index) => {
      const header = section.querySelector("h3");
      if (header) {
        header.textContent = `Assignment #${index + 1}`;
      }
    });
  }
  onClose() {
    const { contentEl } = this;
    contentEl.empty();
  }
};

// Supporting/dataview-functions.ts
function processCourseVocabulary(dv, courseId) {
  return __async(this, null, function* () {
    try {
      const pages = dv.pages(courseId).filter((p) => p.file.ext === "md" && p.file.name !== courseId).map((p) => ({
        name: p.file.name,
        path: p.file.path
      }));
      dv.header(1, "All Course Vocabulary");
      for (const page of pages) {
        if (!page.path)
          continue;
        try {
          const file = yield dv.app.vault.getFileByPath(page.path);
          const content = yield dv.app.vault.read(file);
          const vocabRegex = /^#+ Vocabulary.*\n((?:.*?\n)*?)(?=\n\s*#|$)/m;
          const vocabMatches = content == null ? void 0 : content.match(vocabRegex);
          if (vocabMatches) {
            const vocabData = vocabMatches[1].trim();
            const cleanedVocab = vocabData.replace(/\[\[.*?\]\]/g, "").trim().split("\n").filter((line) => line.startsWith("- ")).map((line) => line.substring(2)).filter(Boolean);
            if (cleanedVocab.length > 0) {
              dv.header(3, `[[${page.name}]]`);
              dv.list(cleanedVocab);
            }
          }
        } catch (e) {
          console.log(`Error processing ${page.path}:`, e);
          continue;
        }
      }
    } catch (error) {
      console.error("Error in Vocabulary Processing:", error);
    }
  });
}
function processDueDates(dv, source, startDate = null, endDate = null) {
  return __async(this, null, function* () {
    var _a, _b, _c, _d, _e, _f, _g, _h;
    function deduplicateFirstTwoColumns(arr) {
      const seen = /* @__PURE__ */ new Set();
      return arr.filter((entry) => {
        const key = JSON.stringify([entry[0], entry[1]]);
        return !seen.has(key) && seen.add(key);
      });
    }
    const defaultStartDate = window.moment().subtract(1, "day").format("YYYY-MM-DD");
    const start = startDate || defaultStartDate;
    const end = endDate || window.moment().add(1, "year").format("YYYY-MM-DD");
    const pages = yield dv.pages(source).filter((p) => p.file.name !== source && p.file.ext == "md");
    let allEntries = [];
    for (const page of pages.values) {
      if (!((_a = page == null ? void 0 : page.file) == null ? void 0 : _a.path)) {
        return;
      }
      const content = yield dv.app.vault.cachedRead(dv.app.vault.getFileByPath((_b = page.file) == null ? void 0 : _b.path));
      const regex = /# Due Dates([\s\S]*?)(?=\n#|$)/;
      const matches = content == null ? void 0 : content.match(regex);
      if (matches) {
        const tableData = matches[1].trim();
        const lines = tableData.split("\n").slice(1);
        for (const line of lines) {
          let formattedDueDate;
          const columns = line.split("|").map((c) => c.trim()).filter((c) => c);
          let [dueDate, assignment] = columns;
          if (!Date.parse(dueDate) || (assignment == null ? void 0 : assignment.match(/✅/))) {
            continue;
          }
          assignment = (assignment == null ? void 0 : assignment.match(/[A-Z]{3}-[0-9]{3}/)) ? assignment : `#${page.course_id} - ${assignment}`;
          if (window.moment(dueDate).isBetween(start, end, void 0, "[]")) {
            const uniqueRow = !allEntries.some(
              (e) => {
                var _a2;
                return e[0].match((_a2 = window.moment(dueDate)) == null ? void 0 : _a2.format("YYYY-MM-DD")) && e[1] == assignment;
              }
            );
            if (assignment && uniqueRow) {
              if ((_c = window.moment(dueDate)) == null ? void 0 : _c.isBefore(start)) {
                continue;
              } else if (window.moment(dueDate).isAfter(window.moment().subtract(1, "w"))) {
                formattedDueDate = `<span class="due one_week">${(_d = window.moment(
                  dueDate
                )) == null ? void 0 : _d.format("YYYY-MM-DD ddd")}</span>`;
              } else if (window.moment(dueDate).isAfter(window.moment().subtract(2, "w"))) {
                formattedDueDate = `<span class="due two_weeks">${(_e = window.moment(
                  dueDate
                )) == null ? void 0 : _e.format("YYYY-MM-DD ddd")}</span>`;
              } else {
                formattedDueDate = (_f = window.moment(dueDate)) == null ? void 0 : _f.format("YYYY-MM-DD ddd");
              }
              allEntries.push([
                dueDate,
                formattedDueDate,
                assignment,
                `[[${(_g = page == null ? void 0 : page.file) == null ? void 0 : _g.path}|${(_h = page == null ? void 0 : page.file) == null ? void 0 : _h.name}]]`
              ]);
            }
          }
        }
      }
    }
    const sortedRows = deduplicateFirstTwoColumns(
      allEntries.sort((a, b) => window.moment(a[0]).valueOf() - window.moment(b[0]).valueOf()).map((a) => [a[1], a[2], a[3]])
    );
    const table = dv.markdownTable(["Due Date", "Task Description", "File"], sortedRows);
    dv.el("table", table);
  });
}

// main.ts
var TuckersToolsPlugin = class extends import_obsidian9.Plugin {
  onload() {
    return __async(this, null, function* () {
      console.log("Loading Tuckers Tools plugin");
      yield this.loadSettings();
      this.templateManager = new TemplateManager(this.app, this.settings);
      this.courseWizard = new CourseCreationWizard(this.app, this.settings);
      this.vocabularyExtractor = new VocabularyExtractor(this.app);
      this.dueDatesParser = new DueDatesParser(this.app);
      this.dailyNotesIntegration = new DailyNotesIntegration(this.app);
      this.dataviewFunctions = { processCourseVocabulary, processDueDates };
      this.addSettingTab(new TuckersToolsSettingTab(this.app, this));
      this.initializeTemplaterFunctions();
      this.addCommand({
        id: "install-templates",
        name: "Install/Update Tuckers Tools Templates",
        callback: () => {
          this.templateManager.installTemplates();
        }
      });
      this.addCommand({
        id: "update-templates",
        name: "Update Tuckers Tools Templates",
        callback: () => {
          this.templateManager.updateTemplates();
        }
      });
      this.addCommand({
        id: "create-multiple-assignments",
        name: "Create Multiple Assignments for Course",
        callback: () => __async(this, null, function* () {
          const currentFile = this.app.workspace.getActiveFile();
          let courseId = "";
          let courseName = "";
          if (currentFile) {
            const cache = this.app.metadataCache.getFileCache(currentFile);
            if (cache && cache.frontmatter) {
              courseId = cache.frontmatter.course_id || "";
              courseName = cache.frontmatter.course_name || cache.frontmatter.title || currentFile.basename;
            }
          }
          if (!courseId) {
            const promptedCourseId = yield this.promptForCourseId("Enter course ID for assignments");
            if (!promptedCourseId)
              return;
            courseId = promptedCourseId;
            courseName = courseId;
          }
          new AssignmentsModal(
            this.app,
            courseName,
            courseId,
            (assignments, courseName2, courseId2) => __async(this, null, function* () {
              for (const assignment of assignments) {
                if (assignment.name.trim() === "")
                  continue;
                const assignmentContent = this.generateAssignmentFileContent(
                  assignment,
                  courseName2,
                  courseId2
                );
                const fileName = `${courseId2} - ${assignment.name.replace(/[<>:"/\\|?*]/g, "_")}.md`;
                const filePath = `${courseId2}/${fileName}`;
                try {
                  yield this.app.vault.create(filePath, assignmentContent);
                  console.log(`Created assignment file: ${filePath}`);
                } catch (error) {
                  console.error(`Error creating assignment file ${filePath}:`, error);
                }
              }
            })
          ).open();
        })
      });
      this.addCommand({
        id: "extract-vocabulary",
        name: "Extract Course Vocabulary",
        callback: () => __async(this, null, function* () {
          const courseId = yield this.promptForCourseId(
            "Enter course ID to extract vocabulary from"
          );
          if (courseId) {
            yield this.vocabularyExtractor.createVocabularyIndexFile(courseId);
          }
        })
      });
      this.addCommand({
        id: "generate-due-dates-summary",
        name: "Generate Due Dates Summary",
        callback: () => __async(this, null, function* () {
          const courseId = yield this.promptForCourseId(
            "Enter course ID to generate due dates summary for"
          );
          if (courseId) {
            yield this.dueDatesParser.createDueDatesSummaryFile(courseId);
          }
        })
      });
      this.addCommand({
        id: "generate-daily-summary",
        name: "Generate Daily Academic Summary",
        callback: () => __async(this, null, function* () {
          const date = yield this.promptForDate(
            "Enter date (YYYY-MM-DD) or leave empty for today"
          );
          yield this.dailyNotesIntegration.createDailySummaryFile(
            date || void 0
          );
        })
      });
      this.addStatusBarItem().setText("Tuckers Tools");
    });
  }
  promptForCourseId(message) {
    return __async(this, null, function* () {
      const courseId = prompt(message + "\n\nExample: PSI-101");
      return courseId ? courseId.trim() : null;
    });
  }
  promptForDate(message) {
    return __async(this, null, function* () {
      const date = prompt(
        message + "\n\nExample: 2025-01-15 or leave empty for today"
      );
      return date ? date.trim() : null;
    });
  }
  generateAssignmentFileContent(assignment, courseName, courseId) {
    return `---
course_id: ${courseId}
assignment_type: ${assignment.type || "Assignment"}
due_date: ${assignment.dueDate}
points: ${assignment.points || ""}
content_type: assignment
created: ${new Date().toISOString()}
status: pending
tags:
  - education
  - ${courseId}
  - assignment
---

# ${assignment.name} - ${courseId}

## Description
${assignment.description}

## Instructions


## Due Date
**Assigned**: ${new Date().toISOString().split("T")[0]}
**Due**: ${assignment.dueDate}

## Submission


## Grading Criteria


## Resources


# Due Dates
| ${assignment.dueDate} | ${assignment.name} | pending |
`;
  }
  onunload() {
    console.log("Unloading Tuckers Tools plugin");
  }
  initializeTemplaterFunctions() {
    return __async(this, null, function* () {
      const templaterPlugin = this.app.plugins.getPlugin("templater-obsidian");
      if (!templaterPlugin) {
        console.log("Templater plugin not found. Course templates will not work properly.");
        return;
      }
      try {
        if (templaterPlugin && templaterPlugin.templater) {
          if (!templaterPlugin.templater.functions) {
            templaterPlugin.templater.functions = {};
          }
          templaterPlugin.templater.functions["new_module"] = (app, tp, year) => __async(this, null, function* () {
            return this.newModuleFunction(app, tp, year);
          });
          if (!templaterPlugin.templater.functions.user) {
            templaterPlugin.templater.functions.user = {};
          }
          templaterPlugin.templater.functions.user["new_module"] = (app, tp, year) => __async(this, null, function* () {
            return this.newModuleFunction(app, tp, year);
          });
          templaterPlugin.templater.functions["new_chapter"] = (tp) => __async(this, null, function* () {
            return this.newChapterFunction(tp);
          });
          templaterPlugin.templater.functions.user["new_chapter"] = (tp) => __async(this, null, function* () {
            return this.newChapterFunction(tp);
          });
          console.log("Tuckers Tools templater functions registered successfully");
        } else {
          console.error("Could not register templater functions - templater object not found");
        }
      } catch (e) {
        console.error("Error registering templater functions:", e);
      }
    });
  }
  newModuleFunction(app, tp, year) {
    return __async(this, null, function* () {
      var _a;
      let moduleNumber = "";
      let weekNumber = "";
      let course = "";
      let courseId = "";
      let discipline = "GEN";
      let dayOfWeek = "";
      try {
        if (tp && tp.system && tp.system.prompt) {
          const tempModuleNumber = yield tp.system.prompt("Module Number (optional)", "");
          moduleNumber = tempModuleNumber ? tempModuleNumber : null;
          const tempWeekNumber = yield tp.system.prompt("Week Number (optional)", "");
          weekNumber = tempWeekNumber ? tempWeekNumber : null;
          const courseFiles = app.vault.getMarkdownFiles().filter((f) => {
            const cache = app.metadataCache.getFileCache(f);
            return cache && (cache.tags && cache.tags.some((tag) => tag.tag === "#course_home") || cache.frontmatter && cache.frontmatter.contentType === "Course" || cache.frontmatter && cache.frontmatter.tags && (Array.isArray(cache.frontmatter.tags) ? cache.frontmatter.tags.includes("course_home") : cache.frontmatter.tags === "course_home"));
          });
          course = yield tp.system.suggester(
            () => courseFiles.map((f) => f.basename),
            courseFiles
          );
          dayOfWeek = yield tp.system.suggester(
            ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
            ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
            "Day of Week"
          );
        } else {
          moduleNumber = null;
          weekNumber = null;
          course = "New Course";
          dayOfWeek = "Monday";
        }
      } catch (e) {
        console.error("Error in new_module prompts:", e);
        moduleNumber = null;
        weekNumber = null;
        course = "New Course";
        dayOfWeek = "Monday";
      }
      courseId = course ? course.split(" - ")[0] || course : "";
      discipline = course ? ((_a = course.split(" - ")[0]) == null ? void 0 : _a.substring(0, 3)) || "GEN" : "GEN";
      return {
        season: "Fall",
        // This would normally be dynamically determined
        moduleNumber,
        weekNumber,
        course,
        courseId,
        discipline,
        dayOfWeek
      };
    });
  }
  newChapterFunction(tp) {
    return __async(this, null, function* () {
      var _a;
      let chapterNumber = "";
      let course = "";
      let courseId = "";
      let discipline = "GEN";
      let text = "";
      try {
        if (tp && tp.system && tp.system.prompt) {
          chapterNumber = (yield tp.system.prompt("Chapter Number", "")) || "";
          const courseFiles = tp.app.vault.getMarkdownFiles().filter((f) => {
            const cache = tp.app.metadataCache.getFileCache(f);
            return cache && (cache.tags && cache.tags.some((tag) => tag.tag === "#course_home") || cache.frontmatter && cache.frontmatter.contentType === "Course" || cache.frontmatter && cache.frontmatter.tags && (Array.isArray(cache.frontmatter.tags) ? cache.frontmatter.tags.includes("course_home") : cache.frontmatter.tags === "course_home"));
          });
          course = yield tp.system.suggester(
            () => courseFiles.map((f) => f.basename),
            courseFiles
          );
          const textOptions = tp.app.vault.getFiles().filter((f) => f.extension === "pdf").map((f) => f.basename);
          text = yield tp.system.suggester(textOptions, textOptions, "Textbook");
        } else {
          chapterNumber = "";
          course = "New Course";
          text = "New Textbook";
        }
      } catch (e) {
        console.error("Error in new_chapter prompts:", e);
        chapterNumber = "";
        course = "New Course";
        text = "New Textbook";
      }
      courseId = course ? course.split(" - ")[0] || course : "";
      discipline = course ? ((_a = course.split(" - ")[0]) == null ? void 0 : _a.substring(0, 3)) || "GEN" : "GEN";
      return {
        chapterNumber,
        course,
        courseId,
        discipline,
        text
      };
    });
  }
  loadSettings() {
    return __async(this, null, function* () {
      this.settings = Object.assign({}, DEFAULT_SETTINGS, yield this.loadData());
    });
  }
  saveSettings() {
    return __async(this, null, function* () {
      yield this.saveData(this.settings);
    });
  }
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsibWFpbi50cyIsICJzZXR0aW5ncy50cyIsICJ1dGlscy50cyIsICJ0ZW1wbGF0ZU1hbmFnZXIudHMiLCAiY291cnNlV2l6YXJkLnRzIiwgImlucHV0TW9kYWwudHMiLCAidm9jYWJ1bGFyeS50cyIsICJkdWVEYXRlcy50cyIsICJkYWlseU5vdGVzLnRzIiwgImFzc2lnbm1lbnRzTW9kYWwudHMiLCAiU3VwcG9ydGluZy9kYXRhdmlldy1mdW5jdGlvbnMudHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbImltcG9ydCB7IFBsdWdpbiwgTm90aWNlLCBURmlsZSB9IGZyb20gXCJvYnNpZGlhblwiXG5pbXBvcnQge1xuICBUdWNrZXJzVG9vbHNTZXR0aW5ncyxcbiAgREVGQVVMVF9TRVRUSU5HUyxcbiAgVHVja2Vyc1Rvb2xzU2V0dGluZ1RhYlxufSBmcm9tIFwiLi9zZXR0aW5nc1wiXG5pbXBvcnQgeyBUZW1wbGF0ZU1hbmFnZXIgfSBmcm9tIFwiLi90ZW1wbGF0ZU1hbmFnZXJcIlxuaW1wb3J0IHsgQ291cnNlQ3JlYXRpb25XaXphcmQgfSBmcm9tIFwiLi9jb3Vyc2VXaXphcmRcIlxuaW1wb3J0IHsgVm9jYWJ1bGFyeUV4dHJhY3RvciB9IGZyb20gXCIuL3ZvY2FidWxhcnlcIlxuaW1wb3J0IHsgRHVlRGF0ZXNQYXJzZXIgfSBmcm9tIFwiLi9kdWVEYXRlc1wiXG5pbXBvcnQgeyBEYWlseU5vdGVzSW50ZWdyYXRpb24gfSBmcm9tIFwiLi9kYWlseU5vdGVzXCJcbmltcG9ydCB7IEFzc2lnbm1lbnRzTW9kYWwgfSBmcm9tIFwiLi9hc3NpZ25tZW50c01vZGFsXCJcblxuaW1wb3J0IHsgcHJvY2Vzc0NvdXJzZVZvY2FidWxhcnksIHByb2Nlc3NEdWVEYXRlcyB9IGZyb20gXCIuL1N1cHBvcnRpbmcvZGF0YXZpZXctZnVuY3Rpb25zXCI7XG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFR1Y2tlcnNUb29sc1BsdWdpbiBleHRlbmRzIFBsdWdpbiB7XG4gIHNldHRpbmdzOiBUdWNrZXJzVG9vbHNTZXR0aW5nc1xuICB0ZW1wbGF0ZU1hbmFnZXI6IFRlbXBsYXRlTWFuYWdlclxuICBjb3Vyc2VXaXphcmQ6IENvdXJzZUNyZWF0aW9uV2l6YXJkXG4gIHZvY2FidWxhcnlFeHRyYWN0b3I6IFZvY2FidWxhcnlFeHRyYWN0b3JcbiAgZHVlRGF0ZXNQYXJzZXI6IER1ZURhdGVzUGFyc2VyXG4gIGRhaWx5Tm90ZXNJbnRlZ3JhdGlvbjogRGFpbHlOb3Rlc0ludGVncmF0aW9uXG4gIGRhdGF2aWV3RnVuY3Rpb25zOiBhbnk7XG5cbiAgYXN5bmMgb25sb2FkKCkge1xuICAgIGNvbnNvbGUubG9nKFwiTG9hZGluZyBUdWNrZXJzIFRvb2xzIHBsdWdpblwiKVxuXG4gICAgLy8gTG9hZCBzZXR0aW5nc1xuICAgIGF3YWl0IHRoaXMubG9hZFNldHRpbmdzKClcblxuICAgIC8vIEluaXRpYWxpemUgY29tcG9uZW50c1xuICAgIHRoaXMudGVtcGxhdGVNYW5hZ2VyID0gbmV3IFRlbXBsYXRlTWFuYWdlcih0aGlzLmFwcCwgdGhpcy5zZXR0aW5ncylcbiAgICB0aGlzLmNvdXJzZVdpemFyZCA9IG5ldyBDb3Vyc2VDcmVhdGlvbldpemFyZCh0aGlzLmFwcCwgdGhpcy5zZXR0aW5ncylcbiAgICB0aGlzLnZvY2FidWxhcnlFeHRyYWN0b3IgPSBuZXcgVm9jYWJ1bGFyeUV4dHJhY3Rvcih0aGlzLmFwcClcbiAgICB0aGlzLmR1ZURhdGVzUGFyc2VyID0gbmV3IER1ZURhdGVzUGFyc2VyKHRoaXMuYXBwKVxuICAgIHRoaXMuZGFpbHlOb3Rlc0ludGVncmF0aW9uID0gbmV3IERhaWx5Tm90ZXNJbnRlZ3JhdGlvbih0aGlzLmFwcClcbiAgICB0aGlzLmRhdGF2aWV3RnVuY3Rpb25zID0geyBwcm9jZXNzQ291cnNlVm9jYWJ1bGFyeSwgcHJvY2Vzc0R1ZURhdGVzIH07XG5cbiAgICAvLyBBZGQgc2V0dGluZ3MgdGFiXG4gICAgdGhpcy5hZGRTZXR0aW5nVGFiKG5ldyBUdWNrZXJzVG9vbHNTZXR0aW5nVGFiKHRoaXMuYXBwLCB0aGlzKSlcblxuICAgIC8vIEluaXRpYWxpemUgdGVtcGxhdGVyIGZ1bmN0aW9ucyBpZiB0ZW1wbGF0ZXIgaXMgYXZhaWxhYmxlXG4gICAgdGhpcy5pbml0aWFsaXplVGVtcGxhdGVyRnVuY3Rpb25zKClcblxuICAgIC8vIEFkZCBjb21tYW5kc1xuICAgIHRoaXMuYWRkQ29tbWFuZCh7XG4gICAgICBpZDogXCJpbnN0YWxsLXRlbXBsYXRlc1wiLFxuICAgICAgbmFtZTogXCJJbnN0YWxsL1VwZGF0ZSBUdWNrZXJzIFRvb2xzIFRlbXBsYXRlc1wiLFxuICAgICAgY2FsbGJhY2s6ICgpID0+IHtcbiAgICAgICAgdGhpcy50ZW1wbGF0ZU1hbmFnZXIuaW5zdGFsbFRlbXBsYXRlcygpXG4gICAgICB9XG4gICAgfSlcblxuICAgIHRoaXMuYWRkQ29tbWFuZCh7XG4gICAgICBpZDogXCJ1cGRhdGUtdGVtcGxhdGVzXCIsXG4gICAgICBuYW1lOiBcIlVwZGF0ZSBUdWNrZXJzIFRvb2xzIFRlbXBsYXRlc1wiLFxuICAgICAgY2FsbGJhY2s6ICgpID0+IHtcbiAgICAgICAgdGhpcy50ZW1wbGF0ZU1hbmFnZXIudXBkYXRlVGVtcGxhdGVzKClcbiAgICAgIH1cbiAgICB9KVxuXG4gICAgLy8gQ291cnNlIGNyZWF0aW9uIGlzIGhhbmRsZWQgYnkgVGVtcGxhdGVyIHRlbXBsYXRlcyAtIG5vIGN1c3RvbSBjb21tYW5kIG5lZWRlZFxuXG4gICAgdGhpcy5hZGRDb21tYW5kKHtcbiAgICAgIGlkOiBcImNyZWF0ZS1tdWx0aXBsZS1hc3NpZ25tZW50c1wiLFxuICAgICAgbmFtZTogXCJDcmVhdGUgTXVsdGlwbGUgQXNzaWdubWVudHMgZm9yIENvdXJzZVwiLFxuICAgICAgY2FsbGJhY2s6IGFzeW5jICgpID0+IHtcbiAgICAgICAgLy8gR2V0IHRoZSBjdXJyZW50IGNvdXJzZSBjb250ZXh0IG9yIHByb21wdCBmb3IgaXRcbiAgICAgICAgY29uc3QgY3VycmVudEZpbGUgPSB0aGlzLmFwcC53b3Jrc3BhY2UuZ2V0QWN0aXZlRmlsZSgpO1xuICAgICAgICBsZXQgY291cnNlSWQgPSBcIlwiO1xuICAgICAgICBsZXQgY291cnNlTmFtZSA9IFwiXCI7XG5cbiAgICAgICAgLy8gVHJ5IHRvIGRldGVybWluZSB0aGUgY291cnNlIGZyb20gdGhlIGN1cnJlbnQgZmlsZVxuICAgICAgICBpZiAoY3VycmVudEZpbGUpIHtcbiAgICAgICAgICBjb25zdCBjYWNoZSA9IHRoaXMuYXBwLm1ldGFkYXRhQ2FjaGUuZ2V0RmlsZUNhY2hlKGN1cnJlbnRGaWxlKTtcbiAgICAgICAgICBpZiAoY2FjaGUgJiYgY2FjaGUuZnJvbnRtYXR0ZXIpIHtcbiAgICAgICAgICAgIGNvdXJzZUlkID0gY2FjaGUuZnJvbnRtYXR0ZXIuY291cnNlX2lkIHx8IFwiXCI7XG4gICAgICAgICAgICBjb3Vyc2VOYW1lID0gY2FjaGUuZnJvbnRtYXR0ZXIuY291cnNlX25hbWUgfHwgY2FjaGUuZnJvbnRtYXR0ZXIudGl0bGUgfHwgY3VycmVudEZpbGUuYmFzZW5hbWU7XG4gICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgLy8gSWYgd2UgY291bGRuJ3QgZGV0ZXJtaW5lIHRoZSBjb3Vyc2UsIHByb21wdCBmb3IgaXRcbiAgICAgICAgaWYgKCFjb3Vyc2VJZCkge1xuICAgICAgICAgIGNvbnN0IHByb21wdGVkQ291cnNlSWQgPSBhd2FpdCB0aGlzLnByb21wdEZvckNvdXJzZUlkKFwiRW50ZXIgY291cnNlIElEIGZvciBhc3NpZ25tZW50c1wiKTtcbiAgICAgICAgICBpZiAoIXByb21wdGVkQ291cnNlSWQpIHJldHVybjtcbiAgICAgICAgICBjb3Vyc2VJZCA9IHByb21wdGVkQ291cnNlSWQ7XG4gICAgICAgICAgY291cnNlTmFtZSA9IGNvdXJzZUlkOyAvLyBGYWxsYmFjayBpZiB3ZSBkb24ndCBoYXZlIGEgYmV0dGVyIG5hbWVcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIFNob3cgdGhlIGFzc2lnbm1lbnRzIG1vZGFsXG4gICAgICAgIG5ldyBBc3NpZ25tZW50c01vZGFsKFxuICAgICAgICAgIHRoaXMuYXBwLFxuICAgICAgICAgIGNvdXJzZU5hbWUsXG4gICAgICAgICAgY291cnNlSWQsXG4gICAgICAgICAgYXN5bmMgKGFzc2lnbm1lbnRzLCBjb3Vyc2VOYW1lLCBjb3Vyc2VJZCkgPT4ge1xuICAgICAgICAgICAgLy8gUHJvY2VzcyB0aGUgYXNzaWdubWVudHMgLSBmb3Igbm93LCB3ZSdsbCBjcmVhdGUgaW5kaXZpZHVhbCBhc3NpZ25tZW50IGZpbGVzXG4gICAgICAgICAgICBmb3IgKGNvbnN0IGFzc2lnbm1lbnQgb2YgYXNzaWdubWVudHMpIHtcbiAgICAgICAgICAgICAgaWYgKGFzc2lnbm1lbnQubmFtZS50cmltKCkgPT09IFwiXCIpIGNvbnRpbnVlOyAvLyBTa2lwIGVtcHR5IGFzc2lnbm1lbnRzXG5cbiAgICAgICAgICAgICAgLy8gQ3JlYXRlIGFuIGFzc2lnbm1lbnQgZmlsZVxuICAgICAgICAgICAgICBjb25zdCBhc3NpZ25tZW50Q29udGVudCA9IHRoaXMuZ2VuZXJhdGVBc3NpZ25tZW50RmlsZUNvbnRlbnQoXG4gICAgICAgICAgICAgICAgYXNzaWdubWVudCxcbiAgICAgICAgICAgICAgICBjb3Vyc2VOYW1lLFxuICAgICAgICAgICAgICAgIGNvdXJzZUlkXG4gICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgIGNvbnN0IGZpbGVOYW1lID0gYCR7Y291cnNlSWR9IC0gJHthc3NpZ25tZW50Lm5hbWUucmVwbGFjZSgvWzw+OlwiL1xcXFx8PypdL2csIFwiX1wiKX0ubWRgO1xuICAgICAgICAgICAgICBjb25zdCBmaWxlUGF0aCA9IGAke2NvdXJzZUlkfS8ke2ZpbGVOYW1lfWA7XG5cbiAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBhd2FpdCB0aGlzLmFwcC52YXVsdC5jcmVhdGUoZmlsZVBhdGgsIGFzc2lnbm1lbnRDb250ZW50KTtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhgQ3JlYXRlZCBhc3NpZ25tZW50IGZpbGU6ICR7ZmlsZVBhdGh9YCk7XG4gICAgICAgICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihgRXJyb3IgY3JlYXRpbmcgYXNzaWdubWVudCBmaWxlICR7ZmlsZVBhdGh9OmAsIGVycm9yKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgKS5vcGVuKCk7XG4gICAgICB9XG4gICAgfSlcblxuICAgIHRoaXMuYWRkQ29tbWFuZCh7XG4gICAgICBpZDogXCJleHRyYWN0LXZvY2FidWxhcnlcIixcbiAgICAgIG5hbWU6IFwiRXh0cmFjdCBDb3Vyc2UgVm9jYWJ1bGFyeVwiLFxuICAgICAgY2FsbGJhY2s6IGFzeW5jICgpID0+IHtcbiAgICAgICAgY29uc3QgY291cnNlSWQgPSBhd2FpdCB0aGlzLnByb21wdEZvckNvdXJzZUlkKFxuICAgICAgICAgIFwiRW50ZXIgY291cnNlIElEIHRvIGV4dHJhY3Qgdm9jYWJ1bGFyeSBmcm9tXCJcbiAgICAgICAgKVxuICAgICAgICBpZiAoY291cnNlSWQpIHtcbiAgICAgICAgICBhd2FpdCB0aGlzLnZvY2FidWxhcnlFeHRyYWN0b3IuY3JlYXRlVm9jYWJ1bGFyeUluZGV4RmlsZShjb3Vyc2VJZClcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0pXG5cbiAgICB0aGlzLmFkZENvbW1hbmQoe1xuICAgICAgaWQ6IFwiZ2VuZXJhdGUtZHVlLWRhdGVzLXN1bW1hcnlcIixcbiAgICAgIG5hbWU6IFwiR2VuZXJhdGUgRHVlIERhdGVzIFN1bW1hcnlcIixcbiAgICAgIGNhbGxiYWNrOiBhc3luYyAoKSA9PiB7XG4gICAgICAgIGNvbnN0IGNvdXJzZUlkID0gYXdhaXQgdGhpcy5wcm9tcHRGb3JDb3Vyc2VJZChcbiAgICAgICAgICBcIkVudGVyIGNvdXJzZSBJRCB0byBnZW5lcmF0ZSBkdWUgZGF0ZXMgc3VtbWFyeSBmb3JcIlxuICAgICAgICApXG4gICAgICAgIGlmIChjb3Vyc2VJZCkge1xuICAgICAgICAgIGF3YWl0IHRoaXMuZHVlRGF0ZXNQYXJzZXIuY3JlYXRlRHVlRGF0ZXNTdW1tYXJ5RmlsZShjb3Vyc2VJZClcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0pXG5cbiAgICB0aGlzLmFkZENvbW1hbmQoe1xuICAgICAgaWQ6IFwiZ2VuZXJhdGUtZGFpbHktc3VtbWFyeVwiLFxuICAgICAgbmFtZTogXCJHZW5lcmF0ZSBEYWlseSBBY2FkZW1pYyBTdW1tYXJ5XCIsXG4gICAgICBjYWxsYmFjazogYXN5bmMgKCkgPT4ge1xuICAgICAgICBjb25zdCBkYXRlID0gYXdhaXQgdGhpcy5wcm9tcHRGb3JEYXRlKFxuICAgICAgICAgIFwiRW50ZXIgZGF0ZSAoWVlZWS1NTS1ERCkgb3IgbGVhdmUgZW1wdHkgZm9yIHRvZGF5XCJcbiAgICAgICAgKVxuICAgICAgICBhd2FpdCB0aGlzLmRhaWx5Tm90ZXNJbnRlZ3JhdGlvbi5jcmVhdGVEYWlseVN1bW1hcnlGaWxlKFxuICAgICAgICAgIGRhdGUgfHwgdW5kZWZpbmVkXG4gICAgICAgIClcbiAgICAgIH1cbiAgICB9KVxuXG4gICAgLy8gQWRkIHN0YXR1cyBiYXIgaXRlbVxuICAgIHRoaXMuYWRkU3RhdHVzQmFySXRlbSgpLnNldFRleHQoXCJUdWNrZXJzIFRvb2xzXCIpXG4gIH1cblxuICBwcml2YXRlIGFzeW5jIHByb21wdEZvckNvdXJzZUlkKG1lc3NhZ2U6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nIHwgbnVsbD4ge1xuICAgIGNvbnN0IGNvdXJzZUlkID0gcHJvbXB0KG1lc3NhZ2UgKyBcIlxcblxcbkV4YW1wbGU6IFBTSS0xMDFcIilcbiAgICByZXR1cm4gY291cnNlSWQgPyBjb3Vyc2VJZC50cmltKCkgOiBudWxsXG4gIH1cblxuICBwcml2YXRlIGFzeW5jIHByb21wdEZvckRhdGUobWVzc2FnZTogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmcgfCBudWxsPiB7XG4gICAgY29uc3QgZGF0ZSA9IHByb21wdChcbiAgICAgIG1lc3NhZ2UgKyBcIlxcblxcbkV4YW1wbGU6IDIwMjUtMDEtMTUgb3IgbGVhdmUgZW1wdHkgZm9yIHRvZGF5XCJcbiAgICApXG4gICAgcmV0dXJuIGRhdGUgPyBkYXRlLnRyaW0oKSA6IG51bGxcbiAgfVxuXG4gIGdlbmVyYXRlQXNzaWdubWVudEZpbGVDb250ZW50KGFzc2lnbm1lbnQ6IGFueSwgY291cnNlTmFtZTogc3RyaW5nLCBjb3Vyc2VJZDogc3RyaW5nKTogc3RyaW5nIHtcbiAgICAvLyBDcmVhdGUgdGhlIGFzc2lnbm1lbnQgZmlsZSBjb250ZW50IHVzaW5nIHRoZSBhc3NpZ25tZW50IHRlbXBsYXRlIHN0cnVjdHVyZVxuICAgIHJldHVybiBgLS0tXG5jb3Vyc2VfaWQ6ICR7Y291cnNlSWR9XG5hc3NpZ25tZW50X3R5cGU6ICR7YXNzaWdubWVudC50eXBlIHx8IFwiQXNzaWdubWVudFwifVxuZHVlX2RhdGU6ICR7YXNzaWdubWVudC5kdWVEYXRlfVxucG9pbnRzOiAke2Fzc2lnbm1lbnQucG9pbnRzIHx8IFwiXCJ9XG5jb250ZW50X3R5cGU6IGFzc2lnbm1lbnRcbmNyZWF0ZWQ6ICR7bmV3IERhdGUoKS50b0lTT1N0cmluZygpfVxuc3RhdHVzOiBwZW5kaW5nXG50YWdzOlxuICAtIGVkdWNhdGlvblxuICAtICR7Y291cnNlSWR9XG4gIC0gYXNzaWdubWVudFxuLS0tXG5cbiMgJHthc3NpZ25tZW50Lm5hbWV9IC0gJHtjb3Vyc2VJZH1cblxuIyMgRGVzY3JpcHRpb25cbiR7YXNzaWdubWVudC5kZXNjcmlwdGlvbn1cblxuIyMgSW5zdHJ1Y3Rpb25zXG5cblxuIyMgRHVlIERhdGVcbioqQXNzaWduZWQqKjogJHtuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc3BsaXQoJ1QnKVswXX1cbioqRHVlKio6ICR7YXNzaWdubWVudC5kdWVEYXRlfVxuXG4jIyBTdWJtaXNzaW9uXG5cblxuIyMgR3JhZGluZyBDcml0ZXJpYVxuXG5cbiMjIFJlc291cmNlc1xuXG5cbiMgRHVlIERhdGVzXG58ICR7YXNzaWdubWVudC5kdWVEYXRlfSB8ICR7YXNzaWdubWVudC5uYW1lfSB8IHBlbmRpbmcgfFxuYDtcbiAgfVxuXG4gIG9udW5sb2FkKCkge1xuICAgIGNvbnNvbGUubG9nKFwiVW5sb2FkaW5nIFR1Y2tlcnMgVG9vbHMgcGx1Z2luXCIpXG4gIH1cblxuICBhc3luYyBpbml0aWFsaXplVGVtcGxhdGVyRnVuY3Rpb25zKCkge1xuICAgIC8vIENoZWNrIGlmIFRlbXBsYXRlciBwbHVnaW4gaXMgYXZhaWxhYmxlXG4gICAgY29uc3QgdGVtcGxhdGVyUGx1Z2luID0gKHRoaXMuYXBwIGFzIGFueSkucGx1Z2lucy5nZXRQbHVnaW4oXCJ0ZW1wbGF0ZXItb2JzaWRpYW5cIik7XG4gICAgaWYgKCF0ZW1wbGF0ZXJQbHVnaW4pIHtcbiAgICAgIGNvbnNvbGUubG9nKFwiVGVtcGxhdGVyIHBsdWdpbiBub3QgZm91bmQuIENvdXJzZSB0ZW1wbGF0ZXMgd2lsbCBub3Qgd29yayBwcm9wZXJseS5cIik7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgLy8gUmVnaXN0ZXIgdXNlciBmdW5jdGlvbnMgd2l0aCBUZW1wbGF0ZXJcbiAgICB0cnkge1xuICAgICAgLy8gVHJ5IHRvIGFkZCBmdW5jdGlvbnMgdmlhIGRpZmZlcmVudCBtZXRob2RzIGRlcGVuZGluZyBvbiB0aGUgVGVtcGxhdGVyIHZlcnNpb25cbiAgICAgIGlmICh0ZW1wbGF0ZXJQbHVnaW4gJiYgdGVtcGxhdGVyUGx1Z2luLnRlbXBsYXRlcikge1xuICAgICAgICAvLyBDcmVhdGUgYSB1c2VyIGZ1bmN0aW9uIG1hbmFnZXIgb2JqZWN0IGlmIGl0IGRvZXNuJ3QgZXhpc3RcbiAgICAgICAgaWYgKCF0ZW1wbGF0ZXJQbHVnaW4udGVtcGxhdGVyLmZ1bmN0aW9ucykge1xuICAgICAgICAgIHRlbXBsYXRlclBsdWdpbi50ZW1wbGF0ZXIuZnVuY3Rpb25zID0ge307XG4gICAgICAgIH1cblxuICAgICAgICAvLyBBZGQgb3VyIGN1c3RvbSBmdW5jdGlvbnMgdG8gYm90aCB0aGUgdGVtcGxhdGVyIGZ1bmN0aW9ucyBvYmplY3QgYW5kIHRwLnVzZXIgbmFtZXNwYWNlXG4gICAgICAgIHRlbXBsYXRlclBsdWdpbi50ZW1wbGF0ZXIuZnVuY3Rpb25zW1wibmV3X21vZHVsZVwiXSA9IGFzeW5jIChhcHA6IGFueSwgdHA6IGFueSwgeWVhcjogYW55KSA9PiB7XG4gICAgICAgICAgcmV0dXJuIHRoaXMubmV3TW9kdWxlRnVuY3Rpb24oYXBwLCB0cCwgeWVhcik7XG4gICAgICAgIH07XG4gICAgICAgIFxuICAgICAgICAvLyBBbHNvIGFkZCB0byB0cC51c2VyIG5hbWVzcGFjZSBmb3IgZGlyZWN0IGFjY2Vzc1xuICAgICAgICBpZiAoIXRlbXBsYXRlclBsdWdpbi50ZW1wbGF0ZXIuZnVuY3Rpb25zLnVzZXIpIHtcbiAgICAgICAgICB0ZW1wbGF0ZXJQbHVnaW4udGVtcGxhdGVyLmZ1bmN0aW9ucy51c2VyID0ge307XG4gICAgICAgIH1cbiAgICAgICAgdGVtcGxhdGVyUGx1Z2luLnRlbXBsYXRlci5mdW5jdGlvbnMudXNlcltcIm5ld19tb2R1bGVcIl0gPSBhc3luYyAoYXBwOiBhbnksIHRwOiBhbnksIHllYXI6IGFueSkgPT4ge1xuICAgICAgICAgIHJldHVybiB0aGlzLm5ld01vZHVsZUZ1bmN0aW9uKGFwcCwgdHAsIHllYXIpO1xuICAgICAgICB9O1xuXG4gICAgICAgIHRlbXBsYXRlclBsdWdpbi50ZW1wbGF0ZXIuZnVuY3Rpb25zW1wibmV3X2NoYXB0ZXJcIl0gPSBhc3luYyAodHA6IGFueSkgPT4ge1xuICAgICAgICAgIHJldHVybiB0aGlzLm5ld0NoYXB0ZXJGdW5jdGlvbih0cCk7XG4gICAgICAgIH07XG4gICAgICAgIFxuICAgICAgICAvLyBBbHNvIGFkZCBuZXdfY2hhcHRlciB0byB0cC51c2VyIG5hbWVzcGFjZVxuICAgICAgICB0ZW1wbGF0ZXJQbHVnaW4udGVtcGxhdGVyLmZ1bmN0aW9ucy51c2VyW1wibmV3X2NoYXB0ZXJcIl0gPSBhc3luYyAodHA6IGFueSkgPT4ge1xuICAgICAgICAgIHJldHVybiB0aGlzLm5ld0NoYXB0ZXJGdW5jdGlvbih0cCk7XG4gICAgICAgIH07XG5cbiAgICAgICAgY29uc29sZS5sb2coXCJUdWNrZXJzIFRvb2xzIHRlbXBsYXRlciBmdW5jdGlvbnMgcmVnaXN0ZXJlZCBzdWNjZXNzZnVsbHlcIik7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjb25zb2xlLmVycm9yKFwiQ291bGQgbm90IHJlZ2lzdGVyIHRlbXBsYXRlciBmdW5jdGlvbnMgLSB0ZW1wbGF0ZXIgb2JqZWN0IG5vdCBmb3VuZFwiKTtcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgcmVnaXN0ZXJpbmcgdGVtcGxhdGVyIGZ1bmN0aW9uczpcIiwgZSk7XG4gICAgfVxuICB9XG5cbiAgYXN5bmMgbmV3TW9kdWxlRnVuY3Rpb24oYXBwOiBhbnksIHRwOiBhbnksIHllYXI6IHN0cmluZykge1xuICAgIC8vIFByb21wdCB1c2VyIGZvciBtb2R1bGUgZGV0YWlsc1xuICAgIGxldCBtb2R1bGVOdW1iZXI6IHN0cmluZyB8IG51bGwgPSBcIlwiO1xuICAgIGxldCB3ZWVrTnVtYmVyOiBzdHJpbmcgfCBudWxsID0gXCJcIjtcbiAgICBsZXQgY291cnNlID0gXCJcIjtcbiAgICBsZXQgY291cnNlSWQgPSBcIlwiO1xuICAgIGxldCBkaXNjaXBsaW5lID0gXCJHRU5cIjtcbiAgICBsZXQgZGF5T2ZXZWVrID0gXCJcIjtcblxuICAgIHRyeSB7XG4gICAgICAvLyBBdHRlbXB0IHByb21wdHMgd2l0aCBmYWxsYmFja1xuICAgICAgaWYgKHRwICYmIHRwLnN5c3RlbSAmJiB0cC5zeXN0ZW0ucHJvbXB0KSB7XG4gICAgICAgIGNvbnN0IHRlbXBNb2R1bGVOdW1iZXIgPSBhd2FpdCB0cC5zeXN0ZW0ucHJvbXB0KFwiTW9kdWxlIE51bWJlciAob3B0aW9uYWwpXCIsIFwiXCIpO1xuICAgICAgICBtb2R1bGVOdW1iZXIgPSB0ZW1wTW9kdWxlTnVtYmVyID8gdGVtcE1vZHVsZU51bWJlciA6IG51bGw7XG4gICAgICAgIFxuICAgICAgICBjb25zdCB0ZW1wV2Vla051bWJlciA9IGF3YWl0IHRwLnN5c3RlbS5wcm9tcHQoXCJXZWVrIE51bWJlciAob3B0aW9uYWwpXCIsIFwiXCIpO1xuICAgICAgICB3ZWVrTnVtYmVyID0gdGVtcFdlZWtOdW1iZXIgPyB0ZW1wV2Vla051bWJlciA6IG51bGw7XG4gICAgICAgIFxuICAgICAgICAvLyBMb29rIGZvciBmaWxlcyB3aXRoIGNvdXJzZV9ob21lIHRhZyBvciBjb250ZW50VHlwZTogQ291cnNlIGluc3RlYWQgb2YgaGFyZGNvZGVkIHBhdGhcbiAgICAgICAgY29uc3QgY291cnNlRmlsZXMgPSBhcHAudmF1bHQuZ2V0TWFya2Rvd25GaWxlcygpLmZpbHRlcigoZjogYW55KSA9PiB7XG4gICAgICAgICAgY29uc3QgY2FjaGUgPSBhcHAubWV0YWRhdGFDYWNoZS5nZXRGaWxlQ2FjaGUoZik7XG4gICAgICAgICAgcmV0dXJuIGNhY2hlICYmIChcbiAgICAgICAgICAgIChjYWNoZS50YWdzICYmIGNhY2hlLnRhZ3Muc29tZSgodGFnOiBhbnkpID0+IHRhZy50YWcgPT09IFwiI2NvdXJzZV9ob21lXCIpKSB8fFxuICAgICAgICAgICAgKGNhY2hlLmZyb250bWF0dGVyICYmIGNhY2hlLmZyb250bWF0dGVyLmNvbnRlbnRUeXBlID09PSBcIkNvdXJzZVwiKSB8fFxuICAgICAgICAgICAgKGNhY2hlLmZyb250bWF0dGVyICYmIGNhY2hlLmZyb250bWF0dGVyLnRhZ3MgJiYgXG4gICAgICAgICAgICAgKEFycmF5LmlzQXJyYXkoY2FjaGUuZnJvbnRtYXR0ZXIudGFncykgXG4gICAgICAgICAgICAgICA/IGNhY2hlLmZyb250bWF0dGVyLnRhZ3MuaW5jbHVkZXMoXCJjb3Vyc2VfaG9tZVwiKVxuICAgICAgICAgICAgICAgOiBjYWNoZS5mcm9udG1hdHRlci50YWdzID09PSBcImNvdXJzZV9ob21lXCIpKVxuICAgICAgICAgICk7XG4gICAgICAgIH0pO1xuICAgICAgICBcbiAgICAgICAgY291cnNlID0gYXdhaXQgdHAuc3lzdGVtLnN1Z2dlc3RlcihcbiAgICAgICAgICAoKSA9PiBjb3Vyc2VGaWxlcy5tYXAoKGY6IGFueSkgPT4gZi5iYXNlbmFtZSksXG4gICAgICAgICAgY291cnNlRmlsZXNcbiAgICAgICAgKTtcbiAgICAgICAgXG4gICAgICAgIGRheU9mV2VlayA9IGF3YWl0IHRwLnN5c3RlbS5zdWdnZXN0ZXIoXG4gICAgICAgICAgW1wiTW9uZGF5XCIsIFwiVHVlc2RheVwiLCBcIldlZG5lc2RheVwiLCBcIlRodXJzZGF5XCIsIFwiRnJpZGF5XCIsIFwiU2F0dXJkYXlcIiwgXCJTdW5kYXlcIl0sXG4gICAgICAgICAgW1wiTW9uZGF5XCIsIFwiVHVlc2RheVwiLCBcIldlZG5lc2RheVwiLCBcIlRodXJzZGF5XCIsIFwiRnJpZGF5XCIsIFwiU2F0dXJkYXlcIiwgXCJTdW5kYXlcIl0sXG4gICAgICAgICAgXCJEYXkgb2YgV2Vla1wiXG4gICAgICAgICk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICAvLyBGYWxsYmFjayB2YWx1ZXNcbiAgICAgICAgbW9kdWxlTnVtYmVyID0gbnVsbDtcbiAgICAgICAgd2Vla051bWJlciA9IG51bGw7XG4gICAgICAgIGNvdXJzZSA9IFwiTmV3IENvdXJzZVwiO1xuICAgICAgICBkYXlPZldlZWsgPSBcIk1vbmRheVwiO1xuICAgICAgfVxuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBpbiBuZXdfbW9kdWxlIHByb21wdHM6XCIsIGUpO1xuICAgICAgLy8gRGVmYXVsdCB2YWx1ZXMgb24gZXJyb3JcbiAgICAgIG1vZHVsZU51bWJlciA9IG51bGw7XG4gICAgICB3ZWVrTnVtYmVyID0gbnVsbDtcbiAgICAgIGNvdXJzZSA9IFwiTmV3IENvdXJzZVwiO1xuICAgICAgZGF5T2ZXZWVrID0gXCJNb25kYXlcIjtcbiAgICB9XG5cbiAgICAvLyBDYWxjdWxhdGUgZGVyaXZlZCB2YWx1ZXNcbiAgICBjb3Vyc2VJZCA9IGNvdXJzZSA/IGNvdXJzZS5zcGxpdChcIiAtIFwiKVswXSB8fCBjb3Vyc2UgOiBcIlwiO1xuICAgIGRpc2NpcGxpbmUgPSBjb3Vyc2UgPyAoY291cnNlLnNwbGl0KFwiIC0gXCIpWzBdPy5zdWJzdHJpbmcoMCwgMykgfHwgXCJHRU5cIikgOiBcIkdFTlwiO1xuXG4gICAgcmV0dXJuIHtcbiAgICAgIHNlYXNvbjogXCJGYWxsXCIsIC8vIFRoaXMgd291bGQgbm9ybWFsbHkgYmUgZHluYW1pY2FsbHkgZGV0ZXJtaW5lZFxuICAgICAgbW9kdWxlTnVtYmVyOiBtb2R1bGVOdW1iZXIsXG4gICAgICB3ZWVrTnVtYmVyOiB3ZWVrTnVtYmVyLFxuICAgICAgY291cnNlLFxuICAgICAgY291cnNlSWQsXG4gICAgICBkaXNjaXBsaW5lLFxuICAgICAgZGF5T2ZXZWVrXG4gICAgfTtcbiAgfVxuXG4gIGFzeW5jIG5ld0NoYXB0ZXJGdW5jdGlvbih0cDogYW55KSB7XG4gICAgbGV0IGNoYXB0ZXJOdW1iZXIgPSBcIlwiO1xuICAgIGxldCBjb3Vyc2UgPSBcIlwiO1xuICAgIGxldCBjb3Vyc2VJZCA9IFwiXCI7XG4gICAgbGV0IGRpc2NpcGxpbmUgPSBcIkdFTlwiO1xuICAgIGxldCB0ZXh0ID0gXCJcIjtcblxuICAgIHRyeSB7XG4gICAgICBpZiAodHAgJiYgdHAuc3lzdGVtICYmIHRwLnN5c3RlbS5wcm9tcHQpIHtcbiAgICAgICAgY2hhcHRlck51bWJlciA9IGF3YWl0IHRwLnN5c3RlbS5wcm9tcHQoXCJDaGFwdGVyIE51bWJlclwiLCBcIlwiKSB8fCBcIlwiO1xuICAgICAgICAvLyBMb29rIGZvciBmaWxlcyB3aXRoIGNvdXJzZV9ob21lIHRhZyBvciBjb250ZW50VHlwZTogQ291cnNlIGluc3RlYWQgb2YgaGFyZGNvZGVkIHBhdGhcbiAgICAgICAgY29uc3QgY291cnNlRmlsZXMgPSB0cC5hcHAudmF1bHQuZ2V0TWFya2Rvd25GaWxlcygpLmZpbHRlcigoZjogYW55KSA9PiB7XG4gICAgICAgICAgY29uc3QgY2FjaGUgPSB0cC5hcHAubWV0YWRhdGFDYWNoZS5nZXRGaWxlQ2FjaGUoZik7XG4gICAgICAgICAgcmV0dXJuIGNhY2hlICYmIChcbiAgICAgICAgICAgIChjYWNoZS50YWdzICYmIGNhY2hlLnRhZ3Muc29tZSgodGFnOiBhbnkpID0+IHRhZy50YWcgPT09IFwiI2NvdXJzZV9ob21lXCIpKSB8fFxuICAgICAgICAgICAgKGNhY2hlLmZyb250bWF0dGVyICYmIGNhY2hlLmZyb250bWF0dGVyLmNvbnRlbnRUeXBlID09PSBcIkNvdXJzZVwiKSB8fFxuICAgICAgICAgICAgKGNhY2hlLmZyb250bWF0dGVyICYmIGNhY2hlLmZyb250bWF0dGVyLnRhZ3MgJiYgXG4gICAgICAgICAgICAgKEFycmF5LmlzQXJyYXkoY2FjaGUuZnJvbnRtYXR0ZXIudGFncykgXG4gICAgICAgICAgICAgICA/IGNhY2hlLmZyb250bWF0dGVyLnRhZ3MuaW5jbHVkZXMoXCJjb3Vyc2VfaG9tZVwiKVxuICAgICAgICAgICAgICAgOiBjYWNoZS5mcm9udG1hdHRlci50YWdzID09PSBcImNvdXJzZV9ob21lXCIpKVxuICAgICAgICAgICk7XG4gICAgICAgIH0pO1xuICAgICAgICBcbiAgICAgICAgY291cnNlID0gYXdhaXQgdHAuc3lzdGVtLnN1Z2dlc3RlcihcbiAgICAgICAgICAoKSA9PiBjb3Vyc2VGaWxlcy5tYXAoKGY6IGFueSkgPT4gZi5iYXNlbmFtZSksXG4gICAgICAgICAgY291cnNlRmlsZXNcbiAgICAgICAgKTtcbiAgICAgICAgY29uc3QgdGV4dE9wdGlvbnMgPSB0cC5hcHAudmF1bHQuZ2V0RmlsZXMoKS5maWx0ZXIoKGY6IGFueSkgPT4gZi5leHRlbnNpb24gPT09IFwicGRmXCIpLm1hcCgoZjogYW55KSA9PiBmLmJhc2VuYW1lKTtcbiAgICAgICAgdGV4dCA9IGF3YWl0IHRwLnN5c3RlbS5zdWdnZXN0ZXIodGV4dE9wdGlvbnMsIHRleHRPcHRpb25zLCBcIlRleHRib29rXCIpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgLy8gRmFsbGJhY2sgdmFsdWVzXG4gICAgICAgIGNoYXB0ZXJOdW1iZXIgPSBcIlwiO1xuICAgICAgICBjb3Vyc2UgPSBcIk5ldyBDb3Vyc2VcIjtcbiAgICAgICAgdGV4dCA9IFwiTmV3IFRleHRib29rXCI7XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGluIG5ld19jaGFwdGVyIHByb21wdHM6XCIsIGUpO1xuICAgICAgLy8gRGVmYXVsdCB2YWx1ZXMgb24gZXJyb3JcbiAgICAgIGNoYXB0ZXJOdW1iZXIgPSBcIlwiO1xuICAgICAgY291cnNlID0gXCJOZXcgQ291cnNlXCI7XG4gICAgICB0ZXh0ID0gXCJOZXcgVGV4dGJvb2tcIjtcbiAgICB9XG5cbiAgICAvLyBDYWxjdWxhdGUgZGVyaXZlZCB2YWx1ZXNcbiAgICBjb3Vyc2VJZCA9IGNvdXJzZSA/IGNvdXJzZS5zcGxpdChcIiAtIFwiKVswXSB8fCBjb3Vyc2UgOiBcIlwiO1xuICAgIGRpc2NpcGxpbmUgPSBjb3Vyc2UgPyAoY291cnNlLnNwbGl0KFwiIC0gXCIpWzBdPy5zdWJzdHJpbmcoMCwgMykgfHwgXCJHRU5cIikgOiBcIkdFTlwiO1xuXG4gICAgcmV0dXJuIHtcbiAgICAgIGNoYXB0ZXJOdW1iZXIsXG4gICAgICBjb3Vyc2UsXG4gICAgICBjb3Vyc2VJZCxcbiAgICAgIGRpc2NpcGxpbmUsXG4gICAgICB0ZXh0XG4gICAgfTtcbiAgfVxuXG4gIGFzeW5jIGxvYWRTZXR0aW5ncygpIHtcbiAgICB0aGlzLnNldHRpbmdzID0gT2JqZWN0LmFzc2lnbih7fSwgREVGQVVMVF9TRVRUSU5HUywgYXdhaXQgdGhpcy5sb2FkRGF0YSgpKVxuICB9XG5cbiAgYXN5bmMgc2F2ZVNldHRpbmdzKCkge1xuICAgIGF3YWl0IHRoaXMuc2F2ZURhdGEodGhpcy5zZXR0aW5ncylcbiAgfVxufVxuIiwgImltcG9ydCB7IEFwcCwgUGx1Z2luU2V0dGluZ1RhYiwgU2V0dGluZyB9IGZyb20gJ29ic2lkaWFuJztcbmltcG9ydCBUdWNrZXJzVG9vbHNQbHVnaW4gZnJvbSAnLi9tYWluJztcbmltcG9ydCB7IHZhbGlkYXRlRGF0ZSB9IGZyb20gJy4vdXRpbHMnO1xuXG5leHBvcnQgaW50ZXJmYWNlIFR1Y2tlcnNUb29sc1NldHRpbmdzIHtcbiAgYmFzZURpcmVjdG9yeTogc3RyaW5nO1xuICBzZW1lc3RlclN0YXJ0RGF0ZTogc3RyaW5nO1xuICBzZW1lc3RlckVuZERhdGU6IHN0cmluZztcbiAgc2Nob29sTmFtZTogc3RyaW5nO1xuICBzY2hvb2xBYmJyZXZpYXRpb246IHN0cmluZztcbiAgdGVtcGxhdGVGb2xkZXI6IHN0cmluZztcbiAgdXNlRW5oYW5jZWRNZXRhZGF0YTogYm9vbGVhbjtcbiAgZGF0YXZpZXdKc1BhdGg6IHN0cmluZztcbn1cblxuZXhwb3J0IGNvbnN0IERFRkFVTFRfU0VUVElOR1M6IFR1Y2tlcnNUb29sc1NldHRpbmdzID0ge1xuICBiYXNlRGlyZWN0b3J5OiAnLycsXG4gIHNlbWVzdGVyU3RhcnREYXRlOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc3BsaXQoJ1QnKVswXSxcbiAgc2VtZXN0ZXJFbmREYXRlOiBuZXcgRGF0ZShuZXcgRGF0ZSgpLnNldE1vbnRoKG5ldyBEYXRlKCkuZ2V0TW9udGgoKSArIDQpKS50b0lTT1N0cmluZygpLnNwbGl0KCdUJylbMF0sXG4gIHNjaG9vbE5hbWU6ICdVbml2ZXJzaXR5JyxcbiAgc2Nob29sQWJicmV2aWF0aW9uOiAnVScsXG4gIHRlbXBsYXRlRm9sZGVyOiAnVHVja2VycyBUb29scycsXG4gIHVzZUVuaGFuY2VkTWV0YWRhdGE6IGZhbHNlLFxuICBkYXRhdmlld0pzUGF0aDogJy9TdXBwb3J0aW5nL2RhdGF2aWV3LWZ1bmN0aW9ucydcbn1cblxuZXhwb3J0IGNsYXNzIFR1Y2tlcnNUb29sc1NldHRpbmdUYWIgZXh0ZW5kcyBQbHVnaW5TZXR0aW5nVGFiIHtcbiAgcGx1Z2luOiBUdWNrZXJzVG9vbHNQbHVnaW47XG5cbiAgY29uc3RydWN0b3IoYXBwOiBBcHAsIHBsdWdpbjogVHVja2Vyc1Rvb2xzUGx1Z2luKSB7XG4gICAgc3VwZXIoYXBwLCBwbHVnaW4pO1xuICAgIHRoaXMucGx1Z2luID0gcGx1Z2luO1xuICB9XG5cbiAgZGlzcGxheSgpOiB2b2lkIHtcbiAgICBjb25zdCB7IGNvbnRhaW5lckVsIH0gPSB0aGlzO1xuXG4gICAgY29udGFpbmVyRWwuZW1wdHkoKTtcblxuICAgIGNvbnRhaW5lckVsLmNyZWF0ZUVsKCdoMicsIHsgdGV4dDogJ1R1Y2tlcnMgVG9vbHMgU2V0dGluZ3MnIH0pO1xuXG4gICAgbmV3IFNldHRpbmcoY29udGFpbmVyRWwpXG4gICAgICAuc2V0TmFtZSgnQmFzZSBEaXJlY3RvcnknKVxuICAgICAgLnNldERlc2MoJ1Jvb3QgZGlyZWN0b3J5IGZvciBjb3Vyc2UgY29udGVudCBvcmdhbml6YXRpb24nKVxuICAgICAgLmFkZFRleHQodGV4dCA9PiB0ZXh0XG4gICAgICAgIC5zZXRQbGFjZWhvbGRlcignLycpXG4gICAgICAgIC5zZXRWYWx1ZSh0aGlzLnBsdWdpbi5zZXR0aW5ncy5iYXNlRGlyZWN0b3J5KVxuICAgICAgICAub25DaGFuZ2UoYXN5bmMgKHZhbHVlKSA9PiB7XG4gICAgICAgICAgdGhpcy5wbHVnaW4uc2V0dGluZ3MuYmFzZURpcmVjdG9yeSA9IHZhbHVlO1xuICAgICAgICAgIGF3YWl0IHRoaXMucGx1Z2luLnNhdmVTZXR0aW5ncygpO1xuICAgICAgICB9KSk7XG5cbiAgICBjb25zdCBzdGFydERhdGVTZXR0aW5nID0gbmV3IFNldHRpbmcoY29udGFpbmVyRWwpXG4gICAgICAuc2V0TmFtZSgnU2VtZXN0ZXIgU3RhcnQgRGF0ZScpXG4gICAgICAuc2V0RGVzYygnU3RhcnQgZGF0ZSBmb3IgdGhlIGN1cnJlbnQgc2VtZXN0ZXInKVxuICAgICAgLmFkZFRleHQodGV4dCA9PiB0ZXh0XG4gICAgICAgIC5zZXRQbGFjZWhvbGRlcignWVlZWS1NTS1ERCcpXG4gICAgICAgIC5zZXRWYWx1ZSh0aGlzLnBsdWdpbi5zZXR0aW5ncy5zZW1lc3RlclN0YXJ0RGF0ZSlcbiAgICAgICAgLm9uQ2hhbmdlKGFzeW5jICh2YWx1ZSkgPT4ge1xuICAgICAgICAgIGlmICh2YWx1ZSAmJiAhdmFsaWRhdGVEYXRlKHZhbHVlKSkge1xuICAgICAgICAgICAgc3RhcnREYXRlU2V0dGluZy5zZXREZXNjKCdTdGFydCBkYXRlIGZvciB0aGUgY3VycmVudCBzZW1lc3RlciAoSW52YWxpZCBkYXRlIGZvcm1hdCknKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgc3RhcnREYXRlU2V0dGluZy5zZXREZXNjKCdTdGFydCBkYXRlIGZvciB0aGUgY3VycmVudCBzZW1lc3RlcicpO1xuICAgICAgICAgIH1cbiAgICAgICAgICB0aGlzLnBsdWdpbi5zZXR0aW5ncy5zZW1lc3RlclN0YXJ0RGF0ZSA9IHZhbHVlO1xuICAgICAgICAgIGF3YWl0IHRoaXMucGx1Z2luLnNhdmVTZXR0aW5ncygpO1xuICAgICAgICB9KSk7XG5cbiAgICBjb25zdCBlbmREYXRlU2V0dGluZyA9IG5ldyBTZXR0aW5nKGNvbnRhaW5lckVsKVxuICAgICAgLnNldE5hbWUoJ1NlbWVzdGVyIEVuZCBEYXRlJylcbiAgICAgIC5zZXREZXNjKCdFbmQgZGF0ZSBmb3IgdGhlIGN1cnJlbnQgc2VtZXN0ZXInKVxuICAgICAgLmFkZFRleHQodGV4dCA9PiB0ZXh0XG4gICAgICAgIC5zZXRQbGFjZWhvbGRlcignWVlZWS1NTS1ERCcpXG4gICAgICAgIC5zZXRWYWx1ZSh0aGlzLnBsdWdpbi5zZXR0aW5ncy5zZW1lc3RlckVuZERhdGUpXG4gICAgICAgIC5vbkNoYW5nZShhc3luYyAodmFsdWUpID0+IHtcbiAgICAgICAgICBpZiAodmFsdWUgJiYgIXZhbGlkYXRlRGF0ZSh2YWx1ZSkpIHtcbiAgICAgICAgICAgIGVuZERhdGVTZXR0aW5nLnNldERlc2MoJ0VuZCBkYXRlIGZvciB0aGUgY3VycmVudCBzZW1lc3RlciAoSW52YWxpZCBkYXRlIGZvcm1hdCknKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgZW5kRGF0ZVNldHRpbmcuc2V0RGVzYygnRW5kIGRhdGUgZm9yIHRoZSBjdXJyZW50IHNlbWVzdGVyJyk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHRoaXMucGx1Z2luLnNldHRpbmdzLnNlbWVzdGVyRW5kRGF0ZSA9IHZhbHVlO1xuICAgICAgICAgIGF3YWl0IHRoaXMucGx1Z2luLnNhdmVTZXR0aW5ncygpO1xuICAgICAgICB9KSk7XG5cbiAgICBuZXcgU2V0dGluZyhjb250YWluZXJFbClcbiAgICAgIC5zZXROYW1lKCdTY2hvb2wgTmFtZScpXG4gICAgICAuc2V0RGVzYygnTmFtZSBvZiB5b3VyIGluc3RpdHV0aW9uJylcbiAgICAgIC5hZGRUZXh0KHRleHQgPT4gdGV4dFxuICAgICAgICAuc2V0UGxhY2Vob2xkZXIoJ1VuaXZlcnNpdHknKVxuICAgICAgICAuc2V0VmFsdWUodGhpcy5wbHVnaW4uc2V0dGluZ3Muc2Nob29sTmFtZSlcbiAgICAgICAgLm9uQ2hhbmdlKGFzeW5jICh2YWx1ZSkgPT4ge1xuICAgICAgICAgIHRoaXMucGx1Z2luLnNldHRpbmdzLnNjaG9vbE5hbWUgPSB2YWx1ZTtcbiAgICAgICAgICBhd2FpdCB0aGlzLnBsdWdpbi5zYXZlU2V0dGluZ3MoKTtcbiAgICAgICAgfSkpO1xuXG4gICAgbmV3IFNldHRpbmcoY29udGFpbmVyRWwpXG4gICAgICAuc2V0TmFtZSgnU2Nob29sIEFiYnJldmlhdGlvbicpXG4gICAgICAuc2V0RGVzYygnQWJicmV2aWF0aW9uIGZvciB5b3VyIGluc3RpdHV0aW9uJylcbiAgICAgIC5hZGRUZXh0KHRleHQgPT4gdGV4dFxuICAgICAgICAuc2V0UGxhY2Vob2xkZXIoJ1UnKVxuICAgICAgICAuc2V0VmFsdWUodGhpcy5wbHVnaW4uc2V0dGluZ3Muc2Nob29sQWJicmV2aWF0aW9uKVxuICAgICAgICAub25DaGFuZ2UoYXN5bmMgKHZhbHVlKSA9PiB7XG4gICAgICAgICAgdGhpcy5wbHVnaW4uc2V0dGluZ3Muc2Nob29sQWJicmV2aWF0aW9uID0gdmFsdWU7XG4gICAgICAgICAgYXdhaXQgdGhpcy5wbHVnaW4uc2F2ZVNldHRpbmdzKCk7XG4gICAgICAgIH0pKTtcblxuICAgIG5ldyBTZXR0aW5nKGNvbnRhaW5lckVsKVxuICAgICAgLnNldE5hbWUoJ1RlbXBsYXRlIEZvbGRlcicpXG4gICAgICAuc2V0RGVzYygnU3ViZm9sZGVyIHdpdGhpbiB5b3VyIFRlbXBsYXRlciB0ZW1wbGF0ZSBmb2xkZXIgZm9yIFR1Y2tlcnMgVG9vbHMgdGVtcGxhdGVzJylcbiAgICAgIC5hZGRUZXh0KHRleHQgPT4gdGV4dFxuICAgICAgICAuc2V0UGxhY2Vob2xkZXIoJ1R1Y2tlcnMgVG9vbHMnKVxuICAgICAgICAuc2V0VmFsdWUodGhpcy5wbHVnaW4uc2V0dGluZ3MudGVtcGxhdGVGb2xkZXIpXG4gICAgICAgIC5vbkNoYW5nZShhc3luYyAodmFsdWUpID0+IHtcbiAgICAgICAgICB0aGlzLnBsdWdpbi5zZXR0aW5ncy50ZW1wbGF0ZUZvbGRlciA9IHZhbHVlO1xuICAgICAgICAgIGF3YWl0IHRoaXMucGx1Z2luLnNhdmVTZXR0aW5ncygpO1xuICAgICAgICB9KSk7XG5cbiAgICBuZXcgU2V0dGluZyhjb250YWluZXJFbClcbiAgICAgIC5zZXROYW1lKCdVc2UgRW5oYW5jZWQgTWV0YWRhdGEnKVxuICAgICAgLnNldERlc2MoJ0VuYWJsZSBlbmhhbmNlZCBtZXRhZGF0YSBmaWVsZHMgZm9yIG5ldyBub3RlcyAoZXhpc3Rpbmcgbm90ZXMgcmVtYWluIHVuY2hhbmdlZCknKVxuICAgICAgLmFkZFRvZ2dsZSh0b2dnbGUgPT4gdG9nZ2xlXG4gICAgICAgIC5zZXRWYWx1ZSh0aGlzLnBsdWdpbi5zZXR0aW5ncy51c2VFbmhhbmNlZE1ldGFkYXRhKVxuICAgICAgICAub25DaGFuZ2UoYXN5bmMgKHZhbHVlKSA9PiB7XG4gICAgICAgICAgdGhpcy5wbHVnaW4uc2V0dGluZ3MudXNlRW5oYW5jZWRNZXRhZGF0YSA9IHZhbHVlO1xuICAgICAgICAgIGF3YWl0IHRoaXMucGx1Z2luLnNhdmVTZXR0aW5ncygpO1xuICAgICAgICB9KSk7XG5cbiAgICBuZXcgU2V0dGluZyhjb250YWluZXJFbClcbiAgICAgIC5zZXROYW1lKCdEYXRhdmlldyBGdW5jdGlvbnMgUGF0aCcpXG4gICAgICAuc2V0RGVzYygnUGF0aCB0byB0aGUgZGF0YXZpZXcgZnVuY3Rpb25zIGZpbGUgKHdpdGhvdXQgZXh0ZW5zaW9uKScpXG4gICAgICAuYWRkVGV4dCh0ZXh0ID0+IHRleHRcbiAgICAgICAgLnNldFBsYWNlaG9sZGVyKCcvU3VwcG9ydGluZy9kYXRhdmlldy1mdW5jdGlvbnMnKVxuICAgICAgICAuc2V0VmFsdWUodGhpcy5wbHVnaW4uc2V0dGluZ3MuZGF0YXZpZXdKc1BhdGgpXG4gICAgICAgIC5vbkNoYW5nZShhc3luYyAodmFsdWUpID0+IHtcbiAgICAgICAgICB0aGlzLnBsdWdpbi5zZXR0aW5ncy5kYXRhdmlld0pzUGF0aCA9IHZhbHVlO1xuICAgICAgICAgIGF3YWl0IHRoaXMucGx1Z2luLnNhdmVTZXR0aW5ncygpO1xuICAgICAgICB9KSk7XG4gIH1cbn0iLCAiLy8gVXRpbGl0eSBmdW5jdGlvbnMgZm9yIFR1Y2tlcnMgVG9vbHMgcGx1Z2luXG5cbmV4cG9ydCBmdW5jdGlvbiBmb3JtYXREYXRlKGRhdGU6IERhdGUpOiBzdHJpbmcge1xuICByZXR1cm4gZGF0ZS50b0lTT1N0cmluZygpLnNwbGl0KFwiVFwiKVswXVxufVxuXG5leHBvcnQgZnVuY3Rpb24gYWRkRGF5cyhkYXRlOiBEYXRlLCBkYXlzOiBudW1iZXIpOiBEYXRlIHtcbiAgY29uc3QgcmVzdWx0ID0gbmV3IERhdGUoZGF0ZSlcbiAgcmVzdWx0LnNldERhdGUocmVzdWx0LmdldERhdGUoKSArIGRheXMpXG4gIHJldHVybiByZXN1bHRcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGlzQmV0d2VlbihkYXRlOiBEYXRlLCBzdGFydDogRGF0ZSwgZW5kOiBEYXRlKTogYm9vbGVhbiB7XG4gIHJldHVybiBkYXRlID49IHN0YXJ0ICYmIGRhdGUgPD0gZW5kXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBzbHVnaWZ5KHRleHQ6IHN0cmluZyk6IHN0cmluZyB7XG4gIHJldHVybiB0ZXh0XG4gICAgLnRvTG93ZXJDYXNlKClcbiAgICAudHJpbSgpXG4gICAgLm5vcm1hbGl6ZShcIk5GRFwiKVxuICAgIC5yZXBsYWNlKC9bXFx1MDMwMC1cXHUwMzZmXS9nLCBcIlwiKVxuICAgIC5yZXBsYWNlKC9bXmEtejAtOVxccy1dL2csIFwiXCIpXG4gICAgLnJlcGxhY2UoL1tcXHMtXSsvZywgXCItXCIpXG4gICAgLnJlcGxhY2UoL14tK3wtKyQvZywgXCJcIilcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGdldENvdXJzZUlkRnJvbVBhdGgocGF0aDogc3RyaW5nKTogc3RyaW5nIHwgbnVsbCB7XG4gIC8vIEV4dHJhY3QgY291cnNlIElEIGZyb20gcGF0aCBsaWtlIFwiMjAyNS9GYWxsL1BTSS0xMDEvLi4uXCIgb3IgZmlsZW5hbWUgXCJQU0ktMTAxIC0gSW50cm8gdG8gUHN5Y2gubWRcIlxuICBjb25zdCBwYXJ0cyA9IHBhdGguc3BsaXQoXCIvXCIpXG4gIGZvciAoY29uc3QgcGFydCBvZiBwYXJ0cykge1xuICAgIC8vIExvb2sgZm9yIGNvdXJzZSBJRCBwYXR0ZXJuIGluIGVhY2ggcGF0aCBzZWdtZW50XG4gICAgY29uc3QgbWF0Y2ggPSBwYXJ0Lm1hdGNoKC8oW0EtWl17Miw0fS1cXGR7M30pLylcbiAgICBpZiAobWF0Y2gpIHtcbiAgICAgIHJldHVybiBtYXRjaFsxXVxuICAgIH1cbiAgfVxuICByZXR1cm4gbnVsbFxufVxuXG5leHBvcnQgZnVuY3Rpb24gdmFsaWRhdGVEYXRlKGRhdGVTdHJpbmc6IHN0cmluZyk6IGJvb2xlYW4ge1xuICBjb25zdCByZWdleCA9IC9eXFxkezR9LVxcZHsyfS1cXGR7Mn0kL1xuICBpZiAoIWRhdGVTdHJpbmcubWF0Y2gocmVnZXgpKSByZXR1cm4gZmFsc2VcblxuICBjb25zdCBkYXRlID0gbmV3IERhdGUoZGF0ZVN0cmluZylcbiAgY29uc3QgdGltZXN0YW1wID0gZGF0ZS5nZXRUaW1lKClcblxuICBpZiAodHlwZW9mIHRpbWVzdGFtcCAhPT0gXCJudW1iZXJcIiB8fCBpc05hTih0aW1lc3RhbXApKSByZXR1cm4gZmFsc2VcblxuICByZXR1cm4gZGF0ZVN0cmluZyA9PT0gZGF0ZS50b0lTT1N0cmluZygpLnNwbGl0KFwiVFwiKVswXVxufVxuIiwgImltcG9ydCB7IEFwcCwgTm90aWNlIH0gZnJvbSBcIm9ic2lkaWFuXCJcbmltcG9ydCB7IFR1Y2tlcnNUb29sc1NldHRpbmdzIH0gZnJvbSBcIi4vc2V0dGluZ3NcIlxuXG5pbnRlcmZhY2UgVGVtcGxhdGVNYW5pZmVzdCB7XG4gIHZlcnNpb246IHN0cmluZ1xuICB0ZW1wbGF0ZXM6IFJlY29yZDxzdHJpbmcsIHN0cmluZz5cbiAgcGx1Z2luX3ZlcnNpb246IHN0cmluZ1xuICByZWxlYXNlX25vdGVzOiBzdHJpbmdcbn1cblxuZXhwb3J0IGNsYXNzIFRlbXBsYXRlTWFuYWdlciB7XG4gIGFwcDogQXBwXG4gIHNldHRpbmdzOiBUdWNrZXJzVG9vbHNTZXR0aW5nc1xuICBtYW5pZmVzdDogVGVtcGxhdGVNYW5pZmVzdFxuXG4gIGNvbnN0cnVjdG9yKGFwcDogQXBwLCBzZXR0aW5nczogVHVja2Vyc1Rvb2xzU2V0dGluZ3MpIHtcbiAgICB0aGlzLmFwcCA9IGFwcFxuICAgIHRoaXMuc2V0dGluZ3MgPSBzZXR0aW5nc1xuICAgIHRoaXMubWFuaWZlc3QgPSB7XG4gICAgICB2ZXJzaW9uOiBcIjEuMC4wXCIsXG4gICAgICB0ZW1wbGF0ZXM6IHtcbiAgICAgICAgXCJDb3Vyc2VzL0NyZWF0ZSBDb3Vyc2UgSG9tZXBhZ2UubWRcIjogXCIxLjAuMFwiLFxuICAgICAgICBcIkNvdXJzZXMvQ291cnNlIEluZGV4Lm1kXCI6IFwiMS4wLjBcIixcbiAgICAgICAgXCJNb2R1bGVzL0NyZWF0ZSBNb2R1bGUubWRcIjogXCIxLjAuMFwiLFxuICAgICAgICBcIkNoYXB0ZXJzL0NyZWF0ZSBDaGFwdGVyLm1kXCI6IFwiMS4wLjBcIixcbiAgICAgICAgXCJBc3NpZ25tZW50cy9DcmVhdGUgQXNzaWdubWVudC5tZFwiOiBcIjEuMC4wXCIsXG4gICAgICAgIFwiRGFpbHkvRGFpbHkgTm90ZS5tZFwiOiBcIjEuMC4wXCIsXG4gICAgICAgIFwiVXRpbGl0aWVzL1ZvY2FidWxhcnkgRW50cnkubWRcIjogXCIxLjAuMFwiLFxuICAgICAgICBcIlV0aWxpdGllcy9EdWUgRGF0ZSBFbnRyeS5tZFwiOiBcIjEuMC4wXCJcbiAgICAgIH0sXG4gICAgICBwbHVnaW5fdmVyc2lvbjogXCIxLjAuMFwiLFxuICAgICAgcmVsZWFzZV9ub3RlczogXCJJbml0aWFsIHJlbGVhc2Ugb2YgVHVja2VycyBUb29scyB0ZW1wbGF0ZXNcIlxuICAgIH1cbiAgfVxuXG4gIGFzeW5jIGluc3RhbGxUZW1wbGF0ZXMoKSB7XG4gICAgdHJ5IHtcbiAgICAgIC8vIEdldCBUZW1wbGF0ZXIgcGx1Z2luIHNldHRpbmdzIHRvIGZpbmQgdGVtcGxhdGUgZm9sZGVyXG4gICAgICBjb25zdCB0ZW1wbGF0ZXJQbHVnaW4gPSB0aGlzLmdldFRlbXBsYXRlclBsdWdpbigpXG4gICAgICBpZiAoIXRlbXBsYXRlclBsdWdpbikge1xuICAgICAgICBuZXcgTm90aWNlKFxuICAgICAgICAgIFwiVGVtcGxhdGVyIHBsdWdpbiBub3QgZm91bmQuIFBsZWFzZSBpbnN0YWxsIGFuZCBlbmFibGUgdGhlIFRlbXBsYXRlciBwbHVnaW4gZmlyc3QuXCJcbiAgICAgICAgKVxuICAgICAgICBjb25zb2xlLmVycm9yKFxuICAgICAgICAgIFwiVGVtcGxhdGVyIHBsdWdpbiBub3QgZm91bmQuIFBsZWFzZSBpbnN0YWxsIGFuZCBlbmFibGUgdGhlIFRlbXBsYXRlciBwbHVnaW4gZmlyc3QuXCJcbiAgICAgICAgKVxuICAgICAgICByZXR1cm5cbiAgICAgIH1cblxuICAgICAgY29uc3QgdGVtcGxhdGVGb2xkZXJQYXRoID0gdGhpcy5nZXRUZW1wbGF0ZUZvbGRlclBhdGgodGVtcGxhdGVyUGx1Z2luKVxuICAgICAgaWYgKCF0ZW1wbGF0ZUZvbGRlclBhdGgpIHtcbiAgICAgICAgbmV3IE5vdGljZShcbiAgICAgICAgICBcIlRlbXBsYXRlIGZvbGRlciBub3QgY29uZmlndXJlZCBpbiBUZW1wbGF0ZXIgc2V0dGluZ3MuIFBsZWFzZSBjb25maWd1cmUgaXQgaW4gVGVtcGxhdGVyIHNldHRpbmdzIGZpcnN0LlwiXG4gICAgICAgIClcbiAgICAgICAgY29uc29sZS5lcnJvcihcbiAgICAgICAgICBcIlRlbXBsYXRlIGZvbGRlciBub3QgY29uZmlndXJlZCBpbiBUZW1wbGF0ZXIgc2V0dGluZ3MuIFBsZWFzZSBjb25maWd1cmUgaXQgaW4gVGVtcGxhdGVyIHNldHRpbmdzIGZpcnN0LlwiXG4gICAgICAgIClcbiAgICAgICAgcmV0dXJuXG4gICAgICB9XG5cbiAgICAgIGNvbnN0IGZ1bGxUZW1wbGF0ZVBhdGggPSBgJHt0ZW1wbGF0ZUZvbGRlclBhdGh9LyR7dGhpcy5zZXR0aW5ncy50ZW1wbGF0ZUZvbGRlcn1gXG5cbiAgICAgIC8vIENyZWF0ZSB0aGUgbWFpbiB0ZW1wbGF0ZSBmb2xkZXIgaWYgaXQgZG9lc24ndCBleGlzdFxuICAgICAgdHJ5IHtcbiAgICAgICAgYXdhaXQgdGhpcy5hcHAudmF1bHQuY3JlYXRlRm9sZGVyKGZ1bGxUZW1wbGF0ZVBhdGgpXG4gICAgICAgIGNvbnNvbGUubG9nKGBDcmVhdGVkIHRlbXBsYXRlIGZvbGRlcjogJHtmdWxsVGVtcGxhdGVQYXRofWApXG4gICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIC8vIEZvbGRlciBtaWdodCBhbHJlYWR5IGV4aXN0LCB3aGljaCBpcyBmaW5lXG4gICAgICAgIGNvbnNvbGUubG9nKFxuICAgICAgICAgIGBUZW1wbGF0ZSBmb2xkZXIgYWxyZWFkeSBleGlzdHMgb3IgY3JlYXRlZDogJHtmdWxsVGVtcGxhdGVQYXRofWBcbiAgICAgICAgKVxuICAgICAgfVxuXG4gICAgICAvLyBDcmVhdGUgc3ViZGlyZWN0b3JpZXNcbiAgICAgIGNvbnN0IHN1YmRpcnMgPSBbXG4gICAgICAgIFwiQ291cnNlc1wiLFxuICAgICAgICBcIk1vZHVsZXNcIixcbiAgICAgICAgXCJDaGFwdGVyc1wiLFxuICAgICAgICBcIkFzc2lnbm1lbnRzXCIsXG4gICAgICAgIFwiRGFpbHlcIixcbiAgICAgICAgXCJVdGlsaXRpZXNcIlxuICAgICAgXVxuICAgICAgZm9yIChjb25zdCBzdWJkaXIgb2Ygc3ViZGlycykge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGNvbnN0IHN1YlBhdGggPSBgJHtmdWxsVGVtcGxhdGVQYXRofS8ke3N1YmRpcn1gXG4gICAgICAgICAgYXdhaXQgdGhpcy5hcHAudmF1bHQuY3JlYXRlRm9sZGVyKHN1YlBhdGgpXG4gICAgICAgICAgY29uc29sZS5sb2coYENyZWF0ZWQgc3ViZGlyZWN0b3J5OiAke3N1YlBhdGh9YClcbiAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgIC8vIEZvbGRlciBtaWdodCBhbHJlYWR5IGV4aXN0LCB3aGljaCBpcyBmaW5lXG4gICAgICAgICAgY29uc29sZS5sb2coXG4gICAgICAgICAgICBgU3ViZGlyZWN0b3J5IGFscmVhZHkgZXhpc3RzOiAke2Z1bGxUZW1wbGF0ZVBhdGh9LyR7c3ViZGlyfWBcbiAgICAgICAgICApXG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgLy8gSW5zdGFsbCB0ZW1wbGF0ZXNcbiAgICAgIGF3YWl0IHRoaXMuaW5zdGFsbENvdXJzZVRlbXBsYXRlcyhmdWxsVGVtcGxhdGVQYXRoKVxuICAgICAgYXdhaXQgdGhpcy5pbnN0YWxsTW9kdWxlVGVtcGxhdGVzKGZ1bGxUZW1wbGF0ZVBhdGgpXG4gICAgICBhd2FpdCB0aGlzLmluc3RhbGxDaGFwdGVyVGVtcGxhdGVzKGZ1bGxUZW1wbGF0ZVBhdGgpXG4gICAgICBhd2FpdCB0aGlzLmluc3RhbGxBc3NpZ25tZW50VGVtcGxhdGVzKGZ1bGxUZW1wbGF0ZVBhdGgpXG4gICAgICBhd2FpdCB0aGlzLmluc3RhbGxEYWlseVRlbXBsYXRlcyhmdWxsVGVtcGxhdGVQYXRoKVxuICAgICAgYXdhaXQgdGhpcy5pbnN0YWxsVXRpbGl0eVRlbXBsYXRlcyhmdWxsVGVtcGxhdGVQYXRoKVxuXG4gICAgICAvLyBDcmVhdGUgUkVBRE1FXG4gICAgICBhd2FpdCB0aGlzLmNyZWF0ZVJFQURNRShmdWxsVGVtcGxhdGVQYXRoKVxuXG4gICAgICAvLyBDcmVhdGUgdGVtcGxhdGUgbWFuaWZlc3RcbiAgICAgIGF3YWl0IHRoaXMuY3JlYXRlVGVtcGxhdGVNYW5pZmVzdChmdWxsVGVtcGxhdGVQYXRoKVxuXG4gICAgICBuZXcgTm90aWNlKFwiVHVja2VycyBUb29scyB0ZW1wbGF0ZXMgaW5zdGFsbGVkIHN1Y2Nlc3NmdWxseSFcIilcbiAgICAgIGNvbnNvbGUubG9nKFwiVHVja2VycyBUb29scyB0ZW1wbGF0ZXMgaW5zdGFsbGVkIHN1Y2Nlc3NmdWxseVwiKVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgaW5zdGFsbGluZyB0ZW1wbGF0ZXM6XCIsIGVycm9yKVxuICAgICAgbmV3IE5vdGljZShcIkVycm9yIGluc3RhbGxpbmcgdGVtcGxhdGVzLiBDaGVjayBjb25zb2xlIGZvciBkZXRhaWxzLlwiKVxuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgZ2V0VGVtcGxhdGVyUGx1Z2luKCk6IGFueSB7XG4gICAgLy8gVHJ5IG11bHRpcGxlIHdheXMgdG8gYWNjZXNzIHRoZSBUZW1wbGF0ZXIgcGx1Z2luXG4gICAgY29uc3QgcG9zc2libGVQYXRocyA9IFtcbiAgICAgICh0aGlzLmFwcCBhcyBhbnkpLnBsdWdpbnMucGx1Z2luc1tcInRlbXBsYXRlci1vYnNpZGlhblwiXSxcbiAgICAgICh0aGlzLmFwcCBhcyBhbnkpLnBsdWdpbnMucGx1Z2luc1tcInRlbXBsYXRlclwiXSxcbiAgICAgICh0aGlzLmFwcCBhcyBhbnkpLnBsdWdpbnMuZ2V0UGx1Z2luKFwidGVtcGxhdGVyLW9ic2lkaWFuXCIpLFxuICAgICAgKHRoaXMuYXBwIGFzIGFueSkucGx1Z2lucy5nZXRQbHVnaW4oXCJ0ZW1wbGF0ZXJcIilcbiAgICBdXG5cbiAgICBmb3IgKGNvbnN0IHBhdGggb2YgcG9zc2libGVQYXRocykge1xuICAgICAgaWYgKHBhdGgpIHtcbiAgICAgICAgcmV0dXJuIHBhdGhcbiAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gbnVsbFxuICB9XG5cbiAgcHJpdmF0ZSBnZXRUZW1wbGF0ZUZvbGRlclBhdGgodGVtcGxhdGVyUGx1Z2luOiBhbnkpOiBzdHJpbmcgfCBudWxsIHtcbiAgICBjb25zdCBzZXR0aW5ncyA9IHRlbXBsYXRlclBsdWdpbi5zZXR0aW5nc1xuXG4gICAgaWYgKCFzZXR0aW5ncykge1xuICAgICAgY29uc29sZS5lcnJvcihcIlRlbXBsYXRlciBwbHVnaW4gaGFzIG5vIHNldHRpbmdzXCIpXG4gICAgICByZXR1cm4gbnVsbFxuICAgIH1cblxuICAgIC8vIFRyeSBkaWZmZXJlbnQgcG9zc2libGUgcHJvcGVydHkgbmFtZXMgZm9yIHRlbXBsYXRlIGZvbGRlclxuICAgIGNvbnN0IHBvc3NpYmxlUGF0aHMgPSBbXG4gICAgICBzZXR0aW5ncy50ZW1wbGF0ZXNfZm9sZGVyLCAgLy8gQ2hhbmdlZCBmcm9tIHRlbXBsYXRlX2ZvbGRlciB0byBtYXRjaCBhY3R1YWwgc2V0dGluZ1xuICAgICAgc2V0dGluZ3MudGVtcGxhdGVfZm9sZGVyLFxuICAgICAgc2V0dGluZ3MudGVtcGxhdGVGb2xkZXIsXG4gICAgICBzZXR0aW5ncy50ZW1wbGF0ZUZvbGRlclBhdGgsXG4gICAgICBzZXR0aW5ncy5mb2xkZXJcbiAgICBdXG5cbiAgICBmb3IgKGNvbnN0IHBhdGggb2YgcG9zc2libGVQYXRocykge1xuICAgICAgaWYgKHBhdGggJiYgdHlwZW9mIHBhdGggPT09IFwic3RyaW5nXCIpIHtcbiAgICAgICAgcmV0dXJuIHBhdGhcbiAgICAgIH1cbiAgICB9XG5cbiAgICBjb25zb2xlLmVycm9yKFxuICAgICAgXCJUZW1wbGF0ZSBmb2xkZXIgbm90IGZvdW5kIGluIFRlbXBsYXRlciBzZXR0aW5ncy4gQXZhaWxhYmxlIHNldHRpbmdzOlwiLFxuICAgICAgT2JqZWN0LmtleXMoc2V0dGluZ3MpXG4gICAgKVxuICAgIHJldHVybiBudWxsXG4gIH1cblxuICBhc3luYyBjcmVhdGVUZW1wbGF0ZU1hbmlmZXN0KGJhc2VQYXRoOiBzdHJpbmcpIHtcbiAgICBjb25zdCBtYW5pZmVzdFBhdGggPSBgJHtiYXNlUGF0aH0vdGVtcGxhdGUtbWFuaWZlc3QuanNvbmBcbiAgICBjb25zdCBtYW5pZmVzdENvbnRlbnQgPSBKU09OLnN0cmluZ2lmeSh0aGlzLm1hbmlmZXN0LCBudWxsLCAyKVxuXG4gICAgdHJ5IHtcbiAgICAgIC8vIENoZWNrIGlmIG1hbmlmZXN0IGFscmVhZHkgZXhpc3RzXG4gICAgICBjb25zdCBleGlzdGluZ01hbmlmZXN0ID1cbiAgICAgICAgdGhpcy5hcHAudmF1bHQuZ2V0QWJzdHJhY3RGaWxlQnlQYXRoKG1hbmlmZXN0UGF0aClcbiAgICAgIGlmIChleGlzdGluZ01hbmlmZXN0KSB7XG4gICAgICAgIC8vIFVwZGF0ZSB0aGUgZXhpc3RpbmcgbWFuaWZlc3RcbiAgICAgICAgY29uc3QgZmlsZSA9IGV4aXN0aW5nTWFuaWZlc3QgYXMgaW1wb3J0KFwib2JzaWRpYW5cIikuVEZpbGVcbiAgICAgICAgYXdhaXQgdGhpcy5hcHAudmF1bHQubW9kaWZ5KGZpbGUsIG1hbmlmZXN0Q29udGVudClcbiAgICAgICAgY29uc29sZS5sb2coYFVwZGF0ZWQgdGVtcGxhdGUgbWFuaWZlc3Q6ICR7bWFuaWZlc3RQYXRofWApXG4gICAgICAgIHJldHVyblxuICAgICAgfVxuXG4gICAgICAvLyBDcmVhdGUgdGhlIG1hbmlmZXN0IGZpbGVcbiAgICAgIGF3YWl0IHRoaXMuYXBwLnZhdWx0LmNyZWF0ZShtYW5pZmVzdFBhdGgsIG1hbmlmZXN0Q29udGVudClcbiAgICAgIGNvbnNvbGUubG9nKGBDcmVhdGVkIHRlbXBsYXRlIG1hbmlmZXN0OiAke21hbmlmZXN0UGF0aH1gKVxuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIG5ldyBOb3RpY2UoYEVycm9yIGNyZWF0aW5nIHRlbXBsYXRlIG1hbmlmZXN0ICR7bWFuaWZlc3RQYXRofWApXG4gICAgICBjb25zb2xlLmVycm9yKGBFcnJvciBjcmVhdGluZyB0ZW1wbGF0ZSBtYW5pZmVzdCAke21hbmlmZXN0UGF0aH06YCwgZSlcbiAgICB9XG4gIH1cblxuICBhc3luYyBjaGVja0ZvclRlbXBsYXRlVXBkYXRlcygpOiBQcm9taXNlPGJvb2xlYW4+IHtcbiAgICAvLyBUaGlzIHdvdWxkIGNoZWNrIGlmIHRlbXBsYXRlcyBuZWVkIHRvIGJlIHVwZGF0ZWRcbiAgICAvLyBGb3Igbm93LCB3ZSdsbCBqdXN0IHJldHVybiBmYWxzZVxuICAgIGNvbnNvbGUubG9nKFwiQ2hlY2tpbmcgZm9yIHRlbXBsYXRlIHVwZGF0ZXNcIilcbiAgICByZXR1cm4gZmFsc2VcbiAgfVxuXG4gIGFzeW5jIHVwZGF0ZVRlbXBsYXRlcygpIHtcbiAgICB0cnkge1xuICAgICAgLy8gVGhpcyB3b3VsZCB1cGRhdGUgZXhpc3RpbmcgdGVtcGxhdGVzXG4gICAgICBjb25zb2xlLmxvZyhcIlVwZGF0aW5nIHRlbXBsYXRlc1wiKVxuXG4gICAgICAvLyBHZXQgVGVtcGxhdGVyIHBsdWdpbiBzZXR0aW5ncyB0byBmaW5kIHRlbXBsYXRlIGZvbGRlclxuICAgICAgY29uc3QgdGVtcGxhdGVyUGx1Z2luID0gdGhpcy5nZXRUZW1wbGF0ZXJQbHVnaW4oKVxuICAgICAgaWYgKCF0ZW1wbGF0ZXJQbHVnaW4pIHtcbiAgICAgICAgbmV3IE5vdGljZShcbiAgICAgICAgICBcIlRlbXBsYXRlciBwbHVnaW4gbm90IGZvdW5kLiBQbGVhc2UgaW5zdGFsbCBhbmQgZW5hYmxlIHRoZSBUZW1wbGF0ZXIgcGx1Z2luIGZpcnN0LlwiXG4gICAgICAgIClcbiAgICAgICAgY29uc29sZS5lcnJvcihcbiAgICAgICAgICBcIlRlbXBsYXRlciBwbHVnaW4gbm90IGZvdW5kLiBQbGVhc2UgaW5zdGFsbCBhbmQgZW5hYmxlIHRoZSBUZW1wbGF0ZXIgcGx1Z2luIGZpcnN0LlwiXG4gICAgICAgIClcbiAgICAgICAgcmV0dXJuXG4gICAgICB9XG5cbiAgICAgIGNvbnN0IHRlbXBsYXRlRm9sZGVyUGF0aCA9IHRoaXMuZ2V0VGVtcGxhdGVGb2xkZXJQYXRoKHRlbXBsYXRlclBsdWdpbilcbiAgICAgIGlmICghdGVtcGxhdGVGb2xkZXJQYXRoKSB7XG4gICAgICAgIG5ldyBOb3RpY2UoXG4gICAgICAgICAgXCJUZW1wbGF0ZSBmb2xkZXIgbm90IGNvbmZpZ3VyZWQgaW4gVGVtcGxhdGVyIHNldHRpbmdzLiBQbGVhc2UgY29uZmlndXJlIGl0IGluIFRlbXBsYXRlciBzZXR0aW5ncyBmaXJzdC5cIlxuICAgICAgICApXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXG4gICAgICAgICAgXCJUZW1wbGF0ZSBmb2xkZXIgbm90IGNvbmZpZ3VyZWQgaW4gVGVtcGxhdGVyIHNldHRpbmdzLiBQbGVhc2UgY29uZmlndXJlIGl0IGluIFRlbXBsYXRlciBzZXR0aW5ncyBmaXJzdC5cIlxuICAgICAgICApXG4gICAgICAgIHJldHVyblxuICAgICAgfVxuXG4gICAgICBjb25zdCBmdWxsVGVtcGxhdGVQYXRoID0gYCR7dGVtcGxhdGVGb2xkZXJQYXRofS8ke3RoaXMuc2V0dGluZ3MudGVtcGxhdGVGb2xkZXJ9YFxuXG4gICAgICAvLyBVcGRhdGUgdGVtcGxhdGVzICh0aGlzIHdpbGwgb3ZlcndyaXRlIGV4aXN0aW5nIG9uZXMpXG4gICAgICBhd2FpdCB0aGlzLmluc3RhbGxDb3Vyc2VUZW1wbGF0ZXMoZnVsbFRlbXBsYXRlUGF0aClcbiAgICAgIGF3YWl0IHRoaXMuaW5zdGFsbE1vZHVsZVRlbXBsYXRlcyhmdWxsVGVtcGxhdGVQYXRoKVxuICAgICAgYXdhaXQgdGhpcy5pbnN0YWxsQ2hhcHRlclRlbXBsYXRlcyhmdWxsVGVtcGxhdGVQYXRoKVxuICAgICAgYXdhaXQgdGhpcy5pbnN0YWxsQXNzaWdubWVudFRlbXBsYXRlcyhmdWxsVGVtcGxhdGVQYXRoKVxuICAgICAgYXdhaXQgdGhpcy5pbnN0YWxsRGFpbHlUZW1wbGF0ZXMoZnVsbFRlbXBsYXRlUGF0aClcbiAgICAgIGF3YWl0IHRoaXMuaW5zdGFsbFV0aWxpdHlUZW1wbGF0ZXMoZnVsbFRlbXBsYXRlUGF0aClcblxuICAgICAgLy8gVXBkYXRlIFJFQURNRVxuICAgICAgYXdhaXQgdGhpcy5jcmVhdGVSRUFETUUoZnVsbFRlbXBsYXRlUGF0aClcblxuICAgICAgLy8gVXBkYXRlIHRlbXBsYXRlIG1hbmlmZXN0XG4gICAgICBhd2FpdCB0aGlzLmNyZWF0ZVRlbXBsYXRlTWFuaWZlc3QoZnVsbFRlbXBsYXRlUGF0aClcblxuICAgICAgbmV3IE5vdGljZShcIlR1Y2tlcnMgVG9vbHMgdGVtcGxhdGVzIHVwZGF0ZWQgc3VjY2Vzc2Z1bGx5IVwiKVxuICAgICAgY29uc29sZS5sb2coXCJUdWNrZXJzIFRvb2xzIHRlbXBsYXRlcyB1cGRhdGVkIHN1Y2Nlc3NmdWxseVwiKVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgdXBkYXRpbmcgdGVtcGxhdGVzOlwiLCBlcnJvcilcbiAgICAgIG5ldyBOb3RpY2UoXCJFcnJvciB1cGRhdGluZyB0ZW1wbGF0ZXMuIENoZWNrIGNvbnNvbGUgZm9yIGRldGFpbHMuXCIpXG4gICAgfVxuICB9XG5cbiAgYXN5bmMgaW5zdGFsbENvdXJzZVRlbXBsYXRlcyhiYXNlUGF0aDogc3RyaW5nKSB7XG4gICAgY29uc3QgY291cnNlUGF0aCA9IGAke2Jhc2VQYXRofS9Db3Vyc2VzYFxuXG4gICAgLy8gQ3JlYXRlIENvdXJzZSBIb21lcGFnZSB0ZW1wbGF0ZVxuICAgIGNvbnN0IGNvdXJzZUhvbWVwYWdlVGVtcGxhdGUgPSB0aGlzLmdlbmVyYXRlQ291cnNlSG9tZXBhZ2VUZW1wbGF0ZSgpXG4gICAgYXdhaXQgdGhpcy53cml0ZVRlbXBsYXRlRmlsZShcbiAgICAgIGAke2NvdXJzZVBhdGh9L0NyZWF0ZSBDb3Vyc2UgSG9tZXBhZ2UubWRgLFxuICAgICAgY291cnNlSG9tZXBhZ2VUZW1wbGF0ZVxuICAgIClcblxuICAgIC8vIENyZWF0ZSBDb3Vyc2UgSW5kZXggdGVtcGxhdGVcbiAgICBjb25zdCBjb3Vyc2VJbmRleFRlbXBsYXRlID0gdGhpcy5nZW5lcmF0ZUNvdXJzZUluZGV4VGVtcGxhdGUoKVxuICAgIGF3YWl0IHRoaXMud3JpdGVUZW1wbGF0ZUZpbGUoXG4gICAgICBgJHtjb3Vyc2VQYXRofS9Db3Vyc2UgSW5kZXgubWRgLFxuICAgICAgY291cnNlSW5kZXhUZW1wbGF0ZVxuICAgIClcbiAgfVxuXG4gIGFzeW5jIGluc3RhbGxNb2R1bGVUZW1wbGF0ZXMoYmFzZVBhdGg6IHN0cmluZykge1xuICAgIGNvbnN0IG1vZHVsZVBhdGggPSBgJHtiYXNlUGF0aH0vTW9kdWxlc2BcblxuICAgIC8vIENyZWF0ZSBNb2R1bGUgdGVtcGxhdGVcbiAgICBjb25zdCBtb2R1bGVUZW1wbGF0ZSA9IHRoaXMuZ2VuZXJhdGVNb2R1bGVUZW1wbGF0ZSgpXG4gICAgYXdhaXQgdGhpcy53cml0ZVRlbXBsYXRlRmlsZShcbiAgICAgIGAke21vZHVsZVBhdGh9L0NyZWF0ZSBNb2R1bGUubWRgLFxuICAgICAgbW9kdWxlVGVtcGxhdGVcbiAgICApXG4gIH1cblxuICBhc3luYyBpbnN0YWxsQ2hhcHRlclRlbXBsYXRlcyhiYXNlUGF0aDogc3RyaW5nKSB7XG4gICAgY29uc3QgY2hhcHRlclBhdGggPSBgJHtiYXNlUGF0aH0vQ2hhcHRlcnNgXG5cbiAgICAvLyBDcmVhdGUgQ2hhcHRlciB0ZW1wbGF0ZVxuICAgIGNvbnN0IGNoYXB0ZXJUZW1wbGF0ZSA9IHRoaXMuZ2VuZXJhdGVDaGFwdGVyVGVtcGxhdGUoKVxuICAgIGF3YWl0IHRoaXMud3JpdGVUZW1wbGF0ZUZpbGUoXG4gICAgICBgJHtjaGFwdGVyUGF0aH0vQ3JlYXRlIENoYXB0ZXIubWRgLFxuICAgICAgY2hhcHRlclRlbXBsYXRlXG4gICAgKVxuICB9XG5cbiAgYXN5bmMgaW5zdGFsbEFzc2lnbm1lbnRUZW1wbGF0ZXMoYmFzZVBhdGg6IHN0cmluZykge1xuICAgIGNvbnN0IGFzc2lnbm1lbnRQYXRoID0gYCR7YmFzZVBhdGh9L0Fzc2lnbm1lbnRzYFxuXG4gICAgLy8gQ3JlYXRlIEFzc2lnbm1lbnQgdGVtcGxhdGVcbiAgICBjb25zdCBhc3NpZ25tZW50VGVtcGxhdGUgPSB0aGlzLmdlbmVyYXRlQXNzaWdubWVudFRlbXBsYXRlKClcbiAgICBhd2FpdCB0aGlzLndyaXRlVGVtcGxhdGVGaWxlKFxuICAgICAgYCR7YXNzaWdubWVudFBhdGh9L0NyZWF0ZSBBc3NpZ25tZW50Lm1kYCxcbiAgICAgIGFzc2lnbm1lbnRUZW1wbGF0ZVxuICAgIClcbiAgfVxuXG4gIGFzeW5jIGluc3RhbGxEYWlseVRlbXBsYXRlcyhiYXNlUGF0aDogc3RyaW5nKSB7XG4gICAgY29uc3QgZGFpbHlQYXRoID0gYCR7YmFzZVBhdGh9L0RhaWx5YFxuXG4gICAgLy8gQ3JlYXRlIERhaWx5IE5vdGUgdGVtcGxhdGVcbiAgICBjb25zdCBkYWlseU5vdGVUZW1wbGF0ZSA9IHRoaXMuZ2VuZXJhdGVEYWlseU5vdGVUZW1wbGF0ZSgpXG4gICAgYXdhaXQgdGhpcy53cml0ZVRlbXBsYXRlRmlsZShcbiAgICAgIGAke2RhaWx5UGF0aH0vRGFpbHkgTm90ZS5tZGAsXG4gICAgICBkYWlseU5vdGVUZW1wbGF0ZVxuICAgIClcbiAgfVxuXG4gIGFzeW5jIGluc3RhbGxVdGlsaXR5VGVtcGxhdGVzKGJhc2VQYXRoOiBzdHJpbmcpIHtcbiAgICBjb25zdCB1dGlsaXR5UGF0aCA9IGAke2Jhc2VQYXRofS9VdGlsaXRpZXNgXG5cbiAgICAvLyBDcmVhdGUgVm9jYWJ1bGFyeSBFbnRyeSB0ZW1wbGF0ZVxuICAgIGNvbnN0IHZvY2FiVGVtcGxhdGUgPSB0aGlzLmdlbmVyYXRlVm9jYWJ1bGFyeVRlbXBsYXRlKClcbiAgICBhd2FpdCB0aGlzLndyaXRlVGVtcGxhdGVGaWxlKFxuICAgICAgYCR7dXRpbGl0eVBhdGh9L1ZvY2FidWxhcnkgRW50cnkubWRgLFxuICAgICAgdm9jYWJUZW1wbGF0ZVxuICAgIClcblxuICAgIC8vIENyZWF0ZSBEdWUgRGF0ZSBFbnRyeSB0ZW1wbGF0ZVxuICAgIGNvbnN0IGR1ZURhdGVUZW1wbGF0ZSA9IHRoaXMuZ2VuZXJhdGVEdWVEYXRlVGVtcGxhdGUoKVxuICAgIGF3YWl0IHRoaXMud3JpdGVUZW1wbGF0ZUZpbGUoXG4gICAgICBgJHt1dGlsaXR5UGF0aH0vRHVlIERhdGUgRW50cnkubWRgLFxuICAgICAgZHVlRGF0ZVRlbXBsYXRlXG4gICAgKVxuICB9XG5cbiAgYXN5bmMgd3JpdGVUZW1wbGF0ZUZpbGUocGF0aDogc3RyaW5nLCBjb250ZW50OiBzdHJpbmcpIHtcbiAgICB0cnkge1xuICAgICAgLy8gQ2hlY2sgaWYgZmlsZSBhbHJlYWR5IGV4aXN0c1xuICAgICAgY29uc3QgZXhpc3RpbmdGaWxlID0gdGhpcy5hcHAudmF1bHQuZ2V0QWJzdHJhY3RGaWxlQnlQYXRoKHBhdGgpXG4gICAgICBpZiAoZXhpc3RpbmdGaWxlKSB7XG4gICAgICAgIC8vIEZvciBub3csIHdlJ2xsIHVwZGF0ZSBleGlzdGluZyB0ZW1wbGF0ZXNcbiAgICAgICAgLy8gSW4gYSByZWFsIGltcGxlbWVudGF0aW9uLCB3ZSdkIGNoZWNrIHZlcnNpb25zIGFuZCBvZmZlciB0byB1cGRhdGVcbiAgICAgICAgY29uc29sZS5sb2coYFVwZGF0aW5nIGV4aXN0aW5nIHRlbXBsYXRlIGZpbGU6ICR7cGF0aH1gKVxuICAgICAgICBjb25zdCBmaWxlID0gZXhpc3RpbmdGaWxlIGFzIGltcG9ydChcIm9ic2lkaWFuXCIpLlRGaWxlXG4gICAgICAgIGF3YWl0IHRoaXMuYXBwLnZhdWx0Lm1vZGlmeShmaWxlLCBjb250ZW50KVxuICAgICAgICByZXR1cm5cbiAgICAgIH1cblxuICAgICAgLy8gQ3JlYXRlIHRoZSBmaWxlXG4gICAgICBhd2FpdCB0aGlzLmFwcC52YXVsdC5jcmVhdGUocGF0aCwgY29udGVudClcbiAgICAgIGNvbnNvbGUubG9nKGBDcmVhdGVkIHRlbXBsYXRlIGZpbGU6ICR7cGF0aH1gKVxuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIG5ldyBOb3RpY2UoYEVycm9yIGNyZWF0aW5nIHRlbXBsYXRlIGZpbGUgJHtwYXRofWApXG4gICAgICBjb25zb2xlLmVycm9yKGBFcnJvciBjcmVhdGluZyB0ZW1wbGF0ZSBmaWxlICR7cGF0aH06YCwgZSlcbiAgICB9XG4gIH1cblxuICBnZW5lcmF0ZUNvdXJzZUhvbWVwYWdlVGVtcGxhdGUoKTogc3RyaW5nIHtcbiAgICBjb25zdCBlbmhhbmNlZE1ldGFkYXRhID0gdGhpcy5zZXR0aW5ncy51c2VFbmhhbmNlZE1ldGFkYXRhO1xuICAgIFxuICAgIGlmIChlbmhhbmNlZE1ldGFkYXRhKSB7XG4gICAgICBsZXQgdGVtcGxhdGUgPSBgPCUqXG4vLyBUdWNrZXJzIFRvb2xzIENvdXJzZSBDcmVhdGlvblxuLy8gRm9yIGJlc3QgZXhwZXJpZW5jZSwgdXNlIHRoZSBwbHVnaW4gY29tbWFuZDogQ29tbWFuZCBQYWxldHRlIFx1MjE5MiAnQ3JlYXRlIE5ldyBDb3Vyc2UnXG5cbmxldCBjb3Vyc2VOYW1lID0gXCJOZXcgQ291cnNlXCI7XG5sZXQgY291cnNlU2Vhc29uID0gXCJGYWxsXCI7IFxubGV0IGNvdXJzZVllYXIgPSBuZXcgRGF0ZSgpLmdldEZ1bGxZZWFyKCkudG9TdHJpbmcoKTtcbmxldCBjb3Vyc2VJZCA9IFwiQ09VUlNFX0lEXCI7XG5cbi8vIFRyeSB0byB1c2Ugc3lzdGVtIHByb21wdHMsIHdpdGggZ3JhY2VmdWwgZmFsbGJhY2tcbnRyeSB7XG4gIGlmICh0cCAmJiB0cC5zeXN0ZW0gJiYgdHAuc3lzdGVtLnByb21wdCkge1xuICAgIGNvdXJzZU5hbWUgPSBhd2FpdCB0cC5zeXN0ZW0ucHJvbXB0KFwiQ291cnNlIE5hbWUgKGUuZy4gU1dPLTI1MCAtIENvdXJzZSBUaXRsZSlcIikgfHwgY291cnNlTmFtZTtcbiAgICBjb3Vyc2VJZCA9IGNvdXJzZU5hbWUuc3BsaXQoJyAtICcpWzBdIHx8IGNvdXJzZU5hbWUucmVwbGFjZSgvW15hLXpBLVowLTldL2csIFwiX1wiKTtcbiAgICBjb3Vyc2VTZWFzb24gPSBhd2FpdCB0cC5zeXN0ZW0uc3VnZ2VzdGVyKFtcIkZhbGxcIixcIldpbnRlclwiLFwiU3ByaW5nXCIsXCJTdW1tZXJcIl0sW1wiRmFsbFwiLFwiV2ludGVyXCIsXCJTcHJpbmdcIixcIlN1bW1lclwiXSwgXCJTZWFzb25cIikgfHwgY291cnNlU2Vhc29uO1xuICAgIGNvdXJzZVllYXIgPSBhd2FpdCB0cC5zeXN0ZW0ucHJvbXB0KFwiWWVhclwiKSB8fCBjb3Vyc2VZZWFyO1xuICB9IGVsc2Uge1xuICAgIGNvbnNvbGUubG9nKFwiU3lzdGVtIHByb21wdHMgbm90IGF2YWlsYWJsZSwgdXNlIHRoZSBwbHVnaW4gY29tbWFuZCBpbnN0ZWFkXCIpO1xuICB9XG59IGNhdGNoIChlKSB7XG4gIGNvbnNvbGUuZXJyb3IoXCJFcnJvciB3aXRoIHN5c3RlbSBwcm9tcHRzOlwiLCBlLm1lc3NhZ2UpO1xuICBjb25zb2xlLmxvZyhcIlVzZSB0aGUgcGx1Z2luIGNvbW1hbmQ6IENvbW1hbmQgUGFsZXR0ZSBcdTIxOTIgJ0NyZWF0ZSBOZXcgQ291cnNlJ1wiKTtcbn1cblxuLy8gTW92ZSBmaWxlIHRvIGFwcHJvcHJpYXRlIGxvY2F0aW9uXG5hd2FpdCB0cC5maWxlLm1vdmUoXFxgL1xcJHtjb3Vyc2VZZWFyfS9cXCR7Y291cnNlU2Vhc29ufS9cXCR7Y291cnNlTmFtZX0vXFwke2NvdXJzZU5hbWV9XFxgKTtcblxuLy8gQ3JlYXRlIGF0dGFjaG1lbnRzIGZvbGRlclxudHJ5IHtcbiAgYXdhaXQgYXBwLnZhdWx0LmNyZWF0ZUZvbGRlcihcXGAvXFwke2NvdXJzZVllYXJ9L1xcJHtjb3Vyc2VTZWFzb259L1xcJHtjb3Vyc2VOYW1lfS9BdHRhY2htZW50c1xcYCk7XG59IGNhdGNoIChlKSB7XG4gIC8vIEZvbGRlciBtaWdodCBhbHJlYWR5IGV4aXN0XG59XG4lPi0tLVxuY291cnNlX2lkOiA8JSBjb3Vyc2VJZCAlPlxuY291cnNlX3NlYXNvbjogPCUgY291cnNlU2Vhc29uICU+XG5jb3Vyc2VfeWVhcjogPCUgY291cnNlWWVhciAlPlxuY3JlYXRlZDogPCUgdHAuZGF0ZS5ub3coXCJZWVlZLU1NLUREW1RdSEg6bW06c3NaXCIpICU+XG5jb250ZW50VHlwZTogQ291cnNlXG50YWdzOiBcbiAgLSA8JSBjb3Vyc2VJZCAlPlxuICAtICR7dGhpcy5zZXR0aW5ncy5zY2hvb2xBYmJyZXZpYXRpb259LzwlIGNvdXJzZVllYXIgJT4vPCUgY291cnNlU2Vhc29uICU+LzwlIGNvdXJzZUlkICU+L1xuICAtIGNvdXJzZV9ob21lXG4gIC0gZWR1Y2F0aW9uXG4gIC0gJHt0aGlzLnNldHRpbmdzLnNjaG9vbE5hbWUucmVwbGFjZSgvXFxzKy9nLCAnXycpfVxuYmFubmVyOlxuY3NzY2xhc3NlczpcbiAgLSB3aGl0ZWJvYXJkLWNvdXJzZVxuLS0tXG5cblxuIyA8JSBjb3Vyc2VOYW1lICU+XG5cbiMjIENvdXJzZSBJbmZvcm1hdGlvblxuKipDb3Vyc2UqKjogPCUgY291cnNlTmFtZSAlPlxuKipDb3Vyc2UgSUQqKjogPCUgY291cnNlSWQgJT5cbioqVGVybSoqOiA8JSBjb3Vyc2VTZWFzb24gJT4gPCUgY291cnNlWWVhciAlPlxuKipTY2hvb2wqKjogJHt0aGlzLnNldHRpbmdzLnNjaG9vbE5hbWV9XG5cbiMjIEluc3RydWN0b3JcbioqTmFtZSoqOiBcXGBJTlBVVFt0ZXh0Omluc3RydWN0b3JfbmFtZV1cXGBcbioqRW1haWwqKjogXFxgSU5QVVRbdGV4dDppbnN0cnVjdG9yX2VtYWlsXVxcYFxuKipPZmZpY2UgSG91cnMqKjogXFxgSU5QVVRbdGV4dDppbnN0cnVjdG9yX29mZmljZV9ob3Vyc11cXGBcbioqT2ZmaWNlIExvY2F0aW9uKio6IFxcYElOUFVUW3RleHQ6aW5zdHJ1Y3Rvcl9vZmZpY2VfbG9jYXRpb25dXFxgXG5cbiMjIENvdXJzZSBEZXNjcmlwdGlvblxuXFxgSU5QVVRbdGV4dEFyZWE6Y291cnNlX2Rlc2NyaXB0aW9uXVxcYFxuXG4jIyBMZWFybmluZyBPYmplY3RpdmVzXG5cXGBJTlBVVFt0ZXh0QXJlYTpsZWFybmluZ19vYmplY3RpdmVzXVxcYFxuXG4jIyBSZXF1aXJlZCBUZXh0c1xuXFxgXFxgXFxgbWV0YS1iaW5kLWpzLXZpZXdcbnt0ZXh0c30gYXMgdGV4dHNcbi0tLVxuY29uc3QgYXZhaWxhYmxlVGV4dHMgPSBhcHAudmF1bHQuZ2V0RmlsZXMoKS5maWx0ZXIoZmlsZSA9PiBmaWxlLmV4dGVuc2lvbiA9PSAncGRmJykubWFwKGYgPT4gZj8ubmFtZSlcbmNvbnN0IGVzY2FwZVJlZ2V4ID0gL1ssXFxgJygpXS9nO1xub3B0aW9ucyA9IGF2YWlsYWJsZVRleHRzLm1hcCh0ID0+IFxcYG9wdGlvbihbW1xcJHt0LnJlcGxhY2UoZXNjYXBlUmVnZXgsXCJcXCQxXCIpfV1dLCBcXCR7dC5yZXBsYWNlKGVzY2FwZVJlZ2V4LFwiXFwkMVwiKX0pXFxgIClcbmNvbnN0IHN0ciA9IFxcYFxcXFxcXGBJTlBVVFtpbmxpbmVMaXN0U3VnZ2VzdGVyKFxcJHtvcHRpb25zLmpvaW4oXCIsIFwiKX0pOnRleHRzXVxcXFxcXGBcXGBcbnJldHVybiBlbmdpbmUubWFya2Rvd24uY3JlYXRlKHN0cilcblxcYFxcYFxcYFxuXG4jIyBDb3Vyc2UgU2NoZWR1bGVcblxcYElOUFVUW3RleHRBcmVhOmNvdXJzZV9zY2hlZHVsZV1cXGBcblxuIyMgUmVzb3VyY2VzXG5cXGBJTlBVVFt0ZXh0QXJlYTpyZXNvdXJjZXNdXFxgXG5cbiMjIFZvY2FidWxhcnlcblxcYFxcYFxcYGRhdGF2aWV3anNcbmNvbnN0IHtwcm9jZXNzQ291cnNlVm9jYWJ1bGFyeX0gPSBhcHAucGx1Z2lucy5nZXRQbHVnaW4oXCJ0dWNrZXJzLXRvb2xzXCIpPy5kYXRhdmlld0Z1bmN0aW9ucyB8fCByZXF1aXJlKFwiJHt0aGlzLnNldHRpbmdzLmRhdGF2aWV3SnNQYXRoIHx8IFwiL1N1cHBvcnRpbmcvZGF0YXZpZXctZnVuY3Rpb25zXCJ9XCIpO1xucHJvY2Vzc0NvdXJzZVZvY2FidWxhcnkoZHYsICc8JSBjb3Vyc2VJZCAlPicpO1xuXFxgXFxgXFxgXG5cbiMjIER1ZSBEYXRlc1xuXFxgXFxgXFxgZGF0YXZpZXdqc1xuY29uc3Qge3Byb2Nlc3NEdWVEYXRlc30gPSBhcHAucGx1Z2lucy5nZXRQbHVnaW4oXCJ0dWNrZXJzLXRvb2xzXCIpPy5kYXRhdmlld0Z1bmN0aW9ucyB8fCByZXF1aXJlKFwiJHt0aGlzLnNldHRpbmdzLmRhdGF2aWV3SnNQYXRoIHx8IFwiL1N1cHBvcnRpbmcvZGF0YXZpZXctZnVuY3Rpb25zXCJ9XCIpO1xucHJvY2Vzc0R1ZURhdGVzKGR2LCcjPCUgY291cnNlSWQgJT4nKTtcblxcYFxcYFxcYFxuXG4jIyBDbGFzcyBNYXRlcmlhbHNcblxcYElOUFVUW3RleHRBcmVhOmNsYXNzX21hdGVyaWFsc11cXGBcblxuIyMgQ2xhc3NtYXRlc1xuXFxgSU5QVVRbdGV4dEFyZWE6Y2xhc3NtYXRlc11cXGBgO1xuICAgICAgXG4gICAgICAgICByZXR1cm4gdGVtcGxhdGU7XG4gICAgfSBlbHNlIHtcbiAgICAgIGxldCB0ZW1wbGF0ZSA9IGA8JSpcbi8vIFR1Y2tlcnMgVG9vbHMgQ291cnNlIENyZWF0aW9uXG4vLyBGb3IgYmVzdCBleHBlcmllbmNlLCB1c2UgdGhlIHBsdWdpbiBjb21tYW5kOiBDb21tYW5kIFBhbGV0dGUgXHUyMTkyICdDcmVhdGUgTmV3IENvdXJzZSdcblxubGV0IGNvdXJzZU5hbWUgPSBcIk5ldyBDb3Vyc2VcIjtcbmxldCBjb3Vyc2VTZWFzb24gPSBcIkZhbGxcIjsgXG5sZXQgY291cnNlWWVhciA9IG5ldyBEYXRlKCkuZ2V0RnVsbFllYXIoKS50b1N0cmluZygpO1xubGV0IGNvdXJzZUlkID0gXCJDT1VSU0VfSURcIjtcblxuLy8gVHJ5IHRvIHVzZSBzeXN0ZW0gcHJvbXB0cywgd2l0aCBncmFjZWZ1bCBmYWxsYmFja1xudHJ5IHtcbiAgaWYgKHRwICYmIHRwLnN5c3RlbSAmJiB0cC5zeXN0ZW0ucHJvbXB0KSB7XG4gICAgY291cnNlTmFtZSA9IGF3YWl0IHRwLnN5c3RlbS5wcm9tcHQoXCJDb3Vyc2UgTmFtZSAoZS5nLiBTV08tMjUwIC0gQ291cnNlIFRpdGxlKVwiKSB8fCBjb3Vyc2VOYW1lO1xuICAgIGNvdXJzZUlkID0gY291cnNlTmFtZS5zcGxpdCgnIC0gJylbMF0gfHwgY291cnNlTmFtZS5yZXBsYWNlKC9bXmEtekEtWjAtOV0vZywgXCJfXCIpO1xuICAgIGNvdXJzZVNlYXNvbiA9IGF3YWl0IHRwLnN5c3RlbS5zdWdnZXN0ZXIoW1wiRmFsbFwiLFwiV2ludGVyXCIsXCJTcHJpbmdcIixcIlN1bW1lclwiXSxbXCJGYWxsXCIsXCJXaW50ZXJcIixcIlNwcmluZ1wiLFwiU3VtbWVyXCJdLCBcIlNlYXNvblwiKSB8fCBjb3Vyc2VTZWFzb247XG4gICAgY291cnNlWWVhciA9IGF3YWl0IHRwLnN5c3RlbS5wcm9tcHQoXCJZZWFyXCIpIHx8IGNvdXJzZVllYXI7XG4gIH0gZWxzZSB7XG4gICAgY29uc29sZS5sb2coXCJTeXN0ZW0gcHJvbXB0cyBub3QgYXZhaWxhYmxlLCB1c2UgdGhlIHBsdWdpbiBjb21tYW5kIGluc3RlYWRcIik7XG4gIH1cbn0gY2F0Y2ggKGUpIHtcbiAgY29uc29sZS5lcnJvcihcIkVycm9yIHdpdGggc3lzdGVtIHByb21wdHM6XCIsIGUubWVzc2FnZSk7XG4gIGNvbnNvbGUubG9nKFwiVXNlIHRoZSBwbHVnaW4gY29tbWFuZDogQ29tbWFuZCBQYWxldHRlIFx1MjE5MiAnQ3JlYXRlIE5ldyBDb3Vyc2UnXCIpO1xufVxuXG4vLyBNb3ZlIGZpbGUgdG8gYXBwcm9wcmlhdGUgbG9jYXRpb25cbmF3YWl0IHRwLmZpbGUubW92ZShcXGAvXFwke2NvdXJzZVllYXJ9L1xcJHtjb3Vyc2VTZWFzb259L1xcJHtjb3Vyc2VOYW1lfS9cXCR7Y291cnNlTmFtZX1cXGApO1xuXG4vLyBDcmVhdGUgYXR0YWNobWVudHMgZm9sZGVyXG50cnkge1xuICBhd2FpdCBhcHAudmF1bHQuY3JlYXRlRm9sZGVyKFxcYC9cXCR7Y291cnNlWWVhcn0vXFwke2NvdXJzZVNlYXNvbn0vXFwke2NvdXJzZU5hbWV9L0F0dGFjaG1lbnRzXFxgKTtcbn0gY2F0Y2ggKGUpIHtcbiAgLy8gRm9sZGVyIG1pZ2h0IGFscmVhZHkgZXhpc3Rcbn1cbiU+LS0tXG5jb3Vyc2VfaWQ6IDwlIGNvdXJzZUlkICU+XG5jb3Vyc2VfbmFtZTogPCUgY291cnNlTmFtZSAlPlxuY291cnNlX3NlYXNvbjogPCUgY291cnNlU2Vhc29uICU+XG5jb3Vyc2VfeWVhcjogPCUgY291cnNlWWVhciAlPlxuY3JlYXRlZDogPCUgdHAuZGF0ZS5ub3coXCJZWVlZLU1NLUREW1RdSEg6bW06c3NaXCIpICU+XG50YWdzOlxuICAtIDwlIGNvdXJzZUlkICU+XG4gIC0gY291cnNlX2hvbWVcbiAgLSBlZHVjYXRpb25cbi0tLVxuXG4jIDwlIGNvdXJzZU5hbWUgJT5cblxuIyMgQ291cnNlIEluZm9ybWF0aW9uXG4qKkNvdXJzZSBJRCoqOiA8JSBjb3Vyc2VJZCAlPlxuKipUZXJtKio6IDwlIGNvdXJzZVNlYXNvbiAlPiA8JSBjb3Vyc2VZZWFyICU+XG4qKlNjaG9vbCoqOiAke3RoaXMuc2V0dGluZ3Muc2Nob29sTmFtZX1cblxuIyMgSW5zdHJ1Y3RvclxuKipOYW1lKio6IFxcYElOUFVUW3RleHQ6aW5zdHJ1Y3Rvcl9uYW1lXVxcYFxuKipFbWFpbCoqOiBcXGBJTlBVVFt0ZXh0Omluc3RydWN0b3JfZW1haWxdXFxgXG4qKk9mZmljZSBIb3VycyoqOiBcXGBJTlBVVFt0ZXh0Omluc3RydWN0b3Jfb2ZmaWNlX2hvdXJzXVxcYFxuKipPZmZpY2UgTG9jYXRpb24qKjogXFxgSU5QVVRbdGV4dDppbnN0cnVjdG9yX29mZmljZV9sb2NhdGlvbl1cXGBcblxuIyMgQ291cnNlIERlc2NyaXB0aW9uXG5cXGBJTlBVVFt0ZXh0QXJlYTpjb3Vyc2VfZGVzY3JpcHRpb25dXFxgXG5cbiMjIExlYXJuaW5nIE9iamVjdGl2ZXNcblxcYElOUFVUW3RleHRBcmVhOmxlYXJuaW5nX29iamVjdGl2ZXNdXFxgXG5cbiMjIFJlcXVpcmVkIFRleHRzXG5cXGBcXGBcXGBtZXRhLWJpbmQtanMtdmlld1xue3RleHRzfSBhcyB0ZXh0c1xuLS0tXG5jb25zdCBhdmFpbGFibGVUZXh0cyA9IGFwcC52YXVsdC5nZXRGaWxlcygpLmZpbHRlcihmaWxlID0+IGZpbGUuZXh0ZW5zaW9uID09ICdwZGYnKS5tYXAoZiA9PiBmPy5uYW1lKVxuY29uc3QgZXNjYXBlUmVnZXggPSAvWyxcXGAnKCldL2c7XG5vcHRpb25zID0gYXZhaWxhYmxlVGV4dHMubWFwKHQgPT4gXFxgb3B0aW9uKFtbXFwke3QucmVwbGFjZShlc2NhcGVSZWdleCxcIlxcJDFcIil9XV0sIFxcJHt0LnJlcGxhY2UoZXNjYXBlUmVnZXgsXCJcXCQxXCIpfSlcXGAgKVxuY29uc3Qgc3RyID0gXFwnXFxcXFxcYElOUFVUW2lubGluZUxpc3RTdWdnZXN0ZXIoXFwke29wdGlvbnMuam9pbihcIiwgXCIpfSk6dGV4dHNdXFxcXFxcYFxcXFwnXG5yZXR1cm4gZW5naW5lLm1hcmtkb3duLmNyZWF0ZShzdHIpXG5cXGBcXGBcXGBcblxuIyMgU2NoZWR1bGVcblxcYElOUFVUW3RleHRBcmVhOmNvdXJzZV9zY2hlZHVsZV1cXGBcblxuIyMgQXNzaWdubWVudHNcblxcYElOUFVUW3RleHRBcmVhOmFzc2lnbm1lbnRzXVxcYFxuXG4jIyBSZXNvdXJjZXNcblxcYElOUFVUW3RleHRBcmVhOnJlc291cmNlc11cXGBcblxuIyMgVm9jYWJ1bGFyeVxuXFxgXFxgXFxgZGF0YXZpZXdqc1xuY29uc3Qge3Byb2Nlc3NDb3Vyc2VWb2NhYnVsYXJ5fSA9IGFwcC5wbHVnaW5zLmdldFBsdWdpbihcInR1Y2tlcnMtdG9vbHNcIik/LmRhdGF2aWV3RnVuY3Rpb25zIHx8IHJlcXVpcmUoXCIke3RoaXMuc2V0dGluZ3MuZGF0YXZpZXdKc1BhdGggfHwgXCIvU3VwcG9ydGluZy9kYXRhdmlldy1mdW5jdGlvbnNcIn1cIik7XG5wcm9jZXNzQ291cnNlVm9jYWJ1bGFyeShkdiwgJzwlIGNvdXJzZUlkICU+Jyk7XG5cXGBcXGBcXGBcblxuIyMgRHVlIERhdGVzXG5cXGBcXGBcXGBkYXRhdmlld2pzXG5jb25zdCB7cHJvY2Vzc0R1ZURhdGVzfSA9IGFwcC5wbHVnaW5zLmdldFBsdWdpbihcInR1Y2tlcnMtdG9vbHNcIik/LmRhdGF2aWV3RnVuY3Rpb25zIHx8IHJlcXVpcmUoXCIke3RoaXMuc2V0dGluZ3MuZGF0YXZpZXdKc1BhdGggfHwgXCIvU3VwcG9ydGluZy9kYXRhdmlldy1mdW5jdGlvbnNcIn1cIik7XG5wcm9jZXNzRHVlRGF0ZXMoZHYsJyM8JSBjb3Vyc2VJZCAlPicpO1xuXFxgXFxgXFxgYDtcbiAgICAgIFxuICAgICAgXG4gICAgICByZXR1cm4gdGVtcGxhdGU7XG4gICAgfVxuICB9XG5cbiAgZ2VuZXJhdGVDb3Vyc2VJbmRleFRlbXBsYXRlKCk6IHN0cmluZyB7XG4gICAgcmV0dXJuIGAtLS1cbmNvbnRlbnRfdHlwZTogY291cnNlX2luZGV4XG50YWdzOlxuICAtIGluZGV4XG4tLS1cblxuIyBDb3Vyc2UgSW5kZXhcblxuIyMgTW9kdWxlc1xuXG4jIyBDaGFwdGVyc1xuXG4jIyBBc3NpZ25tZW50c1xuXG4jIyBSZXNvdXJjZXNcblxuIyMgVm9jYWJ1bGFyeVxuXG4jIyBEdWUgRGF0ZXNgXG4gIH1cblxuICBnZW5lcmF0ZU1vZHVsZVRlbXBsYXRlKCk6IHN0cmluZyB7XG4gICAgcmV0dXJuIGA8JSpcbmNvbnN0IHsgc2Vhc29uLCBtb2R1bGVOdW1iZXIsIHdlZWtOdW1iZXIsIGNvdXJzZSwgY291cnNlSWQsIGRpc2NpcGxpbmUsIGRheU9mV2VlayB9ID0gYXdhaXQgdHAudXNlci5uZXdfbW9kdWxlKGFwcCwgdHAsIFwiMjAyNVwiKTtcbmxldCB0aXRsZSA9IGNvdXJzZUlkXG5pZiAobW9kdWxlTnVtYmVyICYmIHdlZWtOdW1iZXIpIHsgdGl0bGUgPSBcXGBNXFwke21vZHVsZU51bWJlcn0vV1xcJHt3ZWVrTnVtYmVyfVxcYH1cbmVsc2UgaWYgKG1vZHVsZU51bWJlcikgeyB0aXRsZSA9IFxcYE1cXCR7bW9kdWxlTnVtYmVyfVxcYCB9IFxuZWxzZSBpZiAod2Vla051bWJlcikgeyB0aXRsZSA9IFxcYFdcXCR7d2Vla051bWJlcn1cXGB9XG4lPi0tLVxuJHtcbiAgdGhpcy5zZXR0aW5ncy51c2VFbmhhbmNlZE1ldGFkYXRhXG4gICAgPyBgY291cnNlX2lkOiA8JSBjb3Vyc2VJZCAlPlxubW9kdWxlX251bWJlcjogPCUgbW9kdWxlTnVtYmVyICU+XG53ZWVrX251bWJlcjogPCUgd2Vla051bWJlciAlPlxuY2xhc3NfZGF5OiA8JSBkYXlPZldlZWsgJT5cbmNvbnRlbnRfdHlwZTogbW9kdWxlXG5wYXJlbnRfY291cnNlOiBcIltbPCUgY291cnNlICU+XV1cImBcbiAgICA6IGBjb3Vyc2VfaWQ6IDwlIGNvdXJzZUlkICU+XG5tb2R1bGVfbnVtYmVyOiA8JSBtb2R1bGVOdW1iZXIgJT5cbndlZWtfbnVtYmVyOiA8JSB3ZWVrTnVtYmVyICU+XG5jbGFzc19kYXk6IDwlIGRheU9mV2VlayAlPmBcbn1cbmNyZWF0ZWQ6IDwlIHRwLmRhdGUubm93KFwiWVlZWS1NTS1ERFtUXUhIOm1tOnNzWlwiKSAlPlxudGFnczpcbiAgLSBlZHVjYXRpb25cbiAgLSA8JSBjb3Vyc2VJZCAlPlxuICAtIG1vZHVsZVxuLS0tXG5cblxuIyBbWzwlIGNvdXJzZSAlPl1dIC0gPCUgdGl0bGUgJT4gLSA8JSBkYXlPZldlZWsgJT5cblxuIyMgRHVlIERhdGVzXG58IERhdGUgfCBBc3NpZ25tZW50IHxcbnwgLS0tLSB8IC0tLS0tLS0tLS0gfFxufCAgICAgIHwgICAgICAgICAgICB8XG58ICAgICAgfCAgICAgICAgICAgIHxcbnwgICAgICB8ICAgICAgICAgICAgfFxuXG5cXGBcXGBcXGBkYXRhdmlld2pzXG5jb25zdCB7cHJvY2Vzc0R1ZURhdGVzfSA9IHJlcXVpcmUoXCIke3RoaXMuc2V0dGluZ3MuZGF0YXZpZXdKc1BhdGggfHwgXCIvU3VwcG9ydGluZy9kYXRhdmlldy1mdW5jdGlvbnNcIn1cIik7XG5wcm9jZXNzRHVlRGF0ZXMoZHYsJyM8JSBjb3Vyc2VJZCAlPicpO1xuXFxgXFxgXFxgXG5cbiMjIExlYXJuaW5nIE9iamVjdGl2ZXNcblxuIyMgUmVhZGluZyBBc3NpZ25tZW50XG5cbiMjIExlY3R1cmUgTm90ZXNcblxuIyMgRGlzY3Vzc2lvbiBRdWVzdGlvbnNcblxuIyMgVm9jYWJ1bGFyeVxuXG5cXGBcXGBcXGBkYXRhdmlld2pzXG5jb25zdCB7cHJvY2Vzc0NvdXJzZVZvY2FidWxhcnl9ID0gcmVxdWlyZShcIiR7dGhpcy5zZXR0aW5ncy5kYXRhdmlld0pzUGF0aCB8fCBcIi9TdXBwb3J0aW5nL2RhdGF2aWV3LWZ1bmN0aW9uc1wifVwiKTtcbnByb2Nlc3NDb3Vyc2VWb2NhYnVsYXJ5KGR2LCAnPCUgY291cnNlSWQgJT4nKTtcblxcYFxcYFxcYFxuXG4jIyBBZGRpdGlvbmFsIFJlc291cmNlc2BcbiAgfVxuXG4gIGdlbmVyYXRlQ2hhcHRlclRlbXBsYXRlKCk6IHN0cmluZyB7XG4gICAgcmV0dXJuIGA8JSpcbmNvbnN0IHsgY2hhcHRlck51bWJlciwgY291cnNlLCBjb3Vyc2VJZCwgZGlzY2lwbGluZSwgdGV4dH0gPSBhd2FpdCB0cC51c2VyLm5ld19jaGFwdGVyKHRwKTtcbiU+LS0tXG4ke1xuICB0aGlzLnNldHRpbmdzLnVzZUVuaGFuY2VkTWV0YWRhdGFcbiAgICA/IGBjb3Vyc2VfaWQ6IDwlIGNvdXJzZUlkICU+XG5jaGFwdGVyX251bWJlcjogPCUgY2hhcHRlck51bWJlciAlPlxuY29udGVudF90eXBlOiBjaGFwdGVyXG5wYXJlbnRfY291cnNlOiBcIltbPCUgY291cnNlICU+XV1cIlxudGV4dF9yZWZlcmVuY2U6IFwiW1s8JSB0ZXh0ICU+XV1cImBcbiAgICA6IGBjb3Vyc2VfaWQ6IDwlIGNvdXJzZUlkICU+XG5jaGFwdGVyX251bWJlcjogPCUgY2hhcHRlck51bWJlciAlPmBcbn1cbmNyZWF0ZWQ6IDwlIHRwLmRhdGUubm93KFwiWVlZWS1NTS1ERFtUXUhIOm1tOnNzWlwiKSAlPlxudGFnczpcbiAgLSBlZHVjYXRpb25cbiAgLSA8JSBjb3Vyc2VJZCAlPlxuICAtIGNoYXB0ZXJcbi0tLVxuXG5cbiMgW1s8JSB0ZXh0ICU+XV0gLSBDaGFwdGVyIDwlIGNoYXB0ZXJOdW1iZXIgJT5cblxuIyMgUmVhZGluZyBBc3NpZ25tZW50XG4tICoqVGV4dGJvb2sqKjogW1s8JSB0ZXh0ICU+XV1cbi0gKipDaGFwdGVyKio6IDwlIGNoYXB0ZXJOdW1iZXIgJT5cbi0gKipQYWdlcyoqOiBcblxuIyMgU3VtbWFyeVxuXG4jIyBLZXkgQ29uY2VwdHNcblxuIyMgVm9jYWJ1bGFyeVxuLSBcblxuIyMgTm90ZXNcblxuIyMgRGlzY3Vzc2lvbiBRdWVzdGlvbnNcblxuIyMgRnVydGhlciBSZWFkaW5nYFxuICB9XG5cbiAgZ2VuZXJhdGVBc3NpZ25tZW50VGVtcGxhdGUoKTogc3RyaW5nIHtcbiAgICByZXR1cm4gYC0tLVxuJHtcbiAgdGhpcy5zZXR0aW5ncy51c2VFbmhhbmNlZE1ldGFkYXRhXG4gICAgPyBgY291cnNlX2lkOiA8JSBjb3Vyc2VJZCAlPlxuYXNzaWdubWVudF90eXBlOiA8JSBhc3NpZ25tZW50VHlwZSAlPlxuZHVlX2RhdGU6IDwlIGR1ZURhdGUgJT5cbnBvaW50czogPCUgcG9pbnRzICU+XG5jb250ZW50X3R5cGU6IGFzc2lnbm1lbnRcbnBhcmVudF9jb3Vyc2U6IFwiW1s8JSBjb3Vyc2UgJT5dXVwiYFxuICAgIDogYGNvdXJzZV9pZDogPCUgY291cnNlSWQgJT5cbmFzc2lnbm1lbnRfdHlwZTogPCUgYXNzaWdubWVudFR5cGUgJT5cbmR1ZV9kYXRlOiA8JSBkdWVEYXRlICU+YFxufVxuY3JlYXRlZDogPCUgdHAuZGF0ZS5ub3coXCJZWVlZLU1NLUREW1RdSEg6bW06c3NaXCIpICU+XG5zdGF0dXM6IHBlbmRpbmdcbnRhZ3M6XG4gIC0gZWR1Y2F0aW9uXG4gIC0gPCUgY291cnNlSWQgJT5cbiAgLSBhc3NpZ25tZW50XG4tLS1cblxuIyA8JSBhc3NpZ25tZW50TmFtZSAlPiAtIDwlIGNvdXJzZUlkICU+XG5cbiMjIERlc2NyaXB0aW9uXG5cbiMjIEluc3RydWN0aW9uc1xuXG4jIyBEdWUgRGF0ZVxuKipBc3NpZ25lZCoqOiA8JSB0cC5kYXRlLm5vdyhcIllZWVktTU0tRERcIikgJT5cbioqRHVlKio6IDwlIGR1ZURhdGUgJT5cblxuIyMgU3VibWlzc2lvblxuXG4jIyBHcmFkaW5nIENyaXRlcmlhXG5cbiMjIFJlc291cmNlc1xuXG4jIER1ZSBEYXRlc1xufCA8JSBkdWVEYXRlICU+IHwgPCUgYXNzaWdubWVudE5hbWUgJT4gfCBwZW5kaW5nIHxcbmBcbiAgfVxuXG4gIGdlbmVyYXRlRGFpbHlOb3RlVGVtcGxhdGUoKTogc3RyaW5nIHtcbiAgICByZXR1cm4gYC0tLVxuY29udGVudF90eXBlOiBkYWlseV9ub3RlXG5kYXRlOiA8JSB0cC5kYXRlLm5vdyhcIllZWVktTU0tRERcIikgJT5cbnRhZ3M6XG4gIC0gZGFpbHlcbiAgLSA8JSB0cC5kYXRlLm5vdyhcIllZWVlcIikgJT5cbiAgLSA8JSB0cC5kYXRlLm5vdyhcIk1NXCIpICU+XG4gIC0gPCUgdHAuZGF0ZS5ub3coXCJERFwiKSAlPlxuLS0tXG5cbiMgPCUgdHAuZGF0ZS5ub3coXCJZWVlZLU1NLUREIC0gZGRkZFwiKSAlPlxuXG48PCBbWzwlIHRwLmRhdGUueWVzdGVyZGF5KFwiWVlZWS1NTS1ERFwiKSAlPl1dIHwgW1s8JSB0cC5kYXRlLnRvbW9ycm93KFwiWVlZWS1NTS1ERFwiKSAlPl1dID4+XG5cbiMjIFRvZGF5J3MgRm9jdXNcblxuIyMgQ291cnNlcyBXb3JrZWQgT25cbi0gXG5cbiMjIFRhc2tzIENvbXBsZXRlZFxuLSBbIF0gXG5cbiMjIFZvY2FidWxhcnkgUmV2aWV3ZWRcbi0gXG5cbiMjIEFzc2lnbm1lbnRzIER1ZVxuLSBcblxuIyMgTGVhcm5pbmcgQWNoaWV2ZW1lbnRzXG5cbiMjIENoYWxsZW5nZXNcblxuIyMgVG9tb3Jyb3cncyBQbGFuXG5cbiMjIFJlZmxlY3Rpb25gXG4gIH1cblxuICBnZW5lcmF0ZVZvY2FidWxhcnlUZW1wbGF0ZSgpOiBzdHJpbmcge1xuICAgIHJldHVybiBgIyMgPCUgdGVybSAlPlxuKipUZXJtKio6IDwlIHRlcm0gJT5cbioqUGFydCBvZiBTcGVlY2gqKjogXG4qKkRlZmluaXRpb24qKjogXG4qKkNvbnRleHQqKjogXG4qKkV4YW1wbGVzKio6IFxuKipSZWxhdGVkIFRlcm1zKio6IFxuKipTZWUgQWxzbyoqOmBcbiAgfVxuXG4gIGdlbmVyYXRlRHVlRGF0ZVRlbXBsYXRlKCk6IHN0cmluZyB7XG4gICAgcmV0dXJuIGB8IDwlIGR1ZURhdGUgJT4gfCA8JSBhc3NpZ25tZW50ICU+IHwgPCUgc3RhdHVzICU+IHxgXG4gIH1cblxuICBhc3luYyBjcmVhdGVSRUFETUUoYmFzZVBhdGg6IHN0cmluZykge1xuICAgIGNvbnN0IHJlYWRtZUNvbnRlbnQgPSBgIyBUdWNrZXJzIFRvb2xzIFRlbXBsYXRlc1xuXG5UaGlzIGRpcmVjdG9yeSBjb250YWlucyB0ZW1wbGF0ZXMgZm9yIHRoZSBUdWNrZXJzIFRvb2xzIE9ic2lkaWFuIHBsdWdpbi5cblxuIyMgVGVtcGxhdGUgQ2F0ZWdvcmllc1xuXG4tICoqQ291cnNlcyoqOiBUZW1wbGF0ZXMgZm9yIGNyZWF0aW5nIGFuZCBvcmdhbml6aW5nIGNvdXJzZXNcbi0gKipNb2R1bGVzKio6IFRlbXBsYXRlcyBmb3IgY291cnNlIG1vZHVsZXNcbi0gKipDaGFwdGVycyoqOiBUZW1wbGF0ZXMgZm9yIGNoYXB0ZXIgbm90ZXNcbi0gKipBc3NpZ25tZW50cyoqOiBUZW1wbGF0ZXMgZm9yIGFzc2lnbm1lbnRzXG4tICoqRGFpbHkqKjogVGVtcGxhdGVzIGZvciBkYWlseSBub3Rlc1xuLSAqKlV0aWxpdGllcyoqOiBIZWxwZXIgdGVtcGxhdGVzXG5cbiMjIFVzYWdlXG5cblRoZXNlIHRlbXBsYXRlcyBhcmUgZGVzaWduZWQgdG8gd29yayB3aXRoIHRoZSBUdWNrZXJzIFRvb2xzIHBsdWdpbi4gVG8gdXNlIHRoZW06XG5cbjEuIEluc3RhbGwgdGhlIFR1Y2tlcnMgVG9vbHMgcGx1Z2luXG4yLiBDb25maWd1cmUgeW91ciBzZXR0aW5ncyBpbiB0aGUgcGx1Z2luIHNldHRpbmdzIHRhYlxuMy4gVXNlIHRoZSBcIkluc2VydCBUZW1wbGF0ZVwiIGNvbW1hbmQgdG8gYXBwbHkgdGhlc2UgdGVtcGxhdGVzIHRvIG5ldyBub3Rlc1xuXG4jIyBDdXN0b21pemF0aW9uXG5cbkZlZWwgZnJlZSB0byBjdXN0b21pemUgdGhlc2UgdGVtcGxhdGVzIHRvIHN1aXQgeW91ciBuZWVkcy4gVGhlIHBsdWdpbiB3aWxsIG5vdCBvdmVyd3JpdGUgeW91ciBjaGFuZ2VzIHdoZW4gdXBkYXRpbmcgdGVtcGxhdGVzLmBcblxuICAgIGF3YWl0IHRoaXMud3JpdGVUZW1wbGF0ZUZpbGUoYCR7YmFzZVBhdGh9L1JFQURNRS5tZGAsIHJlYWRtZUNvbnRlbnQpXG4gIH1cbn1cbiIsICIvLyBDb3Vyc2UgY3JlYXRpb24gd2l6YXJkIGZvciBUdWNrZXJzIFRvb2xzIHBsdWdpblxuXG5pbXBvcnQgeyBBcHAsIE5vdGljZSwgVEZpbGUgfSBmcm9tIFwib2JzaWRpYW5cIlxuaW1wb3J0IHsgVHVja2Vyc1Rvb2xzU2V0dGluZ3MgfSBmcm9tIFwiLi9zZXR0aW5nc1wiXG5pbXBvcnQgeyBzbHVnaWZ5IH0gZnJvbSBcIi4vdXRpbHNcIlxuaW1wb3J0IHsgSW5wdXRNb2RhbCwgU3VnZ2VzdGVyTW9kYWwgfSBmcm9tIFwiLi9pbnB1dE1vZGFsXCJcbmltcG9ydCB7IFRlbXBsYXRlTWFuYWdlciB9IGZyb20gXCIuL3RlbXBsYXRlTWFuYWdlclwiXG5cbmV4cG9ydCBjbGFzcyBDb3Vyc2VDcmVhdGlvbldpemFyZCB7XG4gIGFwcDogQXBwXG4gIHNldHRpbmdzOiBUdWNrZXJzVG9vbHNTZXR0aW5nc1xuXG4gIGNvbnN0cnVjdG9yKGFwcDogQXBwLCBzZXR0aW5nczogVHVja2Vyc1Rvb2xzU2V0dGluZ3MpIHtcbiAgICB0aGlzLmFwcCA9IGFwcFxuICAgIHRoaXMuc2V0dGluZ3MgPSBzZXR0aW5nc1xuICB9XG5cbiAgYXN5bmMgY3JlYXRlQ291cnNlSG9tZXBhZ2UoKSB7XG4gICAgdHJ5IHtcbiAgICAgIC8vIFByb21wdCB1c2VyIGZvciBjb3Vyc2UgZGV0YWlsc1xuICAgICAgY29uc3QgY291cnNlRGV0YWlscyA9IGF3YWl0IHRoaXMucHJvbXB0Q291cnNlRGV0YWlscygpXG5cbiAgICAgIGlmICghY291cnNlRGV0YWlscykge1xuICAgICAgICByZXR1cm4gZmFsc2UgLy8gVXNlciBjYW5jZWxsZWRcbiAgICAgIH1cblxuICAgICAgLy8gQ3JlYXRlIGZvbGRlciBzdHJ1Y3R1cmVcbiAgICAgIGNvbnN0IGZvbGRlclBhdGggPSBhd2FpdCB0aGlzLmNyZWF0ZUNvdXJzZUZvbGRlclN0cnVjdHVyZShjb3Vyc2VEZXRhaWxzKVxuXG4gICAgICAvLyBHZW5lcmF0ZSBjb3Vyc2UgaG9tZXBhZ2Ugbm90ZVxuICAgICAgYXdhaXQgdGhpcy5jcmVhdGVDb3Vyc2VIb21lcGFnZU5vdGUoY291cnNlRGV0YWlscywgZm9sZGVyUGF0aClcblxuICAgICAgLy8gQ3JlYXRlIGF0dGFjaG1lbnRzIGZvbGRlclxuICAgICAgYXdhaXQgdGhpcy5jcmVhdGVBdHRhY2htZW50c0ZvbGRlcihmb2xkZXJQYXRoKVxuXG4gICAgICBuZXcgTm90aWNlKGBDb3Vyc2UgXCIke2NvdXJzZURldGFpbHMuY291cnNlTmFtZX1cIiBjcmVhdGVkIHN1Y2Nlc3NmdWxseSFgKVxuICAgICAgY29uc29sZS5sb2coXG4gICAgICAgIGBDb3Vyc2UgY3JlYXRlZDogJHtjb3Vyc2VEZXRhaWxzLmNvdXJzZU5hbWV9IGF0ICR7Zm9sZGVyUGF0aH1gXG4gICAgICApXG5cbiAgICAgIHJldHVybiB0cnVlXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBjcmVhdGluZyBjb3Vyc2U6XCIsIGVycm9yKVxuICAgICAgbmV3IE5vdGljZShgRXJyb3IgY3JlYXRpbmcgY291cnNlOiAke2Vycm9yLm1lc3NhZ2V9YClcbiAgICAgIHJldHVybiBmYWxzZVxuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgcHJvbXB0Q291cnNlRGV0YWlscygpOiBQcm9taXNlPHtcbiAgICBjb3Vyc2VOYW1lOiBzdHJpbmdcbiAgICBjb3Vyc2VTZWFzb246IHN0cmluZ1xuICAgIGNvdXJzZVllYXI6IHN0cmluZ1xuICAgIGNvdXJzZUlkOiBzdHJpbmdcbiAgfSB8IG51bGw+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgY291cnNlTmFtZSA9IGF3YWl0IHRoaXMucHJvbXB0V2l0aFZhbGlkYXRpb24oXG4gICAgICAgIFwiQ291cnNlIE5hbWVcIixcbiAgICAgICAgXCJFbnRlciBjb3Vyc2UgbmFtZSAoZS5nLiwgUFNJLTEwMSAtIEludHJvIHRvIFBzeWNob2xvZ3kpXCIsXG4gICAgICAgICh2YWx1ZSkgPT4gdmFsdWUudHJpbSgpLmxlbmd0aCA+IDAsXG4gICAgICAgIFwiQ291cnNlIG5hbWUgaXMgcmVxdWlyZWRcIlxuICAgICAgKVxuXG4gICAgICBpZiAoIWNvdXJzZU5hbWUpIHJldHVybiBudWxsXG5cbiAgICAgIGNvbnN0IGNvdXJzZVNlYXNvbiA9IGF3YWl0IHRoaXMucHJvbXB0V2l0aE9wdGlvbnMoXG4gICAgICAgIFwiU2Vhc29uXCIsXG4gICAgICAgIFwiU2VsZWN0IHNlbWVzdGVyL3NlYXNvblwiLFxuICAgICAgICBbXCJGYWxsXCIsIFwiV2ludGVyXCIsIFwiU3ByaW5nXCIsIFwiU3VtbWVyXCJdXG4gICAgICApXG5cbiAgICAgIGlmICghY291cnNlU2Vhc29uKSByZXR1cm4gbnVsbFxuXG4gICAgICBjb25zdCBjb3Vyc2VZZWFyID0gYXdhaXQgdGhpcy5wcm9tcHRXaXRoVmFsaWRhdGlvbihcbiAgICAgICAgXCJZZWFyXCIsXG4gICAgICAgIFwiRW50ZXIgYWNhZGVtaWMgeWVhciAoZS5nLiwgMjAyNSlcIixcbiAgICAgICAgKHZhbHVlKSA9PiAvXlxcZHs0fSQvLnRlc3QodmFsdWUudHJpbSgpKSxcbiAgICAgICAgXCJQbGVhc2UgZW50ZXIgYSB2YWxpZCA0LWRpZ2l0IHllYXJcIlxuICAgICAgKVxuXG4gICAgICBpZiAoIWNvdXJzZVllYXIpIHJldHVybiBudWxsXG5cbiAgICAgIGNvbnN0IGNvdXJzZUlkID0gY291cnNlTmFtZS5zcGxpdChcIiAtIFwiKVswXT8udHJpbSgpIHx8IHNsdWdpZnkoY291cnNlTmFtZSlcblxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgY291cnNlTmFtZSxcbiAgICAgICAgY291cnNlU2Vhc29uLFxuICAgICAgICBjb3Vyc2VZZWFyLFxuICAgICAgICBjb3Vyc2VJZFxuICAgICAgfVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgcHJvbXB0aW5nIGZvciBjb3Vyc2UgZGV0YWlsczpcIiwgZXJyb3IpXG4gICAgICByZXR1cm4gbnVsbFxuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgcHJvbXB0V2l0aFZhbGlkYXRpb24oXG4gICAgdGl0bGU6IHN0cmluZyxcbiAgICBtZXNzYWdlOiBzdHJpbmcsXG4gICAgdmFsaWRhdG9yOiAodmFsdWU6IHN0cmluZykgPT4gYm9vbGVhbixcbiAgICBlcnJvck1lc3NhZ2U6IHN0cmluZ1xuICApOiBQcm9taXNlPHN0cmluZyB8IG51bGw+IHtcbiAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcbiAgICAgIGNvbnN0IG1vZGFsID0gbmV3IElucHV0TW9kYWwodGhpcy5hcHAsIChyZXN1bHQpID0+IHtcbiAgICAgICAgaWYgKHJlc3VsdCA9PT0gbnVsbCkge1xuICAgICAgICAgIC8vIFVzZXIgY2FuY2VsbGVkXG4gICAgICAgICAgcmVzb2x2ZShudWxsKTtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoIXZhbGlkYXRvcihyZXN1bHQpKSB7XG4gICAgICAgICAgbmV3IE5vdGljZShlcnJvck1lc3NhZ2UpO1xuICAgICAgICAgIC8vIFJlY3Vyc2l2ZWx5IGNhbGwgYWdhaW4gaWYgdmFsaWRhdGlvbiBmYWlsc1xuICAgICAgICAgIHRoaXMucHJvbXB0V2l0aFZhbGlkYXRpb24odGl0bGUsIG1lc3NhZ2UsIHZhbGlkYXRvciwgZXJyb3JNZXNzYWdlKVxuICAgICAgICAgICAgLnRoZW4ocmVzb2x2ZSk7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgcmVzb2x2ZShyZXN1bHQudHJpbSgpKTtcbiAgICAgIH0pO1xuXG4gICAgICAvLyBTZXQgdGhlIHRpdGxlIGFuZCBtZXNzYWdlIGRpZmZlcmVudGx5IHNpbmNlIG91ciBtb2RhbCBpcyBzaW1wbGVcbiAgICAgIG1vZGFsLnRpdGxlRWwuc2V0VGV4dCh0aXRsZSk7XG4gICAgICBjb25zdCBtZXNzYWdlRWwgPSBtb2RhbC5jb250ZW50RWwuY3JlYXRlRGl2KCk7XG4gICAgICBtZXNzYWdlRWwuc2V0VGV4dChtZXNzYWdlKTtcblxuICAgICAgbW9kYWwub3BlbigpO1xuICAgIH0pO1xuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBwcm9tcHRXaXRoT3B0aW9ucyhcbiAgICB0aXRsZTogc3RyaW5nLFxuICAgIG1lc3NhZ2U6IHN0cmluZyxcbiAgICBvcHRpb25zOiBzdHJpbmdbXVxuICApOiBQcm9taXNlPHN0cmluZyB8IG51bGw+IHtcbiAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcbiAgICAgIGNvbnN0IG1vZGFsID0gbmV3IFN1Z2dlc3Rlck1vZGFsKHRoaXMuYXBwLCBvcHRpb25zLCAocmVzdWx0KSA9PiB7XG4gICAgICAgIGlmIChyZXN1bHQgPT09IG51bGwpIHtcbiAgICAgICAgICAvLyBVc2VyIGNhbmNlbGxlZFxuICAgICAgICAgIHJlc29sdmUobnVsbCk7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKG9wdGlvbnMuaW5jbHVkZXMocmVzdWx0KSkge1xuICAgICAgICAgIHJlc29sdmUocmVzdWx0KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBuZXcgTm90aWNlKGBQbGVhc2Ugc2VsZWN0IG9uZSBvZjogJHtvcHRpb25zLmpvaW4oXCIsIFwiKX1gKTtcbiAgICAgICAgICAvLyBSZWN1cnNpdmVseSBjYWxsIGFnYWluIGlmIGNob2ljZSBpcyBpbnZhbGlkXG4gICAgICAgICAgdGhpcy5wcm9tcHRXaXRoT3B0aW9ucyh0aXRsZSwgbWVzc2FnZSwgb3B0aW9ucylcbiAgICAgICAgICAgIC50aGVuKHJlc29sdmUpO1xuICAgICAgICB9XG4gICAgICB9KTtcblxuICAgICAgLy8gU2V0IHRoZSB0aXRsZVxuICAgICAgbW9kYWwudGl0bGVFbC5zZXRUZXh0KHRpdGxlKTtcbiAgICAgIGNvbnN0IG1lc3NhZ2VFbCA9IG1vZGFsLmNvbnRlbnRFbC5jcmVhdGVEaXYoKTtcbiAgICAgIG1lc3NhZ2VFbC5zZXRUZXh0KG1lc3NhZ2UpO1xuXG4gICAgICBtb2RhbC5vcGVuKCk7XG4gICAgfSk7XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIGNyZWF0ZUNvdXJzZUZvbGRlclN0cnVjdHVyZShjb3Vyc2VEZXRhaWxzOiB7XG4gICAgY291cnNlTmFtZTogc3RyaW5nXG4gICAgY291cnNlU2Vhc29uOiBzdHJpbmdcbiAgICBjb3Vyc2VZZWFyOiBzdHJpbmdcbiAgICBjb3Vyc2VJZDogc3RyaW5nXG4gIH0pOiBQcm9taXNlPHN0cmluZz4ge1xuICAgIGNvbnN0IGZvbGRlclBhdGggPSBgJHtjb3Vyc2VEZXRhaWxzLmNvdXJzZVllYXJ9LyR7Y291cnNlRGV0YWlscy5jb3Vyc2VTZWFzb259LyR7Y291cnNlRGV0YWlscy5jb3Vyc2VOYW1lfWBcblxuICAgIHRyeSB7XG4gICAgICBhd2FpdCB0aGlzLmFwcC52YXVsdC5jcmVhdGVGb2xkZXIoZm9sZGVyUGF0aClcbiAgICAgIGNvbnNvbGUubG9nKGBDcmVhdGVkIGNvdXJzZSBmb2xkZXI6ICR7Zm9sZGVyUGF0aH1gKVxuICAgICAgcmV0dXJuIGZvbGRlclBhdGhcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgLy8gRm9sZGVyIG1pZ2h0IGFscmVhZHkgZXhpc3QsIHdoaWNoIGlzIGZpbmUgZm9yIG5vd1xuICAgICAgY29uc29sZS5sb2coYENvdXJzZSBmb2xkZXIgYWxyZWFkeSBleGlzdHMgb3IgY3JlYXRlZDogJHtmb2xkZXJQYXRofWApXG4gICAgICByZXR1cm4gZm9sZGVyUGF0aFxuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgY3JlYXRlQ291cnNlSG9tZXBhZ2VOb3RlKFxuICAgIGNvdXJzZURldGFpbHM6IHtcbiAgICAgIGNvdXJzZU5hbWU6IHN0cmluZ1xuICAgICAgY291cnNlU2Vhc29uOiBzdHJpbmdcbiAgICAgIGNvdXJzZVllYXI6IHN0cmluZ1xuICAgICAgY291cnNlSWQ6IHN0cmluZ1xuICAgIH0sXG4gICAgZm9sZGVyUGF0aDogc3RyaW5nXG4gICk6IFByb21pc2U8dm9pZD4ge1xuICAgIGNvbnN0IG5vdGVQYXRoID0gYCR7Zm9sZGVyUGF0aH0vJHtjb3Vyc2VEZXRhaWxzLmNvdXJzZU5hbWV9Lm1kYFxuICAgIGNvbnN0IGNvbnRlbnQgPSB0aGlzLmdlbmVyYXRlQ291cnNlSG9tZXBhZ2VDb250ZW50KGNvdXJzZURldGFpbHMpXG5cbiAgICB0cnkge1xuICAgICAgYXdhaXQgdGhpcy5hcHAudmF1bHQuY3JlYXRlKG5vdGVQYXRoLCBjb250ZW50KVxuICAgICAgY29uc29sZS5sb2coYENyZWF0ZWQgY291cnNlIGhvbWVwYWdlOiAke25vdGVQYXRofWApXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIGNyZWF0aW5nIGNvdXJzZSBob21lcGFnZTogJHtlcnJvcn1gKVxuICAgICAgdGhyb3cgZXJyb3JcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIGNyZWF0ZUF0dGFjaG1lbnRzRm9sZGVyKGZvbGRlclBhdGg6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICAgIGNvbnN0IGF0dGFjaG1lbnRzUGF0aCA9IGAke2ZvbGRlclBhdGh9L0F0dGFjaG1lbnRzYFxuXG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IHRoaXMuYXBwLnZhdWx0LmNyZWF0ZUZvbGRlcihhdHRhY2htZW50c1BhdGgpXG4gICAgICBjb25zb2xlLmxvZyhgQ3JlYXRlZCBhdHRhY2htZW50cyBmb2xkZXI6ICR7YXR0YWNobWVudHNQYXRofWApXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIC8vIEZvbGRlciBtaWdodCBhbHJlYWR5IGV4aXN0LCB3aGljaCBpcyBmaW5lXG4gICAgICBjb25zb2xlLmxvZyhgQXR0YWNobWVudHMgZm9sZGVyIGFscmVhZHkgZXhpc3RzOiAke2F0dGFjaG1lbnRzUGF0aH1gKVxuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgZ2VuZXJhdGVDb3Vyc2VIb21lcGFnZUNvbnRlbnQoY291cnNlRGV0YWlsczoge1xuICAgIGNvdXJzZU5hbWU6IHN0cmluZ1xuICAgIGNvdXJzZVNlYXNvbjogc3RyaW5nXG4gICAgY291cnNlWWVhcjogc3RyaW5nXG4gICAgY291cnNlSWQ6IHN0cmluZ1xuICB9KTogc3RyaW5nIHtcbiAgICAvLyBVc2UgdGhlIHRlbXBsYXRlTWFuYWdlciB0byBnZXQgdGhlIHRlbXBsYXRlIGNvbnRlbnQgYW5kIHJlcGxhY2UgdmFsdWVzXG4gICAgY29uc3QgdGVtcGxhdGVNYW5hZ2VyID0gbmV3IFRlbXBsYXRlTWFuYWdlcih0aGlzLmFwcCwgdGhpcy5zZXR0aW5ncyk7XG4gICAgY29uc3QgdGVtcGxhdGVDb250ZW50ID0gdGVtcGxhdGVNYW5hZ2VyLmdlbmVyYXRlQ291cnNlSG9tZXBhZ2VUZW1wbGF0ZSgpO1xuICAgIFxuICAgIC8vIFJlcGxhY2UgdGVtcGxhdGUgdmFyaWFibGVzIHdpdGggYWN0dWFsIHZhbHVlc1xuICAgIHJldHVybiB0ZW1wbGF0ZUNvbnRlbnRcbiAgICAgIC5yZXBsYWNlKC88JSBjb3Vyc2VOYW1lICU+L2csIGNvdXJzZURldGFpbHMuY291cnNlTmFtZSlcbiAgICAgIC5yZXBsYWNlKC88JSBjb3Vyc2VTZWFzb24gJT4vZywgY291cnNlRGV0YWlscy5jb3Vyc2VTZWFzb24pXG4gICAgICAucmVwbGFjZSgvPCUgY291cnNlWWVhciAlPi9nLCBjb3Vyc2VEZXRhaWxzLmNvdXJzZVllYXIpXG4gICAgICAucmVwbGFjZSgvPCUgY291cnNlSWQgJT4vZywgY291cnNlRGV0YWlscy5jb3Vyc2VJZClcbiAgICAgIC5yZXBsYWNlKC88JSB0cFxcLmRhdGVcXC5ub3dcXChcIllZWVktTU0tRERcXFtUXFxdSEg6bW06c3NaXCJcXCkgJT4vZywgbmV3IERhdGUoKS50b0lTT1N0cmluZygpKVxuICAgICAgLnJlcGxhY2UoLzwlIHRwXFwuZGF0ZVxcLm5vd1xcKFwiWVlZWS1NTS1ERFxcW1RcXF1oaDptbTpTU1NTWlpcIlxcKSAlPi9nLCBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkpO1xuICB9XG59XG4iLCAiaW1wb3J0IHsgQXBwLCBNb2RhbCwgU2V0dGluZyB9IGZyb20gXCJvYnNpZGlhblwiO1xuXG5leHBvcnQgY2xhc3MgSW5wdXRNb2RhbCBleHRlbmRzIE1vZGFsIHtcbiAgcmVzdWx0OiBzdHJpbmcgfCBudWxsO1xuICBvblN1Ym1pdDogKHJlc3VsdDogc3RyaW5nIHwgbnVsbCkgPT4gdm9pZDtcblxuICBjb25zdHJ1Y3RvcihhcHA6IEFwcCwgb25TdWJtaXQ6IChyZXN1bHQ6IHN0cmluZyB8IG51bGwpID0+IHZvaWQpIHtcbiAgICBzdXBlcihhcHApO1xuICAgIHRoaXMub25TdWJtaXQgPSBvblN1Ym1pdDtcbiAgfVxuXG4gIG9uT3BlbigpIHtcbiAgICBjb25zdCB7IGNvbnRlbnRFbCB9ID0gdGhpcztcblxuICAgIGNvbnRlbnRFbC5jcmVhdGVFbChcImgyXCIsIHsgdGV4dDogXCJFbnRlciBWYWx1ZVwiIH0pO1xuXG4gICAgbmV3IFNldHRpbmcoY29udGVudEVsKVxuICAgICAgLnNldE5hbWUoXCJWYWx1ZVwiKVxuICAgICAgLmFkZFRleHQoKHRleHQpID0+IFxuICAgICAgICB0ZXh0XG4gICAgICAgICAgLm9uQ2hhbmdlKCh2YWx1ZSkgPT4ge1xuICAgICAgICAgICAgdGhpcy5yZXN1bHQgPSB2YWx1ZTtcbiAgICAgICAgICB9KVxuICAgICAgICAgIC5pbnB1dEVsLmZvY3VzKClcbiAgICAgICk7XG5cbiAgICBuZXcgU2V0dGluZyhjb250ZW50RWwpXG4gICAgICAuYWRkQnV0dG9uKChidG4pID0+XG4gICAgICAgIGJ0blxuICAgICAgICAgIC5zZXRCdXR0b25UZXh0KFwiU3VibWl0XCIpXG4gICAgICAgICAgLnNldEN0YSgpXG4gICAgICAgICAgLm9uQ2xpY2soKCkgPT4ge1xuICAgICAgICAgICAgdGhpcy5jbG9zZSgpO1xuICAgICAgICAgICAgdGhpcy5vblN1Ym1pdCh0aGlzLnJlc3VsdCB8fCBcIlwiKTtcbiAgICAgICAgICB9KVxuICAgICAgKVxuICAgICAgLmFkZEJ1dHRvbigoYnRuKSA9PlxuICAgICAgICBidG4uc2V0QnV0dG9uVGV4dChcIkNhbmNlbFwiKS5vbkNsaWNrKCgpID0+IHtcbiAgICAgICAgICB0aGlzLmNsb3NlKCk7XG4gICAgICAgICAgdGhpcy5vblN1Ym1pdChudWxsKTtcbiAgICAgICAgfSlcbiAgICAgICk7XG4gIH1cblxuICBvbkNsb3NlKCkge1xuICAgIGNvbnN0IHsgY29udGVudEVsIH0gPSB0aGlzO1xuICAgIGNvbnRlbnRFbC5lbXB0eSgpO1xuICB9XG59XG5cbmV4cG9ydCBjbGFzcyBTdWdnZXN0ZXJNb2RhbCBleHRlbmRzIE1vZGFsIHtcbiAgcmVzdWx0OiBzdHJpbmcgfCBudWxsO1xuICBvblN1Ym1pdDogKHJlc3VsdDogc3RyaW5nIHwgbnVsbCkgPT4gdm9pZDtcblxuICBjb25zdHJ1Y3RvcihhcHA6IEFwcCwgb3B0aW9uczogc3RyaW5nW10sIG9uU3VibWl0OiAocmVzdWx0OiBzdHJpbmcgfCBudWxsKSA9PiB2b2lkKSB7XG4gICAgc3VwZXIoYXBwKTtcbiAgICB0aGlzLm9uU3VibWl0ID0gb25TdWJtaXQ7XG5cbiAgICAvLyBDcmVhdGUgYSBkcm9wZG93biB3aXRoIHRoZSBwcm92aWRlZCBvcHRpb25zXG4gICAgY29uc3QgZHJvcGRvd25PcHRpb25zOiB7IFtrZXk6IHN0cmluZ106IHN0cmluZyB9ID0ge307XG4gICAgb3B0aW9ucy5mb3JFYWNoKG9wdGlvbiA9PiB7XG4gICAgICBkcm9wZG93bk9wdGlvbnNbb3B0aW9uXSA9IG9wdGlvbjtcbiAgICB9KTtcbiAgICBcbiAgICB0aGlzLmNyZWF0ZURyb3Bkb3duKGRyb3Bkb3duT3B0aW9ucyk7XG4gIH1cblxuICBjcmVhdGVEcm9wZG93bihvcHRpb25zOiB7IFtrZXk6IHN0cmluZ106IHN0cmluZyB9KSB7XG4gICAgY29uc3QgeyBjb250ZW50RWwgfSA9IHRoaXM7XG5cbiAgICBjb250ZW50RWwuY3JlYXRlRWwoXCJoMlwiLCB7IHRleHQ6IFwiU2VsZWN0IE9wdGlvblwiIH0pO1xuXG4gICAgbGV0IHNlbGVjdGVkVmFsdWUgPSBPYmplY3Qua2V5cyhvcHRpb25zKVswXSB8fCBudWxsOyAvLyBEZWZhdWx0IHRvIGZpcnN0IG9wdGlvbiBvciBudWxsXG5cbiAgICBjb25zdCBkcm9wZG93biA9IGNvbnRlbnRFbC5jcmVhdGVFbChcInNlbGVjdFwiKTtcbiAgICBPYmplY3QuZW50cmllcyhvcHRpb25zKS5mb3JFYWNoKChba2V5LCB2YWx1ZV0pID0+IHtcbiAgICAgIGNvbnN0IG9wdGlvbiA9IGRyb3Bkb3duLmNyZWF0ZUVsKFwib3B0aW9uXCIsIHtcbiAgICAgICAgdmFsdWU6IGtleSxcbiAgICAgICAgdGV4dDogdmFsdWVcbiAgICAgIH0pO1xuICAgICAgaWYgKGtleSA9PT0gc2VsZWN0ZWRWYWx1ZSkge1xuICAgICAgICBvcHRpb24uc2VsZWN0ZWQgPSB0cnVlO1xuICAgICAgfVxuICAgIH0pO1xuXG4gICAgZHJvcGRvd24uYWRkRXZlbnRMaXN0ZW5lcihcImNoYW5nZVwiLCAoZXZlbnQpID0+IHtcbiAgICAgIHNlbGVjdGVkVmFsdWUgPSAoZXZlbnQudGFyZ2V0IGFzIEhUTUxTZWxlY3RFbGVtZW50KS52YWx1ZTtcbiAgICAgIHRoaXMucmVzdWx0ID0gc2VsZWN0ZWRWYWx1ZTtcbiAgICB9KTtcblxuICAgIG5ldyBTZXR0aW5nKGNvbnRlbnRFbClcbiAgICAgIC5hZGRCdXR0b24oKGJ0bikgPT5cbiAgICAgICAgYnRuXG4gICAgICAgICAgLnNldEJ1dHRvblRleHQoXCJTdWJtaXRcIilcbiAgICAgICAgICAuc2V0Q3RhKClcbiAgICAgICAgICAub25DbGljaygoKSA9PiB7XG4gICAgICAgICAgICB0aGlzLmNsb3NlKCk7XG4gICAgICAgICAgICB0aGlzLm9uU3VibWl0KHNlbGVjdGVkVmFsdWUpO1xuICAgICAgICAgIH0pXG4gICAgICApXG4gICAgICAuYWRkQnV0dG9uKChidG4pID0+XG4gICAgICAgIGJ0bi5zZXRCdXR0b25UZXh0KFwiQ2FuY2VsXCIpLm9uQ2xpY2soKCkgPT4ge1xuICAgICAgICAgIHRoaXMuY2xvc2UoKTtcbiAgICAgICAgICB0aGlzLm9uU3VibWl0KG51bGwpO1xuICAgICAgICB9KVxuICAgICAgKTtcbiAgfVxuXG4gIG9uT3BlbigpIHtcbiAgICAvLyBUaGUgZHJvcGRvd24gaXMgYWxyZWFkeSBjcmVhdGVkIGluIGNvbnN0cnVjdG9yXG4gIH1cblxuICBvbkNsb3NlKCkge1xuICAgIGNvbnN0IHsgY29udGVudEVsIH0gPSB0aGlzO1xuICAgIGNvbnRlbnRFbC5lbXB0eSgpO1xuICB9XG59IiwgIi8vIFZvY2FidWxhcnkgZXh0cmFjdGlvbiBmb3IgVHVja2VycyBUb29scyBwbHVnaW5cblxuaW1wb3J0IHsgQXBwLCBURmlsZSB9IGZyb20gXCJvYnNpZGlhblwiXG5pbXBvcnQgeyBnZXRDb3Vyc2VJZEZyb21QYXRoIH0gZnJvbSBcIi4vdXRpbHNcIlxuXG5leHBvcnQgY2xhc3MgVm9jYWJ1bGFyeUV4dHJhY3RvciB7XG4gIGFwcDogQXBwXG5cbiAgY29uc3RydWN0b3IoYXBwOiBBcHApIHtcbiAgICB0aGlzLmFwcCA9IGFwcFxuICB9XG5cbiAgZXh0cmFjdFZvY2FidWxhcnlGcm9tTm90ZShjb250ZW50OiBzdHJpbmcpOiBzdHJpbmdbXSB7XG4gICAgLy8gRXh0cmFjdCB2b2NhYnVsYXJ5IHNlY3Rpb24gZnJvbSBub3RlIGNvbnRlbnRcbiAgICBjb25zdCB2b2NhYlJlZ2V4ID0gL14jKyBWb2NhYnVsYXJ5LipcXG4oKD86Lio/XFxuKSo/KSg/PV5cXHMqI1xcc3wkKS9tXG4gICAgY29uc3Qgdm9jYWJNYXRjaGVzID0gY29udGVudD8ubWF0Y2godm9jYWJSZWdleClcblxuICAgIGlmICh2b2NhYk1hdGNoZXMpIHtcbiAgICAgIGNvbnN0IHZvY2FiRGF0YSA9IHZvY2FiTWF0Y2hlc1sxXS50cmltKClcbiAgICAgIGNvbnN0IGNsZWFuZWRWb2NhYiA9IHZvY2FiRGF0YVxuICAgICAgICAucmVwbGFjZSgvXFxbXFxbLio/XFxdXFxdL2csIFwiXCIpIC8vIFJlbW92ZSB3aWtpbGlua3NcbiAgICAgICAgLnJlcGxhY2UoL15cXHMqLVxccyovZ20sIFwiXCIpIC8vIFJlbW92ZSBidWxsZXQgcG9pbnRzXG4gICAgICAgIC5zcGxpdChcIlxcblwiKVxuICAgICAgICAubWFwKCh0ZXJtKSA9PiB0ZXJtLnRyaW0oKSlcbiAgICAgICAgLmZpbHRlcigodGVybSkgPT4gdGVybS5sZW5ndGggPiAwKVxuXG4gICAgICByZXR1cm4gY2xlYW5lZFZvY2FiXG4gICAgfVxuXG4gICAgcmV0dXJuIFtdXG4gIH1cblxuICBhc3luYyBleHRyYWN0Vm9jYWJ1bGFyeUZyb21Db3Vyc2UoXG4gICAgY291cnNlSWQ6IHN0cmluZ1xuICApOiBQcm9taXNlPFJlY29yZDxzdHJpbmcsIHN0cmluZ1tdPj4ge1xuICAgIGNvbnNvbGUubG9nKGBFeHRyYWN0aW5nIHZvY2FidWxhcnkgZm9yIGNvdXJzZTogJHtjb3Vyc2VJZH1gKVxuXG4gICAgdHJ5IHtcbiAgICAgIC8vIEZpbmQgYWxsIG5vdGVzIHJlbGF0ZWQgdG8gdGhlIGNvdXJzZVxuICAgICAgY29uc3QgY291cnNlTm90ZXMgPSBhd2FpdCB0aGlzLmZpbmRDb3Vyc2VOb3Rlcyhjb3Vyc2VJZClcblxuICAgICAgaWYgKGNvdXJzZU5vdGVzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICBjb25zb2xlLmxvZyhgTm8gbm90ZXMgZm91bmQgZm9yIGNvdXJzZTogJHtjb3Vyc2VJZH1gKVxuICAgICAgICByZXR1cm4ge31cbiAgICAgIH1cblxuICAgICAgLy8gRXh0cmFjdCB2b2NhYnVsYXJ5IGZyb20gZWFjaCBub3RlXG4gICAgICBjb25zdCB2b2NhYnVsYXJ5RGF0YTogUmVjb3JkPHN0cmluZywgc3RyaW5nW10+ID0ge31cblxuICAgICAgZm9yIChjb25zdCBub3RlIG9mIGNvdXJzZU5vdGVzKSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgY29uc3QgY29udGVudCA9IGF3YWl0IHRoaXMuYXBwLnZhdWx0LnJlYWQobm90ZSlcbiAgICAgICAgICBjb25zdCB2b2NhYnVsYXJ5ID0gdGhpcy5leHRyYWN0Vm9jYWJ1bGFyeUZyb21Ob3RlKGNvbnRlbnQpXG5cbiAgICAgICAgICBpZiAodm9jYWJ1bGFyeS5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICB2b2NhYnVsYXJ5RGF0YVtub3RlLmJhc2VuYW1lXSA9IHZvY2FidWxhcnlcbiAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgY29uc29sZS5lcnJvcihgRXJyb3IgcmVhZGluZyBub3RlICR7bm90ZS5wYXRofTpgLCBlcnJvcilcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICBjb25zb2xlLmxvZyhcbiAgICAgICAgYEV4dHJhY3RlZCB2b2NhYnVsYXJ5IGZyb20gJHtcbiAgICAgICAgICBPYmplY3Qua2V5cyh2b2NhYnVsYXJ5RGF0YSkubGVuZ3RoXG4gICAgICAgIH0gbm90ZXMgZm9yIGNvdXJzZTogJHtjb3Vyc2VJZH1gXG4gICAgICApXG4gICAgICByZXR1cm4gdm9jYWJ1bGFyeURhdGFcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihcbiAgICAgICAgYEVycm9yIGV4dHJhY3Rpbmcgdm9jYWJ1bGFyeSBmb3IgY291cnNlICR7Y291cnNlSWR9OmAsXG4gICAgICAgIGVycm9yXG4gICAgICApXG4gICAgICByZXR1cm4ge31cbiAgICB9XG4gIH1cblxuICBhc3luYyBmaW5kQ291cnNlTm90ZXMoY291cnNlSWQ6IHN0cmluZyk6IFByb21pc2U8VEZpbGVbXT4ge1xuICAgIGNvbnN0IG5vdGVzOiBURmlsZVtdID0gW11cblxuICAgIC8vIEdldCBhbGwgbWFya2Rvd24gZmlsZXMgaW4gdGhlIHZhdWx0XG4gICAgY29uc3QgZmlsZXMgPSB0aGlzLmFwcC52YXVsdC5nZXRNYXJrZG93bkZpbGVzKClcblxuICAgIGZvciAoY29uc3QgZmlsZSBvZiBmaWxlcykge1xuICAgICAgLy8gQ2hlY2sgaWYgdGhlIGZpbGUgcGF0aCBjb250YWlucyB0aGUgY291cnNlIElEXG4gICAgICBpZiAoXG4gICAgICAgIGZpbGUucGF0aC5pbmNsdWRlcyhjb3Vyc2VJZCkgfHxcbiAgICAgICAgKGF3YWl0IHRoaXMubm90ZUJlbG9uZ3NUb0NvdXJzZShmaWxlLCBjb3Vyc2VJZCkpXG4gICAgICApIHtcbiAgICAgICAgbm90ZXMucHVzaChmaWxlKVxuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBub3Rlc1xuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBub3RlQmVsb25nc1RvQ291cnNlKFxuICAgIGZpbGU6IFRGaWxlLFxuICAgIGNvdXJzZUlkOiBzdHJpbmdcbiAgKTogUHJvbWlzZTxib29sZWFuPiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGNvbnRlbnQgPSBhd2FpdCB0aGlzLmFwcC52YXVsdC5yZWFkKGZpbGUpXG4gICAgICBjb25zdCBmcm9udG1hdHRlck1hdGNoID0gY29udGVudC5tYXRjaCgvXi0tLVxcbihbXFxzXFxTXSo/KVxcbi0tLS8pXG5cbiAgICAgIGlmIChmcm9udG1hdHRlck1hdGNoKSB7XG4gICAgICAgIGNvbnN0IGZyb250bWF0dGVyID0gZnJvbnRtYXR0ZXJNYXRjaFsxXVxuICAgICAgICAvLyBDaGVjayBpZiBjb3Vyc2VfaWQgaXMgaW4gdGhlIGZyb250bWF0dGVyXG4gICAgICAgIHJldHVybiAoXG4gICAgICAgICAgZnJvbnRtYXR0ZXIuaW5jbHVkZXMoYGNvdXJzZV9pZDogJHtjb3Vyc2VJZH1gKSB8fFxuICAgICAgICAgIGZyb250bWF0dGVyLmluY2x1ZGVzKGBjb3Vyc2VfaWQ6JHtjb3Vyc2VJZH1gKVxuICAgICAgICApXG4gICAgICB9XG5cbiAgICAgIHJldHVybiBmYWxzZVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFxuICAgICAgICBgRXJyb3IgY2hlY2tpbmcgaWYgbm90ZSAke2ZpbGUucGF0aH0gYmVsb25ncyB0byBjb3Vyc2UgJHtjb3Vyc2VJZH06YCxcbiAgICAgICAgZXJyb3JcbiAgICAgIClcbiAgICAgIHJldHVybiBmYWxzZVxuICAgIH1cbiAgfVxuXG4gIGFzeW5jIGdlbmVyYXRlVm9jYWJ1bGFyeUluZGV4KFxuICAgIGNvdXJzZUlkOiBzdHJpbmcsXG4gICAgdm9jYWJ1bGFyeURhdGE6IFJlY29yZDxzdHJpbmcsIHN0cmluZ1tdPlxuICApOiBQcm9taXNlPHN0cmluZz4ge1xuICAgIGNvbnN0IGFsbFRlcm1zOiBzdHJpbmdbXSA9IFtdXG4gICAgY29uc3QgdGVybVNvdXJjZXM6IFJlY29yZDxzdHJpbmcsIHN0cmluZ1tdPiA9IHt9XG5cbiAgICAvLyBDb2xsZWN0IGFsbCB1bmlxdWUgdGVybXMgYW5kIHRoZWlyIHNvdXJjZXNcbiAgICBmb3IgKGNvbnN0IFtub3RlTmFtZSwgdGVybXNdIG9mIE9iamVjdC5lbnRyaWVzKHZvY2FidWxhcnlEYXRhKSkge1xuICAgICAgZm9yIChjb25zdCB0ZXJtIG9mIHRlcm1zKSB7XG4gICAgICAgIGlmICghYWxsVGVybXMuaW5jbHVkZXModGVybSkpIHtcbiAgICAgICAgICBhbGxUZXJtcy5wdXNoKHRlcm0pXG4gICAgICAgICAgdGVybVNvdXJjZXNbdGVybV0gPSBbXVxuICAgICAgICB9XG4gICAgICAgIHRlcm1Tb3VyY2VzW3Rlcm1dLnB1c2gobm90ZU5hbWUpXG4gICAgICB9XG4gICAgfVxuXG4gICAgLy8gU29ydCB0ZXJtcyBhbHBoYWJldGljYWxseVxuICAgIGFsbFRlcm1zLnNvcnQoKVxuXG4gICAgLy8gR2VuZXJhdGUgbWFya2Rvd24gY29udGVudFxuICAgIGxldCBjb250ZW50ID0gYCMgVm9jYWJ1bGFyeSBJbmRleCAtICR7Y291cnNlSWR9XFxuXFxuYFxuICAgIGNvbnRlbnQgKz0gYFRvdGFsIHVuaXF1ZSB0ZXJtczogJHthbGxUZXJtcy5sZW5ndGh9XFxuXFxuYFxuXG4gICAgZm9yIChjb25zdCB0ZXJtIG9mIGFsbFRlcm1zKSB7XG4gICAgICBjb250ZW50ICs9IGAjIyAke3Rlcm19XFxuYFxuICAgICAgY29udGVudCArPSBgKipTb3VyY2VzOioqICR7dGVybVNvdXJjZXNbdGVybV0uam9pbihcIiwgXCIpfVxcblxcbmBcbiAgICAgIGNvbnRlbnQgKz0gYCoqRGVmaW5pdGlvbjoqKlxcblxcbmBcbiAgICAgIGNvbnRlbnQgKz0gYCoqQ29udGV4dDoqKlxcblxcbmBcbiAgICAgIGNvbnRlbnQgKz0gYCoqRXhhbXBsZXM6KipcXG5cXG5gXG4gICAgICBjb250ZW50ICs9IGAtLS1cXG5cXG5gXG4gICAgfVxuXG4gICAgcmV0dXJuIGNvbnRlbnRcbiAgfVxuXG4gIGFzeW5jIGNyZWF0ZVZvY2FidWxhcnlJbmRleEZpbGUoY291cnNlSWQ6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB2b2NhYnVsYXJ5RGF0YSA9IGF3YWl0IHRoaXMuZXh0cmFjdFZvY2FidWxhcnlGcm9tQ291cnNlKGNvdXJzZUlkKVxuXG4gICAgICBpZiAoT2JqZWN0LmtleXModm9jYWJ1bGFyeURhdGEpLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICBjb25zb2xlLmxvZyhgTm8gdm9jYWJ1bGFyeSBmb3VuZCBmb3IgY291cnNlOiAke2NvdXJzZUlkfWApXG4gICAgICAgIHJldHVyblxuICAgICAgfVxuXG4gICAgICBjb25zdCBpbmRleENvbnRlbnQgPSBhd2FpdCB0aGlzLmdlbmVyYXRlVm9jYWJ1bGFyeUluZGV4KFxuICAgICAgICBjb3Vyc2VJZCxcbiAgICAgICAgdm9jYWJ1bGFyeURhdGFcbiAgICAgIClcblxuICAgICAgLy8gQ3JlYXRlIHRoZSBpbmRleCBmaWxlXG4gICAgICBjb25zdCBmaWxlTmFtZSA9IGAke2NvdXJzZUlkfSAtIFZvY2FidWxhcnkgSW5kZXgubWRgXG4gICAgICBjb25zdCBmaWxlUGF0aCA9IGBDb3Vyc2VzLyR7Y291cnNlSWR9LyR7ZmlsZU5hbWV9YFxuXG4gICAgICB0cnkge1xuICAgICAgICBhd2FpdCB0aGlzLmFwcC52YXVsdC5jcmVhdGUoZmlsZVBhdGgsIGluZGV4Q29udGVudClcbiAgICAgICAgY29uc29sZS5sb2coYENyZWF0ZWQgdm9jYWJ1bGFyeSBpbmRleCBmaWxlOiAke2ZpbGVQYXRofWApXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAvLyBGaWxlIG1pZ2h0IGFscmVhZHkgZXhpc3QsIHRyeSB0byB1cGRhdGUgaXRcbiAgICAgICAgY29uc3QgZXhpc3RpbmdGaWxlID0gdGhpcy5hcHAudmF1bHQuZ2V0QWJzdHJhY3RGaWxlQnlQYXRoKGZpbGVQYXRoKVxuICAgICAgICBpZiAoZXhpc3RpbmdGaWxlICYmIGV4aXN0aW5nRmlsZSBpbnN0YW5jZW9mIFRGaWxlKSB7XG4gICAgICAgICAgYXdhaXQgdGhpcy5hcHAudmF1bHQubW9kaWZ5KGV4aXN0aW5nRmlsZSwgaW5kZXhDb250ZW50KVxuICAgICAgICAgIGNvbnNvbGUubG9nKGBVcGRhdGVkIHZvY2FidWxhcnkgaW5kZXggZmlsZTogJHtmaWxlUGF0aH1gKVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXG4gICAgICAgIGBFcnJvciBjcmVhdGluZyB2b2NhYnVsYXJ5IGluZGV4IGZvciBjb3Vyc2UgJHtjb3Vyc2VJZH06YCxcbiAgICAgICAgZXJyb3JcbiAgICAgIClcbiAgICAgIHRocm93IGVycm9yXG4gICAgfVxuICB9XG59XG4iLCAiaW1wb3J0IHsgQXBwLCBURmlsZSB9IGZyb20gXCJvYnNpZGlhblwiXG5pbXBvcnQgeyBpc0JldHdlZW4gfSBmcm9tIFwiLi91dGlsc1wiXG5cbmV4cG9ydCBjbGFzcyBEdWVEYXRlc1BhcnNlciB7XG4gIGFwcDogQXBwXG5cbiAgY29uc3RydWN0b3IoYXBwOiBBcHApIHtcbiAgICB0aGlzLmFwcCA9IGFwcFxuICB9XG5cbiAgcGFyc2VEdWVEYXRlc0Zyb21Ob3RlKFxuICAgIGNvbnRlbnQ6IHN0cmluZ1xuICApOiBBcnJheTx7IGRhdGU6IHN0cmluZzsgYXNzaWdubWVudDogc3RyaW5nOyBzdGF0dXM6IHN0cmluZyB9PiB7XG4gICAgLy8gRXh0cmFjdCBkdWUgZGF0ZXMgc2VjdGlvbiBmcm9tIG5vdGUgY29udGVudFxuICAgIGNvbnN0IGR1ZURhdGVzUmVnZXggPSAvIyBEdWUgRGF0ZXNbXFxzXFxTXSo/KD89XFxuI3wkKS9cbiAgICBjb25zdCBtYXRjaGVzID0gY29udGVudD8ubWF0Y2goZHVlRGF0ZXNSZWdleClcblxuICAgIGlmICghbWF0Y2hlcykge1xuICAgICAgcmV0dXJuIFtdXG4gICAgfVxuXG4gICAgY29uc3QgZHVlRGF0ZXNTZWN0aW9uID0gbWF0Y2hlc1swXVxuICAgIGNvbnN0IGR1ZURhdGVzID0gW11cblxuICAgIC8vIExvb2sgZm9yIG1hcmtkb3duIHRhYmxlcyBpbiB0aGUgZHVlIGRhdGVzIHNlY3Rpb25cbiAgICBjb25zdCB0YWJsZVJlZ2V4ID0gL1xcfFtcXHNcXFNdKj9cXG4vZ1xuICAgIGNvbnN0IHRhYmxlTWF0Y2hlcyA9IGR1ZURhdGVzU2VjdGlvbi5tYXRjaCh0YWJsZVJlZ2V4KVxuXG4gICAgaWYgKHRhYmxlTWF0Y2hlcykge1xuICAgICAgZm9yIChjb25zdCB0YWJsZSBvZiB0YWJsZU1hdGNoZXMpIHtcbiAgICAgICAgY29uc3Qgcm93cyA9IHRhYmxlXG4gICAgICAgICAgLnRyaW0oKVxuICAgICAgICAgIC5zcGxpdChcIlxcblwiKVxuICAgICAgICAgIC5maWx0ZXIoKHJvdykgPT4gcm93LnN0YXJ0c1dpdGgoXCJ8XCIpKVxuICAgICAgICBjb25zdCBwYXJzZWRSb3dzID0gdGhpcy5wYXJzZVRhYmxlUm93cyhyb3dzKVxuICAgICAgICBkdWVEYXRlcy5wdXNoKC4uLnBhcnNlZFJvd3MpXG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIGR1ZURhdGVzXG4gIH1cblxuICBwcml2YXRlIHBhcnNlVGFibGVSb3dzKFxuICAgIHJvd3M6IHN0cmluZ1tdXG4gICk6IEFycmF5PHsgZGF0ZTogc3RyaW5nOyBhc3NpZ25tZW50OiBzdHJpbmc7IHN0YXR1czogc3RyaW5nIH0+IHtcbiAgICBpZiAocm93cy5sZW5ndGggPCAyKSByZXR1cm4gW10gLy8gTmVlZCBhdCBsZWFzdCBoZWFkZXIgKyAxIGRhdGEgcm93XG5cbiAgICBjb25zdCBkdWVEYXRlcyA9IFtdXG5cbiAgICBmb3IgKGxldCBpID0gMTsgaSA8IHJvd3MubGVuZ3RoOyBpKyspIHtcbiAgICAgIC8vIFNraXAgaGVhZGVyIHJvd1xuICAgICAgY29uc3Qgcm93ID0gcm93c1tpXVxuICAgICAgY29uc3QgY29sdW1ucyA9IHJvd1xuICAgICAgICAuc3BsaXQoXCJ8XCIpXG4gICAgICAgIC5tYXAoKGNvbCkgPT4gY29sLnRyaW0oKSlcbiAgICAgICAgLmZpbHRlcigoY29sKSA9PiBjb2wpXG5cbiAgICAgIGlmIChjb2x1bW5zLmxlbmd0aCA+PSAyKSB7XG4gICAgICAgIGNvbnN0IFtkYXRlLCBhc3NpZ25tZW50LCBzdGF0dXMgPSBcInBlbmRpbmdcIl0gPSBjb2x1bW5zXG4gICAgICAgIGlmIChkYXRlICYmIGFzc2lnbm1lbnQgJiYgdGhpcy5pc1ZhbGlkRGF0ZShkYXRlKSkge1xuICAgICAgICAgIGR1ZURhdGVzLnB1c2goeyBkYXRlLCBhc3NpZ25tZW50LCBzdGF0dXMgfSlcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBkdWVEYXRlc1xuICB9XG5cbiAgcHJpdmF0ZSBpc1ZhbGlkRGF0ZShkYXRlU3RyaW5nOiBzdHJpbmcpOiBib29sZWFuIHtcbiAgICBjb25zdCBkYXRlUmVnZXggPSAvXlxcZHs0fS1cXGR7Mn0tXFxkezJ9JC9cbiAgICByZXR1cm4gZGF0ZVJlZ2V4LnRlc3QoZGF0ZVN0cmluZykgJiYgIWlzTmFOKERhdGUucGFyc2UoZGF0ZVN0cmluZykpXG4gIH1cblxuICBhc3luYyBwYXJzZUR1ZURhdGVzRnJvbUNvdXJzZShcbiAgICBjb3Vyc2VJZDogc3RyaW5nLFxuICAgIHN0YXJ0RGF0ZT86IHN0cmluZyxcbiAgICBlbmREYXRlPzogc3RyaW5nXG4gICk6IFByb21pc2U8XG4gICAgQXJyYXk8eyBkYXRlOiBzdHJpbmc7IGFzc2lnbm1lbnQ6IHN0cmluZzsgc3RhdHVzOiBzdHJpbmc7IHNvdXJjZTogc3RyaW5nIH0+XG4gID4ge1xuICAgIGNvbnNvbGUubG9nKGBQYXJzaW5nIGR1ZSBkYXRlcyBmb3IgY291cnNlOiAke2NvdXJzZUlkfWApXG5cbiAgICB0cnkge1xuICAgICAgLy8gRmluZCBhbGwgbm90ZXMgcmVsYXRlZCB0byB0aGUgY291cnNlXG4gICAgICBjb25zdCBjb3Vyc2VOb3RlcyA9IGF3YWl0IHRoaXMuZmluZENvdXJzZU5vdGVzKGNvdXJzZUlkKVxuXG4gICAgICBpZiAoY291cnNlTm90ZXMubGVuZ3RoID09PSAwKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKGBObyBub3RlcyBmb3VuZCBmb3IgY291cnNlOiAke2NvdXJzZUlkfWApXG4gICAgICAgIHJldHVybiBbXVxuICAgICAgfVxuXG4gICAgICAvLyBQYXJzZSBkdWUgZGF0ZXMgZnJvbSBlYWNoIG5vdGVcbiAgICAgIGNvbnN0IGFsbER1ZURhdGVzOiBBcnJheTx7XG4gICAgICAgIGRhdGU6IHN0cmluZ1xuICAgICAgICBhc3NpZ25tZW50OiBzdHJpbmdcbiAgICAgICAgc3RhdHVzOiBzdHJpbmdcbiAgICAgICAgc291cmNlOiBzdHJpbmdcbiAgICAgIH0+ID0gW11cblxuICAgICAgZm9yIChjb25zdCBub3RlIG9mIGNvdXJzZU5vdGVzKSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgY29uc3QgY29udGVudCA9IGF3YWl0IHRoaXMuYXBwLnZhdWx0LnJlYWQobm90ZSlcbiAgICAgICAgICBjb25zdCBkdWVEYXRlcyA9IHRoaXMucGFyc2VEdWVEYXRlc0Zyb21Ob3RlKGNvbnRlbnQpXG5cbiAgICAgICAgICAvLyBBZGQgc291cmNlIGluZm9ybWF0aW9uXG4gICAgICAgICAgY29uc3QgZHVlRGF0ZXNXaXRoU291cmNlID0gZHVlRGF0ZXMubWFwKChkdWVEYXRlKSA9PiAoe1xuICAgICAgICAgICAgLi4uZHVlRGF0ZSxcbiAgICAgICAgICAgIHNvdXJjZTogbm90ZS5iYXNlbmFtZVxuICAgICAgICAgIH0pKVxuXG4gICAgICAgICAgYWxsRHVlRGF0ZXMucHVzaCguLi5kdWVEYXRlc1dpdGhTb3VyY2UpXG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgY29uc29sZS5lcnJvcihgRXJyb3IgcmVhZGluZyBub3RlICR7bm90ZS5wYXRofTpgLCBlcnJvcilcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICAvLyBGaWx0ZXIgYnkgZGF0ZSByYW5nZSBpZiBwcm92aWRlZFxuICAgICAgbGV0IGZpbHRlcmVkRHVlRGF0ZXMgPSBhbGxEdWVEYXRlc1xuICAgICAgaWYgKHN0YXJ0RGF0ZSB8fCBlbmREYXRlKSB7XG4gICAgICAgIGZpbHRlcmVkRHVlRGF0ZXMgPSB0aGlzLmZpbHRlckJ5RGF0ZVJhbmdlKFxuICAgICAgICAgIGFsbER1ZURhdGVzLFxuICAgICAgICAgIHN0YXJ0RGF0ZSxcbiAgICAgICAgICBlbmREYXRlXG4gICAgICAgIClcbiAgICAgIH1cblxuICAgICAgLy8gU29ydCBieSBkYXRlXG4gICAgICBmaWx0ZXJlZER1ZURhdGVzLnNvcnQoXG4gICAgICAgIChhLCBiKSA9PiBuZXcgRGF0ZShhLmRhdGUpLmdldFRpbWUoKSAtIG5ldyBEYXRlKGIuZGF0ZSkuZ2V0VGltZSgpXG4gICAgICApXG5cbiAgICAgIGNvbnNvbGUubG9nKFxuICAgICAgICBgRm91bmQgJHtmaWx0ZXJlZER1ZURhdGVzLmxlbmd0aH0gZHVlIGRhdGVzIGZvciBjb3Vyc2U6ICR7Y291cnNlSWR9YFxuICAgICAgKVxuICAgICAgcmV0dXJuIGZpbHRlcmVkRHVlRGF0ZXNcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihgRXJyb3IgcGFyc2luZyBkdWUgZGF0ZXMgZm9yIGNvdXJzZSAke2NvdXJzZUlkfTpgLCBlcnJvcilcbiAgICAgIHJldHVybiBbXVxuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgZmluZENvdXJzZU5vdGVzKGNvdXJzZUlkOiBzdHJpbmcpOiBQcm9taXNlPFRGaWxlW10+IHtcbiAgICBjb25zdCBub3RlczogVEZpbGVbXSA9IFtdXG5cbiAgICAvLyBHZXQgYWxsIG1hcmtkb3duIGZpbGVzIGluIHRoZSB2YXVsdFxuICAgIGNvbnN0IGZpbGVzID0gdGhpcy5hcHAudmF1bHQuZ2V0TWFya2Rvd25GaWxlcygpXG5cbiAgICBmb3IgKGNvbnN0IGZpbGUgb2YgZmlsZXMpIHtcbiAgICAgIC8vIENoZWNrIGlmIHRoZSBmaWxlIHBhdGggY29udGFpbnMgdGhlIGNvdXJzZSBJRCBvciBiZWxvbmdzIHRvIHRoZSBjb3Vyc2VcbiAgICAgIGlmIChcbiAgICAgICAgZmlsZS5wYXRoLmluY2x1ZGVzKGNvdXJzZUlkKSB8fFxuICAgICAgICAoYXdhaXQgdGhpcy5ub3RlQmVsb25nc1RvQ291cnNlKGZpbGUsIGNvdXJzZUlkKSlcbiAgICAgICkge1xuICAgICAgICBub3Rlcy5wdXNoKGZpbGUpXG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIG5vdGVzXG4gIH1cblxuICBwcml2YXRlIGFzeW5jIG5vdGVCZWxvbmdzVG9Db3Vyc2UoXG4gICAgZmlsZTogVEZpbGUsXG4gICAgY291cnNlSWQ6IHN0cmluZ1xuICApOiBQcm9taXNlPGJvb2xlYW4+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgY29udGVudCA9IGF3YWl0IHRoaXMuYXBwLnZhdWx0LnJlYWQoZmlsZSlcbiAgICAgIGNvbnN0IGZyb250bWF0dGVyTWF0Y2ggPSBjb250ZW50Lm1hdGNoKC9eLS0tXFxuKFtcXHNcXFNdKj8pXFxuLS0tLylcblxuICAgICAgaWYgKGZyb250bWF0dGVyTWF0Y2gpIHtcbiAgICAgICAgY29uc3QgZnJvbnRtYXR0ZXIgPSBmcm9udG1hdHRlck1hdGNoWzFdXG4gICAgICAgIC8vIENoZWNrIGlmIGNvdXJzZV9pZCBpcyBpbiB0aGUgZnJvbnRtYXR0ZXJcbiAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICBmcm9udG1hdHRlci5pbmNsdWRlcyhgY291cnNlX2lkOiAke2NvdXJzZUlkfWApIHx8XG4gICAgICAgICAgZnJvbnRtYXR0ZXIuaW5jbHVkZXMoYGNvdXJzZV9pZDoke2NvdXJzZUlkfWApXG4gICAgICAgIClcbiAgICAgIH1cblxuICAgICAgcmV0dXJuIGZhbHNlXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXG4gICAgICAgIGBFcnJvciBjaGVja2luZyBpZiBub3RlICR7ZmlsZS5wYXRofSBiZWxvbmdzIHRvIGNvdXJzZSAke2NvdXJzZUlkfTpgLFxuICAgICAgICBlcnJvclxuICAgICAgKVxuICAgICAgcmV0dXJuIGZhbHNlXG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSBmaWx0ZXJCeURhdGVSYW5nZShcbiAgICBkdWVEYXRlczogQXJyYXk8e1xuICAgICAgZGF0ZTogc3RyaW5nXG4gICAgICBhc3NpZ25tZW50OiBzdHJpbmdcbiAgICAgIHN0YXR1czogc3RyaW5nXG4gICAgICBzb3VyY2U6IHN0cmluZ1xuICAgIH0+LFxuICAgIHN0YXJ0RGF0ZT86IHN0cmluZyxcbiAgICBlbmREYXRlPzogc3RyaW5nXG4gICk6IEFycmF5PHtcbiAgICBkYXRlOiBzdHJpbmdcbiAgICBhc3NpZ25tZW50OiBzdHJpbmdcbiAgICBzdGF0dXM6IHN0cmluZ1xuICAgIHNvdXJjZTogc3RyaW5nXG4gIH0+IHtcbiAgICByZXR1cm4gZHVlRGF0ZXMuZmlsdGVyKChkdWVEYXRlKSA9PiB7XG4gICAgICBjb25zdCBkdWVEYXRlVGltZSA9IG5ldyBEYXRlKGR1ZURhdGUuZGF0ZSkuZ2V0VGltZSgpXG5cbiAgICAgIGlmIChzdGFydERhdGUgJiYgZHVlRGF0ZVRpbWUgPCBuZXcgRGF0ZShzdGFydERhdGUpLmdldFRpbWUoKSkge1xuICAgICAgICByZXR1cm4gZmFsc2VcbiAgICAgIH1cblxuICAgICAgaWYgKGVuZERhdGUgJiYgZHVlRGF0ZVRpbWUgPiBuZXcgRGF0ZShlbmREYXRlKS5nZXRUaW1lKCkpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlXG4gICAgICB9XG5cbiAgICAgIHJldHVybiB0cnVlXG4gICAgfSlcbiAgfVxuXG4gIGFzeW5jIGdlbmVyYXRlRHVlRGF0ZXNTdW1tYXJ5KFxuICAgIGNvdXJzZUlkOiBzdHJpbmcsXG4gICAgZHVlRGF0ZXM6IEFycmF5PHtcbiAgICAgIGRhdGU6IHN0cmluZ1xuICAgICAgYXNzaWdubWVudDogc3RyaW5nXG4gICAgICBzdGF0dXM6IHN0cmluZ1xuICAgICAgc291cmNlOiBzdHJpbmdcbiAgICB9PlxuICApOiBQcm9taXNlPHN0cmluZz4ge1xuICAgIGlmIChkdWVEYXRlcy5sZW5ndGggPT09IDApIHtcbiAgICAgIHJldHVybiBgIyBEdWUgRGF0ZXMgU3VtbWFyeSAtICR7Y291cnNlSWR9XFxuXFxuTm8gZHVlIGRhdGVzIGZvdW5kLlxcbmBcbiAgICB9XG5cbiAgICAvLyBHcm91cCBieSBzdGF0dXNcbiAgICBjb25zdCBieVN0YXR1cyA9IGR1ZURhdGVzLnJlZHVjZSgoYWNjLCBkdWVEYXRlKSA9PiB7XG4gICAgICBpZiAoIWFjY1tkdWVEYXRlLnN0YXR1c10pIHtcbiAgICAgICAgYWNjW2R1ZURhdGUuc3RhdHVzXSA9IFtdXG4gICAgICB9XG4gICAgICBhY2NbZHVlRGF0ZS5zdGF0dXNdLnB1c2goZHVlRGF0ZSlcbiAgICAgIHJldHVybiBhY2NcbiAgICB9LCB7fSBhcyBSZWNvcmQ8c3RyaW5nLCB0eXBlb2YgZHVlRGF0ZXM+KVxuXG4gICAgbGV0IGNvbnRlbnQgPSBgIyBEdWUgRGF0ZXMgU3VtbWFyeSAtICR7Y291cnNlSWR9XFxuXFxuYFxuICAgIGNvbnRlbnQgKz0gYFRvdGFsIGFzc2lnbm1lbnRzOiAke2R1ZURhdGVzLmxlbmd0aH1cXG5cXG5gXG5cbiAgICAvLyBBZGQgc3VtbWFyeSBieSBzdGF0dXNcbiAgICBmb3IgKGNvbnN0IFtzdGF0dXMsIGl0ZW1zXSBvZiBPYmplY3QuZW50cmllcyhieVN0YXR1cykpIHtcbiAgICAgIGNvbnRlbnQgKz0gYCMjICR7c3RhdHVzLmNoYXJBdCgwKS50b1VwcGVyQ2FzZSgpICsgc3RhdHVzLnNsaWNlKDEpfSAoJHtcbiAgICAgICAgaXRlbXMubGVuZ3RoXG4gICAgICB9KVxcblxcbmBcbiAgICAgIGNvbnRlbnQgKz0gYHwgRGF0ZSB8IEFzc2lnbm1lbnQgfCBTb3VyY2UgfFxcbmBcbiAgICAgIGNvbnRlbnQgKz0gYHwgLS0tLSB8IC0tLS0tLS0tLS0gfCAtLS0tLS0gfFxcbmBcblxuICAgICAgZm9yIChjb25zdCBpdGVtIG9mIGl0ZW1zKSB7XG4gICAgICAgIGNvbnRlbnQgKz0gYHwgJHtpdGVtLmRhdGV9IHwgJHtpdGVtLmFzc2lnbm1lbnR9IHwgJHtpdGVtLnNvdXJjZX0gfFxcbmBcbiAgICAgIH1cbiAgICAgIGNvbnRlbnQgKz0gYFxcbmBcbiAgICB9XG5cbiAgICByZXR1cm4gY29udGVudFxuICB9XG5cbiAgYXN5bmMgY3JlYXRlRHVlRGF0ZXNTdW1tYXJ5RmlsZShcbiAgICBjb3Vyc2VJZDogc3RyaW5nLFxuICAgIHN0YXJ0RGF0ZT86IHN0cmluZyxcbiAgICBlbmREYXRlPzogc3RyaW5nXG4gICk6IFByb21pc2U8dm9pZD4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBkdWVEYXRlcyA9IGF3YWl0IHRoaXMucGFyc2VEdWVEYXRlc0Zyb21Db3Vyc2UoXG4gICAgICAgIGNvdXJzZUlkLFxuICAgICAgICBzdGFydERhdGUsXG4gICAgICAgIGVuZERhdGVcbiAgICAgIClcblxuICAgICAgY29uc3Qgc3VtbWFyeUNvbnRlbnQgPSBhd2FpdCB0aGlzLmdlbmVyYXRlRHVlRGF0ZXNTdW1tYXJ5KFxuICAgICAgICBjb3Vyc2VJZCxcbiAgICAgICAgZHVlRGF0ZXNcbiAgICAgIClcblxuICAgICAgLy8gQ3JlYXRlIHRoZSBzdW1tYXJ5IGZpbGVcbiAgICAgIGNvbnN0IGZpbGVOYW1lID0gYCR7Y291cnNlSWR9IC0gRHVlIERhdGVzIFN1bW1hcnkubWRgXG4gICAgICBjb25zdCBmaWxlUGF0aCA9IGBDb3Vyc2VzLyR7Y291cnNlSWR9LyR7ZmlsZU5hbWV9YFxuXG4gICAgICB0cnkge1xuICAgICAgICBhd2FpdCB0aGlzLmFwcC52YXVsdC5jcmVhdGUoZmlsZVBhdGgsIHN1bW1hcnlDb250ZW50KVxuICAgICAgICBjb25zb2xlLmxvZyhgQ3JlYXRlZCBkdWUgZGF0ZXMgc3VtbWFyeSBmaWxlOiAke2ZpbGVQYXRofWApXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAvLyBGaWxlIG1pZ2h0IGFscmVhZHkgZXhpc3QsIHRyeSB0byB1cGRhdGUgaXRcbiAgICAgICAgY29uc3QgZXhpc3RpbmdGaWxlID0gdGhpcy5hcHAudmF1bHQuZ2V0QWJzdHJhY3RGaWxlQnlQYXRoKGZpbGVQYXRoKVxuICAgICAgICBpZiAoZXhpc3RpbmdGaWxlICYmIGV4aXN0aW5nRmlsZSBpbnN0YW5jZW9mIFRGaWxlKSB7XG4gICAgICAgICAgYXdhaXQgdGhpcy5hcHAudmF1bHQubW9kaWZ5KGV4aXN0aW5nRmlsZSwgc3VtbWFyeUNvbnRlbnQpXG4gICAgICAgICAgY29uc29sZS5sb2coYFVwZGF0ZWQgZHVlIGRhdGVzIHN1bW1hcnkgZmlsZTogJHtmaWxlUGF0aH1gKVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXG4gICAgICAgIGBFcnJvciBjcmVhdGluZyBkdWUgZGF0ZXMgc3VtbWFyeSBmb3IgY291cnNlICR7Y291cnNlSWR9OmAsXG4gICAgICAgIGVycm9yXG4gICAgICApXG4gICAgICB0aHJvdyBlcnJvclxuICAgIH1cbiAgfVxufVxuIiwgIi8vIERhaWx5IG5vdGVzIGludGVncmF0aW9uIGZvciBUdWNrZXJzIFRvb2xzIHBsdWdpblxuXG5pbXBvcnQgeyBBcHAsIFRGaWxlIH0gZnJvbSBcIm9ic2lkaWFuXCJcblxuZXhwb3J0IGNsYXNzIERhaWx5Tm90ZXNJbnRlZ3JhdGlvbiB7XG4gIGFwcDogQXBwXG5cbiAgY29uc3RydWN0b3IoYXBwOiBBcHApIHtcbiAgICB0aGlzLmFwcCA9IGFwcFxuICB9XG5cbiAgYXN5bmMgZ2V0VG9kYXlzQWN0aXZpdGllcygpOiBQcm9taXNlPFxuICAgIEFycmF5PHsgZmlsZTogc3RyaW5nOyB0eXBlOiBzdHJpbmc7IGNvdXJzZT86IHN0cmluZyB9PlxuICA+IHtcbiAgICBjb25zb2xlLmxvZyhcIkdldHRpbmcgdG9kYXkncyBhY2FkZW1pYyBhY3Rpdml0aWVzXCIpXG5cbiAgICB0cnkge1xuICAgICAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpXG4gICAgICBjb25zdCB0b2RheVN0cmluZyA9IHRvZGF5LnRvSVNPU3RyaW5nKCkuc3BsaXQoXCJUXCIpWzBdXG5cbiAgICAgIC8vIEZpbmQgZmlsZXMgY3JlYXRlZCBvciBtb2RpZmllZCB0b2RheVxuICAgICAgY29uc3QgZmlsZXMgPSB0aGlzLmFwcC52YXVsdC5nZXRNYXJrZG93bkZpbGVzKClcbiAgICAgIGNvbnN0IHRvZGF5c0ZpbGVzOiBURmlsZVtdID0gW11cblxuICAgICAgZm9yIChjb25zdCBmaWxlIG9mIGZpbGVzKSB7XG4gICAgICAgIGNvbnN0IGZpbGVEYXRlID0gdGhpcy5leHRyYWN0RGF0ZUZyb21QYXRoKGZpbGUucGF0aClcbiAgICAgICAgaWYgKGZpbGVEYXRlID09PSB0b2RheVN0cmluZykge1xuICAgICAgICAgIHRvZGF5c0ZpbGVzLnB1c2goZmlsZSlcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICAvLyBBbmFseXplIGFjdGl2aXRpZXNcbiAgICAgIGNvbnN0IGFjdGl2aXRpZXM6IEFycmF5PHsgZmlsZTogc3RyaW5nOyB0eXBlOiBzdHJpbmc7IGNvdXJzZT86IHN0cmluZyB9PiA9XG4gICAgICAgIFtdXG5cbiAgICAgIGZvciAoY29uc3QgZmlsZSBvZiB0b2RheXNGaWxlcykge1xuICAgICAgICBjb25zdCBhY3Rpdml0eSA9IGF3YWl0IHRoaXMuYW5hbHl6ZUZpbGVBY3Rpdml0eShmaWxlKVxuICAgICAgICBpZiAoYWN0aXZpdHkpIHtcbiAgICAgICAgICBhY3Rpdml0aWVzLnB1c2goYWN0aXZpdHkpXG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgY29uc29sZS5sb2coYEZvdW5kICR7YWN0aXZpdGllcy5sZW5ndGh9IGFjYWRlbWljIGFjdGl2aXRpZXMgZm9yIHRvZGF5YClcbiAgICAgIHJldHVybiBhY3Rpdml0aWVzXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBnZXR0aW5nIHRvZGF5J3MgYWN0aXZpdGllczpcIiwgZXJyb3IpXG4gICAgICByZXR1cm4gW11cbiAgICB9XG4gIH1cblxuICBhc3luYyBnZXRDb3Vyc2VBY3Rpdml0eUZvckRhdGUoXG4gICAgY291cnNlSWQ6IHN0cmluZyxcbiAgICBkYXRlOiBzdHJpbmdcbiAgKTogUHJvbWlzZTxBcnJheTx7IGZpbGU6IHN0cmluZzsgdHlwZTogc3RyaW5nIH0+PiB7XG4gICAgY29uc29sZS5sb2coYEdldHRpbmcgYWN0aXZpdHkgZm9yIGNvdXJzZSAke2NvdXJzZUlkfSBvbiBkYXRlICR7ZGF0ZX1gKVxuXG4gICAgdHJ5IHtcbiAgICAgIC8vIEZpbmQgZmlsZXMgcmVsYXRlZCB0byB0aGUgY291cnNlIG1vZGlmaWVkIG9uIHRoZSBkYXRlXG4gICAgICBjb25zdCBjb3Vyc2VGaWxlcyA9IGF3YWl0IHRoaXMuZmluZENvdXJzZUZpbGVzRm9yRGF0ZShjb3Vyc2VJZCwgZGF0ZSlcblxuICAgICAgY29uc3QgYWN0aXZpdGllczogQXJyYXk8eyBmaWxlOiBzdHJpbmc7IHR5cGU6IHN0cmluZyB9PiA9IFtdXG5cbiAgICAgIGZvciAoY29uc3QgZmlsZSBvZiBjb3Vyc2VGaWxlcykge1xuICAgICAgICBjb25zdCBjb250ZW50ID0gYXdhaXQgdGhpcy5hcHAudmF1bHQucmVhZChmaWxlKVxuICAgICAgICBjb25zdCBmaWxlVHlwZSA9IHRoaXMuZGV0ZXJtaW5lRmlsZVR5cGUoZmlsZSwgY29udGVudClcblxuICAgICAgICBhY3Rpdml0aWVzLnB1c2goe1xuICAgICAgICAgIGZpbGU6IGZpbGUuYmFzZW5hbWUsXG4gICAgICAgICAgdHlwZTogZmlsZVR5cGVcbiAgICAgICAgfSlcbiAgICAgIH1cblxuICAgICAgY29uc29sZS5sb2coXG4gICAgICAgIGBGb3VuZCAke2FjdGl2aXRpZXMubGVuZ3RofSBhY3Rpdml0aWVzIGZvciBjb3Vyc2UgJHtjb3Vyc2VJZH0gb24gJHtkYXRlfWBcbiAgICAgIClcbiAgICAgIHJldHVybiBhY3Rpdml0aWVzXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXG4gICAgICAgIGBFcnJvciBnZXR0aW5nIGNvdXJzZSBhY3Rpdml0eSBmb3IgJHtjb3Vyc2VJZH0gb24gJHtkYXRlfTpgLFxuICAgICAgICBlcnJvclxuICAgICAgKVxuICAgICAgcmV0dXJuIFtdXG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSBleHRyYWN0RGF0ZUZyb21QYXRoKGZpbGVQYXRoOiBzdHJpbmcpOiBzdHJpbmcgfCBudWxsIHtcbiAgICAvLyBUcnkgdG8gZXh0cmFjdCBkYXRlIGZyb20gZmlsZSBwYXRoIChlLmcuLCBcIkRhaWx5LzIwMjUtMDEtMTUubWRcIiAtPiBcIjIwMjUtMDEtMTVcIilcbiAgICBjb25zdCBkYXRlUmVnZXggPSAvKFxcZHs0fS1cXGR7Mn0tXFxkezJ9KS9nXG4gICAgY29uc3QgbWF0Y2hlcyA9IGZpbGVQYXRoLm1hdGNoKGRhdGVSZWdleClcbiAgICByZXR1cm4gbWF0Y2hlcyA/IG1hdGNoZXNbbWF0Y2hlcy5sZW5ndGggLSAxXSA6IG51bGxcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgYW5hbHl6ZUZpbGVBY3Rpdml0eShcbiAgICBmaWxlOiBURmlsZVxuICApOiBQcm9taXNlPHsgZmlsZTogc3RyaW5nOyB0eXBlOiBzdHJpbmc7IGNvdXJzZT86IHN0cmluZyB9IHwgbnVsbD4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBjb250ZW50ID0gYXdhaXQgdGhpcy5hcHAudmF1bHQucmVhZChmaWxlKVxuXG4gICAgICAvLyBEZXRlcm1pbmUgZmlsZSB0eXBlIGJhc2VkIG9uIGNvbnRlbnQgYW5kIHBhdGhcbiAgICAgIGNvbnN0IGZpbGVUeXBlID0gdGhpcy5kZXRlcm1pbmVGaWxlVHlwZShmaWxlLCBjb250ZW50KVxuXG4gICAgICAvLyBFeHRyYWN0IGNvdXJzZSBJRCBpZiBhcHBsaWNhYmxlXG4gICAgICBjb25zdCBjb3Vyc2VJZCA9XG4gICAgICAgIHRoaXMuZXh0cmFjdENvdXJzZUlkRnJvbUNvbnRlbnQoY29udGVudCkgfHxcbiAgICAgICAgdGhpcy5leHRyYWN0Q291cnNlSWRGcm9tUGF0aChmaWxlLnBhdGgpXG5cbiAgICAgIHJldHVybiB7XG4gICAgICAgIGZpbGU6IGZpbGUuYmFzZW5hbWUsXG4gICAgICAgIHR5cGU6IGZpbGVUeXBlLFxuICAgICAgICBjb3Vyc2U6IGNvdXJzZUlkIHx8IHVuZGVmaW5lZFxuICAgICAgfVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKGBFcnJvciBhbmFseXppbmcgZmlsZSAke2ZpbGUucGF0aH06YCwgZXJyb3IpXG4gICAgICByZXR1cm4gbnVsbFxuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgZGV0ZXJtaW5lRmlsZVR5cGUoZmlsZTogVEZpbGUsIGNvbnRlbnQ6IHN0cmluZyk6IHN0cmluZyB7XG4gICAgY29uc3QgcGF0aCA9IGZpbGUucGF0aC50b0xvd2VyQ2FzZSgpXG5cbiAgICAvLyBDaGVjayBmb3IgZGFpbHkgbm90ZXNcbiAgICBpZiAoXG4gICAgICBwYXRoLmluY2x1ZGVzKFwiZGFpbHlcIikgfHxcbiAgICAgIGNvbnRlbnQuaW5jbHVkZXMoXCJjb250ZW50X3R5cGU6IGRhaWx5X25vdGVcIilcbiAgICApIHtcbiAgICAgIHJldHVybiBcImRhaWx5X25vdGVcIlxuICAgIH1cblxuICAgIC8vIENoZWNrIGZvciBjb3Vyc2UtcmVsYXRlZCBmaWxlc1xuICAgIGlmIChwYXRoLmluY2x1ZGVzKFwiY291cnNlc1wiKSB8fCBjb250ZW50LmluY2x1ZGVzKFwiY291cnNlX2lkOlwiKSkge1xuICAgICAgaWYgKGNvbnRlbnQuaW5jbHVkZXMoXCJjb250ZW50X3R5cGU6IGNvdXJzZV9ob21lcGFnZVwiKSkge1xuICAgICAgICByZXR1cm4gXCJjb3Vyc2VfaG9tZXBhZ2VcIlxuICAgICAgfVxuICAgICAgaWYgKGNvbnRlbnQuaW5jbHVkZXMoXCJjb250ZW50X3R5cGU6IG1vZHVsZVwiKSkge1xuICAgICAgICByZXR1cm4gXCJtb2R1bGVcIlxuICAgICAgfVxuICAgICAgaWYgKGNvbnRlbnQuaW5jbHVkZXMoXCJjb250ZW50X3R5cGU6IGNoYXB0ZXJcIikpIHtcbiAgICAgICAgcmV0dXJuIFwiY2hhcHRlclwiXG4gICAgICB9XG4gICAgICBpZiAoY29udGVudC5pbmNsdWRlcyhcImNvbnRlbnRfdHlwZTogYXNzaWdubWVudFwiKSkge1xuICAgICAgICByZXR1cm4gXCJhc3NpZ25tZW50XCJcbiAgICAgIH1cbiAgICAgIHJldHVybiBcImNvdXJzZV9ub3RlXCJcbiAgICB9XG5cbiAgICAvLyBDaGVjayBmb3Igdm9jYWJ1bGFyeSBlbnRyaWVzXG4gICAgaWYgKGNvbnRlbnQuaW5jbHVkZXMoXCIjIyBcIikgJiYgY29udGVudC5tYXRjaCgvXlxcKlxcKlRlcm1cXCpcXCo6L20pKSB7XG4gICAgICByZXR1cm4gXCJ2b2NhYnVsYXJ5X2VudHJ5XCJcbiAgICB9XG5cbiAgICByZXR1cm4gXCJvdGhlclwiXG4gIH1cblxuICBwcml2YXRlIGV4dHJhY3RDb3Vyc2VJZEZyb21Db250ZW50KGNvbnRlbnQ6IHN0cmluZyk6IHN0cmluZyB8IG51bGwge1xuICAgIGNvbnN0IGNvdXJzZUlkUmVnZXggPSAvY291cnNlX2lkOlxccyooW0EtWl17Miw0fS1cXGR7M30pL1xuICAgIGNvbnN0IG1hdGNoID0gY29udGVudC5tYXRjaChjb3Vyc2VJZFJlZ2V4KVxuICAgIHJldHVybiBtYXRjaCA/IG1hdGNoWzFdIDogbnVsbFxuICB9XG5cbiAgcHJpdmF0ZSBleHRyYWN0Q291cnNlSWRGcm9tUGF0aChmaWxlUGF0aDogc3RyaW5nKTogc3RyaW5nIHwgbnVsbCB7XG4gICAgY29uc3QgY291cnNlSWRSZWdleCA9IC8oW0EtWl17Miw0fS1cXGR7M30pL2dcbiAgICBjb25zdCBtYXRjaGVzID0gZmlsZVBhdGgubWF0Y2goY291cnNlSWRSZWdleClcbiAgICByZXR1cm4gbWF0Y2hlcyA/IG1hdGNoZXNbbWF0Y2hlcy5sZW5ndGggLSAxXSA6IG51bGxcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgZmluZENvdXJzZUZpbGVzRm9yRGF0ZShcbiAgICBjb3Vyc2VJZDogc3RyaW5nLFxuICAgIGRhdGU6IHN0cmluZ1xuICApOiBQcm9taXNlPFRGaWxlW10+IHtcbiAgICBjb25zdCBmaWxlczogVEZpbGVbXSA9IFtdXG5cbiAgICAvLyBHZXQgYWxsIGZpbGVzIGFuZCBmaWx0ZXIgYnkgY291cnNlIElEIGFuZCBkYXRlXG4gICAgY29uc3QgYWxsRmlsZXMgPSB0aGlzLmFwcC52YXVsdC5nZXRNYXJrZG93bkZpbGVzKClcblxuICAgIGZvciAoY29uc3QgZmlsZSBvZiBhbGxGaWxlcykge1xuICAgICAgLy8gQ2hlY2sgaWYgZmlsZSBiZWxvbmdzIHRvIHRoZSBjb3Vyc2VcbiAgICAgIGlmIChcbiAgICAgICAgZmlsZS5wYXRoLmluY2x1ZGVzKGNvdXJzZUlkKSB8fFxuICAgICAgICAoYXdhaXQgdGhpcy5maWxlQmVsb25nc1RvQ291cnNlKGZpbGUsIGNvdXJzZUlkKSlcbiAgICAgICkge1xuICAgICAgICAvLyBDaGVjayBpZiBmaWxlIHdhcyBtb2RpZmllZCBvbiB0aGUgc3BlY2lmaWVkIGRhdGVcbiAgICAgICAgY29uc3QgZmlsZURhdGUgPSB0aGlzLmV4dHJhY3REYXRlRnJvbVBhdGgoZmlsZS5wYXRoKVxuICAgICAgICBpZiAoZmlsZURhdGUgPT09IGRhdGUpIHtcbiAgICAgICAgICBmaWxlcy5wdXNoKGZpbGUpXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gZmlsZXNcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgZmlsZUJlbG9uZ3NUb0NvdXJzZShcbiAgICBmaWxlOiBURmlsZSxcbiAgICBjb3Vyc2VJZDogc3RyaW5nXG4gICk6IFByb21pc2U8Ym9vbGVhbj4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBjb250ZW50ID0gYXdhaXQgdGhpcy5hcHAudmF1bHQucmVhZChmaWxlKVxuICAgICAgcmV0dXJuIHRoaXMuZXh0cmFjdENvdXJzZUlkRnJvbUNvbnRlbnQoY29udGVudCkgPT09IGNvdXJzZUlkXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXG4gICAgICAgIGBFcnJvciBjaGVja2luZyBpZiBmaWxlICR7ZmlsZS5wYXRofSBiZWxvbmdzIHRvIGNvdXJzZSAke2NvdXJzZUlkfTpgLFxuICAgICAgICBlcnJvclxuICAgICAgKVxuICAgICAgcmV0dXJuIGZhbHNlXG4gICAgfVxuICB9XG5cbiAgYXN5bmMgZ2VuZXJhdGVEYWlseVN1bW1hcnkoZGF0ZT86IHN0cmluZyk6IFByb21pc2U8c3RyaW5nPiB7XG4gICAgY29uc3QgdGFyZ2V0RGF0ZSA9IGRhdGUgfHwgbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNwbGl0KFwiVFwiKVswXVxuICAgIGNvbnN0IGFjdGl2aXRpZXMgPSBhd2FpdCB0aGlzLmdldENvdXJzZUFjdGl2aXR5Rm9yRGF0ZShcIlwiLCB0YXJnZXREYXRlKVxuXG4gICAgaWYgKGFjdGl2aXRpZXMubGVuZ3RoID09PSAwKSB7XG4gICAgICByZXR1cm4gYCMgQWNhZGVtaWMgQWN0aXZpdGllcyAtICR7dGFyZ2V0RGF0ZX1cXG5cXG5ObyBhY2FkZW1pYyBhY3Rpdml0aWVzIHJlY29yZGVkIGZvciB0aGlzIGRhdGUuXFxuYFxuICAgIH1cblxuICAgIC8vIEdyb3VwIGFjdGl2aXRpZXMgYnkgY291cnNlXG4gICAgY29uc3QgYnlDb3Vyc2U6IFJlY29yZDxzdHJpbmcsIHR5cGVvZiBhY3Rpdml0aWVzPiA9IHt9XG4gICAgY29uc3Qgbm9Db3Vyc2U6IHR5cGVvZiBhY3Rpdml0aWVzID0gW11cblxuICAgIGZvciAoY29uc3QgYWN0aXZpdHkgb2YgYWN0aXZpdGllcykge1xuICAgICAgaWYgKGFjdGl2aXR5LmZpbGUuaW5jbHVkZXMoXCJDb3Vyc2VzL1wiKSkge1xuICAgICAgICAvLyBFeHRyYWN0IGNvdXJzZSBJRCBmcm9tIHBhdGhcbiAgICAgICAgY29uc3QgcGF0aFBhcnRzID0gYWN0aXZpdHkuZmlsZS5zcGxpdChcIi9cIilcbiAgICAgICAgY29uc3QgY291cnNlSW5kZXggPSBwYXRoUGFydHMuZmluZEluZGV4KChwYXJ0KSA9PiBwYXJ0LmluY2x1ZGVzKFwiLVwiKSlcbiAgICAgICAgaWYgKGNvdXJzZUluZGV4ID49IDApIHtcbiAgICAgICAgICBjb25zdCBjb3Vyc2VJZCA9IHBhdGhQYXJ0c1tjb3Vyc2VJbmRleF1cbiAgICAgICAgICBpZiAoIWJ5Q291cnNlW2NvdXJzZUlkXSkge1xuICAgICAgICAgICAgYnlDb3Vyc2VbY291cnNlSWRdID0gW11cbiAgICAgICAgICB9XG4gICAgICAgICAgYnlDb3Vyc2VbY291cnNlSWRdLnB1c2goYWN0aXZpdHkpXG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgbm9Db3Vyc2UucHVzaChhY3Rpdml0eSlcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgbm9Db3Vyc2UucHVzaChhY3Rpdml0eSlcbiAgICAgIH1cbiAgICB9XG5cbiAgICBsZXQgY29udGVudCA9IGAjIEFjYWRlbWljIEFjdGl2aXRpZXMgLSAke3RhcmdldERhdGV9XFxuXFxuYFxuICAgIGNvbnRlbnQgKz0gYFRvdGFsIGFjdGl2aXRpZXM6ICR7YWN0aXZpdGllcy5sZW5ndGh9XFxuXFxuYFxuXG4gICAgLy8gQWRkIGFjdGl2aXRpZXMgYnkgY291cnNlXG4gICAgZm9yIChjb25zdCBbY291cnNlSWQsIGNvdXJzZUFjdGl2aXRpZXNdIG9mIE9iamVjdC5lbnRyaWVzKGJ5Q291cnNlKSkge1xuICAgICAgY29udGVudCArPSBgIyMgJHtjb3Vyc2VJZH1cXG5cXG5gXG4gICAgICBjb250ZW50ICs9IGB8IEZpbGUgfCBUeXBlIHxcXG5gXG4gICAgICBjb250ZW50ICs9IGB8IC0tLS0gfCAtLS0tIHxcXG5gXG5cbiAgICAgIGZvciAoY29uc3QgYWN0aXZpdHkgb2YgY291cnNlQWN0aXZpdGllcykge1xuICAgICAgICBjb250ZW50ICs9IGB8ICR7YWN0aXZpdHkuZmlsZX0gfCAke2FjdGl2aXR5LnR5cGV9IHxcXG5gXG4gICAgICB9XG4gICAgICBjb250ZW50ICs9IGBcXG5gXG4gICAgfVxuXG4gICAgLy8gQWRkIGFjdGl2aXRpZXMgd2l0aG91dCBzcGVjaWZpYyBjb3Vyc2VcbiAgICBpZiAobm9Db3Vyc2UubGVuZ3RoID4gMCkge1xuICAgICAgY29udGVudCArPSBgIyMgT3RoZXIgQWN0aXZpdGllc1xcblxcbmBcbiAgICAgIGNvbnRlbnQgKz0gYHwgRmlsZSB8IFR5cGUgfFxcbmBcbiAgICAgIGNvbnRlbnQgKz0gYHwgLS0tLSB8IC0tLS0gfFxcbmBcblxuICAgICAgZm9yIChjb25zdCBhY3Rpdml0eSBvZiBub0NvdXJzZSkge1xuICAgICAgICBjb250ZW50ICs9IGB8ICR7YWN0aXZpdHkuZmlsZX0gfCAke2FjdGl2aXR5LnR5cGV9IHxcXG5gXG4gICAgICB9XG4gICAgICBjb250ZW50ICs9IGBcXG5gXG4gICAgfVxuXG4gICAgcmV0dXJuIGNvbnRlbnRcbiAgfVxuXG4gIGFzeW5jIGNyZWF0ZURhaWx5U3VtbWFyeUZpbGUoZGF0ZT86IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB0YXJnZXREYXRlID0gZGF0ZSB8fCBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc3BsaXQoXCJUXCIpWzBdXG4gICAgICBjb25zdCBzdW1tYXJ5Q29udGVudCA9IGF3YWl0IHRoaXMuZ2VuZXJhdGVEYWlseVN1bW1hcnkodGFyZ2V0RGF0ZSlcblxuICAgICAgLy8gQ3JlYXRlIHRoZSBzdW1tYXJ5IGZpbGVcbiAgICAgIGNvbnN0IGZpbGVOYW1lID0gYCR7dGFyZ2V0RGF0ZX0gLSBBY2FkZW1pYyBTdW1tYXJ5Lm1kYFxuICAgICAgY29uc3QgZmlsZVBhdGggPSBgRGFpbHkvJHtmaWxlTmFtZX1gXG5cbiAgICAgIHRyeSB7XG4gICAgICAgIGF3YWl0IHRoaXMuYXBwLnZhdWx0LmNyZWF0ZShmaWxlUGF0aCwgc3VtbWFyeUNvbnRlbnQpXG4gICAgICAgIGNvbnNvbGUubG9nKGBDcmVhdGVkIGRhaWx5IHN1bW1hcnkgZmlsZTogJHtmaWxlUGF0aH1gKVxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgLy8gRmlsZSBtaWdodCBhbHJlYWR5IGV4aXN0LCB0cnkgdG8gdXBkYXRlIGl0XG4gICAgICAgIGNvbnN0IGV4aXN0aW5nRmlsZSA9IHRoaXMuYXBwLnZhdWx0LmdldEFic3RyYWN0RmlsZUJ5UGF0aChmaWxlUGF0aClcbiAgICAgICAgaWYgKGV4aXN0aW5nRmlsZSAmJiBleGlzdGluZ0ZpbGUgaW5zdGFuY2VvZiBURmlsZSkge1xuICAgICAgICAgIGF3YWl0IHRoaXMuYXBwLnZhdWx0Lm1vZGlmeShleGlzdGluZ0ZpbGUsIHN1bW1hcnlDb250ZW50KVxuICAgICAgICAgIGNvbnNvbGUubG9nKGBVcGRhdGVkIGRhaWx5IHN1bW1hcnkgZmlsZTogJHtmaWxlUGF0aH1gKVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIGNyZWF0aW5nIGRhaWx5IHN1bW1hcnkgZm9yICR7ZGF0ZX06YCwgZXJyb3IpXG4gICAgICB0aHJvdyBlcnJvclxuICAgIH1cbiAgfVxufVxuIiwgImltcG9ydCB7IEFwcCwgTW9kYWwsIFNldHRpbmcsIFRleHRBcmVhQ29tcG9uZW50IH0gZnJvbSBcIm9ic2lkaWFuXCI7XG5cbmludGVyZmFjZSBBc3NpZ25tZW50IHtcbiAgbmFtZTogc3RyaW5nO1xuICBkdWVEYXRlOiBzdHJpbmc7XG4gIHR5cGU6IHN0cmluZztcbiAgcG9pbnRzOiBzdHJpbmc7XG4gIGRlc2NyaXB0aW9uOiBzdHJpbmc7XG59XG5cbmV4cG9ydCBjbGFzcyBBc3NpZ25tZW50c01vZGFsIGV4dGVuZHMgTW9kYWwge1xuICBhc3NpZ25tZW50czogQXNzaWdubWVudFtdO1xuICBjb3Vyc2VOYW1lOiBzdHJpbmc7XG4gIGNvdXJzZUlkOiBzdHJpbmc7XG4gIG9uU3VibWl0OiAoYXNzaWdubWVudHM6IEFzc2lnbm1lbnRbXSwgY291cnNlTmFtZTogc3RyaW5nLCBjb3Vyc2VJZDogc3RyaW5nKSA9PiB2b2lkO1xuXG4gIGNvbnN0cnVjdG9yKFxuICAgIGFwcDogQXBwLFxuICAgIGNvdXJzZU5hbWU6IHN0cmluZyxcbiAgICBjb3Vyc2VJZDogc3RyaW5nLFxuICAgIG9uU3VibWl0OiAoYXNzaWdubWVudHM6IEFzc2lnbm1lbnRbXSwgY291cnNlTmFtZTogc3RyaW5nLCBjb3Vyc2VJZDogc3RyaW5nKSA9PiB2b2lkXG4gICkge1xuICAgIHN1cGVyKGFwcCk7XG4gICAgdGhpcy5hc3NpZ25tZW50cyA9IFt7IG5hbWU6IFwiXCIsIGR1ZURhdGU6IFwiXCIsIHR5cGU6IFwiXCIsIHBvaW50czogXCJcIiwgZGVzY3JpcHRpb246IFwiXCIgfV07XG4gICAgdGhpcy5jb3Vyc2VOYW1lID0gY291cnNlTmFtZTtcbiAgICB0aGlzLmNvdXJzZUlkID0gY291cnNlSWQ7XG4gICAgdGhpcy5vblN1Ym1pdCA9IG9uU3VibWl0O1xuICB9XG5cbiAgb25PcGVuKCkge1xuICAgIGNvbnN0IHsgY29udGVudEVsIH0gPSB0aGlzO1xuICAgIGNvbnRlbnRFbC5lbXB0eSgpO1xuICAgIGNvbnRlbnRFbC5hZGRDbGFzcyhcInR1Y2tlcnMtdG9vbHMtYXNzaWdubWVudHMtbW9kYWxcIik7XG5cbiAgICBjb250ZW50RWwuY3JlYXRlRWwoXCJoMlwiLCB7IHRleHQ6IFwiQ3JlYXRlIE11bHRpcGxlIEFzc2lnbm1lbnRzXCIgfSk7XG5cbiAgICAvLyBDb3Vyc2UgaW5mb3JtYXRpb24gZGlzcGxheVxuICAgIG5ldyBTZXR0aW5nKGNvbnRlbnRFbClcbiAgICAgIC5zZXROYW1lKFwiQ291cnNlXCIpXG4gICAgICAuc2V0RGVzYyhgJHt0aGlzLmNvdXJzZU5hbWV9ICgke3RoaXMuY291cnNlSWR9KWApXG4gICAgICAuc2V0RGlzYWJsZWQodHJ1ZSk7XG5cbiAgICAvLyBDb250YWluZXIgZm9yIGFzc2lnbm1lbnQgbGlzdFxuICAgIGNvbnN0IGFzc2lnbm1lbnRzQ29udGFpbmVyID0gY29udGVudEVsLmNyZWF0ZURpdih7IGNsczogXCJhc3NpZ25tZW50cy1jb250YWluZXJcIiB9KTtcblxuICAgIC8vIEFkZCBmaXJzdCBhc3NpZ25tZW50XG4gICAgdGhpcy5hZGRBc3NpZ25tZW50U2VjdGlvbihhc3NpZ25tZW50c0NvbnRhaW5lciwgMCk7XG5cbiAgICAvLyBBZGQgYXNzaWdubWVudCBidXR0b25cbiAgICBuZXcgU2V0dGluZyhjb250ZW50RWwpXG4gICAgICAuYWRkQnV0dG9uKChidG4pID0+XG4gICAgICAgIGJ0blxuICAgICAgICAgIC5zZXRCdXR0b25UZXh0KFwiQWRkIEFzc2lnbm1lbnRcIilcbiAgICAgICAgICAuc2V0Q3RhKClcbiAgICAgICAgICAub25DbGljaygoKSA9PiB7XG4gICAgICAgICAgICBjb25zdCBuZXdJbmRleCA9IHRoaXMuYXNzaWdubWVudHMubGVuZ3RoO1xuICAgICAgICAgICAgdGhpcy5hc3NpZ25tZW50cy5wdXNoKHsgbmFtZTogXCJcIiwgZHVlRGF0ZTogXCJcIiwgdHlwZTogXCJcIiwgcG9pbnRzOiBcIlwiLCBkZXNjcmlwdGlvbjogXCJcIiB9KTtcbiAgICAgICAgICAgIHRoaXMuYWRkQXNzaWdubWVudFNlY3Rpb24oYXNzaWdubWVudHNDb250YWluZXIsIG5ld0luZGV4KTtcbiAgICAgICAgICB9KVxuICAgICAgKTtcblxuICAgIC8vIFN1Ym1pdCBidXR0b25cbiAgICBuZXcgU2V0dGluZyhjb250ZW50RWwpXG4gICAgICAuYWRkQnV0dG9uKChidG4pID0+XG4gICAgICAgIGJ0blxuICAgICAgICAgIC5zZXRCdXR0b25UZXh0KFwiQ3JlYXRlIEFzc2lnbm1lbnRzXCIpXG4gICAgICAgICAgLnNldEN0YSgpXG4gICAgICAgICAgLm9uQ2xpY2soKCkgPT4ge1xuICAgICAgICAgICAgLy8gRmlsdGVyIG91dCBlbXB0eSBhc3NpZ25tZW50c1xuICAgICAgICAgICAgY29uc3QgdmFsaWRBc3NpZ25tZW50cyA9IHRoaXMuYXNzaWdubWVudHMuZmlsdGVyKFxuICAgICAgICAgICAgICAoYSkgPT4gYS5uYW1lLnRyaW0oKSAhPT0gXCJcIiB8fCBhLmR1ZURhdGUudHJpbSgpICE9PSBcIlwiXG4gICAgICAgICAgICApO1xuICAgICAgICAgICAgdGhpcy5vblN1Ym1pdCh2YWxpZEFzc2lnbm1lbnRzLCB0aGlzLmNvdXJzZU5hbWUsIHRoaXMuY291cnNlSWQpO1xuICAgICAgICAgICAgdGhpcy5jbG9zZSgpO1xuICAgICAgICAgIH0pXG4gICAgICApO1xuICB9XG5cbiAgYWRkQXNzaWdubWVudFNlY3Rpb24oY29udGFpbmVyOiBIVE1MRWxlbWVudCwgaW5kZXg6IG51bWJlcikge1xuICAgIGNvbnN0IHNlY3Rpb24gPSBjb250YWluZXIuY3JlYXRlRGl2KHsgY2xzOiBcImFzc2lnbm1lbnQtc2VjdGlvblwiIH0pO1xuICAgIHNlY3Rpb24uY3JlYXRlRWwoXCJoM1wiLCB7IHRleHQ6IGBBc3NpZ25tZW50ICMke2luZGV4ICsgMX1gIH0pO1xuXG4gICAgbmV3IFNldHRpbmcoc2VjdGlvbilcbiAgICAgIC5zZXROYW1lKFwiQXNzaWdubWVudCBOYW1lXCIpXG4gICAgICAuYWRkVGV4dCgodGV4dCkgPT5cbiAgICAgICAgdGV4dFxuICAgICAgICAgIC5zZXRQbGFjZWhvbGRlcihcIkVudGVyIGFzc2lnbm1lbnQgbmFtZVwiKVxuICAgICAgICAgIC5zZXRWYWx1ZSh0aGlzLmFzc2lnbm1lbnRzW2luZGV4XS5uYW1lKVxuICAgICAgICAgIC5vbkNoYW5nZSgodmFsdWUpID0+IHtcbiAgICAgICAgICAgIHRoaXMuYXNzaWdubWVudHNbaW5kZXhdLm5hbWUgPSB2YWx1ZTtcbiAgICAgICAgICB9KVxuICAgICAgKTtcblxuICAgIG5ldyBTZXR0aW5nKHNlY3Rpb24pXG4gICAgICAuc2V0TmFtZShcIkR1ZSBEYXRlXCIpXG4gICAgICAuc2V0RGVzYyhcIkZvcm1hdDogWVlZWS1NTS1ERFwiKVxuICAgICAgLmFkZFRleHQoKHRleHQpID0+XG4gICAgICAgIHRleHRcbiAgICAgICAgICAuc2V0UGxhY2Vob2xkZXIoXCIyMDI0LTAxLTE1XCIpXG4gICAgICAgICAgLnNldFZhbHVlKHRoaXMuYXNzaWdubWVudHNbaW5kZXhdLmR1ZURhdGUpXG4gICAgICAgICAgLm9uQ2hhbmdlKCh2YWx1ZSkgPT4ge1xuICAgICAgICAgICAgdGhpcy5hc3NpZ25tZW50c1tpbmRleF0uZHVlRGF0ZSA9IHZhbHVlO1xuICAgICAgICAgIH0pXG4gICAgICApO1xuXG4gICAgbmV3IFNldHRpbmcoc2VjdGlvbilcbiAgICAgIC5zZXROYW1lKFwiQXNzaWdubWVudCBUeXBlXCIpXG4gICAgICAuYWRkVGV4dCgodGV4dCkgPT5cbiAgICAgICAgdGV4dFxuICAgICAgICAgIC5zZXRQbGFjZWhvbGRlcihcImUuZy4sIEhvbWV3b3JrLCBRdWl6LCBFeGFtXCIpXG4gICAgICAgICAgLnNldFZhbHVlKHRoaXMuYXNzaWdubWVudHNbaW5kZXhdLnR5cGUpXG4gICAgICAgICAgLm9uQ2hhbmdlKCh2YWx1ZSkgPT4ge1xuICAgICAgICAgICAgdGhpcy5hc3NpZ25tZW50c1tpbmRleF0udHlwZSA9IHZhbHVlO1xuICAgICAgICAgIH0pXG4gICAgICApO1xuXG4gICAgbmV3IFNldHRpbmcoc2VjdGlvbilcbiAgICAgIC5zZXROYW1lKFwiUG9pbnRzXCIpXG4gICAgICAuYWRkVGV4dCgodGV4dCkgPT5cbiAgICAgICAgdGV4dFxuICAgICAgICAgIC5zZXRQbGFjZWhvbGRlcihcImUuZy4sIDEwMFwiKVxuICAgICAgICAgIC5zZXRWYWx1ZSh0aGlzLmFzc2lnbm1lbnRzW2luZGV4XS5wb2ludHMpXG4gICAgICAgICAgLm9uQ2hhbmdlKCh2YWx1ZSkgPT4ge1xuICAgICAgICAgICAgdGhpcy5hc3NpZ25tZW50c1tpbmRleF0ucG9pbnRzID0gdmFsdWU7XG4gICAgICAgICAgfSlcbiAgICAgICk7XG5cbiAgICBuZXcgU2V0dGluZyhzZWN0aW9uKVxuICAgICAgLnNldE5hbWUoXCJEZXNjcmlwdGlvblwiKVxuICAgICAgLmFkZFRleHRBcmVhKCh0ZXh0KSA9PlxuICAgICAgICB0ZXh0XG4gICAgICAgICAgLnNldFBsYWNlaG9sZGVyKFwiRW50ZXIgYXNzaWdubWVudCBkZXNjcmlwdGlvblwiKVxuICAgICAgICAgIC5zZXRWYWx1ZSh0aGlzLmFzc2lnbm1lbnRzW2luZGV4XS5kZXNjcmlwdGlvbilcbiAgICAgICAgICAub25DaGFuZ2UoKHZhbHVlKSA9PiB7XG4gICAgICAgICAgICB0aGlzLmFzc2lnbm1lbnRzW2luZGV4XS5kZXNjcmlwdGlvbiA9IHZhbHVlO1xuICAgICAgICAgIH0pXG4gICAgICApO1xuXG4gICAgLy8gQWRkIHJlbW92ZSBidXR0b24gaWYgdGhlcmUncyBtb3JlIHRoYW4gb25lIGFzc2lnbm1lbnRcbiAgICBpZiAodGhpcy5hc3NpZ25tZW50cy5sZW5ndGggPiAxKSB7XG4gICAgICBuZXcgU2V0dGluZyhzZWN0aW9uKVxuICAgICAgICAuYWRkQnV0dG9uKChidG4pID0+XG4gICAgICAgICAgYnRuXG4gICAgICAgICAgICAuc2V0QnV0dG9uVGV4dChcIlJlbW92ZVwiKVxuICAgICAgICAgICAgLm9uQ2xpY2soKCkgPT4ge1xuICAgICAgICAgICAgICB0aGlzLmFzc2lnbm1lbnRzLnNwbGljZShpbmRleCwgMSk7XG4gICAgICAgICAgICAgIHNlY3Rpb24ucmVtb3ZlKCk7XG4gICAgICAgICAgICAgIHRoaXMucmVudW1iZXJBc3NpZ25tZW50cygpO1xuICAgICAgICAgICAgfSlcbiAgICAgICAgKTtcbiAgICB9XG4gIH1cblxuICByZW51bWJlckFzc2lnbm1lbnRzKCkge1xuICAgIGNvbnN0IHNlY3Rpb25zID0gdGhpcy5jb250ZW50RWwucXVlcnlTZWxlY3RvckFsbChcIi5hc3NpZ25tZW50LXNlY3Rpb25cIik7XG4gICAgc2VjdGlvbnMuZm9yRWFjaCgoc2VjdGlvbiwgaW5kZXgpID0+IHtcbiAgICAgIGNvbnN0IGhlYWRlciA9IHNlY3Rpb24ucXVlcnlTZWxlY3RvcihcImgzXCIpO1xuICAgICAgaWYgKGhlYWRlcikge1xuICAgICAgICBoZWFkZXIudGV4dENvbnRlbnQgPSBgQXNzaWdubWVudCAjJHtpbmRleCArIDF9YDtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuXG4gIG9uQ2xvc2UoKSB7XG4gICAgY29uc3QgeyBjb250ZW50RWwgfSA9IHRoaXM7XG4gICAgY29udGVudEVsLmVtcHR5KCk7XG4gIH1cbn0iLCAiLyoqXG4gKiBEYXRhdmlldyBmdW5jdGlvbnMgZm9yIFR1Y2tlcnMgVG9vbHNcbiAqIFRoZXNlIGZ1bmN0aW9ucyBwcm92aWRlIGVuaGFuY2VkIHByb2Nlc3NpbmcgY2FwYWJpbGl0aWVzIGZvciBjb3Vyc2Ugdm9jYWJ1bGFyeSBhbmQgZHVlIGRhdGVzXG4gKi9cblxuLyoqXG4gKiBQcm9jZXNzZXMgYW5kIGRpc3BsYXlzIGNvdXJzZSB2b2NhYnVsYXJ5IGZyb20gYWxsIG5vdGVzIGFzc29jaWF0ZWQgd2l0aCBhIGNvdXJzZVxuICogQHBhcmFtIGR2IC0gVGhlIGRhdGF2aWV3IEFQSSBvYmplY3RcbiAqIEBwYXJhbSBjb3Vyc2VJZCAtIFRoZSBjb3Vyc2UgaWRlbnRpZmllciB0byBzZWFyY2ggZm9yXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBwcm9jZXNzQ291cnNlVm9jYWJ1bGFyeShkdjogYW55LCBjb3Vyc2VJZDogc3RyaW5nKSB7XG4gICAgdHJ5IHtcbiAgICAgICAgLy8gRmluZCBhbGwgcGFnZXMgd2l0aCB0aGUgY291cnNlIElEIHRhZ1xuICAgICAgICBjb25zdCBwYWdlcyA9IGR2LnBhZ2VzKGNvdXJzZUlkKVxuICAgICAgICAgICAgLmZpbHRlcigocDogYW55KSA9PiBwLmZpbGUuZXh0ID09PSBcIm1kXCIgJiYgcC5maWxlLm5hbWUgIT09IGNvdXJzZUlkKVxuICAgICAgICAgICAgLm1hcCgocDogYW55KSA9PiAoe1xuICAgICAgICAgICAgICAgIG5hbWU6IHAuZmlsZS5uYW1lLFxuICAgICAgICAgICAgICAgIHBhdGg6IHAuZmlsZS5wYXRoXG4gICAgICAgICAgICB9KSk7XG5cbiAgICAgICAgLy8gUHJvY2VzcyBlYWNoIHBhZ2UgYW5kIGV4dHJhY3Qgdm9jYWJ1bGFyeVxuICAgICAgICBkdi5oZWFkZXIoMSwgXCJBbGwgQ291cnNlIFZvY2FidWxhcnlcIik7XG4gICAgICAgIFxuICAgICAgICBmb3IgKGNvbnN0IHBhZ2Ugb2YgcGFnZXMpIHtcbiAgICAgICAgICAgIGlmICghcGFnZS5wYXRoKSBjb250aW51ZTtcbiAgICAgICAgICAgIFxuICAgICAgICAgICAgdHJ5IHsgICBcbiAgICAgICAgICAgICAgICBjb25zdCBmaWxlID0gYXdhaXQgZHYuYXBwLnZhdWx0LmdldEZpbGVCeVBhdGgocGFnZS5wYXRoKTtcbiAgICAgICAgICAgICAgICBjb25zdCBjb250ZW50ID0gYXdhaXQgZHYuYXBwLnZhdWx0LnJlYWQoZmlsZSk7XG4gICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgLy8gRXh0cmFjdCB2b2NhYnVsYXJ5IHVzaW5nIHJlZ2V4XG4gICAgICAgICAgICAgICAgY29uc3Qgdm9jYWJSZWdleCA9IC9eIysgVm9jYWJ1bGFyeS4qXFxuKCg/Oi4qP1xcbikqPykoPz1cXG5cXHMqI3wkKS9tO1xuICAgICAgICAgICAgICAgIGNvbnN0IHZvY2FiTWF0Y2hlcyA9IGNvbnRlbnQ/Lm1hdGNoKHZvY2FiUmVnZXgpO1xuXG4gICAgICAgICAgICAgICAgaWYgKHZvY2FiTWF0Y2hlcykge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCB2b2NhYkRhdGEgPSB2b2NhYk1hdGNoZXNbMV0udHJpbSgpO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBjbGVhbmVkVm9jYWIgPSB2b2NhYkRhdGFcbiAgICAgICAgICAgICAgICAgICAgICAgIC5yZXBsYWNlKC9cXFtcXFsuKj9cXF1cXF0vZywgXCJcIikgIC8vIFJlbW92ZSB3aWtpbGlua3NcbiAgICAgICAgICAgICAgICAgICAgICAgIC50cmltKClcbiAgICAgICAgICAgICAgICAgICAgICAgIC5zcGxpdChcIlxcblwiKVxuICAgICAgICAgICAgICAgICAgICAgICAgLmZpbHRlcigobGluZTogc3RyaW5nKSA9PiBsaW5lLnN0YXJ0c1dpdGgoXCItIFwiKSkgIC8vIE9ubHkgbGluZXMgc3RhcnRpbmcgd2l0aCBcIi0gXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIC5tYXAoKGxpbmU6IHN0cmluZykgPT4gbGluZS5zdWJzdHJpbmcoMikpICAvLyBSZW1vdmUgXCItIFwiIHByZWZpeFxuICAgICAgICAgICAgICAgICAgICAgICAgLmZpbHRlcihCb29sZWFuKTsgIC8vIFJlbW92ZSBlbXB0eSBlbnRyaWVzXG5cbiAgICAgICAgICAgICAgICAgICAgaWYgKGNsZWFuZWRWb2NhYi5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBkdi5oZWFkZXIoMywgYFtbJHtwYWdlLm5hbWV9XV1gKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGR2Lmxpc3QoY2xlYW5lZFZvY2FiKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGBFcnJvciBwcm9jZXNzaW5nICR7cGFnZS5wYXRofTpgLCBlKTtcbiAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGluIFZvY2FidWxhcnkgUHJvY2Vzc2luZzpcIiwgZXJyb3IpO1xuICAgIH1cbn1cblxuLyoqXG4gKiBQcm9jZXNzZXMgYW5kIGRpc3BsYXlzIGR1ZSBkYXRlcyBmcm9tIGFsbCBub3RlcyBhc3NvY2lhdGVkIHdpdGggYSBjb3Vyc2VcbiAqIEBwYXJhbSBkdiAtIFRoZSBkYXRhdmlldyBBUEkgb2JqZWN0XG4gKiBAcGFyYW0gc291cmNlIC0gVGhlIHRhZyBvciBwYXRoIHRvIHNlYXJjaCBmb3IgZHVlIGRhdGVzXG4gKiBAcGFyYW0gc3RhcnREYXRlIC0gT3B0aW9uYWwgc3RhcnQgZGF0ZSBmb3IgZmlsdGVyaW5nIChZWVlZLU1NLUREIGZvcm1hdClcbiAqIEBwYXJhbSBlbmREYXRlIC0gT3B0aW9uYWwgZW5kIGRhdGUgZm9yIGZpbHRlcmluZyAoWVlZWS1NTS1ERCBmb3JtYXQpXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBwcm9jZXNzRHVlRGF0ZXMoZHY6IGFueSwgc291cmNlOiBzdHJpbmcsIHN0YXJ0RGF0ZTogc3RyaW5nIHwgbnVsbCA9IG51bGwsIGVuZERhdGU6IHN0cmluZyB8IG51bGwgPSBudWxsKSB7XG4gICAgZnVuY3Rpb24gZGVkdXBsaWNhdGVGaXJzdFR3b0NvbHVtbnMoYXJyOiBhbnlbXSkge1xuICAgICAgICBjb25zdCBzZWVuID0gbmV3IFNldCgpO1xuICAgICAgICByZXR1cm4gYXJyLmZpbHRlcigoZW50cnk6IGFueSkgPT4ge1xuICAgICAgICAgICAgY29uc3Qga2V5ID0gSlNPTi5zdHJpbmdpZnkoW2VudHJ5WzBdLCBlbnRyeVsxXV0pO1xuICAgICAgICAgICAgcmV0dXJuICFzZWVuLmhhcyhrZXkpICYmIHNlZW4uYWRkKGtleSk7XG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8vIElmIG5vIGRhdGUgcmFuZ2UgaXMgc3BlY2lmaWVkLCBkZWZhdWx0IHRvIHNob3dpbmcgZGF0ZXMgc3RhcnRpbmcgZnJvbSB5ZXN0ZXJkYXlcbiAgICBjb25zdCBkZWZhdWx0U3RhcnREYXRlID0gKHdpbmRvdyBhcyBhbnkpLm1vbWVudCgpLnN1YnRyYWN0KDEsIFwiZGF5XCIpLmZvcm1hdChcIllZWVktTU0tRERcIik7XG4gICAgY29uc3Qgc3RhcnQgPSBzdGFydERhdGUgfHwgZGVmYXVsdFN0YXJ0RGF0ZTtcbiAgICBjb25zdCBlbmQgPSBlbmREYXRlIHx8ICh3aW5kb3cgYXMgYW55KS5tb21lbnQoKS5hZGQoMSwgXCJ5ZWFyXCIpLmZvcm1hdChcIllZWVktTU0tRERcIik7IC8vIFNob3cgYSB5ZWFyIG9mIGRhdGVzIGJ5IGRlZmF1bHRcblxuICAgIGNvbnN0IHBhZ2VzID0gYXdhaXQgZHYucGFnZXMoc291cmNlKVxuICAgICAgICAuZmlsdGVyKChwOiBhbnkpID0+IHAuZmlsZS5uYW1lICE9PSBzb3VyY2UgJiYgcC5maWxlLmV4dCA9PSBcIm1kXCIpO1xuXG4gICAgbGV0IGFsbEVudHJpZXM6IGFueVtdID0gW107XG5cbiAgICBmb3IgKGNvbnN0IHBhZ2Ugb2YgcGFnZXMudmFsdWVzKSB7XG4gICAgICAgIGlmICghcGFnZT8uZmlsZT8ucGF0aCkgeyByZXR1cm4gfVxuICAgICAgICBjb25zdCBjb250ZW50ID0gYXdhaXQgKGR2LmFwcC52YXVsdCBhcyBhbnkpLmNhY2hlZFJlYWQoKGR2LmFwcC52YXVsdCBhcyBhbnkpLmdldEZpbGVCeVBhdGgocGFnZS5maWxlPy5wYXRoKSk7XG4gICAgICAgIGNvbnN0IHJlZ2V4ID0gLyMgRHVlIERhdGVzKFtcXHNcXFNdKj8pKD89XFxuI3wkKS87XG4gICAgICAgIGNvbnN0IG1hdGNoZXMgPSBjb250ZW50Py5tYXRjaChyZWdleCk7XG4gICAgICAgIGlmIChtYXRjaGVzKSB7XG4gICAgICAgIGNvbnN0IHRhYmxlRGF0YSA9IG1hdGNoZXNbMV0udHJpbSgpO1xuICAgICAgICBjb25zdCBsaW5lcyA9IHRhYmxlRGF0YS5zcGxpdChcIlxcblwiKS5zbGljZSgxKTtcbiAgICAgICAgZm9yIChjb25zdCBsaW5lIG9mIGxpbmVzKSB7XG4gICAgICAgICAgICBsZXQgZm9ybWF0dGVkRHVlRGF0ZTogc3RyaW5nO1xuICAgICAgICAgICAgY29uc3QgY29sdW1ucyA9IGxpbmVcbiAgICAgICAgICAgIC5zcGxpdChcInxcIilcbiAgICAgICAgICAgIC5tYXAoKGM6IHN0cmluZykgPT4gYy50cmltKCkpXG4gICAgICAgICAgICAuZmlsdGVyKChjOiBzdHJpbmcpID0+IGMpO1xuICAgICAgICAgICAgbGV0IFtkdWVEYXRlLCBhc3NpZ25tZW50XSA9IGNvbHVtbnM7XG4gICAgICAgICAgICBpZiAoIURhdGUucGFyc2UoZHVlRGF0ZSkgfHwgYXNzaWdubWVudD8ubWF0Y2goL1x1MjcwNS8pKSB7XG4gICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGFzc2lnbm1lbnQgPSBhc3NpZ25tZW50Py5tYXRjaCgvW0EtWl17M30tWzAtOV17M30vKVxuICAgICAgICAgICAgPyBhc3NpZ25tZW50XG4gICAgICAgICAgICA6IGAjJHtwYWdlLmNvdXJzZV9pZH0gLSAke2Fzc2lnbm1lbnR9YDtcbiAgICAgICAgICAgIFxuICAgICAgICAgICAgaWYgKFxuICAgICAgICAgICAgKHdpbmRvdyBhcyBhbnkpLm1vbWVudChkdWVEYXRlKS5pc0JldHdlZW4oc3RhcnQsIGVuZCwgdW5kZWZpbmVkLCBcIltdXCIpICAvLyBpbmNsdWRlIGVuZHBvaW50c1xuICAgICAgICAgICAgKSB7XG4gICAgICAgICAgICBjb25zdCB1bmlxdWVSb3cgPSAhYWxsRW50cmllcy5zb21lKFxuICAgICAgICAgICAgICAgIChlOiBhbnkpID0+XG4gICAgICAgICAgICAgICAgZVswXS5tYXRjaCgod2luZG93IGFzIGFueSkubW9tZW50KGR1ZURhdGUpPy5mb3JtYXQoXCJZWVlZLU1NLUREXCIpKSAmJlxuICAgICAgICAgICAgICAgIGVbMV0gPT0gYXNzaWdubWVudFxuICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIGlmIChhc3NpZ25tZW50ICYmIHVuaXF1ZVJvdykge1xuICAgICAgICAgICAgICAgIGlmICgod2luZG93IGFzIGFueSkubW9tZW50KGR1ZURhdGUpPy5pc0JlZm9yZShzdGFydCkpIHtcbiAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKCh3aW5kb3cgYXMgYW55KS5tb21lbnQoZHVlRGF0ZSkuaXNBZnRlcigod2luZG93IGFzIGFueSkubW9tZW50KCkuc3VidHJhY3QoMSwgXCJ3XCIpKSkge1xuICAgICAgICAgICAgICAgIGZvcm1hdHRlZER1ZURhdGUgPSBgPHNwYW4gY2xhc3M9XCJkdWUgb25lX3dlZWtcIj4keyh3aW5kb3cgYXMgYW55KS5tb21lbnQoXG4gICAgICAgICAgICAgICAgICAgIGR1ZURhdGVcbiAgICAgICAgICAgICAgICApPy5mb3JtYXQoXCJZWVlZLU1NLUREIGRkZFwiKX08L3NwYW4+YDtcbiAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKCh3aW5kb3cgYXMgYW55KS5tb21lbnQoZHVlRGF0ZSkuaXNBZnRlcigod2luZG93IGFzIGFueSkubW9tZW50KCkuc3VidHJhY3QoMiwgXCJ3XCIpKSkge1xuICAgICAgICAgICAgICAgIGZvcm1hdHRlZER1ZURhdGUgPSBgPHNwYW4gY2xhc3M9XCJkdWUgdHdvX3dlZWtzXCI+JHsod2luZG93IGFzIGFueSkubW9tZW50KFxuICAgICAgICAgICAgICAgICAgICBkdWVEYXRlXG4gICAgICAgICAgICAgICAgKT8uZm9ybWF0KFwiWVlZWS1NTS1ERCBkZGRcIil9PC9zcGFuPmA7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBmb3JtYXR0ZWREdWVEYXRlID0gKHdpbmRvdyBhcyBhbnkpLm1vbWVudChkdWVEYXRlKT8uZm9ybWF0KFwiWVlZWS1NTS1ERCBkZGRcIik7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGFsbEVudHJpZXMucHVzaChbXG4gICAgICAgICAgICAgICAgZHVlRGF0ZSxcbiAgICAgICAgICAgICAgICBmb3JtYXR0ZWREdWVEYXRlLFxuICAgICAgICAgICAgICAgIGFzc2lnbm1lbnQsXG4gICAgICAgICAgICAgICAgYFtbJHtwYWdlPy5maWxlPy5wYXRofXwke3BhZ2U/LmZpbGU/Lm5hbWV9XV1gLFxuICAgICAgICAgICAgICAgIF0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBjb25zdCBzb3J0ZWRSb3dzID0gZGVkdXBsaWNhdGVGaXJzdFR3b0NvbHVtbnMoYWxsRW50cmllc1xuICAgICAgICAuc29ydCgoYTogYW55LCBiOiBhbnkpID0+ICh3aW5kb3cgYXMgYW55KS5tb21lbnQoYVswXSkudmFsdWVPZigpIC0gKHdpbmRvdyBhcyBhbnkpLm1vbWVudChiWzBdKS52YWx1ZU9mKCkgKSBcbiAgICAgICAgLm1hcCgoYTogYW55KSA9PiBbYVsxXSwgYVsyXSwgYVszXV0pXG4gICAgKTtcbiAgICBcbiAgICBjb25zdCB0YWJsZSA9IGR2Lm1hcmtkb3duVGFibGUoIFtcIkR1ZSBEYXRlXCIsIFwiVGFzayBEZXNjcmlwdGlvblwiLCBcIkZpbGVcIl0sIHNvcnRlZFJvd3MgKTtcbiAgICBkdi5lbChcInRhYmxlXCIsIHRhYmxlKTtcbn1cbiJdLAogICJtYXBwaW5ncyI6ICI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBQUFBLG1CQUFzQzs7O0FDQXRDLHNCQUErQzs7O0FDZ0J4QyxTQUFTLFFBQVEsTUFBc0I7QUFDNUMsU0FBTyxLQUNKLFlBQVksRUFDWixLQUFLLEVBQ0wsVUFBVSxLQUFLLEVBQ2YsUUFBUSxvQkFBb0IsRUFBRSxFQUM5QixRQUFRLGlCQUFpQixFQUFFLEVBQzNCLFFBQVEsV0FBVyxHQUFHLEVBQ3RCLFFBQVEsWUFBWSxFQUFFO0FBQzNCO0FBZU8sU0FBUyxhQUFhLFlBQTZCO0FBQ3hELFFBQU0sUUFBUTtBQUNkLE1BQUksQ0FBQyxXQUFXLE1BQU0sS0FBSztBQUFHLFdBQU87QUFFckMsUUFBTSxPQUFPLElBQUksS0FBSyxVQUFVO0FBQ2hDLFFBQU0sWUFBWSxLQUFLLFFBQVE7QUFFL0IsTUFBSSxPQUFPLGNBQWMsWUFBWSxNQUFNLFNBQVM7QUFBRyxXQUFPO0FBRTlELFNBQU8sZUFBZSxLQUFLLFlBQVksRUFBRSxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQ3ZEOzs7QURuQ08sSUFBTSxtQkFBeUM7QUFBQSxFQUNwRCxlQUFlO0FBQUEsRUFDZixtQkFBbUIsSUFBSSxLQUFLLEVBQUUsWUFBWSxFQUFFLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFBQSxFQUN4RCxpQkFBaUIsSUFBSSxLQUFLLElBQUksS0FBSyxFQUFFLFNBQVMsSUFBSSxLQUFLLEVBQUUsU0FBUyxJQUFJLENBQUMsQ0FBQyxFQUFFLFlBQVksRUFBRSxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsRUFDcEcsWUFBWTtBQUFBLEVBQ1osb0JBQW9CO0FBQUEsRUFDcEIsZ0JBQWdCO0FBQUEsRUFDaEIscUJBQXFCO0FBQUEsRUFDckIsZ0JBQWdCO0FBQ2xCO0FBRU8sSUFBTSx5QkFBTixjQUFxQyxpQ0FBaUI7QUFBQSxFQUczRCxZQUFZLEtBQVUsUUFBNEI7QUFDaEQsVUFBTSxLQUFLLE1BQU07QUFDakIsU0FBSyxTQUFTO0FBQUEsRUFDaEI7QUFBQSxFQUVBLFVBQWdCO0FBQ2QsVUFBTSxFQUFFLFlBQVksSUFBSTtBQUV4QixnQkFBWSxNQUFNO0FBRWxCLGdCQUFZLFNBQVMsTUFBTSxFQUFFLE1BQU0seUJBQXlCLENBQUM7QUFFN0QsUUFBSSx3QkFBUSxXQUFXLEVBQ3BCLFFBQVEsZ0JBQWdCLEVBQ3hCLFFBQVEsZ0RBQWdELEVBQ3hELFFBQVEsVUFBUSxLQUNkLGVBQWUsR0FBRyxFQUNsQixTQUFTLEtBQUssT0FBTyxTQUFTLGFBQWEsRUFDM0MsU0FBUyxDQUFPLFVBQVU7QUFDekIsV0FBSyxPQUFPLFNBQVMsZ0JBQWdCO0FBQ3JDLFlBQU0sS0FBSyxPQUFPLGFBQWE7QUFBQSxJQUNqQyxFQUFDLENBQUM7QUFFTixVQUFNLG1CQUFtQixJQUFJLHdCQUFRLFdBQVcsRUFDN0MsUUFBUSxxQkFBcUIsRUFDN0IsUUFBUSxxQ0FBcUMsRUFDN0MsUUFBUSxVQUFRLEtBQ2QsZUFBZSxZQUFZLEVBQzNCLFNBQVMsS0FBSyxPQUFPLFNBQVMsaUJBQWlCLEVBQy9DLFNBQVMsQ0FBTyxVQUFVO0FBQ3pCLFVBQUksU0FBUyxDQUFDLGFBQWEsS0FBSyxHQUFHO0FBQ2pDLHlCQUFpQixRQUFRLDJEQUEyRDtBQUFBLE1BQ3RGLE9BQU87QUFDTCx5QkFBaUIsUUFBUSxxQ0FBcUM7QUFBQSxNQUNoRTtBQUNBLFdBQUssT0FBTyxTQUFTLG9CQUFvQjtBQUN6QyxZQUFNLEtBQUssT0FBTyxhQUFhO0FBQUEsSUFDakMsRUFBQyxDQUFDO0FBRU4sVUFBTSxpQkFBaUIsSUFBSSx3QkFBUSxXQUFXLEVBQzNDLFFBQVEsbUJBQW1CLEVBQzNCLFFBQVEsbUNBQW1DLEVBQzNDLFFBQVEsVUFBUSxLQUNkLGVBQWUsWUFBWSxFQUMzQixTQUFTLEtBQUssT0FBTyxTQUFTLGVBQWUsRUFDN0MsU0FBUyxDQUFPLFVBQVU7QUFDekIsVUFBSSxTQUFTLENBQUMsYUFBYSxLQUFLLEdBQUc7QUFDakMsdUJBQWUsUUFBUSx5REFBeUQ7QUFBQSxNQUNsRixPQUFPO0FBQ0wsdUJBQWUsUUFBUSxtQ0FBbUM7QUFBQSxNQUM1RDtBQUNBLFdBQUssT0FBTyxTQUFTLGtCQUFrQjtBQUN2QyxZQUFNLEtBQUssT0FBTyxhQUFhO0FBQUEsSUFDakMsRUFBQyxDQUFDO0FBRU4sUUFBSSx3QkFBUSxXQUFXLEVBQ3BCLFFBQVEsYUFBYSxFQUNyQixRQUFRLDBCQUEwQixFQUNsQyxRQUFRLFVBQVEsS0FDZCxlQUFlLFlBQVksRUFDM0IsU0FBUyxLQUFLLE9BQU8sU0FBUyxVQUFVLEVBQ3hDLFNBQVMsQ0FBTyxVQUFVO0FBQ3pCLFdBQUssT0FBTyxTQUFTLGFBQWE7QUFDbEMsWUFBTSxLQUFLLE9BQU8sYUFBYTtBQUFBLElBQ2pDLEVBQUMsQ0FBQztBQUVOLFFBQUksd0JBQVEsV0FBVyxFQUNwQixRQUFRLHFCQUFxQixFQUM3QixRQUFRLG1DQUFtQyxFQUMzQyxRQUFRLFVBQVEsS0FDZCxlQUFlLEdBQUcsRUFDbEIsU0FBUyxLQUFLLE9BQU8sU0FBUyxrQkFBa0IsRUFDaEQsU0FBUyxDQUFPLFVBQVU7QUFDekIsV0FBSyxPQUFPLFNBQVMscUJBQXFCO0FBQzFDLFlBQU0sS0FBSyxPQUFPLGFBQWE7QUFBQSxJQUNqQyxFQUFDLENBQUM7QUFFTixRQUFJLHdCQUFRLFdBQVcsRUFDcEIsUUFBUSxpQkFBaUIsRUFDekIsUUFBUSw2RUFBNkUsRUFDckYsUUFBUSxVQUFRLEtBQ2QsZUFBZSxlQUFlLEVBQzlCLFNBQVMsS0FBSyxPQUFPLFNBQVMsY0FBYyxFQUM1QyxTQUFTLENBQU8sVUFBVTtBQUN6QixXQUFLLE9BQU8sU0FBUyxpQkFBaUI7QUFDdEMsWUFBTSxLQUFLLE9BQU8sYUFBYTtBQUFBLElBQ2pDLEVBQUMsQ0FBQztBQUVOLFFBQUksd0JBQVEsV0FBVyxFQUNwQixRQUFRLHVCQUF1QixFQUMvQixRQUFRLGlGQUFpRixFQUN6RixVQUFVLFlBQVUsT0FDbEIsU0FBUyxLQUFLLE9BQU8sU0FBUyxtQkFBbUIsRUFDakQsU0FBUyxDQUFPLFVBQVU7QUFDekIsV0FBSyxPQUFPLFNBQVMsc0JBQXNCO0FBQzNDLFlBQU0sS0FBSyxPQUFPLGFBQWE7QUFBQSxJQUNqQyxFQUFDLENBQUM7QUFFTixRQUFJLHdCQUFRLFdBQVcsRUFDcEIsUUFBUSx5QkFBeUIsRUFDakMsUUFBUSx5REFBeUQsRUFDakUsUUFBUSxVQUFRLEtBQ2QsZUFBZSxnQ0FBZ0MsRUFDL0MsU0FBUyxLQUFLLE9BQU8sU0FBUyxjQUFjLEVBQzVDLFNBQVMsQ0FBTyxVQUFVO0FBQ3pCLFdBQUssT0FBTyxTQUFTLGlCQUFpQjtBQUN0QyxZQUFNLEtBQUssT0FBTyxhQUFhO0FBQUEsSUFDakMsRUFBQyxDQUFDO0FBQUEsRUFDUjtBQUNGOzs7QUUxSUEsSUFBQUMsbUJBQTRCO0FBVXJCLElBQU0sa0JBQU4sTUFBc0I7QUFBQSxFQUszQixZQUFZLEtBQVUsVUFBZ0M7QUFDcEQsU0FBSyxNQUFNO0FBQ1gsU0FBSyxXQUFXO0FBQ2hCLFNBQUssV0FBVztBQUFBLE1BQ2QsU0FBUztBQUFBLE1BQ1QsV0FBVztBQUFBLFFBQ1QscUNBQXFDO0FBQUEsUUFDckMsMkJBQTJCO0FBQUEsUUFDM0IsNEJBQTRCO0FBQUEsUUFDNUIsOEJBQThCO0FBQUEsUUFDOUIsb0NBQW9DO0FBQUEsUUFDcEMsdUJBQXVCO0FBQUEsUUFDdkIsaUNBQWlDO0FBQUEsUUFDakMsK0JBQStCO0FBQUEsTUFDakM7QUFBQSxNQUNBLGdCQUFnQjtBQUFBLE1BQ2hCLGVBQWU7QUFBQSxJQUNqQjtBQUFBLEVBQ0Y7QUFBQSxFQUVNLG1CQUFtQjtBQUFBO0FBQ3ZCLFVBQUk7QUFFRixjQUFNLGtCQUFrQixLQUFLLG1CQUFtQjtBQUNoRCxZQUFJLENBQUMsaUJBQWlCO0FBQ3BCLGNBQUk7QUFBQSxZQUNGO0FBQUEsVUFDRjtBQUNBLGtCQUFRO0FBQUEsWUFDTjtBQUFBLFVBQ0Y7QUFDQTtBQUFBLFFBQ0Y7QUFFQSxjQUFNLHFCQUFxQixLQUFLLHNCQUFzQixlQUFlO0FBQ3JFLFlBQUksQ0FBQyxvQkFBb0I7QUFDdkIsY0FBSTtBQUFBLFlBQ0Y7QUFBQSxVQUNGO0FBQ0Esa0JBQVE7QUFBQSxZQUNOO0FBQUEsVUFDRjtBQUNBO0FBQUEsUUFDRjtBQUVBLGNBQU0sbUJBQW1CLEdBQUcsc0JBQXNCLEtBQUssU0FBUztBQUdoRSxZQUFJO0FBQ0YsZ0JBQU0sS0FBSyxJQUFJLE1BQU0sYUFBYSxnQkFBZ0I7QUFDbEQsa0JBQVEsSUFBSSw0QkFBNEIsa0JBQWtCO0FBQUEsUUFDNUQsU0FBUyxHQUFQO0FBRUEsa0JBQVE7QUFBQSxZQUNOLDhDQUE4QztBQUFBLFVBQ2hEO0FBQUEsUUFDRjtBQUdBLGNBQU0sVUFBVTtBQUFBLFVBQ2Q7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFFBQ0Y7QUFDQSxtQkFBVyxVQUFVLFNBQVM7QUFDNUIsY0FBSTtBQUNGLGtCQUFNLFVBQVUsR0FBRyxvQkFBb0I7QUFDdkMsa0JBQU0sS0FBSyxJQUFJLE1BQU0sYUFBYSxPQUFPO0FBQ3pDLG9CQUFRLElBQUkseUJBQXlCLFNBQVM7QUFBQSxVQUNoRCxTQUFTLEdBQVA7QUFFQSxvQkFBUTtBQUFBLGNBQ04sZ0NBQWdDLG9CQUFvQjtBQUFBLFlBQ3REO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFHQSxjQUFNLEtBQUssdUJBQXVCLGdCQUFnQjtBQUNsRCxjQUFNLEtBQUssdUJBQXVCLGdCQUFnQjtBQUNsRCxjQUFNLEtBQUssd0JBQXdCLGdCQUFnQjtBQUNuRCxjQUFNLEtBQUssMkJBQTJCLGdCQUFnQjtBQUN0RCxjQUFNLEtBQUssc0JBQXNCLGdCQUFnQjtBQUNqRCxjQUFNLEtBQUssd0JBQXdCLGdCQUFnQjtBQUduRCxjQUFNLEtBQUssYUFBYSxnQkFBZ0I7QUFHeEMsY0FBTSxLQUFLLHVCQUF1QixnQkFBZ0I7QUFFbEQsWUFBSSx3QkFBTyxpREFBaUQ7QUFDNUQsZ0JBQVEsSUFBSSxnREFBZ0Q7QUFBQSxNQUM5RCxTQUFTLE9BQVA7QUFDQSxnQkFBUSxNQUFNLCtCQUErQixLQUFLO0FBQ2xELFlBQUksd0JBQU8sd0RBQXdEO0FBQUEsTUFDckU7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVRLHFCQUEwQjtBQUVoQyxVQUFNLGdCQUFnQjtBQUFBLE1BQ25CLEtBQUssSUFBWSxRQUFRLFFBQVEsb0JBQW9CO0FBQUEsTUFDckQsS0FBSyxJQUFZLFFBQVEsUUFBUSxXQUFXO0FBQUEsTUFDNUMsS0FBSyxJQUFZLFFBQVEsVUFBVSxvQkFBb0I7QUFBQSxNQUN2RCxLQUFLLElBQVksUUFBUSxVQUFVLFdBQVc7QUFBQSxJQUNqRDtBQUVBLGVBQVcsUUFBUSxlQUFlO0FBQ2hDLFVBQUksTUFBTTtBQUNSLGVBQU87QUFBQSxNQUNUO0FBQUEsSUFDRjtBQUVBLFdBQU87QUFBQSxFQUNUO0FBQUEsRUFFUSxzQkFBc0IsaUJBQXFDO0FBQ2pFLFVBQU0sV0FBVyxnQkFBZ0I7QUFFakMsUUFBSSxDQUFDLFVBQVU7QUFDYixjQUFRLE1BQU0sa0NBQWtDO0FBQ2hELGFBQU87QUFBQSxJQUNUO0FBR0EsVUFBTSxnQkFBZ0I7QUFBQSxNQUNwQixTQUFTO0FBQUE7QUFBQSxNQUNULFNBQVM7QUFBQSxNQUNULFNBQVM7QUFBQSxNQUNULFNBQVM7QUFBQSxNQUNULFNBQVM7QUFBQSxJQUNYO0FBRUEsZUFBVyxRQUFRLGVBQWU7QUFDaEMsVUFBSSxRQUFRLE9BQU8sU0FBUyxVQUFVO0FBQ3BDLGVBQU87QUFBQSxNQUNUO0FBQUEsSUFDRjtBQUVBLFlBQVE7QUFBQSxNQUNOO0FBQUEsTUFDQSxPQUFPLEtBQUssUUFBUTtBQUFBLElBQ3RCO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUVNLHVCQUF1QixVQUFrQjtBQUFBO0FBQzdDLFlBQU0sZUFBZSxHQUFHO0FBQ3hCLFlBQU0sa0JBQWtCLEtBQUssVUFBVSxLQUFLLFVBQVUsTUFBTSxDQUFDO0FBRTdELFVBQUk7QUFFRixjQUFNLG1CQUNKLEtBQUssSUFBSSxNQUFNLHNCQUFzQixZQUFZO0FBQ25ELFlBQUksa0JBQWtCO0FBRXBCLGdCQUFNLE9BQU87QUFDYixnQkFBTSxLQUFLLElBQUksTUFBTSxPQUFPLE1BQU0sZUFBZTtBQUNqRCxrQkFBUSxJQUFJLDhCQUE4QixjQUFjO0FBQ3hEO0FBQUEsUUFDRjtBQUdBLGNBQU0sS0FBSyxJQUFJLE1BQU0sT0FBTyxjQUFjLGVBQWU7QUFDekQsZ0JBQVEsSUFBSSw4QkFBOEIsY0FBYztBQUFBLE1BQzFELFNBQVMsR0FBUDtBQUNBLFlBQUksd0JBQU8sb0NBQW9DLGNBQWM7QUFDN0QsZ0JBQVEsTUFBTSxvQ0FBb0MsaUJBQWlCLENBQUM7QUFBQSxNQUN0RTtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRU0sMEJBQTRDO0FBQUE7QUFHaEQsY0FBUSxJQUFJLCtCQUErQjtBQUMzQyxhQUFPO0FBQUEsSUFDVDtBQUFBO0FBQUEsRUFFTSxrQkFBa0I7QUFBQTtBQUN0QixVQUFJO0FBRUYsZ0JBQVEsSUFBSSxvQkFBb0I7QUFHaEMsY0FBTSxrQkFBa0IsS0FBSyxtQkFBbUI7QUFDaEQsWUFBSSxDQUFDLGlCQUFpQjtBQUNwQixjQUFJO0FBQUEsWUFDRjtBQUFBLFVBQ0Y7QUFDQSxrQkFBUTtBQUFBLFlBQ047QUFBQSxVQUNGO0FBQ0E7QUFBQSxRQUNGO0FBRUEsY0FBTSxxQkFBcUIsS0FBSyxzQkFBc0IsZUFBZTtBQUNyRSxZQUFJLENBQUMsb0JBQW9CO0FBQ3ZCLGNBQUk7QUFBQSxZQUNGO0FBQUEsVUFDRjtBQUNBLGtCQUFRO0FBQUEsWUFDTjtBQUFBLFVBQ0Y7QUFDQTtBQUFBLFFBQ0Y7QUFFQSxjQUFNLG1CQUFtQixHQUFHLHNCQUFzQixLQUFLLFNBQVM7QUFHaEUsY0FBTSxLQUFLLHVCQUF1QixnQkFBZ0I7QUFDbEQsY0FBTSxLQUFLLHVCQUF1QixnQkFBZ0I7QUFDbEQsY0FBTSxLQUFLLHdCQUF3QixnQkFBZ0I7QUFDbkQsY0FBTSxLQUFLLDJCQUEyQixnQkFBZ0I7QUFDdEQsY0FBTSxLQUFLLHNCQUFzQixnQkFBZ0I7QUFDakQsY0FBTSxLQUFLLHdCQUF3QixnQkFBZ0I7QUFHbkQsY0FBTSxLQUFLLGFBQWEsZ0JBQWdCO0FBR3hDLGNBQU0sS0FBSyx1QkFBdUIsZ0JBQWdCO0FBRWxELFlBQUksd0JBQU8sK0NBQStDO0FBQzFELGdCQUFRLElBQUksOENBQThDO0FBQUEsTUFDNUQsU0FBUyxPQUFQO0FBQ0EsZ0JBQVEsTUFBTSw2QkFBNkIsS0FBSztBQUNoRCxZQUFJLHdCQUFPLHNEQUFzRDtBQUFBLE1BQ25FO0FBQUEsSUFDRjtBQUFBO0FBQUEsRUFFTSx1QkFBdUIsVUFBa0I7QUFBQTtBQUM3QyxZQUFNLGFBQWEsR0FBRztBQUd0QixZQUFNLHlCQUF5QixLQUFLLCtCQUErQjtBQUNuRSxZQUFNLEtBQUs7QUFBQSxRQUNULEdBQUc7QUFBQSxRQUNIO0FBQUEsTUFDRjtBQUdBLFlBQU0sc0JBQXNCLEtBQUssNEJBQTRCO0FBQzdELFlBQU0sS0FBSztBQUFBLFFBQ1QsR0FBRztBQUFBLFFBQ0g7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBO0FBQUEsRUFFTSx1QkFBdUIsVUFBa0I7QUFBQTtBQUM3QyxZQUFNLGFBQWEsR0FBRztBQUd0QixZQUFNLGlCQUFpQixLQUFLLHVCQUF1QjtBQUNuRCxZQUFNLEtBQUs7QUFBQSxRQUNULEdBQUc7QUFBQSxRQUNIO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRU0sd0JBQXdCLFVBQWtCO0FBQUE7QUFDOUMsWUFBTSxjQUFjLEdBQUc7QUFHdkIsWUFBTSxrQkFBa0IsS0FBSyx3QkFBd0I7QUFDckQsWUFBTSxLQUFLO0FBQUEsUUFDVCxHQUFHO0FBQUEsUUFDSDtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVNLDJCQUEyQixVQUFrQjtBQUFBO0FBQ2pELFlBQU0saUJBQWlCLEdBQUc7QUFHMUIsWUFBTSxxQkFBcUIsS0FBSywyQkFBMkI7QUFDM0QsWUFBTSxLQUFLO0FBQUEsUUFDVCxHQUFHO0FBQUEsUUFDSDtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVNLHNCQUFzQixVQUFrQjtBQUFBO0FBQzVDLFlBQU0sWUFBWSxHQUFHO0FBR3JCLFlBQU0sb0JBQW9CLEtBQUssMEJBQTBCO0FBQ3pELFlBQU0sS0FBSztBQUFBLFFBQ1QsR0FBRztBQUFBLFFBQ0g7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBO0FBQUEsRUFFTSx3QkFBd0IsVUFBa0I7QUFBQTtBQUM5QyxZQUFNLGNBQWMsR0FBRztBQUd2QixZQUFNLGdCQUFnQixLQUFLLDJCQUEyQjtBQUN0RCxZQUFNLEtBQUs7QUFBQSxRQUNULEdBQUc7QUFBQSxRQUNIO0FBQUEsTUFDRjtBQUdBLFlBQU0sa0JBQWtCLEtBQUssd0JBQXdCO0FBQ3JELFlBQU0sS0FBSztBQUFBLFFBQ1QsR0FBRztBQUFBLFFBQ0g7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBO0FBQUEsRUFFTSxrQkFBa0IsTUFBYyxTQUFpQjtBQUFBO0FBQ3JELFVBQUk7QUFFRixjQUFNLGVBQWUsS0FBSyxJQUFJLE1BQU0sc0JBQXNCLElBQUk7QUFDOUQsWUFBSSxjQUFjO0FBR2hCLGtCQUFRLElBQUksb0NBQW9DLE1BQU07QUFDdEQsZ0JBQU0sT0FBTztBQUNiLGdCQUFNLEtBQUssSUFBSSxNQUFNLE9BQU8sTUFBTSxPQUFPO0FBQ3pDO0FBQUEsUUFDRjtBQUdBLGNBQU0sS0FBSyxJQUFJLE1BQU0sT0FBTyxNQUFNLE9BQU87QUFDekMsZ0JBQVEsSUFBSSwwQkFBMEIsTUFBTTtBQUFBLE1BQzlDLFNBQVMsR0FBUDtBQUNBLFlBQUksd0JBQU8sZ0NBQWdDLE1BQU07QUFDakQsZ0JBQVEsTUFBTSxnQ0FBZ0MsU0FBUyxDQUFDO0FBQUEsTUFDMUQ7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVBLGlDQUF5QztBQUN2QyxVQUFNLG1CQUFtQixLQUFLLFNBQVM7QUFFdkMsUUFBSSxrQkFBa0I7QUFDcEIsVUFBSSxXQUFXO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQXlDZixLQUFLLFNBQVM7QUFBQTtBQUFBO0FBQUEsTUFHZCxLQUFLLFNBQVMsV0FBVyxRQUFRLFFBQVEsR0FBRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBYXBDLEtBQUssU0FBUztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwR0FpQzhFLEtBQUssU0FBUyxrQkFBa0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0dBTXhDLEtBQUssU0FBUyxrQkFBa0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBVXpILGFBQU87QUFBQSxJQUNaLE9BQU87QUFDTCxVQUFJLFdBQVc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBa0RQLEtBQUssU0FBUztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwR0FvQzhFLEtBQUssU0FBUyxrQkFBa0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0dBTXhDLEtBQUssU0FBUyxrQkFBa0I7QUFBQTtBQUFBO0FBSzVILGFBQU87QUFBQSxJQUNUO0FBQUEsRUFDRjtBQUFBLEVBRUEsOEJBQXNDO0FBQ3BDLFdBQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQW1CVDtBQUFBLEVBRUEseUJBQWlDO0FBQy9CLFdBQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVFULEtBQUssU0FBUyxzQkFDVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUNBTUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQ0F1QitCLEtBQUssU0FBUyxrQkFBa0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkNBZXhCLEtBQUssU0FBUyxrQkFBa0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBSzNFO0FBQUEsRUFFQSwwQkFBa0M7QUFDaEMsV0FBTztBQUFBO0FBQUE7QUFBQSxFQUlULEtBQUssU0FBUyxzQkFDVjtBQUFBO0FBQUE7QUFBQTtBQUFBLG9DQUtBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQThCSjtBQUFBLEVBRUEsNkJBQXFDO0FBQ25DLFdBQU87QUFBQSxFQUVULEtBQUssU0FBUyxzQkFDVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUNBTUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUErQko7QUFBQSxFQUVBLDRCQUFvQztBQUNsQyxXQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQW1DVDtBQUFBLEVBRUEsNkJBQXFDO0FBQ25DLFdBQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBUVQ7QUFBQSxFQUVBLDBCQUFrQztBQUNoQyxXQUFPO0FBQUEsRUFDVDtBQUFBLEVBRU0sYUFBYSxVQUFrQjtBQUFBO0FBQ25DLFlBQU0sZ0JBQWdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQXlCdEIsWUFBTSxLQUFLLGtCQUFrQixHQUFHLHNCQUFzQixhQUFhO0FBQUEsSUFDckU7QUFBQTtBQUNGOzs7QUM1eUJBLElBQUFDLG1CQUFtQzs7O0FDRm5DLElBQUFDLG1CQUFvQztBQUU3QixJQUFNLGFBQU4sY0FBeUIsdUJBQU07QUFBQSxFQUlwQyxZQUFZLEtBQVUsVUFBMkM7QUFDL0QsVUFBTSxHQUFHO0FBQ1QsU0FBSyxXQUFXO0FBQUEsRUFDbEI7QUFBQSxFQUVBLFNBQVM7QUFDUCxVQUFNLEVBQUUsVUFBVSxJQUFJO0FBRXRCLGNBQVUsU0FBUyxNQUFNLEVBQUUsTUFBTSxjQUFjLENBQUM7QUFFaEQsUUFBSSx5QkFBUSxTQUFTLEVBQ2xCLFFBQVEsT0FBTyxFQUNmO0FBQUEsTUFBUSxDQUFDLFNBQ1IsS0FDRyxTQUFTLENBQUMsVUFBVTtBQUNuQixhQUFLLFNBQVM7QUFBQSxNQUNoQixDQUFDLEVBQ0EsUUFBUSxNQUFNO0FBQUEsSUFDbkI7QUFFRixRQUFJLHlCQUFRLFNBQVMsRUFDbEI7QUFBQSxNQUFVLENBQUMsUUFDVixJQUNHLGNBQWMsUUFBUSxFQUN0QixPQUFPLEVBQ1AsUUFBUSxNQUFNO0FBQ2IsYUFBSyxNQUFNO0FBQ1gsYUFBSyxTQUFTLEtBQUssVUFBVSxFQUFFO0FBQUEsTUFDakMsQ0FBQztBQUFBLElBQ0wsRUFDQztBQUFBLE1BQVUsQ0FBQyxRQUNWLElBQUksY0FBYyxRQUFRLEVBQUUsUUFBUSxNQUFNO0FBQ3hDLGFBQUssTUFBTTtBQUNYLGFBQUssU0FBUyxJQUFJO0FBQUEsTUFDcEIsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNKO0FBQUEsRUFFQSxVQUFVO0FBQ1IsVUFBTSxFQUFFLFVBQVUsSUFBSTtBQUN0QixjQUFVLE1BQU07QUFBQSxFQUNsQjtBQUNGO0FBRU8sSUFBTSxpQkFBTixjQUE2Qix1QkFBTTtBQUFBLEVBSXhDLFlBQVksS0FBVSxTQUFtQixVQUEyQztBQUNsRixVQUFNLEdBQUc7QUFDVCxTQUFLLFdBQVc7QUFHaEIsVUFBTSxrQkFBNkMsQ0FBQztBQUNwRCxZQUFRLFFBQVEsWUFBVTtBQUN4QixzQkFBZ0IsTUFBTSxJQUFJO0FBQUEsSUFDNUIsQ0FBQztBQUVELFNBQUssZUFBZSxlQUFlO0FBQUEsRUFDckM7QUFBQSxFQUVBLGVBQWUsU0FBb0M7QUFDakQsVUFBTSxFQUFFLFVBQVUsSUFBSTtBQUV0QixjQUFVLFNBQVMsTUFBTSxFQUFFLE1BQU0sZ0JBQWdCLENBQUM7QUFFbEQsUUFBSSxnQkFBZ0IsT0FBTyxLQUFLLE9BQU8sRUFBRSxDQUFDLEtBQUs7QUFFL0MsVUFBTSxXQUFXLFVBQVUsU0FBUyxRQUFRO0FBQzVDLFdBQU8sUUFBUSxPQUFPLEVBQUUsUUFBUSxDQUFDLENBQUMsS0FBSyxLQUFLLE1BQU07QUFDaEQsWUFBTSxTQUFTLFNBQVMsU0FBUyxVQUFVO0FBQUEsUUFDekMsT0FBTztBQUFBLFFBQ1AsTUFBTTtBQUFBLE1BQ1IsQ0FBQztBQUNELFVBQUksUUFBUSxlQUFlO0FBQ3pCLGVBQU8sV0FBVztBQUFBLE1BQ3BCO0FBQUEsSUFDRixDQUFDO0FBRUQsYUFBUyxpQkFBaUIsVUFBVSxDQUFDLFVBQVU7QUFDN0Msc0JBQWlCLE1BQU0sT0FBNkI7QUFDcEQsV0FBSyxTQUFTO0FBQUEsSUFDaEIsQ0FBQztBQUVELFFBQUkseUJBQVEsU0FBUyxFQUNsQjtBQUFBLE1BQVUsQ0FBQyxRQUNWLElBQ0csY0FBYyxRQUFRLEVBQ3RCLE9BQU8sRUFDUCxRQUFRLE1BQU07QUFDYixhQUFLLE1BQU07QUFDWCxhQUFLLFNBQVMsYUFBYTtBQUFBLE1BQzdCLENBQUM7QUFBQSxJQUNMLEVBQ0M7QUFBQSxNQUFVLENBQUMsUUFDVixJQUFJLGNBQWMsUUFBUSxFQUFFLFFBQVEsTUFBTTtBQUN4QyxhQUFLLE1BQU07QUFDWCxhQUFLLFNBQVMsSUFBSTtBQUFBLE1BQ3BCLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDSjtBQUFBLEVBRUEsU0FBUztBQUFBLEVBRVQ7QUFBQSxFQUVBLFVBQVU7QUFDUixVQUFNLEVBQUUsVUFBVSxJQUFJO0FBQ3RCLGNBQVUsTUFBTTtBQUFBLEVBQ2xCO0FBQ0Y7OztBRDVHTyxJQUFNLHVCQUFOLE1BQTJCO0FBQUEsRUFJaEMsWUFBWSxLQUFVLFVBQWdDO0FBQ3BELFNBQUssTUFBTTtBQUNYLFNBQUssV0FBVztBQUFBLEVBQ2xCO0FBQUEsRUFFTSx1QkFBdUI7QUFBQTtBQUMzQixVQUFJO0FBRUYsY0FBTSxnQkFBZ0IsTUFBTSxLQUFLLG9CQUFvQjtBQUVyRCxZQUFJLENBQUMsZUFBZTtBQUNsQixpQkFBTztBQUFBLFFBQ1Q7QUFHQSxjQUFNLGFBQWEsTUFBTSxLQUFLLDRCQUE0QixhQUFhO0FBR3ZFLGNBQU0sS0FBSyx5QkFBeUIsZUFBZSxVQUFVO0FBRzdELGNBQU0sS0FBSyx3QkFBd0IsVUFBVTtBQUU3QyxZQUFJLHdCQUFPLFdBQVcsY0FBYyxtQ0FBbUM7QUFDdkUsZ0JBQVE7QUFBQSxVQUNOLG1CQUFtQixjQUFjLGlCQUFpQjtBQUFBLFFBQ3BEO0FBRUEsZUFBTztBQUFBLE1BQ1QsU0FBUyxPQUFQO0FBQ0EsZ0JBQVEsTUFBTSwwQkFBMEIsS0FBSztBQUM3QyxZQUFJLHdCQUFPLDBCQUEwQixNQUFNLFNBQVM7QUFDcEQsZUFBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVjLHNCQUtKO0FBQUE7QUFyRFo7QUFzREksVUFBSTtBQUNGLGNBQU0sYUFBYSxNQUFNLEtBQUs7QUFBQSxVQUM1QjtBQUFBLFVBQ0E7QUFBQSxVQUNBLENBQUMsVUFBVSxNQUFNLEtBQUssRUFBRSxTQUFTO0FBQUEsVUFDakM7QUFBQSxRQUNGO0FBRUEsWUFBSSxDQUFDO0FBQVksaUJBQU87QUFFeEIsY0FBTSxlQUFlLE1BQU0sS0FBSztBQUFBLFVBQzlCO0FBQUEsVUFDQTtBQUFBLFVBQ0EsQ0FBQyxRQUFRLFVBQVUsVUFBVSxRQUFRO0FBQUEsUUFDdkM7QUFFQSxZQUFJLENBQUM7QUFBYyxpQkFBTztBQUUxQixjQUFNLGFBQWEsTUFBTSxLQUFLO0FBQUEsVUFDNUI7QUFBQSxVQUNBO0FBQUEsVUFDQSxDQUFDLFVBQVUsVUFBVSxLQUFLLE1BQU0sS0FBSyxDQUFDO0FBQUEsVUFDdEM7QUFBQSxRQUNGO0FBRUEsWUFBSSxDQUFDO0FBQVksaUJBQU87QUFFeEIsY0FBTSxhQUFXLGdCQUFXLE1BQU0sS0FBSyxFQUFFLENBQUMsTUFBekIsbUJBQTRCLFdBQVUsUUFBUSxVQUFVO0FBRXpFLGVBQU87QUFBQSxVQUNMO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsUUFDRjtBQUFBLE1BQ0YsU0FBUyxPQUFQO0FBQ0EsZ0JBQVEsTUFBTSx1Q0FBdUMsS0FBSztBQUMxRCxlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRWMscUJBQ1osT0FDQSxTQUNBLFdBQ0EsY0FDd0I7QUFBQTtBQUN4QixhQUFPLElBQUksUUFBUSxDQUFDLFlBQVk7QUFDOUIsY0FBTSxRQUFRLElBQUksV0FBVyxLQUFLLEtBQUssQ0FBQyxXQUFXO0FBQ2pELGNBQUksV0FBVyxNQUFNO0FBRW5CLG9CQUFRLElBQUk7QUFDWjtBQUFBLFVBQ0Y7QUFFQSxjQUFJLENBQUMsVUFBVSxNQUFNLEdBQUc7QUFDdEIsZ0JBQUksd0JBQU8sWUFBWTtBQUV2QixpQkFBSyxxQkFBcUIsT0FBTyxTQUFTLFdBQVcsWUFBWSxFQUM5RCxLQUFLLE9BQU87QUFDZjtBQUFBLFVBQ0Y7QUFFQSxrQkFBUSxPQUFPLEtBQUssQ0FBQztBQUFBLFFBQ3ZCLENBQUM7QUFHRCxjQUFNLFFBQVEsUUFBUSxLQUFLO0FBQzNCLGNBQU0sWUFBWSxNQUFNLFVBQVUsVUFBVTtBQUM1QyxrQkFBVSxRQUFRLE9BQU87QUFFekIsY0FBTSxLQUFLO0FBQUEsTUFDYixDQUFDO0FBQUEsSUFDSDtBQUFBO0FBQUEsRUFFYyxrQkFDWixPQUNBLFNBQ0EsU0FDd0I7QUFBQTtBQUN4QixhQUFPLElBQUksUUFBUSxDQUFDLFlBQVk7QUFDOUIsY0FBTSxRQUFRLElBQUksZUFBZSxLQUFLLEtBQUssU0FBUyxDQUFDLFdBQVc7QUFDOUQsY0FBSSxXQUFXLE1BQU07QUFFbkIsb0JBQVEsSUFBSTtBQUNaO0FBQUEsVUFDRjtBQUVBLGNBQUksUUFBUSxTQUFTLE1BQU0sR0FBRztBQUM1QixvQkFBUSxNQUFNO0FBQUEsVUFDaEIsT0FBTztBQUNMLGdCQUFJLHdCQUFPLHlCQUF5QixRQUFRLEtBQUssSUFBSSxHQUFHO0FBRXhELGlCQUFLLGtCQUFrQixPQUFPLFNBQVMsT0FBTyxFQUMzQyxLQUFLLE9BQU87QUFBQSxVQUNqQjtBQUFBLFFBQ0YsQ0FBQztBQUdELGNBQU0sUUFBUSxRQUFRLEtBQUs7QUFDM0IsY0FBTSxZQUFZLE1BQU0sVUFBVSxVQUFVO0FBQzVDLGtCQUFVLFFBQVEsT0FBTztBQUV6QixjQUFNLEtBQUs7QUFBQSxNQUNiLENBQUM7QUFBQSxJQUNIO0FBQUE7QUFBQSxFQUVjLDRCQUE0QixlQUt0QjtBQUFBO0FBQ2xCLFlBQU0sYUFBYSxHQUFHLGNBQWMsY0FBYyxjQUFjLGdCQUFnQixjQUFjO0FBRTlGLFVBQUk7QUFDRixjQUFNLEtBQUssSUFBSSxNQUFNLGFBQWEsVUFBVTtBQUM1QyxnQkFBUSxJQUFJLDBCQUEwQixZQUFZO0FBQ2xELGVBQU87QUFBQSxNQUNULFNBQVMsT0FBUDtBQUVBLGdCQUFRLElBQUksNENBQTRDLFlBQVk7QUFDcEUsZUFBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVjLHlCQUNaLGVBTUEsWUFDZTtBQUFBO0FBQ2YsWUFBTSxXQUFXLEdBQUcsY0FBYyxjQUFjO0FBQ2hELFlBQU0sVUFBVSxLQUFLLDhCQUE4QixhQUFhO0FBRWhFLFVBQUk7QUFDRixjQUFNLEtBQUssSUFBSSxNQUFNLE9BQU8sVUFBVSxPQUFPO0FBQzdDLGdCQUFRLElBQUksNEJBQTRCLFVBQVU7QUFBQSxNQUNwRCxTQUFTLE9BQVA7QUFDQSxnQkFBUSxNQUFNLG1DQUFtQyxPQUFPO0FBQ3hELGNBQU07QUFBQSxNQUNSO0FBQUEsSUFDRjtBQUFBO0FBQUEsRUFFYyx3QkFBd0IsWUFBbUM7QUFBQTtBQUN2RSxZQUFNLGtCQUFrQixHQUFHO0FBRTNCLFVBQUk7QUFDRixjQUFNLEtBQUssSUFBSSxNQUFNLGFBQWEsZUFBZTtBQUNqRCxnQkFBUSxJQUFJLCtCQUErQixpQkFBaUI7QUFBQSxNQUM5RCxTQUFTLE9BQVA7QUFFQSxnQkFBUSxJQUFJLHNDQUFzQyxpQkFBaUI7QUFBQSxNQUNyRTtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRVEsOEJBQThCLGVBSzNCO0FBRVQsVUFBTSxrQkFBa0IsSUFBSSxnQkFBZ0IsS0FBSyxLQUFLLEtBQUssUUFBUTtBQUNuRSxVQUFNLGtCQUFrQixnQkFBZ0IsK0JBQStCO0FBR3ZFLFdBQU8sZ0JBQ0osUUFBUSxxQkFBcUIsY0FBYyxVQUFVLEVBQ3JELFFBQVEsdUJBQXVCLGNBQWMsWUFBWSxFQUN6RCxRQUFRLHFCQUFxQixjQUFjLFVBQVUsRUFDckQsUUFBUSxtQkFBbUIsY0FBYyxRQUFRLEVBQ2pELFFBQVEsc0RBQXNELElBQUksS0FBSyxFQUFFLFlBQVksQ0FBQyxFQUN0RixRQUFRLHlEQUF5RCxJQUFJLEtBQUssRUFBRSxZQUFZLENBQUM7QUFBQSxFQUM5RjtBQUNGOzs7QUV0T0EsSUFBQUMsbUJBQTJCO0FBR3BCLElBQU0sc0JBQU4sTUFBMEI7QUFBQSxFQUcvQixZQUFZLEtBQVU7QUFDcEIsU0FBSyxNQUFNO0FBQUEsRUFDYjtBQUFBLEVBRUEsMEJBQTBCLFNBQTJCO0FBRW5ELFVBQU0sYUFBYTtBQUNuQixVQUFNLGVBQWUsbUNBQVMsTUFBTTtBQUVwQyxRQUFJLGNBQWM7QUFDaEIsWUFBTSxZQUFZLGFBQWEsQ0FBQyxFQUFFLEtBQUs7QUFDdkMsWUFBTSxlQUFlLFVBQ2xCLFFBQVEsZ0JBQWdCLEVBQUUsRUFDMUIsUUFBUSxjQUFjLEVBQUUsRUFDeEIsTUFBTSxJQUFJLEVBQ1YsSUFBSSxDQUFDLFNBQVMsS0FBSyxLQUFLLENBQUMsRUFDekIsT0FBTyxDQUFDLFNBQVMsS0FBSyxTQUFTLENBQUM7QUFFbkMsYUFBTztBQUFBLElBQ1Q7QUFFQSxXQUFPLENBQUM7QUFBQSxFQUNWO0FBQUEsRUFFTSw0QkFDSixVQUNtQztBQUFBO0FBQ25DLGNBQVEsSUFBSSxxQ0FBcUMsVUFBVTtBQUUzRCxVQUFJO0FBRUYsY0FBTSxjQUFjLE1BQU0sS0FBSyxnQkFBZ0IsUUFBUTtBQUV2RCxZQUFJLFlBQVksV0FBVyxHQUFHO0FBQzVCLGtCQUFRLElBQUksOEJBQThCLFVBQVU7QUFDcEQsaUJBQU8sQ0FBQztBQUFBLFFBQ1Y7QUFHQSxjQUFNLGlCQUEyQyxDQUFDO0FBRWxELG1CQUFXLFFBQVEsYUFBYTtBQUM5QixjQUFJO0FBQ0Ysa0JBQU0sVUFBVSxNQUFNLEtBQUssSUFBSSxNQUFNLEtBQUssSUFBSTtBQUM5QyxrQkFBTSxhQUFhLEtBQUssMEJBQTBCLE9BQU87QUFFekQsZ0JBQUksV0FBVyxTQUFTLEdBQUc7QUFDekIsNkJBQWUsS0FBSyxRQUFRLElBQUk7QUFBQSxZQUNsQztBQUFBLFVBQ0YsU0FBUyxPQUFQO0FBQ0Esb0JBQVEsTUFBTSxzQkFBc0IsS0FBSyxTQUFTLEtBQUs7QUFBQSxVQUN6RDtBQUFBLFFBQ0Y7QUFFQSxnQkFBUTtBQUFBLFVBQ04sNkJBQ0UsT0FBTyxLQUFLLGNBQWMsRUFBRSw0QkFDUjtBQUFBLFFBQ3hCO0FBQ0EsZUFBTztBQUFBLE1BQ1QsU0FBUyxPQUFQO0FBQ0EsZ0JBQVE7QUFBQSxVQUNOLDBDQUEwQztBQUFBLFVBQzFDO0FBQUEsUUFDRjtBQUNBLGVBQU8sQ0FBQztBQUFBLE1BQ1Y7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVNLGdCQUFnQixVQUFvQztBQUFBO0FBQ3hELFlBQU0sUUFBaUIsQ0FBQztBQUd4QixZQUFNLFFBQVEsS0FBSyxJQUFJLE1BQU0saUJBQWlCO0FBRTlDLGlCQUFXLFFBQVEsT0FBTztBQUV4QixZQUNFLEtBQUssS0FBSyxTQUFTLFFBQVEsTUFDMUIsTUFBTSxLQUFLLG9CQUFvQixNQUFNLFFBQVEsSUFDOUM7QUFDQSxnQkFBTSxLQUFLLElBQUk7QUFBQSxRQUNqQjtBQUFBLE1BQ0Y7QUFFQSxhQUFPO0FBQUEsSUFDVDtBQUFBO0FBQUEsRUFFYyxvQkFDWixNQUNBLFVBQ2tCO0FBQUE7QUFDbEIsVUFBSTtBQUNGLGNBQU0sVUFBVSxNQUFNLEtBQUssSUFBSSxNQUFNLEtBQUssSUFBSTtBQUM5QyxjQUFNLG1CQUFtQixRQUFRLE1BQU0sdUJBQXVCO0FBRTlELFlBQUksa0JBQWtCO0FBQ3BCLGdCQUFNLGNBQWMsaUJBQWlCLENBQUM7QUFFdEMsaUJBQ0UsWUFBWSxTQUFTLGNBQWMsVUFBVSxLQUM3QyxZQUFZLFNBQVMsYUFBYSxVQUFVO0FBQUEsUUFFaEQ7QUFFQSxlQUFPO0FBQUEsTUFDVCxTQUFTLE9BQVA7QUFDQSxnQkFBUTtBQUFBLFVBQ04sMEJBQTBCLEtBQUssMEJBQTBCO0FBQUEsVUFDekQ7QUFBQSxRQUNGO0FBQ0EsZUFBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVNLHdCQUNKLFVBQ0EsZ0JBQ2lCO0FBQUE7QUFDakIsWUFBTSxXQUFxQixDQUFDO0FBQzVCLFlBQU0sY0FBd0MsQ0FBQztBQUcvQyxpQkFBVyxDQUFDLFVBQVUsS0FBSyxLQUFLLE9BQU8sUUFBUSxjQUFjLEdBQUc7QUFDOUQsbUJBQVcsUUFBUSxPQUFPO0FBQ3hCLGNBQUksQ0FBQyxTQUFTLFNBQVMsSUFBSSxHQUFHO0FBQzVCLHFCQUFTLEtBQUssSUFBSTtBQUNsQix3QkFBWSxJQUFJLElBQUksQ0FBQztBQUFBLFVBQ3ZCO0FBQ0Esc0JBQVksSUFBSSxFQUFFLEtBQUssUUFBUTtBQUFBLFFBQ2pDO0FBQUEsTUFDRjtBQUdBLGVBQVMsS0FBSztBQUdkLFVBQUksVUFBVSx3QkFBd0I7QUFBQTtBQUFBO0FBQ3RDLGlCQUFXLHVCQUF1QixTQUFTO0FBQUE7QUFBQTtBQUUzQyxpQkFBVyxRQUFRLFVBQVU7QUFDM0IsbUJBQVcsTUFBTTtBQUFBO0FBQ2pCLG1CQUFXLGdCQUFnQixZQUFZLElBQUksRUFBRSxLQUFLLElBQUk7QUFBQTtBQUFBO0FBQ3RELG1CQUFXO0FBQUE7QUFBQTtBQUNYLG1CQUFXO0FBQUE7QUFBQTtBQUNYLG1CQUFXO0FBQUE7QUFBQTtBQUNYLG1CQUFXO0FBQUE7QUFBQTtBQUFBLE1BQ2I7QUFFQSxhQUFPO0FBQUEsSUFDVDtBQUFBO0FBQUEsRUFFTSwwQkFBMEIsVUFBaUM7QUFBQTtBQUMvRCxVQUFJO0FBQ0YsY0FBTSxpQkFBaUIsTUFBTSxLQUFLLDRCQUE0QixRQUFRO0FBRXRFLFlBQUksT0FBTyxLQUFLLGNBQWMsRUFBRSxXQUFXLEdBQUc7QUFDNUMsa0JBQVEsSUFBSSxtQ0FBbUMsVUFBVTtBQUN6RDtBQUFBLFFBQ0Y7QUFFQSxjQUFNLGVBQWUsTUFBTSxLQUFLO0FBQUEsVUFDOUI7QUFBQSxVQUNBO0FBQUEsUUFDRjtBQUdBLGNBQU0sV0FBVyxHQUFHO0FBQ3BCLGNBQU0sV0FBVyxXQUFXLFlBQVk7QUFFeEMsWUFBSTtBQUNGLGdCQUFNLEtBQUssSUFBSSxNQUFNLE9BQU8sVUFBVSxZQUFZO0FBQ2xELGtCQUFRLElBQUksa0NBQWtDLFVBQVU7QUFBQSxRQUMxRCxTQUFTLE9BQVA7QUFFQSxnQkFBTSxlQUFlLEtBQUssSUFBSSxNQUFNLHNCQUFzQixRQUFRO0FBQ2xFLGNBQUksZ0JBQWdCLHdCQUF3Qix3QkFBTztBQUNqRCxrQkFBTSxLQUFLLElBQUksTUFBTSxPQUFPLGNBQWMsWUFBWTtBQUN0RCxvQkFBUSxJQUFJLGtDQUFrQyxVQUFVO0FBQUEsVUFDMUQ7QUFBQSxRQUNGO0FBQUEsTUFDRixTQUFTLE9BQVA7QUFDQSxnQkFBUTtBQUFBLFVBQ04sOENBQThDO0FBQUEsVUFDOUM7QUFBQSxRQUNGO0FBQ0EsY0FBTTtBQUFBLE1BQ1I7QUFBQSxJQUNGO0FBQUE7QUFDRjs7O0FDck1BLElBQUFDLG1CQUEyQjtBQUdwQixJQUFNLGlCQUFOLE1BQXFCO0FBQUEsRUFHMUIsWUFBWSxLQUFVO0FBQ3BCLFNBQUssTUFBTTtBQUFBLEVBQ2I7QUFBQSxFQUVBLHNCQUNFLFNBQzZEO0FBRTdELFVBQU0sZ0JBQWdCO0FBQ3RCLFVBQU0sVUFBVSxtQ0FBUyxNQUFNO0FBRS9CLFFBQUksQ0FBQyxTQUFTO0FBQ1osYUFBTyxDQUFDO0FBQUEsSUFDVjtBQUVBLFVBQU0sa0JBQWtCLFFBQVEsQ0FBQztBQUNqQyxVQUFNLFdBQVcsQ0FBQztBQUdsQixVQUFNLGFBQWE7QUFDbkIsVUFBTSxlQUFlLGdCQUFnQixNQUFNLFVBQVU7QUFFckQsUUFBSSxjQUFjO0FBQ2hCLGlCQUFXLFNBQVMsY0FBYztBQUNoQyxjQUFNLE9BQU8sTUFDVixLQUFLLEVBQ0wsTUFBTSxJQUFJLEVBQ1YsT0FBTyxDQUFDLFFBQVEsSUFBSSxXQUFXLEdBQUcsQ0FBQztBQUN0QyxjQUFNLGFBQWEsS0FBSyxlQUFlLElBQUk7QUFDM0MsaUJBQVMsS0FBSyxHQUFHLFVBQVU7QUFBQSxNQUM3QjtBQUFBLElBQ0Y7QUFFQSxXQUFPO0FBQUEsRUFDVDtBQUFBLEVBRVEsZUFDTixNQUM2RDtBQUM3RCxRQUFJLEtBQUssU0FBUztBQUFHLGFBQU8sQ0FBQztBQUU3QixVQUFNLFdBQVcsQ0FBQztBQUVsQixhQUFTLElBQUksR0FBRyxJQUFJLEtBQUssUUFBUSxLQUFLO0FBRXBDLFlBQU0sTUFBTSxLQUFLLENBQUM7QUFDbEIsWUFBTSxVQUFVLElBQ2IsTUFBTSxHQUFHLEVBQ1QsSUFBSSxDQUFDLFFBQVEsSUFBSSxLQUFLLENBQUMsRUFDdkIsT0FBTyxDQUFDLFFBQVEsR0FBRztBQUV0QixVQUFJLFFBQVEsVUFBVSxHQUFHO0FBQ3ZCLGNBQU0sQ0FBQyxNQUFNLFlBQVksU0FBUyxTQUFTLElBQUk7QUFDL0MsWUFBSSxRQUFRLGNBQWMsS0FBSyxZQUFZLElBQUksR0FBRztBQUNoRCxtQkFBUyxLQUFLLEVBQUUsTUFBTSxZQUFZLE9BQU8sQ0FBQztBQUFBLFFBQzVDO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFFQSxXQUFPO0FBQUEsRUFDVDtBQUFBLEVBRVEsWUFBWSxZQUE2QjtBQUMvQyxVQUFNLFlBQVk7QUFDbEIsV0FBTyxVQUFVLEtBQUssVUFBVSxLQUFLLENBQUMsTUFBTSxLQUFLLE1BQU0sVUFBVSxDQUFDO0FBQUEsRUFDcEU7QUFBQSxFQUVNLHdCQUNKLFVBQ0EsV0FDQSxTQUdBO0FBQUE7QUFDQSxjQUFRLElBQUksaUNBQWlDLFVBQVU7QUFFdkQsVUFBSTtBQUVGLGNBQU0sY0FBYyxNQUFNLEtBQUssZ0JBQWdCLFFBQVE7QUFFdkQsWUFBSSxZQUFZLFdBQVcsR0FBRztBQUM1QixrQkFBUSxJQUFJLDhCQUE4QixVQUFVO0FBQ3BELGlCQUFPLENBQUM7QUFBQSxRQUNWO0FBR0EsY0FBTSxjQUtELENBQUM7QUFFTixtQkFBVyxRQUFRLGFBQWE7QUFDOUIsY0FBSTtBQUNGLGtCQUFNLFVBQVUsTUFBTSxLQUFLLElBQUksTUFBTSxLQUFLLElBQUk7QUFDOUMsa0JBQU0sV0FBVyxLQUFLLHNCQUFzQixPQUFPO0FBR25ELGtCQUFNLHFCQUFxQixTQUFTLElBQUksQ0FBQyxZQUFhLGlDQUNqRCxVQURpRDtBQUFBLGNBRXBELFFBQVEsS0FBSztBQUFBLFlBQ2YsRUFBRTtBQUVGLHdCQUFZLEtBQUssR0FBRyxrQkFBa0I7QUFBQSxVQUN4QyxTQUFTLE9BQVA7QUFDQSxvQkFBUSxNQUFNLHNCQUFzQixLQUFLLFNBQVMsS0FBSztBQUFBLFVBQ3pEO0FBQUEsUUFDRjtBQUdBLFlBQUksbUJBQW1CO0FBQ3ZCLFlBQUksYUFBYSxTQUFTO0FBQ3hCLDZCQUFtQixLQUFLO0FBQUEsWUFDdEI7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBR0EseUJBQWlCO0FBQUEsVUFDZixDQUFDLEdBQUcsTUFBTSxJQUFJLEtBQUssRUFBRSxJQUFJLEVBQUUsUUFBUSxJQUFJLElBQUksS0FBSyxFQUFFLElBQUksRUFBRSxRQUFRO0FBQUEsUUFDbEU7QUFFQSxnQkFBUTtBQUFBLFVBQ04sU0FBUyxpQkFBaUIsZ0NBQWdDO0FBQUEsUUFDNUQ7QUFDQSxlQUFPO0FBQUEsTUFDVCxTQUFTLE9BQVA7QUFDQSxnQkFBUSxNQUFNLHNDQUFzQyxhQUFhLEtBQUs7QUFDdEUsZUFBTyxDQUFDO0FBQUEsTUFDVjtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRWMsZ0JBQWdCLFVBQW9DO0FBQUE7QUFDaEUsWUFBTSxRQUFpQixDQUFDO0FBR3hCLFlBQU0sUUFBUSxLQUFLLElBQUksTUFBTSxpQkFBaUI7QUFFOUMsaUJBQVcsUUFBUSxPQUFPO0FBRXhCLFlBQ0UsS0FBSyxLQUFLLFNBQVMsUUFBUSxNQUMxQixNQUFNLEtBQUssb0JBQW9CLE1BQU0sUUFBUSxJQUM5QztBQUNBLGdCQUFNLEtBQUssSUFBSTtBQUFBLFFBQ2pCO0FBQUEsTUFDRjtBQUVBLGFBQU87QUFBQSxJQUNUO0FBQUE7QUFBQSxFQUVjLG9CQUNaLE1BQ0EsVUFDa0I7QUFBQTtBQUNsQixVQUFJO0FBQ0YsY0FBTSxVQUFVLE1BQU0sS0FBSyxJQUFJLE1BQU0sS0FBSyxJQUFJO0FBQzlDLGNBQU0sbUJBQW1CLFFBQVEsTUFBTSx1QkFBdUI7QUFFOUQsWUFBSSxrQkFBa0I7QUFDcEIsZ0JBQU0sY0FBYyxpQkFBaUIsQ0FBQztBQUV0QyxpQkFDRSxZQUFZLFNBQVMsY0FBYyxVQUFVLEtBQzdDLFlBQVksU0FBUyxhQUFhLFVBQVU7QUFBQSxRQUVoRDtBQUVBLGVBQU87QUFBQSxNQUNULFNBQVMsT0FBUDtBQUNBLGdCQUFRO0FBQUEsVUFDTiwwQkFBMEIsS0FBSywwQkFBMEI7QUFBQSxVQUN6RDtBQUFBLFFBQ0Y7QUFDQSxlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRVEsa0JBQ04sVUFNQSxXQUNBLFNBTUM7QUFDRCxXQUFPLFNBQVMsT0FBTyxDQUFDLFlBQVk7QUFDbEMsWUFBTSxjQUFjLElBQUksS0FBSyxRQUFRLElBQUksRUFBRSxRQUFRO0FBRW5ELFVBQUksYUFBYSxjQUFjLElBQUksS0FBSyxTQUFTLEVBQUUsUUFBUSxHQUFHO0FBQzVELGVBQU87QUFBQSxNQUNUO0FBRUEsVUFBSSxXQUFXLGNBQWMsSUFBSSxLQUFLLE9BQU8sRUFBRSxRQUFRLEdBQUc7QUFDeEQsZUFBTztBQUFBLE1BQ1Q7QUFFQSxhQUFPO0FBQUEsSUFDVCxDQUFDO0FBQUEsRUFDSDtBQUFBLEVBRU0sd0JBQ0osVUFDQSxVQU1pQjtBQUFBO0FBQ2pCLFVBQUksU0FBUyxXQUFXLEdBQUc7QUFDekIsZUFBTyx5QkFBeUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUNsQztBQUdBLFlBQU0sV0FBVyxTQUFTLE9BQU8sQ0FBQyxLQUFLLFlBQVk7QUFDakQsWUFBSSxDQUFDLElBQUksUUFBUSxNQUFNLEdBQUc7QUFDeEIsY0FBSSxRQUFRLE1BQU0sSUFBSSxDQUFDO0FBQUEsUUFDekI7QUFDQSxZQUFJLFFBQVEsTUFBTSxFQUFFLEtBQUssT0FBTztBQUNoQyxlQUFPO0FBQUEsTUFDVCxHQUFHLENBQUMsQ0FBb0M7QUFFeEMsVUFBSSxVQUFVLHlCQUF5QjtBQUFBO0FBQUE7QUFDdkMsaUJBQVcsc0JBQXNCLFNBQVM7QUFBQTtBQUFBO0FBRzFDLGlCQUFXLENBQUMsUUFBUSxLQUFLLEtBQUssT0FBTyxRQUFRLFFBQVEsR0FBRztBQUN0RCxtQkFBVyxNQUFNLE9BQU8sT0FBTyxDQUFDLEVBQUUsWUFBWSxJQUFJLE9BQU8sTUFBTSxDQUFDLE1BQzlELE1BQU07QUFBQTtBQUFBO0FBRVIsbUJBQVc7QUFBQTtBQUNYLG1CQUFXO0FBQUE7QUFFWCxtQkFBVyxRQUFRLE9BQU87QUFDeEIscUJBQVcsS0FBSyxLQUFLLFVBQVUsS0FBSyxnQkFBZ0IsS0FBSztBQUFBO0FBQUEsUUFDM0Q7QUFDQSxtQkFBVztBQUFBO0FBQUEsTUFDYjtBQUVBLGFBQU87QUFBQSxJQUNUO0FBQUE7QUFBQSxFQUVNLDBCQUNKLFVBQ0EsV0FDQSxTQUNlO0FBQUE7QUFDZixVQUFJO0FBQ0YsY0FBTSxXQUFXLE1BQU0sS0FBSztBQUFBLFVBQzFCO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxRQUNGO0FBRUEsY0FBTSxpQkFBaUIsTUFBTSxLQUFLO0FBQUEsVUFDaEM7QUFBQSxVQUNBO0FBQUEsUUFDRjtBQUdBLGNBQU0sV0FBVyxHQUFHO0FBQ3BCLGNBQU0sV0FBVyxXQUFXLFlBQVk7QUFFeEMsWUFBSTtBQUNGLGdCQUFNLEtBQUssSUFBSSxNQUFNLE9BQU8sVUFBVSxjQUFjO0FBQ3BELGtCQUFRLElBQUksbUNBQW1DLFVBQVU7QUFBQSxRQUMzRCxTQUFTLE9BQVA7QUFFQSxnQkFBTSxlQUFlLEtBQUssSUFBSSxNQUFNLHNCQUFzQixRQUFRO0FBQ2xFLGNBQUksZ0JBQWdCLHdCQUF3Qix3QkFBTztBQUNqRCxrQkFBTSxLQUFLLElBQUksTUFBTSxPQUFPLGNBQWMsY0FBYztBQUN4RCxvQkFBUSxJQUFJLG1DQUFtQyxVQUFVO0FBQUEsVUFDM0Q7QUFBQSxRQUNGO0FBQUEsTUFDRixTQUFTLE9BQVA7QUFDQSxnQkFBUTtBQUFBLFVBQ04sK0NBQStDO0FBQUEsVUFDL0M7QUFBQSxRQUNGO0FBQ0EsY0FBTTtBQUFBLE1BQ1I7QUFBQSxJQUNGO0FBQUE7QUFDRjs7O0FDelNBLElBQUFDLG1CQUEyQjtBQUVwQixJQUFNLHdCQUFOLE1BQTRCO0FBQUEsRUFHakMsWUFBWSxLQUFVO0FBQ3BCLFNBQUssTUFBTTtBQUFBLEVBQ2I7QUFBQSxFQUVNLHNCQUVKO0FBQUE7QUFDQSxjQUFRLElBQUkscUNBQXFDO0FBRWpELFVBQUk7QUFDRixjQUFNLFFBQVEsSUFBSSxLQUFLO0FBQ3ZCLGNBQU0sY0FBYyxNQUFNLFlBQVksRUFBRSxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBR3BELGNBQU0sUUFBUSxLQUFLLElBQUksTUFBTSxpQkFBaUI7QUFDOUMsY0FBTSxjQUF1QixDQUFDO0FBRTlCLG1CQUFXLFFBQVEsT0FBTztBQUN4QixnQkFBTSxXQUFXLEtBQUssb0JBQW9CLEtBQUssSUFBSTtBQUNuRCxjQUFJLGFBQWEsYUFBYTtBQUM1Qix3QkFBWSxLQUFLLElBQUk7QUFBQSxVQUN2QjtBQUFBLFFBQ0Y7QUFHQSxjQUFNLGFBQ0osQ0FBQztBQUVILG1CQUFXLFFBQVEsYUFBYTtBQUM5QixnQkFBTSxXQUFXLE1BQU0sS0FBSyxvQkFBb0IsSUFBSTtBQUNwRCxjQUFJLFVBQVU7QUFDWix1QkFBVyxLQUFLLFFBQVE7QUFBQSxVQUMxQjtBQUFBLFFBQ0Y7QUFFQSxnQkFBUSxJQUFJLFNBQVMsV0FBVyxzQ0FBc0M7QUFDdEUsZUFBTztBQUFBLE1BQ1QsU0FBUyxPQUFQO0FBQ0EsZ0JBQVEsTUFBTSxxQ0FBcUMsS0FBSztBQUN4RCxlQUFPLENBQUM7QUFBQSxNQUNWO0FBQUEsSUFDRjtBQUFBO0FBQUEsRUFFTSx5QkFDSixVQUNBLE1BQ2dEO0FBQUE7QUFDaEQsY0FBUSxJQUFJLCtCQUErQixvQkFBb0IsTUFBTTtBQUVyRSxVQUFJO0FBRUYsY0FBTSxjQUFjLE1BQU0sS0FBSyx1QkFBdUIsVUFBVSxJQUFJO0FBRXBFLGNBQU0sYUFBb0QsQ0FBQztBQUUzRCxtQkFBVyxRQUFRLGFBQWE7QUFDOUIsZ0JBQU0sVUFBVSxNQUFNLEtBQUssSUFBSSxNQUFNLEtBQUssSUFBSTtBQUM5QyxnQkFBTSxXQUFXLEtBQUssa0JBQWtCLE1BQU0sT0FBTztBQUVyRCxxQkFBVyxLQUFLO0FBQUEsWUFDZCxNQUFNLEtBQUs7QUFBQSxZQUNYLE1BQU07QUFBQSxVQUNSLENBQUM7QUFBQSxRQUNIO0FBRUEsZ0JBQVE7QUFBQSxVQUNOLFNBQVMsV0FBVyxnQ0FBZ0MsZUFBZTtBQUFBLFFBQ3JFO0FBQ0EsZUFBTztBQUFBLE1BQ1QsU0FBUyxPQUFQO0FBQ0EsZ0JBQVE7QUFBQSxVQUNOLHFDQUFxQyxlQUFlO0FBQUEsVUFDcEQ7QUFBQSxRQUNGO0FBQ0EsZUFBTyxDQUFDO0FBQUEsTUFDVjtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRVEsb0JBQW9CLFVBQWlDO0FBRTNELFVBQU0sWUFBWTtBQUNsQixVQUFNLFVBQVUsU0FBUyxNQUFNLFNBQVM7QUFDeEMsV0FBTyxVQUFVLFFBQVEsUUFBUSxTQUFTLENBQUMsSUFBSTtBQUFBLEVBQ2pEO0FBQUEsRUFFYyxvQkFDWixNQUNpRTtBQUFBO0FBQ2pFLFVBQUk7QUFDRixjQUFNLFVBQVUsTUFBTSxLQUFLLElBQUksTUFBTSxLQUFLLElBQUk7QUFHOUMsY0FBTSxXQUFXLEtBQUssa0JBQWtCLE1BQU0sT0FBTztBQUdyRCxjQUFNLFdBQ0osS0FBSywyQkFBMkIsT0FBTyxLQUN2QyxLQUFLLHdCQUF3QixLQUFLLElBQUk7QUFFeEMsZUFBTztBQUFBLFVBQ0wsTUFBTSxLQUFLO0FBQUEsVUFDWCxNQUFNO0FBQUEsVUFDTixRQUFRLFlBQVk7QUFBQSxRQUN0QjtBQUFBLE1BQ0YsU0FBUyxPQUFQO0FBQ0EsZ0JBQVEsTUFBTSx3QkFBd0IsS0FBSyxTQUFTLEtBQUs7QUFDekQsZUFBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVRLGtCQUFrQixNQUFhLFNBQXlCO0FBQzlELFVBQU0sT0FBTyxLQUFLLEtBQUssWUFBWTtBQUduQyxRQUNFLEtBQUssU0FBUyxPQUFPLEtBQ3JCLFFBQVEsU0FBUywwQkFBMEIsR0FDM0M7QUFDQSxhQUFPO0FBQUEsSUFDVDtBQUdBLFFBQUksS0FBSyxTQUFTLFNBQVMsS0FBSyxRQUFRLFNBQVMsWUFBWSxHQUFHO0FBQzlELFVBQUksUUFBUSxTQUFTLCtCQUErQixHQUFHO0FBQ3JELGVBQU87QUFBQSxNQUNUO0FBQ0EsVUFBSSxRQUFRLFNBQVMsc0JBQXNCLEdBQUc7QUFDNUMsZUFBTztBQUFBLE1BQ1Q7QUFDQSxVQUFJLFFBQVEsU0FBUyx1QkFBdUIsR0FBRztBQUM3QyxlQUFPO0FBQUEsTUFDVDtBQUNBLFVBQUksUUFBUSxTQUFTLDBCQUEwQixHQUFHO0FBQ2hELGVBQU87QUFBQSxNQUNUO0FBQ0EsYUFBTztBQUFBLElBQ1Q7QUFHQSxRQUFJLFFBQVEsU0FBUyxLQUFLLEtBQUssUUFBUSxNQUFNLGlCQUFpQixHQUFHO0FBQy9ELGFBQU87QUFBQSxJQUNUO0FBRUEsV0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUVRLDJCQUEyQixTQUFnQztBQUNqRSxVQUFNLGdCQUFnQjtBQUN0QixVQUFNLFFBQVEsUUFBUSxNQUFNLGFBQWE7QUFDekMsV0FBTyxRQUFRLE1BQU0sQ0FBQyxJQUFJO0FBQUEsRUFDNUI7QUFBQSxFQUVRLHdCQUF3QixVQUFpQztBQUMvRCxVQUFNLGdCQUFnQjtBQUN0QixVQUFNLFVBQVUsU0FBUyxNQUFNLGFBQWE7QUFDNUMsV0FBTyxVQUFVLFFBQVEsUUFBUSxTQUFTLENBQUMsSUFBSTtBQUFBLEVBQ2pEO0FBQUEsRUFFYyx1QkFDWixVQUNBLE1BQ2tCO0FBQUE7QUFDbEIsWUFBTSxRQUFpQixDQUFDO0FBR3hCLFlBQU0sV0FBVyxLQUFLLElBQUksTUFBTSxpQkFBaUI7QUFFakQsaUJBQVcsUUFBUSxVQUFVO0FBRTNCLFlBQ0UsS0FBSyxLQUFLLFNBQVMsUUFBUSxNQUMxQixNQUFNLEtBQUssb0JBQW9CLE1BQU0sUUFBUSxJQUM5QztBQUVBLGdCQUFNLFdBQVcsS0FBSyxvQkFBb0IsS0FBSyxJQUFJO0FBQ25ELGNBQUksYUFBYSxNQUFNO0FBQ3JCLGtCQUFNLEtBQUssSUFBSTtBQUFBLFVBQ2pCO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFFQSxhQUFPO0FBQUEsSUFDVDtBQUFBO0FBQUEsRUFFYyxvQkFDWixNQUNBLFVBQ2tCO0FBQUE7QUFDbEIsVUFBSTtBQUNGLGNBQU0sVUFBVSxNQUFNLEtBQUssSUFBSSxNQUFNLEtBQUssSUFBSTtBQUM5QyxlQUFPLEtBQUssMkJBQTJCLE9BQU8sTUFBTTtBQUFBLE1BQ3RELFNBQVMsT0FBUDtBQUNBLGdCQUFRO0FBQUEsVUFDTiwwQkFBMEIsS0FBSywwQkFBMEI7QUFBQSxVQUN6RDtBQUFBLFFBQ0Y7QUFDQSxlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRU0scUJBQXFCLE1BQWdDO0FBQUE7QUFDekQsWUFBTSxhQUFhLFFBQVEsSUFBSSxLQUFLLEVBQUUsWUFBWSxFQUFFLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFDaEUsWUFBTSxhQUFhLE1BQU0sS0FBSyx5QkFBeUIsSUFBSSxVQUFVO0FBRXJFLFVBQUksV0FBVyxXQUFXLEdBQUc7QUFDM0IsZUFBTywyQkFBMkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUNwQztBQUdBLFlBQU0sV0FBOEMsQ0FBQztBQUNyRCxZQUFNLFdBQThCLENBQUM7QUFFckMsaUJBQVcsWUFBWSxZQUFZO0FBQ2pDLFlBQUksU0FBUyxLQUFLLFNBQVMsVUFBVSxHQUFHO0FBRXRDLGdCQUFNLFlBQVksU0FBUyxLQUFLLE1BQU0sR0FBRztBQUN6QyxnQkFBTSxjQUFjLFVBQVUsVUFBVSxDQUFDLFNBQVMsS0FBSyxTQUFTLEdBQUcsQ0FBQztBQUNwRSxjQUFJLGVBQWUsR0FBRztBQUNwQixrQkFBTSxXQUFXLFVBQVUsV0FBVztBQUN0QyxnQkFBSSxDQUFDLFNBQVMsUUFBUSxHQUFHO0FBQ3ZCLHVCQUFTLFFBQVEsSUFBSSxDQUFDO0FBQUEsWUFDeEI7QUFDQSxxQkFBUyxRQUFRLEVBQUUsS0FBSyxRQUFRO0FBQUEsVUFDbEMsT0FBTztBQUNMLHFCQUFTLEtBQUssUUFBUTtBQUFBLFVBQ3hCO0FBQUEsUUFDRixPQUFPO0FBQ0wsbUJBQVMsS0FBSyxRQUFRO0FBQUEsUUFDeEI7QUFBQSxNQUNGO0FBRUEsVUFBSSxVQUFVLDJCQUEyQjtBQUFBO0FBQUE7QUFDekMsaUJBQVcscUJBQXFCLFdBQVc7QUFBQTtBQUFBO0FBRzNDLGlCQUFXLENBQUMsVUFBVSxnQkFBZ0IsS0FBSyxPQUFPLFFBQVEsUUFBUSxHQUFHO0FBQ25FLG1CQUFXLE1BQU07QUFBQTtBQUFBO0FBQ2pCLG1CQUFXO0FBQUE7QUFDWCxtQkFBVztBQUFBO0FBRVgsbUJBQVcsWUFBWSxrQkFBa0I7QUFDdkMscUJBQVcsS0FBSyxTQUFTLFVBQVUsU0FBUztBQUFBO0FBQUEsUUFDOUM7QUFDQSxtQkFBVztBQUFBO0FBQUEsTUFDYjtBQUdBLFVBQUksU0FBUyxTQUFTLEdBQUc7QUFDdkIsbUJBQVc7QUFBQTtBQUFBO0FBQ1gsbUJBQVc7QUFBQTtBQUNYLG1CQUFXO0FBQUE7QUFFWCxtQkFBVyxZQUFZLFVBQVU7QUFDL0IscUJBQVcsS0FBSyxTQUFTLFVBQVUsU0FBUztBQUFBO0FBQUEsUUFDOUM7QUFDQSxtQkFBVztBQUFBO0FBQUEsTUFDYjtBQUVBLGFBQU87QUFBQSxJQUNUO0FBQUE7QUFBQSxFQUVNLHVCQUF1QixNQUE4QjtBQUFBO0FBQ3pELFVBQUk7QUFDRixjQUFNLGFBQWEsUUFBUSxJQUFJLEtBQUssRUFBRSxZQUFZLEVBQUUsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUNoRSxjQUFNLGlCQUFpQixNQUFNLEtBQUsscUJBQXFCLFVBQVU7QUFHakUsY0FBTSxXQUFXLEdBQUc7QUFDcEIsY0FBTSxXQUFXLFNBQVM7QUFFMUIsWUFBSTtBQUNGLGdCQUFNLEtBQUssSUFBSSxNQUFNLE9BQU8sVUFBVSxjQUFjO0FBQ3BELGtCQUFRLElBQUksK0JBQStCLFVBQVU7QUFBQSxRQUN2RCxTQUFTLE9BQVA7QUFFQSxnQkFBTSxlQUFlLEtBQUssSUFBSSxNQUFNLHNCQUFzQixRQUFRO0FBQ2xFLGNBQUksZ0JBQWdCLHdCQUF3Qix3QkFBTztBQUNqRCxrQkFBTSxLQUFLLElBQUksTUFBTSxPQUFPLGNBQWMsY0FBYztBQUN4RCxvQkFBUSxJQUFJLCtCQUErQixVQUFVO0FBQUEsVUFDdkQ7QUFBQSxRQUNGO0FBQUEsTUFDRixTQUFTLE9BQVA7QUFDQSxnQkFBUSxNQUFNLG9DQUFvQyxTQUFTLEtBQUs7QUFDaEUsY0FBTTtBQUFBLE1BQ1I7QUFBQSxJQUNGO0FBQUE7QUFDRjs7O0FDclNBLElBQUFDLG1CQUF1RDtBQVVoRCxJQUFNLG1CQUFOLGNBQStCLHVCQUFNO0FBQUEsRUFNMUMsWUFDRSxLQUNBLFlBQ0EsVUFDQSxVQUNBO0FBQ0EsVUFBTSxHQUFHO0FBQ1QsU0FBSyxjQUFjLENBQUMsRUFBRSxNQUFNLElBQUksU0FBUyxJQUFJLE1BQU0sSUFBSSxRQUFRLElBQUksYUFBYSxHQUFHLENBQUM7QUFDcEYsU0FBSyxhQUFhO0FBQ2xCLFNBQUssV0FBVztBQUNoQixTQUFLLFdBQVc7QUFBQSxFQUNsQjtBQUFBLEVBRUEsU0FBUztBQUNQLFVBQU0sRUFBRSxVQUFVLElBQUk7QUFDdEIsY0FBVSxNQUFNO0FBQ2hCLGNBQVUsU0FBUyxpQ0FBaUM7QUFFcEQsY0FBVSxTQUFTLE1BQU0sRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBR2hFLFFBQUkseUJBQVEsU0FBUyxFQUNsQixRQUFRLFFBQVEsRUFDaEIsUUFBUSxHQUFHLEtBQUssZUFBZSxLQUFLLFdBQVcsRUFDL0MsWUFBWSxJQUFJO0FBR25CLFVBQU0sdUJBQXVCLFVBQVUsVUFBVSxFQUFFLEtBQUssd0JBQXdCLENBQUM7QUFHakYsU0FBSyxxQkFBcUIsc0JBQXNCLENBQUM7QUFHakQsUUFBSSx5QkFBUSxTQUFTLEVBQ2xCO0FBQUEsTUFBVSxDQUFDLFFBQ1YsSUFDRyxjQUFjLGdCQUFnQixFQUM5QixPQUFPLEVBQ1AsUUFBUSxNQUFNO0FBQ2IsY0FBTSxXQUFXLEtBQUssWUFBWTtBQUNsQyxhQUFLLFlBQVksS0FBSyxFQUFFLE1BQU0sSUFBSSxTQUFTLElBQUksTUFBTSxJQUFJLFFBQVEsSUFBSSxhQUFhLEdBQUcsQ0FBQztBQUN0RixhQUFLLHFCQUFxQixzQkFBc0IsUUFBUTtBQUFBLE1BQzFELENBQUM7QUFBQSxJQUNMO0FBR0YsUUFBSSx5QkFBUSxTQUFTLEVBQ2xCO0FBQUEsTUFBVSxDQUFDLFFBQ1YsSUFDRyxjQUFjLG9CQUFvQixFQUNsQyxPQUFPLEVBQ1AsUUFBUSxNQUFNO0FBRWIsY0FBTSxtQkFBbUIsS0FBSyxZQUFZO0FBQUEsVUFDeEMsQ0FBQyxNQUFNLEVBQUUsS0FBSyxLQUFLLE1BQU0sTUFBTSxFQUFFLFFBQVEsS0FBSyxNQUFNO0FBQUEsUUFDdEQ7QUFDQSxhQUFLLFNBQVMsa0JBQWtCLEtBQUssWUFBWSxLQUFLLFFBQVE7QUFDOUQsYUFBSyxNQUFNO0FBQUEsTUFDYixDQUFDO0FBQUEsSUFDTDtBQUFBLEVBQ0o7QUFBQSxFQUVBLHFCQUFxQixXQUF3QixPQUFlO0FBQzFELFVBQU0sVUFBVSxVQUFVLFVBQVUsRUFBRSxLQUFLLHFCQUFxQixDQUFDO0FBQ2pFLFlBQVEsU0FBUyxNQUFNLEVBQUUsTUFBTSxlQUFlLFFBQVEsSUFBSSxDQUFDO0FBRTNELFFBQUkseUJBQVEsT0FBTyxFQUNoQixRQUFRLGlCQUFpQixFQUN6QjtBQUFBLE1BQVEsQ0FBQyxTQUNSLEtBQ0csZUFBZSx1QkFBdUIsRUFDdEMsU0FBUyxLQUFLLFlBQVksS0FBSyxFQUFFLElBQUksRUFDckMsU0FBUyxDQUFDLFVBQVU7QUFDbkIsYUFBSyxZQUFZLEtBQUssRUFBRSxPQUFPO0FBQUEsTUFDakMsQ0FBQztBQUFBLElBQ0w7QUFFRixRQUFJLHlCQUFRLE9BQU8sRUFDaEIsUUFBUSxVQUFVLEVBQ2xCLFFBQVEsb0JBQW9CLEVBQzVCO0FBQUEsTUFBUSxDQUFDLFNBQ1IsS0FDRyxlQUFlLFlBQVksRUFDM0IsU0FBUyxLQUFLLFlBQVksS0FBSyxFQUFFLE9BQU8sRUFDeEMsU0FBUyxDQUFDLFVBQVU7QUFDbkIsYUFBSyxZQUFZLEtBQUssRUFBRSxVQUFVO0FBQUEsTUFDcEMsQ0FBQztBQUFBLElBQ0w7QUFFRixRQUFJLHlCQUFRLE9BQU8sRUFDaEIsUUFBUSxpQkFBaUIsRUFDekI7QUFBQSxNQUFRLENBQUMsU0FDUixLQUNHLGVBQWUsNEJBQTRCLEVBQzNDLFNBQVMsS0FBSyxZQUFZLEtBQUssRUFBRSxJQUFJLEVBQ3JDLFNBQVMsQ0FBQyxVQUFVO0FBQ25CLGFBQUssWUFBWSxLQUFLLEVBQUUsT0FBTztBQUFBLE1BQ2pDLENBQUM7QUFBQSxJQUNMO0FBRUYsUUFBSSx5QkFBUSxPQUFPLEVBQ2hCLFFBQVEsUUFBUSxFQUNoQjtBQUFBLE1BQVEsQ0FBQyxTQUNSLEtBQ0csZUFBZSxXQUFXLEVBQzFCLFNBQVMsS0FBSyxZQUFZLEtBQUssRUFBRSxNQUFNLEVBQ3ZDLFNBQVMsQ0FBQyxVQUFVO0FBQ25CLGFBQUssWUFBWSxLQUFLLEVBQUUsU0FBUztBQUFBLE1BQ25DLENBQUM7QUFBQSxJQUNMO0FBRUYsUUFBSSx5QkFBUSxPQUFPLEVBQ2hCLFFBQVEsYUFBYSxFQUNyQjtBQUFBLE1BQVksQ0FBQyxTQUNaLEtBQ0csZUFBZSw4QkFBOEIsRUFDN0MsU0FBUyxLQUFLLFlBQVksS0FBSyxFQUFFLFdBQVcsRUFDNUMsU0FBUyxDQUFDLFVBQVU7QUFDbkIsYUFBSyxZQUFZLEtBQUssRUFBRSxjQUFjO0FBQUEsTUFDeEMsQ0FBQztBQUFBLElBQ0w7QUFHRixRQUFJLEtBQUssWUFBWSxTQUFTLEdBQUc7QUFDL0IsVUFBSSx5QkFBUSxPQUFPLEVBQ2hCO0FBQUEsUUFBVSxDQUFDLFFBQ1YsSUFDRyxjQUFjLFFBQVEsRUFDdEIsUUFBUSxNQUFNO0FBQ2IsZUFBSyxZQUFZLE9BQU8sT0FBTyxDQUFDO0FBQ2hDLGtCQUFRLE9BQU87QUFDZixlQUFLLG9CQUFvQjtBQUFBLFFBQzNCLENBQUM7QUFBQSxNQUNMO0FBQUEsSUFDSjtBQUFBLEVBQ0Y7QUFBQSxFQUVBLHNCQUFzQjtBQUNwQixVQUFNLFdBQVcsS0FBSyxVQUFVLGlCQUFpQixxQkFBcUI7QUFDdEUsYUFBUyxRQUFRLENBQUMsU0FBUyxVQUFVO0FBQ25DLFlBQU0sU0FBUyxRQUFRLGNBQWMsSUFBSTtBQUN6QyxVQUFJLFFBQVE7QUFDVixlQUFPLGNBQWMsZUFBZSxRQUFRO0FBQUEsTUFDOUM7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNIO0FBQUEsRUFFQSxVQUFVO0FBQ1IsVUFBTSxFQUFFLFVBQVUsSUFBSTtBQUN0QixjQUFVLE1BQU07QUFBQSxFQUNsQjtBQUNGOzs7QUM3SkEsU0FBc0Isd0JBQXdCLElBQVMsVUFBa0I7QUFBQTtBQUNyRSxRQUFJO0FBRUEsWUFBTSxRQUFRLEdBQUcsTUFBTSxRQUFRLEVBQzFCLE9BQU8sQ0FBQyxNQUFXLEVBQUUsS0FBSyxRQUFRLFFBQVEsRUFBRSxLQUFLLFNBQVMsUUFBUSxFQUNsRSxJQUFJLENBQUMsT0FBWTtBQUFBLFFBQ2QsTUFBTSxFQUFFLEtBQUs7QUFBQSxRQUNiLE1BQU0sRUFBRSxLQUFLO0FBQUEsTUFDakIsRUFBRTtBQUdOLFNBQUcsT0FBTyxHQUFHLHVCQUF1QjtBQUVwQyxpQkFBVyxRQUFRLE9BQU87QUFDdEIsWUFBSSxDQUFDLEtBQUs7QUFBTTtBQUVoQixZQUFJO0FBQ0EsZ0JBQU0sT0FBTyxNQUFNLEdBQUcsSUFBSSxNQUFNLGNBQWMsS0FBSyxJQUFJO0FBQ3ZELGdCQUFNLFVBQVUsTUFBTSxHQUFHLElBQUksTUFBTSxLQUFLLElBQUk7QUFHNUMsZ0JBQU0sYUFBYTtBQUNuQixnQkFBTSxlQUFlLG1DQUFTLE1BQU07QUFFcEMsY0FBSSxjQUFjO0FBQ2Qsa0JBQU0sWUFBWSxhQUFhLENBQUMsRUFBRSxLQUFLO0FBQ3ZDLGtCQUFNLGVBQWUsVUFDaEIsUUFBUSxnQkFBZ0IsRUFBRSxFQUMxQixLQUFLLEVBQ0wsTUFBTSxJQUFJLEVBQ1YsT0FBTyxDQUFDLFNBQWlCLEtBQUssV0FBVyxJQUFJLENBQUMsRUFDOUMsSUFBSSxDQUFDLFNBQWlCLEtBQUssVUFBVSxDQUFDLENBQUMsRUFDdkMsT0FBTyxPQUFPO0FBRW5CLGdCQUFJLGFBQWEsU0FBUyxHQUFHO0FBQ3pCLGlCQUFHLE9BQU8sR0FBRyxLQUFLLEtBQUssUUFBUTtBQUMvQixpQkFBRyxLQUFLLFlBQVk7QUFBQSxZQUN4QjtBQUFBLFVBQ0o7QUFBQSxRQUVKLFNBQVMsR0FBUDtBQUNFLGtCQUFRLElBQUksb0JBQW9CLEtBQUssU0FBUyxDQUFDO0FBQy9DO0FBQUEsUUFDSjtBQUFBLE1BQ0o7QUFBQSxJQUVKLFNBQVMsT0FBUDtBQUNFLGNBQVEsTUFBTSxtQ0FBbUMsS0FBSztBQUFBLElBQzFEO0FBQUEsRUFDSjtBQUFBO0FBU0EsU0FBc0IsZ0JBQWdCLElBQVMsUUFBZ0IsWUFBMkIsTUFBTSxVQUF5QixNQUFNO0FBQUE7QUFwRS9IO0FBcUVJLGFBQVMsMkJBQTJCLEtBQVk7QUFDNUMsWUFBTSxPQUFPLG9CQUFJLElBQUk7QUFDckIsYUFBTyxJQUFJLE9BQU8sQ0FBQyxVQUFlO0FBQzlCLGNBQU0sTUFBTSxLQUFLLFVBQVUsQ0FBQyxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQy9DLGVBQU8sQ0FBQyxLQUFLLElBQUksR0FBRyxLQUFLLEtBQUssSUFBSSxHQUFHO0FBQUEsTUFDekMsQ0FBQztBQUFBLElBQ0w7QUFHQSxVQUFNLG1CQUFvQixPQUFlLE9BQU8sRUFBRSxTQUFTLEdBQUcsS0FBSyxFQUFFLE9BQU8sWUFBWTtBQUN4RixVQUFNLFFBQVEsYUFBYTtBQUMzQixVQUFNLE1BQU0sV0FBWSxPQUFlLE9BQU8sRUFBRSxJQUFJLEdBQUcsTUFBTSxFQUFFLE9BQU8sWUFBWTtBQUVsRixVQUFNLFFBQVEsTUFBTSxHQUFHLE1BQU0sTUFBTSxFQUM5QixPQUFPLENBQUMsTUFBVyxFQUFFLEtBQUssU0FBUyxVQUFVLEVBQUUsS0FBSyxPQUFPLElBQUk7QUFFcEUsUUFBSSxhQUFvQixDQUFDO0FBRXpCLGVBQVcsUUFBUSxNQUFNLFFBQVE7QUFDN0IsVUFBSSxHQUFDLGtDQUFNLFNBQU4sbUJBQVksT0FBTTtBQUFFO0FBQUEsTUFBTztBQUNoQyxZQUFNLFVBQVUsTUFBTyxHQUFHLElBQUksTUFBYyxXQUFZLEdBQUcsSUFBSSxNQUFjLGVBQWMsVUFBSyxTQUFMLG1CQUFXLElBQUksQ0FBQztBQUMzRyxZQUFNLFFBQVE7QUFDZCxZQUFNLFVBQVUsbUNBQVMsTUFBTTtBQUMvQixVQUFJLFNBQVM7QUFDYixjQUFNLFlBQVksUUFBUSxDQUFDLEVBQUUsS0FBSztBQUNsQyxjQUFNLFFBQVEsVUFBVSxNQUFNLElBQUksRUFBRSxNQUFNLENBQUM7QUFDM0MsbUJBQVcsUUFBUSxPQUFPO0FBQ3RCLGNBQUk7QUFDSixnQkFBTSxVQUFVLEtBQ2YsTUFBTSxHQUFHLEVBQ1QsSUFBSSxDQUFDLE1BQWMsRUFBRSxLQUFLLENBQUMsRUFDM0IsT0FBTyxDQUFDLE1BQWMsQ0FBQztBQUN4QixjQUFJLENBQUMsU0FBUyxVQUFVLElBQUk7QUFDNUIsY0FBSSxDQUFDLEtBQUssTUFBTSxPQUFPLE1BQUsseUNBQVksTUFBTSxPQUFNO0FBQ3BEO0FBQUEsVUFDQTtBQUNBLHdCQUFhLHlDQUFZLE1BQU0sd0JBQzdCLGFBQ0EsSUFBSSxLQUFLLGVBQWU7QUFFMUIsY0FDQyxPQUFlLE9BQU8sT0FBTyxFQUFFLFVBQVUsT0FBTyxLQUFLLFFBQVcsSUFBSSxHQUNuRTtBQUNGLGtCQUFNLFlBQVksQ0FBQyxXQUFXO0FBQUEsY0FDMUIsQ0FBQyxNQUFRO0FBakh6QixvQkFBQUM7QUFrSGdCLHlCQUFFLENBQUMsRUFBRSxPQUFPQSxNQUFBLE9BQWUsT0FBTyxPQUFPLE1BQTdCLGdCQUFBQSxJQUFnQyxPQUFPLGFBQWEsS0FDaEUsRUFBRSxDQUFDLEtBQUs7QUFBQTtBQUFBLFlBQ1o7QUFDQSxnQkFBSSxjQUFjLFdBQVc7QUFDekIsbUJBQUssWUFBZSxPQUFPLE9BQU8sTUFBN0IsbUJBQWdDLFNBQVMsUUFBUTtBQUN0RDtBQUFBLGNBQ0EsV0FBWSxPQUFlLE9BQU8sT0FBTyxFQUFFLFFBQVMsT0FBZSxPQUFPLEVBQUUsU0FBUyxHQUFHLEdBQUcsQ0FBQyxHQUFHO0FBQy9GLG1DQUFtQiwrQkFBK0IsWUFBZTtBQUFBLGtCQUM3RDtBQUFBLGdCQUNKLE1BRmtELG1CQUUvQyxPQUFPO0FBQUEsY0FDVixXQUFZLE9BQWUsT0FBTyxPQUFPLEVBQUUsUUFBUyxPQUFlLE9BQU8sRUFBRSxTQUFTLEdBQUcsR0FBRyxDQUFDLEdBQUc7QUFDL0YsbUNBQW1CLGdDQUFnQyxZQUFlO0FBQUEsa0JBQzlEO0FBQUEsZ0JBQ0osTUFGbUQsbUJBRWhELE9BQU87QUFBQSxjQUNWLE9BQU87QUFDUCxvQ0FBb0IsWUFBZSxPQUFPLE9BQU8sTUFBN0IsbUJBQWdDLE9BQU87QUFBQSxjQUMzRDtBQUNBLHlCQUFXLEtBQUs7QUFBQSxnQkFDaEI7QUFBQSxnQkFDQTtBQUFBLGdCQUNBO0FBQUEsZ0JBQ0EsTUFBSyxrQ0FBTSxTQUFOLG1CQUFZLFNBQVEsa0NBQU0sU0FBTixtQkFBWTtBQUFBLGNBQ3JDLENBQUM7QUFBQSxZQUNMO0FBQUEsVUFDQTtBQUFBLFFBQ0o7QUFBQSxNQUNBO0FBQUEsSUFDSjtBQUVBLFVBQU0sYUFBYTtBQUFBLE1BQTJCLFdBQ3pDLEtBQUssQ0FBQyxHQUFRLE1BQVksT0FBZSxPQUFPLEVBQUUsQ0FBQyxDQUFDLEVBQUUsUUFBUSxJQUFLLE9BQWUsT0FBTyxFQUFFLENBQUMsQ0FBQyxFQUFFLFFBQVEsQ0FBRSxFQUN6RyxJQUFJLENBQUMsTUFBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFBQSxJQUN2QztBQUVBLFVBQU0sUUFBUSxHQUFHLGNBQWUsQ0FBQyxZQUFZLG9CQUFvQixNQUFNLEdBQUcsVUFBVztBQUNyRixPQUFHLEdBQUcsU0FBUyxLQUFLO0FBQUEsRUFDeEI7QUFBQTs7O0FWdklBLElBQXFCLHFCQUFyQixjQUFnRCx3QkFBTztBQUFBLEVBUy9DLFNBQVM7QUFBQTtBQUNiLGNBQVEsSUFBSSw4QkFBOEI7QUFHMUMsWUFBTSxLQUFLLGFBQWE7QUFHeEIsV0FBSyxrQkFBa0IsSUFBSSxnQkFBZ0IsS0FBSyxLQUFLLEtBQUssUUFBUTtBQUNsRSxXQUFLLGVBQWUsSUFBSSxxQkFBcUIsS0FBSyxLQUFLLEtBQUssUUFBUTtBQUNwRSxXQUFLLHNCQUFzQixJQUFJLG9CQUFvQixLQUFLLEdBQUc7QUFDM0QsV0FBSyxpQkFBaUIsSUFBSSxlQUFlLEtBQUssR0FBRztBQUNqRCxXQUFLLHdCQUF3QixJQUFJLHNCQUFzQixLQUFLLEdBQUc7QUFDL0QsV0FBSyxvQkFBb0IsRUFBRSx5QkFBeUIsZ0JBQWdCO0FBR3BFLFdBQUssY0FBYyxJQUFJLHVCQUF1QixLQUFLLEtBQUssSUFBSSxDQUFDO0FBRzdELFdBQUssNkJBQTZCO0FBR2xDLFdBQUssV0FBVztBQUFBLFFBQ2QsSUFBSTtBQUFBLFFBQ0osTUFBTTtBQUFBLFFBQ04sVUFBVSxNQUFNO0FBQ2QsZUFBSyxnQkFBZ0IsaUJBQWlCO0FBQUEsUUFDeEM7QUFBQSxNQUNGLENBQUM7QUFFRCxXQUFLLFdBQVc7QUFBQSxRQUNkLElBQUk7QUFBQSxRQUNKLE1BQU07QUFBQSxRQUNOLFVBQVUsTUFBTTtBQUNkLGVBQUssZ0JBQWdCLGdCQUFnQjtBQUFBLFFBQ3ZDO0FBQUEsTUFDRixDQUFDO0FBSUQsV0FBSyxXQUFXO0FBQUEsUUFDZCxJQUFJO0FBQUEsUUFDSixNQUFNO0FBQUEsUUFDTixVQUFVLE1BQVk7QUFFcEIsZ0JBQU0sY0FBYyxLQUFLLElBQUksVUFBVSxjQUFjO0FBQ3JELGNBQUksV0FBVztBQUNmLGNBQUksYUFBYTtBQUdqQixjQUFJLGFBQWE7QUFDZixrQkFBTSxRQUFRLEtBQUssSUFBSSxjQUFjLGFBQWEsV0FBVztBQUM3RCxnQkFBSSxTQUFTLE1BQU0sYUFBYTtBQUM5Qix5QkFBVyxNQUFNLFlBQVksYUFBYTtBQUMxQywyQkFBYSxNQUFNLFlBQVksZUFBZSxNQUFNLFlBQVksU0FBUyxZQUFZO0FBQUEsWUFDdkY7QUFBQSxVQUNGO0FBR0EsY0FBSSxDQUFDLFVBQVU7QUFDYixrQkFBTSxtQkFBbUIsTUFBTSxLQUFLLGtCQUFrQixpQ0FBaUM7QUFDdkYsZ0JBQUksQ0FBQztBQUFrQjtBQUN2Qix1QkFBVztBQUNYLHlCQUFhO0FBQUEsVUFDZjtBQUdBLGNBQUk7QUFBQSxZQUNGLEtBQUs7QUFBQSxZQUNMO0FBQUEsWUFDQTtBQUFBLFlBQ0EsQ0FBTyxhQUFhQyxhQUFZQyxjQUFhO0FBRTNDLHlCQUFXLGNBQWMsYUFBYTtBQUNwQyxvQkFBSSxXQUFXLEtBQUssS0FBSyxNQUFNO0FBQUk7QUFHbkMsc0JBQU0sb0JBQW9CLEtBQUs7QUFBQSxrQkFDN0I7QUFBQSxrQkFDQUQ7QUFBQSxrQkFDQUM7QUFBQSxnQkFDRjtBQUNBLHNCQUFNLFdBQVcsR0FBR0EsZUFBYyxXQUFXLEtBQUssUUFBUSxpQkFBaUIsR0FBRztBQUM5RSxzQkFBTSxXQUFXLEdBQUdBLGFBQVk7QUFFaEMsb0JBQUk7QUFDRix3QkFBTSxLQUFLLElBQUksTUFBTSxPQUFPLFVBQVUsaUJBQWlCO0FBQ3ZELDBCQUFRLElBQUksNEJBQTRCLFVBQVU7QUFBQSxnQkFDcEQsU0FBUyxPQUFQO0FBQ0EsMEJBQVEsTUFBTSxrQ0FBa0MsYUFBYSxLQUFLO0FBQUEsZ0JBQ3BFO0FBQUEsY0FDRjtBQUFBLFlBQ0Y7QUFBQSxVQUNGLEVBQUUsS0FBSztBQUFBLFFBQ1Q7QUFBQSxNQUNGLENBQUM7QUFFRCxXQUFLLFdBQVc7QUFBQSxRQUNkLElBQUk7QUFBQSxRQUNKLE1BQU07QUFBQSxRQUNOLFVBQVUsTUFBWTtBQUNwQixnQkFBTSxXQUFXLE1BQU0sS0FBSztBQUFBLFlBQzFCO0FBQUEsVUFDRjtBQUNBLGNBQUksVUFBVTtBQUNaLGtCQUFNLEtBQUssb0JBQW9CLDBCQUEwQixRQUFRO0FBQUEsVUFDbkU7QUFBQSxRQUNGO0FBQUEsTUFDRixDQUFDO0FBRUQsV0FBSyxXQUFXO0FBQUEsUUFDZCxJQUFJO0FBQUEsUUFDSixNQUFNO0FBQUEsUUFDTixVQUFVLE1BQVk7QUFDcEIsZ0JBQU0sV0FBVyxNQUFNLEtBQUs7QUFBQSxZQUMxQjtBQUFBLFVBQ0Y7QUFDQSxjQUFJLFVBQVU7QUFDWixrQkFBTSxLQUFLLGVBQWUsMEJBQTBCLFFBQVE7QUFBQSxVQUM5RDtBQUFBLFFBQ0Y7QUFBQSxNQUNGLENBQUM7QUFFRCxXQUFLLFdBQVc7QUFBQSxRQUNkLElBQUk7QUFBQSxRQUNKLE1BQU07QUFBQSxRQUNOLFVBQVUsTUFBWTtBQUNwQixnQkFBTSxPQUFPLE1BQU0sS0FBSztBQUFBLFlBQ3RCO0FBQUEsVUFDRjtBQUNBLGdCQUFNLEtBQUssc0JBQXNCO0FBQUEsWUFDL0IsUUFBUTtBQUFBLFVBQ1Y7QUFBQSxRQUNGO0FBQUEsTUFDRixDQUFDO0FBR0QsV0FBSyxpQkFBaUIsRUFBRSxRQUFRLGVBQWU7QUFBQSxJQUNqRDtBQUFBO0FBQUEsRUFFYyxrQkFBa0IsU0FBeUM7QUFBQTtBQUN2RSxZQUFNLFdBQVcsT0FBTyxVQUFVLHNCQUFzQjtBQUN4RCxhQUFPLFdBQVcsU0FBUyxLQUFLLElBQUk7QUFBQSxJQUN0QztBQUFBO0FBQUEsRUFFYyxjQUFjLFNBQXlDO0FBQUE7QUFDbkUsWUFBTSxPQUFPO0FBQUEsUUFDWCxVQUFVO0FBQUEsTUFDWjtBQUNBLGFBQU8sT0FBTyxLQUFLLEtBQUssSUFBSTtBQUFBLElBQzlCO0FBQUE7QUFBQSxFQUVBLDhCQUE4QixZQUFpQixZQUFvQixVQUEwQjtBQUUzRixXQUFPO0FBQUEsYUFDRTtBQUFBLG1CQUNNLFdBQVcsUUFBUTtBQUFBLFlBQzFCLFdBQVc7QUFBQSxVQUNiLFdBQVcsVUFBVTtBQUFBO0FBQUEsV0FFcEIsSUFBSSxLQUFLLEVBQUUsWUFBWTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BSTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFJRixXQUFXLFVBQVU7QUFBQTtBQUFBO0FBQUEsRUFHdkIsV0FBVztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNRyxJQUFJLEtBQUssRUFBRSxZQUFZLEVBQUUsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLFdBQzFDLFdBQVc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFZbEIsV0FBVyxhQUFhLFdBQVc7QUFBQTtBQUFBLEVBRXJDO0FBQUEsRUFFQSxXQUFXO0FBQ1QsWUFBUSxJQUFJLGdDQUFnQztBQUFBLEVBQzlDO0FBQUEsRUFFTSwrQkFBK0I7QUFBQTtBQUVuQyxZQUFNLGtCQUFtQixLQUFLLElBQVksUUFBUSxVQUFVLG9CQUFvQjtBQUNoRixVQUFJLENBQUMsaUJBQWlCO0FBQ3BCLGdCQUFRLElBQUksc0VBQXNFO0FBQ2xGO0FBQUEsTUFDRjtBQUdBLFVBQUk7QUFFRixZQUFJLG1CQUFtQixnQkFBZ0IsV0FBVztBQUVoRCxjQUFJLENBQUMsZ0JBQWdCLFVBQVUsV0FBVztBQUN4Qyw0QkFBZ0IsVUFBVSxZQUFZLENBQUM7QUFBQSxVQUN6QztBQUdBLDBCQUFnQixVQUFVLFVBQVUsWUFBWSxJQUFJLENBQU8sS0FBVSxJQUFTLFNBQWM7QUFDMUYsbUJBQU8sS0FBSyxrQkFBa0IsS0FBSyxJQUFJLElBQUk7QUFBQSxVQUM3QztBQUdBLGNBQUksQ0FBQyxnQkFBZ0IsVUFBVSxVQUFVLE1BQU07QUFDN0MsNEJBQWdCLFVBQVUsVUFBVSxPQUFPLENBQUM7QUFBQSxVQUM5QztBQUNBLDBCQUFnQixVQUFVLFVBQVUsS0FBSyxZQUFZLElBQUksQ0FBTyxLQUFVLElBQVMsU0FBYztBQUMvRixtQkFBTyxLQUFLLGtCQUFrQixLQUFLLElBQUksSUFBSTtBQUFBLFVBQzdDO0FBRUEsMEJBQWdCLFVBQVUsVUFBVSxhQUFhLElBQUksQ0FBTyxPQUFZO0FBQ3RFLG1CQUFPLEtBQUssbUJBQW1CLEVBQUU7QUFBQSxVQUNuQztBQUdBLDBCQUFnQixVQUFVLFVBQVUsS0FBSyxhQUFhLElBQUksQ0FBTyxPQUFZO0FBQzNFLG1CQUFPLEtBQUssbUJBQW1CLEVBQUU7QUFBQSxVQUNuQztBQUVBLGtCQUFRLElBQUksMkRBQTJEO0FBQUEsUUFDekUsT0FBTztBQUNMLGtCQUFRLE1BQU0scUVBQXFFO0FBQUEsUUFDckY7QUFBQSxNQUNGLFNBQVMsR0FBUDtBQUNBLGdCQUFRLE1BQU0sMENBQTBDLENBQUM7QUFBQSxNQUMzRDtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRU0sa0JBQWtCLEtBQVUsSUFBUyxNQUFjO0FBQUE7QUE3UTNEO0FBK1FJLFVBQUksZUFBOEI7QUFDbEMsVUFBSSxhQUE0QjtBQUNoQyxVQUFJLFNBQVM7QUFDYixVQUFJLFdBQVc7QUFDZixVQUFJLGFBQWE7QUFDakIsVUFBSSxZQUFZO0FBRWhCLFVBQUk7QUFFRixZQUFJLE1BQU0sR0FBRyxVQUFVLEdBQUcsT0FBTyxRQUFRO0FBQ3ZDLGdCQUFNLG1CQUFtQixNQUFNLEdBQUcsT0FBTyxPQUFPLDRCQUE0QixFQUFFO0FBQzlFLHlCQUFlLG1CQUFtQixtQkFBbUI7QUFFckQsZ0JBQU0saUJBQWlCLE1BQU0sR0FBRyxPQUFPLE9BQU8sMEJBQTBCLEVBQUU7QUFDMUUsdUJBQWEsaUJBQWlCLGlCQUFpQjtBQUcvQyxnQkFBTSxjQUFjLElBQUksTUFBTSxpQkFBaUIsRUFBRSxPQUFPLENBQUMsTUFBVztBQUNsRSxrQkFBTSxRQUFRLElBQUksY0FBYyxhQUFhLENBQUM7QUFDOUMsbUJBQU8sVUFDSixNQUFNLFFBQVEsTUFBTSxLQUFLLEtBQUssQ0FBQyxRQUFhLElBQUksUUFBUSxjQUFjLEtBQ3RFLE1BQU0sZUFBZSxNQUFNLFlBQVksZ0JBQWdCLFlBQ3ZELE1BQU0sZUFBZSxNQUFNLFlBQVksU0FDdEMsTUFBTSxRQUFRLE1BQU0sWUFBWSxJQUFJLElBQ2pDLE1BQU0sWUFBWSxLQUFLLFNBQVMsYUFBYSxJQUM3QyxNQUFNLFlBQVksU0FBUztBQUFBLFVBRXBDLENBQUM7QUFFRCxtQkFBUyxNQUFNLEdBQUcsT0FBTztBQUFBLFlBQ3ZCLE1BQU0sWUFBWSxJQUFJLENBQUMsTUFBVyxFQUFFLFFBQVE7QUFBQSxZQUM1QztBQUFBLFVBQ0Y7QUFFQSxzQkFBWSxNQUFNLEdBQUcsT0FBTztBQUFBLFlBQzFCLENBQUMsVUFBVSxXQUFXLGFBQWEsWUFBWSxVQUFVLFlBQVksUUFBUTtBQUFBLFlBQzdFLENBQUMsVUFBVSxXQUFXLGFBQWEsWUFBWSxVQUFVLFlBQVksUUFBUTtBQUFBLFlBQzdFO0FBQUEsVUFDRjtBQUFBLFFBQ0YsT0FBTztBQUVMLHlCQUFlO0FBQ2YsdUJBQWE7QUFDYixtQkFBUztBQUNULHNCQUFZO0FBQUEsUUFDZDtBQUFBLE1BQ0YsU0FBUyxHQUFQO0FBQ0EsZ0JBQVEsTUFBTSxnQ0FBZ0MsQ0FBQztBQUUvQyx1QkFBZTtBQUNmLHFCQUFhO0FBQ2IsaUJBQVM7QUFDVCxvQkFBWTtBQUFBLE1BQ2Q7QUFHQSxpQkFBVyxTQUFTLE9BQU8sTUFBTSxLQUFLLEVBQUUsQ0FBQyxLQUFLLFNBQVM7QUFDdkQsbUJBQWEsV0FBVSxZQUFPLE1BQU0sS0FBSyxFQUFFLENBQUMsTUFBckIsbUJBQXdCLFVBQVUsR0FBRyxPQUFNLFFBQVM7QUFFM0UsYUFBTztBQUFBLFFBQ0wsUUFBUTtBQUFBO0FBQUEsUUFDUjtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRU0sbUJBQW1CLElBQVM7QUFBQTtBQXJWcEM7QUFzVkksVUFBSSxnQkFBZ0I7QUFDcEIsVUFBSSxTQUFTO0FBQ2IsVUFBSSxXQUFXO0FBQ2YsVUFBSSxhQUFhO0FBQ2pCLFVBQUksT0FBTztBQUVYLFVBQUk7QUFDRixZQUFJLE1BQU0sR0FBRyxVQUFVLEdBQUcsT0FBTyxRQUFRO0FBQ3ZDLDJCQUFnQixNQUFNLEdBQUcsT0FBTyxPQUFPLGtCQUFrQixFQUFFLE1BQUs7QUFFaEUsZ0JBQU0sY0FBYyxHQUFHLElBQUksTUFBTSxpQkFBaUIsRUFBRSxPQUFPLENBQUMsTUFBVztBQUNyRSxrQkFBTSxRQUFRLEdBQUcsSUFBSSxjQUFjLGFBQWEsQ0FBQztBQUNqRCxtQkFBTyxVQUNKLE1BQU0sUUFBUSxNQUFNLEtBQUssS0FBSyxDQUFDLFFBQWEsSUFBSSxRQUFRLGNBQWMsS0FDdEUsTUFBTSxlQUFlLE1BQU0sWUFBWSxnQkFBZ0IsWUFDdkQsTUFBTSxlQUFlLE1BQU0sWUFBWSxTQUN0QyxNQUFNLFFBQVEsTUFBTSxZQUFZLElBQUksSUFDakMsTUFBTSxZQUFZLEtBQUssU0FBUyxhQUFhLElBQzdDLE1BQU0sWUFBWSxTQUFTO0FBQUEsVUFFcEMsQ0FBQztBQUVELG1CQUFTLE1BQU0sR0FBRyxPQUFPO0FBQUEsWUFDdkIsTUFBTSxZQUFZLElBQUksQ0FBQyxNQUFXLEVBQUUsUUFBUTtBQUFBLFlBQzVDO0FBQUEsVUFDRjtBQUNBLGdCQUFNLGNBQWMsR0FBRyxJQUFJLE1BQU0sU0FBUyxFQUFFLE9BQU8sQ0FBQyxNQUFXLEVBQUUsY0FBYyxLQUFLLEVBQUUsSUFBSSxDQUFDLE1BQVcsRUFBRSxRQUFRO0FBQ2hILGlCQUFPLE1BQU0sR0FBRyxPQUFPLFVBQVUsYUFBYSxhQUFhLFVBQVU7QUFBQSxRQUN2RSxPQUFPO0FBRUwsMEJBQWdCO0FBQ2hCLG1CQUFTO0FBQ1QsaUJBQU87QUFBQSxRQUNUO0FBQUEsTUFDRixTQUFTLEdBQVA7QUFDQSxnQkFBUSxNQUFNLGlDQUFpQyxDQUFDO0FBRWhELHdCQUFnQjtBQUNoQixpQkFBUztBQUNULGVBQU87QUFBQSxNQUNUO0FBR0EsaUJBQVcsU0FBUyxPQUFPLE1BQU0sS0FBSyxFQUFFLENBQUMsS0FBSyxTQUFTO0FBQ3ZELG1CQUFhLFdBQVUsWUFBTyxNQUFNLEtBQUssRUFBRSxDQUFDLE1BQXJCLG1CQUF3QixVQUFVLEdBQUcsT0FBTSxRQUFTO0FBRTNFLGFBQU87QUFBQSxRQUNMO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVNLGVBQWU7QUFBQTtBQUNuQixXQUFLLFdBQVcsT0FBTyxPQUFPLENBQUMsR0FBRyxrQkFBa0IsTUFBTSxLQUFLLFNBQVMsQ0FBQztBQUFBLElBQzNFO0FBQUE7QUFBQSxFQUVNLGVBQWU7QUFBQTtBQUNuQixZQUFNLEtBQUssU0FBUyxLQUFLLFFBQVE7QUFBQSxJQUNuQztBQUFBO0FBQ0Y7IiwKICAibmFtZXMiOiBbImltcG9ydF9vYnNpZGlhbiIsICJpbXBvcnRfb2JzaWRpYW4iLCAiaW1wb3J0X29ic2lkaWFuIiwgImltcG9ydF9vYnNpZGlhbiIsICJpbXBvcnRfb2JzaWRpYW4iLCAiaW1wb3J0X29ic2lkaWFuIiwgImltcG9ydF9vYnNpZGlhbiIsICJpbXBvcnRfb2JzaWRpYW4iLCAiX2EiLCAiY291cnNlTmFtZSIsICJjb3Vyc2VJZCJdCn0K
