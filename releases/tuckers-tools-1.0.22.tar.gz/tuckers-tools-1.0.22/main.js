var __defProp = Object.defineProperty;
var __defProps = Object.defineProperties;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getOwnPropSymbols = Object.getOwnPropertySymbols;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __propIsEnum = Object.prototype.propertyIsEnumerable;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __spreadValues = (a, b) => {
  for (var prop in b || (b = {}))
    if (__hasOwnProp.call(b, prop))
      __defNormalProp(a, prop, b[prop]);
  if (__getOwnPropSymbols)
    for (var prop of __getOwnPropSymbols(b)) {
      if (__propIsEnum.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    }
  return a;
};
var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __async = (__this, __arguments, generator) => {
  return new Promise((resolve, reject) => {
    var fulfilled = (value) => {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    };
    var rejected = (value) => {
      try {
        step(generator.throw(value));
      } catch (e) {
        reject(e);
      }
    };
    var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
    step((generator = generator.apply(__this, __arguments)).next());
  });
};

// main.ts
var main_exports = {};
__export(main_exports, {
  default: () => TuckersToolsPlugin
});
module.exports = __toCommonJS(main_exports);
var import_obsidian7 = require("obsidian");

// settings.ts
var import_obsidian = require("obsidian");

// utils.ts
function slugify(text) {
  return text.toLowerCase().trim().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9\s-]/g, "").replace(/[\s-]+/g, "-").replace(/^-+|-+$/g, "");
}
function validateDate(dateString) {
  const regex = /^\d{4}-\d{2}-\d{2}$/;
  if (!dateString.match(regex))
    return false;
  const date = new Date(dateString);
  const timestamp = date.getTime();
  if (typeof timestamp !== "number" || isNaN(timestamp))
    return false;
  return dateString === date.toISOString().split("T")[0];
}

// settings.ts
var DEFAULT_SETTINGS = {
  baseDirectory: "/",
  semesterStartDate: new Date().toISOString().split("T")[0],
  semesterEndDate: new Date(new Date().setMonth(new Date().getMonth() + 4)).toISOString().split("T")[0],
  schoolName: "University",
  schoolAbbreviation: "U",
  templateFolder: "Tuckers Tools",
  useEnhancedMetadata: false
};
var TuckersToolsSettingTab = class extends import_obsidian.PluginSettingTab {
  constructor(app, plugin) {
    super(app, plugin);
    this.plugin = plugin;
  }
  display() {
    const { containerEl } = this;
    containerEl.empty();
    containerEl.createEl("h2", { text: "Tuckers Tools Settings" });
    new import_obsidian.Setting(containerEl).setName("Base Directory").setDesc("Root directory for course content organization").addText((text) => text.setPlaceholder("/").setValue(this.plugin.settings.baseDirectory).onChange((value) => __async(this, null, function* () {
      this.plugin.settings.baseDirectory = value;
      yield this.plugin.saveSettings();
    })));
    const startDateSetting = new import_obsidian.Setting(containerEl).setName("Semester Start Date").setDesc("Start date for the current semester").addText((text) => text.setPlaceholder("YYYY-MM-DD").setValue(this.plugin.settings.semesterStartDate).onChange((value) => __async(this, null, function* () {
      if (value && !validateDate(value)) {
        startDateSetting.setDesc("Start date for the current semester (Invalid date format)");
      } else {
        startDateSetting.setDesc("Start date for the current semester");
      }
      this.plugin.settings.semesterStartDate = value;
      yield this.plugin.saveSettings();
    })));
    const endDateSetting = new import_obsidian.Setting(containerEl).setName("Semester End Date").setDesc("End date for the current semester").addText((text) => text.setPlaceholder("YYYY-MM-DD").setValue(this.plugin.settings.semesterEndDate).onChange((value) => __async(this, null, function* () {
      if (value && !validateDate(value)) {
        endDateSetting.setDesc("End date for the current semester (Invalid date format)");
      } else {
        endDateSetting.setDesc("End date for the current semester");
      }
      this.plugin.settings.semesterEndDate = value;
      yield this.plugin.saveSettings();
    })));
    new import_obsidian.Setting(containerEl).setName("School Name").setDesc("Name of your institution").addText((text) => text.setPlaceholder("University").setValue(this.plugin.settings.schoolName).onChange((value) => __async(this, null, function* () {
      this.plugin.settings.schoolName = value;
      yield this.plugin.saveSettings();
    })));
    new import_obsidian.Setting(containerEl).setName("School Abbreviation").setDesc("Abbreviation for your institution").addText((text) => text.setPlaceholder("U").setValue(this.plugin.settings.schoolAbbreviation).onChange((value) => __async(this, null, function* () {
      this.plugin.settings.schoolAbbreviation = value;
      yield this.plugin.saveSettings();
    })));
    new import_obsidian.Setting(containerEl).setName("Template Folder").setDesc("Subfolder within your Templater template folder for Tuckers Tools templates").addText((text) => text.setPlaceholder("Tuckers Tools").setValue(this.plugin.settings.templateFolder).onChange((value) => __async(this, null, function* () {
      this.plugin.settings.templateFolder = value;
      yield this.plugin.saveSettings();
    })));
    new import_obsidian.Setting(containerEl).setName("Use Enhanced Metadata").setDesc("Enable enhanced metadata fields for new notes (existing notes remain unchanged)").addToggle((toggle) => toggle.setValue(this.plugin.settings.useEnhancedMetadata).onChange((value) => __async(this, null, function* () {
      this.plugin.settings.useEnhancedMetadata = value;
      yield this.plugin.saveSettings();
    })));
  }
};

// templateManager.ts
var import_obsidian2 = require("obsidian");
var TemplateManager = class {
  constructor(app, settings) {
    this.app = app;
    this.settings = settings;
    this.manifest = {
      version: "1.0.0",
      templates: {
        "Courses/Create Course Homepage.md": "1.0.0",
        "Courses/Course Index.md": "1.0.0",
        "Modules/Create Module.md": "1.0.0",
        "Chapters/Create Chapter.md": "1.0.0",
        "Assignments/Create Assignment.md": "1.0.0",
        "Daily/Daily Note.md": "1.0.0",
        "Utilities/Vocabulary Entry.md": "1.0.0",
        "Utilities/Due Date Entry.md": "1.0.0"
      },
      plugin_version: "1.0.0",
      release_notes: "Initial release of Tuckers Tools templates"
    };
  }
  installTemplates() {
    return __async(this, null, function* () {
      try {
        const templaterPlugin = this.getTemplaterPlugin();
        if (!templaterPlugin) {
          new import_obsidian2.Notice(
            "Templater plugin not found. Please install and enable the Templater plugin first."
          );
          console.error(
            "Templater plugin not found. Please install and enable the Templater plugin first."
          );
          return;
        }
        const templateFolderPath = this.getTemplateFolderPath(templaterPlugin);
        if (!templateFolderPath) {
          new import_obsidian2.Notice(
            "Template folder not configured in Templater settings. Please configure it in Templater settings first."
          );
          console.error(
            "Template folder not configured in Templater settings. Please configure it in Templater settings first."
          );
          return;
        }
        const fullTemplatePath = `${templateFolderPath}/${this.settings.templateFolder}`;
        try {
          yield this.app.vault.createFolder(fullTemplatePath);
          console.log(`Created template folder: ${fullTemplatePath}`);
        } catch (e) {
          console.log(
            `Template folder already exists or created: ${fullTemplatePath}`
          );
        }
        const subdirs = [
          "Courses",
          "Modules",
          "Chapters",
          "Assignments",
          "Daily",
          "Utilities"
        ];
        for (const subdir of subdirs) {
          try {
            const subPath = `${fullTemplatePath}/${subdir}`;
            yield this.app.vault.createFolder(subPath);
            console.log(`Created subdirectory: ${subPath}`);
          } catch (e) {
            console.log(
              `Subdirectory already exists: ${fullTemplatePath}/${subdir}`
            );
          }
        }
        yield this.installCourseTemplates(fullTemplatePath);
        yield this.installModuleTemplates(fullTemplatePath);
        yield this.installChapterTemplates(fullTemplatePath);
        yield this.installAssignmentTemplates(fullTemplatePath);
        yield this.installDailyTemplates(fullTemplatePath);
        yield this.installUtilityTemplates(fullTemplatePath);
        yield this.createREADME(fullTemplatePath);
        yield this.createTemplateManifest(fullTemplatePath);
        new import_obsidian2.Notice("Tuckers Tools templates installed successfully!");
        console.log("Tuckers Tools templates installed successfully");
      } catch (error) {
        console.error("Error installing templates:", error);
        new import_obsidian2.Notice("Error installing templates. Check console for details.");
      }
    });
  }
  getTemplaterPlugin() {
    const possiblePaths = [
      this.app.plugins.plugins["templater-obsidian"],
      this.app.plugins.plugins["templater"],
      this.app.plugins.getPlugin("templater-obsidian"),
      this.app.plugins.getPlugin("templater")
    ];
    for (const path of possiblePaths) {
      if (path) {
        return path;
      }
    }
    return null;
  }
  getTemplateFolderPath(templaterPlugin) {
    const settings = templaterPlugin.settings;
    if (!settings) {
      console.error("Templater plugin has no settings");
      return null;
    }
    const possiblePaths = [
      settings.template_folder,
      settings.templateFolder,
      settings.templateFolderPath,
      settings.folder
    ];
    for (const path of possiblePaths) {
      if (path && typeof path === "string") {
        return path;
      }
    }
    console.error(
      "Template folder not found in Templater settings. Available settings:",
      Object.keys(settings)
    );
    return null;
  }
  createTemplateManifest(basePath) {
    return __async(this, null, function* () {
      const manifestPath = `${basePath}/template-manifest.json`;
      const manifestContent = JSON.stringify(this.manifest, null, 2);
      try {
        const existingManifest = this.app.vault.getAbstractFileByPath(manifestPath);
        if (existingManifest) {
          const file = existingManifest;
          yield this.app.vault.modify(file, manifestContent);
          console.log(`Updated template manifest: ${manifestPath}`);
          return;
        }
        yield this.app.vault.create(manifestPath, manifestContent);
        console.log(`Created template manifest: ${manifestPath}`);
      } catch (e) {
        new import_obsidian2.Notice(`Error creating template manifest ${manifestPath}`);
        console.error(`Error creating template manifest ${manifestPath}:`, e);
      }
    });
  }
  checkForTemplateUpdates() {
    return __async(this, null, function* () {
      console.log("Checking for template updates");
      return false;
    });
  }
  updateTemplates() {
    return __async(this, null, function* () {
      try {
        console.log("Updating templates");
        const templaterPlugin = this.getTemplaterPlugin();
        if (!templaterPlugin) {
          new import_obsidian2.Notice(
            "Templater plugin not found. Please install and enable the Templater plugin first."
          );
          console.error(
            "Templater plugin not found. Please install and enable the Templater plugin first."
          );
          return;
        }
        const templateFolderPath = this.getTemplateFolderPath(templaterPlugin);
        if (!templateFolderPath) {
          new import_obsidian2.Notice(
            "Template folder not configured in Templater settings. Please configure it in Templater settings first."
          );
          console.error(
            "Template folder not configured in Templater settings. Please configure it in Templater settings first."
          );
          return;
        }
        const fullTemplatePath = `${templateFolderPath}/${this.settings.templateFolder}`;
        yield this.installCourseTemplates(fullTemplatePath);
        yield this.installModuleTemplates(fullTemplatePath);
        yield this.installChapterTemplates(fullTemplatePath);
        yield this.installAssignmentTemplates(fullTemplatePath);
        yield this.installDailyTemplates(fullTemplatePath);
        yield this.installUtilityTemplates(fullTemplatePath);
        yield this.createREADME(fullTemplatePath);
        yield this.createTemplateManifest(fullTemplatePath);
        new import_obsidian2.Notice("Tuckers Tools templates updated successfully!");
        console.log("Tuckers Tools templates updated successfully");
      } catch (error) {
        console.error("Error updating templates:", error);
        new import_obsidian2.Notice("Error updating templates. Check console for details.");
      }
    });
  }
  installCourseTemplates(basePath) {
    return __async(this, null, function* () {
      const coursePath = `${basePath}/Courses`;
      const courseHomepageTemplate = this.generateCourseHomepageTemplate();
      yield this.writeTemplateFile(
        `${coursePath}/Create Course Homepage.md`,
        courseHomepageTemplate
      );
      const courseIndexTemplate = this.generateCourseIndexTemplate();
      yield this.writeTemplateFile(
        `${coursePath}/Course Index.md`,
        courseIndexTemplate
      );
    });
  }
  installModuleTemplates(basePath) {
    return __async(this, null, function* () {
      const modulePath = `${basePath}/Modules`;
      const moduleTemplate = this.generateModuleTemplate();
      yield this.writeTemplateFile(
        `${modulePath}/Create Module.md`,
        moduleTemplate
      );
    });
  }
  installChapterTemplates(basePath) {
    return __async(this, null, function* () {
      const chapterPath = `${basePath}/Chapters`;
      const chapterTemplate = this.generateChapterTemplate();
      yield this.writeTemplateFile(
        `${chapterPath}/Create Chapter.md`,
        chapterTemplate
      );
    });
  }
  installAssignmentTemplates(basePath) {
    return __async(this, null, function* () {
      const assignmentPath = `${basePath}/Assignments`;
      const assignmentTemplate = this.generateAssignmentTemplate();
      yield this.writeTemplateFile(
        `${assignmentPath}/Create Assignment.md`,
        assignmentTemplate
      );
    });
  }
  installDailyTemplates(basePath) {
    return __async(this, null, function* () {
      const dailyPath = `${basePath}/Daily`;
      const dailyNoteTemplate = this.generateDailyNoteTemplate();
      yield this.writeTemplateFile(
        `${dailyPath}/Daily Note.md`,
        dailyNoteTemplate
      );
    });
  }
  installUtilityTemplates(basePath) {
    return __async(this, null, function* () {
      const utilityPath = `${basePath}/Utilities`;
      const vocabTemplate = this.generateVocabularyTemplate();
      yield this.writeTemplateFile(
        `${utilityPath}/Vocabulary Entry.md`,
        vocabTemplate
      );
      const dueDateTemplate = this.generateDueDateTemplate();
      yield this.writeTemplateFile(
        `${utilityPath}/Due Date Entry.md`,
        dueDateTemplate
      );
    });
  }
  writeTemplateFile(path, content) {
    return __async(this, null, function* () {
      try {
        const existingFile = this.app.vault.getAbstractFileByPath(path);
        if (existingFile) {
          console.log(`Updating existing template file: ${path}`);
          const file = existingFile;
          yield this.app.vault.modify(file, content);
          return;
        }
        yield this.app.vault.create(path, content);
        console.log(`Created template file: ${path}`);
      } catch (e) {
        new import_obsidian2.Notice(`Error creating template file ${path}`);
        console.error(`Error creating template file ${path}:`, e);
      }
    });
  }
  generateCourseHomepageTemplate() {
    return `---
${this.settings.useEnhancedMetadata ? `course_id: <% courseId %>
course_name: <% courseName %>
course_term: <% courseSeason %> <% courseYear %>
course_year: <% courseYear %>
course_semester: <% courseSeason %>
content_type: course_homepage
school: ${this.settings.schoolName}
school_abbreviation: ${this.settings.schoolAbbreviation}` : `course_id: <% courseId %>
title: <% courseName %>`}
created: <% tp.date.now("YYYY-MM-DD[T]HH:mm:ssZ") %>
tags: 
  - course_home
  - education
  - <% courseId %>
  - ${this.settings.schoolAbbreviation}/<% courseYear %>/<% courseSeason %>/<% courseId %>
---

<%*
const { exec } = require("child_process");
let courseName = await tp.system.prompt("Course Name (e.g. PSI-101 - Intro to Psych)")
let courseSeason = await tp.system.suggester(["Fall","Winter","Spring","Summer"],["Fall","Winter","Spring","Summer"], "Season")
let courseYear = await tp.system.prompt("Year")
let courseId = courseName.split(' - ')[0]
await tp.file.move(\`/\${courseYear}/\${courseSeason}/\${courseName}/\${courseName}\`)
try {await app.vault.createFolder(\`\${courseYear}/\${courseSeason}/\${courseName}/Attachments\`)} catch (e) {}
%>

# <% courseName %>

## Course Information
**Course ID**: <% courseId %>
**Term**: <% courseSeason %> <% courseYear %>
**School**: ${this.settings.schoolName}

## Instructor
**Name**: 
**Email**: 
**Office Hours**: 

## Course Description

## Learning Objectives

## Required Texts
\`\`\`meta-bind-js-view
{texts} as texts
---
const availableTexts = app.vault.getFiles().filter(file => file.extension == 'pdf').map(f => f?.name)
const escapeRegex = /[,"\`'()]/g;
options = availableTexts.map(t => \`option([[\${t.replace(escapeRegex,\`\\\\$1\`)}]], \${t.replace(escapeRegex,\`\\\\$1\`)})\` )
const str = \\\`INPUT[inlineListSuggester(\${options.join(", ")}):texts]\\\`
return engine.markdown.create(str)
\`\`\`

## Schedule

## Assignments

## Resources

## Vocabulary
\`\`\`dataviewjs
// Vocabulary aggregation code would go here
\`\`\`

## Due Dates
\`\`\`dataviewjs
// Due dates aggregation code would go here
\`\`\``;
  }
  generateCourseIndexTemplate() {
    return `---
content_type: course_index
tags:
  - index
---

# Course Index

## Modules

## Chapters

## Assignments

## Resources

## Vocabulary

## Due Dates`;
  }
  generateModuleTemplate() {
    return `---
${this.settings.useEnhancedMetadata ? `course_id: <% courseId %>
module_number: <% moduleNumber %>
week_number: <% weekNumber %>
class_day: <% dayOfWeek %>
content_type: module
parent_course: "[[<% course %>]]"` : `course_id: <% courseId %>
module_number: <% moduleNumber %>
week_number: <% weekNumber %>
class_day: <% dayOfWeek %>`}
created: <% tp.date.now("YYYY-MM-DD[T]HH:mm:ssZ") %>
tags:
  - education
  - <% courseId %>
  - module
---

<%*
const { season, moduleNumber, weekNumber, course, courseId, discipline, dayOfWeek } = await tp.user.new_module(app, tp, "2025");
let title = courseId
if (moduleNumber && weekNumber) { title = \`M\${moduleNumber}/W\${weekNumber}\`}
else if (moduleNumber) { title = \`M\${moduleNumber}\` } 
else if (weekNumber) { title = \`W\${weekNumber}\`}
%>

# [[<% course %>]] - <% title %> - <% dayOfWeek %>

## Learning Objectives

## Reading Assignment

## Lecture Notes

## Discussion Questions

## Assignments
| Date | Assignment | Status |
| ---- | ---------- | ------ |
|      |            |        |

## Vocabulary

## Additional Resources`;
  }
  generateChapterTemplate() {
    return `---
${this.settings.useEnhancedMetadata ? `course_id: <% courseId %>
chapter_number: <% chapterNumber %>
content_type: chapter
parent_course: "[[<% course %>]]"
text_reference: "[[<% text %>]]"` : `course_id: <% courseId %>
chapter_number: <% chapterNumber %>`}
created: <% tp.date.now("YYYY-MM-DD[T]HH:mm:ssZ") %>
tags:
  - education
  - <% courseId %>
  - chapter
---

<%*
const { chapterNumber, course, courseId, discipline, text} = await tp.user.new_chapter(tp);
%>

# [[<% text %>]] - Chapter <% chapterNumber %>

## Summary

## Key Concepts

## Vocabulary
- 

## Notes

## Discussion Questions

## Further Reading`;
  }
  generateAssignmentTemplate() {
    return `---
${this.settings.useEnhancedMetadata ? `course_id: <% courseId %>
assignment_type: <% assignmentType %>
due_date: <% dueDate %>
points: <% points %>
content_type: assignment
parent_course: "[[<% course %>]]"` : `course_id: <% courseId %>
assignment_type: <% assignmentType %>
due_date: <% dueDate %>`}
created: <% tp.date.now("YYYY-MM-DD[T]HH:mm:ssZ") %>
status: pending
tags:
  - education
  - <% courseId %>
  - assignment
---

# <% assignmentName %> - <% courseId %>

## Description

## Instructions

## Due Date
**Assigned**: <% tp.date.now("YYYY-MM-DD") %>
**Due**: <% dueDate %>

## Submission

## Grading Criteria

## Resources`;
  }
  generateDailyNoteTemplate() {
    return `---
content_type: daily_note
date: <% tp.date.now("YYYY-MM-DD") %>
tags:
  - daily
  - <% tp.date.now("YYYY") %>
  - <% tp.date.now("MM") %>
  - <% tp.date.now("DD") %>
---

# <% tp.date.now("YYYY-MM-DD - dddd") %>

<< [[<% tp.date.yesterday("YYYY-MM-DD") %>]] | [[<% tp.date.tomorrow("YYYY-MM-DD") %>]] >>

## Today's Focus

## Courses Worked On
- 

## Tasks Completed
- [ ] 

## Vocabulary Reviewed
- 

## Assignments Due
- 

## Learning Achievements

## Challenges

## Tomorrow's Plan

## Reflection`;
  }
  generateVocabularyTemplate() {
    return `## <% term %>
**Term**: <% term %>
**Part of Speech**: 
**Definition**: 
**Context**: 
**Examples**: 
**Related Terms**: 
**See Also**:`;
  }
  generateDueDateTemplate() {
    return `| <% dueDate %> | <% assignment %> | <% status %> |`;
  }
  createREADME(basePath) {
    return __async(this, null, function* () {
      const readmeContent = `# Tuckers Tools Templates

This directory contains templates for the Tuckers Tools Obsidian plugin.

## Template Categories

- **Courses**: Templates for creating and organizing courses
- **Modules**: Templates for course modules
- **Chapters**: Templates for chapter notes
- **Assignments**: Templates for assignments
- **Daily**: Templates for daily notes
- **Utilities**: Helper templates

## Usage

These templates are designed to work with the Tuckers Tools plugin. To use them:

1. Install the Tuckers Tools plugin
2. Configure your settings in the plugin settings tab
3. Use the "Insert Template" command to apply these templates to new notes

## Customization

Feel free to customize these templates to suit your needs. The plugin will not overwrite your changes when updating templates.`;
      yield this.writeTemplateFile(`${basePath}/README.md`, readmeContent);
    });
  }
};

// courseWizard.ts
var import_obsidian3 = require("obsidian");
var CourseCreationWizard = class {
  constructor(app, settings) {
    this.app = app;
    this.settings = settings;
  }
  createCourseHomepage() {
    return __async(this, null, function* () {
      try {
        const courseDetails = yield this.promptCourseDetails();
        if (!courseDetails) {
          return false;
        }
        const folderPath = yield this.createCourseFolderStructure(courseDetails);
        yield this.createCourseHomepageNote(courseDetails, folderPath);
        yield this.createAttachmentsFolder(folderPath);
        new import_obsidian3.Notice(`Course "${courseDetails.courseName}" created successfully!`);
        console.log(
          `Course created: ${courseDetails.courseName} at ${folderPath}`
        );
        return true;
      } catch (error) {
        console.error("Error creating course:", error);
        new import_obsidian3.Notice(`Error creating course: ${error.message}`);
        return false;
      }
    });
  }
  promptCourseDetails() {
    return __async(this, null, function* () {
      var _a;
      try {
        const courseName = yield this.promptWithValidation(
          "Course Name",
          "Enter course name (e.g., PSI-101 - Intro to Psychology)",
          (value) => value.trim().length > 0,
          "Course name is required"
        );
        if (!courseName)
          return null;
        const courseSeason = yield this.promptWithOptions(
          "Season",
          "Select semester/season",
          ["Fall", "Winter", "Spring", "Summer"]
        );
        if (!courseSeason)
          return null;
        const courseYear = yield this.promptWithValidation(
          "Year",
          "Enter academic year (e.g., 2025)",
          (value) => /^\d{4}$/.test(value.trim()),
          "Please enter a valid 4-digit year"
        );
        if (!courseYear)
          return null;
        const courseId = ((_a = courseName.split(" - ")[0]) == null ? void 0 : _a.trim()) || slugify(courseName);
        return {
          courseName,
          courseSeason,
          courseYear,
          courseId
        };
      } catch (error) {
        console.error("Error prompting for course details:", error);
        return null;
      }
    });
  }
  promptWithValidation(title, message, validator, errorMessage) {
    return __async(this, null, function* () {
      const value = prompt(`${title}: ${message}`);
      if (!value)
        return null;
      if (!validator(value)) {
        new import_obsidian3.Notice(errorMessage);
        return yield this.promptWithValidation(
          title,
          message,
          validator,
          errorMessage
        );
      }
      return value.trim();
    });
  }
  promptWithOptions(title, message, options) {
    return __async(this, null, function* () {
      const choice = prompt(
        `${title}: ${message}
Options: ${options.join(", ")}
Enter your choice:`
      );
      if (!choice)
        return null;
      const trimmedChoice = choice.trim();
      if (options.includes(trimmedChoice)) {
        return trimmedChoice;
      }
      new import_obsidian3.Notice(`Please select one of: ${options.join(", ")}`);
      return yield this.promptWithOptions(title, message, options);
    });
  }
  createCourseFolderStructure(courseDetails) {
    return __async(this, null, function* () {
      const folderPath = `${courseDetails.courseYear}/${courseDetails.courseSeason}/${courseDetails.courseName}`;
      try {
        yield this.app.vault.createFolder(folderPath);
        console.log(`Created course folder: ${folderPath}`);
        return folderPath;
      } catch (error) {
        console.log(`Course folder already exists or created: ${folderPath}`);
        return folderPath;
      }
    });
  }
  createCourseHomepageNote(courseDetails, folderPath) {
    return __async(this, null, function* () {
      const notePath = `${folderPath}/${courseDetails.courseName}.md`;
      const content = this.generateCourseHomepageContent(courseDetails);
      try {
        yield this.app.vault.create(notePath, content);
        console.log(`Created course homepage: ${notePath}`);
      } catch (error) {
        console.error(`Error creating course homepage: ${error}`);
        throw error;
      }
    });
  }
  createAttachmentsFolder(folderPath) {
    return __async(this, null, function* () {
      const attachmentsPath = `${folderPath}/Attachments`;
      try {
        yield this.app.vault.createFolder(attachmentsPath);
        console.log(`Created attachments folder: ${attachmentsPath}`);
      } catch (error) {
        console.log(`Attachments folder already exists: ${attachmentsPath}`);
      }
    });
  }
  generateCourseHomepageContent(courseDetails) {
    const enhancedMetadata = this.settings.useEnhancedMetadata;
    return `---
${enhancedMetadata ? `course_id: ${courseDetails.courseId}
course_name: ${courseDetails.courseName}
course_term: ${courseDetails.courseSeason} ${courseDetails.courseYear}
course_year: ${courseDetails.courseYear}
course_semester: ${courseDetails.courseSeason}
content_type: course_homepage
school: ${this.settings.schoolName}
school_abbreviation: ${this.settings.schoolAbbreviation}` : `course_id: ${courseDetails.courseId}
title: ${courseDetails.courseName}`}
created: ${new Date().toISOString()}
tags:
 - course_home
 - education
 - ${courseDetails.courseId}
 - ${this.settings.schoolAbbreviation}/${courseDetails.courseYear}/${courseDetails.courseSeason}/${courseDetails.courseId}
---


# ${courseDetails.courseName}

## Course Information
**Course ID**: ${courseDetails.courseId}
**Term**: ${courseDetails.courseSeason} ${courseDetails.courseYear}
**School**: ${this.settings.schoolName}

## Instructor
**Name**:
**Email**:
**Office Hours**:

## Course Description

## Learning Objectives

## Required Texts

## Schedule

## Assignments

## Resources

## Vocabulary

## Due Dates`;
  }
};

// vocabulary.ts
var import_obsidian4 = require("obsidian");
var VocabularyExtractor = class {
  constructor(app) {
    this.app = app;
  }
  extractVocabularyFromNote(content) {
    const vocabRegex = /^#+ Vocabulary.*\n((?:.*?\n)*?)(?=^\s*#\s|$)/m;
    const vocabMatches = content == null ? void 0 : content.match(vocabRegex);
    if (vocabMatches) {
      const vocabData = vocabMatches[1].trim();
      const cleanedVocab = vocabData.replace(/\[\[.*?\]\]/g, "").replace(/^\s*-\s*/gm, "").split("\n").map((term) => term.trim()).filter((term) => term.length > 0);
      return cleanedVocab;
    }
    return [];
  }
  extractVocabularyFromCourse(courseId) {
    return __async(this, null, function* () {
      console.log(`Extracting vocabulary for course: ${courseId}`);
      try {
        const courseNotes = yield this.findCourseNotes(courseId);
        if (courseNotes.length === 0) {
          console.log(`No notes found for course: ${courseId}`);
          return {};
        }
        const vocabularyData = {};
        for (const note of courseNotes) {
          try {
            const content = yield this.app.vault.read(note);
            const vocabulary = this.extractVocabularyFromNote(content);
            if (vocabulary.length > 0) {
              vocabularyData[note.basename] = vocabulary;
            }
          } catch (error) {
            console.error(`Error reading note ${note.path}:`, error);
          }
        }
        console.log(
          `Extracted vocabulary from ${Object.keys(vocabularyData).length} notes for course: ${courseId}`
        );
        return vocabularyData;
      } catch (error) {
        console.error(
          `Error extracting vocabulary for course ${courseId}:`,
          error
        );
        return {};
      }
    });
  }
  findCourseNotes(courseId) {
    return __async(this, null, function* () {
      const notes = [];
      const files = this.app.vault.getMarkdownFiles();
      for (const file of files) {
        if (file.path.includes(courseId) || (yield this.noteBelongsToCourse(file, courseId))) {
          notes.push(file);
        }
      }
      return notes;
    });
  }
  noteBelongsToCourse(file, courseId) {
    return __async(this, null, function* () {
      try {
        const content = yield this.app.vault.read(file);
        const frontmatterMatch = content.match(/^---\n([\s\S]*?)\n---/);
        if (frontmatterMatch) {
          const frontmatter = frontmatterMatch[1];
          return frontmatter.includes(`course_id: ${courseId}`) || frontmatter.includes(`course_id:${courseId}`);
        }
        return false;
      } catch (error) {
        console.error(
          `Error checking if note ${file.path} belongs to course ${courseId}:`,
          error
        );
        return false;
      }
    });
  }
  generateVocabularyIndex(courseId, vocabularyData) {
    return __async(this, null, function* () {
      const allTerms = [];
      const termSources = {};
      for (const [noteName, terms] of Object.entries(vocabularyData)) {
        for (const term of terms) {
          if (!allTerms.includes(term)) {
            allTerms.push(term);
            termSources[term] = [];
          }
          termSources[term].push(noteName);
        }
      }
      allTerms.sort();
      let content = `# Vocabulary Index - ${courseId}

`;
      content += `Total unique terms: ${allTerms.length}

`;
      for (const term of allTerms) {
        content += `## ${term}
`;
        content += `**Sources:** ${termSources[term].join(", ")}

`;
        content += `**Definition:**

`;
        content += `**Context:**

`;
        content += `**Examples:**

`;
        content += `---

`;
      }
      return content;
    });
  }
  createVocabularyIndexFile(courseId) {
    return __async(this, null, function* () {
      try {
        const vocabularyData = yield this.extractVocabularyFromCourse(courseId);
        if (Object.keys(vocabularyData).length === 0) {
          console.log(`No vocabulary found for course: ${courseId}`);
          return;
        }
        const indexContent = yield this.generateVocabularyIndex(
          courseId,
          vocabularyData
        );
        const fileName = `${courseId} - Vocabulary Index.md`;
        const filePath = `Courses/${courseId}/${fileName}`;
        try {
          yield this.app.vault.create(filePath, indexContent);
          console.log(`Created vocabulary index file: ${filePath}`);
        } catch (error) {
          const existingFile = this.app.vault.getAbstractFileByPath(filePath);
          if (existingFile && existingFile instanceof import_obsidian4.TFile) {
            yield this.app.vault.modify(existingFile, indexContent);
            console.log(`Updated vocabulary index file: ${filePath}`);
          }
        }
      } catch (error) {
        console.error(
          `Error creating vocabulary index for course ${courseId}:`,
          error
        );
        throw error;
      }
    });
  }
};

// dueDates.ts
var import_obsidian5 = require("obsidian");
var DueDatesParser = class {
  constructor(app) {
    this.app = app;
  }
  parseDueDatesFromNote(content) {
    const dueDatesRegex = /# Due Dates[\s\S]*?(?=\n#|$)/;
    const matches = content == null ? void 0 : content.match(dueDatesRegex);
    if (!matches) {
      return [];
    }
    const dueDatesSection = matches[0];
    const dueDates = [];
    const tableRegex = /\|[\s\S]*?\n/g;
    const tableMatches = dueDatesSection.match(tableRegex);
    if (tableMatches) {
      for (const table of tableMatches) {
        const rows = table.trim().split("\n").filter((row) => row.startsWith("|"));
        const parsedRows = this.parseTableRows(rows);
        dueDates.push(...parsedRows);
      }
    }
    return dueDates;
  }
  parseTableRows(rows) {
    if (rows.length < 2)
      return [];
    const dueDates = [];
    for (let i = 1; i < rows.length; i++) {
      const row = rows[i];
      const columns = row.split("|").map((col) => col.trim()).filter((col) => col);
      if (columns.length >= 2) {
        const [date, assignment, status = "pending"] = columns;
        if (date && assignment && this.isValidDate(date)) {
          dueDates.push({ date, assignment, status });
        }
      }
    }
    return dueDates;
  }
  isValidDate(dateString) {
    const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
    return dateRegex.test(dateString) && !isNaN(Date.parse(dateString));
  }
  parseDueDatesFromCourse(courseId, startDate, endDate) {
    return __async(this, null, function* () {
      console.log(`Parsing due dates for course: ${courseId}`);
      try {
        const courseNotes = yield this.findCourseNotes(courseId);
        if (courseNotes.length === 0) {
          console.log(`No notes found for course: ${courseId}`);
          return [];
        }
        const allDueDates = [];
        for (const note of courseNotes) {
          try {
            const content = yield this.app.vault.read(note);
            const dueDates = this.parseDueDatesFromNote(content);
            const dueDatesWithSource = dueDates.map((dueDate) => __spreadProps(__spreadValues({}, dueDate), {
              source: note.basename
            }));
            allDueDates.push(...dueDatesWithSource);
          } catch (error) {
            console.error(`Error reading note ${note.path}:`, error);
          }
        }
        let filteredDueDates = allDueDates;
        if (startDate || endDate) {
          filteredDueDates = this.filterByDateRange(
            allDueDates,
            startDate,
            endDate
          );
        }
        filteredDueDates.sort(
          (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()
        );
        console.log(
          `Found ${filteredDueDates.length} due dates for course: ${courseId}`
        );
        return filteredDueDates;
      } catch (error) {
        console.error(`Error parsing due dates for course ${courseId}:`, error);
        return [];
      }
    });
  }
  findCourseNotes(courseId) {
    return __async(this, null, function* () {
      const notes = [];
      const files = this.app.vault.getMarkdownFiles();
      for (const file of files) {
        if (file.path.includes(courseId) || (yield this.noteBelongsToCourse(file, courseId))) {
          notes.push(file);
        }
      }
      return notes;
    });
  }
  noteBelongsToCourse(file, courseId) {
    return __async(this, null, function* () {
      try {
        const content = yield this.app.vault.read(file);
        const frontmatterMatch = content.match(/^---\n([\s\S]*?)\n---/);
        if (frontmatterMatch) {
          const frontmatter = frontmatterMatch[1];
          return frontmatter.includes(`course_id: ${courseId}`) || frontmatter.includes(`course_id:${courseId}`);
        }
        return false;
      } catch (error) {
        console.error(
          `Error checking if note ${file.path} belongs to course ${courseId}:`,
          error
        );
        return false;
      }
    });
  }
  filterByDateRange(dueDates, startDate, endDate) {
    return dueDates.filter((dueDate) => {
      const dueDateTime = new Date(dueDate.date).getTime();
      if (startDate && dueDateTime < new Date(startDate).getTime()) {
        return false;
      }
      if (endDate && dueDateTime > new Date(endDate).getTime()) {
        return false;
      }
      return true;
    });
  }
  generateDueDatesSummary(courseId, dueDates) {
    return __async(this, null, function* () {
      if (dueDates.length === 0) {
        return `# Due Dates Summary - ${courseId}

No due dates found.
`;
      }
      const byStatus = dueDates.reduce((acc, dueDate) => {
        if (!acc[dueDate.status]) {
          acc[dueDate.status] = [];
        }
        acc[dueDate.status].push(dueDate);
        return acc;
      }, {});
      let content = `# Due Dates Summary - ${courseId}

`;
      content += `Total assignments: ${dueDates.length}

`;
      for (const [status, items] of Object.entries(byStatus)) {
        content += `## ${status.charAt(0).toUpperCase() + status.slice(1)} (${items.length})

`;
        content += `| Date | Assignment | Source |
`;
        content += `| ---- | ---------- | ------ |
`;
        for (const item of items) {
          content += `| ${item.date} | ${item.assignment} | ${item.source} |
`;
        }
        content += `
`;
      }
      return content;
    });
  }
  createDueDatesSummaryFile(courseId, startDate, endDate) {
    return __async(this, null, function* () {
      try {
        const dueDates = yield this.parseDueDatesFromCourse(
          courseId,
          startDate,
          endDate
        );
        const summaryContent = yield this.generateDueDatesSummary(
          courseId,
          dueDates
        );
        const fileName = `${courseId} - Due Dates Summary.md`;
        const filePath = `Courses/${courseId}/${fileName}`;
        try {
          yield this.app.vault.create(filePath, summaryContent);
          console.log(`Created due dates summary file: ${filePath}`);
        } catch (error) {
          const existingFile = this.app.vault.getAbstractFileByPath(filePath);
          if (existingFile && existingFile instanceof import_obsidian5.TFile) {
            yield this.app.vault.modify(existingFile, summaryContent);
            console.log(`Updated due dates summary file: ${filePath}`);
          }
        }
      } catch (error) {
        console.error(
          `Error creating due dates summary for course ${courseId}:`,
          error
        );
        throw error;
      }
    });
  }
};

// dailyNotes.ts
var import_obsidian6 = require("obsidian");
var DailyNotesIntegration = class {
  constructor(app) {
    this.app = app;
  }
  getTodaysActivities() {
    return __async(this, null, function* () {
      console.log("Getting today's academic activities");
      try {
        const today = new Date();
        const todayString = today.toISOString().split("T")[0];
        const files = this.app.vault.getMarkdownFiles();
        const todaysFiles = [];
        for (const file of files) {
          const fileDate = this.extractDateFromPath(file.path);
          if (fileDate === todayString) {
            todaysFiles.push(file);
          }
        }
        const activities = [];
        for (const file of todaysFiles) {
          const activity = yield this.analyzeFileActivity(file);
          if (activity) {
            activities.push(activity);
          }
        }
        console.log(`Found ${activities.length} academic activities for today`);
        return activities;
      } catch (error) {
        console.error("Error getting today's activities:", error);
        return [];
      }
    });
  }
  getCourseActivityForDate(courseId, date) {
    return __async(this, null, function* () {
      console.log(`Getting activity for course ${courseId} on date ${date}`);
      try {
        const courseFiles = yield this.findCourseFilesForDate(courseId, date);
        const activities = [];
        for (const file of courseFiles) {
          const content = yield this.app.vault.read(file);
          const fileType = this.determineFileType(file, content);
          activities.push({
            file: file.basename,
            type: fileType
          });
        }
        console.log(
          `Found ${activities.length} activities for course ${courseId} on ${date}`
        );
        return activities;
      } catch (error) {
        console.error(
          `Error getting course activity for ${courseId} on ${date}:`,
          error
        );
        return [];
      }
    });
  }
  extractDateFromPath(filePath) {
    const dateRegex = /(\d{4}-\d{2}-\d{2})/g;
    const matches = filePath.match(dateRegex);
    return matches ? matches[matches.length - 1] : null;
  }
  analyzeFileActivity(file) {
    return __async(this, null, function* () {
      try {
        const content = yield this.app.vault.read(file);
        const fileType = this.determineFileType(file, content);
        const courseId = this.extractCourseIdFromContent(content) || this.extractCourseIdFromPath(file.path);
        return {
          file: file.basename,
          type: fileType,
          course: courseId || void 0
        };
      } catch (error) {
        console.error(`Error analyzing file ${file.path}:`, error);
        return null;
      }
    });
  }
  determineFileType(file, content) {
    const path = file.path.toLowerCase();
    if (path.includes("daily") || content.includes("content_type: daily_note")) {
      return "daily_note";
    }
    if (path.includes("courses") || content.includes("course_id:")) {
      if (content.includes("content_type: course_homepage")) {
        return "course_homepage";
      }
      if (content.includes("content_type: module")) {
        return "module";
      }
      if (content.includes("content_type: chapter")) {
        return "chapter";
      }
      if (content.includes("content_type: assignment")) {
        return "assignment";
      }
      return "course_note";
    }
    if (content.includes("## ") && content.match(/^\*\*Term\*\*:/m)) {
      return "vocabulary_entry";
    }
    return "other";
  }
  extractCourseIdFromContent(content) {
    const courseIdRegex = /course_id:\s*([A-Z]{2,4}-\d{3})/;
    const match = content.match(courseIdRegex);
    return match ? match[1] : null;
  }
  extractCourseIdFromPath(filePath) {
    const courseIdRegex = /([A-Z]{2,4}-\d{3})/g;
    const matches = filePath.match(courseIdRegex);
    return matches ? matches[matches.length - 1] : null;
  }
  findCourseFilesForDate(courseId, date) {
    return __async(this, null, function* () {
      const files = [];
      const allFiles = this.app.vault.getMarkdownFiles();
      for (const file of allFiles) {
        if (file.path.includes(courseId) || (yield this.fileBelongsToCourse(file, courseId))) {
          const fileDate = this.extractDateFromPath(file.path);
          if (fileDate === date) {
            files.push(file);
          }
        }
      }
      return files;
    });
  }
  fileBelongsToCourse(file, courseId) {
    return __async(this, null, function* () {
      try {
        const content = yield this.app.vault.read(file);
        return this.extractCourseIdFromContent(content) === courseId;
      } catch (error) {
        console.error(
          `Error checking if file ${file.path} belongs to course ${courseId}:`,
          error
        );
        return false;
      }
    });
  }
  generateDailySummary(date) {
    return __async(this, null, function* () {
      const targetDate = date || new Date().toISOString().split("T")[0];
      const activities = yield this.getCourseActivityForDate("", targetDate);
      if (activities.length === 0) {
        return `# Academic Activities - ${targetDate}

No academic activities recorded for this date.
`;
      }
      const byCourse = {};
      const noCourse = [];
      for (const activity of activities) {
        if (activity.file.includes("Courses/")) {
          const pathParts = activity.file.split("/");
          const courseIndex = pathParts.findIndex((part) => part.includes("-"));
          if (courseIndex >= 0) {
            const courseId = pathParts[courseIndex];
            if (!byCourse[courseId]) {
              byCourse[courseId] = [];
            }
            byCourse[courseId].push(activity);
          } else {
            noCourse.push(activity);
          }
        } else {
          noCourse.push(activity);
        }
      }
      let content = `# Academic Activities - ${targetDate}

`;
      content += `Total activities: ${activities.length}

`;
      for (const [courseId, courseActivities] of Object.entries(byCourse)) {
        content += `## ${courseId}

`;
        content += `| File | Type |
`;
        content += `| ---- | ---- |
`;
        for (const activity of courseActivities) {
          content += `| ${activity.file} | ${activity.type} |
`;
        }
        content += `
`;
      }
      if (noCourse.length > 0) {
        content += `## Other Activities

`;
        content += `| File | Type |
`;
        content += `| ---- | ---- |
`;
        for (const activity of noCourse) {
          content += `| ${activity.file} | ${activity.type} |
`;
        }
        content += `
`;
      }
      return content;
    });
  }
  createDailySummaryFile(date) {
    return __async(this, null, function* () {
      try {
        const targetDate = date || new Date().toISOString().split("T")[0];
        const summaryContent = yield this.generateDailySummary(targetDate);
        const fileName = `${targetDate} - Academic Summary.md`;
        const filePath = `Daily/${fileName}`;
        try {
          yield this.app.vault.create(filePath, summaryContent);
          console.log(`Created daily summary file: ${filePath}`);
        } catch (error) {
          const existingFile = this.app.vault.getAbstractFileByPath(filePath);
          if (existingFile && existingFile instanceof import_obsidian6.TFile) {
            yield this.app.vault.modify(existingFile, summaryContent);
            console.log(`Updated daily summary file: ${filePath}`);
          }
        }
      } catch (error) {
        console.error(`Error creating daily summary for ${date}:`, error);
        throw error;
      }
    });
  }
};

// main.ts
var TuckersToolsPlugin = class extends import_obsidian7.Plugin {
  onload() {
    return __async(this, null, function* () {
      console.log("Loading Tuckers Tools plugin");
      yield this.loadSettings();
      this.templateManager = new TemplateManager(this.app, this.settings);
      this.courseWizard = new CourseCreationWizard(this.app, this.settings);
      this.vocabularyExtractor = new VocabularyExtractor(this.app);
      this.dueDatesParser = new DueDatesParser(this.app);
      this.dailyNotesIntegration = new DailyNotesIntegration(this.app);
      this.addSettingTab(new TuckersToolsSettingTab(this.app, this));
      this.initializeTemplaterFunctions();
      this.addCommand({
        id: "install-templates",
        name: "Install/Update Tuckers Tools Templates",
        callback: () => {
          this.templateManager.installTemplates();
        }
      });
      this.addCommand({
        id: "update-templates",
        name: "Update Tuckers Tools Templates",
        callback: () => {
          this.templateManager.updateTemplates();
        }
      });
      this.addCommand({
        id: "create-course",
        name: "Create New Course",
        callback: () => {
          this.courseWizard.createCourseHomepage();
        }
      });
      this.addCommand({
        id: "extract-vocabulary",
        name: "Extract Course Vocabulary",
        callback: () => __async(this, null, function* () {
          const courseId = yield this.promptForCourseId(
            "Enter course ID to extract vocabulary from"
          );
          if (courseId) {
            yield this.vocabularyExtractor.createVocabularyIndexFile(courseId);
          }
        })
      });
      this.addCommand({
        id: "generate-due-dates-summary",
        name: "Generate Due Dates Summary",
        callback: () => __async(this, null, function* () {
          const courseId = yield this.promptForCourseId(
            "Enter course ID to generate due dates summary for"
          );
          if (courseId) {
            yield this.dueDatesParser.createDueDatesSummaryFile(courseId);
          }
        })
      });
      this.addCommand({
        id: "generate-daily-summary",
        name: "Generate Daily Academic Summary",
        callback: () => __async(this, null, function* () {
          const date = yield this.promptForDate(
            "Enter date (YYYY-MM-DD) or leave empty for today"
          );
          yield this.dailyNotesIntegration.createDailySummaryFile(
            date || void 0
          );
        })
      });
      this.addStatusBarItem().setText("Tuckers Tools");
    });
  }
  promptForCourseId(message) {
    return __async(this, null, function* () {
      const courseId = prompt(message + "\n\nExample: PSI-101");
      return courseId ? courseId.trim() : null;
    });
  }
  promptForDate(message) {
    return __async(this, null, function* () {
      const date = prompt(
        message + "\n\nExample: 2025-01-15 or leave empty for today"
      );
      return date ? date.trim() : null;
    });
  }
  onunload() {
    console.log("Unloading Tuckers Tools plugin");
  }
  initializeTemplaterFunctions() {
    return __async(this, null, function* () {
      const templaterPlugin = this.app.plugins.getPlugin("templater-obsidian");
      if (!templaterPlugin) {
        console.log("Templater plugin not found. Course templates will not work properly.");
        return;
      }
      templaterPlugin.templater.functions_manager.add_from_js_function({
        name: "new_module",
        f: (app, tp, year) => {
          return this.newModuleFunction(app, tp, year);
        },
        doc: "Creates a new module with interactive prompts"
      });
      templaterPlugin.templater.functions_manager.add_from_js_function({
        name: "new_chapter",
        f: (tp) => {
          return this.newChapterFunction(tp);
        },
        doc: "Creates a new chapter with interactive prompts"
      });
    });
  }
  newModuleFunction(app, tp, year) {
    return __async(this, null, function* () {
      var _a;
      const moduleNumber = yield tp.system.prompt("Module Number (optional)", "");
      const weekNumber = yield tp.system.prompt("Week Number (optional)", "");
      const course = yield tp.system.suggester(
        () => app.vault.getMarkdownFiles().filter((f) => f.path.includes("Courses")).map((f) => f.basename),
        app.vault.getMarkdownFiles().filter((f) => f.path.includes("Courses"))
      );
      const courseId = course ? course.split(" - ")[0] || course : "";
      const discipline = course ? ((_a = course.split(" - ")[0]) == null ? void 0 : _a.substring(0, 3)) || "GEN" : "GEN";
      const dayOptions = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
      const dayOfWeek = yield tp.system.suggester(dayOptions, dayOptions, "Day of Week");
      return {
        season: "Fall",
        // This would normally be dynamically determined
        moduleNumber: moduleNumber || null,
        weekNumber: weekNumber || null,
        course,
        courseId,
        discipline,
        dayOfWeek
      };
    });
  }
  newChapterFunction(tp) {
    return __async(this, null, function* () {
      var _a;
      const chapterNumber = yield tp.system.prompt("Chapter Number", "");
      const course = yield tp.system.suggester(
        () => tp.app.vault.getMarkdownFiles().filter((f) => f.path.includes("Courses")).map((f) => f.basename),
        tp.app.vault.getMarkdownFiles().filter((f) => f.path.includes("Courses"))
      );
      const courseId = course ? course.split(" - ")[0] || course : "";
      const discipline = course ? ((_a = course.split(" - ")[0]) == null ? void 0 : _a.substring(0, 3)) || "GEN" : "GEN";
      const textOptions = tp.app.vault.getFiles().filter((f) => f.extension === "pdf").map((f) => f.basename);
      const text = yield tp.system.suggester(textOptions, textOptions, "Textbook");
      return {
        chapterNumber: chapterNumber || "",
        course,
        courseId,
        discipline,
        text
      };
    });
  }
  loadSettings() {
    return __async(this, null, function* () {
      this.settings = Object.assign({}, DEFAULT_SETTINGS, yield this.loadData());
    });
  }
  saveSettings() {
    return __async(this, null, function* () {
      yield this.saveData(this.settings);
    });
  }
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsibWFpbi50cyIsICJzZXR0aW5ncy50cyIsICJ1dGlscy50cyIsICJ0ZW1wbGF0ZU1hbmFnZXIudHMiLCAiY291cnNlV2l6YXJkLnRzIiwgInZvY2FidWxhcnkudHMiLCAiZHVlRGF0ZXMudHMiLCAiZGFpbHlOb3Rlcy50cyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiaW1wb3J0IHsgUGx1Z2luIH0gZnJvbSBcIm9ic2lkaWFuXCJcbmltcG9ydCB7XG4gIFR1Y2tlcnNUb29sc1NldHRpbmdzLFxuICBERUZBVUxUX1NFVFRJTkdTLFxuICBUdWNrZXJzVG9vbHNTZXR0aW5nVGFiXG59IGZyb20gXCIuL3NldHRpbmdzXCJcbmltcG9ydCB7IFRlbXBsYXRlTWFuYWdlciB9IGZyb20gXCIuL3RlbXBsYXRlTWFuYWdlclwiXG5pbXBvcnQgeyBDb3Vyc2VDcmVhdGlvbldpemFyZCB9IGZyb20gXCIuL2NvdXJzZVdpemFyZFwiXG5pbXBvcnQgeyBWb2NhYnVsYXJ5RXh0cmFjdG9yIH0gZnJvbSBcIi4vdm9jYWJ1bGFyeVwiXG5pbXBvcnQgeyBEdWVEYXRlc1BhcnNlciB9IGZyb20gXCIuL2R1ZURhdGVzXCJcbmltcG9ydCB7IERhaWx5Tm90ZXNJbnRlZ3JhdGlvbiB9IGZyb20gXCIuL2RhaWx5Tm90ZXNcIlxuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBUdWNrZXJzVG9vbHNQbHVnaW4gZXh0ZW5kcyBQbHVnaW4ge1xuICBzZXR0aW5nczogVHVja2Vyc1Rvb2xzU2V0dGluZ3NcbiAgdGVtcGxhdGVNYW5hZ2VyOiBUZW1wbGF0ZU1hbmFnZXJcbiAgY291cnNlV2l6YXJkOiBDb3Vyc2VDcmVhdGlvbldpemFyZFxuICB2b2NhYnVsYXJ5RXh0cmFjdG9yOiBWb2NhYnVsYXJ5RXh0cmFjdG9yXG4gIGR1ZURhdGVzUGFyc2VyOiBEdWVEYXRlc1BhcnNlclxuICBkYWlseU5vdGVzSW50ZWdyYXRpb246IERhaWx5Tm90ZXNJbnRlZ3JhdGlvblxuXG4gIGFzeW5jIG9ubG9hZCgpIHtcbiAgICBjb25zb2xlLmxvZyhcIkxvYWRpbmcgVHVja2VycyBUb29scyBwbHVnaW5cIilcblxuICAgIC8vIExvYWQgc2V0dGluZ3NcbiAgICBhd2FpdCB0aGlzLmxvYWRTZXR0aW5ncygpXG5cbiAgICAvLyBJbml0aWFsaXplIGNvbXBvbmVudHNcbiAgICB0aGlzLnRlbXBsYXRlTWFuYWdlciA9IG5ldyBUZW1wbGF0ZU1hbmFnZXIodGhpcy5hcHAsIHRoaXMuc2V0dGluZ3MpXG4gICAgdGhpcy5jb3Vyc2VXaXphcmQgPSBuZXcgQ291cnNlQ3JlYXRpb25XaXphcmQodGhpcy5hcHAsIHRoaXMuc2V0dGluZ3MpXG4gICAgdGhpcy52b2NhYnVsYXJ5RXh0cmFjdG9yID0gbmV3IFZvY2FidWxhcnlFeHRyYWN0b3IodGhpcy5hcHApXG4gICAgdGhpcy5kdWVEYXRlc1BhcnNlciA9IG5ldyBEdWVEYXRlc1BhcnNlcih0aGlzLmFwcClcbiAgICB0aGlzLmRhaWx5Tm90ZXNJbnRlZ3JhdGlvbiA9IG5ldyBEYWlseU5vdGVzSW50ZWdyYXRpb24odGhpcy5hcHApXG5cbiAgICAvLyBBZGQgc2V0dGluZ3MgdGFiXG4gICAgdGhpcy5hZGRTZXR0aW5nVGFiKG5ldyBUdWNrZXJzVG9vbHNTZXR0aW5nVGFiKHRoaXMuYXBwLCB0aGlzKSlcblxuICAgIC8vIEluaXRpYWxpemUgdGVtcGxhdGVyIGZ1bmN0aW9ucyBpZiB0ZW1wbGF0ZXIgaXMgYXZhaWxhYmxlXG4gICAgdGhpcy5pbml0aWFsaXplVGVtcGxhdGVyRnVuY3Rpb25zKClcblxuICAgIC8vIEFkZCBjb21tYW5kc1xuICAgIHRoaXMuYWRkQ29tbWFuZCh7XG4gICAgICBpZDogXCJpbnN0YWxsLXRlbXBsYXRlc1wiLFxuICAgICAgbmFtZTogXCJJbnN0YWxsL1VwZGF0ZSBUdWNrZXJzIFRvb2xzIFRlbXBsYXRlc1wiLFxuICAgICAgY2FsbGJhY2s6ICgpID0+IHtcbiAgICAgICAgdGhpcy50ZW1wbGF0ZU1hbmFnZXIuaW5zdGFsbFRlbXBsYXRlcygpXG4gICAgICB9XG4gICAgfSlcblxuICAgIHRoaXMuYWRkQ29tbWFuZCh7XG4gICAgICBpZDogXCJ1cGRhdGUtdGVtcGxhdGVzXCIsXG4gICAgICBuYW1lOiBcIlVwZGF0ZSBUdWNrZXJzIFRvb2xzIFRlbXBsYXRlc1wiLFxuICAgICAgY2FsbGJhY2s6ICgpID0+IHtcbiAgICAgICAgdGhpcy50ZW1wbGF0ZU1hbmFnZXIudXBkYXRlVGVtcGxhdGVzKClcbiAgICAgIH1cbiAgICB9KVxuXG4gICAgdGhpcy5hZGRDb21tYW5kKHtcbiAgICAgIGlkOiBcImNyZWF0ZS1jb3Vyc2VcIixcbiAgICAgIG5hbWU6IFwiQ3JlYXRlIE5ldyBDb3Vyc2VcIixcbiAgICAgIGNhbGxiYWNrOiAoKSA9PiB7XG4gICAgICAgIHRoaXMuY291cnNlV2l6YXJkLmNyZWF0ZUNvdXJzZUhvbWVwYWdlKClcbiAgICAgIH1cbiAgICB9KVxuXG4gICAgdGhpcy5hZGRDb21tYW5kKHtcbiAgICAgIGlkOiBcImV4dHJhY3Qtdm9jYWJ1bGFyeVwiLFxuICAgICAgbmFtZTogXCJFeHRyYWN0IENvdXJzZSBWb2NhYnVsYXJ5XCIsXG4gICAgICBjYWxsYmFjazogYXN5bmMgKCkgPT4ge1xuICAgICAgICBjb25zdCBjb3Vyc2VJZCA9IGF3YWl0IHRoaXMucHJvbXB0Rm9yQ291cnNlSWQoXG4gICAgICAgICAgXCJFbnRlciBjb3Vyc2UgSUQgdG8gZXh0cmFjdCB2b2NhYnVsYXJ5IGZyb21cIlxuICAgICAgICApXG4gICAgICAgIGlmIChjb3Vyc2VJZCkge1xuICAgICAgICAgIGF3YWl0IHRoaXMudm9jYWJ1bGFyeUV4dHJhY3Rvci5jcmVhdGVWb2NhYnVsYXJ5SW5kZXhGaWxlKGNvdXJzZUlkKVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfSlcblxuICAgIHRoaXMuYWRkQ29tbWFuZCh7XG4gICAgICBpZDogXCJnZW5lcmF0ZS1kdWUtZGF0ZXMtc3VtbWFyeVwiLFxuICAgICAgbmFtZTogXCJHZW5lcmF0ZSBEdWUgRGF0ZXMgU3VtbWFyeVwiLFxuICAgICAgY2FsbGJhY2s6IGFzeW5jICgpID0+IHtcbiAgICAgICAgY29uc3QgY291cnNlSWQgPSBhd2FpdCB0aGlzLnByb21wdEZvckNvdXJzZUlkKFxuICAgICAgICAgIFwiRW50ZXIgY291cnNlIElEIHRvIGdlbmVyYXRlIGR1ZSBkYXRlcyBzdW1tYXJ5IGZvclwiXG4gICAgICAgIClcbiAgICAgICAgaWYgKGNvdXJzZUlkKSB7XG4gICAgICAgICAgYXdhaXQgdGhpcy5kdWVEYXRlc1BhcnNlci5jcmVhdGVEdWVEYXRlc1N1bW1hcnlGaWxlKGNvdXJzZUlkKVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfSlcblxuICAgIHRoaXMuYWRkQ29tbWFuZCh7XG4gICAgICBpZDogXCJnZW5lcmF0ZS1kYWlseS1zdW1tYXJ5XCIsXG4gICAgICBuYW1lOiBcIkdlbmVyYXRlIERhaWx5IEFjYWRlbWljIFN1bW1hcnlcIixcbiAgICAgIGNhbGxiYWNrOiBhc3luYyAoKSA9PiB7XG4gICAgICAgIGNvbnN0IGRhdGUgPSBhd2FpdCB0aGlzLnByb21wdEZvckRhdGUoXG4gICAgICAgICAgXCJFbnRlciBkYXRlIChZWVlZLU1NLUREKSBvciBsZWF2ZSBlbXB0eSBmb3IgdG9kYXlcIlxuICAgICAgICApXG4gICAgICAgIGF3YWl0IHRoaXMuZGFpbHlOb3Rlc0ludGVncmF0aW9uLmNyZWF0ZURhaWx5U3VtbWFyeUZpbGUoXG4gICAgICAgICAgZGF0ZSB8fCB1bmRlZmluZWRcbiAgICAgICAgKVxuICAgICAgfVxuICAgIH0pXG5cbiAgICAvLyBBZGQgc3RhdHVzIGJhciBpdGVtXG4gICAgdGhpcy5hZGRTdGF0dXNCYXJJdGVtKCkuc2V0VGV4dChcIlR1Y2tlcnMgVG9vbHNcIilcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgcHJvbXB0Rm9yQ291cnNlSWQobWVzc2FnZTogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmcgfCBudWxsPiB7XG4gICAgY29uc3QgY291cnNlSWQgPSBwcm9tcHQobWVzc2FnZSArIFwiXFxuXFxuRXhhbXBsZTogUFNJLTEwMVwiKVxuICAgIHJldHVybiBjb3Vyc2VJZCA/IGNvdXJzZUlkLnRyaW0oKSA6IG51bGxcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgcHJvbXB0Rm9yRGF0ZShtZXNzYWdlOiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZyB8IG51bGw+IHtcbiAgICBjb25zdCBkYXRlID0gcHJvbXB0KFxuICAgICAgbWVzc2FnZSArIFwiXFxuXFxuRXhhbXBsZTogMjAyNS0wMS0xNSBvciBsZWF2ZSBlbXB0eSBmb3IgdG9kYXlcIlxuICAgIClcbiAgICByZXR1cm4gZGF0ZSA/IGRhdGUudHJpbSgpIDogbnVsbFxuICB9XG5cbiAgb251bmxvYWQoKSB7XG4gICAgY29uc29sZS5sb2coXCJVbmxvYWRpbmcgVHVja2VycyBUb29scyBwbHVnaW5cIilcbiAgfVxuXG4gIGFzeW5jIGluaXRpYWxpemVUZW1wbGF0ZXJGdW5jdGlvbnMoKSB7XG4gICAgLy8gQ2hlY2sgaWYgVGVtcGxhdGVyIHBsdWdpbiBpcyBhdmFpbGFibGVcbiAgICBjb25zdCB0ZW1wbGF0ZXJQbHVnaW4gPSAodGhpcy5hcHAgYXMgYW55KS5wbHVnaW5zLmdldFBsdWdpbihcInRlbXBsYXRlci1vYnNpZGlhblwiKTtcbiAgICBpZiAoIXRlbXBsYXRlclBsdWdpbikge1xuICAgICAgY29uc29sZS5sb2coXCJUZW1wbGF0ZXIgcGx1Z2luIG5vdCBmb3VuZC4gQ291cnNlIHRlbXBsYXRlcyB3aWxsIG5vdCB3b3JrIHByb3Blcmx5LlwiKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICAvLyBSZWdpc3RlciB1c2VyIGZ1bmN0aW9ucyB3aXRoIFRlbXBsYXRlclxuICAgIHRlbXBsYXRlclBsdWdpbi50ZW1wbGF0ZXIuZnVuY3Rpb25zX21hbmFnZXIuYWRkX2Zyb21fanNfZnVuY3Rpb24oe1xuICAgICAgbmFtZTogXCJuZXdfbW9kdWxlXCIsXG4gICAgICBmOiAoYXBwOiBhbnksIHRwOiBhbnksIHllYXI6IGFueSkgPT4ge1xuICAgICAgICByZXR1cm4gdGhpcy5uZXdNb2R1bGVGdW5jdGlvbihhcHAsIHRwLCB5ZWFyKTtcbiAgICAgIH0sXG4gICAgICBkb2M6IFwiQ3JlYXRlcyBhIG5ldyBtb2R1bGUgd2l0aCBpbnRlcmFjdGl2ZSBwcm9tcHRzXCJcbiAgICB9KTtcblxuICAgIHRlbXBsYXRlclBsdWdpbi50ZW1wbGF0ZXIuZnVuY3Rpb25zX21hbmFnZXIuYWRkX2Zyb21fanNfZnVuY3Rpb24oe1xuICAgICAgbmFtZTogXCJuZXdfY2hhcHRlclwiLFxuICAgICAgZjogKHRwOiBhbnkpID0+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMubmV3Q2hhcHRlckZ1bmN0aW9uKHRwKTtcbiAgICAgIH0sXG4gICAgICBkb2M6IFwiQ3JlYXRlcyBhIG5ldyBjaGFwdGVyIHdpdGggaW50ZXJhY3RpdmUgcHJvbXB0c1wiXG4gICAgfSk7XG4gIH1cblxuICBhc3luYyBuZXdNb2R1bGVGdW5jdGlvbihhcHA6IGFueSwgdHA6IGFueSwgeWVhcjogc3RyaW5nKSB7XG4gICAgLy8gUHJvbXB0IHVzZXIgZm9yIG1vZHVsZSBkZXRhaWxzXG4gICAgY29uc3QgbW9kdWxlTnVtYmVyID0gYXdhaXQgdHAuc3lzdGVtLnByb21wdChcIk1vZHVsZSBOdW1iZXIgKG9wdGlvbmFsKVwiLCBcIlwiKTtcbiAgICBjb25zdCB3ZWVrTnVtYmVyID0gYXdhaXQgdHAuc3lzdGVtLnByb21wdChcIldlZWsgTnVtYmVyIChvcHRpb25hbClcIiwgXCJcIik7XG4gICAgY29uc3QgY291cnNlID0gYXdhaXQgdHAuc3lzdGVtLnN1Z2dlc3RlcihcbiAgICAgICgpID0+IGFwcC52YXVsdC5nZXRNYXJrZG93bkZpbGVzKCkuZmlsdGVyKChmOiBhbnkpID0+IGYucGF0aC5pbmNsdWRlcyhcIkNvdXJzZXNcIikpLm1hcCgoZjogYW55KSA9PiBmLmJhc2VuYW1lKSxcbiAgICAgIGFwcC52YXVsdC5nZXRNYXJrZG93bkZpbGVzKCkuZmlsdGVyKChmOiBhbnkpID0+IGYucGF0aC5pbmNsdWRlcyhcIkNvdXJzZXNcIikpXG4gICAgKTtcbiAgICBjb25zdCBjb3Vyc2VJZCA9IGNvdXJzZSA/IGNvdXJzZS5zcGxpdChcIiAtIFwiKVswXSB8fCBjb3Vyc2UgOiBcIlwiO1xuICAgIGNvbnN0IGRpc2NpcGxpbmUgPSBjb3Vyc2UgPyBjb3Vyc2Uuc3BsaXQoXCIgLSBcIilbMF0/LnN1YnN0cmluZygwLCAzKSB8fCBcIkdFTlwiIDogXCJHRU5cIjtcbiAgICBjb25zdCBkYXlPcHRpb25zID0gW1wiTW9uZGF5XCIsIFwiVHVlc2RheVwiLCBcIldlZG5lc2RheVwiLCBcIlRodXJzZGF5XCIsIFwiRnJpZGF5XCIsIFwiU2F0dXJkYXlcIiwgXCJTdW5kYXlcIl07XG4gICAgY29uc3QgZGF5T2ZXZWVrID0gYXdhaXQgdHAuc3lzdGVtLnN1Z2dlc3RlcihkYXlPcHRpb25zLCBkYXlPcHRpb25zLCBcIkRheSBvZiBXZWVrXCIpO1xuXG4gICAgcmV0dXJuIHtcbiAgICAgIHNlYXNvbjogXCJGYWxsXCIsIC8vIFRoaXMgd291bGQgbm9ybWFsbHkgYmUgZHluYW1pY2FsbHkgZGV0ZXJtaW5lZFxuICAgICAgbW9kdWxlTnVtYmVyOiBtb2R1bGVOdW1iZXIgfHwgbnVsbCxcbiAgICAgIHdlZWtOdW1iZXI6IHdlZWtOdW1iZXIgfHwgbnVsbCxcbiAgICAgIGNvdXJzZSxcbiAgICAgIGNvdXJzZUlkLFxuICAgICAgZGlzY2lwbGluZSxcbiAgICAgIGRheU9mV2Vla1xuICAgIH07XG4gIH1cblxuICBhc3luYyBuZXdDaGFwdGVyRnVuY3Rpb24odHA6IGFueSkge1xuICAgIGNvbnN0IGNoYXB0ZXJOdW1iZXIgPSBhd2FpdCB0cC5zeXN0ZW0ucHJvbXB0KFwiQ2hhcHRlciBOdW1iZXJcIiwgXCJcIik7XG4gICAgY29uc3QgY291cnNlID0gYXdhaXQgdHAuc3lzdGVtLnN1Z2dlc3RlcihcbiAgICAgICgpID0+IHRwLmFwcC52YXVsdC5nZXRNYXJrZG93bkZpbGVzKCkuZmlsdGVyKChmOiBhbnkpID0+IGYucGF0aC5pbmNsdWRlcyhcIkNvdXJzZXNcIikpLm1hcCgoZjogYW55KSA9PiBmLmJhc2VuYW1lKSxcbiAgICAgIHRwLmFwcC52YXVsdC5nZXRNYXJrZG93bkZpbGVzKCkuZmlsdGVyKChmOiBhbnkpID0+IGYucGF0aC5pbmNsdWRlcyhcIkNvdXJzZXNcIikpXG4gICAgKTtcbiAgICBjb25zdCBjb3Vyc2VJZCA9IGNvdXJzZSA/IGNvdXJzZS5zcGxpdChcIiAtIFwiKVswXSB8fCBjb3Vyc2UgOiBcIlwiO1xuICAgIGNvbnN0IGRpc2NpcGxpbmUgPSBjb3Vyc2UgPyBjb3Vyc2Uuc3BsaXQoXCIgLSBcIilbMF0/LnN1YnN0cmluZygwLCAzKSB8fCBcIkdFTlwiIDogXCJHRU5cIjtcbiAgICBjb25zdCB0ZXh0T3B0aW9ucyA9IHRwLmFwcC52YXVsdC5nZXRGaWxlcygpLmZpbHRlcigoZjogYW55KSA9PiBmLmV4dGVuc2lvbiA9PT0gXCJwZGZcIikubWFwKChmOiBhbnkpID0+IGYuYmFzZW5hbWUpO1xuICAgIGNvbnN0IHRleHQgPSBhd2FpdCB0cC5zeXN0ZW0uc3VnZ2VzdGVyKHRleHRPcHRpb25zLCB0ZXh0T3B0aW9ucywgXCJUZXh0Ym9va1wiKTtcblxuICAgIHJldHVybiB7XG4gICAgICBjaGFwdGVyTnVtYmVyOiBjaGFwdGVyTnVtYmVyIHx8IFwiXCIsXG4gICAgICBjb3Vyc2UsXG4gICAgICBjb3Vyc2VJZCxcbiAgICAgIGRpc2NpcGxpbmUsXG4gICAgICB0ZXh0XG4gICAgfTtcbiAgfVxuXG4gIGFzeW5jIGxvYWRTZXR0aW5ncygpIHtcbiAgICB0aGlzLnNldHRpbmdzID0gT2JqZWN0LmFzc2lnbih7fSwgREVGQVVMVF9TRVRUSU5HUywgYXdhaXQgdGhpcy5sb2FkRGF0YSgpKVxuICB9XG5cbiAgYXN5bmMgc2F2ZVNldHRpbmdzKCkge1xuICAgIGF3YWl0IHRoaXMuc2F2ZURhdGEodGhpcy5zZXR0aW5ncylcbiAgfVxufVxuIiwgImltcG9ydCB7IEFwcCwgUGx1Z2luU2V0dGluZ1RhYiwgU2V0dGluZyB9IGZyb20gJ29ic2lkaWFuJztcbmltcG9ydCBUdWNrZXJzVG9vbHNQbHVnaW4gZnJvbSAnLi9tYWluJztcbmltcG9ydCB7IHZhbGlkYXRlRGF0ZSB9IGZyb20gJy4vdXRpbHMnO1xuXG5leHBvcnQgaW50ZXJmYWNlIFR1Y2tlcnNUb29sc1NldHRpbmdzIHtcbiAgYmFzZURpcmVjdG9yeTogc3RyaW5nO1xuICBzZW1lc3RlclN0YXJ0RGF0ZTogc3RyaW5nO1xuICBzZW1lc3RlckVuZERhdGU6IHN0cmluZztcbiAgc2Nob29sTmFtZTogc3RyaW5nO1xuICBzY2hvb2xBYmJyZXZpYXRpb246IHN0cmluZztcbiAgdGVtcGxhdGVGb2xkZXI6IHN0cmluZztcbiAgdXNlRW5oYW5jZWRNZXRhZGF0YTogYm9vbGVhbjtcbn1cblxuZXhwb3J0IGNvbnN0IERFRkFVTFRfU0VUVElOR1M6IFR1Y2tlcnNUb29sc1NldHRpbmdzID0ge1xuICBiYXNlRGlyZWN0b3J5OiAnLycsXG4gIHNlbWVzdGVyU3RhcnREYXRlOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc3BsaXQoJ1QnKVswXSxcbiAgc2VtZXN0ZXJFbmREYXRlOiBuZXcgRGF0ZShuZXcgRGF0ZSgpLnNldE1vbnRoKG5ldyBEYXRlKCkuZ2V0TW9udGgoKSArIDQpKS50b0lTT1N0cmluZygpLnNwbGl0KCdUJylbMF0sXG4gIHNjaG9vbE5hbWU6ICdVbml2ZXJzaXR5JyxcbiAgc2Nob29sQWJicmV2aWF0aW9uOiAnVScsXG4gIHRlbXBsYXRlRm9sZGVyOiAnVHVja2VycyBUb29scycsXG4gIHVzZUVuaGFuY2VkTWV0YWRhdGE6IGZhbHNlXG59XG5cbmV4cG9ydCBjbGFzcyBUdWNrZXJzVG9vbHNTZXR0aW5nVGFiIGV4dGVuZHMgUGx1Z2luU2V0dGluZ1RhYiB7XG4gIHBsdWdpbjogVHVja2Vyc1Rvb2xzUGx1Z2luO1xuXG4gIGNvbnN0cnVjdG9yKGFwcDogQXBwLCBwbHVnaW46IFR1Y2tlcnNUb29sc1BsdWdpbikge1xuICAgIHN1cGVyKGFwcCwgcGx1Z2luKTtcbiAgICB0aGlzLnBsdWdpbiA9IHBsdWdpbjtcbiAgfVxuXG4gIGRpc3BsYXkoKTogdm9pZCB7XG4gICAgY29uc3QgeyBjb250YWluZXJFbCB9ID0gdGhpcztcblxuICAgIGNvbnRhaW5lckVsLmVtcHR5KCk7XG5cbiAgICBjb250YWluZXJFbC5jcmVhdGVFbCgnaDInLCB7IHRleHQ6ICdUdWNrZXJzIFRvb2xzIFNldHRpbmdzJyB9KTtcblxuICAgIG5ldyBTZXR0aW5nKGNvbnRhaW5lckVsKVxuICAgICAgLnNldE5hbWUoJ0Jhc2UgRGlyZWN0b3J5JylcbiAgICAgIC5zZXREZXNjKCdSb290IGRpcmVjdG9yeSBmb3IgY291cnNlIGNvbnRlbnQgb3JnYW5pemF0aW9uJylcbiAgICAgIC5hZGRUZXh0KHRleHQgPT4gdGV4dFxuICAgICAgICAuc2V0UGxhY2Vob2xkZXIoJy8nKVxuICAgICAgICAuc2V0VmFsdWUodGhpcy5wbHVnaW4uc2V0dGluZ3MuYmFzZURpcmVjdG9yeSlcbiAgICAgICAgLm9uQ2hhbmdlKGFzeW5jICh2YWx1ZSkgPT4ge1xuICAgICAgICAgIHRoaXMucGx1Z2luLnNldHRpbmdzLmJhc2VEaXJlY3RvcnkgPSB2YWx1ZTtcbiAgICAgICAgICBhd2FpdCB0aGlzLnBsdWdpbi5zYXZlU2V0dGluZ3MoKTtcbiAgICAgICAgfSkpO1xuXG4gICAgY29uc3Qgc3RhcnREYXRlU2V0dGluZyA9IG5ldyBTZXR0aW5nKGNvbnRhaW5lckVsKVxuICAgICAgLnNldE5hbWUoJ1NlbWVzdGVyIFN0YXJ0IERhdGUnKVxuICAgICAgLnNldERlc2MoJ1N0YXJ0IGRhdGUgZm9yIHRoZSBjdXJyZW50IHNlbWVzdGVyJylcbiAgICAgIC5hZGRUZXh0KHRleHQgPT4gdGV4dFxuICAgICAgICAuc2V0UGxhY2Vob2xkZXIoJ1lZWVktTU0tREQnKVxuICAgICAgICAuc2V0VmFsdWUodGhpcy5wbHVnaW4uc2V0dGluZ3Muc2VtZXN0ZXJTdGFydERhdGUpXG4gICAgICAgIC5vbkNoYW5nZShhc3luYyAodmFsdWUpID0+IHtcbiAgICAgICAgICBpZiAodmFsdWUgJiYgIXZhbGlkYXRlRGF0ZSh2YWx1ZSkpIHtcbiAgICAgICAgICAgIHN0YXJ0RGF0ZVNldHRpbmcuc2V0RGVzYygnU3RhcnQgZGF0ZSBmb3IgdGhlIGN1cnJlbnQgc2VtZXN0ZXIgKEludmFsaWQgZGF0ZSBmb3JtYXQpJyk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHN0YXJ0RGF0ZVNldHRpbmcuc2V0RGVzYygnU3RhcnQgZGF0ZSBmb3IgdGhlIGN1cnJlbnQgc2VtZXN0ZXInKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgdGhpcy5wbHVnaW4uc2V0dGluZ3Muc2VtZXN0ZXJTdGFydERhdGUgPSB2YWx1ZTtcbiAgICAgICAgICBhd2FpdCB0aGlzLnBsdWdpbi5zYXZlU2V0dGluZ3MoKTtcbiAgICAgICAgfSkpO1xuXG4gICAgY29uc3QgZW5kRGF0ZVNldHRpbmcgPSBuZXcgU2V0dGluZyhjb250YWluZXJFbClcbiAgICAgIC5zZXROYW1lKCdTZW1lc3RlciBFbmQgRGF0ZScpXG4gICAgICAuc2V0RGVzYygnRW5kIGRhdGUgZm9yIHRoZSBjdXJyZW50IHNlbWVzdGVyJylcbiAgICAgIC5hZGRUZXh0KHRleHQgPT4gdGV4dFxuICAgICAgICAuc2V0UGxhY2Vob2xkZXIoJ1lZWVktTU0tREQnKVxuICAgICAgICAuc2V0VmFsdWUodGhpcy5wbHVnaW4uc2V0dGluZ3Muc2VtZXN0ZXJFbmREYXRlKVxuICAgICAgICAub25DaGFuZ2UoYXN5bmMgKHZhbHVlKSA9PiB7XG4gICAgICAgICAgaWYgKHZhbHVlICYmICF2YWxpZGF0ZURhdGUodmFsdWUpKSB7XG4gICAgICAgICAgICBlbmREYXRlU2V0dGluZy5zZXREZXNjKCdFbmQgZGF0ZSBmb3IgdGhlIGN1cnJlbnQgc2VtZXN0ZXIgKEludmFsaWQgZGF0ZSBmb3JtYXQpJyk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGVuZERhdGVTZXR0aW5nLnNldERlc2MoJ0VuZCBkYXRlIGZvciB0aGUgY3VycmVudCBzZW1lc3RlcicpO1xuICAgICAgICAgIH1cbiAgICAgICAgICB0aGlzLnBsdWdpbi5zZXR0aW5ncy5zZW1lc3RlckVuZERhdGUgPSB2YWx1ZTtcbiAgICAgICAgICBhd2FpdCB0aGlzLnBsdWdpbi5zYXZlU2V0dGluZ3MoKTtcbiAgICAgICAgfSkpO1xuXG4gICAgbmV3IFNldHRpbmcoY29udGFpbmVyRWwpXG4gICAgICAuc2V0TmFtZSgnU2Nob29sIE5hbWUnKVxuICAgICAgLnNldERlc2MoJ05hbWUgb2YgeW91ciBpbnN0aXR1dGlvbicpXG4gICAgICAuYWRkVGV4dCh0ZXh0ID0+IHRleHRcbiAgICAgICAgLnNldFBsYWNlaG9sZGVyKCdVbml2ZXJzaXR5JylcbiAgICAgICAgLnNldFZhbHVlKHRoaXMucGx1Z2luLnNldHRpbmdzLnNjaG9vbE5hbWUpXG4gICAgICAgIC5vbkNoYW5nZShhc3luYyAodmFsdWUpID0+IHtcbiAgICAgICAgICB0aGlzLnBsdWdpbi5zZXR0aW5ncy5zY2hvb2xOYW1lID0gdmFsdWU7XG4gICAgICAgICAgYXdhaXQgdGhpcy5wbHVnaW4uc2F2ZVNldHRpbmdzKCk7XG4gICAgICAgIH0pKTtcblxuICAgIG5ldyBTZXR0aW5nKGNvbnRhaW5lckVsKVxuICAgICAgLnNldE5hbWUoJ1NjaG9vbCBBYmJyZXZpYXRpb24nKVxuICAgICAgLnNldERlc2MoJ0FiYnJldmlhdGlvbiBmb3IgeW91ciBpbnN0aXR1dGlvbicpXG4gICAgICAuYWRkVGV4dCh0ZXh0ID0+IHRleHRcbiAgICAgICAgLnNldFBsYWNlaG9sZGVyKCdVJylcbiAgICAgICAgLnNldFZhbHVlKHRoaXMucGx1Z2luLnNldHRpbmdzLnNjaG9vbEFiYnJldmlhdGlvbilcbiAgICAgICAgLm9uQ2hhbmdlKGFzeW5jICh2YWx1ZSkgPT4ge1xuICAgICAgICAgIHRoaXMucGx1Z2luLnNldHRpbmdzLnNjaG9vbEFiYnJldmlhdGlvbiA9IHZhbHVlO1xuICAgICAgICAgIGF3YWl0IHRoaXMucGx1Z2luLnNhdmVTZXR0aW5ncygpO1xuICAgICAgICB9KSk7XG5cbiAgICBuZXcgU2V0dGluZyhjb250YWluZXJFbClcbiAgICAgIC5zZXROYW1lKCdUZW1wbGF0ZSBGb2xkZXInKVxuICAgICAgLnNldERlc2MoJ1N1YmZvbGRlciB3aXRoaW4geW91ciBUZW1wbGF0ZXIgdGVtcGxhdGUgZm9sZGVyIGZvciBUdWNrZXJzIFRvb2xzIHRlbXBsYXRlcycpXG4gICAgICAuYWRkVGV4dCh0ZXh0ID0+IHRleHRcbiAgICAgICAgLnNldFBsYWNlaG9sZGVyKCdUdWNrZXJzIFRvb2xzJylcbiAgICAgICAgLnNldFZhbHVlKHRoaXMucGx1Z2luLnNldHRpbmdzLnRlbXBsYXRlRm9sZGVyKVxuICAgICAgICAub25DaGFuZ2UoYXN5bmMgKHZhbHVlKSA9PiB7XG4gICAgICAgICAgdGhpcy5wbHVnaW4uc2V0dGluZ3MudGVtcGxhdGVGb2xkZXIgPSB2YWx1ZTtcbiAgICAgICAgICBhd2FpdCB0aGlzLnBsdWdpbi5zYXZlU2V0dGluZ3MoKTtcbiAgICAgICAgfSkpO1xuXG4gICAgbmV3IFNldHRpbmcoY29udGFpbmVyRWwpXG4gICAgICAuc2V0TmFtZSgnVXNlIEVuaGFuY2VkIE1ldGFkYXRhJylcbiAgICAgIC5zZXREZXNjKCdFbmFibGUgZW5oYW5jZWQgbWV0YWRhdGEgZmllbGRzIGZvciBuZXcgbm90ZXMgKGV4aXN0aW5nIG5vdGVzIHJlbWFpbiB1bmNoYW5nZWQpJylcbiAgICAgIC5hZGRUb2dnbGUodG9nZ2xlID0+IHRvZ2dsZVxuICAgICAgICAuc2V0VmFsdWUodGhpcy5wbHVnaW4uc2V0dGluZ3MudXNlRW5oYW5jZWRNZXRhZGF0YSlcbiAgICAgICAgLm9uQ2hhbmdlKGFzeW5jICh2YWx1ZSkgPT4ge1xuICAgICAgICAgIHRoaXMucGx1Z2luLnNldHRpbmdzLnVzZUVuaGFuY2VkTWV0YWRhdGEgPSB2YWx1ZTtcbiAgICAgICAgICBhd2FpdCB0aGlzLnBsdWdpbi5zYXZlU2V0dGluZ3MoKTtcbiAgICAgICAgfSkpO1xuICB9XG59IiwgIi8vIFV0aWxpdHkgZnVuY3Rpb25zIGZvciBUdWNrZXJzIFRvb2xzIHBsdWdpblxuXG5leHBvcnQgZnVuY3Rpb24gZm9ybWF0RGF0ZShkYXRlOiBEYXRlKTogc3RyaW5nIHtcbiAgcmV0dXJuIGRhdGUudG9JU09TdHJpbmcoKS5zcGxpdChcIlRcIilbMF1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGFkZERheXMoZGF0ZTogRGF0ZSwgZGF5czogbnVtYmVyKTogRGF0ZSB7XG4gIGNvbnN0IHJlc3VsdCA9IG5ldyBEYXRlKGRhdGUpXG4gIHJlc3VsdC5zZXREYXRlKHJlc3VsdC5nZXREYXRlKCkgKyBkYXlzKVxuICByZXR1cm4gcmVzdWx0XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBpc0JldHdlZW4oZGF0ZTogRGF0ZSwgc3RhcnQ6IERhdGUsIGVuZDogRGF0ZSk6IGJvb2xlYW4ge1xuICByZXR1cm4gZGF0ZSA+PSBzdGFydCAmJiBkYXRlIDw9IGVuZFxufVxuXG5leHBvcnQgZnVuY3Rpb24gc2x1Z2lmeSh0ZXh0OiBzdHJpbmcpOiBzdHJpbmcge1xuICByZXR1cm4gdGV4dFxuICAgIC50b0xvd2VyQ2FzZSgpXG4gICAgLnRyaW0oKVxuICAgIC5ub3JtYWxpemUoXCJORkRcIilcbiAgICAucmVwbGFjZSgvW1xcdTAzMDAtXFx1MDM2Zl0vZywgXCJcIilcbiAgICAucmVwbGFjZSgvW15hLXowLTlcXHMtXS9nLCBcIlwiKVxuICAgIC5yZXBsYWNlKC9bXFxzLV0rL2csIFwiLVwiKVxuICAgIC5yZXBsYWNlKC9eLSt8LSskL2csIFwiXCIpXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBnZXRDb3Vyc2VJZEZyb21QYXRoKHBhdGg6IHN0cmluZyk6IHN0cmluZyB8IG51bGwge1xuICAvLyBFeHRyYWN0IGNvdXJzZSBJRCBmcm9tIHBhdGggbGlrZSBcIjIwMjUvRmFsbC9QU0ktMTAxLy4uLlwiIG9yIGZpbGVuYW1lIFwiUFNJLTEwMSAtIEludHJvIHRvIFBzeWNoLm1kXCJcbiAgY29uc3QgcGFydHMgPSBwYXRoLnNwbGl0KFwiL1wiKVxuICBmb3IgKGNvbnN0IHBhcnQgb2YgcGFydHMpIHtcbiAgICAvLyBMb29rIGZvciBjb3Vyc2UgSUQgcGF0dGVybiBpbiBlYWNoIHBhdGggc2VnbWVudFxuICAgIGNvbnN0IG1hdGNoID0gcGFydC5tYXRjaCgvKFtBLVpdezIsNH0tXFxkezN9KS8pXG4gICAgaWYgKG1hdGNoKSB7XG4gICAgICByZXR1cm4gbWF0Y2hbMV1cbiAgICB9XG4gIH1cbiAgcmV0dXJuIG51bGxcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHZhbGlkYXRlRGF0ZShkYXRlU3RyaW5nOiBzdHJpbmcpOiBib29sZWFuIHtcbiAgY29uc3QgcmVnZXggPSAvXlxcZHs0fS1cXGR7Mn0tXFxkezJ9JC9cbiAgaWYgKCFkYXRlU3RyaW5nLm1hdGNoKHJlZ2V4KSkgcmV0dXJuIGZhbHNlXG5cbiAgY29uc3QgZGF0ZSA9IG5ldyBEYXRlKGRhdGVTdHJpbmcpXG4gIGNvbnN0IHRpbWVzdGFtcCA9IGRhdGUuZ2V0VGltZSgpXG5cbiAgaWYgKHR5cGVvZiB0aW1lc3RhbXAgIT09IFwibnVtYmVyXCIgfHwgaXNOYU4odGltZXN0YW1wKSkgcmV0dXJuIGZhbHNlXG5cbiAgcmV0dXJuIGRhdGVTdHJpbmcgPT09IGRhdGUudG9JU09TdHJpbmcoKS5zcGxpdChcIlRcIilbMF1cbn1cbiIsICJpbXBvcnQgeyBBcHAsIE5vdGljZSB9IGZyb20gXCJvYnNpZGlhblwiXG5pbXBvcnQgeyBUdWNrZXJzVG9vbHNTZXR0aW5ncyB9IGZyb20gXCIuL3NldHRpbmdzXCJcblxuaW50ZXJmYWNlIFRlbXBsYXRlTWFuaWZlc3Qge1xuICB2ZXJzaW9uOiBzdHJpbmdcbiAgdGVtcGxhdGVzOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+XG4gIHBsdWdpbl92ZXJzaW9uOiBzdHJpbmdcbiAgcmVsZWFzZV9ub3Rlczogc3RyaW5nXG59XG5cbmV4cG9ydCBjbGFzcyBUZW1wbGF0ZU1hbmFnZXIge1xuICBhcHA6IEFwcFxuICBzZXR0aW5nczogVHVja2Vyc1Rvb2xzU2V0dGluZ3NcbiAgbWFuaWZlc3Q6IFRlbXBsYXRlTWFuaWZlc3RcblxuICBjb25zdHJ1Y3RvcihhcHA6IEFwcCwgc2V0dGluZ3M6IFR1Y2tlcnNUb29sc1NldHRpbmdzKSB7XG4gICAgdGhpcy5hcHAgPSBhcHBcbiAgICB0aGlzLnNldHRpbmdzID0gc2V0dGluZ3NcbiAgICB0aGlzLm1hbmlmZXN0ID0ge1xuICAgICAgdmVyc2lvbjogXCIxLjAuMFwiLFxuICAgICAgdGVtcGxhdGVzOiB7XG4gICAgICAgIFwiQ291cnNlcy9DcmVhdGUgQ291cnNlIEhvbWVwYWdlLm1kXCI6IFwiMS4wLjBcIixcbiAgICAgICAgXCJDb3Vyc2VzL0NvdXJzZSBJbmRleC5tZFwiOiBcIjEuMC4wXCIsXG4gICAgICAgIFwiTW9kdWxlcy9DcmVhdGUgTW9kdWxlLm1kXCI6IFwiMS4wLjBcIixcbiAgICAgICAgXCJDaGFwdGVycy9DcmVhdGUgQ2hhcHRlci5tZFwiOiBcIjEuMC4wXCIsXG4gICAgICAgIFwiQXNzaWdubWVudHMvQ3JlYXRlIEFzc2lnbm1lbnQubWRcIjogXCIxLjAuMFwiLFxuICAgICAgICBcIkRhaWx5L0RhaWx5IE5vdGUubWRcIjogXCIxLjAuMFwiLFxuICAgICAgICBcIlV0aWxpdGllcy9Wb2NhYnVsYXJ5IEVudHJ5Lm1kXCI6IFwiMS4wLjBcIixcbiAgICAgICAgXCJVdGlsaXRpZXMvRHVlIERhdGUgRW50cnkubWRcIjogXCIxLjAuMFwiXG4gICAgICB9LFxuICAgICAgcGx1Z2luX3ZlcnNpb246IFwiMS4wLjBcIixcbiAgICAgIHJlbGVhc2Vfbm90ZXM6IFwiSW5pdGlhbCByZWxlYXNlIG9mIFR1Y2tlcnMgVG9vbHMgdGVtcGxhdGVzXCJcbiAgICB9XG4gIH1cblxuICBhc3luYyBpbnN0YWxsVGVtcGxhdGVzKCkge1xuICAgIHRyeSB7XG4gICAgICAvLyBHZXQgVGVtcGxhdGVyIHBsdWdpbiBzZXR0aW5ncyB0byBmaW5kIHRlbXBsYXRlIGZvbGRlclxuICAgICAgY29uc3QgdGVtcGxhdGVyUGx1Z2luID0gdGhpcy5nZXRUZW1wbGF0ZXJQbHVnaW4oKVxuICAgICAgaWYgKCF0ZW1wbGF0ZXJQbHVnaW4pIHtcbiAgICAgICAgbmV3IE5vdGljZShcbiAgICAgICAgICBcIlRlbXBsYXRlciBwbHVnaW4gbm90IGZvdW5kLiBQbGVhc2UgaW5zdGFsbCBhbmQgZW5hYmxlIHRoZSBUZW1wbGF0ZXIgcGx1Z2luIGZpcnN0LlwiXG4gICAgICAgIClcbiAgICAgICAgY29uc29sZS5lcnJvcihcbiAgICAgICAgICBcIlRlbXBsYXRlciBwbHVnaW4gbm90IGZvdW5kLiBQbGVhc2UgaW5zdGFsbCBhbmQgZW5hYmxlIHRoZSBUZW1wbGF0ZXIgcGx1Z2luIGZpcnN0LlwiXG4gICAgICAgIClcbiAgICAgICAgcmV0dXJuXG4gICAgICB9XG5cbiAgICAgIGNvbnN0IHRlbXBsYXRlRm9sZGVyUGF0aCA9IHRoaXMuZ2V0VGVtcGxhdGVGb2xkZXJQYXRoKHRlbXBsYXRlclBsdWdpbilcbiAgICAgIGlmICghdGVtcGxhdGVGb2xkZXJQYXRoKSB7XG4gICAgICAgIG5ldyBOb3RpY2UoXG4gICAgICAgICAgXCJUZW1wbGF0ZSBmb2xkZXIgbm90IGNvbmZpZ3VyZWQgaW4gVGVtcGxhdGVyIHNldHRpbmdzLiBQbGVhc2UgY29uZmlndXJlIGl0IGluIFRlbXBsYXRlciBzZXR0aW5ncyBmaXJzdC5cIlxuICAgICAgICApXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXG4gICAgICAgICAgXCJUZW1wbGF0ZSBmb2xkZXIgbm90IGNvbmZpZ3VyZWQgaW4gVGVtcGxhdGVyIHNldHRpbmdzLiBQbGVhc2UgY29uZmlndXJlIGl0IGluIFRlbXBsYXRlciBzZXR0aW5ncyBmaXJzdC5cIlxuICAgICAgICApXG4gICAgICAgIHJldHVyblxuICAgICAgfVxuXG4gICAgICBjb25zdCBmdWxsVGVtcGxhdGVQYXRoID0gYCR7dGVtcGxhdGVGb2xkZXJQYXRofS8ke3RoaXMuc2V0dGluZ3MudGVtcGxhdGVGb2xkZXJ9YFxuXG4gICAgICAvLyBDcmVhdGUgdGhlIG1haW4gdGVtcGxhdGUgZm9sZGVyIGlmIGl0IGRvZXNuJ3QgZXhpc3RcbiAgICAgIHRyeSB7XG4gICAgICAgIGF3YWl0IHRoaXMuYXBwLnZhdWx0LmNyZWF0ZUZvbGRlcihmdWxsVGVtcGxhdGVQYXRoKVxuICAgICAgICBjb25zb2xlLmxvZyhgQ3JlYXRlZCB0ZW1wbGF0ZSBmb2xkZXI6ICR7ZnVsbFRlbXBsYXRlUGF0aH1gKVxuICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAvLyBGb2xkZXIgbWlnaHQgYWxyZWFkeSBleGlzdCwgd2hpY2ggaXMgZmluZVxuICAgICAgICBjb25zb2xlLmxvZyhcbiAgICAgICAgICBgVGVtcGxhdGUgZm9sZGVyIGFscmVhZHkgZXhpc3RzIG9yIGNyZWF0ZWQ6ICR7ZnVsbFRlbXBsYXRlUGF0aH1gXG4gICAgICAgIClcbiAgICAgIH1cblxuICAgICAgLy8gQ3JlYXRlIHN1YmRpcmVjdG9yaWVzXG4gICAgICBjb25zdCBzdWJkaXJzID0gW1xuICAgICAgICBcIkNvdXJzZXNcIixcbiAgICAgICAgXCJNb2R1bGVzXCIsXG4gICAgICAgIFwiQ2hhcHRlcnNcIixcbiAgICAgICAgXCJBc3NpZ25tZW50c1wiLFxuICAgICAgICBcIkRhaWx5XCIsXG4gICAgICAgIFwiVXRpbGl0aWVzXCJcbiAgICAgIF1cbiAgICAgIGZvciAoY29uc3Qgc3ViZGlyIG9mIHN1YmRpcnMpIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBjb25zdCBzdWJQYXRoID0gYCR7ZnVsbFRlbXBsYXRlUGF0aH0vJHtzdWJkaXJ9YFxuICAgICAgICAgIGF3YWl0IHRoaXMuYXBwLnZhdWx0LmNyZWF0ZUZvbGRlcihzdWJQYXRoKVxuICAgICAgICAgIGNvbnNvbGUubG9nKGBDcmVhdGVkIHN1YmRpcmVjdG9yeTogJHtzdWJQYXRofWApXG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAvLyBGb2xkZXIgbWlnaHQgYWxyZWFkeSBleGlzdCwgd2hpY2ggaXMgZmluZVxuICAgICAgICAgIGNvbnNvbGUubG9nKFxuICAgICAgICAgICAgYFN1YmRpcmVjdG9yeSBhbHJlYWR5IGV4aXN0czogJHtmdWxsVGVtcGxhdGVQYXRofS8ke3N1YmRpcn1gXG4gICAgICAgICAgKVxuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIC8vIEluc3RhbGwgdGVtcGxhdGVzXG4gICAgICBhd2FpdCB0aGlzLmluc3RhbGxDb3Vyc2VUZW1wbGF0ZXMoZnVsbFRlbXBsYXRlUGF0aClcbiAgICAgIGF3YWl0IHRoaXMuaW5zdGFsbE1vZHVsZVRlbXBsYXRlcyhmdWxsVGVtcGxhdGVQYXRoKVxuICAgICAgYXdhaXQgdGhpcy5pbnN0YWxsQ2hhcHRlclRlbXBsYXRlcyhmdWxsVGVtcGxhdGVQYXRoKVxuICAgICAgYXdhaXQgdGhpcy5pbnN0YWxsQXNzaWdubWVudFRlbXBsYXRlcyhmdWxsVGVtcGxhdGVQYXRoKVxuICAgICAgYXdhaXQgdGhpcy5pbnN0YWxsRGFpbHlUZW1wbGF0ZXMoZnVsbFRlbXBsYXRlUGF0aClcbiAgICAgIGF3YWl0IHRoaXMuaW5zdGFsbFV0aWxpdHlUZW1wbGF0ZXMoZnVsbFRlbXBsYXRlUGF0aClcblxuICAgICAgLy8gQ3JlYXRlIFJFQURNRVxuICAgICAgYXdhaXQgdGhpcy5jcmVhdGVSRUFETUUoZnVsbFRlbXBsYXRlUGF0aClcblxuICAgICAgLy8gQ3JlYXRlIHRlbXBsYXRlIG1hbmlmZXN0XG4gICAgICBhd2FpdCB0aGlzLmNyZWF0ZVRlbXBsYXRlTWFuaWZlc3QoZnVsbFRlbXBsYXRlUGF0aClcblxuICAgICAgbmV3IE5vdGljZShcIlR1Y2tlcnMgVG9vbHMgdGVtcGxhdGVzIGluc3RhbGxlZCBzdWNjZXNzZnVsbHkhXCIpXG4gICAgICBjb25zb2xlLmxvZyhcIlR1Y2tlcnMgVG9vbHMgdGVtcGxhdGVzIGluc3RhbGxlZCBzdWNjZXNzZnVsbHlcIilcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGluc3RhbGxpbmcgdGVtcGxhdGVzOlwiLCBlcnJvcilcbiAgICAgIG5ldyBOb3RpY2UoXCJFcnJvciBpbnN0YWxsaW5nIHRlbXBsYXRlcy4gQ2hlY2sgY29uc29sZSBmb3IgZGV0YWlscy5cIilcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGdldFRlbXBsYXRlclBsdWdpbigpOiBhbnkge1xuICAgIC8vIFRyeSBtdWx0aXBsZSB3YXlzIHRvIGFjY2VzcyB0aGUgVGVtcGxhdGVyIHBsdWdpblxuICAgIGNvbnN0IHBvc3NpYmxlUGF0aHMgPSBbXG4gICAgICAodGhpcy5hcHAgYXMgYW55KS5wbHVnaW5zLnBsdWdpbnNbXCJ0ZW1wbGF0ZXItb2JzaWRpYW5cIl0sXG4gICAgICAodGhpcy5hcHAgYXMgYW55KS5wbHVnaW5zLnBsdWdpbnNbXCJ0ZW1wbGF0ZXJcIl0sXG4gICAgICAodGhpcy5hcHAgYXMgYW55KS5wbHVnaW5zLmdldFBsdWdpbihcInRlbXBsYXRlci1vYnNpZGlhblwiKSxcbiAgICAgICh0aGlzLmFwcCBhcyBhbnkpLnBsdWdpbnMuZ2V0UGx1Z2luKFwidGVtcGxhdGVyXCIpXG4gICAgXVxuXG4gICAgZm9yIChjb25zdCBwYXRoIG9mIHBvc3NpYmxlUGF0aHMpIHtcbiAgICAgIGlmIChwYXRoKSB7XG4gICAgICAgIHJldHVybiBwYXRoXG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIG51bGxcbiAgfVxuXG4gIHByaXZhdGUgZ2V0VGVtcGxhdGVGb2xkZXJQYXRoKHRlbXBsYXRlclBsdWdpbjogYW55KTogc3RyaW5nIHwgbnVsbCB7XG4gICAgY29uc3Qgc2V0dGluZ3MgPSB0ZW1wbGF0ZXJQbHVnaW4uc2V0dGluZ3NcblxuICAgIGlmICghc2V0dGluZ3MpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJUZW1wbGF0ZXIgcGx1Z2luIGhhcyBubyBzZXR0aW5nc1wiKVxuICAgICAgcmV0dXJuIG51bGxcbiAgICB9XG5cbiAgICAvLyBUcnkgZGlmZmVyZW50IHBvc3NpYmxlIHByb3BlcnR5IG5hbWVzIGZvciB0ZW1wbGF0ZSBmb2xkZXJcbiAgICBjb25zdCBwb3NzaWJsZVBhdGhzID0gW1xuICAgICAgc2V0dGluZ3MudGVtcGxhdGVfZm9sZGVyLFxuICAgICAgc2V0dGluZ3MudGVtcGxhdGVGb2xkZXIsXG4gICAgICBzZXR0aW5ncy50ZW1wbGF0ZUZvbGRlclBhdGgsXG4gICAgICBzZXR0aW5ncy5mb2xkZXJcbiAgICBdXG5cbiAgICBmb3IgKGNvbnN0IHBhdGggb2YgcG9zc2libGVQYXRocykge1xuICAgICAgaWYgKHBhdGggJiYgdHlwZW9mIHBhdGggPT09IFwic3RyaW5nXCIpIHtcbiAgICAgICAgcmV0dXJuIHBhdGhcbiAgICAgIH1cbiAgICB9XG5cbiAgICBjb25zb2xlLmVycm9yKFxuICAgICAgXCJUZW1wbGF0ZSBmb2xkZXIgbm90IGZvdW5kIGluIFRlbXBsYXRlciBzZXR0aW5ncy4gQXZhaWxhYmxlIHNldHRpbmdzOlwiLFxuICAgICAgT2JqZWN0LmtleXMoc2V0dGluZ3MpXG4gICAgKVxuICAgIHJldHVybiBudWxsXG4gIH1cblxuICBhc3luYyBjcmVhdGVUZW1wbGF0ZU1hbmlmZXN0KGJhc2VQYXRoOiBzdHJpbmcpIHtcbiAgICBjb25zdCBtYW5pZmVzdFBhdGggPSBgJHtiYXNlUGF0aH0vdGVtcGxhdGUtbWFuaWZlc3QuanNvbmBcbiAgICBjb25zdCBtYW5pZmVzdENvbnRlbnQgPSBKU09OLnN0cmluZ2lmeSh0aGlzLm1hbmlmZXN0LCBudWxsLCAyKVxuXG4gICAgdHJ5IHtcbiAgICAgIC8vIENoZWNrIGlmIG1hbmlmZXN0IGFscmVhZHkgZXhpc3RzXG4gICAgICBjb25zdCBleGlzdGluZ01hbmlmZXN0ID1cbiAgICAgICAgdGhpcy5hcHAudmF1bHQuZ2V0QWJzdHJhY3RGaWxlQnlQYXRoKG1hbmlmZXN0UGF0aClcbiAgICAgIGlmIChleGlzdGluZ01hbmlmZXN0KSB7XG4gICAgICAgIC8vIFVwZGF0ZSB0aGUgZXhpc3RpbmcgbWFuaWZlc3RcbiAgICAgICAgY29uc3QgZmlsZSA9IGV4aXN0aW5nTWFuaWZlc3QgYXMgaW1wb3J0KFwib2JzaWRpYW5cIikuVEZpbGVcbiAgICAgICAgYXdhaXQgdGhpcy5hcHAudmF1bHQubW9kaWZ5KGZpbGUsIG1hbmlmZXN0Q29udGVudClcbiAgICAgICAgY29uc29sZS5sb2coYFVwZGF0ZWQgdGVtcGxhdGUgbWFuaWZlc3Q6ICR7bWFuaWZlc3RQYXRofWApXG4gICAgICAgIHJldHVyblxuICAgICAgfVxuXG4gICAgICAvLyBDcmVhdGUgdGhlIG1hbmlmZXN0IGZpbGVcbiAgICAgIGF3YWl0IHRoaXMuYXBwLnZhdWx0LmNyZWF0ZShtYW5pZmVzdFBhdGgsIG1hbmlmZXN0Q29udGVudClcbiAgICAgIGNvbnNvbGUubG9nKGBDcmVhdGVkIHRlbXBsYXRlIG1hbmlmZXN0OiAke21hbmlmZXN0UGF0aH1gKVxuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIG5ldyBOb3RpY2UoYEVycm9yIGNyZWF0aW5nIHRlbXBsYXRlIG1hbmlmZXN0ICR7bWFuaWZlc3RQYXRofWApXG4gICAgICBjb25zb2xlLmVycm9yKGBFcnJvciBjcmVhdGluZyB0ZW1wbGF0ZSBtYW5pZmVzdCAke21hbmlmZXN0UGF0aH06YCwgZSlcbiAgICB9XG4gIH1cblxuICBhc3luYyBjaGVja0ZvclRlbXBsYXRlVXBkYXRlcygpOiBQcm9taXNlPGJvb2xlYW4+IHtcbiAgICAvLyBUaGlzIHdvdWxkIGNoZWNrIGlmIHRlbXBsYXRlcyBuZWVkIHRvIGJlIHVwZGF0ZWRcbiAgICAvLyBGb3Igbm93LCB3ZSdsbCBqdXN0IHJldHVybiBmYWxzZVxuICAgIGNvbnNvbGUubG9nKFwiQ2hlY2tpbmcgZm9yIHRlbXBsYXRlIHVwZGF0ZXNcIilcbiAgICByZXR1cm4gZmFsc2VcbiAgfVxuXG4gIGFzeW5jIHVwZGF0ZVRlbXBsYXRlcygpIHtcbiAgICB0cnkge1xuICAgICAgLy8gVGhpcyB3b3VsZCB1cGRhdGUgZXhpc3RpbmcgdGVtcGxhdGVzXG4gICAgICBjb25zb2xlLmxvZyhcIlVwZGF0aW5nIHRlbXBsYXRlc1wiKVxuXG4gICAgICAvLyBHZXQgVGVtcGxhdGVyIHBsdWdpbiBzZXR0aW5ncyB0byBmaW5kIHRlbXBsYXRlIGZvbGRlclxuICAgICAgY29uc3QgdGVtcGxhdGVyUGx1Z2luID0gdGhpcy5nZXRUZW1wbGF0ZXJQbHVnaW4oKVxuICAgICAgaWYgKCF0ZW1wbGF0ZXJQbHVnaW4pIHtcbiAgICAgICAgbmV3IE5vdGljZShcbiAgICAgICAgICBcIlRlbXBsYXRlciBwbHVnaW4gbm90IGZvdW5kLiBQbGVhc2UgaW5zdGFsbCBhbmQgZW5hYmxlIHRoZSBUZW1wbGF0ZXIgcGx1Z2luIGZpcnN0LlwiXG4gICAgICAgIClcbiAgICAgICAgY29uc29sZS5lcnJvcihcbiAgICAgICAgICBcIlRlbXBsYXRlciBwbHVnaW4gbm90IGZvdW5kLiBQbGVhc2UgaW5zdGFsbCBhbmQgZW5hYmxlIHRoZSBUZW1wbGF0ZXIgcGx1Z2luIGZpcnN0LlwiXG4gICAgICAgIClcbiAgICAgICAgcmV0dXJuXG4gICAgICB9XG5cbiAgICAgIGNvbnN0IHRlbXBsYXRlRm9sZGVyUGF0aCA9IHRoaXMuZ2V0VGVtcGxhdGVGb2xkZXJQYXRoKHRlbXBsYXRlclBsdWdpbilcbiAgICAgIGlmICghdGVtcGxhdGVGb2xkZXJQYXRoKSB7XG4gICAgICAgIG5ldyBOb3RpY2UoXG4gICAgICAgICAgXCJUZW1wbGF0ZSBmb2xkZXIgbm90IGNvbmZpZ3VyZWQgaW4gVGVtcGxhdGVyIHNldHRpbmdzLiBQbGVhc2UgY29uZmlndXJlIGl0IGluIFRlbXBsYXRlciBzZXR0aW5ncyBmaXJzdC5cIlxuICAgICAgICApXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXG4gICAgICAgICAgXCJUZW1wbGF0ZSBmb2xkZXIgbm90IGNvbmZpZ3VyZWQgaW4gVGVtcGxhdGVyIHNldHRpbmdzLiBQbGVhc2UgY29uZmlndXJlIGl0IGluIFRlbXBsYXRlciBzZXR0aW5ncyBmaXJzdC5cIlxuICAgICAgICApXG4gICAgICAgIHJldHVyblxuICAgICAgfVxuXG4gICAgICBjb25zdCBmdWxsVGVtcGxhdGVQYXRoID0gYCR7dGVtcGxhdGVGb2xkZXJQYXRofS8ke3RoaXMuc2V0dGluZ3MudGVtcGxhdGVGb2xkZXJ9YFxuXG4gICAgICAvLyBVcGRhdGUgdGVtcGxhdGVzICh0aGlzIHdpbGwgb3ZlcndyaXRlIGV4aXN0aW5nIG9uZXMpXG4gICAgICBhd2FpdCB0aGlzLmluc3RhbGxDb3Vyc2VUZW1wbGF0ZXMoZnVsbFRlbXBsYXRlUGF0aClcbiAgICAgIGF3YWl0IHRoaXMuaW5zdGFsbE1vZHVsZVRlbXBsYXRlcyhmdWxsVGVtcGxhdGVQYXRoKVxuICAgICAgYXdhaXQgdGhpcy5pbnN0YWxsQ2hhcHRlclRlbXBsYXRlcyhmdWxsVGVtcGxhdGVQYXRoKVxuICAgICAgYXdhaXQgdGhpcy5pbnN0YWxsQXNzaWdubWVudFRlbXBsYXRlcyhmdWxsVGVtcGxhdGVQYXRoKVxuICAgICAgYXdhaXQgdGhpcy5pbnN0YWxsRGFpbHlUZW1wbGF0ZXMoZnVsbFRlbXBsYXRlUGF0aClcbiAgICAgIGF3YWl0IHRoaXMuaW5zdGFsbFV0aWxpdHlUZW1wbGF0ZXMoZnVsbFRlbXBsYXRlUGF0aClcblxuICAgICAgLy8gVXBkYXRlIFJFQURNRVxuICAgICAgYXdhaXQgdGhpcy5jcmVhdGVSRUFETUUoZnVsbFRlbXBsYXRlUGF0aClcblxuICAgICAgLy8gVXBkYXRlIHRlbXBsYXRlIG1hbmlmZXN0XG4gICAgICBhd2FpdCB0aGlzLmNyZWF0ZVRlbXBsYXRlTWFuaWZlc3QoZnVsbFRlbXBsYXRlUGF0aClcblxuICAgICAgbmV3IE5vdGljZShcIlR1Y2tlcnMgVG9vbHMgdGVtcGxhdGVzIHVwZGF0ZWQgc3VjY2Vzc2Z1bGx5IVwiKVxuICAgICAgY29uc29sZS5sb2coXCJUdWNrZXJzIFRvb2xzIHRlbXBsYXRlcyB1cGRhdGVkIHN1Y2Nlc3NmdWxseVwiKVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgdXBkYXRpbmcgdGVtcGxhdGVzOlwiLCBlcnJvcilcbiAgICAgIG5ldyBOb3RpY2UoXCJFcnJvciB1cGRhdGluZyB0ZW1wbGF0ZXMuIENoZWNrIGNvbnNvbGUgZm9yIGRldGFpbHMuXCIpXG4gICAgfVxuICB9XG5cbiAgYXN5bmMgaW5zdGFsbENvdXJzZVRlbXBsYXRlcyhiYXNlUGF0aDogc3RyaW5nKSB7XG4gICAgY29uc3QgY291cnNlUGF0aCA9IGAke2Jhc2VQYXRofS9Db3Vyc2VzYFxuXG4gICAgLy8gQ3JlYXRlIENvdXJzZSBIb21lcGFnZSB0ZW1wbGF0ZVxuICAgIGNvbnN0IGNvdXJzZUhvbWVwYWdlVGVtcGxhdGUgPSB0aGlzLmdlbmVyYXRlQ291cnNlSG9tZXBhZ2VUZW1wbGF0ZSgpXG4gICAgYXdhaXQgdGhpcy53cml0ZVRlbXBsYXRlRmlsZShcbiAgICAgIGAke2NvdXJzZVBhdGh9L0NyZWF0ZSBDb3Vyc2UgSG9tZXBhZ2UubWRgLFxuICAgICAgY291cnNlSG9tZXBhZ2VUZW1wbGF0ZVxuICAgIClcblxuICAgIC8vIENyZWF0ZSBDb3Vyc2UgSW5kZXggdGVtcGxhdGVcbiAgICBjb25zdCBjb3Vyc2VJbmRleFRlbXBsYXRlID0gdGhpcy5nZW5lcmF0ZUNvdXJzZUluZGV4VGVtcGxhdGUoKVxuICAgIGF3YWl0IHRoaXMud3JpdGVUZW1wbGF0ZUZpbGUoXG4gICAgICBgJHtjb3Vyc2VQYXRofS9Db3Vyc2UgSW5kZXgubWRgLFxuICAgICAgY291cnNlSW5kZXhUZW1wbGF0ZVxuICAgIClcbiAgfVxuXG4gIGFzeW5jIGluc3RhbGxNb2R1bGVUZW1wbGF0ZXMoYmFzZVBhdGg6IHN0cmluZykge1xuICAgIGNvbnN0IG1vZHVsZVBhdGggPSBgJHtiYXNlUGF0aH0vTW9kdWxlc2BcblxuICAgIC8vIENyZWF0ZSBNb2R1bGUgdGVtcGxhdGVcbiAgICBjb25zdCBtb2R1bGVUZW1wbGF0ZSA9IHRoaXMuZ2VuZXJhdGVNb2R1bGVUZW1wbGF0ZSgpXG4gICAgYXdhaXQgdGhpcy53cml0ZVRlbXBsYXRlRmlsZShcbiAgICAgIGAke21vZHVsZVBhdGh9L0NyZWF0ZSBNb2R1bGUubWRgLFxuICAgICAgbW9kdWxlVGVtcGxhdGVcbiAgICApXG4gIH1cblxuICBhc3luYyBpbnN0YWxsQ2hhcHRlclRlbXBsYXRlcyhiYXNlUGF0aDogc3RyaW5nKSB7XG4gICAgY29uc3QgY2hhcHRlclBhdGggPSBgJHtiYXNlUGF0aH0vQ2hhcHRlcnNgXG5cbiAgICAvLyBDcmVhdGUgQ2hhcHRlciB0ZW1wbGF0ZVxuICAgIGNvbnN0IGNoYXB0ZXJUZW1wbGF0ZSA9IHRoaXMuZ2VuZXJhdGVDaGFwdGVyVGVtcGxhdGUoKVxuICAgIGF3YWl0IHRoaXMud3JpdGVUZW1wbGF0ZUZpbGUoXG4gICAgICBgJHtjaGFwdGVyUGF0aH0vQ3JlYXRlIENoYXB0ZXIubWRgLFxuICAgICAgY2hhcHRlclRlbXBsYXRlXG4gICAgKVxuICB9XG5cbiAgYXN5bmMgaW5zdGFsbEFzc2lnbm1lbnRUZW1wbGF0ZXMoYmFzZVBhdGg6IHN0cmluZykge1xuICAgIGNvbnN0IGFzc2lnbm1lbnRQYXRoID0gYCR7YmFzZVBhdGh9L0Fzc2lnbm1lbnRzYFxuXG4gICAgLy8gQ3JlYXRlIEFzc2lnbm1lbnQgdGVtcGxhdGVcbiAgICBjb25zdCBhc3NpZ25tZW50VGVtcGxhdGUgPSB0aGlzLmdlbmVyYXRlQXNzaWdubWVudFRlbXBsYXRlKClcbiAgICBhd2FpdCB0aGlzLndyaXRlVGVtcGxhdGVGaWxlKFxuICAgICAgYCR7YXNzaWdubWVudFBhdGh9L0NyZWF0ZSBBc3NpZ25tZW50Lm1kYCxcbiAgICAgIGFzc2lnbm1lbnRUZW1wbGF0ZVxuICAgIClcbiAgfVxuXG4gIGFzeW5jIGluc3RhbGxEYWlseVRlbXBsYXRlcyhiYXNlUGF0aDogc3RyaW5nKSB7XG4gICAgY29uc3QgZGFpbHlQYXRoID0gYCR7YmFzZVBhdGh9L0RhaWx5YFxuXG4gICAgLy8gQ3JlYXRlIERhaWx5IE5vdGUgdGVtcGxhdGVcbiAgICBjb25zdCBkYWlseU5vdGVUZW1wbGF0ZSA9IHRoaXMuZ2VuZXJhdGVEYWlseU5vdGVUZW1wbGF0ZSgpXG4gICAgYXdhaXQgdGhpcy53cml0ZVRlbXBsYXRlRmlsZShcbiAgICAgIGAke2RhaWx5UGF0aH0vRGFpbHkgTm90ZS5tZGAsXG4gICAgICBkYWlseU5vdGVUZW1wbGF0ZVxuICAgIClcbiAgfVxuXG4gIGFzeW5jIGluc3RhbGxVdGlsaXR5VGVtcGxhdGVzKGJhc2VQYXRoOiBzdHJpbmcpIHtcbiAgICBjb25zdCB1dGlsaXR5UGF0aCA9IGAke2Jhc2VQYXRofS9VdGlsaXRpZXNgXG5cbiAgICAvLyBDcmVhdGUgVm9jYWJ1bGFyeSBFbnRyeSB0ZW1wbGF0ZVxuICAgIGNvbnN0IHZvY2FiVGVtcGxhdGUgPSB0aGlzLmdlbmVyYXRlVm9jYWJ1bGFyeVRlbXBsYXRlKClcbiAgICBhd2FpdCB0aGlzLndyaXRlVGVtcGxhdGVGaWxlKFxuICAgICAgYCR7dXRpbGl0eVBhdGh9L1ZvY2FidWxhcnkgRW50cnkubWRgLFxuICAgICAgdm9jYWJUZW1wbGF0ZVxuICAgIClcblxuICAgIC8vIENyZWF0ZSBEdWUgRGF0ZSBFbnRyeSB0ZW1wbGF0ZVxuICAgIGNvbnN0IGR1ZURhdGVUZW1wbGF0ZSA9IHRoaXMuZ2VuZXJhdGVEdWVEYXRlVGVtcGxhdGUoKVxuICAgIGF3YWl0IHRoaXMud3JpdGVUZW1wbGF0ZUZpbGUoXG4gICAgICBgJHt1dGlsaXR5UGF0aH0vRHVlIERhdGUgRW50cnkubWRgLFxuICAgICAgZHVlRGF0ZVRlbXBsYXRlXG4gICAgKVxuICB9XG5cbiAgYXN5bmMgd3JpdGVUZW1wbGF0ZUZpbGUocGF0aDogc3RyaW5nLCBjb250ZW50OiBzdHJpbmcpIHtcbiAgICB0cnkge1xuICAgICAgLy8gQ2hlY2sgaWYgZmlsZSBhbHJlYWR5IGV4aXN0c1xuICAgICAgY29uc3QgZXhpc3RpbmdGaWxlID0gdGhpcy5hcHAudmF1bHQuZ2V0QWJzdHJhY3RGaWxlQnlQYXRoKHBhdGgpXG4gICAgICBpZiAoZXhpc3RpbmdGaWxlKSB7XG4gICAgICAgIC8vIEZvciBub3csIHdlJ2xsIHVwZGF0ZSBleGlzdGluZyB0ZW1wbGF0ZXNcbiAgICAgICAgLy8gSW4gYSByZWFsIGltcGxlbWVudGF0aW9uLCB3ZSdkIGNoZWNrIHZlcnNpb25zIGFuZCBvZmZlciB0byB1cGRhdGVcbiAgICAgICAgY29uc29sZS5sb2coYFVwZGF0aW5nIGV4aXN0aW5nIHRlbXBsYXRlIGZpbGU6ICR7cGF0aH1gKVxuICAgICAgICBjb25zdCBmaWxlID0gZXhpc3RpbmdGaWxlIGFzIGltcG9ydChcIm9ic2lkaWFuXCIpLlRGaWxlXG4gICAgICAgIGF3YWl0IHRoaXMuYXBwLnZhdWx0Lm1vZGlmeShmaWxlLCBjb250ZW50KVxuICAgICAgICByZXR1cm5cbiAgICAgIH1cblxuICAgICAgLy8gQ3JlYXRlIHRoZSBmaWxlXG4gICAgICBhd2FpdCB0aGlzLmFwcC52YXVsdC5jcmVhdGUocGF0aCwgY29udGVudClcbiAgICAgIGNvbnNvbGUubG9nKGBDcmVhdGVkIHRlbXBsYXRlIGZpbGU6ICR7cGF0aH1gKVxuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIG5ldyBOb3RpY2UoYEVycm9yIGNyZWF0aW5nIHRlbXBsYXRlIGZpbGUgJHtwYXRofWApXG4gICAgICBjb25zb2xlLmVycm9yKGBFcnJvciBjcmVhdGluZyB0ZW1wbGF0ZSBmaWxlICR7cGF0aH06YCwgZSlcbiAgICB9XG4gIH1cblxuICBnZW5lcmF0ZUNvdXJzZUhvbWVwYWdlVGVtcGxhdGUoKTogc3RyaW5nIHtcbiAgICByZXR1cm4gYC0tLVxuJHtcbiAgdGhpcy5zZXR0aW5ncy51c2VFbmhhbmNlZE1ldGFkYXRhXG4gICAgPyBgY291cnNlX2lkOiA8JSBjb3Vyc2VJZCAlPlxuY291cnNlX25hbWU6IDwlIGNvdXJzZU5hbWUgJT5cbmNvdXJzZV90ZXJtOiA8JSBjb3Vyc2VTZWFzb24gJT4gPCUgY291cnNlWWVhciAlPlxuY291cnNlX3llYXI6IDwlIGNvdXJzZVllYXIgJT5cbmNvdXJzZV9zZW1lc3RlcjogPCUgY291cnNlU2Vhc29uICU+XG5jb250ZW50X3R5cGU6IGNvdXJzZV9ob21lcGFnZVxuc2Nob29sOiAke3RoaXMuc2V0dGluZ3Muc2Nob29sTmFtZX1cbnNjaG9vbF9hYmJyZXZpYXRpb246ICR7dGhpcy5zZXR0aW5ncy5zY2hvb2xBYmJyZXZpYXRpb259YFxuICAgIDogYGNvdXJzZV9pZDogPCUgY291cnNlSWQgJT5cbnRpdGxlOiA8JSBjb3Vyc2VOYW1lICU+YFxufVxuY3JlYXRlZDogPCUgdHAuZGF0ZS5ub3coXCJZWVlZLU1NLUREW1RdSEg6bW06c3NaXCIpICU+XG50YWdzOiBcbiAgLSBjb3Vyc2VfaG9tZVxuICAtIGVkdWNhdGlvblxuICAtIDwlIGNvdXJzZUlkICU+XG4gIC0gJHtcbiAgICB0aGlzLnNldHRpbmdzLnNjaG9vbEFiYnJldmlhdGlvblxuICB9LzwlIGNvdXJzZVllYXIgJT4vPCUgY291cnNlU2Vhc29uICU+LzwlIGNvdXJzZUlkICU+XG4tLS1cblxuPCUqXG5jb25zdCB7IGV4ZWMgfSA9IHJlcXVpcmUoXCJjaGlsZF9wcm9jZXNzXCIpO1xubGV0IGNvdXJzZU5hbWUgPSBhd2FpdCB0cC5zeXN0ZW0ucHJvbXB0KFwiQ291cnNlIE5hbWUgKGUuZy4gUFNJLTEwMSAtIEludHJvIHRvIFBzeWNoKVwiKVxubGV0IGNvdXJzZVNlYXNvbiA9IGF3YWl0IHRwLnN5c3RlbS5zdWdnZXN0ZXIoW1wiRmFsbFwiLFwiV2ludGVyXCIsXCJTcHJpbmdcIixcIlN1bW1lclwiXSxbXCJGYWxsXCIsXCJXaW50ZXJcIixcIlNwcmluZ1wiLFwiU3VtbWVyXCJdLCBcIlNlYXNvblwiKVxubGV0IGNvdXJzZVllYXIgPSBhd2FpdCB0cC5zeXN0ZW0ucHJvbXB0KFwiWWVhclwiKVxubGV0IGNvdXJzZUlkID0gY291cnNlTmFtZS5zcGxpdCgnIC0gJylbMF1cbmF3YWl0IHRwLmZpbGUubW92ZShcXGAvXFwke2NvdXJzZVllYXJ9L1xcJHtjb3Vyc2VTZWFzb259L1xcJHtjb3Vyc2VOYW1lfS9cXCR7Y291cnNlTmFtZX1cXGApXG50cnkge2F3YWl0IGFwcC52YXVsdC5jcmVhdGVGb2xkZXIoXFxgXFwke2NvdXJzZVllYXJ9L1xcJHtjb3Vyc2VTZWFzb259L1xcJHtjb3Vyc2VOYW1lfS9BdHRhY2htZW50c1xcYCl9IGNhdGNoIChlKSB7fVxuJT5cblxuIyA8JSBjb3Vyc2VOYW1lICU+XG5cbiMjIENvdXJzZSBJbmZvcm1hdGlvblxuKipDb3Vyc2UgSUQqKjogPCUgY291cnNlSWQgJT5cbioqVGVybSoqOiA8JSBjb3Vyc2VTZWFzb24gJT4gPCUgY291cnNlWWVhciAlPlxuKipTY2hvb2wqKjogJHt0aGlzLnNldHRpbmdzLnNjaG9vbE5hbWV9XG5cbiMjIEluc3RydWN0b3JcbioqTmFtZSoqOiBcbioqRW1haWwqKjogXG4qKk9mZmljZSBIb3VycyoqOiBcblxuIyMgQ291cnNlIERlc2NyaXB0aW9uXG5cbiMjIExlYXJuaW5nIE9iamVjdGl2ZXNcblxuIyMgUmVxdWlyZWQgVGV4dHNcblxcYFxcYFxcYG1ldGEtYmluZC1qcy12aWV3XG57dGV4dHN9IGFzIHRleHRzXG4tLS1cbmNvbnN0IGF2YWlsYWJsZVRleHRzID0gYXBwLnZhdWx0LmdldEZpbGVzKCkuZmlsdGVyKGZpbGUgPT4gZmlsZS5leHRlbnNpb24gPT0gJ3BkZicpLm1hcChmID0+IGY/Lm5hbWUpXG5jb25zdCBlc2NhcGVSZWdleCA9IC9bLFxcXCJcXGAnKCldL2c7XG5vcHRpb25zID0gYXZhaWxhYmxlVGV4dHMubWFwKHQgPT4gXFxgb3B0aW9uKFtbXFwke3QucmVwbGFjZShlc2NhcGVSZWdleCxcXGBcXFxcXFxcXCQxXFxgKX1dXSwgXFwke3QucmVwbGFjZShlc2NhcGVSZWdleCxcXGBcXFxcXFxcXCQxXFxgKX0pXFxgIClcbmNvbnN0IHN0ciA9IFxcXFxcXGBJTlBVVFtpbmxpbmVMaXN0U3VnZ2VzdGVyKFxcJHtvcHRpb25zLmpvaW4oXCIsIFwiKX0pOnRleHRzXVxcXFxcXGBcbnJldHVybiBlbmdpbmUubWFya2Rvd24uY3JlYXRlKHN0cilcblxcYFxcYFxcYFxuXG4jIyBTY2hlZHVsZVxuXG4jIyBBc3NpZ25tZW50c1xuXG4jIyBSZXNvdXJjZXNcblxuIyMgVm9jYWJ1bGFyeVxuXFxgXFxgXFxgZGF0YXZpZXdqc1xuLy8gVm9jYWJ1bGFyeSBhZ2dyZWdhdGlvbiBjb2RlIHdvdWxkIGdvIGhlcmVcblxcYFxcYFxcYFxuXG4jIyBEdWUgRGF0ZXNcblxcYFxcYFxcYGRhdGF2aWV3anNcbi8vIER1ZSBkYXRlcyBhZ2dyZWdhdGlvbiBjb2RlIHdvdWxkIGdvIGhlcmVcblxcYFxcYFxcYGBcbiAgfVxuXG4gIGdlbmVyYXRlQ291cnNlSW5kZXhUZW1wbGF0ZSgpOiBzdHJpbmcge1xuICAgIHJldHVybiBgLS0tXG5jb250ZW50X3R5cGU6IGNvdXJzZV9pbmRleFxudGFnczpcbiAgLSBpbmRleFxuLS0tXG5cbiMgQ291cnNlIEluZGV4XG5cbiMjIE1vZHVsZXNcblxuIyMgQ2hhcHRlcnNcblxuIyMgQXNzaWdubWVudHNcblxuIyMgUmVzb3VyY2VzXG5cbiMjIFZvY2FidWxhcnlcblxuIyMgRHVlIERhdGVzYFxuICB9XG5cbiAgZ2VuZXJhdGVNb2R1bGVUZW1wbGF0ZSgpOiBzdHJpbmcge1xuICAgIHJldHVybiBgLS0tXG4ke1xuICB0aGlzLnNldHRpbmdzLnVzZUVuaGFuY2VkTWV0YWRhdGFcbiAgICA/IGBjb3Vyc2VfaWQ6IDwlIGNvdXJzZUlkICU+XG5tb2R1bGVfbnVtYmVyOiA8JSBtb2R1bGVOdW1iZXIgJT5cbndlZWtfbnVtYmVyOiA8JSB3ZWVrTnVtYmVyICU+XG5jbGFzc19kYXk6IDwlIGRheU9mV2VlayAlPlxuY29udGVudF90eXBlOiBtb2R1bGVcbnBhcmVudF9jb3Vyc2U6IFwiW1s8JSBjb3Vyc2UgJT5dXVwiYFxuICAgIDogYGNvdXJzZV9pZDogPCUgY291cnNlSWQgJT5cbm1vZHVsZV9udW1iZXI6IDwlIG1vZHVsZU51bWJlciAlPlxud2Vla19udW1iZXI6IDwlIHdlZWtOdW1iZXIgJT5cbmNsYXNzX2RheTogPCUgZGF5T2ZXZWVrICU+YFxufVxuY3JlYXRlZDogPCUgdHAuZGF0ZS5ub3coXCJZWVlZLU1NLUREW1RdSEg6bW06c3NaXCIpICU+XG50YWdzOlxuICAtIGVkdWNhdGlvblxuICAtIDwlIGNvdXJzZUlkICU+XG4gIC0gbW9kdWxlXG4tLS1cblxuPCUqXG5jb25zdCB7IHNlYXNvbiwgbW9kdWxlTnVtYmVyLCB3ZWVrTnVtYmVyLCBjb3Vyc2UsIGNvdXJzZUlkLCBkaXNjaXBsaW5lLCBkYXlPZldlZWsgfSA9IGF3YWl0IHRwLnVzZXIubmV3X21vZHVsZShhcHAsIHRwLCBcIjIwMjVcIik7XG5sZXQgdGl0bGUgPSBjb3Vyc2VJZFxuaWYgKG1vZHVsZU51bWJlciAmJiB3ZWVrTnVtYmVyKSB7IHRpdGxlID0gXFxgTVxcJHttb2R1bGVOdW1iZXJ9L1dcXCR7d2Vla051bWJlcn1cXGB9XG5lbHNlIGlmIChtb2R1bGVOdW1iZXIpIHsgdGl0bGUgPSBcXGBNXFwke21vZHVsZU51bWJlcn1cXGAgfSBcbmVsc2UgaWYgKHdlZWtOdW1iZXIpIHsgdGl0bGUgPSBcXGBXXFwke3dlZWtOdW1iZXJ9XFxgfVxuJT5cblxuIyBbWzwlIGNvdXJzZSAlPl1dIC0gPCUgdGl0bGUgJT4gLSA8JSBkYXlPZldlZWsgJT5cblxuIyMgTGVhcm5pbmcgT2JqZWN0aXZlc1xuXG4jIyBSZWFkaW5nIEFzc2lnbm1lbnRcblxuIyMgTGVjdHVyZSBOb3Rlc1xuXG4jIyBEaXNjdXNzaW9uIFF1ZXN0aW9uc1xuXG4jIyBBc3NpZ25tZW50c1xufCBEYXRlIHwgQXNzaWdubWVudCB8IFN0YXR1cyB8XG58IC0tLS0gfCAtLS0tLS0tLS0tIHwgLS0tLS0tIHxcbnwgICAgICB8ICAgICAgICAgICAgfCAgICAgICAgfFxuXG4jIyBWb2NhYnVsYXJ5XG5cbiMjIEFkZGl0aW9uYWwgUmVzb3VyY2VzYFxuICB9XG5cbiAgZ2VuZXJhdGVDaGFwdGVyVGVtcGxhdGUoKTogc3RyaW5nIHtcbiAgICByZXR1cm4gYC0tLVxuJHtcbiAgdGhpcy5zZXR0aW5ncy51c2VFbmhhbmNlZE1ldGFkYXRhXG4gICAgPyBgY291cnNlX2lkOiA8JSBjb3Vyc2VJZCAlPlxuY2hhcHRlcl9udW1iZXI6IDwlIGNoYXB0ZXJOdW1iZXIgJT5cbmNvbnRlbnRfdHlwZTogY2hhcHRlclxucGFyZW50X2NvdXJzZTogXCJbWzwlIGNvdXJzZSAlPl1dXCJcbnRleHRfcmVmZXJlbmNlOiBcIltbPCUgdGV4dCAlPl1dXCJgXG4gICAgOiBgY291cnNlX2lkOiA8JSBjb3Vyc2VJZCAlPlxuY2hhcHRlcl9udW1iZXI6IDwlIGNoYXB0ZXJOdW1iZXIgJT5gXG59XG5jcmVhdGVkOiA8JSB0cC5kYXRlLm5vdyhcIllZWVktTU0tRERbVF1ISDptbTpzc1pcIikgJT5cbnRhZ3M6XG4gIC0gZWR1Y2F0aW9uXG4gIC0gPCUgY291cnNlSWQgJT5cbiAgLSBjaGFwdGVyXG4tLS1cblxuPCUqXG5jb25zdCB7IGNoYXB0ZXJOdW1iZXIsIGNvdXJzZSwgY291cnNlSWQsIGRpc2NpcGxpbmUsIHRleHR9ID0gYXdhaXQgdHAudXNlci5uZXdfY2hhcHRlcih0cCk7XG4lPlxuXG4jIFtbPCUgdGV4dCAlPl1dIC0gQ2hhcHRlciA8JSBjaGFwdGVyTnVtYmVyICU+XG5cbiMjIFN1bW1hcnlcblxuIyMgS2V5IENvbmNlcHRzXG5cbiMjIFZvY2FidWxhcnlcbi0gXG5cbiMjIE5vdGVzXG5cbiMjIERpc2N1c3Npb24gUXVlc3Rpb25zXG5cbiMjIEZ1cnRoZXIgUmVhZGluZ2BcbiAgfVxuXG4gIGdlbmVyYXRlQXNzaWdubWVudFRlbXBsYXRlKCk6IHN0cmluZyB7XG4gICAgcmV0dXJuIGAtLS1cbiR7XG4gIHRoaXMuc2V0dGluZ3MudXNlRW5oYW5jZWRNZXRhZGF0YVxuICAgID8gYGNvdXJzZV9pZDogPCUgY291cnNlSWQgJT5cbmFzc2lnbm1lbnRfdHlwZTogPCUgYXNzaWdubWVudFR5cGUgJT5cbmR1ZV9kYXRlOiA8JSBkdWVEYXRlICU+XG5wb2ludHM6IDwlIHBvaW50cyAlPlxuY29udGVudF90eXBlOiBhc3NpZ25tZW50XG5wYXJlbnRfY291cnNlOiBcIltbPCUgY291cnNlICU+XV1cImBcbiAgICA6IGBjb3Vyc2VfaWQ6IDwlIGNvdXJzZUlkICU+XG5hc3NpZ25tZW50X3R5cGU6IDwlIGFzc2lnbm1lbnRUeXBlICU+XG5kdWVfZGF0ZTogPCUgZHVlRGF0ZSAlPmBcbn1cbmNyZWF0ZWQ6IDwlIHRwLmRhdGUubm93KFwiWVlZWS1NTS1ERFtUXUhIOm1tOnNzWlwiKSAlPlxuc3RhdHVzOiBwZW5kaW5nXG50YWdzOlxuICAtIGVkdWNhdGlvblxuICAtIDwlIGNvdXJzZUlkICU+XG4gIC0gYXNzaWdubWVudFxuLS0tXG5cbiMgPCUgYXNzaWdubWVudE5hbWUgJT4gLSA8JSBjb3Vyc2VJZCAlPlxuXG4jIyBEZXNjcmlwdGlvblxuXG4jIyBJbnN0cnVjdGlvbnNcblxuIyMgRHVlIERhdGVcbioqQXNzaWduZWQqKjogPCUgdHAuZGF0ZS5ub3coXCJZWVlZLU1NLUREXCIpICU+XG4qKkR1ZSoqOiA8JSBkdWVEYXRlICU+XG5cbiMjIFN1Ym1pc3Npb25cblxuIyMgR3JhZGluZyBDcml0ZXJpYVxuXG4jIyBSZXNvdXJjZXNgXG4gIH1cblxuICBnZW5lcmF0ZURhaWx5Tm90ZVRlbXBsYXRlKCk6IHN0cmluZyB7XG4gICAgcmV0dXJuIGAtLS1cbmNvbnRlbnRfdHlwZTogZGFpbHlfbm90ZVxuZGF0ZTogPCUgdHAuZGF0ZS5ub3coXCJZWVlZLU1NLUREXCIpICU+XG50YWdzOlxuICAtIGRhaWx5XG4gIC0gPCUgdHAuZGF0ZS5ub3coXCJZWVlZXCIpICU+XG4gIC0gPCUgdHAuZGF0ZS5ub3coXCJNTVwiKSAlPlxuICAtIDwlIHRwLmRhdGUubm93KFwiRERcIikgJT5cbi0tLVxuXG4jIDwlIHRwLmRhdGUubm93KFwiWVlZWS1NTS1ERCAtIGRkZGRcIikgJT5cblxuPDwgW1s8JSB0cC5kYXRlLnllc3RlcmRheShcIllZWVktTU0tRERcIikgJT5dXSB8IFtbPCUgdHAuZGF0ZS50b21vcnJvdyhcIllZWVktTU0tRERcIikgJT5dXSA+PlxuXG4jIyBUb2RheSdzIEZvY3VzXG5cbiMjIENvdXJzZXMgV29ya2VkIE9uXG4tIFxuXG4jIyBUYXNrcyBDb21wbGV0ZWRcbi0gWyBdIFxuXG4jIyBWb2NhYnVsYXJ5IFJldmlld2VkXG4tIFxuXG4jIyBBc3NpZ25tZW50cyBEdWVcbi0gXG5cbiMjIExlYXJuaW5nIEFjaGlldmVtZW50c1xuXG4jIyBDaGFsbGVuZ2VzXG5cbiMjIFRvbW9ycm93J3MgUGxhblxuXG4jIyBSZWZsZWN0aW9uYFxuICB9XG5cbiAgZ2VuZXJhdGVWb2NhYnVsYXJ5VGVtcGxhdGUoKTogc3RyaW5nIHtcbiAgICByZXR1cm4gYCMjIDwlIHRlcm0gJT5cbioqVGVybSoqOiA8JSB0ZXJtICU+XG4qKlBhcnQgb2YgU3BlZWNoKio6IFxuKipEZWZpbml0aW9uKio6IFxuKipDb250ZXh0Kio6IFxuKipFeGFtcGxlcyoqOiBcbioqUmVsYXRlZCBUZXJtcyoqOiBcbioqU2VlIEFsc28qKjpgXG4gIH1cblxuICBnZW5lcmF0ZUR1ZURhdGVUZW1wbGF0ZSgpOiBzdHJpbmcge1xuICAgIHJldHVybiBgfCA8JSBkdWVEYXRlICU+IHwgPCUgYXNzaWdubWVudCAlPiB8IDwlIHN0YXR1cyAlPiB8YFxuICB9XG5cbiAgYXN5bmMgY3JlYXRlUkVBRE1FKGJhc2VQYXRoOiBzdHJpbmcpIHtcbiAgICBjb25zdCByZWFkbWVDb250ZW50ID0gYCMgVHVja2VycyBUb29scyBUZW1wbGF0ZXNcblxuVGhpcyBkaXJlY3RvcnkgY29udGFpbnMgdGVtcGxhdGVzIGZvciB0aGUgVHVja2VycyBUb29scyBPYnNpZGlhbiBwbHVnaW4uXG5cbiMjIFRlbXBsYXRlIENhdGVnb3JpZXNcblxuLSAqKkNvdXJzZXMqKjogVGVtcGxhdGVzIGZvciBjcmVhdGluZyBhbmQgb3JnYW5pemluZyBjb3Vyc2VzXG4tICoqTW9kdWxlcyoqOiBUZW1wbGF0ZXMgZm9yIGNvdXJzZSBtb2R1bGVzXG4tICoqQ2hhcHRlcnMqKjogVGVtcGxhdGVzIGZvciBjaGFwdGVyIG5vdGVzXG4tICoqQXNzaWdubWVudHMqKjogVGVtcGxhdGVzIGZvciBhc3NpZ25tZW50c1xuLSAqKkRhaWx5Kio6IFRlbXBsYXRlcyBmb3IgZGFpbHkgbm90ZXNcbi0gKipVdGlsaXRpZXMqKjogSGVscGVyIHRlbXBsYXRlc1xuXG4jIyBVc2FnZVxuXG5UaGVzZSB0ZW1wbGF0ZXMgYXJlIGRlc2lnbmVkIHRvIHdvcmsgd2l0aCB0aGUgVHVja2VycyBUb29scyBwbHVnaW4uIFRvIHVzZSB0aGVtOlxuXG4xLiBJbnN0YWxsIHRoZSBUdWNrZXJzIFRvb2xzIHBsdWdpblxuMi4gQ29uZmlndXJlIHlvdXIgc2V0dGluZ3MgaW4gdGhlIHBsdWdpbiBzZXR0aW5ncyB0YWJcbjMuIFVzZSB0aGUgXCJJbnNlcnQgVGVtcGxhdGVcIiBjb21tYW5kIHRvIGFwcGx5IHRoZXNlIHRlbXBsYXRlcyB0byBuZXcgbm90ZXNcblxuIyMgQ3VzdG9taXphdGlvblxuXG5GZWVsIGZyZWUgdG8gY3VzdG9taXplIHRoZXNlIHRlbXBsYXRlcyB0byBzdWl0IHlvdXIgbmVlZHMuIFRoZSBwbHVnaW4gd2lsbCBub3Qgb3ZlcndyaXRlIHlvdXIgY2hhbmdlcyB3aGVuIHVwZGF0aW5nIHRlbXBsYXRlcy5gXG5cbiAgICBhd2FpdCB0aGlzLndyaXRlVGVtcGxhdGVGaWxlKGAke2Jhc2VQYXRofS9SRUFETUUubWRgLCByZWFkbWVDb250ZW50KVxuICB9XG59XG4iLCAiLy8gQ291cnNlIGNyZWF0aW9uIHdpemFyZCBmb3IgVHVja2VycyBUb29scyBwbHVnaW5cblxuaW1wb3J0IHsgQXBwLCBOb3RpY2UsIFRGaWxlIH0gZnJvbSBcIm9ic2lkaWFuXCJcbmltcG9ydCB7IFR1Y2tlcnNUb29sc1NldHRpbmdzIH0gZnJvbSBcIi4vc2V0dGluZ3NcIlxuaW1wb3J0IHsgc2x1Z2lmeSB9IGZyb20gXCIuL3V0aWxzXCJcblxuZXhwb3J0IGNsYXNzIENvdXJzZUNyZWF0aW9uV2l6YXJkIHtcbiAgYXBwOiBBcHBcbiAgc2V0dGluZ3M6IFR1Y2tlcnNUb29sc1NldHRpbmdzXG5cbiAgY29uc3RydWN0b3IoYXBwOiBBcHAsIHNldHRpbmdzOiBUdWNrZXJzVG9vbHNTZXR0aW5ncykge1xuICAgIHRoaXMuYXBwID0gYXBwXG4gICAgdGhpcy5zZXR0aW5ncyA9IHNldHRpbmdzXG4gIH1cblxuICBhc3luYyBjcmVhdGVDb3Vyc2VIb21lcGFnZSgpIHtcbiAgICB0cnkge1xuICAgICAgLy8gUHJvbXB0IHVzZXIgZm9yIGNvdXJzZSBkZXRhaWxzXG4gICAgICBjb25zdCBjb3Vyc2VEZXRhaWxzID0gYXdhaXQgdGhpcy5wcm9tcHRDb3Vyc2VEZXRhaWxzKClcblxuICAgICAgaWYgKCFjb3Vyc2VEZXRhaWxzKSB7XG4gICAgICAgIHJldHVybiBmYWxzZSAvLyBVc2VyIGNhbmNlbGxlZFxuICAgICAgfVxuXG4gICAgICAvLyBDcmVhdGUgZm9sZGVyIHN0cnVjdHVyZVxuICAgICAgY29uc3QgZm9sZGVyUGF0aCA9IGF3YWl0IHRoaXMuY3JlYXRlQ291cnNlRm9sZGVyU3RydWN0dXJlKGNvdXJzZURldGFpbHMpXG5cbiAgICAgIC8vIEdlbmVyYXRlIGNvdXJzZSBob21lcGFnZSBub3RlXG4gICAgICBhd2FpdCB0aGlzLmNyZWF0ZUNvdXJzZUhvbWVwYWdlTm90ZShjb3Vyc2VEZXRhaWxzLCBmb2xkZXJQYXRoKVxuXG4gICAgICAvLyBDcmVhdGUgYXR0YWNobWVudHMgZm9sZGVyXG4gICAgICBhd2FpdCB0aGlzLmNyZWF0ZUF0dGFjaG1lbnRzRm9sZGVyKGZvbGRlclBhdGgpXG5cbiAgICAgIG5ldyBOb3RpY2UoYENvdXJzZSBcIiR7Y291cnNlRGV0YWlscy5jb3Vyc2VOYW1lfVwiIGNyZWF0ZWQgc3VjY2Vzc2Z1bGx5IWApXG4gICAgICBjb25zb2xlLmxvZyhcbiAgICAgICAgYENvdXJzZSBjcmVhdGVkOiAke2NvdXJzZURldGFpbHMuY291cnNlTmFtZX0gYXQgJHtmb2xkZXJQYXRofWBcbiAgICAgIClcblxuICAgICAgcmV0dXJuIHRydWVcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGNyZWF0aW5nIGNvdXJzZTpcIiwgZXJyb3IpXG4gICAgICBuZXcgTm90aWNlKGBFcnJvciBjcmVhdGluZyBjb3Vyc2U6ICR7ZXJyb3IubWVzc2FnZX1gKVxuICAgICAgcmV0dXJuIGZhbHNlXG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBwcm9tcHRDb3Vyc2VEZXRhaWxzKCk6IFByb21pc2U8e1xuICAgIGNvdXJzZU5hbWU6IHN0cmluZ1xuICAgIGNvdXJzZVNlYXNvbjogc3RyaW5nXG4gICAgY291cnNlWWVhcjogc3RyaW5nXG4gICAgY291cnNlSWQ6IHN0cmluZ1xuICB9IHwgbnVsbD4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBjb3Vyc2VOYW1lID0gYXdhaXQgdGhpcy5wcm9tcHRXaXRoVmFsaWRhdGlvbihcbiAgICAgICAgXCJDb3Vyc2UgTmFtZVwiLFxuICAgICAgICBcIkVudGVyIGNvdXJzZSBuYW1lIChlLmcuLCBQU0ktMTAxIC0gSW50cm8gdG8gUHN5Y2hvbG9neSlcIixcbiAgICAgICAgKHZhbHVlKSA9PiB2YWx1ZS50cmltKCkubGVuZ3RoID4gMCxcbiAgICAgICAgXCJDb3Vyc2UgbmFtZSBpcyByZXF1aXJlZFwiXG4gICAgICApXG5cbiAgICAgIGlmICghY291cnNlTmFtZSkgcmV0dXJuIG51bGxcblxuICAgICAgY29uc3QgY291cnNlU2Vhc29uID0gYXdhaXQgdGhpcy5wcm9tcHRXaXRoT3B0aW9ucyhcbiAgICAgICAgXCJTZWFzb25cIixcbiAgICAgICAgXCJTZWxlY3Qgc2VtZXN0ZXIvc2Vhc29uXCIsXG4gICAgICAgIFtcIkZhbGxcIiwgXCJXaW50ZXJcIiwgXCJTcHJpbmdcIiwgXCJTdW1tZXJcIl1cbiAgICAgIClcblxuICAgICAgaWYgKCFjb3Vyc2VTZWFzb24pIHJldHVybiBudWxsXG5cbiAgICAgIGNvbnN0IGNvdXJzZVllYXIgPSBhd2FpdCB0aGlzLnByb21wdFdpdGhWYWxpZGF0aW9uKFxuICAgICAgICBcIlllYXJcIixcbiAgICAgICAgXCJFbnRlciBhY2FkZW1pYyB5ZWFyIChlLmcuLCAyMDI1KVwiLFxuICAgICAgICAodmFsdWUpID0+IC9eXFxkezR9JC8udGVzdCh2YWx1ZS50cmltKCkpLFxuICAgICAgICBcIlBsZWFzZSBlbnRlciBhIHZhbGlkIDQtZGlnaXQgeWVhclwiXG4gICAgICApXG5cbiAgICAgIGlmICghY291cnNlWWVhcikgcmV0dXJuIG51bGxcblxuICAgICAgY29uc3QgY291cnNlSWQgPSBjb3Vyc2VOYW1lLnNwbGl0KFwiIC0gXCIpWzBdPy50cmltKCkgfHwgc2x1Z2lmeShjb3Vyc2VOYW1lKVxuXG4gICAgICByZXR1cm4ge1xuICAgICAgICBjb3Vyc2VOYW1lLFxuICAgICAgICBjb3Vyc2VTZWFzb24sXG4gICAgICAgIGNvdXJzZVllYXIsXG4gICAgICAgIGNvdXJzZUlkXG4gICAgICB9XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBwcm9tcHRpbmcgZm9yIGNvdXJzZSBkZXRhaWxzOlwiLCBlcnJvcilcbiAgICAgIHJldHVybiBudWxsXG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBwcm9tcHRXaXRoVmFsaWRhdGlvbihcbiAgICB0aXRsZTogc3RyaW5nLFxuICAgIG1lc3NhZ2U6IHN0cmluZyxcbiAgICB2YWxpZGF0b3I6ICh2YWx1ZTogc3RyaW5nKSA9PiBib29sZWFuLFxuICAgIGVycm9yTWVzc2FnZTogc3RyaW5nXG4gICk6IFByb21pc2U8c3RyaW5nIHwgbnVsbD4ge1xuICAgIC8vIFVzZSBhIHNpbXBsZSBwcm9tcHQgZm9yIG5vdyAtIGluIGEgcmVhbCBpbXBsZW1lbnRhdGlvbiwgdGhpcyB3b3VsZCB1c2UgYSBwcm9wZXIgbW9kYWxcbiAgICBjb25zdCB2YWx1ZSA9IHByb21wdChgJHt0aXRsZX06ICR7bWVzc2FnZX1gKVxuXG4gICAgaWYgKCF2YWx1ZSkgcmV0dXJuIG51bGwgLy8gVXNlciBjYW5jZWxsZWRcblxuICAgIGlmICghdmFsaWRhdG9yKHZhbHVlKSkge1xuICAgICAgbmV3IE5vdGljZShlcnJvck1lc3NhZ2UpXG4gICAgICByZXR1cm4gYXdhaXQgdGhpcy5wcm9tcHRXaXRoVmFsaWRhdGlvbihcbiAgICAgICAgdGl0bGUsXG4gICAgICAgIG1lc3NhZ2UsXG4gICAgICAgIHZhbGlkYXRvcixcbiAgICAgICAgZXJyb3JNZXNzYWdlXG4gICAgICApXG4gICAgfVxuXG4gICAgcmV0dXJuIHZhbHVlLnRyaW0oKVxuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBwcm9tcHRXaXRoT3B0aW9ucyhcbiAgICB0aXRsZTogc3RyaW5nLFxuICAgIG1lc3NhZ2U6IHN0cmluZyxcbiAgICBvcHRpb25zOiBzdHJpbmdbXVxuICApOiBQcm9taXNlPHN0cmluZyB8IG51bGw+IHtcbiAgICAvLyBVc2UgYSBzaW1wbGUgY29uZmlybSBkaWFsb2cgZm9yIG5vdyAtIGluIGEgcmVhbCBpbXBsZW1lbnRhdGlvbiwgdGhpcyB3b3VsZCB1c2UgYSBwcm9wZXIgbW9kYWxcbiAgICBjb25zdCBjaG9pY2UgPSBwcm9tcHQoXG4gICAgICBgJHt0aXRsZX06ICR7bWVzc2FnZX1cXG5PcHRpb25zOiAke29wdGlvbnMuam9pbihcIiwgXCIpfVxcbkVudGVyIHlvdXIgY2hvaWNlOmBcbiAgICApXG5cbiAgICBpZiAoIWNob2ljZSkgcmV0dXJuIG51bGwgLy8gVXNlciBjYW5jZWxsZWRcblxuICAgIGNvbnN0IHRyaW1tZWRDaG9pY2UgPSBjaG9pY2UudHJpbSgpXG4gICAgaWYgKG9wdGlvbnMuaW5jbHVkZXModHJpbW1lZENob2ljZSkpIHtcbiAgICAgIHJldHVybiB0cmltbWVkQ2hvaWNlXG4gICAgfVxuXG4gICAgbmV3IE5vdGljZShgUGxlYXNlIHNlbGVjdCBvbmUgb2Y6ICR7b3B0aW9ucy5qb2luKFwiLCBcIil9YClcbiAgICByZXR1cm4gYXdhaXQgdGhpcy5wcm9tcHRXaXRoT3B0aW9ucyh0aXRsZSwgbWVzc2FnZSwgb3B0aW9ucylcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgY3JlYXRlQ291cnNlRm9sZGVyU3RydWN0dXJlKGNvdXJzZURldGFpbHM6IHtcbiAgICBjb3Vyc2VOYW1lOiBzdHJpbmdcbiAgICBjb3Vyc2VTZWFzb246IHN0cmluZ1xuICAgIGNvdXJzZVllYXI6IHN0cmluZ1xuICAgIGNvdXJzZUlkOiBzdHJpbmdcbiAgfSk6IFByb21pc2U8c3RyaW5nPiB7XG4gICAgY29uc3QgZm9sZGVyUGF0aCA9IGAke2NvdXJzZURldGFpbHMuY291cnNlWWVhcn0vJHtjb3Vyc2VEZXRhaWxzLmNvdXJzZVNlYXNvbn0vJHtjb3Vyc2VEZXRhaWxzLmNvdXJzZU5hbWV9YFxuXG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IHRoaXMuYXBwLnZhdWx0LmNyZWF0ZUZvbGRlcihmb2xkZXJQYXRoKVxuICAgICAgY29uc29sZS5sb2coYENyZWF0ZWQgY291cnNlIGZvbGRlcjogJHtmb2xkZXJQYXRofWApXG4gICAgICByZXR1cm4gZm9sZGVyUGF0aFxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAvLyBGb2xkZXIgbWlnaHQgYWxyZWFkeSBleGlzdCwgd2hpY2ggaXMgZmluZSBmb3Igbm93XG4gICAgICBjb25zb2xlLmxvZyhgQ291cnNlIGZvbGRlciBhbHJlYWR5IGV4aXN0cyBvciBjcmVhdGVkOiAke2ZvbGRlclBhdGh9YClcbiAgICAgIHJldHVybiBmb2xkZXJQYXRoXG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBjcmVhdGVDb3Vyc2VIb21lcGFnZU5vdGUoXG4gICAgY291cnNlRGV0YWlsczoge1xuICAgICAgY291cnNlTmFtZTogc3RyaW5nXG4gICAgICBjb3Vyc2VTZWFzb246IHN0cmluZ1xuICAgICAgY291cnNlWWVhcjogc3RyaW5nXG4gICAgICBjb3Vyc2VJZDogc3RyaW5nXG4gICAgfSxcbiAgICBmb2xkZXJQYXRoOiBzdHJpbmdcbiAgKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgY29uc3Qgbm90ZVBhdGggPSBgJHtmb2xkZXJQYXRofS8ke2NvdXJzZURldGFpbHMuY291cnNlTmFtZX0ubWRgXG4gICAgY29uc3QgY29udGVudCA9IHRoaXMuZ2VuZXJhdGVDb3Vyc2VIb21lcGFnZUNvbnRlbnQoY291cnNlRGV0YWlscylcblxuICAgIHRyeSB7XG4gICAgICBhd2FpdCB0aGlzLmFwcC52YXVsdC5jcmVhdGUobm90ZVBhdGgsIGNvbnRlbnQpXG4gICAgICBjb25zb2xlLmxvZyhgQ3JlYXRlZCBjb3Vyc2UgaG9tZXBhZ2U6ICR7bm90ZVBhdGh9YClcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihgRXJyb3IgY3JlYXRpbmcgY291cnNlIGhvbWVwYWdlOiAke2Vycm9yfWApXG4gICAgICB0aHJvdyBlcnJvclxuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgY3JlYXRlQXR0YWNobWVudHNGb2xkZXIoZm9sZGVyUGF0aDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgY29uc3QgYXR0YWNobWVudHNQYXRoID0gYCR7Zm9sZGVyUGF0aH0vQXR0YWNobWVudHNgXG5cbiAgICB0cnkge1xuICAgICAgYXdhaXQgdGhpcy5hcHAudmF1bHQuY3JlYXRlRm9sZGVyKGF0dGFjaG1lbnRzUGF0aClcbiAgICAgIGNvbnNvbGUubG9nKGBDcmVhdGVkIGF0dGFjaG1lbnRzIGZvbGRlcjogJHthdHRhY2htZW50c1BhdGh9YClcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgLy8gRm9sZGVyIG1pZ2h0IGFscmVhZHkgZXhpc3QsIHdoaWNoIGlzIGZpbmVcbiAgICAgIGNvbnNvbGUubG9nKGBBdHRhY2htZW50cyBmb2xkZXIgYWxyZWFkeSBleGlzdHM6ICR7YXR0YWNobWVudHNQYXRofWApXG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSBnZW5lcmF0ZUNvdXJzZUhvbWVwYWdlQ29udGVudChjb3Vyc2VEZXRhaWxzOiB7XG4gICAgY291cnNlTmFtZTogc3RyaW5nXG4gICAgY291cnNlU2Vhc29uOiBzdHJpbmdcbiAgICBjb3Vyc2VZZWFyOiBzdHJpbmdcbiAgICBjb3Vyc2VJZDogc3RyaW5nXG4gIH0pOiBzdHJpbmcge1xuICAgIGNvbnN0IGVuaGFuY2VkTWV0YWRhdGEgPSB0aGlzLnNldHRpbmdzLnVzZUVuaGFuY2VkTWV0YWRhdGFcblxuICAgIHJldHVybiBgLS0tXG4ke1xuICBlbmhhbmNlZE1ldGFkYXRhXG4gICAgPyBgY291cnNlX2lkOiAke2NvdXJzZURldGFpbHMuY291cnNlSWR9XG5jb3Vyc2VfbmFtZTogJHtjb3Vyc2VEZXRhaWxzLmNvdXJzZU5hbWV9XG5jb3Vyc2VfdGVybTogJHtjb3Vyc2VEZXRhaWxzLmNvdXJzZVNlYXNvbn0gJHtjb3Vyc2VEZXRhaWxzLmNvdXJzZVllYXJ9XG5jb3Vyc2VfeWVhcjogJHtjb3Vyc2VEZXRhaWxzLmNvdXJzZVllYXJ9XG5jb3Vyc2Vfc2VtZXN0ZXI6ICR7Y291cnNlRGV0YWlscy5jb3Vyc2VTZWFzb259XG5jb250ZW50X3R5cGU6IGNvdXJzZV9ob21lcGFnZVxuc2Nob29sOiAke3RoaXMuc2V0dGluZ3Muc2Nob29sTmFtZX1cbnNjaG9vbF9hYmJyZXZpYXRpb246ICR7dGhpcy5zZXR0aW5ncy5zY2hvb2xBYmJyZXZpYXRpb259YFxuICAgIDogYGNvdXJzZV9pZDogJHtjb3Vyc2VEZXRhaWxzLmNvdXJzZUlkfVxudGl0bGU6ICR7Y291cnNlRGV0YWlscy5jb3Vyc2VOYW1lfWBcbn1cbmNyZWF0ZWQ6ICR7bmV3IERhdGUoKS50b0lTT1N0cmluZygpfVxudGFnczpcbiAtIGNvdXJzZV9ob21lXG4gLSBlZHVjYXRpb25cbiAtICR7Y291cnNlRGV0YWlscy5jb3Vyc2VJZH1cbiAtICR7dGhpcy5zZXR0aW5ncy5zY2hvb2xBYmJyZXZpYXRpb259LyR7Y291cnNlRGV0YWlscy5jb3Vyc2VZZWFyfS8ke1xuICAgICAgY291cnNlRGV0YWlscy5jb3Vyc2VTZWFzb25cbiAgICB9LyR7Y291cnNlRGV0YWlscy5jb3Vyc2VJZH1cbi0tLVxuXG5cbiMgJHtjb3Vyc2VEZXRhaWxzLmNvdXJzZU5hbWV9XG5cbiMjIENvdXJzZSBJbmZvcm1hdGlvblxuKipDb3Vyc2UgSUQqKjogJHtjb3Vyc2VEZXRhaWxzLmNvdXJzZUlkfVxuKipUZXJtKio6ICR7Y291cnNlRGV0YWlscy5jb3Vyc2VTZWFzb259ICR7Y291cnNlRGV0YWlscy5jb3Vyc2VZZWFyfVxuKipTY2hvb2wqKjogJHt0aGlzLnNldHRpbmdzLnNjaG9vbE5hbWV9XG5cbiMjIEluc3RydWN0b3JcbioqTmFtZSoqOlxuKipFbWFpbCoqOlxuKipPZmZpY2UgSG91cnMqKjpcblxuIyMgQ291cnNlIERlc2NyaXB0aW9uXG5cbiMjIExlYXJuaW5nIE9iamVjdGl2ZXNcblxuIyMgUmVxdWlyZWQgVGV4dHNcblxuIyMgU2NoZWR1bGVcblxuIyMgQXNzaWdubWVudHNcblxuIyMgUmVzb3VyY2VzXG5cbiMjIFZvY2FidWxhcnlcblxuIyMgRHVlIERhdGVzYFxuICB9XG59XG4iLCAiLy8gVm9jYWJ1bGFyeSBleHRyYWN0aW9uIGZvciBUdWNrZXJzIFRvb2xzIHBsdWdpblxuXG5pbXBvcnQgeyBBcHAsIFRGaWxlIH0gZnJvbSBcIm9ic2lkaWFuXCJcbmltcG9ydCB7IGdldENvdXJzZUlkRnJvbVBhdGggfSBmcm9tIFwiLi91dGlsc1wiXG5cbmV4cG9ydCBjbGFzcyBWb2NhYnVsYXJ5RXh0cmFjdG9yIHtcbiAgYXBwOiBBcHBcblxuICBjb25zdHJ1Y3RvcihhcHA6IEFwcCkge1xuICAgIHRoaXMuYXBwID0gYXBwXG4gIH1cblxuICBleHRyYWN0Vm9jYWJ1bGFyeUZyb21Ob3RlKGNvbnRlbnQ6IHN0cmluZyk6IHN0cmluZ1tdIHtcbiAgICAvLyBFeHRyYWN0IHZvY2FidWxhcnkgc2VjdGlvbiBmcm9tIG5vdGUgY29udGVudFxuICAgIGNvbnN0IHZvY2FiUmVnZXggPSAvXiMrIFZvY2FidWxhcnkuKlxcbigoPzouKj9cXG4pKj8pKD89XlxccyojXFxzfCQpL21cbiAgICBjb25zdCB2b2NhYk1hdGNoZXMgPSBjb250ZW50Py5tYXRjaCh2b2NhYlJlZ2V4KVxuXG4gICAgaWYgKHZvY2FiTWF0Y2hlcykge1xuICAgICAgY29uc3Qgdm9jYWJEYXRhID0gdm9jYWJNYXRjaGVzWzFdLnRyaW0oKVxuICAgICAgY29uc3QgY2xlYW5lZFZvY2FiID0gdm9jYWJEYXRhXG4gICAgICAgIC5yZXBsYWNlKC9cXFtcXFsuKj9cXF1cXF0vZywgXCJcIikgLy8gUmVtb3ZlIHdpa2lsaW5rc1xuICAgICAgICAucmVwbGFjZSgvXlxccyotXFxzKi9nbSwgXCJcIikgLy8gUmVtb3ZlIGJ1bGxldCBwb2ludHNcbiAgICAgICAgLnNwbGl0KFwiXFxuXCIpXG4gICAgICAgIC5tYXAoKHRlcm0pID0+IHRlcm0udHJpbSgpKVxuICAgICAgICAuZmlsdGVyKCh0ZXJtKSA9PiB0ZXJtLmxlbmd0aCA+IDApXG5cbiAgICAgIHJldHVybiBjbGVhbmVkVm9jYWJcbiAgICB9XG5cbiAgICByZXR1cm4gW11cbiAgfVxuXG4gIGFzeW5jIGV4dHJhY3RWb2NhYnVsYXJ5RnJvbUNvdXJzZShcbiAgICBjb3Vyc2VJZDogc3RyaW5nXG4gICk6IFByb21pc2U8UmVjb3JkPHN0cmluZywgc3RyaW5nW10+PiB7XG4gICAgY29uc29sZS5sb2coYEV4dHJhY3Rpbmcgdm9jYWJ1bGFyeSBmb3IgY291cnNlOiAke2NvdXJzZUlkfWApXG5cbiAgICB0cnkge1xuICAgICAgLy8gRmluZCBhbGwgbm90ZXMgcmVsYXRlZCB0byB0aGUgY291cnNlXG4gICAgICBjb25zdCBjb3Vyc2VOb3RlcyA9IGF3YWl0IHRoaXMuZmluZENvdXJzZU5vdGVzKGNvdXJzZUlkKVxuXG4gICAgICBpZiAoY291cnNlTm90ZXMubGVuZ3RoID09PSAwKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKGBObyBub3RlcyBmb3VuZCBmb3IgY291cnNlOiAke2NvdXJzZUlkfWApXG4gICAgICAgIHJldHVybiB7fVxuICAgICAgfVxuXG4gICAgICAvLyBFeHRyYWN0IHZvY2FidWxhcnkgZnJvbSBlYWNoIG5vdGVcbiAgICAgIGNvbnN0IHZvY2FidWxhcnlEYXRhOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT4gPSB7fVxuXG4gICAgICBmb3IgKGNvbnN0IG5vdGUgb2YgY291cnNlTm90ZXMpIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBjb25zdCBjb250ZW50ID0gYXdhaXQgdGhpcy5hcHAudmF1bHQucmVhZChub3RlKVxuICAgICAgICAgIGNvbnN0IHZvY2FidWxhcnkgPSB0aGlzLmV4dHJhY3RWb2NhYnVsYXJ5RnJvbU5vdGUoY29udGVudClcblxuICAgICAgICAgIGlmICh2b2NhYnVsYXJ5Lmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgIHZvY2FidWxhcnlEYXRhW25vdGUuYmFzZW5hbWVdID0gdm9jYWJ1bGFyeVxuICAgICAgICAgIH1cbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICBjb25zb2xlLmVycm9yKGBFcnJvciByZWFkaW5nIG5vdGUgJHtub3RlLnBhdGh9OmAsIGVycm9yKVxuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIGNvbnNvbGUubG9nKFxuICAgICAgICBgRXh0cmFjdGVkIHZvY2FidWxhcnkgZnJvbSAke1xuICAgICAgICAgIE9iamVjdC5rZXlzKHZvY2FidWxhcnlEYXRhKS5sZW5ndGhcbiAgICAgICAgfSBub3RlcyBmb3IgY291cnNlOiAke2NvdXJzZUlkfWBcbiAgICAgIClcbiAgICAgIHJldHVybiB2b2NhYnVsYXJ5RGF0YVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFxuICAgICAgICBgRXJyb3IgZXh0cmFjdGluZyB2b2NhYnVsYXJ5IGZvciBjb3Vyc2UgJHtjb3Vyc2VJZH06YCxcbiAgICAgICAgZXJyb3JcbiAgICAgIClcbiAgICAgIHJldHVybiB7fVxuICAgIH1cbiAgfVxuXG4gIGFzeW5jIGZpbmRDb3Vyc2VOb3Rlcyhjb3Vyc2VJZDogc3RyaW5nKTogUHJvbWlzZTxURmlsZVtdPiB7XG4gICAgY29uc3Qgbm90ZXM6IFRGaWxlW10gPSBbXVxuXG4gICAgLy8gR2V0IGFsbCBtYXJrZG93biBmaWxlcyBpbiB0aGUgdmF1bHRcbiAgICBjb25zdCBmaWxlcyA9IHRoaXMuYXBwLnZhdWx0LmdldE1hcmtkb3duRmlsZXMoKVxuXG4gICAgZm9yIChjb25zdCBmaWxlIG9mIGZpbGVzKSB7XG4gICAgICAvLyBDaGVjayBpZiB0aGUgZmlsZSBwYXRoIGNvbnRhaW5zIHRoZSBjb3Vyc2UgSURcbiAgICAgIGlmIChcbiAgICAgICAgZmlsZS5wYXRoLmluY2x1ZGVzKGNvdXJzZUlkKSB8fFxuICAgICAgICAoYXdhaXQgdGhpcy5ub3RlQmVsb25nc1RvQ291cnNlKGZpbGUsIGNvdXJzZUlkKSlcbiAgICAgICkge1xuICAgICAgICBub3Rlcy5wdXNoKGZpbGUpXG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIG5vdGVzXG4gIH1cblxuICBwcml2YXRlIGFzeW5jIG5vdGVCZWxvbmdzVG9Db3Vyc2UoXG4gICAgZmlsZTogVEZpbGUsXG4gICAgY291cnNlSWQ6IHN0cmluZ1xuICApOiBQcm9taXNlPGJvb2xlYW4+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgY29udGVudCA9IGF3YWl0IHRoaXMuYXBwLnZhdWx0LnJlYWQoZmlsZSlcbiAgICAgIGNvbnN0IGZyb250bWF0dGVyTWF0Y2ggPSBjb250ZW50Lm1hdGNoKC9eLS0tXFxuKFtcXHNcXFNdKj8pXFxuLS0tLylcblxuICAgICAgaWYgKGZyb250bWF0dGVyTWF0Y2gpIHtcbiAgICAgICAgY29uc3QgZnJvbnRtYXR0ZXIgPSBmcm9udG1hdHRlck1hdGNoWzFdXG4gICAgICAgIC8vIENoZWNrIGlmIGNvdXJzZV9pZCBpcyBpbiB0aGUgZnJvbnRtYXR0ZXJcbiAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICBmcm9udG1hdHRlci5pbmNsdWRlcyhgY291cnNlX2lkOiAke2NvdXJzZUlkfWApIHx8XG4gICAgICAgICAgZnJvbnRtYXR0ZXIuaW5jbHVkZXMoYGNvdXJzZV9pZDoke2NvdXJzZUlkfWApXG4gICAgICAgIClcbiAgICAgIH1cblxuICAgICAgcmV0dXJuIGZhbHNlXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXG4gICAgICAgIGBFcnJvciBjaGVja2luZyBpZiBub3RlICR7ZmlsZS5wYXRofSBiZWxvbmdzIHRvIGNvdXJzZSAke2NvdXJzZUlkfTpgLFxuICAgICAgICBlcnJvclxuICAgICAgKVxuICAgICAgcmV0dXJuIGZhbHNlXG4gICAgfVxuICB9XG5cbiAgYXN5bmMgZ2VuZXJhdGVWb2NhYnVsYXJ5SW5kZXgoXG4gICAgY291cnNlSWQ6IHN0cmluZyxcbiAgICB2b2NhYnVsYXJ5RGF0YTogUmVjb3JkPHN0cmluZywgc3RyaW5nW10+XG4gICk6IFByb21pc2U8c3RyaW5nPiB7XG4gICAgY29uc3QgYWxsVGVybXM6IHN0cmluZ1tdID0gW11cbiAgICBjb25zdCB0ZXJtU291cmNlczogUmVjb3JkPHN0cmluZywgc3RyaW5nW10+ID0ge31cblxuICAgIC8vIENvbGxlY3QgYWxsIHVuaXF1ZSB0ZXJtcyBhbmQgdGhlaXIgc291cmNlc1xuICAgIGZvciAoY29uc3QgW25vdGVOYW1lLCB0ZXJtc10gb2YgT2JqZWN0LmVudHJpZXModm9jYWJ1bGFyeURhdGEpKSB7XG4gICAgICBmb3IgKGNvbnN0IHRlcm0gb2YgdGVybXMpIHtcbiAgICAgICAgaWYgKCFhbGxUZXJtcy5pbmNsdWRlcyh0ZXJtKSkge1xuICAgICAgICAgIGFsbFRlcm1zLnB1c2godGVybSlcbiAgICAgICAgICB0ZXJtU291cmNlc1t0ZXJtXSA9IFtdXG4gICAgICAgIH1cbiAgICAgICAgdGVybVNvdXJjZXNbdGVybV0ucHVzaChub3RlTmFtZSlcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBTb3J0IHRlcm1zIGFscGhhYmV0aWNhbGx5XG4gICAgYWxsVGVybXMuc29ydCgpXG5cbiAgICAvLyBHZW5lcmF0ZSBtYXJrZG93biBjb250ZW50XG4gICAgbGV0IGNvbnRlbnQgPSBgIyBWb2NhYnVsYXJ5IEluZGV4IC0gJHtjb3Vyc2VJZH1cXG5cXG5gXG4gICAgY29udGVudCArPSBgVG90YWwgdW5pcXVlIHRlcm1zOiAke2FsbFRlcm1zLmxlbmd0aH1cXG5cXG5gXG5cbiAgICBmb3IgKGNvbnN0IHRlcm0gb2YgYWxsVGVybXMpIHtcbiAgICAgIGNvbnRlbnQgKz0gYCMjICR7dGVybX1cXG5gXG4gICAgICBjb250ZW50ICs9IGAqKlNvdXJjZXM6KiogJHt0ZXJtU291cmNlc1t0ZXJtXS5qb2luKFwiLCBcIil9XFxuXFxuYFxuICAgICAgY29udGVudCArPSBgKipEZWZpbml0aW9uOioqXFxuXFxuYFxuICAgICAgY29udGVudCArPSBgKipDb250ZXh0OioqXFxuXFxuYFxuICAgICAgY29udGVudCArPSBgKipFeGFtcGxlczoqKlxcblxcbmBcbiAgICAgIGNvbnRlbnQgKz0gYC0tLVxcblxcbmBcbiAgICB9XG5cbiAgICByZXR1cm4gY29udGVudFxuICB9XG5cbiAgYXN5bmMgY3JlYXRlVm9jYWJ1bGFyeUluZGV4RmlsZShjb3Vyc2VJZDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHZvY2FidWxhcnlEYXRhID0gYXdhaXQgdGhpcy5leHRyYWN0Vm9jYWJ1bGFyeUZyb21Db3Vyc2UoY291cnNlSWQpXG5cbiAgICAgIGlmIChPYmplY3Qua2V5cyh2b2NhYnVsYXJ5RGF0YSkubGVuZ3RoID09PSAwKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKGBObyB2b2NhYnVsYXJ5IGZvdW5kIGZvciBjb3Vyc2U6ICR7Y291cnNlSWR9YClcbiAgICAgICAgcmV0dXJuXG4gICAgICB9XG5cbiAgICAgIGNvbnN0IGluZGV4Q29udGVudCA9IGF3YWl0IHRoaXMuZ2VuZXJhdGVWb2NhYnVsYXJ5SW5kZXgoXG4gICAgICAgIGNvdXJzZUlkLFxuICAgICAgICB2b2NhYnVsYXJ5RGF0YVxuICAgICAgKVxuXG4gICAgICAvLyBDcmVhdGUgdGhlIGluZGV4IGZpbGVcbiAgICAgIGNvbnN0IGZpbGVOYW1lID0gYCR7Y291cnNlSWR9IC0gVm9jYWJ1bGFyeSBJbmRleC5tZGBcbiAgICAgIGNvbnN0IGZpbGVQYXRoID0gYENvdXJzZXMvJHtjb3Vyc2VJZH0vJHtmaWxlTmFtZX1gXG5cbiAgICAgIHRyeSB7XG4gICAgICAgIGF3YWl0IHRoaXMuYXBwLnZhdWx0LmNyZWF0ZShmaWxlUGF0aCwgaW5kZXhDb250ZW50KVxuICAgICAgICBjb25zb2xlLmxvZyhgQ3JlYXRlZCB2b2NhYnVsYXJ5IGluZGV4IGZpbGU6ICR7ZmlsZVBhdGh9YClcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIC8vIEZpbGUgbWlnaHQgYWxyZWFkeSBleGlzdCwgdHJ5IHRvIHVwZGF0ZSBpdFxuICAgICAgICBjb25zdCBleGlzdGluZ0ZpbGUgPSB0aGlzLmFwcC52YXVsdC5nZXRBYnN0cmFjdEZpbGVCeVBhdGgoZmlsZVBhdGgpXG4gICAgICAgIGlmIChleGlzdGluZ0ZpbGUgJiYgZXhpc3RpbmdGaWxlIGluc3RhbmNlb2YgVEZpbGUpIHtcbiAgICAgICAgICBhd2FpdCB0aGlzLmFwcC52YXVsdC5tb2RpZnkoZXhpc3RpbmdGaWxlLCBpbmRleENvbnRlbnQpXG4gICAgICAgICAgY29uc29sZS5sb2coYFVwZGF0ZWQgdm9jYWJ1bGFyeSBpbmRleCBmaWxlOiAke2ZpbGVQYXRofWApXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihcbiAgICAgICAgYEVycm9yIGNyZWF0aW5nIHZvY2FidWxhcnkgaW5kZXggZm9yIGNvdXJzZSAke2NvdXJzZUlkfTpgLFxuICAgICAgICBlcnJvclxuICAgICAgKVxuICAgICAgdGhyb3cgZXJyb3JcbiAgICB9XG4gIH1cbn1cbiIsICJpbXBvcnQgeyBBcHAsIFRGaWxlIH0gZnJvbSBcIm9ic2lkaWFuXCJcbmltcG9ydCB7IGlzQmV0d2VlbiB9IGZyb20gXCIuL3V0aWxzXCJcblxuZXhwb3J0IGNsYXNzIER1ZURhdGVzUGFyc2VyIHtcbiAgYXBwOiBBcHBcblxuICBjb25zdHJ1Y3RvcihhcHA6IEFwcCkge1xuICAgIHRoaXMuYXBwID0gYXBwXG4gIH1cblxuICBwYXJzZUR1ZURhdGVzRnJvbU5vdGUoXG4gICAgY29udGVudDogc3RyaW5nXG4gICk6IEFycmF5PHsgZGF0ZTogc3RyaW5nOyBhc3NpZ25tZW50OiBzdHJpbmc7IHN0YXR1czogc3RyaW5nIH0+IHtcbiAgICAvLyBFeHRyYWN0IGR1ZSBkYXRlcyBzZWN0aW9uIGZyb20gbm90ZSBjb250ZW50XG4gICAgY29uc3QgZHVlRGF0ZXNSZWdleCA9IC8jIER1ZSBEYXRlc1tcXHNcXFNdKj8oPz1cXG4jfCQpL1xuICAgIGNvbnN0IG1hdGNoZXMgPSBjb250ZW50Py5tYXRjaChkdWVEYXRlc1JlZ2V4KVxuXG4gICAgaWYgKCFtYXRjaGVzKSB7XG4gICAgICByZXR1cm4gW11cbiAgICB9XG5cbiAgICBjb25zdCBkdWVEYXRlc1NlY3Rpb24gPSBtYXRjaGVzWzBdXG4gICAgY29uc3QgZHVlRGF0ZXMgPSBbXVxuXG4gICAgLy8gTG9vayBmb3IgbWFya2Rvd24gdGFibGVzIGluIHRoZSBkdWUgZGF0ZXMgc2VjdGlvblxuICAgIGNvbnN0IHRhYmxlUmVnZXggPSAvXFx8W1xcc1xcU10qP1xcbi9nXG4gICAgY29uc3QgdGFibGVNYXRjaGVzID0gZHVlRGF0ZXNTZWN0aW9uLm1hdGNoKHRhYmxlUmVnZXgpXG5cbiAgICBpZiAodGFibGVNYXRjaGVzKSB7XG4gICAgICBmb3IgKGNvbnN0IHRhYmxlIG9mIHRhYmxlTWF0Y2hlcykge1xuICAgICAgICBjb25zdCByb3dzID0gdGFibGVcbiAgICAgICAgICAudHJpbSgpXG4gICAgICAgICAgLnNwbGl0KFwiXFxuXCIpXG4gICAgICAgICAgLmZpbHRlcigocm93KSA9PiByb3cuc3RhcnRzV2l0aChcInxcIikpXG4gICAgICAgIGNvbnN0IHBhcnNlZFJvd3MgPSB0aGlzLnBhcnNlVGFibGVSb3dzKHJvd3MpXG4gICAgICAgIGR1ZURhdGVzLnB1c2goLi4ucGFyc2VkUm93cylcbiAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gZHVlRGF0ZXNcbiAgfVxuXG4gIHByaXZhdGUgcGFyc2VUYWJsZVJvd3MoXG4gICAgcm93czogc3RyaW5nW11cbiAgKTogQXJyYXk8eyBkYXRlOiBzdHJpbmc7IGFzc2lnbm1lbnQ6IHN0cmluZzsgc3RhdHVzOiBzdHJpbmcgfT4ge1xuICAgIGlmIChyb3dzLmxlbmd0aCA8IDIpIHJldHVybiBbXSAvLyBOZWVkIGF0IGxlYXN0IGhlYWRlciArIDEgZGF0YSByb3dcblxuICAgIGNvbnN0IGR1ZURhdGVzID0gW11cblxuICAgIGZvciAobGV0IGkgPSAxOyBpIDwgcm93cy5sZW5ndGg7IGkrKykge1xuICAgICAgLy8gU2tpcCBoZWFkZXIgcm93XG4gICAgICBjb25zdCByb3cgPSByb3dzW2ldXG4gICAgICBjb25zdCBjb2x1bW5zID0gcm93XG4gICAgICAgIC5zcGxpdChcInxcIilcbiAgICAgICAgLm1hcCgoY29sKSA9PiBjb2wudHJpbSgpKVxuICAgICAgICAuZmlsdGVyKChjb2wpID0+IGNvbClcblxuICAgICAgaWYgKGNvbHVtbnMubGVuZ3RoID49IDIpIHtcbiAgICAgICAgY29uc3QgW2RhdGUsIGFzc2lnbm1lbnQsIHN0YXR1cyA9IFwicGVuZGluZ1wiXSA9IGNvbHVtbnNcbiAgICAgICAgaWYgKGRhdGUgJiYgYXNzaWdubWVudCAmJiB0aGlzLmlzVmFsaWREYXRlKGRhdGUpKSB7XG4gICAgICAgICAgZHVlRGF0ZXMucHVzaCh7IGRhdGUsIGFzc2lnbm1lbnQsIHN0YXR1cyB9KVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIGR1ZURhdGVzXG4gIH1cblxuICBwcml2YXRlIGlzVmFsaWREYXRlKGRhdGVTdHJpbmc6IHN0cmluZyk6IGJvb2xlYW4ge1xuICAgIGNvbnN0IGRhdGVSZWdleCA9IC9eXFxkezR9LVxcZHsyfS1cXGR7Mn0kL1xuICAgIHJldHVybiBkYXRlUmVnZXgudGVzdChkYXRlU3RyaW5nKSAmJiAhaXNOYU4oRGF0ZS5wYXJzZShkYXRlU3RyaW5nKSlcbiAgfVxuXG4gIGFzeW5jIHBhcnNlRHVlRGF0ZXNGcm9tQ291cnNlKFxuICAgIGNvdXJzZUlkOiBzdHJpbmcsXG4gICAgc3RhcnREYXRlPzogc3RyaW5nLFxuICAgIGVuZERhdGU/OiBzdHJpbmdcbiAgKTogUHJvbWlzZTxcbiAgICBBcnJheTx7IGRhdGU6IHN0cmluZzsgYXNzaWdubWVudDogc3RyaW5nOyBzdGF0dXM6IHN0cmluZzsgc291cmNlOiBzdHJpbmcgfT5cbiAgPiB7XG4gICAgY29uc29sZS5sb2coYFBhcnNpbmcgZHVlIGRhdGVzIGZvciBjb3Vyc2U6ICR7Y291cnNlSWR9YClcblxuICAgIHRyeSB7XG4gICAgICAvLyBGaW5kIGFsbCBub3RlcyByZWxhdGVkIHRvIHRoZSBjb3Vyc2VcbiAgICAgIGNvbnN0IGNvdXJzZU5vdGVzID0gYXdhaXQgdGhpcy5maW5kQ291cnNlTm90ZXMoY291cnNlSWQpXG5cbiAgICAgIGlmIChjb3Vyc2VOb3Rlcy5sZW5ndGggPT09IDApIHtcbiAgICAgICAgY29uc29sZS5sb2coYE5vIG5vdGVzIGZvdW5kIGZvciBjb3Vyc2U6ICR7Y291cnNlSWR9YClcbiAgICAgICAgcmV0dXJuIFtdXG4gICAgICB9XG5cbiAgICAgIC8vIFBhcnNlIGR1ZSBkYXRlcyBmcm9tIGVhY2ggbm90ZVxuICAgICAgY29uc3QgYWxsRHVlRGF0ZXM6IEFycmF5PHtcbiAgICAgICAgZGF0ZTogc3RyaW5nXG4gICAgICAgIGFzc2lnbm1lbnQ6IHN0cmluZ1xuICAgICAgICBzdGF0dXM6IHN0cmluZ1xuICAgICAgICBzb3VyY2U6IHN0cmluZ1xuICAgICAgfT4gPSBbXVxuXG4gICAgICBmb3IgKGNvbnN0IG5vdGUgb2YgY291cnNlTm90ZXMpIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBjb25zdCBjb250ZW50ID0gYXdhaXQgdGhpcy5hcHAudmF1bHQucmVhZChub3RlKVxuICAgICAgICAgIGNvbnN0IGR1ZURhdGVzID0gdGhpcy5wYXJzZUR1ZURhdGVzRnJvbU5vdGUoY29udGVudClcblxuICAgICAgICAgIC8vIEFkZCBzb3VyY2UgaW5mb3JtYXRpb25cbiAgICAgICAgICBjb25zdCBkdWVEYXRlc1dpdGhTb3VyY2UgPSBkdWVEYXRlcy5tYXAoKGR1ZURhdGUpID0+ICh7XG4gICAgICAgICAgICAuLi5kdWVEYXRlLFxuICAgICAgICAgICAgc291cmNlOiBub3RlLmJhc2VuYW1lXG4gICAgICAgICAgfSkpXG5cbiAgICAgICAgICBhbGxEdWVEYXRlcy5wdXNoKC4uLmR1ZURhdGVzV2l0aFNvdXJjZSlcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICBjb25zb2xlLmVycm9yKGBFcnJvciByZWFkaW5nIG5vdGUgJHtub3RlLnBhdGh9OmAsIGVycm9yKVxuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIC8vIEZpbHRlciBieSBkYXRlIHJhbmdlIGlmIHByb3ZpZGVkXG4gICAgICBsZXQgZmlsdGVyZWREdWVEYXRlcyA9IGFsbER1ZURhdGVzXG4gICAgICBpZiAoc3RhcnREYXRlIHx8IGVuZERhdGUpIHtcbiAgICAgICAgZmlsdGVyZWREdWVEYXRlcyA9IHRoaXMuZmlsdGVyQnlEYXRlUmFuZ2UoXG4gICAgICAgICAgYWxsRHVlRGF0ZXMsXG4gICAgICAgICAgc3RhcnREYXRlLFxuICAgICAgICAgIGVuZERhdGVcbiAgICAgICAgKVxuICAgICAgfVxuXG4gICAgICAvLyBTb3J0IGJ5IGRhdGVcbiAgICAgIGZpbHRlcmVkRHVlRGF0ZXMuc29ydChcbiAgICAgICAgKGEsIGIpID0+IG5ldyBEYXRlKGEuZGF0ZSkuZ2V0VGltZSgpIC0gbmV3IERhdGUoYi5kYXRlKS5nZXRUaW1lKClcbiAgICAgIClcblxuICAgICAgY29uc29sZS5sb2coXG4gICAgICAgIGBGb3VuZCAke2ZpbHRlcmVkRHVlRGF0ZXMubGVuZ3RofSBkdWUgZGF0ZXMgZm9yIGNvdXJzZTogJHtjb3Vyc2VJZH1gXG4gICAgICApXG4gICAgICByZXR1cm4gZmlsdGVyZWREdWVEYXRlc1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKGBFcnJvciBwYXJzaW5nIGR1ZSBkYXRlcyBmb3IgY291cnNlICR7Y291cnNlSWR9OmAsIGVycm9yKVxuICAgICAgcmV0dXJuIFtdXG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBmaW5kQ291cnNlTm90ZXMoY291cnNlSWQ6IHN0cmluZyk6IFByb21pc2U8VEZpbGVbXT4ge1xuICAgIGNvbnN0IG5vdGVzOiBURmlsZVtdID0gW11cblxuICAgIC8vIEdldCBhbGwgbWFya2Rvd24gZmlsZXMgaW4gdGhlIHZhdWx0XG4gICAgY29uc3QgZmlsZXMgPSB0aGlzLmFwcC52YXVsdC5nZXRNYXJrZG93bkZpbGVzKClcblxuICAgIGZvciAoY29uc3QgZmlsZSBvZiBmaWxlcykge1xuICAgICAgLy8gQ2hlY2sgaWYgdGhlIGZpbGUgcGF0aCBjb250YWlucyB0aGUgY291cnNlIElEIG9yIGJlbG9uZ3MgdG8gdGhlIGNvdXJzZVxuICAgICAgaWYgKFxuICAgICAgICBmaWxlLnBhdGguaW5jbHVkZXMoY291cnNlSWQpIHx8XG4gICAgICAgIChhd2FpdCB0aGlzLm5vdGVCZWxvbmdzVG9Db3Vyc2UoZmlsZSwgY291cnNlSWQpKVxuICAgICAgKSB7XG4gICAgICAgIG5vdGVzLnB1c2goZmlsZSlcbiAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gbm90ZXNcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgbm90ZUJlbG9uZ3NUb0NvdXJzZShcbiAgICBmaWxlOiBURmlsZSxcbiAgICBjb3Vyc2VJZDogc3RyaW5nXG4gICk6IFByb21pc2U8Ym9vbGVhbj4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBjb250ZW50ID0gYXdhaXQgdGhpcy5hcHAudmF1bHQucmVhZChmaWxlKVxuICAgICAgY29uc3QgZnJvbnRtYXR0ZXJNYXRjaCA9IGNvbnRlbnQubWF0Y2goL14tLS1cXG4oW1xcc1xcU10qPylcXG4tLS0vKVxuXG4gICAgICBpZiAoZnJvbnRtYXR0ZXJNYXRjaCkge1xuICAgICAgICBjb25zdCBmcm9udG1hdHRlciA9IGZyb250bWF0dGVyTWF0Y2hbMV1cbiAgICAgICAgLy8gQ2hlY2sgaWYgY291cnNlX2lkIGlzIGluIHRoZSBmcm9udG1hdHRlclxuICAgICAgICByZXR1cm4gKFxuICAgICAgICAgIGZyb250bWF0dGVyLmluY2x1ZGVzKGBjb3Vyc2VfaWQ6ICR7Y291cnNlSWR9YCkgfHxcbiAgICAgICAgICBmcm9udG1hdHRlci5pbmNsdWRlcyhgY291cnNlX2lkOiR7Y291cnNlSWR9YClcbiAgICAgICAgKVxuICAgICAgfVxuXG4gICAgICByZXR1cm4gZmFsc2VcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihcbiAgICAgICAgYEVycm9yIGNoZWNraW5nIGlmIG5vdGUgJHtmaWxlLnBhdGh9IGJlbG9uZ3MgdG8gY291cnNlICR7Y291cnNlSWR9OmAsXG4gICAgICAgIGVycm9yXG4gICAgICApXG4gICAgICByZXR1cm4gZmFsc2VcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGZpbHRlckJ5RGF0ZVJhbmdlKFxuICAgIGR1ZURhdGVzOiBBcnJheTx7XG4gICAgICBkYXRlOiBzdHJpbmdcbiAgICAgIGFzc2lnbm1lbnQ6IHN0cmluZ1xuICAgICAgc3RhdHVzOiBzdHJpbmdcbiAgICAgIHNvdXJjZTogc3RyaW5nXG4gICAgfT4sXG4gICAgc3RhcnREYXRlPzogc3RyaW5nLFxuICAgIGVuZERhdGU/OiBzdHJpbmdcbiAgKTogQXJyYXk8e1xuICAgIGRhdGU6IHN0cmluZ1xuICAgIGFzc2lnbm1lbnQ6IHN0cmluZ1xuICAgIHN0YXR1czogc3RyaW5nXG4gICAgc291cmNlOiBzdHJpbmdcbiAgfT4ge1xuICAgIHJldHVybiBkdWVEYXRlcy5maWx0ZXIoKGR1ZURhdGUpID0+IHtcbiAgICAgIGNvbnN0IGR1ZURhdGVUaW1lID0gbmV3IERhdGUoZHVlRGF0ZS5kYXRlKS5nZXRUaW1lKClcblxuICAgICAgaWYgKHN0YXJ0RGF0ZSAmJiBkdWVEYXRlVGltZSA8IG5ldyBEYXRlKHN0YXJ0RGF0ZSkuZ2V0VGltZSgpKSB7XG4gICAgICAgIHJldHVybiBmYWxzZVxuICAgICAgfVxuXG4gICAgICBpZiAoZW5kRGF0ZSAmJiBkdWVEYXRlVGltZSA+IG5ldyBEYXRlKGVuZERhdGUpLmdldFRpbWUoKSkge1xuICAgICAgICByZXR1cm4gZmFsc2VcbiAgICAgIH1cblxuICAgICAgcmV0dXJuIHRydWVcbiAgICB9KVxuICB9XG5cbiAgYXN5bmMgZ2VuZXJhdGVEdWVEYXRlc1N1bW1hcnkoXG4gICAgY291cnNlSWQ6IHN0cmluZyxcbiAgICBkdWVEYXRlczogQXJyYXk8e1xuICAgICAgZGF0ZTogc3RyaW5nXG4gICAgICBhc3NpZ25tZW50OiBzdHJpbmdcbiAgICAgIHN0YXR1czogc3RyaW5nXG4gICAgICBzb3VyY2U6IHN0cmluZ1xuICAgIH0+XG4gICk6IFByb21pc2U8c3RyaW5nPiB7XG4gICAgaWYgKGR1ZURhdGVzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgcmV0dXJuIGAjIER1ZSBEYXRlcyBTdW1tYXJ5IC0gJHtjb3Vyc2VJZH1cXG5cXG5ObyBkdWUgZGF0ZXMgZm91bmQuXFxuYFxuICAgIH1cblxuICAgIC8vIEdyb3VwIGJ5IHN0YXR1c1xuICAgIGNvbnN0IGJ5U3RhdHVzID0gZHVlRGF0ZXMucmVkdWNlKChhY2MsIGR1ZURhdGUpID0+IHtcbiAgICAgIGlmICghYWNjW2R1ZURhdGUuc3RhdHVzXSkge1xuICAgICAgICBhY2NbZHVlRGF0ZS5zdGF0dXNdID0gW11cbiAgICAgIH1cbiAgICAgIGFjY1tkdWVEYXRlLnN0YXR1c10ucHVzaChkdWVEYXRlKVxuICAgICAgcmV0dXJuIGFjY1xuICAgIH0sIHt9IGFzIFJlY29yZDxzdHJpbmcsIHR5cGVvZiBkdWVEYXRlcz4pXG5cbiAgICBsZXQgY29udGVudCA9IGAjIER1ZSBEYXRlcyBTdW1tYXJ5IC0gJHtjb3Vyc2VJZH1cXG5cXG5gXG4gICAgY29udGVudCArPSBgVG90YWwgYXNzaWdubWVudHM6ICR7ZHVlRGF0ZXMubGVuZ3RofVxcblxcbmBcblxuICAgIC8vIEFkZCBzdW1tYXJ5IGJ5IHN0YXR1c1xuICAgIGZvciAoY29uc3QgW3N0YXR1cywgaXRlbXNdIG9mIE9iamVjdC5lbnRyaWVzKGJ5U3RhdHVzKSkge1xuICAgICAgY29udGVudCArPSBgIyMgJHtzdGF0dXMuY2hhckF0KDApLnRvVXBwZXJDYXNlKCkgKyBzdGF0dXMuc2xpY2UoMSl9ICgke1xuICAgICAgICBpdGVtcy5sZW5ndGhcbiAgICAgIH0pXFxuXFxuYFxuICAgICAgY29udGVudCArPSBgfCBEYXRlIHwgQXNzaWdubWVudCB8IFNvdXJjZSB8XFxuYFxuICAgICAgY29udGVudCArPSBgfCAtLS0tIHwgLS0tLS0tLS0tLSB8IC0tLS0tLSB8XFxuYFxuXG4gICAgICBmb3IgKGNvbnN0IGl0ZW0gb2YgaXRlbXMpIHtcbiAgICAgICAgY29udGVudCArPSBgfCAke2l0ZW0uZGF0ZX0gfCAke2l0ZW0uYXNzaWdubWVudH0gfCAke2l0ZW0uc291cmNlfSB8XFxuYFxuICAgICAgfVxuICAgICAgY29udGVudCArPSBgXFxuYFxuICAgIH1cblxuICAgIHJldHVybiBjb250ZW50XG4gIH1cblxuICBhc3luYyBjcmVhdGVEdWVEYXRlc1N1bW1hcnlGaWxlKFxuICAgIGNvdXJzZUlkOiBzdHJpbmcsXG4gICAgc3RhcnREYXRlPzogc3RyaW5nLFxuICAgIGVuZERhdGU/OiBzdHJpbmdcbiAgKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGR1ZURhdGVzID0gYXdhaXQgdGhpcy5wYXJzZUR1ZURhdGVzRnJvbUNvdXJzZShcbiAgICAgICAgY291cnNlSWQsXG4gICAgICAgIHN0YXJ0RGF0ZSxcbiAgICAgICAgZW5kRGF0ZVxuICAgICAgKVxuXG4gICAgICBjb25zdCBzdW1tYXJ5Q29udGVudCA9IGF3YWl0IHRoaXMuZ2VuZXJhdGVEdWVEYXRlc1N1bW1hcnkoXG4gICAgICAgIGNvdXJzZUlkLFxuICAgICAgICBkdWVEYXRlc1xuICAgICAgKVxuXG4gICAgICAvLyBDcmVhdGUgdGhlIHN1bW1hcnkgZmlsZVxuICAgICAgY29uc3QgZmlsZU5hbWUgPSBgJHtjb3Vyc2VJZH0gLSBEdWUgRGF0ZXMgU3VtbWFyeS5tZGBcbiAgICAgIGNvbnN0IGZpbGVQYXRoID0gYENvdXJzZXMvJHtjb3Vyc2VJZH0vJHtmaWxlTmFtZX1gXG5cbiAgICAgIHRyeSB7XG4gICAgICAgIGF3YWl0IHRoaXMuYXBwLnZhdWx0LmNyZWF0ZShmaWxlUGF0aCwgc3VtbWFyeUNvbnRlbnQpXG4gICAgICAgIGNvbnNvbGUubG9nKGBDcmVhdGVkIGR1ZSBkYXRlcyBzdW1tYXJ5IGZpbGU6ICR7ZmlsZVBhdGh9YClcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIC8vIEZpbGUgbWlnaHQgYWxyZWFkeSBleGlzdCwgdHJ5IHRvIHVwZGF0ZSBpdFxuICAgICAgICBjb25zdCBleGlzdGluZ0ZpbGUgPSB0aGlzLmFwcC52YXVsdC5nZXRBYnN0cmFjdEZpbGVCeVBhdGgoZmlsZVBhdGgpXG4gICAgICAgIGlmIChleGlzdGluZ0ZpbGUgJiYgZXhpc3RpbmdGaWxlIGluc3RhbmNlb2YgVEZpbGUpIHtcbiAgICAgICAgICBhd2FpdCB0aGlzLmFwcC52YXVsdC5tb2RpZnkoZXhpc3RpbmdGaWxlLCBzdW1tYXJ5Q29udGVudClcbiAgICAgICAgICBjb25zb2xlLmxvZyhgVXBkYXRlZCBkdWUgZGF0ZXMgc3VtbWFyeSBmaWxlOiAke2ZpbGVQYXRofWApXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihcbiAgICAgICAgYEVycm9yIGNyZWF0aW5nIGR1ZSBkYXRlcyBzdW1tYXJ5IGZvciBjb3Vyc2UgJHtjb3Vyc2VJZH06YCxcbiAgICAgICAgZXJyb3JcbiAgICAgIClcbiAgICAgIHRocm93IGVycm9yXG4gICAgfVxuICB9XG59XG4iLCAiLy8gRGFpbHkgbm90ZXMgaW50ZWdyYXRpb24gZm9yIFR1Y2tlcnMgVG9vbHMgcGx1Z2luXG5cbmltcG9ydCB7IEFwcCwgVEZpbGUgfSBmcm9tIFwib2JzaWRpYW5cIlxuXG5leHBvcnQgY2xhc3MgRGFpbHlOb3Rlc0ludGVncmF0aW9uIHtcbiAgYXBwOiBBcHBcblxuICBjb25zdHJ1Y3RvcihhcHA6IEFwcCkge1xuICAgIHRoaXMuYXBwID0gYXBwXG4gIH1cblxuICBhc3luYyBnZXRUb2RheXNBY3Rpdml0aWVzKCk6IFByb21pc2U8XG4gICAgQXJyYXk8eyBmaWxlOiBzdHJpbmc7IHR5cGU6IHN0cmluZzsgY291cnNlPzogc3RyaW5nIH0+XG4gID4ge1xuICAgIGNvbnNvbGUubG9nKFwiR2V0dGluZyB0b2RheSdzIGFjYWRlbWljIGFjdGl2aXRpZXNcIilcblxuICAgIHRyeSB7XG4gICAgICBjb25zdCB0b2RheSA9IG5ldyBEYXRlKClcbiAgICAgIGNvbnN0IHRvZGF5U3RyaW5nID0gdG9kYXkudG9JU09TdHJpbmcoKS5zcGxpdChcIlRcIilbMF1cblxuICAgICAgLy8gRmluZCBmaWxlcyBjcmVhdGVkIG9yIG1vZGlmaWVkIHRvZGF5XG4gICAgICBjb25zdCBmaWxlcyA9IHRoaXMuYXBwLnZhdWx0LmdldE1hcmtkb3duRmlsZXMoKVxuICAgICAgY29uc3QgdG9kYXlzRmlsZXM6IFRGaWxlW10gPSBbXVxuXG4gICAgICBmb3IgKGNvbnN0IGZpbGUgb2YgZmlsZXMpIHtcbiAgICAgICAgY29uc3QgZmlsZURhdGUgPSB0aGlzLmV4dHJhY3REYXRlRnJvbVBhdGgoZmlsZS5wYXRoKVxuICAgICAgICBpZiAoZmlsZURhdGUgPT09IHRvZGF5U3RyaW5nKSB7XG4gICAgICAgICAgdG9kYXlzRmlsZXMucHVzaChmaWxlKVxuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIC8vIEFuYWx5emUgYWN0aXZpdGllc1xuICAgICAgY29uc3QgYWN0aXZpdGllczogQXJyYXk8eyBmaWxlOiBzdHJpbmc7IHR5cGU6IHN0cmluZzsgY291cnNlPzogc3RyaW5nIH0+ID1cbiAgICAgICAgW11cblxuICAgICAgZm9yIChjb25zdCBmaWxlIG9mIHRvZGF5c0ZpbGVzKSB7XG4gICAgICAgIGNvbnN0IGFjdGl2aXR5ID0gYXdhaXQgdGhpcy5hbmFseXplRmlsZUFjdGl2aXR5KGZpbGUpXG4gICAgICAgIGlmIChhY3Rpdml0eSkge1xuICAgICAgICAgIGFjdGl2aXRpZXMucHVzaChhY3Rpdml0eSlcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICBjb25zb2xlLmxvZyhgRm91bmQgJHthY3Rpdml0aWVzLmxlbmd0aH0gYWNhZGVtaWMgYWN0aXZpdGllcyBmb3IgdG9kYXlgKVxuICAgICAgcmV0dXJuIGFjdGl2aXRpZXNcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGdldHRpbmcgdG9kYXkncyBhY3Rpdml0aWVzOlwiLCBlcnJvcilcbiAgICAgIHJldHVybiBbXVxuICAgIH1cbiAgfVxuXG4gIGFzeW5jIGdldENvdXJzZUFjdGl2aXR5Rm9yRGF0ZShcbiAgICBjb3Vyc2VJZDogc3RyaW5nLFxuICAgIGRhdGU6IHN0cmluZ1xuICApOiBQcm9taXNlPEFycmF5PHsgZmlsZTogc3RyaW5nOyB0eXBlOiBzdHJpbmcgfT4+IHtcbiAgICBjb25zb2xlLmxvZyhgR2V0dGluZyBhY3Rpdml0eSBmb3IgY291cnNlICR7Y291cnNlSWR9IG9uIGRhdGUgJHtkYXRlfWApXG5cbiAgICB0cnkge1xuICAgICAgLy8gRmluZCBmaWxlcyByZWxhdGVkIHRvIHRoZSBjb3Vyc2UgbW9kaWZpZWQgb24gdGhlIGRhdGVcbiAgICAgIGNvbnN0IGNvdXJzZUZpbGVzID0gYXdhaXQgdGhpcy5maW5kQ291cnNlRmlsZXNGb3JEYXRlKGNvdXJzZUlkLCBkYXRlKVxuXG4gICAgICBjb25zdCBhY3Rpdml0aWVzOiBBcnJheTx7IGZpbGU6IHN0cmluZzsgdHlwZTogc3RyaW5nIH0+ID0gW11cblxuICAgICAgZm9yIChjb25zdCBmaWxlIG9mIGNvdXJzZUZpbGVzKSB7XG4gICAgICAgIGNvbnN0IGNvbnRlbnQgPSBhd2FpdCB0aGlzLmFwcC52YXVsdC5yZWFkKGZpbGUpXG4gICAgICAgIGNvbnN0IGZpbGVUeXBlID0gdGhpcy5kZXRlcm1pbmVGaWxlVHlwZShmaWxlLCBjb250ZW50KVxuXG4gICAgICAgIGFjdGl2aXRpZXMucHVzaCh7XG4gICAgICAgICAgZmlsZTogZmlsZS5iYXNlbmFtZSxcbiAgICAgICAgICB0eXBlOiBmaWxlVHlwZVxuICAgICAgICB9KVxuICAgICAgfVxuXG4gICAgICBjb25zb2xlLmxvZyhcbiAgICAgICAgYEZvdW5kICR7YWN0aXZpdGllcy5sZW5ndGh9IGFjdGl2aXRpZXMgZm9yIGNvdXJzZSAke2NvdXJzZUlkfSBvbiAke2RhdGV9YFxuICAgICAgKVxuICAgICAgcmV0dXJuIGFjdGl2aXRpZXNcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihcbiAgICAgICAgYEVycm9yIGdldHRpbmcgY291cnNlIGFjdGl2aXR5IGZvciAke2NvdXJzZUlkfSBvbiAke2RhdGV9OmAsXG4gICAgICAgIGVycm9yXG4gICAgICApXG4gICAgICByZXR1cm4gW11cbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGV4dHJhY3REYXRlRnJvbVBhdGgoZmlsZVBhdGg6IHN0cmluZyk6IHN0cmluZyB8IG51bGwge1xuICAgIC8vIFRyeSB0byBleHRyYWN0IGRhdGUgZnJvbSBmaWxlIHBhdGggKGUuZy4sIFwiRGFpbHkvMjAyNS0wMS0xNS5tZFwiIC0+IFwiMjAyNS0wMS0xNVwiKVxuICAgIGNvbnN0IGRhdGVSZWdleCA9IC8oXFxkezR9LVxcZHsyfS1cXGR7Mn0pL2dcbiAgICBjb25zdCBtYXRjaGVzID0gZmlsZVBhdGgubWF0Y2goZGF0ZVJlZ2V4KVxuICAgIHJldHVybiBtYXRjaGVzID8gbWF0Y2hlc1ttYXRjaGVzLmxlbmd0aCAtIDFdIDogbnVsbFxuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBhbmFseXplRmlsZUFjdGl2aXR5KFxuICAgIGZpbGU6IFRGaWxlXG4gICk6IFByb21pc2U8eyBmaWxlOiBzdHJpbmc7IHR5cGU6IHN0cmluZzsgY291cnNlPzogc3RyaW5nIH0gfCBudWxsPiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGNvbnRlbnQgPSBhd2FpdCB0aGlzLmFwcC52YXVsdC5yZWFkKGZpbGUpXG5cbiAgICAgIC8vIERldGVybWluZSBmaWxlIHR5cGUgYmFzZWQgb24gY29udGVudCBhbmQgcGF0aFxuICAgICAgY29uc3QgZmlsZVR5cGUgPSB0aGlzLmRldGVybWluZUZpbGVUeXBlKGZpbGUsIGNvbnRlbnQpXG5cbiAgICAgIC8vIEV4dHJhY3QgY291cnNlIElEIGlmIGFwcGxpY2FibGVcbiAgICAgIGNvbnN0IGNvdXJzZUlkID1cbiAgICAgICAgdGhpcy5leHRyYWN0Q291cnNlSWRGcm9tQ29udGVudChjb250ZW50KSB8fFxuICAgICAgICB0aGlzLmV4dHJhY3RDb3Vyc2VJZEZyb21QYXRoKGZpbGUucGF0aClcblxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgZmlsZTogZmlsZS5iYXNlbmFtZSxcbiAgICAgICAgdHlwZTogZmlsZVR5cGUsXG4gICAgICAgIGNvdXJzZTogY291cnNlSWQgfHwgdW5kZWZpbmVkXG4gICAgICB9XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIGFuYWx5emluZyBmaWxlICR7ZmlsZS5wYXRofTpgLCBlcnJvcilcbiAgICAgIHJldHVybiBudWxsXG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSBkZXRlcm1pbmVGaWxlVHlwZShmaWxlOiBURmlsZSwgY29udGVudDogc3RyaW5nKTogc3RyaW5nIHtcbiAgICBjb25zdCBwYXRoID0gZmlsZS5wYXRoLnRvTG93ZXJDYXNlKClcblxuICAgIC8vIENoZWNrIGZvciBkYWlseSBub3Rlc1xuICAgIGlmIChcbiAgICAgIHBhdGguaW5jbHVkZXMoXCJkYWlseVwiKSB8fFxuICAgICAgY29udGVudC5pbmNsdWRlcyhcImNvbnRlbnRfdHlwZTogZGFpbHlfbm90ZVwiKVxuICAgICkge1xuICAgICAgcmV0dXJuIFwiZGFpbHlfbm90ZVwiXG4gICAgfVxuXG4gICAgLy8gQ2hlY2sgZm9yIGNvdXJzZS1yZWxhdGVkIGZpbGVzXG4gICAgaWYgKHBhdGguaW5jbHVkZXMoXCJjb3Vyc2VzXCIpIHx8IGNvbnRlbnQuaW5jbHVkZXMoXCJjb3Vyc2VfaWQ6XCIpKSB7XG4gICAgICBpZiAoY29udGVudC5pbmNsdWRlcyhcImNvbnRlbnRfdHlwZTogY291cnNlX2hvbWVwYWdlXCIpKSB7XG4gICAgICAgIHJldHVybiBcImNvdXJzZV9ob21lcGFnZVwiXG4gICAgICB9XG4gICAgICBpZiAoY29udGVudC5pbmNsdWRlcyhcImNvbnRlbnRfdHlwZTogbW9kdWxlXCIpKSB7XG4gICAgICAgIHJldHVybiBcIm1vZHVsZVwiXG4gICAgICB9XG4gICAgICBpZiAoY29udGVudC5pbmNsdWRlcyhcImNvbnRlbnRfdHlwZTogY2hhcHRlclwiKSkge1xuICAgICAgICByZXR1cm4gXCJjaGFwdGVyXCJcbiAgICAgIH1cbiAgICAgIGlmIChjb250ZW50LmluY2x1ZGVzKFwiY29udGVudF90eXBlOiBhc3NpZ25tZW50XCIpKSB7XG4gICAgICAgIHJldHVybiBcImFzc2lnbm1lbnRcIlxuICAgICAgfVxuICAgICAgcmV0dXJuIFwiY291cnNlX25vdGVcIlxuICAgIH1cblxuICAgIC8vIENoZWNrIGZvciB2b2NhYnVsYXJ5IGVudHJpZXNcbiAgICBpZiAoY29udGVudC5pbmNsdWRlcyhcIiMjIFwiKSAmJiBjb250ZW50Lm1hdGNoKC9eXFwqXFwqVGVybVxcKlxcKjovbSkpIHtcbiAgICAgIHJldHVybiBcInZvY2FidWxhcnlfZW50cnlcIlxuICAgIH1cblxuICAgIHJldHVybiBcIm90aGVyXCJcbiAgfVxuXG4gIHByaXZhdGUgZXh0cmFjdENvdXJzZUlkRnJvbUNvbnRlbnQoY29udGVudDogc3RyaW5nKTogc3RyaW5nIHwgbnVsbCB7XG4gICAgY29uc3QgY291cnNlSWRSZWdleCA9IC9jb3Vyc2VfaWQ6XFxzKihbQS1aXXsyLDR9LVxcZHszfSkvXG4gICAgY29uc3QgbWF0Y2ggPSBjb250ZW50Lm1hdGNoKGNvdXJzZUlkUmVnZXgpXG4gICAgcmV0dXJuIG1hdGNoID8gbWF0Y2hbMV0gOiBudWxsXG4gIH1cblxuICBwcml2YXRlIGV4dHJhY3RDb3Vyc2VJZEZyb21QYXRoKGZpbGVQYXRoOiBzdHJpbmcpOiBzdHJpbmcgfCBudWxsIHtcbiAgICBjb25zdCBjb3Vyc2VJZFJlZ2V4ID0gLyhbQS1aXXsyLDR9LVxcZHszfSkvZ1xuICAgIGNvbnN0IG1hdGNoZXMgPSBmaWxlUGF0aC5tYXRjaChjb3Vyc2VJZFJlZ2V4KVxuICAgIHJldHVybiBtYXRjaGVzID8gbWF0Y2hlc1ttYXRjaGVzLmxlbmd0aCAtIDFdIDogbnVsbFxuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBmaW5kQ291cnNlRmlsZXNGb3JEYXRlKFxuICAgIGNvdXJzZUlkOiBzdHJpbmcsXG4gICAgZGF0ZTogc3RyaW5nXG4gICk6IFByb21pc2U8VEZpbGVbXT4ge1xuICAgIGNvbnN0IGZpbGVzOiBURmlsZVtdID0gW11cblxuICAgIC8vIEdldCBhbGwgZmlsZXMgYW5kIGZpbHRlciBieSBjb3Vyc2UgSUQgYW5kIGRhdGVcbiAgICBjb25zdCBhbGxGaWxlcyA9IHRoaXMuYXBwLnZhdWx0LmdldE1hcmtkb3duRmlsZXMoKVxuXG4gICAgZm9yIChjb25zdCBmaWxlIG9mIGFsbEZpbGVzKSB7XG4gICAgICAvLyBDaGVjayBpZiBmaWxlIGJlbG9uZ3MgdG8gdGhlIGNvdXJzZVxuICAgICAgaWYgKFxuICAgICAgICBmaWxlLnBhdGguaW5jbHVkZXMoY291cnNlSWQpIHx8XG4gICAgICAgIChhd2FpdCB0aGlzLmZpbGVCZWxvbmdzVG9Db3Vyc2UoZmlsZSwgY291cnNlSWQpKVxuICAgICAgKSB7XG4gICAgICAgIC8vIENoZWNrIGlmIGZpbGUgd2FzIG1vZGlmaWVkIG9uIHRoZSBzcGVjaWZpZWQgZGF0ZVxuICAgICAgICBjb25zdCBmaWxlRGF0ZSA9IHRoaXMuZXh0cmFjdERhdGVGcm9tUGF0aChmaWxlLnBhdGgpXG4gICAgICAgIGlmIChmaWxlRGF0ZSA9PT0gZGF0ZSkge1xuICAgICAgICAgIGZpbGVzLnB1c2goZmlsZSlcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBmaWxlc1xuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBmaWxlQmVsb25nc1RvQ291cnNlKFxuICAgIGZpbGU6IFRGaWxlLFxuICAgIGNvdXJzZUlkOiBzdHJpbmdcbiAgKTogUHJvbWlzZTxib29sZWFuPiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGNvbnRlbnQgPSBhd2FpdCB0aGlzLmFwcC52YXVsdC5yZWFkKGZpbGUpXG4gICAgICByZXR1cm4gdGhpcy5leHRyYWN0Q291cnNlSWRGcm9tQ29udGVudChjb250ZW50KSA9PT0gY291cnNlSWRcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihcbiAgICAgICAgYEVycm9yIGNoZWNraW5nIGlmIGZpbGUgJHtmaWxlLnBhdGh9IGJlbG9uZ3MgdG8gY291cnNlICR7Y291cnNlSWR9OmAsXG4gICAgICAgIGVycm9yXG4gICAgICApXG4gICAgICByZXR1cm4gZmFsc2VcbiAgICB9XG4gIH1cblxuICBhc3luYyBnZW5lcmF0ZURhaWx5U3VtbWFyeShkYXRlPzogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgICBjb25zdCB0YXJnZXREYXRlID0gZGF0ZSB8fCBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc3BsaXQoXCJUXCIpWzBdXG4gICAgY29uc3QgYWN0aXZpdGllcyA9IGF3YWl0IHRoaXMuZ2V0Q291cnNlQWN0aXZpdHlGb3JEYXRlKFwiXCIsIHRhcmdldERhdGUpXG5cbiAgICBpZiAoYWN0aXZpdGllcy5sZW5ndGggPT09IDApIHtcbiAgICAgIHJldHVybiBgIyBBY2FkZW1pYyBBY3Rpdml0aWVzIC0gJHt0YXJnZXREYXRlfVxcblxcbk5vIGFjYWRlbWljIGFjdGl2aXRpZXMgcmVjb3JkZWQgZm9yIHRoaXMgZGF0ZS5cXG5gXG4gICAgfVxuXG4gICAgLy8gR3JvdXAgYWN0aXZpdGllcyBieSBjb3Vyc2VcbiAgICBjb25zdCBieUNvdXJzZTogUmVjb3JkPHN0cmluZywgdHlwZW9mIGFjdGl2aXRpZXM+ID0ge31cbiAgICBjb25zdCBub0NvdXJzZTogdHlwZW9mIGFjdGl2aXRpZXMgPSBbXVxuXG4gICAgZm9yIChjb25zdCBhY3Rpdml0eSBvZiBhY3Rpdml0aWVzKSB7XG4gICAgICBpZiAoYWN0aXZpdHkuZmlsZS5pbmNsdWRlcyhcIkNvdXJzZXMvXCIpKSB7XG4gICAgICAgIC8vIEV4dHJhY3QgY291cnNlIElEIGZyb20gcGF0aFxuICAgICAgICBjb25zdCBwYXRoUGFydHMgPSBhY3Rpdml0eS5maWxlLnNwbGl0KFwiL1wiKVxuICAgICAgICBjb25zdCBjb3Vyc2VJbmRleCA9IHBhdGhQYXJ0cy5maW5kSW5kZXgoKHBhcnQpID0+IHBhcnQuaW5jbHVkZXMoXCItXCIpKVxuICAgICAgICBpZiAoY291cnNlSW5kZXggPj0gMCkge1xuICAgICAgICAgIGNvbnN0IGNvdXJzZUlkID0gcGF0aFBhcnRzW2NvdXJzZUluZGV4XVxuICAgICAgICAgIGlmICghYnlDb3Vyc2VbY291cnNlSWRdKSB7XG4gICAgICAgICAgICBieUNvdXJzZVtjb3Vyc2VJZF0gPSBbXVxuICAgICAgICAgIH1cbiAgICAgICAgICBieUNvdXJzZVtjb3Vyc2VJZF0ucHVzaChhY3Rpdml0eSlcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBub0NvdXJzZS5wdXNoKGFjdGl2aXR5KVxuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBub0NvdXJzZS5wdXNoKGFjdGl2aXR5KVxuICAgICAgfVxuICAgIH1cblxuICAgIGxldCBjb250ZW50ID0gYCMgQWNhZGVtaWMgQWN0aXZpdGllcyAtICR7dGFyZ2V0RGF0ZX1cXG5cXG5gXG4gICAgY29udGVudCArPSBgVG90YWwgYWN0aXZpdGllczogJHthY3Rpdml0aWVzLmxlbmd0aH1cXG5cXG5gXG5cbiAgICAvLyBBZGQgYWN0aXZpdGllcyBieSBjb3Vyc2VcbiAgICBmb3IgKGNvbnN0IFtjb3Vyc2VJZCwgY291cnNlQWN0aXZpdGllc10gb2YgT2JqZWN0LmVudHJpZXMoYnlDb3Vyc2UpKSB7XG4gICAgICBjb250ZW50ICs9IGAjIyAke2NvdXJzZUlkfVxcblxcbmBcbiAgICAgIGNvbnRlbnQgKz0gYHwgRmlsZSB8IFR5cGUgfFxcbmBcbiAgICAgIGNvbnRlbnQgKz0gYHwgLS0tLSB8IC0tLS0gfFxcbmBcblxuICAgICAgZm9yIChjb25zdCBhY3Rpdml0eSBvZiBjb3Vyc2VBY3Rpdml0aWVzKSB7XG4gICAgICAgIGNvbnRlbnQgKz0gYHwgJHthY3Rpdml0eS5maWxlfSB8ICR7YWN0aXZpdHkudHlwZX0gfFxcbmBcbiAgICAgIH1cbiAgICAgIGNvbnRlbnQgKz0gYFxcbmBcbiAgICB9XG5cbiAgICAvLyBBZGQgYWN0aXZpdGllcyB3aXRob3V0IHNwZWNpZmljIGNvdXJzZVxuICAgIGlmIChub0NvdXJzZS5sZW5ndGggPiAwKSB7XG4gICAgICBjb250ZW50ICs9IGAjIyBPdGhlciBBY3Rpdml0aWVzXFxuXFxuYFxuICAgICAgY29udGVudCArPSBgfCBGaWxlIHwgVHlwZSB8XFxuYFxuICAgICAgY29udGVudCArPSBgfCAtLS0tIHwgLS0tLSB8XFxuYFxuXG4gICAgICBmb3IgKGNvbnN0IGFjdGl2aXR5IG9mIG5vQ291cnNlKSB7XG4gICAgICAgIGNvbnRlbnQgKz0gYHwgJHthY3Rpdml0eS5maWxlfSB8ICR7YWN0aXZpdHkudHlwZX0gfFxcbmBcbiAgICAgIH1cbiAgICAgIGNvbnRlbnQgKz0gYFxcbmBcbiAgICB9XG5cbiAgICByZXR1cm4gY29udGVudFxuICB9XG5cbiAgYXN5bmMgY3JlYXRlRGFpbHlTdW1tYXJ5RmlsZShkYXRlPzogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHRhcmdldERhdGUgPSBkYXRlIHx8IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zcGxpdChcIlRcIilbMF1cbiAgICAgIGNvbnN0IHN1bW1hcnlDb250ZW50ID0gYXdhaXQgdGhpcy5nZW5lcmF0ZURhaWx5U3VtbWFyeSh0YXJnZXREYXRlKVxuXG4gICAgICAvLyBDcmVhdGUgdGhlIHN1bW1hcnkgZmlsZVxuICAgICAgY29uc3QgZmlsZU5hbWUgPSBgJHt0YXJnZXREYXRlfSAtIEFjYWRlbWljIFN1bW1hcnkubWRgXG4gICAgICBjb25zdCBmaWxlUGF0aCA9IGBEYWlseS8ke2ZpbGVOYW1lfWBcblxuICAgICAgdHJ5IHtcbiAgICAgICAgYXdhaXQgdGhpcy5hcHAudmF1bHQuY3JlYXRlKGZpbGVQYXRoLCBzdW1tYXJ5Q29udGVudClcbiAgICAgICAgY29uc29sZS5sb2coYENyZWF0ZWQgZGFpbHkgc3VtbWFyeSBmaWxlOiAke2ZpbGVQYXRofWApXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAvLyBGaWxlIG1pZ2h0IGFscmVhZHkgZXhpc3QsIHRyeSB0byB1cGRhdGUgaXRcbiAgICAgICAgY29uc3QgZXhpc3RpbmdGaWxlID0gdGhpcy5hcHAudmF1bHQuZ2V0QWJzdHJhY3RGaWxlQnlQYXRoKGZpbGVQYXRoKVxuICAgICAgICBpZiAoZXhpc3RpbmdGaWxlICYmIGV4aXN0aW5nRmlsZSBpbnN0YW5jZW9mIFRGaWxlKSB7XG4gICAgICAgICAgYXdhaXQgdGhpcy5hcHAudmF1bHQubW9kaWZ5KGV4aXN0aW5nRmlsZSwgc3VtbWFyeUNvbnRlbnQpXG4gICAgICAgICAgY29uc29sZS5sb2coYFVwZGF0ZWQgZGFpbHkgc3VtbWFyeSBmaWxlOiAke2ZpbGVQYXRofWApXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihgRXJyb3IgY3JlYXRpbmcgZGFpbHkgc3VtbWFyeSBmb3IgJHtkYXRlfTpgLCBlcnJvcilcbiAgICAgIHRocm93IGVycm9yXG4gICAgfVxuICB9XG59XG4iXSwKICAibWFwcGluZ3MiOiAiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUFBQSxtQkFBdUI7OztBQ0F2QixzQkFBK0M7OztBQ2dCeEMsU0FBUyxRQUFRLE1BQXNCO0FBQzVDLFNBQU8sS0FDSixZQUFZLEVBQ1osS0FBSyxFQUNMLFVBQVUsS0FBSyxFQUNmLFFBQVEsb0JBQW9CLEVBQUUsRUFDOUIsUUFBUSxpQkFBaUIsRUFBRSxFQUMzQixRQUFRLFdBQVcsR0FBRyxFQUN0QixRQUFRLFlBQVksRUFBRTtBQUMzQjtBQWVPLFNBQVMsYUFBYSxZQUE2QjtBQUN4RCxRQUFNLFFBQVE7QUFDZCxNQUFJLENBQUMsV0FBVyxNQUFNLEtBQUs7QUFBRyxXQUFPO0FBRXJDLFFBQU0sT0FBTyxJQUFJLEtBQUssVUFBVTtBQUNoQyxRQUFNLFlBQVksS0FBSyxRQUFRO0FBRS9CLE1BQUksT0FBTyxjQUFjLFlBQVksTUFBTSxTQUFTO0FBQUcsV0FBTztBQUU5RCxTQUFPLGVBQWUsS0FBSyxZQUFZLEVBQUUsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUN2RDs7O0FEcENPLElBQU0sbUJBQXlDO0FBQUEsRUFDcEQsZUFBZTtBQUFBLEVBQ2YsbUJBQW1CLElBQUksS0FBSyxFQUFFLFlBQVksRUFBRSxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsRUFDeEQsaUJBQWlCLElBQUksS0FBSyxJQUFJLEtBQUssRUFBRSxTQUFTLElBQUksS0FBSyxFQUFFLFNBQVMsSUFBSSxDQUFDLENBQUMsRUFBRSxZQUFZLEVBQUUsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLEVBQ3BHLFlBQVk7QUFBQSxFQUNaLG9CQUFvQjtBQUFBLEVBQ3BCLGdCQUFnQjtBQUFBLEVBQ2hCLHFCQUFxQjtBQUN2QjtBQUVPLElBQU0seUJBQU4sY0FBcUMsaUNBQWlCO0FBQUEsRUFHM0QsWUFBWSxLQUFVLFFBQTRCO0FBQ2hELFVBQU0sS0FBSyxNQUFNO0FBQ2pCLFNBQUssU0FBUztBQUFBLEVBQ2hCO0FBQUEsRUFFQSxVQUFnQjtBQUNkLFVBQU0sRUFBRSxZQUFZLElBQUk7QUFFeEIsZ0JBQVksTUFBTTtBQUVsQixnQkFBWSxTQUFTLE1BQU0sRUFBRSxNQUFNLHlCQUF5QixDQUFDO0FBRTdELFFBQUksd0JBQVEsV0FBVyxFQUNwQixRQUFRLGdCQUFnQixFQUN4QixRQUFRLGdEQUFnRCxFQUN4RCxRQUFRLFVBQVEsS0FDZCxlQUFlLEdBQUcsRUFDbEIsU0FBUyxLQUFLLE9BQU8sU0FBUyxhQUFhLEVBQzNDLFNBQVMsQ0FBTyxVQUFVO0FBQ3pCLFdBQUssT0FBTyxTQUFTLGdCQUFnQjtBQUNyQyxZQUFNLEtBQUssT0FBTyxhQUFhO0FBQUEsSUFDakMsRUFBQyxDQUFDO0FBRU4sVUFBTSxtQkFBbUIsSUFBSSx3QkFBUSxXQUFXLEVBQzdDLFFBQVEscUJBQXFCLEVBQzdCLFFBQVEscUNBQXFDLEVBQzdDLFFBQVEsVUFBUSxLQUNkLGVBQWUsWUFBWSxFQUMzQixTQUFTLEtBQUssT0FBTyxTQUFTLGlCQUFpQixFQUMvQyxTQUFTLENBQU8sVUFBVTtBQUN6QixVQUFJLFNBQVMsQ0FBQyxhQUFhLEtBQUssR0FBRztBQUNqQyx5QkFBaUIsUUFBUSwyREFBMkQ7QUFBQSxNQUN0RixPQUFPO0FBQ0wseUJBQWlCLFFBQVEscUNBQXFDO0FBQUEsTUFDaEU7QUFDQSxXQUFLLE9BQU8sU0FBUyxvQkFBb0I7QUFDekMsWUFBTSxLQUFLLE9BQU8sYUFBYTtBQUFBLElBQ2pDLEVBQUMsQ0FBQztBQUVOLFVBQU0saUJBQWlCLElBQUksd0JBQVEsV0FBVyxFQUMzQyxRQUFRLG1CQUFtQixFQUMzQixRQUFRLG1DQUFtQyxFQUMzQyxRQUFRLFVBQVEsS0FDZCxlQUFlLFlBQVksRUFDM0IsU0FBUyxLQUFLLE9BQU8sU0FBUyxlQUFlLEVBQzdDLFNBQVMsQ0FBTyxVQUFVO0FBQ3pCLFVBQUksU0FBUyxDQUFDLGFBQWEsS0FBSyxHQUFHO0FBQ2pDLHVCQUFlLFFBQVEseURBQXlEO0FBQUEsTUFDbEYsT0FBTztBQUNMLHVCQUFlLFFBQVEsbUNBQW1DO0FBQUEsTUFDNUQ7QUFDQSxXQUFLLE9BQU8sU0FBUyxrQkFBa0I7QUFDdkMsWUFBTSxLQUFLLE9BQU8sYUFBYTtBQUFBLElBQ2pDLEVBQUMsQ0FBQztBQUVOLFFBQUksd0JBQVEsV0FBVyxFQUNwQixRQUFRLGFBQWEsRUFDckIsUUFBUSwwQkFBMEIsRUFDbEMsUUFBUSxVQUFRLEtBQ2QsZUFBZSxZQUFZLEVBQzNCLFNBQVMsS0FBSyxPQUFPLFNBQVMsVUFBVSxFQUN4QyxTQUFTLENBQU8sVUFBVTtBQUN6QixXQUFLLE9BQU8sU0FBUyxhQUFhO0FBQ2xDLFlBQU0sS0FBSyxPQUFPLGFBQWE7QUFBQSxJQUNqQyxFQUFDLENBQUM7QUFFTixRQUFJLHdCQUFRLFdBQVcsRUFDcEIsUUFBUSxxQkFBcUIsRUFDN0IsUUFBUSxtQ0FBbUMsRUFDM0MsUUFBUSxVQUFRLEtBQ2QsZUFBZSxHQUFHLEVBQ2xCLFNBQVMsS0FBSyxPQUFPLFNBQVMsa0JBQWtCLEVBQ2hELFNBQVMsQ0FBTyxVQUFVO0FBQ3pCLFdBQUssT0FBTyxTQUFTLHFCQUFxQjtBQUMxQyxZQUFNLEtBQUssT0FBTyxhQUFhO0FBQUEsSUFDakMsRUFBQyxDQUFDO0FBRU4sUUFBSSx3QkFBUSxXQUFXLEVBQ3BCLFFBQVEsaUJBQWlCLEVBQ3pCLFFBQVEsNkVBQTZFLEVBQ3JGLFFBQVEsVUFBUSxLQUNkLGVBQWUsZUFBZSxFQUM5QixTQUFTLEtBQUssT0FBTyxTQUFTLGNBQWMsRUFDNUMsU0FBUyxDQUFPLFVBQVU7QUFDekIsV0FBSyxPQUFPLFNBQVMsaUJBQWlCO0FBQ3RDLFlBQU0sS0FBSyxPQUFPLGFBQWE7QUFBQSxJQUNqQyxFQUFDLENBQUM7QUFFTixRQUFJLHdCQUFRLFdBQVcsRUFDcEIsUUFBUSx1QkFBdUIsRUFDL0IsUUFBUSxpRkFBaUYsRUFDekYsVUFBVSxZQUFVLE9BQ2xCLFNBQVMsS0FBSyxPQUFPLFNBQVMsbUJBQW1CLEVBQ2pELFNBQVMsQ0FBTyxVQUFVO0FBQ3pCLFdBQUssT0FBTyxTQUFTLHNCQUFzQjtBQUMzQyxZQUFNLEtBQUssT0FBTyxhQUFhO0FBQUEsSUFDakMsRUFBQyxDQUFDO0FBQUEsRUFDUjtBQUNGOzs7QUU3SEEsSUFBQUMsbUJBQTRCO0FBVXJCLElBQU0sa0JBQU4sTUFBc0I7QUFBQSxFQUszQixZQUFZLEtBQVUsVUFBZ0M7QUFDcEQsU0FBSyxNQUFNO0FBQ1gsU0FBSyxXQUFXO0FBQ2hCLFNBQUssV0FBVztBQUFBLE1BQ2QsU0FBUztBQUFBLE1BQ1QsV0FBVztBQUFBLFFBQ1QscUNBQXFDO0FBQUEsUUFDckMsMkJBQTJCO0FBQUEsUUFDM0IsNEJBQTRCO0FBQUEsUUFDNUIsOEJBQThCO0FBQUEsUUFDOUIsb0NBQW9DO0FBQUEsUUFDcEMsdUJBQXVCO0FBQUEsUUFDdkIsaUNBQWlDO0FBQUEsUUFDakMsK0JBQStCO0FBQUEsTUFDakM7QUFBQSxNQUNBLGdCQUFnQjtBQUFBLE1BQ2hCLGVBQWU7QUFBQSxJQUNqQjtBQUFBLEVBQ0Y7QUFBQSxFQUVNLG1CQUFtQjtBQUFBO0FBQ3ZCLFVBQUk7QUFFRixjQUFNLGtCQUFrQixLQUFLLG1CQUFtQjtBQUNoRCxZQUFJLENBQUMsaUJBQWlCO0FBQ3BCLGNBQUk7QUFBQSxZQUNGO0FBQUEsVUFDRjtBQUNBLGtCQUFRO0FBQUEsWUFDTjtBQUFBLFVBQ0Y7QUFDQTtBQUFBLFFBQ0Y7QUFFQSxjQUFNLHFCQUFxQixLQUFLLHNCQUFzQixlQUFlO0FBQ3JFLFlBQUksQ0FBQyxvQkFBb0I7QUFDdkIsY0FBSTtBQUFBLFlBQ0Y7QUFBQSxVQUNGO0FBQ0Esa0JBQVE7QUFBQSxZQUNOO0FBQUEsVUFDRjtBQUNBO0FBQUEsUUFDRjtBQUVBLGNBQU0sbUJBQW1CLEdBQUcsc0JBQXNCLEtBQUssU0FBUztBQUdoRSxZQUFJO0FBQ0YsZ0JBQU0sS0FBSyxJQUFJLE1BQU0sYUFBYSxnQkFBZ0I7QUFDbEQsa0JBQVEsSUFBSSw0QkFBNEIsa0JBQWtCO0FBQUEsUUFDNUQsU0FBUyxHQUFQO0FBRUEsa0JBQVE7QUFBQSxZQUNOLDhDQUE4QztBQUFBLFVBQ2hEO0FBQUEsUUFDRjtBQUdBLGNBQU0sVUFBVTtBQUFBLFVBQ2Q7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFFBQ0Y7QUFDQSxtQkFBVyxVQUFVLFNBQVM7QUFDNUIsY0FBSTtBQUNGLGtCQUFNLFVBQVUsR0FBRyxvQkFBb0I7QUFDdkMsa0JBQU0sS0FBSyxJQUFJLE1BQU0sYUFBYSxPQUFPO0FBQ3pDLG9CQUFRLElBQUkseUJBQXlCLFNBQVM7QUFBQSxVQUNoRCxTQUFTLEdBQVA7QUFFQSxvQkFBUTtBQUFBLGNBQ04sZ0NBQWdDLG9CQUFvQjtBQUFBLFlBQ3REO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFHQSxjQUFNLEtBQUssdUJBQXVCLGdCQUFnQjtBQUNsRCxjQUFNLEtBQUssdUJBQXVCLGdCQUFnQjtBQUNsRCxjQUFNLEtBQUssd0JBQXdCLGdCQUFnQjtBQUNuRCxjQUFNLEtBQUssMkJBQTJCLGdCQUFnQjtBQUN0RCxjQUFNLEtBQUssc0JBQXNCLGdCQUFnQjtBQUNqRCxjQUFNLEtBQUssd0JBQXdCLGdCQUFnQjtBQUduRCxjQUFNLEtBQUssYUFBYSxnQkFBZ0I7QUFHeEMsY0FBTSxLQUFLLHVCQUF1QixnQkFBZ0I7QUFFbEQsWUFBSSx3QkFBTyxpREFBaUQ7QUFDNUQsZ0JBQVEsSUFBSSxnREFBZ0Q7QUFBQSxNQUM5RCxTQUFTLE9BQVA7QUFDQSxnQkFBUSxNQUFNLCtCQUErQixLQUFLO0FBQ2xELFlBQUksd0JBQU8sd0RBQXdEO0FBQUEsTUFDckU7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVRLHFCQUEwQjtBQUVoQyxVQUFNLGdCQUFnQjtBQUFBLE1BQ25CLEtBQUssSUFBWSxRQUFRLFFBQVEsb0JBQW9CO0FBQUEsTUFDckQsS0FBSyxJQUFZLFFBQVEsUUFBUSxXQUFXO0FBQUEsTUFDNUMsS0FBSyxJQUFZLFFBQVEsVUFBVSxvQkFBb0I7QUFBQSxNQUN2RCxLQUFLLElBQVksUUFBUSxVQUFVLFdBQVc7QUFBQSxJQUNqRDtBQUVBLGVBQVcsUUFBUSxlQUFlO0FBQ2hDLFVBQUksTUFBTTtBQUNSLGVBQU87QUFBQSxNQUNUO0FBQUEsSUFDRjtBQUVBLFdBQU87QUFBQSxFQUNUO0FBQUEsRUFFUSxzQkFBc0IsaUJBQXFDO0FBQ2pFLFVBQU0sV0FBVyxnQkFBZ0I7QUFFakMsUUFBSSxDQUFDLFVBQVU7QUFDYixjQUFRLE1BQU0sa0NBQWtDO0FBQ2hELGFBQU87QUFBQSxJQUNUO0FBR0EsVUFBTSxnQkFBZ0I7QUFBQSxNQUNwQixTQUFTO0FBQUEsTUFDVCxTQUFTO0FBQUEsTUFDVCxTQUFTO0FBQUEsTUFDVCxTQUFTO0FBQUEsSUFDWDtBQUVBLGVBQVcsUUFBUSxlQUFlO0FBQ2hDLFVBQUksUUFBUSxPQUFPLFNBQVMsVUFBVTtBQUNwQyxlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFFQSxZQUFRO0FBQUEsTUFDTjtBQUFBLE1BQ0EsT0FBTyxLQUFLLFFBQVE7QUFBQSxJQUN0QjtBQUNBLFdBQU87QUFBQSxFQUNUO0FBQUEsRUFFTSx1QkFBdUIsVUFBa0I7QUFBQTtBQUM3QyxZQUFNLGVBQWUsR0FBRztBQUN4QixZQUFNLGtCQUFrQixLQUFLLFVBQVUsS0FBSyxVQUFVLE1BQU0sQ0FBQztBQUU3RCxVQUFJO0FBRUYsY0FBTSxtQkFDSixLQUFLLElBQUksTUFBTSxzQkFBc0IsWUFBWTtBQUNuRCxZQUFJLGtCQUFrQjtBQUVwQixnQkFBTSxPQUFPO0FBQ2IsZ0JBQU0sS0FBSyxJQUFJLE1BQU0sT0FBTyxNQUFNLGVBQWU7QUFDakQsa0JBQVEsSUFBSSw4QkFBOEIsY0FBYztBQUN4RDtBQUFBLFFBQ0Y7QUFHQSxjQUFNLEtBQUssSUFBSSxNQUFNLE9BQU8sY0FBYyxlQUFlO0FBQ3pELGdCQUFRLElBQUksOEJBQThCLGNBQWM7QUFBQSxNQUMxRCxTQUFTLEdBQVA7QUFDQSxZQUFJLHdCQUFPLG9DQUFvQyxjQUFjO0FBQzdELGdCQUFRLE1BQU0sb0NBQW9DLGlCQUFpQixDQUFDO0FBQUEsTUFDdEU7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVNLDBCQUE0QztBQUFBO0FBR2hELGNBQVEsSUFBSSwrQkFBK0I7QUFDM0MsYUFBTztBQUFBLElBQ1Q7QUFBQTtBQUFBLEVBRU0sa0JBQWtCO0FBQUE7QUFDdEIsVUFBSTtBQUVGLGdCQUFRLElBQUksb0JBQW9CO0FBR2hDLGNBQU0sa0JBQWtCLEtBQUssbUJBQW1CO0FBQ2hELFlBQUksQ0FBQyxpQkFBaUI7QUFDcEIsY0FBSTtBQUFBLFlBQ0Y7QUFBQSxVQUNGO0FBQ0Esa0JBQVE7QUFBQSxZQUNOO0FBQUEsVUFDRjtBQUNBO0FBQUEsUUFDRjtBQUVBLGNBQU0scUJBQXFCLEtBQUssc0JBQXNCLGVBQWU7QUFDckUsWUFBSSxDQUFDLG9CQUFvQjtBQUN2QixjQUFJO0FBQUEsWUFDRjtBQUFBLFVBQ0Y7QUFDQSxrQkFBUTtBQUFBLFlBQ047QUFBQSxVQUNGO0FBQ0E7QUFBQSxRQUNGO0FBRUEsY0FBTSxtQkFBbUIsR0FBRyxzQkFBc0IsS0FBSyxTQUFTO0FBR2hFLGNBQU0sS0FBSyx1QkFBdUIsZ0JBQWdCO0FBQ2xELGNBQU0sS0FBSyx1QkFBdUIsZ0JBQWdCO0FBQ2xELGNBQU0sS0FBSyx3QkFBd0IsZ0JBQWdCO0FBQ25ELGNBQU0sS0FBSywyQkFBMkIsZ0JBQWdCO0FBQ3RELGNBQU0sS0FBSyxzQkFBc0IsZ0JBQWdCO0FBQ2pELGNBQU0sS0FBSyx3QkFBd0IsZ0JBQWdCO0FBR25ELGNBQU0sS0FBSyxhQUFhLGdCQUFnQjtBQUd4QyxjQUFNLEtBQUssdUJBQXVCLGdCQUFnQjtBQUVsRCxZQUFJLHdCQUFPLCtDQUErQztBQUMxRCxnQkFBUSxJQUFJLDhDQUE4QztBQUFBLE1BQzVELFNBQVMsT0FBUDtBQUNBLGdCQUFRLE1BQU0sNkJBQTZCLEtBQUs7QUFDaEQsWUFBSSx3QkFBTyxzREFBc0Q7QUFBQSxNQUNuRTtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRU0sdUJBQXVCLFVBQWtCO0FBQUE7QUFDN0MsWUFBTSxhQUFhLEdBQUc7QUFHdEIsWUFBTSx5QkFBeUIsS0FBSywrQkFBK0I7QUFDbkUsWUFBTSxLQUFLO0FBQUEsUUFDVCxHQUFHO0FBQUEsUUFDSDtBQUFBLE1BQ0Y7QUFHQSxZQUFNLHNCQUFzQixLQUFLLDRCQUE0QjtBQUM3RCxZQUFNLEtBQUs7QUFBQSxRQUNULEdBQUc7QUFBQSxRQUNIO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRU0sdUJBQXVCLFVBQWtCO0FBQUE7QUFDN0MsWUFBTSxhQUFhLEdBQUc7QUFHdEIsWUFBTSxpQkFBaUIsS0FBSyx1QkFBdUI7QUFDbkQsWUFBTSxLQUFLO0FBQUEsUUFDVCxHQUFHO0FBQUEsUUFDSDtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVNLHdCQUF3QixVQUFrQjtBQUFBO0FBQzlDLFlBQU0sY0FBYyxHQUFHO0FBR3ZCLFlBQU0sa0JBQWtCLEtBQUssd0JBQXdCO0FBQ3JELFlBQU0sS0FBSztBQUFBLFFBQ1QsR0FBRztBQUFBLFFBQ0g7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBO0FBQUEsRUFFTSwyQkFBMkIsVUFBa0I7QUFBQTtBQUNqRCxZQUFNLGlCQUFpQixHQUFHO0FBRzFCLFlBQU0scUJBQXFCLEtBQUssMkJBQTJCO0FBQzNELFlBQU0sS0FBSztBQUFBLFFBQ1QsR0FBRztBQUFBLFFBQ0g7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBO0FBQUEsRUFFTSxzQkFBc0IsVUFBa0I7QUFBQTtBQUM1QyxZQUFNLFlBQVksR0FBRztBQUdyQixZQUFNLG9CQUFvQixLQUFLLDBCQUEwQjtBQUN6RCxZQUFNLEtBQUs7QUFBQSxRQUNULEdBQUc7QUFBQSxRQUNIO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRU0sd0JBQXdCLFVBQWtCO0FBQUE7QUFDOUMsWUFBTSxjQUFjLEdBQUc7QUFHdkIsWUFBTSxnQkFBZ0IsS0FBSywyQkFBMkI7QUFDdEQsWUFBTSxLQUFLO0FBQUEsUUFDVCxHQUFHO0FBQUEsUUFDSDtBQUFBLE1BQ0Y7QUFHQSxZQUFNLGtCQUFrQixLQUFLLHdCQUF3QjtBQUNyRCxZQUFNLEtBQUs7QUFBQSxRQUNULEdBQUc7QUFBQSxRQUNIO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRU0sa0JBQWtCLE1BQWMsU0FBaUI7QUFBQTtBQUNyRCxVQUFJO0FBRUYsY0FBTSxlQUFlLEtBQUssSUFBSSxNQUFNLHNCQUFzQixJQUFJO0FBQzlELFlBQUksY0FBYztBQUdoQixrQkFBUSxJQUFJLG9DQUFvQyxNQUFNO0FBQ3RELGdCQUFNLE9BQU87QUFDYixnQkFBTSxLQUFLLElBQUksTUFBTSxPQUFPLE1BQU0sT0FBTztBQUN6QztBQUFBLFFBQ0Y7QUFHQSxjQUFNLEtBQUssSUFBSSxNQUFNLE9BQU8sTUFBTSxPQUFPO0FBQ3pDLGdCQUFRLElBQUksMEJBQTBCLE1BQU07QUFBQSxNQUM5QyxTQUFTLEdBQVA7QUFDQSxZQUFJLHdCQUFPLGdDQUFnQyxNQUFNO0FBQ2pELGdCQUFRLE1BQU0sZ0NBQWdDLFNBQVMsQ0FBQztBQUFBLE1BQzFEO0FBQUEsSUFDRjtBQUFBO0FBQUEsRUFFQSxpQ0FBeUM7QUFDdkMsV0FBTztBQUFBLEVBRVQsS0FBSyxTQUFTLHNCQUNWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTUksS0FBSyxTQUFTO0FBQUEsdUJBQ0QsS0FBSyxTQUFTLHVCQUMvQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BU0YsS0FBSyxTQUFTO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBbUJKLEtBQUssU0FBUztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBcUMxQjtBQUFBLEVBRUEsOEJBQXNDO0FBQ3BDLFdBQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQW1CVDtBQUFBLEVBRUEseUJBQWlDO0FBQy9CLFdBQU87QUFBQSxFQUVULEtBQUssU0FBUyxzQkFDVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUNBTUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQXNDSjtBQUFBLEVBRUEsMEJBQWtDO0FBQ2hDLFdBQU87QUFBQSxFQUVULEtBQUssU0FBUyxzQkFDVjtBQUFBO0FBQUE7QUFBQTtBQUFBLG9DQUtBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBNEJKO0FBQUEsRUFFQSw2QkFBcUM7QUFDbkMsV0FBTztBQUFBLEVBRVQsS0FBSyxTQUFTLHNCQUNWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQ0FNQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUEyQko7QUFBQSxFQUVBLDRCQUFvQztBQUNsQyxXQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQW1DVDtBQUFBLEVBRUEsNkJBQXFDO0FBQ25DLFdBQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBUVQ7QUFBQSxFQUVBLDBCQUFrQztBQUNoQyxXQUFPO0FBQUEsRUFDVDtBQUFBLEVBRU0sYUFBYSxVQUFrQjtBQUFBO0FBQ25DLFlBQU0sZ0JBQWdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQXlCdEIsWUFBTSxLQUFLLGtCQUFrQixHQUFHLHNCQUFzQixhQUFhO0FBQUEsSUFDckU7QUFBQTtBQUNGOzs7QUNscEJBLElBQUFDLG1CQUFtQztBQUk1QixJQUFNLHVCQUFOLE1BQTJCO0FBQUEsRUFJaEMsWUFBWSxLQUFVLFVBQWdDO0FBQ3BELFNBQUssTUFBTTtBQUNYLFNBQUssV0FBVztBQUFBLEVBQ2xCO0FBQUEsRUFFTSx1QkFBdUI7QUFBQTtBQUMzQixVQUFJO0FBRUYsY0FBTSxnQkFBZ0IsTUFBTSxLQUFLLG9CQUFvQjtBQUVyRCxZQUFJLENBQUMsZUFBZTtBQUNsQixpQkFBTztBQUFBLFFBQ1Q7QUFHQSxjQUFNLGFBQWEsTUFBTSxLQUFLLDRCQUE0QixhQUFhO0FBR3ZFLGNBQU0sS0FBSyx5QkFBeUIsZUFBZSxVQUFVO0FBRzdELGNBQU0sS0FBSyx3QkFBd0IsVUFBVTtBQUU3QyxZQUFJLHdCQUFPLFdBQVcsY0FBYyxtQ0FBbUM7QUFDdkUsZ0JBQVE7QUFBQSxVQUNOLG1CQUFtQixjQUFjLGlCQUFpQjtBQUFBLFFBQ3BEO0FBRUEsZUFBTztBQUFBLE1BQ1QsU0FBUyxPQUFQO0FBQ0EsZ0JBQVEsTUFBTSwwQkFBMEIsS0FBSztBQUM3QyxZQUFJLHdCQUFPLDBCQUEwQixNQUFNLFNBQVM7QUFDcEQsZUFBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVjLHNCQUtKO0FBQUE7QUFuRFo7QUFvREksVUFBSTtBQUNGLGNBQU0sYUFBYSxNQUFNLEtBQUs7QUFBQSxVQUM1QjtBQUFBLFVBQ0E7QUFBQSxVQUNBLENBQUMsVUFBVSxNQUFNLEtBQUssRUFBRSxTQUFTO0FBQUEsVUFDakM7QUFBQSxRQUNGO0FBRUEsWUFBSSxDQUFDO0FBQVksaUJBQU87QUFFeEIsY0FBTSxlQUFlLE1BQU0sS0FBSztBQUFBLFVBQzlCO0FBQUEsVUFDQTtBQUFBLFVBQ0EsQ0FBQyxRQUFRLFVBQVUsVUFBVSxRQUFRO0FBQUEsUUFDdkM7QUFFQSxZQUFJLENBQUM7QUFBYyxpQkFBTztBQUUxQixjQUFNLGFBQWEsTUFBTSxLQUFLO0FBQUEsVUFDNUI7QUFBQSxVQUNBO0FBQUEsVUFDQSxDQUFDLFVBQVUsVUFBVSxLQUFLLE1BQU0sS0FBSyxDQUFDO0FBQUEsVUFDdEM7QUFBQSxRQUNGO0FBRUEsWUFBSSxDQUFDO0FBQVksaUJBQU87QUFFeEIsY0FBTSxhQUFXLGdCQUFXLE1BQU0sS0FBSyxFQUFFLENBQUMsTUFBekIsbUJBQTRCLFdBQVUsUUFBUSxVQUFVO0FBRXpFLGVBQU87QUFBQSxVQUNMO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsUUFDRjtBQUFBLE1BQ0YsU0FBUyxPQUFQO0FBQ0EsZ0JBQVEsTUFBTSx1Q0FBdUMsS0FBSztBQUMxRCxlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRWMscUJBQ1osT0FDQSxTQUNBLFdBQ0EsY0FDd0I7QUFBQTtBQUV4QixZQUFNLFFBQVEsT0FBTyxHQUFHLFVBQVUsU0FBUztBQUUzQyxVQUFJLENBQUM7QUFBTyxlQUFPO0FBRW5CLFVBQUksQ0FBQyxVQUFVLEtBQUssR0FBRztBQUNyQixZQUFJLHdCQUFPLFlBQVk7QUFDdkIsZUFBTyxNQUFNLEtBQUs7QUFBQSxVQUNoQjtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBRUEsYUFBTyxNQUFNLEtBQUs7QUFBQSxJQUNwQjtBQUFBO0FBQUEsRUFFYyxrQkFDWixPQUNBLFNBQ0EsU0FDd0I7QUFBQTtBQUV4QixZQUFNLFNBQVM7QUFBQSxRQUNiLEdBQUcsVUFBVTtBQUFBLFdBQXFCLFFBQVEsS0FBSyxJQUFJO0FBQUE7QUFBQSxNQUNyRDtBQUVBLFVBQUksQ0FBQztBQUFRLGVBQU87QUFFcEIsWUFBTSxnQkFBZ0IsT0FBTyxLQUFLO0FBQ2xDLFVBQUksUUFBUSxTQUFTLGFBQWEsR0FBRztBQUNuQyxlQUFPO0FBQUEsTUFDVDtBQUVBLFVBQUksd0JBQU8seUJBQXlCLFFBQVEsS0FBSyxJQUFJLEdBQUc7QUFDeEQsYUFBTyxNQUFNLEtBQUssa0JBQWtCLE9BQU8sU0FBUyxPQUFPO0FBQUEsSUFDN0Q7QUFBQTtBQUFBLEVBRWMsNEJBQTRCLGVBS3RCO0FBQUE7QUFDbEIsWUFBTSxhQUFhLEdBQUcsY0FBYyxjQUFjLGNBQWMsZ0JBQWdCLGNBQWM7QUFFOUYsVUFBSTtBQUNGLGNBQU0sS0FBSyxJQUFJLE1BQU0sYUFBYSxVQUFVO0FBQzVDLGdCQUFRLElBQUksMEJBQTBCLFlBQVk7QUFDbEQsZUFBTztBQUFBLE1BQ1QsU0FBUyxPQUFQO0FBRUEsZ0JBQVEsSUFBSSw0Q0FBNEMsWUFBWTtBQUNwRSxlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRWMseUJBQ1osZUFNQSxZQUNlO0FBQUE7QUFDZixZQUFNLFdBQVcsR0FBRyxjQUFjLGNBQWM7QUFDaEQsWUFBTSxVQUFVLEtBQUssOEJBQThCLGFBQWE7QUFFaEUsVUFBSTtBQUNGLGNBQU0sS0FBSyxJQUFJLE1BQU0sT0FBTyxVQUFVLE9BQU87QUFDN0MsZ0JBQVEsSUFBSSw0QkFBNEIsVUFBVTtBQUFBLE1BQ3BELFNBQVMsT0FBUDtBQUNBLGdCQUFRLE1BQU0sbUNBQW1DLE9BQU87QUFDeEQsY0FBTTtBQUFBLE1BQ1I7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVjLHdCQUF3QixZQUFtQztBQUFBO0FBQ3ZFLFlBQU0sa0JBQWtCLEdBQUc7QUFFM0IsVUFBSTtBQUNGLGNBQU0sS0FBSyxJQUFJLE1BQU0sYUFBYSxlQUFlO0FBQ2pELGdCQUFRLElBQUksK0JBQStCLGlCQUFpQjtBQUFBLE1BQzlELFNBQVMsT0FBUDtBQUVBLGdCQUFRLElBQUksc0NBQXNDLGlCQUFpQjtBQUFBLE1BQ3JFO0FBQUEsSUFDRjtBQUFBO0FBQUEsRUFFUSw4QkFBOEIsZUFLM0I7QUFDVCxVQUFNLG1CQUFtQixLQUFLLFNBQVM7QUFFdkMsV0FBTztBQUFBLEVBRVQsbUJBQ0ksY0FBYyxjQUFjO0FBQUEsZUFDbkIsY0FBYztBQUFBLGVBQ2QsY0FBYyxnQkFBZ0IsY0FBYztBQUFBLGVBQzVDLGNBQWM7QUFBQSxtQkFDVixjQUFjO0FBQUE7QUFBQSxVQUV2QixLQUFLLFNBQVM7QUFBQSx1QkFDRCxLQUFLLFNBQVMsdUJBQy9CLGNBQWMsY0FBYztBQUFBLFNBQ3pCLGNBQWM7QUFBQSxXQUVaLElBQUksS0FBSyxFQUFFLFlBQVk7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQUk3QixjQUFjO0FBQUEsS0FDZCxLQUFLLFNBQVMsc0JBQXNCLGNBQWMsY0FDakQsY0FBYyxnQkFDWixjQUFjO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFJbEIsY0FBYztBQUFBO0FBQUE7QUFBQSxpQkFHRCxjQUFjO0FBQUEsWUFDbkIsY0FBYyxnQkFBZ0IsY0FBYztBQUFBLGNBQzFDLEtBQUssU0FBUztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBc0IxQjtBQUNGOzs7QUN6UEEsSUFBQUMsbUJBQTJCO0FBR3BCLElBQU0sc0JBQU4sTUFBMEI7QUFBQSxFQUcvQixZQUFZLEtBQVU7QUFDcEIsU0FBSyxNQUFNO0FBQUEsRUFDYjtBQUFBLEVBRUEsMEJBQTBCLFNBQTJCO0FBRW5ELFVBQU0sYUFBYTtBQUNuQixVQUFNLGVBQWUsbUNBQVMsTUFBTTtBQUVwQyxRQUFJLGNBQWM7QUFDaEIsWUFBTSxZQUFZLGFBQWEsQ0FBQyxFQUFFLEtBQUs7QUFDdkMsWUFBTSxlQUFlLFVBQ2xCLFFBQVEsZ0JBQWdCLEVBQUUsRUFDMUIsUUFBUSxjQUFjLEVBQUUsRUFDeEIsTUFBTSxJQUFJLEVBQ1YsSUFBSSxDQUFDLFNBQVMsS0FBSyxLQUFLLENBQUMsRUFDekIsT0FBTyxDQUFDLFNBQVMsS0FBSyxTQUFTLENBQUM7QUFFbkMsYUFBTztBQUFBLElBQ1Q7QUFFQSxXQUFPLENBQUM7QUFBQSxFQUNWO0FBQUEsRUFFTSw0QkFDSixVQUNtQztBQUFBO0FBQ25DLGNBQVEsSUFBSSxxQ0FBcUMsVUFBVTtBQUUzRCxVQUFJO0FBRUYsY0FBTSxjQUFjLE1BQU0sS0FBSyxnQkFBZ0IsUUFBUTtBQUV2RCxZQUFJLFlBQVksV0FBVyxHQUFHO0FBQzVCLGtCQUFRLElBQUksOEJBQThCLFVBQVU7QUFDcEQsaUJBQU8sQ0FBQztBQUFBLFFBQ1Y7QUFHQSxjQUFNLGlCQUEyQyxDQUFDO0FBRWxELG1CQUFXLFFBQVEsYUFBYTtBQUM5QixjQUFJO0FBQ0Ysa0JBQU0sVUFBVSxNQUFNLEtBQUssSUFBSSxNQUFNLEtBQUssSUFBSTtBQUM5QyxrQkFBTSxhQUFhLEtBQUssMEJBQTBCLE9BQU87QUFFekQsZ0JBQUksV0FBVyxTQUFTLEdBQUc7QUFDekIsNkJBQWUsS0FBSyxRQUFRLElBQUk7QUFBQSxZQUNsQztBQUFBLFVBQ0YsU0FBUyxPQUFQO0FBQ0Esb0JBQVEsTUFBTSxzQkFBc0IsS0FBSyxTQUFTLEtBQUs7QUFBQSxVQUN6RDtBQUFBLFFBQ0Y7QUFFQSxnQkFBUTtBQUFBLFVBQ04sNkJBQ0UsT0FBTyxLQUFLLGNBQWMsRUFBRSw0QkFDUjtBQUFBLFFBQ3hCO0FBQ0EsZUFBTztBQUFBLE1BQ1QsU0FBUyxPQUFQO0FBQ0EsZ0JBQVE7QUFBQSxVQUNOLDBDQUEwQztBQUFBLFVBQzFDO0FBQUEsUUFDRjtBQUNBLGVBQU8sQ0FBQztBQUFBLE1BQ1Y7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVNLGdCQUFnQixVQUFvQztBQUFBO0FBQ3hELFlBQU0sUUFBaUIsQ0FBQztBQUd4QixZQUFNLFFBQVEsS0FBSyxJQUFJLE1BQU0saUJBQWlCO0FBRTlDLGlCQUFXLFFBQVEsT0FBTztBQUV4QixZQUNFLEtBQUssS0FBSyxTQUFTLFFBQVEsTUFDMUIsTUFBTSxLQUFLLG9CQUFvQixNQUFNLFFBQVEsSUFDOUM7QUFDQSxnQkFBTSxLQUFLLElBQUk7QUFBQSxRQUNqQjtBQUFBLE1BQ0Y7QUFFQSxhQUFPO0FBQUEsSUFDVDtBQUFBO0FBQUEsRUFFYyxvQkFDWixNQUNBLFVBQ2tCO0FBQUE7QUFDbEIsVUFBSTtBQUNGLGNBQU0sVUFBVSxNQUFNLEtBQUssSUFBSSxNQUFNLEtBQUssSUFBSTtBQUM5QyxjQUFNLG1CQUFtQixRQUFRLE1BQU0sdUJBQXVCO0FBRTlELFlBQUksa0JBQWtCO0FBQ3BCLGdCQUFNLGNBQWMsaUJBQWlCLENBQUM7QUFFdEMsaUJBQ0UsWUFBWSxTQUFTLGNBQWMsVUFBVSxLQUM3QyxZQUFZLFNBQVMsYUFBYSxVQUFVO0FBQUEsUUFFaEQ7QUFFQSxlQUFPO0FBQUEsTUFDVCxTQUFTLE9BQVA7QUFDQSxnQkFBUTtBQUFBLFVBQ04sMEJBQTBCLEtBQUssMEJBQTBCO0FBQUEsVUFDekQ7QUFBQSxRQUNGO0FBQ0EsZUFBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVNLHdCQUNKLFVBQ0EsZ0JBQ2lCO0FBQUE7QUFDakIsWUFBTSxXQUFxQixDQUFDO0FBQzVCLFlBQU0sY0FBd0MsQ0FBQztBQUcvQyxpQkFBVyxDQUFDLFVBQVUsS0FBSyxLQUFLLE9BQU8sUUFBUSxjQUFjLEdBQUc7QUFDOUQsbUJBQVcsUUFBUSxPQUFPO0FBQ3hCLGNBQUksQ0FBQyxTQUFTLFNBQVMsSUFBSSxHQUFHO0FBQzVCLHFCQUFTLEtBQUssSUFBSTtBQUNsQix3QkFBWSxJQUFJLElBQUksQ0FBQztBQUFBLFVBQ3ZCO0FBQ0Esc0JBQVksSUFBSSxFQUFFLEtBQUssUUFBUTtBQUFBLFFBQ2pDO0FBQUEsTUFDRjtBQUdBLGVBQVMsS0FBSztBQUdkLFVBQUksVUFBVSx3QkFBd0I7QUFBQTtBQUFBO0FBQ3RDLGlCQUFXLHVCQUF1QixTQUFTO0FBQUE7QUFBQTtBQUUzQyxpQkFBVyxRQUFRLFVBQVU7QUFDM0IsbUJBQVcsTUFBTTtBQUFBO0FBQ2pCLG1CQUFXLGdCQUFnQixZQUFZLElBQUksRUFBRSxLQUFLLElBQUk7QUFBQTtBQUFBO0FBQ3RELG1CQUFXO0FBQUE7QUFBQTtBQUNYLG1CQUFXO0FBQUE7QUFBQTtBQUNYLG1CQUFXO0FBQUE7QUFBQTtBQUNYLG1CQUFXO0FBQUE7QUFBQTtBQUFBLE1BQ2I7QUFFQSxhQUFPO0FBQUEsSUFDVDtBQUFBO0FBQUEsRUFFTSwwQkFBMEIsVUFBaUM7QUFBQTtBQUMvRCxVQUFJO0FBQ0YsY0FBTSxpQkFBaUIsTUFBTSxLQUFLLDRCQUE0QixRQUFRO0FBRXRFLFlBQUksT0FBTyxLQUFLLGNBQWMsRUFBRSxXQUFXLEdBQUc7QUFDNUMsa0JBQVEsSUFBSSxtQ0FBbUMsVUFBVTtBQUN6RDtBQUFBLFFBQ0Y7QUFFQSxjQUFNLGVBQWUsTUFBTSxLQUFLO0FBQUEsVUFDOUI7QUFBQSxVQUNBO0FBQUEsUUFDRjtBQUdBLGNBQU0sV0FBVyxHQUFHO0FBQ3BCLGNBQU0sV0FBVyxXQUFXLFlBQVk7QUFFeEMsWUFBSTtBQUNGLGdCQUFNLEtBQUssSUFBSSxNQUFNLE9BQU8sVUFBVSxZQUFZO0FBQ2xELGtCQUFRLElBQUksa0NBQWtDLFVBQVU7QUFBQSxRQUMxRCxTQUFTLE9BQVA7QUFFQSxnQkFBTSxlQUFlLEtBQUssSUFBSSxNQUFNLHNCQUFzQixRQUFRO0FBQ2xFLGNBQUksZ0JBQWdCLHdCQUF3Qix3QkFBTztBQUNqRCxrQkFBTSxLQUFLLElBQUksTUFBTSxPQUFPLGNBQWMsWUFBWTtBQUN0RCxvQkFBUSxJQUFJLGtDQUFrQyxVQUFVO0FBQUEsVUFDMUQ7QUFBQSxRQUNGO0FBQUEsTUFDRixTQUFTLE9BQVA7QUFDQSxnQkFBUTtBQUFBLFVBQ04sOENBQThDO0FBQUEsVUFDOUM7QUFBQSxRQUNGO0FBQ0EsY0FBTTtBQUFBLE1BQ1I7QUFBQSxJQUNGO0FBQUE7QUFDRjs7O0FDck1BLElBQUFDLG1CQUEyQjtBQUdwQixJQUFNLGlCQUFOLE1BQXFCO0FBQUEsRUFHMUIsWUFBWSxLQUFVO0FBQ3BCLFNBQUssTUFBTTtBQUFBLEVBQ2I7QUFBQSxFQUVBLHNCQUNFLFNBQzZEO0FBRTdELFVBQU0sZ0JBQWdCO0FBQ3RCLFVBQU0sVUFBVSxtQ0FBUyxNQUFNO0FBRS9CLFFBQUksQ0FBQyxTQUFTO0FBQ1osYUFBTyxDQUFDO0FBQUEsSUFDVjtBQUVBLFVBQU0sa0JBQWtCLFFBQVEsQ0FBQztBQUNqQyxVQUFNLFdBQVcsQ0FBQztBQUdsQixVQUFNLGFBQWE7QUFDbkIsVUFBTSxlQUFlLGdCQUFnQixNQUFNLFVBQVU7QUFFckQsUUFBSSxjQUFjO0FBQ2hCLGlCQUFXLFNBQVMsY0FBYztBQUNoQyxjQUFNLE9BQU8sTUFDVixLQUFLLEVBQ0wsTUFBTSxJQUFJLEVBQ1YsT0FBTyxDQUFDLFFBQVEsSUFBSSxXQUFXLEdBQUcsQ0FBQztBQUN0QyxjQUFNLGFBQWEsS0FBSyxlQUFlLElBQUk7QUFDM0MsaUJBQVMsS0FBSyxHQUFHLFVBQVU7QUFBQSxNQUM3QjtBQUFBLElBQ0Y7QUFFQSxXQUFPO0FBQUEsRUFDVDtBQUFBLEVBRVEsZUFDTixNQUM2RDtBQUM3RCxRQUFJLEtBQUssU0FBUztBQUFHLGFBQU8sQ0FBQztBQUU3QixVQUFNLFdBQVcsQ0FBQztBQUVsQixhQUFTLElBQUksR0FBRyxJQUFJLEtBQUssUUFBUSxLQUFLO0FBRXBDLFlBQU0sTUFBTSxLQUFLLENBQUM7QUFDbEIsWUFBTSxVQUFVLElBQ2IsTUFBTSxHQUFHLEVBQ1QsSUFBSSxDQUFDLFFBQVEsSUFBSSxLQUFLLENBQUMsRUFDdkIsT0FBTyxDQUFDLFFBQVEsR0FBRztBQUV0QixVQUFJLFFBQVEsVUFBVSxHQUFHO0FBQ3ZCLGNBQU0sQ0FBQyxNQUFNLFlBQVksU0FBUyxTQUFTLElBQUk7QUFDL0MsWUFBSSxRQUFRLGNBQWMsS0FBSyxZQUFZLElBQUksR0FBRztBQUNoRCxtQkFBUyxLQUFLLEVBQUUsTUFBTSxZQUFZLE9BQU8sQ0FBQztBQUFBLFFBQzVDO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFFQSxXQUFPO0FBQUEsRUFDVDtBQUFBLEVBRVEsWUFBWSxZQUE2QjtBQUMvQyxVQUFNLFlBQVk7QUFDbEIsV0FBTyxVQUFVLEtBQUssVUFBVSxLQUFLLENBQUMsTUFBTSxLQUFLLE1BQU0sVUFBVSxDQUFDO0FBQUEsRUFDcEU7QUFBQSxFQUVNLHdCQUNKLFVBQ0EsV0FDQSxTQUdBO0FBQUE7QUFDQSxjQUFRLElBQUksaUNBQWlDLFVBQVU7QUFFdkQsVUFBSTtBQUVGLGNBQU0sY0FBYyxNQUFNLEtBQUssZ0JBQWdCLFFBQVE7QUFFdkQsWUFBSSxZQUFZLFdBQVcsR0FBRztBQUM1QixrQkFBUSxJQUFJLDhCQUE4QixVQUFVO0FBQ3BELGlCQUFPLENBQUM7QUFBQSxRQUNWO0FBR0EsY0FBTSxjQUtELENBQUM7QUFFTixtQkFBVyxRQUFRLGFBQWE7QUFDOUIsY0FBSTtBQUNGLGtCQUFNLFVBQVUsTUFBTSxLQUFLLElBQUksTUFBTSxLQUFLLElBQUk7QUFDOUMsa0JBQU0sV0FBVyxLQUFLLHNCQUFzQixPQUFPO0FBR25ELGtCQUFNLHFCQUFxQixTQUFTLElBQUksQ0FBQyxZQUFhLGlDQUNqRCxVQURpRDtBQUFBLGNBRXBELFFBQVEsS0FBSztBQUFBLFlBQ2YsRUFBRTtBQUVGLHdCQUFZLEtBQUssR0FBRyxrQkFBa0I7QUFBQSxVQUN4QyxTQUFTLE9BQVA7QUFDQSxvQkFBUSxNQUFNLHNCQUFzQixLQUFLLFNBQVMsS0FBSztBQUFBLFVBQ3pEO0FBQUEsUUFDRjtBQUdBLFlBQUksbUJBQW1CO0FBQ3ZCLFlBQUksYUFBYSxTQUFTO0FBQ3hCLDZCQUFtQixLQUFLO0FBQUEsWUFDdEI7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBR0EseUJBQWlCO0FBQUEsVUFDZixDQUFDLEdBQUcsTUFBTSxJQUFJLEtBQUssRUFBRSxJQUFJLEVBQUUsUUFBUSxJQUFJLElBQUksS0FBSyxFQUFFLElBQUksRUFBRSxRQUFRO0FBQUEsUUFDbEU7QUFFQSxnQkFBUTtBQUFBLFVBQ04sU0FBUyxpQkFBaUIsZ0NBQWdDO0FBQUEsUUFDNUQ7QUFDQSxlQUFPO0FBQUEsTUFDVCxTQUFTLE9BQVA7QUFDQSxnQkFBUSxNQUFNLHNDQUFzQyxhQUFhLEtBQUs7QUFDdEUsZUFBTyxDQUFDO0FBQUEsTUFDVjtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRWMsZ0JBQWdCLFVBQW9DO0FBQUE7QUFDaEUsWUFBTSxRQUFpQixDQUFDO0FBR3hCLFlBQU0sUUFBUSxLQUFLLElBQUksTUFBTSxpQkFBaUI7QUFFOUMsaUJBQVcsUUFBUSxPQUFPO0FBRXhCLFlBQ0UsS0FBSyxLQUFLLFNBQVMsUUFBUSxNQUMxQixNQUFNLEtBQUssb0JBQW9CLE1BQU0sUUFBUSxJQUM5QztBQUNBLGdCQUFNLEtBQUssSUFBSTtBQUFBLFFBQ2pCO0FBQUEsTUFDRjtBQUVBLGFBQU87QUFBQSxJQUNUO0FBQUE7QUFBQSxFQUVjLG9CQUNaLE1BQ0EsVUFDa0I7QUFBQTtBQUNsQixVQUFJO0FBQ0YsY0FBTSxVQUFVLE1BQU0sS0FBSyxJQUFJLE1BQU0sS0FBSyxJQUFJO0FBQzlDLGNBQU0sbUJBQW1CLFFBQVEsTUFBTSx1QkFBdUI7QUFFOUQsWUFBSSxrQkFBa0I7QUFDcEIsZ0JBQU0sY0FBYyxpQkFBaUIsQ0FBQztBQUV0QyxpQkFDRSxZQUFZLFNBQVMsY0FBYyxVQUFVLEtBQzdDLFlBQVksU0FBUyxhQUFhLFVBQVU7QUFBQSxRQUVoRDtBQUVBLGVBQU87QUFBQSxNQUNULFNBQVMsT0FBUDtBQUNBLGdCQUFRO0FBQUEsVUFDTiwwQkFBMEIsS0FBSywwQkFBMEI7QUFBQSxVQUN6RDtBQUFBLFFBQ0Y7QUFDQSxlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRVEsa0JBQ04sVUFNQSxXQUNBLFNBTUM7QUFDRCxXQUFPLFNBQVMsT0FBTyxDQUFDLFlBQVk7QUFDbEMsWUFBTSxjQUFjLElBQUksS0FBSyxRQUFRLElBQUksRUFBRSxRQUFRO0FBRW5ELFVBQUksYUFBYSxjQUFjLElBQUksS0FBSyxTQUFTLEVBQUUsUUFBUSxHQUFHO0FBQzVELGVBQU87QUFBQSxNQUNUO0FBRUEsVUFBSSxXQUFXLGNBQWMsSUFBSSxLQUFLLE9BQU8sRUFBRSxRQUFRLEdBQUc7QUFDeEQsZUFBTztBQUFBLE1BQ1Q7QUFFQSxhQUFPO0FBQUEsSUFDVCxDQUFDO0FBQUEsRUFDSDtBQUFBLEVBRU0sd0JBQ0osVUFDQSxVQU1pQjtBQUFBO0FBQ2pCLFVBQUksU0FBUyxXQUFXLEdBQUc7QUFDekIsZUFBTyx5QkFBeUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUNsQztBQUdBLFlBQU0sV0FBVyxTQUFTLE9BQU8sQ0FBQyxLQUFLLFlBQVk7QUFDakQsWUFBSSxDQUFDLElBQUksUUFBUSxNQUFNLEdBQUc7QUFDeEIsY0FBSSxRQUFRLE1BQU0sSUFBSSxDQUFDO0FBQUEsUUFDekI7QUFDQSxZQUFJLFFBQVEsTUFBTSxFQUFFLEtBQUssT0FBTztBQUNoQyxlQUFPO0FBQUEsTUFDVCxHQUFHLENBQUMsQ0FBb0M7QUFFeEMsVUFBSSxVQUFVLHlCQUF5QjtBQUFBO0FBQUE7QUFDdkMsaUJBQVcsc0JBQXNCLFNBQVM7QUFBQTtBQUFBO0FBRzFDLGlCQUFXLENBQUMsUUFBUSxLQUFLLEtBQUssT0FBTyxRQUFRLFFBQVEsR0FBRztBQUN0RCxtQkFBVyxNQUFNLE9BQU8sT0FBTyxDQUFDLEVBQUUsWUFBWSxJQUFJLE9BQU8sTUFBTSxDQUFDLE1BQzlELE1BQU07QUFBQTtBQUFBO0FBRVIsbUJBQVc7QUFBQTtBQUNYLG1CQUFXO0FBQUE7QUFFWCxtQkFBVyxRQUFRLE9BQU87QUFDeEIscUJBQVcsS0FBSyxLQUFLLFVBQVUsS0FBSyxnQkFBZ0IsS0FBSztBQUFBO0FBQUEsUUFDM0Q7QUFDQSxtQkFBVztBQUFBO0FBQUEsTUFDYjtBQUVBLGFBQU87QUFBQSxJQUNUO0FBQUE7QUFBQSxFQUVNLDBCQUNKLFVBQ0EsV0FDQSxTQUNlO0FBQUE7QUFDZixVQUFJO0FBQ0YsY0FBTSxXQUFXLE1BQU0sS0FBSztBQUFBLFVBQzFCO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxRQUNGO0FBRUEsY0FBTSxpQkFBaUIsTUFBTSxLQUFLO0FBQUEsVUFDaEM7QUFBQSxVQUNBO0FBQUEsUUFDRjtBQUdBLGNBQU0sV0FBVyxHQUFHO0FBQ3BCLGNBQU0sV0FBVyxXQUFXLFlBQVk7QUFFeEMsWUFBSTtBQUNGLGdCQUFNLEtBQUssSUFBSSxNQUFNLE9BQU8sVUFBVSxjQUFjO0FBQ3BELGtCQUFRLElBQUksbUNBQW1DLFVBQVU7QUFBQSxRQUMzRCxTQUFTLE9BQVA7QUFFQSxnQkFBTSxlQUFlLEtBQUssSUFBSSxNQUFNLHNCQUFzQixRQUFRO0FBQ2xFLGNBQUksZ0JBQWdCLHdCQUF3Qix3QkFBTztBQUNqRCxrQkFBTSxLQUFLLElBQUksTUFBTSxPQUFPLGNBQWMsY0FBYztBQUN4RCxvQkFBUSxJQUFJLG1DQUFtQyxVQUFVO0FBQUEsVUFDM0Q7QUFBQSxRQUNGO0FBQUEsTUFDRixTQUFTLE9BQVA7QUFDQSxnQkFBUTtBQUFBLFVBQ04sK0NBQStDO0FBQUEsVUFDL0M7QUFBQSxRQUNGO0FBQ0EsY0FBTTtBQUFBLE1BQ1I7QUFBQSxJQUNGO0FBQUE7QUFDRjs7O0FDelNBLElBQUFDLG1CQUEyQjtBQUVwQixJQUFNLHdCQUFOLE1BQTRCO0FBQUEsRUFHakMsWUFBWSxLQUFVO0FBQ3BCLFNBQUssTUFBTTtBQUFBLEVBQ2I7QUFBQSxFQUVNLHNCQUVKO0FBQUE7QUFDQSxjQUFRLElBQUkscUNBQXFDO0FBRWpELFVBQUk7QUFDRixjQUFNLFFBQVEsSUFBSSxLQUFLO0FBQ3ZCLGNBQU0sY0FBYyxNQUFNLFlBQVksRUFBRSxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBR3BELGNBQU0sUUFBUSxLQUFLLElBQUksTUFBTSxpQkFBaUI7QUFDOUMsY0FBTSxjQUF1QixDQUFDO0FBRTlCLG1CQUFXLFFBQVEsT0FBTztBQUN4QixnQkFBTSxXQUFXLEtBQUssb0JBQW9CLEtBQUssSUFBSTtBQUNuRCxjQUFJLGFBQWEsYUFBYTtBQUM1Qix3QkFBWSxLQUFLLElBQUk7QUFBQSxVQUN2QjtBQUFBLFFBQ0Y7QUFHQSxjQUFNLGFBQ0osQ0FBQztBQUVILG1CQUFXLFFBQVEsYUFBYTtBQUM5QixnQkFBTSxXQUFXLE1BQU0sS0FBSyxvQkFBb0IsSUFBSTtBQUNwRCxjQUFJLFVBQVU7QUFDWix1QkFBVyxLQUFLLFFBQVE7QUFBQSxVQUMxQjtBQUFBLFFBQ0Y7QUFFQSxnQkFBUSxJQUFJLFNBQVMsV0FBVyxzQ0FBc0M7QUFDdEUsZUFBTztBQUFBLE1BQ1QsU0FBUyxPQUFQO0FBQ0EsZ0JBQVEsTUFBTSxxQ0FBcUMsS0FBSztBQUN4RCxlQUFPLENBQUM7QUFBQSxNQUNWO0FBQUEsSUFDRjtBQUFBO0FBQUEsRUFFTSx5QkFDSixVQUNBLE1BQ2dEO0FBQUE7QUFDaEQsY0FBUSxJQUFJLCtCQUErQixvQkFBb0IsTUFBTTtBQUVyRSxVQUFJO0FBRUYsY0FBTSxjQUFjLE1BQU0sS0FBSyx1QkFBdUIsVUFBVSxJQUFJO0FBRXBFLGNBQU0sYUFBb0QsQ0FBQztBQUUzRCxtQkFBVyxRQUFRLGFBQWE7QUFDOUIsZ0JBQU0sVUFBVSxNQUFNLEtBQUssSUFBSSxNQUFNLEtBQUssSUFBSTtBQUM5QyxnQkFBTSxXQUFXLEtBQUssa0JBQWtCLE1BQU0sT0FBTztBQUVyRCxxQkFBVyxLQUFLO0FBQUEsWUFDZCxNQUFNLEtBQUs7QUFBQSxZQUNYLE1BQU07QUFBQSxVQUNSLENBQUM7QUFBQSxRQUNIO0FBRUEsZ0JBQVE7QUFBQSxVQUNOLFNBQVMsV0FBVyxnQ0FBZ0MsZUFBZTtBQUFBLFFBQ3JFO0FBQ0EsZUFBTztBQUFBLE1BQ1QsU0FBUyxPQUFQO0FBQ0EsZ0JBQVE7QUFBQSxVQUNOLHFDQUFxQyxlQUFlO0FBQUEsVUFDcEQ7QUFBQSxRQUNGO0FBQ0EsZUFBTyxDQUFDO0FBQUEsTUFDVjtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRVEsb0JBQW9CLFVBQWlDO0FBRTNELFVBQU0sWUFBWTtBQUNsQixVQUFNLFVBQVUsU0FBUyxNQUFNLFNBQVM7QUFDeEMsV0FBTyxVQUFVLFFBQVEsUUFBUSxTQUFTLENBQUMsSUFBSTtBQUFBLEVBQ2pEO0FBQUEsRUFFYyxvQkFDWixNQUNpRTtBQUFBO0FBQ2pFLFVBQUk7QUFDRixjQUFNLFVBQVUsTUFBTSxLQUFLLElBQUksTUFBTSxLQUFLLElBQUk7QUFHOUMsY0FBTSxXQUFXLEtBQUssa0JBQWtCLE1BQU0sT0FBTztBQUdyRCxjQUFNLFdBQ0osS0FBSywyQkFBMkIsT0FBTyxLQUN2QyxLQUFLLHdCQUF3QixLQUFLLElBQUk7QUFFeEMsZUFBTztBQUFBLFVBQ0wsTUFBTSxLQUFLO0FBQUEsVUFDWCxNQUFNO0FBQUEsVUFDTixRQUFRLFlBQVk7QUFBQSxRQUN0QjtBQUFBLE1BQ0YsU0FBUyxPQUFQO0FBQ0EsZ0JBQVEsTUFBTSx3QkFBd0IsS0FBSyxTQUFTLEtBQUs7QUFDekQsZUFBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVRLGtCQUFrQixNQUFhLFNBQXlCO0FBQzlELFVBQU0sT0FBTyxLQUFLLEtBQUssWUFBWTtBQUduQyxRQUNFLEtBQUssU0FBUyxPQUFPLEtBQ3JCLFFBQVEsU0FBUywwQkFBMEIsR0FDM0M7QUFDQSxhQUFPO0FBQUEsSUFDVDtBQUdBLFFBQUksS0FBSyxTQUFTLFNBQVMsS0FBSyxRQUFRLFNBQVMsWUFBWSxHQUFHO0FBQzlELFVBQUksUUFBUSxTQUFTLCtCQUErQixHQUFHO0FBQ3JELGVBQU87QUFBQSxNQUNUO0FBQ0EsVUFBSSxRQUFRLFNBQVMsc0JBQXNCLEdBQUc7QUFDNUMsZUFBTztBQUFBLE1BQ1Q7QUFDQSxVQUFJLFFBQVEsU0FBUyx1QkFBdUIsR0FBRztBQUM3QyxlQUFPO0FBQUEsTUFDVDtBQUNBLFVBQUksUUFBUSxTQUFTLDBCQUEwQixHQUFHO0FBQ2hELGVBQU87QUFBQSxNQUNUO0FBQ0EsYUFBTztBQUFBLElBQ1Q7QUFHQSxRQUFJLFFBQVEsU0FBUyxLQUFLLEtBQUssUUFBUSxNQUFNLGlCQUFpQixHQUFHO0FBQy9ELGFBQU87QUFBQSxJQUNUO0FBRUEsV0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUVRLDJCQUEyQixTQUFnQztBQUNqRSxVQUFNLGdCQUFnQjtBQUN0QixVQUFNLFFBQVEsUUFBUSxNQUFNLGFBQWE7QUFDekMsV0FBTyxRQUFRLE1BQU0sQ0FBQyxJQUFJO0FBQUEsRUFDNUI7QUFBQSxFQUVRLHdCQUF3QixVQUFpQztBQUMvRCxVQUFNLGdCQUFnQjtBQUN0QixVQUFNLFVBQVUsU0FBUyxNQUFNLGFBQWE7QUFDNUMsV0FBTyxVQUFVLFFBQVEsUUFBUSxTQUFTLENBQUMsSUFBSTtBQUFBLEVBQ2pEO0FBQUEsRUFFYyx1QkFDWixVQUNBLE1BQ2tCO0FBQUE7QUFDbEIsWUFBTSxRQUFpQixDQUFDO0FBR3hCLFlBQU0sV0FBVyxLQUFLLElBQUksTUFBTSxpQkFBaUI7QUFFakQsaUJBQVcsUUFBUSxVQUFVO0FBRTNCLFlBQ0UsS0FBSyxLQUFLLFNBQVMsUUFBUSxNQUMxQixNQUFNLEtBQUssb0JBQW9CLE1BQU0sUUFBUSxJQUM5QztBQUVBLGdCQUFNLFdBQVcsS0FBSyxvQkFBb0IsS0FBSyxJQUFJO0FBQ25ELGNBQUksYUFBYSxNQUFNO0FBQ3JCLGtCQUFNLEtBQUssSUFBSTtBQUFBLFVBQ2pCO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFFQSxhQUFPO0FBQUEsSUFDVDtBQUFBO0FBQUEsRUFFYyxvQkFDWixNQUNBLFVBQ2tCO0FBQUE7QUFDbEIsVUFBSTtBQUNGLGNBQU0sVUFBVSxNQUFNLEtBQUssSUFBSSxNQUFNLEtBQUssSUFBSTtBQUM5QyxlQUFPLEtBQUssMkJBQTJCLE9BQU8sTUFBTTtBQUFBLE1BQ3RELFNBQVMsT0FBUDtBQUNBLGdCQUFRO0FBQUEsVUFDTiwwQkFBMEIsS0FBSywwQkFBMEI7QUFBQSxVQUN6RDtBQUFBLFFBQ0Y7QUFDQSxlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRU0scUJBQXFCLE1BQWdDO0FBQUE7QUFDekQsWUFBTSxhQUFhLFFBQVEsSUFBSSxLQUFLLEVBQUUsWUFBWSxFQUFFLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFDaEUsWUFBTSxhQUFhLE1BQU0sS0FBSyx5QkFBeUIsSUFBSSxVQUFVO0FBRXJFLFVBQUksV0FBVyxXQUFXLEdBQUc7QUFDM0IsZUFBTywyQkFBMkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUNwQztBQUdBLFlBQU0sV0FBOEMsQ0FBQztBQUNyRCxZQUFNLFdBQThCLENBQUM7QUFFckMsaUJBQVcsWUFBWSxZQUFZO0FBQ2pDLFlBQUksU0FBUyxLQUFLLFNBQVMsVUFBVSxHQUFHO0FBRXRDLGdCQUFNLFlBQVksU0FBUyxLQUFLLE1BQU0sR0FBRztBQUN6QyxnQkFBTSxjQUFjLFVBQVUsVUFBVSxDQUFDLFNBQVMsS0FBSyxTQUFTLEdBQUcsQ0FBQztBQUNwRSxjQUFJLGVBQWUsR0FBRztBQUNwQixrQkFBTSxXQUFXLFVBQVUsV0FBVztBQUN0QyxnQkFBSSxDQUFDLFNBQVMsUUFBUSxHQUFHO0FBQ3ZCLHVCQUFTLFFBQVEsSUFBSSxDQUFDO0FBQUEsWUFDeEI7QUFDQSxxQkFBUyxRQUFRLEVBQUUsS0FBSyxRQUFRO0FBQUEsVUFDbEMsT0FBTztBQUNMLHFCQUFTLEtBQUssUUFBUTtBQUFBLFVBQ3hCO0FBQUEsUUFDRixPQUFPO0FBQ0wsbUJBQVMsS0FBSyxRQUFRO0FBQUEsUUFDeEI7QUFBQSxNQUNGO0FBRUEsVUFBSSxVQUFVLDJCQUEyQjtBQUFBO0FBQUE7QUFDekMsaUJBQVcscUJBQXFCLFdBQVc7QUFBQTtBQUFBO0FBRzNDLGlCQUFXLENBQUMsVUFBVSxnQkFBZ0IsS0FBSyxPQUFPLFFBQVEsUUFBUSxHQUFHO0FBQ25FLG1CQUFXLE1BQU07QUFBQTtBQUFBO0FBQ2pCLG1CQUFXO0FBQUE7QUFDWCxtQkFBVztBQUFBO0FBRVgsbUJBQVcsWUFBWSxrQkFBa0I7QUFDdkMscUJBQVcsS0FBSyxTQUFTLFVBQVUsU0FBUztBQUFBO0FBQUEsUUFDOUM7QUFDQSxtQkFBVztBQUFBO0FBQUEsTUFDYjtBQUdBLFVBQUksU0FBUyxTQUFTLEdBQUc7QUFDdkIsbUJBQVc7QUFBQTtBQUFBO0FBQ1gsbUJBQVc7QUFBQTtBQUNYLG1CQUFXO0FBQUE7QUFFWCxtQkFBVyxZQUFZLFVBQVU7QUFDL0IscUJBQVcsS0FBSyxTQUFTLFVBQVUsU0FBUztBQUFBO0FBQUEsUUFDOUM7QUFDQSxtQkFBVztBQUFBO0FBQUEsTUFDYjtBQUVBLGFBQU87QUFBQSxJQUNUO0FBQUE7QUFBQSxFQUVNLHVCQUF1QixNQUE4QjtBQUFBO0FBQ3pELFVBQUk7QUFDRixjQUFNLGFBQWEsUUFBUSxJQUFJLEtBQUssRUFBRSxZQUFZLEVBQUUsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUNoRSxjQUFNLGlCQUFpQixNQUFNLEtBQUsscUJBQXFCLFVBQVU7QUFHakUsY0FBTSxXQUFXLEdBQUc7QUFDcEIsY0FBTSxXQUFXLFNBQVM7QUFFMUIsWUFBSTtBQUNGLGdCQUFNLEtBQUssSUFBSSxNQUFNLE9BQU8sVUFBVSxjQUFjO0FBQ3BELGtCQUFRLElBQUksK0JBQStCLFVBQVU7QUFBQSxRQUN2RCxTQUFTLE9BQVA7QUFFQSxnQkFBTSxlQUFlLEtBQUssSUFBSSxNQUFNLHNCQUFzQixRQUFRO0FBQ2xFLGNBQUksZ0JBQWdCLHdCQUF3Qix3QkFBTztBQUNqRCxrQkFBTSxLQUFLLElBQUksTUFBTSxPQUFPLGNBQWMsY0FBYztBQUN4RCxvQkFBUSxJQUFJLCtCQUErQixVQUFVO0FBQUEsVUFDdkQ7QUFBQSxRQUNGO0FBQUEsTUFDRixTQUFTLE9BQVA7QUFDQSxnQkFBUSxNQUFNLG9DQUFvQyxTQUFTLEtBQUs7QUFDaEUsY0FBTTtBQUFBLE1BQ1I7QUFBQSxJQUNGO0FBQUE7QUFDRjs7O0FQelJBLElBQXFCLHFCQUFyQixjQUFnRCx3QkFBTztBQUFBLEVBUS9DLFNBQVM7QUFBQTtBQUNiLGNBQVEsSUFBSSw4QkFBOEI7QUFHMUMsWUFBTSxLQUFLLGFBQWE7QUFHeEIsV0FBSyxrQkFBa0IsSUFBSSxnQkFBZ0IsS0FBSyxLQUFLLEtBQUssUUFBUTtBQUNsRSxXQUFLLGVBQWUsSUFBSSxxQkFBcUIsS0FBSyxLQUFLLEtBQUssUUFBUTtBQUNwRSxXQUFLLHNCQUFzQixJQUFJLG9CQUFvQixLQUFLLEdBQUc7QUFDM0QsV0FBSyxpQkFBaUIsSUFBSSxlQUFlLEtBQUssR0FBRztBQUNqRCxXQUFLLHdCQUF3QixJQUFJLHNCQUFzQixLQUFLLEdBQUc7QUFHL0QsV0FBSyxjQUFjLElBQUksdUJBQXVCLEtBQUssS0FBSyxJQUFJLENBQUM7QUFHN0QsV0FBSyw2QkFBNkI7QUFHbEMsV0FBSyxXQUFXO0FBQUEsUUFDZCxJQUFJO0FBQUEsUUFDSixNQUFNO0FBQUEsUUFDTixVQUFVLE1BQU07QUFDZCxlQUFLLGdCQUFnQixpQkFBaUI7QUFBQSxRQUN4QztBQUFBLE1BQ0YsQ0FBQztBQUVELFdBQUssV0FBVztBQUFBLFFBQ2QsSUFBSTtBQUFBLFFBQ0osTUFBTTtBQUFBLFFBQ04sVUFBVSxNQUFNO0FBQ2QsZUFBSyxnQkFBZ0IsZ0JBQWdCO0FBQUEsUUFDdkM7QUFBQSxNQUNGLENBQUM7QUFFRCxXQUFLLFdBQVc7QUFBQSxRQUNkLElBQUk7QUFBQSxRQUNKLE1BQU07QUFBQSxRQUNOLFVBQVUsTUFBTTtBQUNkLGVBQUssYUFBYSxxQkFBcUI7QUFBQSxRQUN6QztBQUFBLE1BQ0YsQ0FBQztBQUVELFdBQUssV0FBVztBQUFBLFFBQ2QsSUFBSTtBQUFBLFFBQ0osTUFBTTtBQUFBLFFBQ04sVUFBVSxNQUFZO0FBQ3BCLGdCQUFNLFdBQVcsTUFBTSxLQUFLO0FBQUEsWUFDMUI7QUFBQSxVQUNGO0FBQ0EsY0FBSSxVQUFVO0FBQ1osa0JBQU0sS0FBSyxvQkFBb0IsMEJBQTBCLFFBQVE7QUFBQSxVQUNuRTtBQUFBLFFBQ0Y7QUFBQSxNQUNGLENBQUM7QUFFRCxXQUFLLFdBQVc7QUFBQSxRQUNkLElBQUk7QUFBQSxRQUNKLE1BQU07QUFBQSxRQUNOLFVBQVUsTUFBWTtBQUNwQixnQkFBTSxXQUFXLE1BQU0sS0FBSztBQUFBLFlBQzFCO0FBQUEsVUFDRjtBQUNBLGNBQUksVUFBVTtBQUNaLGtCQUFNLEtBQUssZUFBZSwwQkFBMEIsUUFBUTtBQUFBLFVBQzlEO0FBQUEsUUFDRjtBQUFBLE1BQ0YsQ0FBQztBQUVELFdBQUssV0FBVztBQUFBLFFBQ2QsSUFBSTtBQUFBLFFBQ0osTUFBTTtBQUFBLFFBQ04sVUFBVSxNQUFZO0FBQ3BCLGdCQUFNLE9BQU8sTUFBTSxLQUFLO0FBQUEsWUFDdEI7QUFBQSxVQUNGO0FBQ0EsZ0JBQU0sS0FBSyxzQkFBc0I7QUFBQSxZQUMvQixRQUFRO0FBQUEsVUFDVjtBQUFBLFFBQ0Y7QUFBQSxNQUNGLENBQUM7QUFHRCxXQUFLLGlCQUFpQixFQUFFLFFBQVEsZUFBZTtBQUFBLElBQ2pEO0FBQUE7QUFBQSxFQUVjLGtCQUFrQixTQUF5QztBQUFBO0FBQ3ZFLFlBQU0sV0FBVyxPQUFPLFVBQVUsc0JBQXNCO0FBQ3hELGFBQU8sV0FBVyxTQUFTLEtBQUssSUFBSTtBQUFBLElBQ3RDO0FBQUE7QUFBQSxFQUVjLGNBQWMsU0FBeUM7QUFBQTtBQUNuRSxZQUFNLE9BQU87QUFBQSxRQUNYLFVBQVU7QUFBQSxNQUNaO0FBQ0EsYUFBTyxPQUFPLEtBQUssS0FBSyxJQUFJO0FBQUEsSUFDOUI7QUFBQTtBQUFBLEVBRUEsV0FBVztBQUNULFlBQVEsSUFBSSxnQ0FBZ0M7QUFBQSxFQUM5QztBQUFBLEVBRU0sK0JBQStCO0FBQUE7QUFFbkMsWUFBTSxrQkFBbUIsS0FBSyxJQUFZLFFBQVEsVUFBVSxvQkFBb0I7QUFDaEYsVUFBSSxDQUFDLGlCQUFpQjtBQUNwQixnQkFBUSxJQUFJLHNFQUFzRTtBQUNsRjtBQUFBLE1BQ0Y7QUFHQSxzQkFBZ0IsVUFBVSxrQkFBa0IscUJBQXFCO0FBQUEsUUFDL0QsTUFBTTtBQUFBLFFBQ04sR0FBRyxDQUFDLEtBQVUsSUFBUyxTQUFjO0FBQ25DLGlCQUFPLEtBQUssa0JBQWtCLEtBQUssSUFBSSxJQUFJO0FBQUEsUUFDN0M7QUFBQSxRQUNBLEtBQUs7QUFBQSxNQUNQLENBQUM7QUFFRCxzQkFBZ0IsVUFBVSxrQkFBa0IscUJBQXFCO0FBQUEsUUFDL0QsTUFBTTtBQUFBLFFBQ04sR0FBRyxDQUFDLE9BQVk7QUFDZCxpQkFBTyxLQUFLLG1CQUFtQixFQUFFO0FBQUEsUUFDbkM7QUFBQSxRQUNBLEtBQUs7QUFBQSxNQUNQLENBQUM7QUFBQSxJQUNIO0FBQUE7QUFBQSxFQUVNLGtCQUFrQixLQUFVLElBQVMsTUFBYztBQUFBO0FBckozRDtBQXVKSSxZQUFNLGVBQWUsTUFBTSxHQUFHLE9BQU8sT0FBTyw0QkFBNEIsRUFBRTtBQUMxRSxZQUFNLGFBQWEsTUFBTSxHQUFHLE9BQU8sT0FBTywwQkFBMEIsRUFBRTtBQUN0RSxZQUFNLFNBQVMsTUFBTSxHQUFHLE9BQU87QUFBQSxRQUM3QixNQUFNLElBQUksTUFBTSxpQkFBaUIsRUFBRSxPQUFPLENBQUMsTUFBVyxFQUFFLEtBQUssU0FBUyxTQUFTLENBQUMsRUFBRSxJQUFJLENBQUMsTUFBVyxFQUFFLFFBQVE7QUFBQSxRQUM1RyxJQUFJLE1BQU0saUJBQWlCLEVBQUUsT0FBTyxDQUFDLE1BQVcsRUFBRSxLQUFLLFNBQVMsU0FBUyxDQUFDO0FBQUEsTUFDNUU7QUFDQSxZQUFNLFdBQVcsU0FBUyxPQUFPLE1BQU0sS0FBSyxFQUFFLENBQUMsS0FBSyxTQUFTO0FBQzdELFlBQU0sYUFBYSxXQUFTLFlBQU8sTUFBTSxLQUFLLEVBQUUsQ0FBQyxNQUFyQixtQkFBd0IsVUFBVSxHQUFHLE9BQU0sUUFBUTtBQUMvRSxZQUFNLGFBQWEsQ0FBQyxVQUFVLFdBQVcsYUFBYSxZQUFZLFVBQVUsWUFBWSxRQUFRO0FBQ2hHLFlBQU0sWUFBWSxNQUFNLEdBQUcsT0FBTyxVQUFVLFlBQVksWUFBWSxhQUFhO0FBRWpGLGFBQU87QUFBQSxRQUNMLFFBQVE7QUFBQTtBQUFBLFFBQ1IsY0FBYyxnQkFBZ0I7QUFBQSxRQUM5QixZQUFZLGNBQWM7QUFBQSxRQUMxQjtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVNLG1CQUFtQixJQUFTO0FBQUE7QUE3S3BDO0FBOEtJLFlBQU0sZ0JBQWdCLE1BQU0sR0FBRyxPQUFPLE9BQU8sa0JBQWtCLEVBQUU7QUFDakUsWUFBTSxTQUFTLE1BQU0sR0FBRyxPQUFPO0FBQUEsUUFDN0IsTUFBTSxHQUFHLElBQUksTUFBTSxpQkFBaUIsRUFBRSxPQUFPLENBQUMsTUFBVyxFQUFFLEtBQUssU0FBUyxTQUFTLENBQUMsRUFBRSxJQUFJLENBQUMsTUFBVyxFQUFFLFFBQVE7QUFBQSxRQUMvRyxHQUFHLElBQUksTUFBTSxpQkFBaUIsRUFBRSxPQUFPLENBQUMsTUFBVyxFQUFFLEtBQUssU0FBUyxTQUFTLENBQUM7QUFBQSxNQUMvRTtBQUNBLFlBQU0sV0FBVyxTQUFTLE9BQU8sTUFBTSxLQUFLLEVBQUUsQ0FBQyxLQUFLLFNBQVM7QUFDN0QsWUFBTSxhQUFhLFdBQVMsWUFBTyxNQUFNLEtBQUssRUFBRSxDQUFDLE1BQXJCLG1CQUF3QixVQUFVLEdBQUcsT0FBTSxRQUFRO0FBQy9FLFlBQU0sY0FBYyxHQUFHLElBQUksTUFBTSxTQUFTLEVBQUUsT0FBTyxDQUFDLE1BQVcsRUFBRSxjQUFjLEtBQUssRUFBRSxJQUFJLENBQUMsTUFBVyxFQUFFLFFBQVE7QUFDaEgsWUFBTSxPQUFPLE1BQU0sR0FBRyxPQUFPLFVBQVUsYUFBYSxhQUFhLFVBQVU7QUFFM0UsYUFBTztBQUFBLFFBQ0wsZUFBZSxpQkFBaUI7QUFBQSxRQUNoQztBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVNLGVBQWU7QUFBQTtBQUNuQixXQUFLLFdBQVcsT0FBTyxPQUFPLENBQUMsR0FBRyxrQkFBa0IsTUFBTSxLQUFLLFNBQVMsQ0FBQztBQUFBLElBQzNFO0FBQUE7QUFBQSxFQUVNLGVBQWU7QUFBQTtBQUNuQixZQUFNLEtBQUssU0FBUyxLQUFLLFFBQVE7QUFBQSxJQUNuQztBQUFBO0FBQ0Y7IiwKICAibmFtZXMiOiBbImltcG9ydF9vYnNpZGlhbiIsICJpbXBvcnRfb2JzaWRpYW4iLCAiaW1wb3J0X29ic2lkaWFuIiwgImltcG9ydF9vYnNpZGlhbiIsICJpbXBvcnRfb2JzaWRpYW4iLCAiaW1wb3J0X29ic2lkaWFuIl0KfQo=
