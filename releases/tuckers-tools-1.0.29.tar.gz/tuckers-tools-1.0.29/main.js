var __defProp = Object.defineProperty;
var __defProps = Object.defineProperties;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getOwnPropSymbols = Object.getOwnPropertySymbols;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __propIsEnum = Object.prototype.propertyIsEnumerable;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __spreadValues = (a, b) => {
  for (var prop in b || (b = {}))
    if (__hasOwnProp.call(b, prop))
      __defNormalProp(a, prop, b[prop]);
  if (__getOwnPropSymbols)
    for (var prop of __getOwnPropSymbols(b)) {
      if (__propIsEnum.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    }
  return a;
};
var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __async = (__this, __arguments, generator) => {
  return new Promise((resolve, reject) => {
    var fulfilled = (value) => {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    };
    var rejected = (value) => {
      try {
        step(generator.throw(value));
      } catch (e) {
        reject(e);
      }
    };
    var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
    step((generator = generator.apply(__this, __arguments)).next());
  });
};

// main.ts
var main_exports = {};
__export(main_exports, {
  default: () => TuckersToolsPlugin
});
module.exports = __toCommonJS(main_exports);
var import_obsidian8 = require("obsidian");

// settings.ts
var import_obsidian = require("obsidian");

// utils.ts
function slugify(text) {
  return text.toLowerCase().trim().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9\s-]/g, "").replace(/[\s-]+/g, "-").replace(/^-+|-+$/g, "");
}
function validateDate(dateString) {
  const regex = /^\d{4}-\d{2}-\d{2}$/;
  if (!dateString.match(regex))
    return false;
  const date = new Date(dateString);
  const timestamp = date.getTime();
  if (typeof timestamp !== "number" || isNaN(timestamp))
    return false;
  return dateString === date.toISOString().split("T")[0];
}

// settings.ts
var DEFAULT_SETTINGS = {
  baseDirectory: "/",
  semesterStartDate: new Date().toISOString().split("T")[0],
  semesterEndDate: new Date(new Date().setMonth(new Date().getMonth() + 4)).toISOString().split("T")[0],
  schoolName: "University",
  schoolAbbreviation: "U",
  templateFolder: "Tuckers Tools",
  useEnhancedMetadata: false
};
var TuckersToolsSettingTab = class extends import_obsidian.PluginSettingTab {
  constructor(app, plugin) {
    super(app, plugin);
    this.plugin = plugin;
  }
  display() {
    const { containerEl } = this;
    containerEl.empty();
    containerEl.createEl("h2", { text: "Tuckers Tools Settings" });
    new import_obsidian.Setting(containerEl).setName("Base Directory").setDesc("Root directory for course content organization").addText((text) => text.setPlaceholder("/").setValue(this.plugin.settings.baseDirectory).onChange((value) => __async(this, null, function* () {
      this.plugin.settings.baseDirectory = value;
      yield this.plugin.saveSettings();
    })));
    const startDateSetting = new import_obsidian.Setting(containerEl).setName("Semester Start Date").setDesc("Start date for the current semester").addText((text) => text.setPlaceholder("YYYY-MM-DD").setValue(this.plugin.settings.semesterStartDate).onChange((value) => __async(this, null, function* () {
      if (value && !validateDate(value)) {
        startDateSetting.setDesc("Start date for the current semester (Invalid date format)");
      } else {
        startDateSetting.setDesc("Start date for the current semester");
      }
      this.plugin.settings.semesterStartDate = value;
      yield this.plugin.saveSettings();
    })));
    const endDateSetting = new import_obsidian.Setting(containerEl).setName("Semester End Date").setDesc("End date for the current semester").addText((text) => text.setPlaceholder("YYYY-MM-DD").setValue(this.plugin.settings.semesterEndDate).onChange((value) => __async(this, null, function* () {
      if (value && !validateDate(value)) {
        endDateSetting.setDesc("End date for the current semester (Invalid date format)");
      } else {
        endDateSetting.setDesc("End date for the current semester");
      }
      this.plugin.settings.semesterEndDate = value;
      yield this.plugin.saveSettings();
    })));
    new import_obsidian.Setting(containerEl).setName("School Name").setDesc("Name of your institution").addText((text) => text.setPlaceholder("University").setValue(this.plugin.settings.schoolName).onChange((value) => __async(this, null, function* () {
      this.plugin.settings.schoolName = value;
      yield this.plugin.saveSettings();
    })));
    new import_obsidian.Setting(containerEl).setName("School Abbreviation").setDesc("Abbreviation for your institution").addText((text) => text.setPlaceholder("U").setValue(this.plugin.settings.schoolAbbreviation).onChange((value) => __async(this, null, function* () {
      this.plugin.settings.schoolAbbreviation = value;
      yield this.plugin.saveSettings();
    })));
    new import_obsidian.Setting(containerEl).setName("Template Folder").setDesc("Subfolder within your Templater template folder for Tuckers Tools templates").addText((text) => text.setPlaceholder("Tuckers Tools").setValue(this.plugin.settings.templateFolder).onChange((value) => __async(this, null, function* () {
      this.plugin.settings.templateFolder = value;
      yield this.plugin.saveSettings();
    })));
    new import_obsidian.Setting(containerEl).setName("Use Enhanced Metadata").setDesc("Enable enhanced metadata fields for new notes (existing notes remain unchanged)").addToggle((toggle) => toggle.setValue(this.plugin.settings.useEnhancedMetadata).onChange((value) => __async(this, null, function* () {
      this.plugin.settings.useEnhancedMetadata = value;
      yield this.plugin.saveSettings();
    })));
  }
};

// templateManager.ts
var import_obsidian2 = require("obsidian");
var TemplateManager = class {
  constructor(app, settings) {
    this.app = app;
    this.settings = settings;
    this.manifest = {
      version: "1.0.0",
      templates: {
        "Courses/Create Course Homepage.md": "1.0.0",
        "Courses/Course Index.md": "1.0.0",
        "Modules/Create Module.md": "1.0.0",
        "Chapters/Create Chapter.md": "1.0.0",
        "Assignments/Create Assignment.md": "1.0.0",
        "Daily/Daily Note.md": "1.0.0",
        "Utilities/Vocabulary Entry.md": "1.0.0",
        "Utilities/Due Date Entry.md": "1.0.0"
      },
      plugin_version: "1.0.0",
      release_notes: "Initial release of Tuckers Tools templates"
    };
  }
  installTemplates() {
    return __async(this, null, function* () {
      try {
        const templaterPlugin = this.getTemplaterPlugin();
        if (!templaterPlugin) {
          new import_obsidian2.Notice(
            "Templater plugin not found. Please install and enable the Templater plugin first."
          );
          console.error(
            "Templater plugin not found. Please install and enable the Templater plugin first."
          );
          return;
        }
        const templateFolderPath = this.getTemplateFolderPath(templaterPlugin);
        if (!templateFolderPath) {
          new import_obsidian2.Notice(
            "Template folder not configured in Templater settings. Please configure it in Templater settings first."
          );
          console.error(
            "Template folder not configured in Templater settings. Please configure it in Templater settings first."
          );
          return;
        }
        const fullTemplatePath = `${templateFolderPath}/${this.settings.templateFolder}`;
        try {
          yield this.app.vault.createFolder(fullTemplatePath);
          console.log(`Created template folder: ${fullTemplatePath}`);
        } catch (e) {
          console.log(
            `Template folder already exists or created: ${fullTemplatePath}`
          );
        }
        const subdirs = [
          "Courses",
          "Modules",
          "Chapters",
          "Assignments",
          "Daily",
          "Utilities"
        ];
        for (const subdir of subdirs) {
          try {
            const subPath = `${fullTemplatePath}/${subdir}`;
            yield this.app.vault.createFolder(subPath);
            console.log(`Created subdirectory: ${subPath}`);
          } catch (e) {
            console.log(
              `Subdirectory already exists: ${fullTemplatePath}/${subdir}`
            );
          }
        }
        yield this.installCourseTemplates(fullTemplatePath);
        yield this.installModuleTemplates(fullTemplatePath);
        yield this.installChapterTemplates(fullTemplatePath);
        yield this.installAssignmentTemplates(fullTemplatePath);
        yield this.installDailyTemplates(fullTemplatePath);
        yield this.installUtilityTemplates(fullTemplatePath);
        yield this.createREADME(fullTemplatePath);
        yield this.createTemplateManifest(fullTemplatePath);
        new import_obsidian2.Notice("Tuckers Tools templates installed successfully!");
        console.log("Tuckers Tools templates installed successfully");
      } catch (error) {
        console.error("Error installing templates:", error);
        new import_obsidian2.Notice("Error installing templates. Check console for details.");
      }
    });
  }
  getTemplaterPlugin() {
    const possiblePaths = [
      this.app.plugins.plugins["templater-obsidian"],
      this.app.plugins.plugins["templater"],
      this.app.plugins.getPlugin("templater-obsidian"),
      this.app.plugins.getPlugin("templater")
    ];
    for (const path of possiblePaths) {
      if (path) {
        return path;
      }
    }
    return null;
  }
  getTemplateFolderPath(templaterPlugin) {
    const settings = templaterPlugin.settings;
    if (!settings) {
      console.error("Templater plugin has no settings");
      return null;
    }
    const possiblePaths = [
      settings.templates_folder,
      // Changed from template_folder to match actual setting
      settings.template_folder,
      settings.templateFolder,
      settings.templateFolderPath,
      settings.folder
    ];
    for (const path of possiblePaths) {
      if (path && typeof path === "string") {
        return path;
      }
    }
    console.error(
      "Template folder not found in Templater settings. Available settings:",
      Object.keys(settings)
    );
    return null;
  }
  createTemplateManifest(basePath) {
    return __async(this, null, function* () {
      const manifestPath = `${basePath}/template-manifest.json`;
      const manifestContent = JSON.stringify(this.manifest, null, 2);
      try {
        const existingManifest = this.app.vault.getAbstractFileByPath(manifestPath);
        if (existingManifest) {
          const file = existingManifest;
          yield this.app.vault.modify(file, manifestContent);
          console.log(`Updated template manifest: ${manifestPath}`);
          return;
        }
        yield this.app.vault.create(manifestPath, manifestContent);
        console.log(`Created template manifest: ${manifestPath}`);
      } catch (e) {
        new import_obsidian2.Notice(`Error creating template manifest ${manifestPath}`);
        console.error(`Error creating template manifest ${manifestPath}:`, e);
      }
    });
  }
  checkForTemplateUpdates() {
    return __async(this, null, function* () {
      console.log("Checking for template updates");
      return false;
    });
  }
  updateTemplates() {
    return __async(this, null, function* () {
      try {
        console.log("Updating templates");
        const templaterPlugin = this.getTemplaterPlugin();
        if (!templaterPlugin) {
          new import_obsidian2.Notice(
            "Templater plugin not found. Please install and enable the Templater plugin first."
          );
          console.error(
            "Templater plugin not found. Please install and enable the Templater plugin first."
          );
          return;
        }
        const templateFolderPath = this.getTemplateFolderPath(templaterPlugin);
        if (!templateFolderPath) {
          new import_obsidian2.Notice(
            "Template folder not configured in Templater settings. Please configure it in Templater settings first."
          );
          console.error(
            "Template folder not configured in Templater settings. Please configure it in Templater settings first."
          );
          return;
        }
        const fullTemplatePath = `${templateFolderPath}/${this.settings.templateFolder}`;
        yield this.installCourseTemplates(fullTemplatePath);
        yield this.installModuleTemplates(fullTemplatePath);
        yield this.installChapterTemplates(fullTemplatePath);
        yield this.installAssignmentTemplates(fullTemplatePath);
        yield this.installDailyTemplates(fullTemplatePath);
        yield this.installUtilityTemplates(fullTemplatePath);
        yield this.createREADME(fullTemplatePath);
        yield this.createTemplateManifest(fullTemplatePath);
        new import_obsidian2.Notice("Tuckers Tools templates updated successfully!");
        console.log("Tuckers Tools templates updated successfully");
      } catch (error) {
        console.error("Error updating templates:", error);
        new import_obsidian2.Notice("Error updating templates. Check console for details.");
      }
    });
  }
  installCourseTemplates(basePath) {
    return __async(this, null, function* () {
      const coursePath = `${basePath}/Courses`;
      const courseHomepageTemplate = this.generateCourseHomepageTemplate();
      yield this.writeTemplateFile(
        `${coursePath}/Create Course Homepage.md`,
        courseHomepageTemplate
      );
      const courseIndexTemplate = this.generateCourseIndexTemplate();
      yield this.writeTemplateFile(
        `${coursePath}/Course Index.md`,
        courseIndexTemplate
      );
    });
  }
  installModuleTemplates(basePath) {
    return __async(this, null, function* () {
      const modulePath = `${basePath}/Modules`;
      const moduleTemplate = this.generateModuleTemplate();
      yield this.writeTemplateFile(
        `${modulePath}/Create Module.md`,
        moduleTemplate
      );
    });
  }
  installChapterTemplates(basePath) {
    return __async(this, null, function* () {
      const chapterPath = `${basePath}/Chapters`;
      const chapterTemplate = this.generateChapterTemplate();
      yield this.writeTemplateFile(
        `${chapterPath}/Create Chapter.md`,
        chapterTemplate
      );
    });
  }
  installAssignmentTemplates(basePath) {
    return __async(this, null, function* () {
      const assignmentPath = `${basePath}/Assignments`;
      const assignmentTemplate = this.generateAssignmentTemplate();
      yield this.writeTemplateFile(
        `${assignmentPath}/Create Assignment.md`,
        assignmentTemplate
      );
    });
  }
  installDailyTemplates(basePath) {
    return __async(this, null, function* () {
      const dailyPath = `${basePath}/Daily`;
      const dailyNoteTemplate = this.generateDailyNoteTemplate();
      yield this.writeTemplateFile(
        `${dailyPath}/Daily Note.md`,
        dailyNoteTemplate
      );
    });
  }
  installUtilityTemplates(basePath) {
    return __async(this, null, function* () {
      const utilityPath = `${basePath}/Utilities`;
      const vocabTemplate = this.generateVocabularyTemplate();
      yield this.writeTemplateFile(
        `${utilityPath}/Vocabulary Entry.md`,
        vocabTemplate
      );
      const dueDateTemplate = this.generateDueDateTemplate();
      yield this.writeTemplateFile(
        `${utilityPath}/Due Date Entry.md`,
        dueDateTemplate
      );
    });
  }
  writeTemplateFile(path, content) {
    return __async(this, null, function* () {
      try {
        const existingFile = this.app.vault.getAbstractFileByPath(path);
        if (existingFile) {
          console.log(`Updating existing template file: ${path}`);
          const file = existingFile;
          yield this.app.vault.modify(file, content);
          return;
        }
        yield this.app.vault.create(path, content);
        console.log(`Created template file: ${path}`);
      } catch (e) {
        new import_obsidian2.Notice(`Error creating template file ${path}`);
        console.error(`Error creating template file ${path}:`, e);
      }
    });
  }
  generateCourseHomepageTemplate() {
    const enhancedMetadata = this.settings.useEnhancedMetadata;
    if (enhancedMetadata) {
      return `---
course_id: <% courseId %>
course_season: <% courseSeason %>
course_year: <% courseYear %>
created: <% tp.date.now("YYYY-MM-DD[T]HH:mm:ssZ") %>
tags: 
  - <% courseId %>
  - ${this.settings.schoolAbbreviation}/<% courseYear %>/<% courseSeason %>/<% courseId %>/
  - course_home
  - education
  - ${this.settings.schoolName.replace(/\s+/g, "_")}
banner:
cssclasses:
  - whiteboard-course
---

<%*
// Tuckers Tools Course Creation
// For best experience, use the plugin command: Command Palette \u2192 'Create New Course'

let courseName = "New Course";
let courseSeason = "Fall"; 
let courseYear = new Date().getFullYear().toString();
let courseId = "COURSE_ID";

// Try to use system prompts, with graceful fallback
try {
  if (tp && tp.system && tp.system.prompt) {
    courseName = await tp.system.prompt("Course Name (e.g. SWO-250 - Course Title)") || courseName;
    courseId = courseName.split(' - ')[0] || courseName.replace(/[^a-zA-Z0-9]/g, "_");
    courseSeason = await tp.system.suggester(["Fall","Winter","Spring","Summer"],["Fall","Winter","Spring","Summer"], "Season") || courseSeason;
    courseYear = await tp.system.prompt("Year") || courseYear;
  } else {
    console.log("System prompts not available, use the plugin command instead");
  }
} catch (e) {
  console.error("Error with system prompts:", e.message);
  console.log("Use the plugin command: Command Palette \u2192 'Create New Course'");
}

// Move file to appropriate location
await tp.file.move(\`/\${courseYear}/\${courseSeason}/\${courseName}/\${courseName}\`);

// Create attachments folder
try {
  await app.vault.createFolder(\`/\${courseYear}/\${courseSeason}/\${courseName}/Attachments\`);
} catch (e) {
  // Folder might already exist
}
%>

# <% courseName %>

## Course Information
**Course**: <% courseName %>
**Course ID**: <% courseId %>
**Term**: <% courseSeason %> <% courseYear %>
**School**: ${this.settings.schoolName}

## Instructor
**Name**: \`INPUT[text(instructor_name)]\`
**Email**: \`INPUT[text(instructor_email)]\`
**Office Hours**: \`INPUT[text(instructor_office_hours)]\`
**Office Location**: \`INPUT[text(instructor_office_location)]\`

## Course Description
\`INPUT[multiline(10x50)(course_description)]\`

## Learning Objectives
\`INPUT[multiline(10x50)(learning_objectives)]\`

## Required Texts
\`\`\`meta-bind-js-view
{texts} as texts
---
const availableTexts = app.vault.getFiles().filter(file => file.extension == 'pdf').map(f => f?.name)
const escapeRegex = /[,\`'()]/g;
options = availableTexts.map(t => \`option([[\${t.replace(escapeRegex,$1)}]], \${t.replace(escapeRegex,$1)})\` )
const str = \\\`INPUT[inlineListSuggester(\${options.join(", ")}):texts]\\\`
return engine.markdown.create(str)
\`\`\`

## Course Schedule
\`INPUT[multiline(20x50)(course_schedule)]\`

## Assignments
\`INPUT[multiline(15x50)(assignments)]\`

## Resources
\`INPUT[multiline(10x50)(resources)]\`

## Vocabulary
\`\`\`dataviewjs
const {processCourseVocabulary} = require("/Supporting/dataview-functions");
processCourseVocabulary(dv, '<% courseId %>');
\`\`\`

## Due Dates
\`\`\`dataviewjs
function processDueDates(dv, tag) {
  // Find all pages with the specified tag
  const pages = dv.pages(tag).file;

  // Array to store all rows
  const allRows = [];

  // For each page, extract the "Due Dates" section
  for (const page of pages.values()) {
    const content = app.vault.cachedRead(app.vault.getAbstractFileByPath(page.path));
    const regex = /# Due Dates\\s*
((?:.|
)*?)(?=
#|\\$)/;
    const match = content.match(regex);
    
    if (match && match[1]) {
      const tableContent = match[1];
      // Split content into lines and process table rows
      const lines = tableContent.split('
');
      
      for (const line of lines) {
        // Check if the line looks like a table row (contains | characters)
        if (line.includes('|')) {
          const columns = line.split('|').map(col => col.trim()).filter(col => col !== '');
          
          if (columns.length >= 2) { // Ensure there are at least 2 columns (due date, task)
            // Parse the date to check if it's valid
            const dueDate = columns[0];
            if (!Date.parse(dueDate)) continue; // Skip if not a valid date
            
            // Add the row data to the collection
            allRows.push([columns[0], columns[1], \`[[\${page.path}|\${page.name}]]\`]);
          }
        }
      }
    }
  }

  // Function to remove duplicate rows based on the first two columns
  const deduplicateFirstTwoColumns = (rows) => {
    const seen = new Set();
    return rows.filter(row => {
      const key = JSON.stringify([row[0], row[1]]); // Combine first two columns as a key
      if (seen.has(key)) {
        return false;
      }
      seen.add(key);
      return true;
    });
  };
  
  // Remove duplicates based on first two columns
  const allUniqueRows = deduplicateFirstTwoColumns(allRows);

  // Sort rows by date (parse the date string for comparison)
  const sortedRows = allUniqueRows.sort((a, b) => new Date(a[0]) - new Date(b[0]));

  // Create the table with the collected data
  const table = dv.markdownTable(
    ["Due Date", "Task Description", "File"], 
    sortedRows
  );

  return table;
}

processDueDates(dv,'#<% courseId %>');
\`\`\`

## Class Materials
\`INPUT[multiline(10x50)(class_materials)]\`

## Classmates
\`INPUT[multiline(15x50)(classmates)]\``;
    } else {
      return `---
course_id: <% courseId %>
course_name: <% courseName %>
course_season: <% courseSeason %>
course_year: <% courseYear %>
created: <% tp.date.now("YYYY-MM-DD[T]HH:mm:ssZ") %>
tags:
  - <% courseId %>
  - course_home
  - education
---

<%*
// Tuckers Tools Course Creation
// For best experience, use the plugin command: Command Palette \u2192 'Create New Course'

let courseName = "New Course";
let courseSeason = "Fall"; 
let courseYear = new Date().getFullYear().toString();
let courseId = "COURSE_ID";

// Try to use system prompts, with graceful fallback
try {
  if (tp && tp.system && tp.system.prompt) {
    courseName = await tp.system.prompt("Course Name (e.g. SWO-250 - Course Title)") || courseName;
    courseId = courseName.split(' - ')[0] || courseName.replace(/[^a-zA-Z0-9]/g, "_");
    courseSeason = await tp.system.suggester(["Fall","Winter","Spring","Summer"],["Fall","Winter","Spring","Summer"], "Season") || courseSeason;
    courseYear = await tp.system.prompt("Year") || courseYear;
  } else {
    console.log("System prompts not available, use the plugin command instead");
  }
} catch (e) {
  console.error("Error with system prompts:", e.message);
  console.log("Use the plugin command: Command Palette \u2192 'Create New Course'");
}

// Move file to appropriate location
await tp.file.move(\`/\${courseYear}/\${courseSeason}/\${courseName}/\${courseName}\`);

// Create attachments folder
try {
  await app.vault.createFolder(\`/\${courseYear}/\${courseSeason}/\${courseName}/Attachments\`);
} catch (e) {
  // Folder might already exist
}
%>

# <% courseName %>

## Course Information
**Course ID**: <% courseId %>
**Term**: <% courseSeason %> <% courseYear %>
**School**: ${this.settings.schoolName}

## Instructor
**Name**: \`INPUT[text(instructor_name)]\`
**Email**: \`INPUT[text(instructor_email)]\`
**Office Hours**: \`INPUT[text(instructor_office_hours)]\`
**Office Location**: \`INPUT[text(instructor_office_location)]\`

## Course Description
\`INPUT[multiline(10x50)(course_description)]\`

## Learning Objectives
\`INPUT[multiline(10x50)(learning_objectives)]\`

## Required Texts
\`\`\`meta-bind-js-view
{texts} as texts
---
const availableTexts = app.vault.getFiles().filter(file => file.extension == 'pdf').map(f => f?.name)
const escapeRegex = /[,\`'()]/g;
options = availableTexts.map(t => \`option([[\${t.replace(escapeRegex,$1)}]], \${t.replace(escapeRegex,$1)})\` )
const str = \\\`INPUT[inlineListSuggester(\${options.join(", ")}):texts]\\\`
return engine.markdown.create(str)
\`\`\`

## Schedule
\`INPUT[multiline(15x50)(course_schedule)]\`

## Assignments
\`INPUT[multiline(10x50)(assignments)]\`

## Resources
\`INPUT[multiline(10x50)(resources)]\`

## Vocabulary
\`\`\`dataviewjs
const {processCourseVocabulary} = require("/Supporting/dataview-functions");
processCourseVocabulary(dv, '<% courseId %>');
\`\`\`

## Due Dates
\`\`\`dataviewjs
function processDueDates(dv, tag) {
  // Find all pages with the specified tag
  const pages = dv.pages(tag).file;

  // Array to store all rows
  const allRows = [];

  // For each page, extract the "Due Dates" section
  for (const page of pages.values()) {
    const content = app.vault.cachedRead(app.vault.getAbstractFileByPath(page.path));
    const regex = /# Due Dates\\s*
((?:.|
)*?)(?=
#|\\$)/;
    const match = content.match(regex);
    
    if (match && match[1]) {
      const tableContent = match[1];
      // Split content into lines and process table rows
      const lines = tableContent.split('
');
      
      for (const line of lines) {
        // Check if the line looks like a table row (contains | characters)
        if (line.includes('|')) {
          const columns = line.split('|').map(col => col.trim()).filter(col => col !== '');
          
          if (columns.length >= 2) { // Ensure there are at least 2 columns (due date, task)
            // Parse the date to check if it's valid
            const dueDate = columns[0];
            if (!Date.parse(dueDate)) continue; // Skip if not a valid date
            
            // Add the row data to the collection
            allRows.push([columns[0], columns[1], \`[[\${page.path}|\${page.name}]]\`]);
          }
        }
      }
    }
  }

  // Function to remove duplicate rows based on the first two columns
  const deduplicateFirstTwoColumns = (rows) => {
    const seen = new Set();
    return rows.filter(row => {
      const key = JSON.stringify([row[0], row[1]]); // Combine first two columns as a key
      if (seen.has(key)) {
        return false;
      }
      seen.add(key);
      return true;
    });
  };
  
  // Remove duplicates based on first two columns
  const allUniqueRows = deduplicateFirstTwoColumns(allRows);

  // Sort rows by date (parse the date string for comparison)
  const sortedRows = allUniqueRows.sort((a, b) => new Date(a[0]) - new Date(b[0]));

  // Create the table with the collected data
  const table = dv.markdownTable(
    ["Due Date", "Task Description", "File"], 
    sortedRows
  );

  return table;
}

processDueDates(dv,'#<% courseId %>');
\`\`\``;
    }
  }
  generateCourseIndexTemplate() {
    return `---
content_type: course_index
tags:
  - index
---

# Course Index

## Modules

## Chapters

## Assignments

## Resources

## Vocabulary

## Due Dates`;
  }
  generateModuleTemplate() {
    return `---
${this.settings.useEnhancedMetadata ? `course_id: <% courseId %>
module_number: <% moduleNumber %>
week_number: <% weekNumber %>
class_day: <% dayOfWeek %>
content_type: module
parent_course: "[[<% course %>]]"` : `course_id: <% courseId %>
module_number: <% moduleNumber %>
week_number: <% weekNumber %>
class_day: <% dayOfWeek %>`}
created: <% tp.date.now("YYYY-MM-DD[T]HH:mm:ssZ") %>
tags:
  - education
  - <% courseId %>
  - module
---

<%*
const { season, moduleNumber, weekNumber, course, courseId, discipline, dayOfWeek } = await tp.user.new_module(app, tp, "2025");
let title = courseId
if (moduleNumber && weekNumber) { title = \`M\${moduleNumber}/W\${weekNumber}\`}
else if (moduleNumber) { title = \`M\${moduleNumber}\` } 
else if (weekNumber) { title = \`W\${weekNumber}\`}
%>

# [[<% course %>]] - <% title %> - <% dayOfWeek %>

## Learning Objectives

## Reading Assignment

## Lecture Notes

## Discussion Questions

## Assignments
| Date | Assignment | Status |
| ---- | ---------- | ------ |
|      |            |        |

## Vocabulary

## Additional Resources`;
  }
  generateChapterTemplate() {
    return `---
${this.settings.useEnhancedMetadata ? `course_id: <% courseId %>
chapter_number: <% chapterNumber %>
content_type: chapter
parent_course: "[[<% course %>]]"
text_reference: "[[<% text %>]]"` : `course_id: <% courseId %>
chapter_number: <% chapterNumber %>`}
created: <% tp.date.now("YYYY-MM-DD[T]HH:mm:ssZ") %>
tags:
  - education
  - <% courseId %>
  - chapter
---

<%*
const { chapterNumber, course, courseId, discipline, text} = await tp.user.new_chapter(tp);
%>

# [[<% text %>]] - Chapter <% chapterNumber %>

## Summary

## Key Concepts

## Vocabulary
- 

## Notes

## Discussion Questions

## Further Reading`;
  }
  generateAssignmentTemplate() {
    return `---
${this.settings.useEnhancedMetadata ? `course_id: <% courseId %>
assignment_type: <% assignmentType %>
due_date: <% dueDate %>
points: <% points %>
content_type: assignment
parent_course: "[[<% course %>]]"` : `course_id: <% courseId %>
assignment_type: <% assignmentType %>
due_date: <% dueDate %>`}
created: <% tp.date.now("YYYY-MM-DD[T]HH:mm:ssZ") %>
status: pending
tags:
  - education
  - <% courseId %>
  - assignment
---

# <% assignmentName %> - <% courseId %>

## Description

## Instructions

## Due Date
**Assigned**: <% tp.date.now("YYYY-MM-DD") %>
**Due**: <% dueDate %>

## Submission

## Grading Criteria

## Resources`;
  }
  generateDailyNoteTemplate() {
    return `---
content_type: daily_note
date: <% tp.date.now("YYYY-MM-DD") %>
tags:
  - daily
  - <% tp.date.now("YYYY") %>
  - <% tp.date.now("MM") %>
  - <% tp.date.now("DD") %>
---

# <% tp.date.now("YYYY-MM-DD - dddd") %>

<< [[<% tp.date.yesterday("YYYY-MM-DD") %>]] | [[<% tp.date.tomorrow("YYYY-MM-DD") %>]] >>

## Today's Focus

## Courses Worked On
- 

## Tasks Completed
- [ ] 

## Vocabulary Reviewed
- 

## Assignments Due
- 

## Learning Achievements

## Challenges

## Tomorrow's Plan

## Reflection`;
  }
  generateVocabularyTemplate() {
    return `## <% term %>
**Term**: <% term %>
**Part of Speech**: 
**Definition**: 
**Context**: 
**Examples**: 
**Related Terms**: 
**See Also**:`;
  }
  generateDueDateTemplate() {
    return `| <% dueDate %> | <% assignment %> | <% status %> |`;
  }
  createREADME(basePath) {
    return __async(this, null, function* () {
      const readmeContent = `# Tuckers Tools Templates

This directory contains templates for the Tuckers Tools Obsidian plugin.

## Template Categories

- **Courses**: Templates for creating and organizing courses
- **Modules**: Templates for course modules
- **Chapters**: Templates for chapter notes
- **Assignments**: Templates for assignments
- **Daily**: Templates for daily notes
- **Utilities**: Helper templates

## Usage

These templates are designed to work with the Tuckers Tools plugin. To use them:

1. Install the Tuckers Tools plugin
2. Configure your settings in the plugin settings tab
3. Use the "Insert Template" command to apply these templates to new notes

## Customization

Feel free to customize these templates to suit your needs. The plugin will not overwrite your changes when updating templates.`;
      yield this.writeTemplateFile(`${basePath}/README.md`, readmeContent);
    });
  }
};

// courseWizard.ts
var import_obsidian4 = require("obsidian");

// inputModal.ts
var import_obsidian3 = require("obsidian");
var InputModal = class extends import_obsidian3.Modal {
  constructor(app, onSubmit) {
    super(app);
    this.onSubmit = onSubmit;
  }
  onOpen() {
    const { contentEl } = this;
    contentEl.createEl("h2", { text: "Enter Value" });
    new import_obsidian3.Setting(contentEl).setName("Value").addText(
      (text) => text.onChange((value) => {
        this.result = value;
      }).inputEl.focus()
    );
    new import_obsidian3.Setting(contentEl).addButton(
      (btn) => btn.setButtonText("Submit").setCta().onClick(() => {
        this.close();
        this.onSubmit(this.result || "");
      })
    ).addButton(
      (btn) => btn.setButtonText("Cancel").onClick(() => {
        this.close();
        this.onSubmit(null);
      })
    );
  }
  onClose() {
    const { contentEl } = this;
    contentEl.empty();
  }
};
var SuggesterModal = class extends import_obsidian3.Modal {
  constructor(app, options, onSubmit) {
    super(app);
    this.onSubmit = onSubmit;
    const dropdownOptions = {};
    options.forEach((option) => {
      dropdownOptions[option] = option;
    });
    this.createDropdown(dropdownOptions);
  }
  createDropdown(options) {
    const { contentEl } = this;
    contentEl.createEl("h2", { text: "Select Option" });
    let selectedValue = Object.keys(options)[0] || null;
    const dropdown = contentEl.createEl("select");
    Object.entries(options).forEach(([key, value]) => {
      const option = dropdown.createEl("option", {
        value: key,
        text: value
      });
      if (key === selectedValue) {
        option.selected = true;
      }
    });
    dropdown.addEventListener("change", (event) => {
      selectedValue = event.target.value;
      this.result = selectedValue;
    });
    new import_obsidian3.Setting(contentEl).addButton(
      (btn) => btn.setButtonText("Submit").setCta().onClick(() => {
        this.close();
        this.onSubmit(selectedValue);
      })
    ).addButton(
      (btn) => btn.setButtonText("Cancel").onClick(() => {
        this.close();
        this.onSubmit(null);
      })
    );
  }
  onOpen() {
  }
  onClose() {
    const { contentEl } = this;
    contentEl.empty();
  }
};

// courseWizard.ts
var CourseCreationWizard = class {
  constructor(app, settings) {
    this.app = app;
    this.settings = settings;
  }
  createCourseHomepage() {
    return __async(this, null, function* () {
      try {
        const courseDetails = yield this.promptCourseDetails();
        if (!courseDetails) {
          return false;
        }
        const folderPath = yield this.createCourseFolderStructure(courseDetails);
        yield this.createCourseHomepageNote(courseDetails, folderPath);
        yield this.createAttachmentsFolder(folderPath);
        new import_obsidian4.Notice(`Course "${courseDetails.courseName}" created successfully!`);
        console.log(
          `Course created: ${courseDetails.courseName} at ${folderPath}`
        );
        return true;
      } catch (error) {
        console.error("Error creating course:", error);
        new import_obsidian4.Notice(`Error creating course: ${error.message}`);
        return false;
      }
    });
  }
  promptCourseDetails() {
    return __async(this, null, function* () {
      var _a;
      try {
        const courseName = yield this.promptWithValidation(
          "Course Name",
          "Enter course name (e.g., PSI-101 - Intro to Psychology)",
          (value) => value.trim().length > 0,
          "Course name is required"
        );
        if (!courseName)
          return null;
        const courseSeason = yield this.promptWithOptions(
          "Season",
          "Select semester/season",
          ["Fall", "Winter", "Spring", "Summer"]
        );
        if (!courseSeason)
          return null;
        const courseYear = yield this.promptWithValidation(
          "Year",
          "Enter academic year (e.g., 2025)",
          (value) => /^\d{4}$/.test(value.trim()),
          "Please enter a valid 4-digit year"
        );
        if (!courseYear)
          return null;
        const courseId = ((_a = courseName.split(" - ")[0]) == null ? void 0 : _a.trim()) || slugify(courseName);
        return {
          courseName,
          courseSeason,
          courseYear,
          courseId
        };
      } catch (error) {
        console.error("Error prompting for course details:", error);
        return null;
      }
    });
  }
  promptWithValidation(title, message, validator, errorMessage) {
    return __async(this, null, function* () {
      return new Promise((resolve) => {
        const modal = new InputModal(this.app, (result) => {
          if (result === null) {
            resolve(null);
            return;
          }
          if (!validator(result)) {
            new import_obsidian4.Notice(errorMessage);
            this.promptWithValidation(title, message, validator, errorMessage).then(resolve);
            return;
          }
          resolve(result.trim());
        });
        modal.titleEl.setText(title);
        const messageEl = modal.contentEl.createDiv();
        messageEl.setText(message);
        modal.open();
      });
    });
  }
  promptWithOptions(title, message, options) {
    return __async(this, null, function* () {
      return new Promise((resolve) => {
        const modal = new SuggesterModal(this.app, options, (result) => {
          if (result === null) {
            resolve(null);
            return;
          }
          if (options.includes(result)) {
            resolve(result);
          } else {
            new import_obsidian4.Notice(`Please select one of: ${options.join(", ")}`);
            this.promptWithOptions(title, message, options).then(resolve);
          }
        });
        modal.titleEl.setText(title);
        const messageEl = modal.contentEl.createDiv();
        messageEl.setText(message);
        modal.open();
      });
    });
  }
  createCourseFolderStructure(courseDetails) {
    return __async(this, null, function* () {
      const folderPath = `${courseDetails.courseYear}/${courseDetails.courseSeason}/${courseDetails.courseName}`;
      try {
        yield this.app.vault.createFolder(folderPath);
        console.log(`Created course folder: ${folderPath}`);
        return folderPath;
      } catch (error) {
        console.log(`Course folder already exists or created: ${folderPath}`);
        return folderPath;
      }
    });
  }
  createCourseHomepageNote(courseDetails, folderPath) {
    return __async(this, null, function* () {
      const notePath = `${folderPath}/${courseDetails.courseName}.md`;
      const content = this.generateCourseHomepageContent(courseDetails);
      try {
        yield this.app.vault.create(notePath, content);
        console.log(`Created course homepage: ${notePath}`);
      } catch (error) {
        console.error(`Error creating course homepage: ${error}`);
        throw error;
      }
    });
  }
  createAttachmentsFolder(folderPath) {
    return __async(this, null, function* () {
      const attachmentsPath = `${folderPath}/Attachments`;
      try {
        yield this.app.vault.createFolder(attachmentsPath);
        console.log(`Created attachments folder: ${attachmentsPath}`);
      } catch (error) {
        console.log(`Attachments folder already exists: ${attachmentsPath}`);
      }
    });
  }
  generateCourseHomepageContent(courseDetails) {
    const enhancedMetadata = this.settings.useEnhancedMetadata;
    return `---
${enhancedMetadata ? `course_id: ${courseDetails.courseId}
course_name: ${courseDetails.courseName}
course_term: ${courseDetails.courseSeason} ${courseDetails.courseYear}
course_year: ${courseDetails.courseYear}
course_semester: ${courseDetails.courseSeason}
content_type: course_homepage
school: ${this.settings.schoolName}
school_abbreviation: ${this.settings.schoolAbbreviation}` : `course_id: ${courseDetails.courseId}
title: ${courseDetails.courseName}`}
created: ${new Date().toISOString()}
tags:
 - course_home
 - education
 - ${courseDetails.courseId}
 - ${this.settings.schoolAbbreviation}/${courseDetails.courseYear}/${courseDetails.courseSeason}/${courseDetails.courseId}
---


# ${courseDetails.courseName}

## Course Information
**Course ID**: ${courseDetails.courseId}
**Term**: ${courseDetails.courseSeason} ${courseDetails.courseYear}
**School**: ${this.settings.schoolName}

## Instructor
**Name**:
**Email**:
**Office Hours**:

## Course Description

## Learning Objectives

## Required Texts

## Schedule

## Assignments

## Resources

## Vocabulary

## Due Dates`;
  }
};

// vocabulary.ts
var import_obsidian5 = require("obsidian");
var VocabularyExtractor = class {
  constructor(app) {
    this.app = app;
  }
  extractVocabularyFromNote(content) {
    const vocabRegex = /^#+ Vocabulary.*\n((?:.*?\n)*?)(?=^\s*#\s|$)/m;
    const vocabMatches = content == null ? void 0 : content.match(vocabRegex);
    if (vocabMatches) {
      const vocabData = vocabMatches[1].trim();
      const cleanedVocab = vocabData.replace(/\[\[.*?\]\]/g, "").replace(/^\s*-\s*/gm, "").split("\n").map((term) => term.trim()).filter((term) => term.length > 0);
      return cleanedVocab;
    }
    return [];
  }
  extractVocabularyFromCourse(courseId) {
    return __async(this, null, function* () {
      console.log(`Extracting vocabulary for course: ${courseId}`);
      try {
        const courseNotes = yield this.findCourseNotes(courseId);
        if (courseNotes.length === 0) {
          console.log(`No notes found for course: ${courseId}`);
          return {};
        }
        const vocabularyData = {};
        for (const note of courseNotes) {
          try {
            const content = yield this.app.vault.read(note);
            const vocabulary = this.extractVocabularyFromNote(content);
            if (vocabulary.length > 0) {
              vocabularyData[note.basename] = vocabulary;
            }
          } catch (error) {
            console.error(`Error reading note ${note.path}:`, error);
          }
        }
        console.log(
          `Extracted vocabulary from ${Object.keys(vocabularyData).length} notes for course: ${courseId}`
        );
        return vocabularyData;
      } catch (error) {
        console.error(
          `Error extracting vocabulary for course ${courseId}:`,
          error
        );
        return {};
      }
    });
  }
  findCourseNotes(courseId) {
    return __async(this, null, function* () {
      const notes = [];
      const files = this.app.vault.getMarkdownFiles();
      for (const file of files) {
        if (file.path.includes(courseId) || (yield this.noteBelongsToCourse(file, courseId))) {
          notes.push(file);
        }
      }
      return notes;
    });
  }
  noteBelongsToCourse(file, courseId) {
    return __async(this, null, function* () {
      try {
        const content = yield this.app.vault.read(file);
        const frontmatterMatch = content.match(/^---\n([\s\S]*?)\n---/);
        if (frontmatterMatch) {
          const frontmatter = frontmatterMatch[1];
          return frontmatter.includes(`course_id: ${courseId}`) || frontmatter.includes(`course_id:${courseId}`);
        }
        return false;
      } catch (error) {
        console.error(
          `Error checking if note ${file.path} belongs to course ${courseId}:`,
          error
        );
        return false;
      }
    });
  }
  generateVocabularyIndex(courseId, vocabularyData) {
    return __async(this, null, function* () {
      const allTerms = [];
      const termSources = {};
      for (const [noteName, terms] of Object.entries(vocabularyData)) {
        for (const term of terms) {
          if (!allTerms.includes(term)) {
            allTerms.push(term);
            termSources[term] = [];
          }
          termSources[term].push(noteName);
        }
      }
      allTerms.sort();
      let content = `# Vocabulary Index - ${courseId}

`;
      content += `Total unique terms: ${allTerms.length}

`;
      for (const term of allTerms) {
        content += `## ${term}
`;
        content += `**Sources:** ${termSources[term].join(", ")}

`;
        content += `**Definition:**

`;
        content += `**Context:**

`;
        content += `**Examples:**

`;
        content += `---

`;
      }
      return content;
    });
  }
  createVocabularyIndexFile(courseId) {
    return __async(this, null, function* () {
      try {
        const vocabularyData = yield this.extractVocabularyFromCourse(courseId);
        if (Object.keys(vocabularyData).length === 0) {
          console.log(`No vocabulary found for course: ${courseId}`);
          return;
        }
        const indexContent = yield this.generateVocabularyIndex(
          courseId,
          vocabularyData
        );
        const fileName = `${courseId} - Vocabulary Index.md`;
        const filePath = `Courses/${courseId}/${fileName}`;
        try {
          yield this.app.vault.create(filePath, indexContent);
          console.log(`Created vocabulary index file: ${filePath}`);
        } catch (error) {
          const existingFile = this.app.vault.getAbstractFileByPath(filePath);
          if (existingFile && existingFile instanceof import_obsidian5.TFile) {
            yield this.app.vault.modify(existingFile, indexContent);
            console.log(`Updated vocabulary index file: ${filePath}`);
          }
        }
      } catch (error) {
        console.error(
          `Error creating vocabulary index for course ${courseId}:`,
          error
        );
        throw error;
      }
    });
  }
};

// dueDates.ts
var import_obsidian6 = require("obsidian");
var DueDatesParser = class {
  constructor(app) {
    this.app = app;
  }
  parseDueDatesFromNote(content) {
    const dueDatesRegex = /# Due Dates[\s\S]*?(?=\n#|$)/;
    const matches = content == null ? void 0 : content.match(dueDatesRegex);
    if (!matches) {
      return [];
    }
    const dueDatesSection = matches[0];
    const dueDates = [];
    const tableRegex = /\|[\s\S]*?\n/g;
    const tableMatches = dueDatesSection.match(tableRegex);
    if (tableMatches) {
      for (const table of tableMatches) {
        const rows = table.trim().split("\n").filter((row) => row.startsWith("|"));
        const parsedRows = this.parseTableRows(rows);
        dueDates.push(...parsedRows);
      }
    }
    return dueDates;
  }
  parseTableRows(rows) {
    if (rows.length < 2)
      return [];
    const dueDates = [];
    for (let i = 1; i < rows.length; i++) {
      const row = rows[i];
      const columns = row.split("|").map((col) => col.trim()).filter((col) => col);
      if (columns.length >= 2) {
        const [date, assignment, status = "pending"] = columns;
        if (date && assignment && this.isValidDate(date)) {
          dueDates.push({ date, assignment, status });
        }
      }
    }
    return dueDates;
  }
  isValidDate(dateString) {
    const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
    return dateRegex.test(dateString) && !isNaN(Date.parse(dateString));
  }
  parseDueDatesFromCourse(courseId, startDate, endDate) {
    return __async(this, null, function* () {
      console.log(`Parsing due dates for course: ${courseId}`);
      try {
        const courseNotes = yield this.findCourseNotes(courseId);
        if (courseNotes.length === 0) {
          console.log(`No notes found for course: ${courseId}`);
          return [];
        }
        const allDueDates = [];
        for (const note of courseNotes) {
          try {
            const content = yield this.app.vault.read(note);
            const dueDates = this.parseDueDatesFromNote(content);
            const dueDatesWithSource = dueDates.map((dueDate) => __spreadProps(__spreadValues({}, dueDate), {
              source: note.basename
            }));
            allDueDates.push(...dueDatesWithSource);
          } catch (error) {
            console.error(`Error reading note ${note.path}:`, error);
          }
        }
        let filteredDueDates = allDueDates;
        if (startDate || endDate) {
          filteredDueDates = this.filterByDateRange(
            allDueDates,
            startDate,
            endDate
          );
        }
        filteredDueDates.sort(
          (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()
        );
        console.log(
          `Found ${filteredDueDates.length} due dates for course: ${courseId}`
        );
        return filteredDueDates;
      } catch (error) {
        console.error(`Error parsing due dates for course ${courseId}:`, error);
        return [];
      }
    });
  }
  findCourseNotes(courseId) {
    return __async(this, null, function* () {
      const notes = [];
      const files = this.app.vault.getMarkdownFiles();
      for (const file of files) {
        if (file.path.includes(courseId) || (yield this.noteBelongsToCourse(file, courseId))) {
          notes.push(file);
        }
      }
      return notes;
    });
  }
  noteBelongsToCourse(file, courseId) {
    return __async(this, null, function* () {
      try {
        const content = yield this.app.vault.read(file);
        const frontmatterMatch = content.match(/^---\n([\s\S]*?)\n---/);
        if (frontmatterMatch) {
          const frontmatter = frontmatterMatch[1];
          return frontmatter.includes(`course_id: ${courseId}`) || frontmatter.includes(`course_id:${courseId}`);
        }
        return false;
      } catch (error) {
        console.error(
          `Error checking if note ${file.path} belongs to course ${courseId}:`,
          error
        );
        return false;
      }
    });
  }
  filterByDateRange(dueDates, startDate, endDate) {
    return dueDates.filter((dueDate) => {
      const dueDateTime = new Date(dueDate.date).getTime();
      if (startDate && dueDateTime < new Date(startDate).getTime()) {
        return false;
      }
      if (endDate && dueDateTime > new Date(endDate).getTime()) {
        return false;
      }
      return true;
    });
  }
  generateDueDatesSummary(courseId, dueDates) {
    return __async(this, null, function* () {
      if (dueDates.length === 0) {
        return `# Due Dates Summary - ${courseId}

No due dates found.
`;
      }
      const byStatus = dueDates.reduce((acc, dueDate) => {
        if (!acc[dueDate.status]) {
          acc[dueDate.status] = [];
        }
        acc[dueDate.status].push(dueDate);
        return acc;
      }, {});
      let content = `# Due Dates Summary - ${courseId}

`;
      content += `Total assignments: ${dueDates.length}

`;
      for (const [status, items] of Object.entries(byStatus)) {
        content += `## ${status.charAt(0).toUpperCase() + status.slice(1)} (${items.length})

`;
        content += `| Date | Assignment | Source |
`;
        content += `| ---- | ---------- | ------ |
`;
        for (const item of items) {
          content += `| ${item.date} | ${item.assignment} | ${item.source} |
`;
        }
        content += `
`;
      }
      return content;
    });
  }
  createDueDatesSummaryFile(courseId, startDate, endDate) {
    return __async(this, null, function* () {
      try {
        const dueDates = yield this.parseDueDatesFromCourse(
          courseId,
          startDate,
          endDate
        );
        const summaryContent = yield this.generateDueDatesSummary(
          courseId,
          dueDates
        );
        const fileName = `${courseId} - Due Dates Summary.md`;
        const filePath = `Courses/${courseId}/${fileName}`;
        try {
          yield this.app.vault.create(filePath, summaryContent);
          console.log(`Created due dates summary file: ${filePath}`);
        } catch (error) {
          const existingFile = this.app.vault.getAbstractFileByPath(filePath);
          if (existingFile && existingFile instanceof import_obsidian6.TFile) {
            yield this.app.vault.modify(existingFile, summaryContent);
            console.log(`Updated due dates summary file: ${filePath}`);
          }
        }
      } catch (error) {
        console.error(
          `Error creating due dates summary for course ${courseId}:`,
          error
        );
        throw error;
      }
    });
  }
};

// dailyNotes.ts
var import_obsidian7 = require("obsidian");
var DailyNotesIntegration = class {
  constructor(app) {
    this.app = app;
  }
  getTodaysActivities() {
    return __async(this, null, function* () {
      console.log("Getting today's academic activities");
      try {
        const today = new Date();
        const todayString = today.toISOString().split("T")[0];
        const files = this.app.vault.getMarkdownFiles();
        const todaysFiles = [];
        for (const file of files) {
          const fileDate = this.extractDateFromPath(file.path);
          if (fileDate === todayString) {
            todaysFiles.push(file);
          }
        }
        const activities = [];
        for (const file of todaysFiles) {
          const activity = yield this.analyzeFileActivity(file);
          if (activity) {
            activities.push(activity);
          }
        }
        console.log(`Found ${activities.length} academic activities for today`);
        return activities;
      } catch (error) {
        console.error("Error getting today's activities:", error);
        return [];
      }
    });
  }
  getCourseActivityForDate(courseId, date) {
    return __async(this, null, function* () {
      console.log(`Getting activity for course ${courseId} on date ${date}`);
      try {
        const courseFiles = yield this.findCourseFilesForDate(courseId, date);
        const activities = [];
        for (const file of courseFiles) {
          const content = yield this.app.vault.read(file);
          const fileType = this.determineFileType(file, content);
          activities.push({
            file: file.basename,
            type: fileType
          });
        }
        console.log(
          `Found ${activities.length} activities for course ${courseId} on ${date}`
        );
        return activities;
      } catch (error) {
        console.error(
          `Error getting course activity for ${courseId} on ${date}:`,
          error
        );
        return [];
      }
    });
  }
  extractDateFromPath(filePath) {
    const dateRegex = /(\d{4}-\d{2}-\d{2})/g;
    const matches = filePath.match(dateRegex);
    return matches ? matches[matches.length - 1] : null;
  }
  analyzeFileActivity(file) {
    return __async(this, null, function* () {
      try {
        const content = yield this.app.vault.read(file);
        const fileType = this.determineFileType(file, content);
        const courseId = this.extractCourseIdFromContent(content) || this.extractCourseIdFromPath(file.path);
        return {
          file: file.basename,
          type: fileType,
          course: courseId || void 0
        };
      } catch (error) {
        console.error(`Error analyzing file ${file.path}:`, error);
        return null;
      }
    });
  }
  determineFileType(file, content) {
    const path = file.path.toLowerCase();
    if (path.includes("daily") || content.includes("content_type: daily_note")) {
      return "daily_note";
    }
    if (path.includes("courses") || content.includes("course_id:")) {
      if (content.includes("content_type: course_homepage")) {
        return "course_homepage";
      }
      if (content.includes("content_type: module")) {
        return "module";
      }
      if (content.includes("content_type: chapter")) {
        return "chapter";
      }
      if (content.includes("content_type: assignment")) {
        return "assignment";
      }
      return "course_note";
    }
    if (content.includes("## ") && content.match(/^\*\*Term\*\*:/m)) {
      return "vocabulary_entry";
    }
    return "other";
  }
  extractCourseIdFromContent(content) {
    const courseIdRegex = /course_id:\s*([A-Z]{2,4}-\d{3})/;
    const match = content.match(courseIdRegex);
    return match ? match[1] : null;
  }
  extractCourseIdFromPath(filePath) {
    const courseIdRegex = /([A-Z]{2,4}-\d{3})/g;
    const matches = filePath.match(courseIdRegex);
    return matches ? matches[matches.length - 1] : null;
  }
  findCourseFilesForDate(courseId, date) {
    return __async(this, null, function* () {
      const files = [];
      const allFiles = this.app.vault.getMarkdownFiles();
      for (const file of allFiles) {
        if (file.path.includes(courseId) || (yield this.fileBelongsToCourse(file, courseId))) {
          const fileDate = this.extractDateFromPath(file.path);
          if (fileDate === date) {
            files.push(file);
          }
        }
      }
      return files;
    });
  }
  fileBelongsToCourse(file, courseId) {
    return __async(this, null, function* () {
      try {
        const content = yield this.app.vault.read(file);
        return this.extractCourseIdFromContent(content) === courseId;
      } catch (error) {
        console.error(
          `Error checking if file ${file.path} belongs to course ${courseId}:`,
          error
        );
        return false;
      }
    });
  }
  generateDailySummary(date) {
    return __async(this, null, function* () {
      const targetDate = date || new Date().toISOString().split("T")[0];
      const activities = yield this.getCourseActivityForDate("", targetDate);
      if (activities.length === 0) {
        return `# Academic Activities - ${targetDate}

No academic activities recorded for this date.
`;
      }
      const byCourse = {};
      const noCourse = [];
      for (const activity of activities) {
        if (activity.file.includes("Courses/")) {
          const pathParts = activity.file.split("/");
          const courseIndex = pathParts.findIndex((part) => part.includes("-"));
          if (courseIndex >= 0) {
            const courseId = pathParts[courseIndex];
            if (!byCourse[courseId]) {
              byCourse[courseId] = [];
            }
            byCourse[courseId].push(activity);
          } else {
            noCourse.push(activity);
          }
        } else {
          noCourse.push(activity);
        }
      }
      let content = `# Academic Activities - ${targetDate}

`;
      content += `Total activities: ${activities.length}

`;
      for (const [courseId, courseActivities] of Object.entries(byCourse)) {
        content += `## ${courseId}

`;
        content += `| File | Type |
`;
        content += `| ---- | ---- |
`;
        for (const activity of courseActivities) {
          content += `| ${activity.file} | ${activity.type} |
`;
        }
        content += `
`;
      }
      if (noCourse.length > 0) {
        content += `## Other Activities

`;
        content += `| File | Type |
`;
        content += `| ---- | ---- |
`;
        for (const activity of noCourse) {
          content += `| ${activity.file} | ${activity.type} |
`;
        }
        content += `
`;
      }
      return content;
    });
  }
  createDailySummaryFile(date) {
    return __async(this, null, function* () {
      try {
        const targetDate = date || new Date().toISOString().split("T")[0];
        const summaryContent = yield this.generateDailySummary(targetDate);
        const fileName = `${targetDate} - Academic Summary.md`;
        const filePath = `Daily/${fileName}`;
        try {
          yield this.app.vault.create(filePath, summaryContent);
          console.log(`Created daily summary file: ${filePath}`);
        } catch (error) {
          const existingFile = this.app.vault.getAbstractFileByPath(filePath);
          if (existingFile && existingFile instanceof import_obsidian7.TFile) {
            yield this.app.vault.modify(existingFile, summaryContent);
            console.log(`Updated daily summary file: ${filePath}`);
          }
        }
      } catch (error) {
        console.error(`Error creating daily summary for ${date}:`, error);
        throw error;
      }
    });
  }
};

// main.ts
var TuckersToolsPlugin = class extends import_obsidian8.Plugin {
  onload() {
    return __async(this, null, function* () {
      console.log("Loading Tuckers Tools plugin");
      yield this.loadSettings();
      this.templateManager = new TemplateManager(this.app, this.settings);
      this.courseWizard = new CourseCreationWizard(this.app, this.settings);
      this.vocabularyExtractor = new VocabularyExtractor(this.app);
      this.dueDatesParser = new DueDatesParser(this.app);
      this.dailyNotesIntegration = new DailyNotesIntegration(this.app);
      this.addSettingTab(new TuckersToolsSettingTab(this.app, this));
      this.initializeTemplaterFunctions();
      this.addCommand({
        id: "install-templates",
        name: "Install/Update Tuckers Tools Templates",
        callback: () => {
          this.templateManager.installTemplates();
        }
      });
      this.addCommand({
        id: "update-templates",
        name: "Update Tuckers Tools Templates",
        callback: () => {
          this.templateManager.updateTemplates();
        }
      });
      this.addCommand({
        id: "create-course",
        name: "Create New Course",
        callback: () => {
          this.courseWizard.createCourseHomepage();
        }
      });
      this.addCommand({
        id: "extract-vocabulary",
        name: "Extract Course Vocabulary",
        callback: () => __async(this, null, function* () {
          const courseId = yield this.promptForCourseId(
            "Enter course ID to extract vocabulary from"
          );
          if (courseId) {
            yield this.vocabularyExtractor.createVocabularyIndexFile(courseId);
          }
        })
      });
      this.addCommand({
        id: "generate-due-dates-summary",
        name: "Generate Due Dates Summary",
        callback: () => __async(this, null, function* () {
          const courseId = yield this.promptForCourseId(
            "Enter course ID to generate due dates summary for"
          );
          if (courseId) {
            yield this.dueDatesParser.createDueDatesSummaryFile(courseId);
          }
        })
      });
      this.addCommand({
        id: "generate-daily-summary",
        name: "Generate Daily Academic Summary",
        callback: () => __async(this, null, function* () {
          const date = yield this.promptForDate(
            "Enter date (YYYY-MM-DD) or leave empty for today"
          );
          yield this.dailyNotesIntegration.createDailySummaryFile(
            date || void 0
          );
        })
      });
      this.addStatusBarItem().setText("Tuckers Tools");
    });
  }
  promptForCourseId(message) {
    return __async(this, null, function* () {
      const courseId = prompt(message + "\n\nExample: PSI-101");
      return courseId ? courseId.trim() : null;
    });
  }
  promptForDate(message) {
    return __async(this, null, function* () {
      const date = prompt(
        message + "\n\nExample: 2025-01-15 or leave empty for today"
      );
      return date ? date.trim() : null;
    });
  }
  onunload() {
    console.log("Unloading Tuckers Tools plugin");
  }
  initializeTemplaterFunctions() {
    return __async(this, null, function* () {
      const templaterPlugin = this.app.plugins.getPlugin("templater-obsidian");
      if (!templaterPlugin) {
        console.log("Templater plugin not found. Course templates will not work properly.");
        return;
      }
      try {
        if (templaterPlugin && templaterPlugin.templater) {
          if (!templaterPlugin.templater.functions) {
            templaterPlugin.templater.functions = {};
          }
          templaterPlugin.templater.functions["new_module"] = (app, tp, year) => __async(this, null, function* () {
            return this.newModuleFunction(app, tp, year);
          });
          templaterPlugin.templater.functions["new_chapter"] = (tp) => __async(this, null, function* () {
            return this.newChapterFunction(tp);
          });
          console.log("Tuckers Tools templater functions registered successfully");
        } else {
          console.error("Could not register templater functions - templater object not found");
        }
      } catch (e) {
        console.error("Error registering templater functions:", e);
      }
    });
  }
  newModuleFunction(app, tp, year) {
    return __async(this, null, function* () {
      var _a;
      let moduleNumber = "";
      let weekNumber = "";
      let course = "";
      let courseId = "";
      let discipline = "GEN";
      let dayOfWeek = "";
      try {
        if (tp && tp.system && tp.system.prompt) {
          const tempModuleNumber = yield tp.system.prompt("Module Number (optional)", "");
          moduleNumber = tempModuleNumber ? tempModuleNumber : null;
          const tempWeekNumber = yield tp.system.prompt("Week Number (optional)", "");
          weekNumber = tempWeekNumber ? tempWeekNumber : null;
          course = yield tp.system.suggester(
            () => app.vault.getMarkdownFiles().filter((f) => f.path.includes("Courses")).map((f) => f.basename),
            app.vault.getMarkdownFiles().filter((f) => f.path.includes("Courses"))
          );
          dayOfWeek = yield tp.system.suggester(
            ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
            ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
            "Day of Week"
          );
        } else {
          moduleNumber = null;
          weekNumber = null;
          course = "New Course";
          dayOfWeek = "Monday";
        }
      } catch (e) {
        console.error("Error in new_module prompts:", e);
        moduleNumber = null;
        weekNumber = null;
        course = "New Course";
        dayOfWeek = "Monday";
      }
      courseId = course ? course.split(" - ")[0] || course : "";
      discipline = course ? ((_a = course.split(" - ")[0]) == null ? void 0 : _a.substring(0, 3)) || "GEN" : "GEN";
      return {
        season: "Fall",
        // This would normally be dynamically determined
        moduleNumber,
        weekNumber,
        course,
        courseId,
        discipline,
        dayOfWeek
      };
    });
  }
  newChapterFunction(tp) {
    return __async(this, null, function* () {
      var _a;
      let chapterNumber = "";
      let course = "";
      let courseId = "";
      let discipline = "GEN";
      let text = "";
      try {
        if (tp && tp.system && tp.system.prompt) {
          chapterNumber = (yield tp.system.prompt("Chapter Number", "")) || "";
          course = yield tp.system.suggester(
            () => tp.app.vault.getMarkdownFiles().filter((f) => f.path.includes("Courses")).map((f) => f.basename),
            tp.app.vault.getMarkdownFiles().filter((f) => f.path.includes("Courses"))
          );
          const textOptions = tp.app.vault.getFiles().filter((f) => f.extension === "pdf").map((f) => f.basename);
          text = yield tp.system.suggester(textOptions, textOptions, "Textbook");
        } else {
          chapterNumber = "";
          course = "New Course";
          text = "New Textbook";
        }
      } catch (e) {
        console.error("Error in new_chapter prompts:", e);
        chapterNumber = "";
        course = "New Course";
        text = "New Textbook";
      }
      courseId = course ? course.split(" - ")[0] || course : "";
      discipline = course ? ((_a = course.split(" - ")[0]) == null ? void 0 : _a.substring(0, 3)) || "GEN" : "GEN";
      return {
        chapterNumber,
        course,
        courseId,
        discipline,
        text
      };
    });
  }
  loadSettings() {
    return __async(this, null, function* () {
      this.settings = Object.assign({}, DEFAULT_SETTINGS, yield this.loadData());
    });
  }
  saveSettings() {
    return __async(this, null, function* () {
      yield this.saveData(this.settings);
    });
  }
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsibWFpbi50cyIsICJzZXR0aW5ncy50cyIsICJ1dGlscy50cyIsICJ0ZW1wbGF0ZU1hbmFnZXIudHMiLCAiY291cnNlV2l6YXJkLnRzIiwgImlucHV0TW9kYWwudHMiLCAidm9jYWJ1bGFyeS50cyIsICJkdWVEYXRlcy50cyIsICJkYWlseU5vdGVzLnRzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyJpbXBvcnQgeyBQbHVnaW4gfSBmcm9tIFwib2JzaWRpYW5cIlxuaW1wb3J0IHtcbiAgVHVja2Vyc1Rvb2xzU2V0dGluZ3MsXG4gIERFRkFVTFRfU0VUVElOR1MsXG4gIFR1Y2tlcnNUb29sc1NldHRpbmdUYWJcbn0gZnJvbSBcIi4vc2V0dGluZ3NcIlxuaW1wb3J0IHsgVGVtcGxhdGVNYW5hZ2VyIH0gZnJvbSBcIi4vdGVtcGxhdGVNYW5hZ2VyXCJcbmltcG9ydCB7IENvdXJzZUNyZWF0aW9uV2l6YXJkIH0gZnJvbSBcIi4vY291cnNlV2l6YXJkXCJcbmltcG9ydCB7IFZvY2FidWxhcnlFeHRyYWN0b3IgfSBmcm9tIFwiLi92b2NhYnVsYXJ5XCJcbmltcG9ydCB7IER1ZURhdGVzUGFyc2VyIH0gZnJvbSBcIi4vZHVlRGF0ZXNcIlxuaW1wb3J0IHsgRGFpbHlOb3Rlc0ludGVncmF0aW9uIH0gZnJvbSBcIi4vZGFpbHlOb3Rlc1wiXG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFR1Y2tlcnNUb29sc1BsdWdpbiBleHRlbmRzIFBsdWdpbiB7XG4gIHNldHRpbmdzOiBUdWNrZXJzVG9vbHNTZXR0aW5nc1xuICB0ZW1wbGF0ZU1hbmFnZXI6IFRlbXBsYXRlTWFuYWdlclxuICBjb3Vyc2VXaXphcmQ6IENvdXJzZUNyZWF0aW9uV2l6YXJkXG4gIHZvY2FidWxhcnlFeHRyYWN0b3I6IFZvY2FidWxhcnlFeHRyYWN0b3JcbiAgZHVlRGF0ZXNQYXJzZXI6IER1ZURhdGVzUGFyc2VyXG4gIGRhaWx5Tm90ZXNJbnRlZ3JhdGlvbjogRGFpbHlOb3Rlc0ludGVncmF0aW9uXG5cbiAgYXN5bmMgb25sb2FkKCkge1xuICAgIGNvbnNvbGUubG9nKFwiTG9hZGluZyBUdWNrZXJzIFRvb2xzIHBsdWdpblwiKVxuXG4gICAgLy8gTG9hZCBzZXR0aW5nc1xuICAgIGF3YWl0IHRoaXMubG9hZFNldHRpbmdzKClcblxuICAgIC8vIEluaXRpYWxpemUgY29tcG9uZW50c1xuICAgIHRoaXMudGVtcGxhdGVNYW5hZ2VyID0gbmV3IFRlbXBsYXRlTWFuYWdlcih0aGlzLmFwcCwgdGhpcy5zZXR0aW5ncylcbiAgICB0aGlzLmNvdXJzZVdpemFyZCA9IG5ldyBDb3Vyc2VDcmVhdGlvbldpemFyZCh0aGlzLmFwcCwgdGhpcy5zZXR0aW5ncylcbiAgICB0aGlzLnZvY2FidWxhcnlFeHRyYWN0b3IgPSBuZXcgVm9jYWJ1bGFyeUV4dHJhY3Rvcih0aGlzLmFwcClcbiAgICB0aGlzLmR1ZURhdGVzUGFyc2VyID0gbmV3IER1ZURhdGVzUGFyc2VyKHRoaXMuYXBwKVxuICAgIHRoaXMuZGFpbHlOb3Rlc0ludGVncmF0aW9uID0gbmV3IERhaWx5Tm90ZXNJbnRlZ3JhdGlvbih0aGlzLmFwcClcblxuICAgIC8vIEFkZCBzZXR0aW5ncyB0YWJcbiAgICB0aGlzLmFkZFNldHRpbmdUYWIobmV3IFR1Y2tlcnNUb29sc1NldHRpbmdUYWIodGhpcy5hcHAsIHRoaXMpKVxuXG4gICAgLy8gSW5pdGlhbGl6ZSB0ZW1wbGF0ZXIgZnVuY3Rpb25zIGlmIHRlbXBsYXRlciBpcyBhdmFpbGFibGVcbiAgICB0aGlzLmluaXRpYWxpemVUZW1wbGF0ZXJGdW5jdGlvbnMoKVxuXG4gICAgLy8gQWRkIGNvbW1hbmRzXG4gICAgdGhpcy5hZGRDb21tYW5kKHtcbiAgICAgIGlkOiBcImluc3RhbGwtdGVtcGxhdGVzXCIsXG4gICAgICBuYW1lOiBcIkluc3RhbGwvVXBkYXRlIFR1Y2tlcnMgVG9vbHMgVGVtcGxhdGVzXCIsXG4gICAgICBjYWxsYmFjazogKCkgPT4ge1xuICAgICAgICB0aGlzLnRlbXBsYXRlTWFuYWdlci5pbnN0YWxsVGVtcGxhdGVzKClcbiAgICAgIH1cbiAgICB9KVxuXG4gICAgdGhpcy5hZGRDb21tYW5kKHtcbiAgICAgIGlkOiBcInVwZGF0ZS10ZW1wbGF0ZXNcIixcbiAgICAgIG5hbWU6IFwiVXBkYXRlIFR1Y2tlcnMgVG9vbHMgVGVtcGxhdGVzXCIsXG4gICAgICBjYWxsYmFjazogKCkgPT4ge1xuICAgICAgICB0aGlzLnRlbXBsYXRlTWFuYWdlci51cGRhdGVUZW1wbGF0ZXMoKVxuICAgICAgfVxuICAgIH0pXG5cbiAgICB0aGlzLmFkZENvbW1hbmQoe1xuICAgICAgaWQ6IFwiY3JlYXRlLWNvdXJzZVwiLFxuICAgICAgbmFtZTogXCJDcmVhdGUgTmV3IENvdXJzZVwiLFxuICAgICAgY2FsbGJhY2s6ICgpID0+IHtcbiAgICAgICAgdGhpcy5jb3Vyc2VXaXphcmQuY3JlYXRlQ291cnNlSG9tZXBhZ2UoKVxuICAgICAgfVxuICAgIH0pXG5cbiAgICB0aGlzLmFkZENvbW1hbmQoe1xuICAgICAgaWQ6IFwiZXh0cmFjdC12b2NhYnVsYXJ5XCIsXG4gICAgICBuYW1lOiBcIkV4dHJhY3QgQ291cnNlIFZvY2FidWxhcnlcIixcbiAgICAgIGNhbGxiYWNrOiBhc3luYyAoKSA9PiB7XG4gICAgICAgIGNvbnN0IGNvdXJzZUlkID0gYXdhaXQgdGhpcy5wcm9tcHRGb3JDb3Vyc2VJZChcbiAgICAgICAgICBcIkVudGVyIGNvdXJzZSBJRCB0byBleHRyYWN0IHZvY2FidWxhcnkgZnJvbVwiXG4gICAgICAgIClcbiAgICAgICAgaWYgKGNvdXJzZUlkKSB7XG4gICAgICAgICAgYXdhaXQgdGhpcy52b2NhYnVsYXJ5RXh0cmFjdG9yLmNyZWF0ZVZvY2FidWxhcnlJbmRleEZpbGUoY291cnNlSWQpXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9KVxuXG4gICAgdGhpcy5hZGRDb21tYW5kKHtcbiAgICAgIGlkOiBcImdlbmVyYXRlLWR1ZS1kYXRlcy1zdW1tYXJ5XCIsXG4gICAgICBuYW1lOiBcIkdlbmVyYXRlIER1ZSBEYXRlcyBTdW1tYXJ5XCIsXG4gICAgICBjYWxsYmFjazogYXN5bmMgKCkgPT4ge1xuICAgICAgICBjb25zdCBjb3Vyc2VJZCA9IGF3YWl0IHRoaXMucHJvbXB0Rm9yQ291cnNlSWQoXG4gICAgICAgICAgXCJFbnRlciBjb3Vyc2UgSUQgdG8gZ2VuZXJhdGUgZHVlIGRhdGVzIHN1bW1hcnkgZm9yXCJcbiAgICAgICAgKVxuICAgICAgICBpZiAoY291cnNlSWQpIHtcbiAgICAgICAgICBhd2FpdCB0aGlzLmR1ZURhdGVzUGFyc2VyLmNyZWF0ZUR1ZURhdGVzU3VtbWFyeUZpbGUoY291cnNlSWQpXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9KVxuXG4gICAgdGhpcy5hZGRDb21tYW5kKHtcbiAgICAgIGlkOiBcImdlbmVyYXRlLWRhaWx5LXN1bW1hcnlcIixcbiAgICAgIG5hbWU6IFwiR2VuZXJhdGUgRGFpbHkgQWNhZGVtaWMgU3VtbWFyeVwiLFxuICAgICAgY2FsbGJhY2s6IGFzeW5jICgpID0+IHtcbiAgICAgICAgY29uc3QgZGF0ZSA9IGF3YWl0IHRoaXMucHJvbXB0Rm9yRGF0ZShcbiAgICAgICAgICBcIkVudGVyIGRhdGUgKFlZWVktTU0tREQpIG9yIGxlYXZlIGVtcHR5IGZvciB0b2RheVwiXG4gICAgICAgIClcbiAgICAgICAgYXdhaXQgdGhpcy5kYWlseU5vdGVzSW50ZWdyYXRpb24uY3JlYXRlRGFpbHlTdW1tYXJ5RmlsZShcbiAgICAgICAgICBkYXRlIHx8IHVuZGVmaW5lZFxuICAgICAgICApXG4gICAgICB9XG4gICAgfSlcblxuICAgIC8vIEFkZCBzdGF0dXMgYmFyIGl0ZW1cbiAgICB0aGlzLmFkZFN0YXR1c0Jhckl0ZW0oKS5zZXRUZXh0KFwiVHVja2VycyBUb29sc1wiKVxuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBwcm9tcHRGb3JDb3Vyc2VJZChtZXNzYWdlOiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZyB8IG51bGw+IHtcbiAgICBjb25zdCBjb3Vyc2VJZCA9IHByb21wdChtZXNzYWdlICsgXCJcXG5cXG5FeGFtcGxlOiBQU0ktMTAxXCIpXG4gICAgcmV0dXJuIGNvdXJzZUlkID8gY291cnNlSWQudHJpbSgpIDogbnVsbFxuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBwcm9tcHRGb3JEYXRlKG1lc3NhZ2U6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nIHwgbnVsbD4ge1xuICAgIGNvbnN0IGRhdGUgPSBwcm9tcHQoXG4gICAgICBtZXNzYWdlICsgXCJcXG5cXG5FeGFtcGxlOiAyMDI1LTAxLTE1IG9yIGxlYXZlIGVtcHR5IGZvciB0b2RheVwiXG4gICAgKVxuICAgIHJldHVybiBkYXRlID8gZGF0ZS50cmltKCkgOiBudWxsXG4gIH1cblxuICBvbnVubG9hZCgpIHtcbiAgICBjb25zb2xlLmxvZyhcIlVubG9hZGluZyBUdWNrZXJzIFRvb2xzIHBsdWdpblwiKVxuICB9XG5cbiAgYXN5bmMgaW5pdGlhbGl6ZVRlbXBsYXRlckZ1bmN0aW9ucygpIHtcbiAgICAvLyBDaGVjayBpZiBUZW1wbGF0ZXIgcGx1Z2luIGlzIGF2YWlsYWJsZVxuICAgIGNvbnN0IHRlbXBsYXRlclBsdWdpbiA9ICh0aGlzLmFwcCBhcyBhbnkpLnBsdWdpbnMuZ2V0UGx1Z2luKFwidGVtcGxhdGVyLW9ic2lkaWFuXCIpO1xuICAgIGlmICghdGVtcGxhdGVyUGx1Z2luKSB7XG4gICAgICBjb25zb2xlLmxvZyhcIlRlbXBsYXRlciBwbHVnaW4gbm90IGZvdW5kLiBDb3Vyc2UgdGVtcGxhdGVzIHdpbGwgbm90IHdvcmsgcHJvcGVybHkuXCIpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIC8vIFJlZ2lzdGVyIHVzZXIgZnVuY3Rpb25zIHdpdGggVGVtcGxhdGVyXG4gICAgdHJ5IHtcbiAgICAgIC8vIFRyeSB0byBhZGQgZnVuY3Rpb25zIHZpYSBkaWZmZXJlbnQgbWV0aG9kcyBkZXBlbmRpbmcgb24gdGhlIFRlbXBsYXRlciB2ZXJzaW9uXG4gICAgICBpZiAodGVtcGxhdGVyUGx1Z2luICYmIHRlbXBsYXRlclBsdWdpbi50ZW1wbGF0ZXIpIHtcbiAgICAgICAgLy8gQ3JlYXRlIGEgdXNlciBmdW5jdGlvbiBtYW5hZ2VyIG9iamVjdCBpZiBpdCBkb2Vzbid0IGV4aXN0XG4gICAgICAgIGlmICghdGVtcGxhdGVyUGx1Z2luLnRlbXBsYXRlci5mdW5jdGlvbnMpIHtcbiAgICAgICAgICB0ZW1wbGF0ZXJQbHVnaW4udGVtcGxhdGVyLmZ1bmN0aW9ucyA9IHt9O1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gQWRkIG91ciBjdXN0b20gZnVuY3Rpb25zIGRpcmVjdGx5IHRvIHRoZSB0ZW1wbGF0ZXIgZnVuY3Rpb25zIG9iamVjdFxuICAgICAgICB0ZW1wbGF0ZXJQbHVnaW4udGVtcGxhdGVyLmZ1bmN0aW9uc1tcIm5ld19tb2R1bGVcIl0gPSBhc3luYyAoYXBwOiBhbnksIHRwOiBhbnksIHllYXI6IGFueSkgPT4ge1xuICAgICAgICAgIHJldHVybiB0aGlzLm5ld01vZHVsZUZ1bmN0aW9uKGFwcCwgdHAsIHllYXIpO1xuICAgICAgICB9O1xuXG4gICAgICAgIHRlbXBsYXRlclBsdWdpbi50ZW1wbGF0ZXIuZnVuY3Rpb25zW1wibmV3X2NoYXB0ZXJcIl0gPSBhc3luYyAodHA6IGFueSkgPT4ge1xuICAgICAgICAgIHJldHVybiB0aGlzLm5ld0NoYXB0ZXJGdW5jdGlvbih0cCk7XG4gICAgICAgIH07XG5cbiAgICAgICAgY29uc29sZS5sb2coXCJUdWNrZXJzIFRvb2xzIHRlbXBsYXRlciBmdW5jdGlvbnMgcmVnaXN0ZXJlZCBzdWNjZXNzZnVsbHlcIik7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjb25zb2xlLmVycm9yKFwiQ291bGQgbm90IHJlZ2lzdGVyIHRlbXBsYXRlciBmdW5jdGlvbnMgLSB0ZW1wbGF0ZXIgb2JqZWN0IG5vdCBmb3VuZFwiKTtcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgcmVnaXN0ZXJpbmcgdGVtcGxhdGVyIGZ1bmN0aW9uczpcIiwgZSk7XG4gICAgfVxuICB9XG5cbiAgYXN5bmMgbmV3TW9kdWxlRnVuY3Rpb24oYXBwOiBhbnksIHRwOiBhbnksIHllYXI6IHN0cmluZykge1xuICAgIC8vIFByb21wdCB1c2VyIGZvciBtb2R1bGUgZGV0YWlsc1xuICAgIGxldCBtb2R1bGVOdW1iZXI6IHN0cmluZyB8IG51bGwgPSBcIlwiO1xuICAgIGxldCB3ZWVrTnVtYmVyOiBzdHJpbmcgfCBudWxsID0gXCJcIjtcbiAgICBsZXQgY291cnNlID0gXCJcIjtcbiAgICBsZXQgY291cnNlSWQgPSBcIlwiO1xuICAgIGxldCBkaXNjaXBsaW5lID0gXCJHRU5cIjtcbiAgICBsZXQgZGF5T2ZXZWVrID0gXCJcIjtcblxuICAgIHRyeSB7XG4gICAgICAvLyBBdHRlbXB0IHByb21wdHMgd2l0aCBmYWxsYmFja1xuICAgICAgaWYgKHRwICYmIHRwLnN5c3RlbSAmJiB0cC5zeXN0ZW0ucHJvbXB0KSB7XG4gICAgICAgIGNvbnN0IHRlbXBNb2R1bGVOdW1iZXIgPSBhd2FpdCB0cC5zeXN0ZW0ucHJvbXB0KFwiTW9kdWxlIE51bWJlciAob3B0aW9uYWwpXCIsIFwiXCIpO1xuICAgICAgICBtb2R1bGVOdW1iZXIgPSB0ZW1wTW9kdWxlTnVtYmVyID8gdGVtcE1vZHVsZU51bWJlciA6IG51bGw7XG4gICAgICAgIFxuICAgICAgICBjb25zdCB0ZW1wV2Vla051bWJlciA9IGF3YWl0IHRwLnN5c3RlbS5wcm9tcHQoXCJXZWVrIE51bWJlciAob3B0aW9uYWwpXCIsIFwiXCIpO1xuICAgICAgICB3ZWVrTnVtYmVyID0gdGVtcFdlZWtOdW1iZXIgPyB0ZW1wV2Vla051bWJlciA6IG51bGw7XG4gICAgICAgIFxuICAgICAgICBjb3Vyc2UgPSBhd2FpdCB0cC5zeXN0ZW0uc3VnZ2VzdGVyKFxuICAgICAgICAgICgpID0+IGFwcC52YXVsdC5nZXRNYXJrZG93bkZpbGVzKCkuZmlsdGVyKChmOiBhbnkpID0+IGYucGF0aC5pbmNsdWRlcyhcIkNvdXJzZXNcIikpLm1hcCgoZjogYW55KSA9PiBmLmJhc2VuYW1lKSxcbiAgICAgICAgICBhcHAudmF1bHQuZ2V0TWFya2Rvd25GaWxlcygpLmZpbHRlcigoZjogYW55KSA9PiBmLnBhdGguaW5jbHVkZXMoXCJDb3Vyc2VzXCIpKVxuICAgICAgICApO1xuICAgICAgICBcbiAgICAgICAgZGF5T2ZXZWVrID0gYXdhaXQgdHAuc3lzdGVtLnN1Z2dlc3RlcihcbiAgICAgICAgICBbXCJNb25kYXlcIiwgXCJUdWVzZGF5XCIsIFwiV2VkbmVzZGF5XCIsIFwiVGh1cnNkYXlcIiwgXCJGcmlkYXlcIiwgXCJTYXR1cmRheVwiLCBcIlN1bmRheVwiXSxcbiAgICAgICAgICBbXCJNb25kYXlcIiwgXCJUdWVzZGF5XCIsIFwiV2VkbmVzZGF5XCIsIFwiVGh1cnNkYXlcIiwgXCJGcmlkYXlcIiwgXCJTYXR1cmRheVwiLCBcIlN1bmRheVwiXSxcbiAgICAgICAgICBcIkRheSBvZiBXZWVrXCJcbiAgICAgICAgKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIC8vIEZhbGxiYWNrIHZhbHVlc1xuICAgICAgICBtb2R1bGVOdW1iZXIgPSBudWxsO1xuICAgICAgICB3ZWVrTnVtYmVyID0gbnVsbDtcbiAgICAgICAgY291cnNlID0gXCJOZXcgQ291cnNlXCI7XG4gICAgICAgIGRheU9mV2VlayA9IFwiTW9uZGF5XCI7XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGluIG5ld19tb2R1bGUgcHJvbXB0czpcIiwgZSk7XG4gICAgICAvLyBEZWZhdWx0IHZhbHVlcyBvbiBlcnJvclxuICAgICAgbW9kdWxlTnVtYmVyID0gbnVsbDtcbiAgICAgIHdlZWtOdW1iZXIgPSBudWxsO1xuICAgICAgY291cnNlID0gXCJOZXcgQ291cnNlXCI7XG4gICAgICBkYXlPZldlZWsgPSBcIk1vbmRheVwiO1xuICAgIH1cblxuICAgIC8vIENhbGN1bGF0ZSBkZXJpdmVkIHZhbHVlc1xuICAgIGNvdXJzZUlkID0gY291cnNlID8gY291cnNlLnNwbGl0KFwiIC0gXCIpWzBdIHx8IGNvdXJzZSA6IFwiXCI7XG4gICAgZGlzY2lwbGluZSA9IGNvdXJzZSA/IChjb3Vyc2Uuc3BsaXQoXCIgLSBcIilbMF0/LnN1YnN0cmluZygwLCAzKSB8fCBcIkdFTlwiKSA6IFwiR0VOXCI7XG5cbiAgICByZXR1cm4ge1xuICAgICAgc2Vhc29uOiBcIkZhbGxcIiwgLy8gVGhpcyB3b3VsZCBub3JtYWxseSBiZSBkeW5hbWljYWxseSBkZXRlcm1pbmVkXG4gICAgICBtb2R1bGVOdW1iZXI6IG1vZHVsZU51bWJlcixcbiAgICAgIHdlZWtOdW1iZXI6IHdlZWtOdW1iZXIsXG4gICAgICBjb3Vyc2UsXG4gICAgICBjb3Vyc2VJZCxcbiAgICAgIGRpc2NpcGxpbmUsXG4gICAgICBkYXlPZldlZWtcbiAgICB9O1xuICB9XG5cbiAgYXN5bmMgbmV3Q2hhcHRlckZ1bmN0aW9uKHRwOiBhbnkpIHtcbiAgICBsZXQgY2hhcHRlck51bWJlciA9IFwiXCI7XG4gICAgbGV0IGNvdXJzZSA9IFwiXCI7XG4gICAgbGV0IGNvdXJzZUlkID0gXCJcIjtcbiAgICBsZXQgZGlzY2lwbGluZSA9IFwiR0VOXCI7XG4gICAgbGV0IHRleHQgPSBcIlwiO1xuXG4gICAgdHJ5IHtcbiAgICAgIGlmICh0cCAmJiB0cC5zeXN0ZW0gJiYgdHAuc3lzdGVtLnByb21wdCkge1xuICAgICAgICBjaGFwdGVyTnVtYmVyID0gYXdhaXQgdHAuc3lzdGVtLnByb21wdChcIkNoYXB0ZXIgTnVtYmVyXCIsIFwiXCIpIHx8IFwiXCI7XG4gICAgICAgIGNvdXJzZSA9IGF3YWl0IHRwLnN5c3RlbS5zdWdnZXN0ZXIoXG4gICAgICAgICAgKCkgPT4gdHAuYXBwLnZhdWx0LmdldE1hcmtkb3duRmlsZXMoKS5maWx0ZXIoKGY6IGFueSkgPT4gZi5wYXRoLmluY2x1ZGVzKFwiQ291cnNlc1wiKSkubWFwKChmOiBhbnkpID0+IGYuYmFzZW5hbWUpLFxuICAgICAgICAgIHRwLmFwcC52YXVsdC5nZXRNYXJrZG93bkZpbGVzKCkuZmlsdGVyKChmOiBhbnkpID0+IGYucGF0aC5pbmNsdWRlcyhcIkNvdXJzZXNcIikpXG4gICAgICAgICk7XG4gICAgICAgIGNvbnN0IHRleHRPcHRpb25zID0gdHAuYXBwLnZhdWx0LmdldEZpbGVzKCkuZmlsdGVyKChmOiBhbnkpID0+IGYuZXh0ZW5zaW9uID09PSBcInBkZlwiKS5tYXAoKGY6IGFueSkgPT4gZi5iYXNlbmFtZSk7XG4gICAgICAgIHRleHQgPSBhd2FpdCB0cC5zeXN0ZW0uc3VnZ2VzdGVyKHRleHRPcHRpb25zLCB0ZXh0T3B0aW9ucywgXCJUZXh0Ym9va1wiKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIC8vIEZhbGxiYWNrIHZhbHVlc1xuICAgICAgICBjaGFwdGVyTnVtYmVyID0gXCJcIjtcbiAgICAgICAgY291cnNlID0gXCJOZXcgQ291cnNlXCI7XG4gICAgICAgIHRleHQgPSBcIk5ldyBUZXh0Ym9va1wiO1xuICAgICAgfVxuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBpbiBuZXdfY2hhcHRlciBwcm9tcHRzOlwiLCBlKTtcbiAgICAgIC8vIERlZmF1bHQgdmFsdWVzIG9uIGVycm9yXG4gICAgICBjaGFwdGVyTnVtYmVyID0gXCJcIjtcbiAgICAgIGNvdXJzZSA9IFwiTmV3IENvdXJzZVwiO1xuICAgICAgdGV4dCA9IFwiTmV3IFRleHRib29rXCI7XG4gICAgfVxuXG4gICAgLy8gQ2FsY3VsYXRlIGRlcml2ZWQgdmFsdWVzXG4gICAgY291cnNlSWQgPSBjb3Vyc2UgPyBjb3Vyc2Uuc3BsaXQoXCIgLSBcIilbMF0gfHwgY291cnNlIDogXCJcIjtcbiAgICBkaXNjaXBsaW5lID0gY291cnNlID8gKGNvdXJzZS5zcGxpdChcIiAtIFwiKVswXT8uc3Vic3RyaW5nKDAsIDMpIHx8IFwiR0VOXCIpIDogXCJHRU5cIjtcblxuICAgIHJldHVybiB7XG4gICAgICBjaGFwdGVyTnVtYmVyLFxuICAgICAgY291cnNlLFxuICAgICAgY291cnNlSWQsXG4gICAgICBkaXNjaXBsaW5lLFxuICAgICAgdGV4dFxuICAgIH07XG4gIH1cblxuICBhc3luYyBsb2FkU2V0dGluZ3MoKSB7XG4gICAgdGhpcy5zZXR0aW5ncyA9IE9iamVjdC5hc3NpZ24oe30sIERFRkFVTFRfU0VUVElOR1MsIGF3YWl0IHRoaXMubG9hZERhdGEoKSlcbiAgfVxuXG4gIGFzeW5jIHNhdmVTZXR0aW5ncygpIHtcbiAgICBhd2FpdCB0aGlzLnNhdmVEYXRhKHRoaXMuc2V0dGluZ3MpXG4gIH1cbn1cbiIsICJpbXBvcnQgeyBBcHAsIFBsdWdpblNldHRpbmdUYWIsIFNldHRpbmcgfSBmcm9tICdvYnNpZGlhbic7XG5pbXBvcnQgVHVja2Vyc1Rvb2xzUGx1Z2luIGZyb20gJy4vbWFpbic7XG5pbXBvcnQgeyB2YWxpZGF0ZURhdGUgfSBmcm9tICcuL3V0aWxzJztcblxuZXhwb3J0IGludGVyZmFjZSBUdWNrZXJzVG9vbHNTZXR0aW5ncyB7XG4gIGJhc2VEaXJlY3Rvcnk6IHN0cmluZztcbiAgc2VtZXN0ZXJTdGFydERhdGU6IHN0cmluZztcbiAgc2VtZXN0ZXJFbmREYXRlOiBzdHJpbmc7XG4gIHNjaG9vbE5hbWU6IHN0cmluZztcbiAgc2Nob29sQWJicmV2aWF0aW9uOiBzdHJpbmc7XG4gIHRlbXBsYXRlRm9sZGVyOiBzdHJpbmc7XG4gIHVzZUVuaGFuY2VkTWV0YWRhdGE6IGJvb2xlYW47XG59XG5cbmV4cG9ydCBjb25zdCBERUZBVUxUX1NFVFRJTkdTOiBUdWNrZXJzVG9vbHNTZXR0aW5ncyA9IHtcbiAgYmFzZURpcmVjdG9yeTogJy8nLFxuICBzZW1lc3RlclN0YXJ0RGF0ZTogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNwbGl0KCdUJylbMF0sXG4gIHNlbWVzdGVyRW5kRGF0ZTogbmV3IERhdGUobmV3IERhdGUoKS5zZXRNb250aChuZXcgRGF0ZSgpLmdldE1vbnRoKCkgKyA0KSkudG9JU09TdHJpbmcoKS5zcGxpdCgnVCcpWzBdLFxuICBzY2hvb2xOYW1lOiAnVW5pdmVyc2l0eScsXG4gIHNjaG9vbEFiYnJldmlhdGlvbjogJ1UnLFxuICB0ZW1wbGF0ZUZvbGRlcjogJ1R1Y2tlcnMgVG9vbHMnLFxuICB1c2VFbmhhbmNlZE1ldGFkYXRhOiBmYWxzZVxufVxuXG5leHBvcnQgY2xhc3MgVHVja2Vyc1Rvb2xzU2V0dGluZ1RhYiBleHRlbmRzIFBsdWdpblNldHRpbmdUYWIge1xuICBwbHVnaW46IFR1Y2tlcnNUb29sc1BsdWdpbjtcblxuICBjb25zdHJ1Y3RvcihhcHA6IEFwcCwgcGx1Z2luOiBUdWNrZXJzVG9vbHNQbHVnaW4pIHtcbiAgICBzdXBlcihhcHAsIHBsdWdpbik7XG4gICAgdGhpcy5wbHVnaW4gPSBwbHVnaW47XG4gIH1cblxuICBkaXNwbGF5KCk6IHZvaWQge1xuICAgIGNvbnN0IHsgY29udGFpbmVyRWwgfSA9IHRoaXM7XG5cbiAgICBjb250YWluZXJFbC5lbXB0eSgpO1xuXG4gICAgY29udGFpbmVyRWwuY3JlYXRlRWwoJ2gyJywgeyB0ZXh0OiAnVHVja2VycyBUb29scyBTZXR0aW5ncycgfSk7XG5cbiAgICBuZXcgU2V0dGluZyhjb250YWluZXJFbClcbiAgICAgIC5zZXROYW1lKCdCYXNlIERpcmVjdG9yeScpXG4gICAgICAuc2V0RGVzYygnUm9vdCBkaXJlY3RvcnkgZm9yIGNvdXJzZSBjb250ZW50IG9yZ2FuaXphdGlvbicpXG4gICAgICAuYWRkVGV4dCh0ZXh0ID0+IHRleHRcbiAgICAgICAgLnNldFBsYWNlaG9sZGVyKCcvJylcbiAgICAgICAgLnNldFZhbHVlKHRoaXMucGx1Z2luLnNldHRpbmdzLmJhc2VEaXJlY3RvcnkpXG4gICAgICAgIC5vbkNoYW5nZShhc3luYyAodmFsdWUpID0+IHtcbiAgICAgICAgICB0aGlzLnBsdWdpbi5zZXR0aW5ncy5iYXNlRGlyZWN0b3J5ID0gdmFsdWU7XG4gICAgICAgICAgYXdhaXQgdGhpcy5wbHVnaW4uc2F2ZVNldHRpbmdzKCk7XG4gICAgICAgIH0pKTtcblxuICAgIGNvbnN0IHN0YXJ0RGF0ZVNldHRpbmcgPSBuZXcgU2V0dGluZyhjb250YWluZXJFbClcbiAgICAgIC5zZXROYW1lKCdTZW1lc3RlciBTdGFydCBEYXRlJylcbiAgICAgIC5zZXREZXNjKCdTdGFydCBkYXRlIGZvciB0aGUgY3VycmVudCBzZW1lc3RlcicpXG4gICAgICAuYWRkVGV4dCh0ZXh0ID0+IHRleHRcbiAgICAgICAgLnNldFBsYWNlaG9sZGVyKCdZWVlZLU1NLUREJylcbiAgICAgICAgLnNldFZhbHVlKHRoaXMucGx1Z2luLnNldHRpbmdzLnNlbWVzdGVyU3RhcnREYXRlKVxuICAgICAgICAub25DaGFuZ2UoYXN5bmMgKHZhbHVlKSA9PiB7XG4gICAgICAgICAgaWYgKHZhbHVlICYmICF2YWxpZGF0ZURhdGUodmFsdWUpKSB7XG4gICAgICAgICAgICBzdGFydERhdGVTZXR0aW5nLnNldERlc2MoJ1N0YXJ0IGRhdGUgZm9yIHRoZSBjdXJyZW50IHNlbWVzdGVyIChJbnZhbGlkIGRhdGUgZm9ybWF0KScpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBzdGFydERhdGVTZXR0aW5nLnNldERlc2MoJ1N0YXJ0IGRhdGUgZm9yIHRoZSBjdXJyZW50IHNlbWVzdGVyJyk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHRoaXMucGx1Z2luLnNldHRpbmdzLnNlbWVzdGVyU3RhcnREYXRlID0gdmFsdWU7XG4gICAgICAgICAgYXdhaXQgdGhpcy5wbHVnaW4uc2F2ZVNldHRpbmdzKCk7XG4gICAgICAgIH0pKTtcblxuICAgIGNvbnN0IGVuZERhdGVTZXR0aW5nID0gbmV3IFNldHRpbmcoY29udGFpbmVyRWwpXG4gICAgICAuc2V0TmFtZSgnU2VtZXN0ZXIgRW5kIERhdGUnKVxuICAgICAgLnNldERlc2MoJ0VuZCBkYXRlIGZvciB0aGUgY3VycmVudCBzZW1lc3RlcicpXG4gICAgICAuYWRkVGV4dCh0ZXh0ID0+IHRleHRcbiAgICAgICAgLnNldFBsYWNlaG9sZGVyKCdZWVlZLU1NLUREJylcbiAgICAgICAgLnNldFZhbHVlKHRoaXMucGx1Z2luLnNldHRpbmdzLnNlbWVzdGVyRW5kRGF0ZSlcbiAgICAgICAgLm9uQ2hhbmdlKGFzeW5jICh2YWx1ZSkgPT4ge1xuICAgICAgICAgIGlmICh2YWx1ZSAmJiAhdmFsaWRhdGVEYXRlKHZhbHVlKSkge1xuICAgICAgICAgICAgZW5kRGF0ZVNldHRpbmcuc2V0RGVzYygnRW5kIGRhdGUgZm9yIHRoZSBjdXJyZW50IHNlbWVzdGVyIChJbnZhbGlkIGRhdGUgZm9ybWF0KScpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBlbmREYXRlU2V0dGluZy5zZXREZXNjKCdFbmQgZGF0ZSBmb3IgdGhlIGN1cnJlbnQgc2VtZXN0ZXInKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgdGhpcy5wbHVnaW4uc2V0dGluZ3Muc2VtZXN0ZXJFbmREYXRlID0gdmFsdWU7XG4gICAgICAgICAgYXdhaXQgdGhpcy5wbHVnaW4uc2F2ZVNldHRpbmdzKCk7XG4gICAgICAgIH0pKTtcblxuICAgIG5ldyBTZXR0aW5nKGNvbnRhaW5lckVsKVxuICAgICAgLnNldE5hbWUoJ1NjaG9vbCBOYW1lJylcbiAgICAgIC5zZXREZXNjKCdOYW1lIG9mIHlvdXIgaW5zdGl0dXRpb24nKVxuICAgICAgLmFkZFRleHQodGV4dCA9PiB0ZXh0XG4gICAgICAgIC5zZXRQbGFjZWhvbGRlcignVW5pdmVyc2l0eScpXG4gICAgICAgIC5zZXRWYWx1ZSh0aGlzLnBsdWdpbi5zZXR0aW5ncy5zY2hvb2xOYW1lKVxuICAgICAgICAub25DaGFuZ2UoYXN5bmMgKHZhbHVlKSA9PiB7XG4gICAgICAgICAgdGhpcy5wbHVnaW4uc2V0dGluZ3Muc2Nob29sTmFtZSA9IHZhbHVlO1xuICAgICAgICAgIGF3YWl0IHRoaXMucGx1Z2luLnNhdmVTZXR0aW5ncygpO1xuICAgICAgICB9KSk7XG5cbiAgICBuZXcgU2V0dGluZyhjb250YWluZXJFbClcbiAgICAgIC5zZXROYW1lKCdTY2hvb2wgQWJicmV2aWF0aW9uJylcbiAgICAgIC5zZXREZXNjKCdBYmJyZXZpYXRpb24gZm9yIHlvdXIgaW5zdGl0dXRpb24nKVxuICAgICAgLmFkZFRleHQodGV4dCA9PiB0ZXh0XG4gICAgICAgIC5zZXRQbGFjZWhvbGRlcignVScpXG4gICAgICAgIC5zZXRWYWx1ZSh0aGlzLnBsdWdpbi5zZXR0aW5ncy5zY2hvb2xBYmJyZXZpYXRpb24pXG4gICAgICAgIC5vbkNoYW5nZShhc3luYyAodmFsdWUpID0+IHtcbiAgICAgICAgICB0aGlzLnBsdWdpbi5zZXR0aW5ncy5zY2hvb2xBYmJyZXZpYXRpb24gPSB2YWx1ZTtcbiAgICAgICAgICBhd2FpdCB0aGlzLnBsdWdpbi5zYXZlU2V0dGluZ3MoKTtcbiAgICAgICAgfSkpO1xuXG4gICAgbmV3IFNldHRpbmcoY29udGFpbmVyRWwpXG4gICAgICAuc2V0TmFtZSgnVGVtcGxhdGUgRm9sZGVyJylcbiAgICAgIC5zZXREZXNjKCdTdWJmb2xkZXIgd2l0aGluIHlvdXIgVGVtcGxhdGVyIHRlbXBsYXRlIGZvbGRlciBmb3IgVHVja2VycyBUb29scyB0ZW1wbGF0ZXMnKVxuICAgICAgLmFkZFRleHQodGV4dCA9PiB0ZXh0XG4gICAgICAgIC5zZXRQbGFjZWhvbGRlcignVHVja2VycyBUb29scycpXG4gICAgICAgIC5zZXRWYWx1ZSh0aGlzLnBsdWdpbi5zZXR0aW5ncy50ZW1wbGF0ZUZvbGRlcilcbiAgICAgICAgLm9uQ2hhbmdlKGFzeW5jICh2YWx1ZSkgPT4ge1xuICAgICAgICAgIHRoaXMucGx1Z2luLnNldHRpbmdzLnRlbXBsYXRlRm9sZGVyID0gdmFsdWU7XG4gICAgICAgICAgYXdhaXQgdGhpcy5wbHVnaW4uc2F2ZVNldHRpbmdzKCk7XG4gICAgICAgIH0pKTtcblxuICAgIG5ldyBTZXR0aW5nKGNvbnRhaW5lckVsKVxuICAgICAgLnNldE5hbWUoJ1VzZSBFbmhhbmNlZCBNZXRhZGF0YScpXG4gICAgICAuc2V0RGVzYygnRW5hYmxlIGVuaGFuY2VkIG1ldGFkYXRhIGZpZWxkcyBmb3IgbmV3IG5vdGVzIChleGlzdGluZyBub3RlcyByZW1haW4gdW5jaGFuZ2VkKScpXG4gICAgICAuYWRkVG9nZ2xlKHRvZ2dsZSA9PiB0b2dnbGVcbiAgICAgICAgLnNldFZhbHVlKHRoaXMucGx1Z2luLnNldHRpbmdzLnVzZUVuaGFuY2VkTWV0YWRhdGEpXG4gICAgICAgIC5vbkNoYW5nZShhc3luYyAodmFsdWUpID0+IHtcbiAgICAgICAgICB0aGlzLnBsdWdpbi5zZXR0aW5ncy51c2VFbmhhbmNlZE1ldGFkYXRhID0gdmFsdWU7XG4gICAgICAgICAgYXdhaXQgdGhpcy5wbHVnaW4uc2F2ZVNldHRpbmdzKCk7XG4gICAgICAgIH0pKTtcbiAgfVxufSIsICIvLyBVdGlsaXR5IGZ1bmN0aW9ucyBmb3IgVHVja2VycyBUb29scyBwbHVnaW5cblxuZXhwb3J0IGZ1bmN0aW9uIGZvcm1hdERhdGUoZGF0ZTogRGF0ZSk6IHN0cmluZyB7XG4gIHJldHVybiBkYXRlLnRvSVNPU3RyaW5nKCkuc3BsaXQoXCJUXCIpWzBdXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBhZGREYXlzKGRhdGU6IERhdGUsIGRheXM6IG51bWJlcik6IERhdGUge1xuICBjb25zdCByZXN1bHQgPSBuZXcgRGF0ZShkYXRlKVxuICByZXN1bHQuc2V0RGF0ZShyZXN1bHQuZ2V0RGF0ZSgpICsgZGF5cylcbiAgcmV0dXJuIHJlc3VsdFxufVxuXG5leHBvcnQgZnVuY3Rpb24gaXNCZXR3ZWVuKGRhdGU6IERhdGUsIHN0YXJ0OiBEYXRlLCBlbmQ6IERhdGUpOiBib29sZWFuIHtcbiAgcmV0dXJuIGRhdGUgPj0gc3RhcnQgJiYgZGF0ZSA8PSBlbmRcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHNsdWdpZnkodGV4dDogc3RyaW5nKTogc3RyaW5nIHtcbiAgcmV0dXJuIHRleHRcbiAgICAudG9Mb3dlckNhc2UoKVxuICAgIC50cmltKClcbiAgICAubm9ybWFsaXplKFwiTkZEXCIpXG4gICAgLnJlcGxhY2UoL1tcXHUwMzAwLVxcdTAzNmZdL2csIFwiXCIpXG4gICAgLnJlcGxhY2UoL1teYS16MC05XFxzLV0vZywgXCJcIilcbiAgICAucmVwbGFjZSgvW1xccy1dKy9nLCBcIi1cIilcbiAgICAucmVwbGFjZSgvXi0rfC0rJC9nLCBcIlwiKVxufVxuXG5leHBvcnQgZnVuY3Rpb24gZ2V0Q291cnNlSWRGcm9tUGF0aChwYXRoOiBzdHJpbmcpOiBzdHJpbmcgfCBudWxsIHtcbiAgLy8gRXh0cmFjdCBjb3Vyc2UgSUQgZnJvbSBwYXRoIGxpa2UgXCIyMDI1L0ZhbGwvUFNJLTEwMS8uLi5cIiBvciBmaWxlbmFtZSBcIlBTSS0xMDEgLSBJbnRybyB0byBQc3ljaC5tZFwiXG4gIGNvbnN0IHBhcnRzID0gcGF0aC5zcGxpdChcIi9cIilcbiAgZm9yIChjb25zdCBwYXJ0IG9mIHBhcnRzKSB7XG4gICAgLy8gTG9vayBmb3IgY291cnNlIElEIHBhdHRlcm4gaW4gZWFjaCBwYXRoIHNlZ21lbnRcbiAgICBjb25zdCBtYXRjaCA9IHBhcnQubWF0Y2goLyhbQS1aXXsyLDR9LVxcZHszfSkvKVxuICAgIGlmIChtYXRjaCkge1xuICAgICAgcmV0dXJuIG1hdGNoWzFdXG4gICAgfVxuICB9XG4gIHJldHVybiBudWxsXG59XG5cbmV4cG9ydCBmdW5jdGlvbiB2YWxpZGF0ZURhdGUoZGF0ZVN0cmluZzogc3RyaW5nKTogYm9vbGVhbiB7XG4gIGNvbnN0IHJlZ2V4ID0gL15cXGR7NH0tXFxkezJ9LVxcZHsyfSQvXG4gIGlmICghZGF0ZVN0cmluZy5tYXRjaChyZWdleCkpIHJldHVybiBmYWxzZVxuXG4gIGNvbnN0IGRhdGUgPSBuZXcgRGF0ZShkYXRlU3RyaW5nKVxuICBjb25zdCB0aW1lc3RhbXAgPSBkYXRlLmdldFRpbWUoKVxuXG4gIGlmICh0eXBlb2YgdGltZXN0YW1wICE9PSBcIm51bWJlclwiIHx8IGlzTmFOKHRpbWVzdGFtcCkpIHJldHVybiBmYWxzZVxuXG4gIHJldHVybiBkYXRlU3RyaW5nID09PSBkYXRlLnRvSVNPU3RyaW5nKCkuc3BsaXQoXCJUXCIpWzBdXG59XG4iLCAiaW1wb3J0IHsgQXBwLCBOb3RpY2UgfSBmcm9tIFwib2JzaWRpYW5cIlxuaW1wb3J0IHsgVHVja2Vyc1Rvb2xzU2V0dGluZ3MgfSBmcm9tIFwiLi9zZXR0aW5nc1wiXG5cbmludGVyZmFjZSBUZW1wbGF0ZU1hbmlmZXN0IHtcbiAgdmVyc2lvbjogc3RyaW5nXG4gIHRlbXBsYXRlczogUmVjb3JkPHN0cmluZywgc3RyaW5nPlxuICBwbHVnaW5fdmVyc2lvbjogc3RyaW5nXG4gIHJlbGVhc2Vfbm90ZXM6IHN0cmluZ1xufVxuXG5leHBvcnQgY2xhc3MgVGVtcGxhdGVNYW5hZ2VyIHtcbiAgYXBwOiBBcHBcbiAgc2V0dGluZ3M6IFR1Y2tlcnNUb29sc1NldHRpbmdzXG4gIG1hbmlmZXN0OiBUZW1wbGF0ZU1hbmlmZXN0XG5cbiAgY29uc3RydWN0b3IoYXBwOiBBcHAsIHNldHRpbmdzOiBUdWNrZXJzVG9vbHNTZXR0aW5ncykge1xuICAgIHRoaXMuYXBwID0gYXBwXG4gICAgdGhpcy5zZXR0aW5ncyA9IHNldHRpbmdzXG4gICAgdGhpcy5tYW5pZmVzdCA9IHtcbiAgICAgIHZlcnNpb246IFwiMS4wLjBcIixcbiAgICAgIHRlbXBsYXRlczoge1xuICAgICAgICBcIkNvdXJzZXMvQ3JlYXRlIENvdXJzZSBIb21lcGFnZS5tZFwiOiBcIjEuMC4wXCIsXG4gICAgICAgIFwiQ291cnNlcy9Db3Vyc2UgSW5kZXgubWRcIjogXCIxLjAuMFwiLFxuICAgICAgICBcIk1vZHVsZXMvQ3JlYXRlIE1vZHVsZS5tZFwiOiBcIjEuMC4wXCIsXG4gICAgICAgIFwiQ2hhcHRlcnMvQ3JlYXRlIENoYXB0ZXIubWRcIjogXCIxLjAuMFwiLFxuICAgICAgICBcIkFzc2lnbm1lbnRzL0NyZWF0ZSBBc3NpZ25tZW50Lm1kXCI6IFwiMS4wLjBcIixcbiAgICAgICAgXCJEYWlseS9EYWlseSBOb3RlLm1kXCI6IFwiMS4wLjBcIixcbiAgICAgICAgXCJVdGlsaXRpZXMvVm9jYWJ1bGFyeSBFbnRyeS5tZFwiOiBcIjEuMC4wXCIsXG4gICAgICAgIFwiVXRpbGl0aWVzL0R1ZSBEYXRlIEVudHJ5Lm1kXCI6IFwiMS4wLjBcIlxuICAgICAgfSxcbiAgICAgIHBsdWdpbl92ZXJzaW9uOiBcIjEuMC4wXCIsXG4gICAgICByZWxlYXNlX25vdGVzOiBcIkluaXRpYWwgcmVsZWFzZSBvZiBUdWNrZXJzIFRvb2xzIHRlbXBsYXRlc1wiXG4gICAgfVxuICB9XG5cbiAgYXN5bmMgaW5zdGFsbFRlbXBsYXRlcygpIHtcbiAgICB0cnkge1xuICAgICAgLy8gR2V0IFRlbXBsYXRlciBwbHVnaW4gc2V0dGluZ3MgdG8gZmluZCB0ZW1wbGF0ZSBmb2xkZXJcbiAgICAgIGNvbnN0IHRlbXBsYXRlclBsdWdpbiA9IHRoaXMuZ2V0VGVtcGxhdGVyUGx1Z2luKClcbiAgICAgIGlmICghdGVtcGxhdGVyUGx1Z2luKSB7XG4gICAgICAgIG5ldyBOb3RpY2UoXG4gICAgICAgICAgXCJUZW1wbGF0ZXIgcGx1Z2luIG5vdCBmb3VuZC4gUGxlYXNlIGluc3RhbGwgYW5kIGVuYWJsZSB0aGUgVGVtcGxhdGVyIHBsdWdpbiBmaXJzdC5cIlxuICAgICAgICApXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXG4gICAgICAgICAgXCJUZW1wbGF0ZXIgcGx1Z2luIG5vdCBmb3VuZC4gUGxlYXNlIGluc3RhbGwgYW5kIGVuYWJsZSB0aGUgVGVtcGxhdGVyIHBsdWdpbiBmaXJzdC5cIlxuICAgICAgICApXG4gICAgICAgIHJldHVyblxuICAgICAgfVxuXG4gICAgICBjb25zdCB0ZW1wbGF0ZUZvbGRlclBhdGggPSB0aGlzLmdldFRlbXBsYXRlRm9sZGVyUGF0aCh0ZW1wbGF0ZXJQbHVnaW4pXG4gICAgICBpZiAoIXRlbXBsYXRlRm9sZGVyUGF0aCkge1xuICAgICAgICBuZXcgTm90aWNlKFxuICAgICAgICAgIFwiVGVtcGxhdGUgZm9sZGVyIG5vdCBjb25maWd1cmVkIGluIFRlbXBsYXRlciBzZXR0aW5ncy4gUGxlYXNlIGNvbmZpZ3VyZSBpdCBpbiBUZW1wbGF0ZXIgc2V0dGluZ3MgZmlyc3QuXCJcbiAgICAgICAgKVxuICAgICAgICBjb25zb2xlLmVycm9yKFxuICAgICAgICAgIFwiVGVtcGxhdGUgZm9sZGVyIG5vdCBjb25maWd1cmVkIGluIFRlbXBsYXRlciBzZXR0aW5ncy4gUGxlYXNlIGNvbmZpZ3VyZSBpdCBpbiBUZW1wbGF0ZXIgc2V0dGluZ3MgZmlyc3QuXCJcbiAgICAgICAgKVxuICAgICAgICByZXR1cm5cbiAgICAgIH1cblxuICAgICAgY29uc3QgZnVsbFRlbXBsYXRlUGF0aCA9IGAke3RlbXBsYXRlRm9sZGVyUGF0aH0vJHt0aGlzLnNldHRpbmdzLnRlbXBsYXRlRm9sZGVyfWBcblxuICAgICAgLy8gQ3JlYXRlIHRoZSBtYWluIHRlbXBsYXRlIGZvbGRlciBpZiBpdCBkb2Vzbid0IGV4aXN0XG4gICAgICB0cnkge1xuICAgICAgICBhd2FpdCB0aGlzLmFwcC52YXVsdC5jcmVhdGVGb2xkZXIoZnVsbFRlbXBsYXRlUGF0aClcbiAgICAgICAgY29uc29sZS5sb2coYENyZWF0ZWQgdGVtcGxhdGUgZm9sZGVyOiAke2Z1bGxUZW1wbGF0ZVBhdGh9YClcbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgLy8gRm9sZGVyIG1pZ2h0IGFscmVhZHkgZXhpc3QsIHdoaWNoIGlzIGZpbmVcbiAgICAgICAgY29uc29sZS5sb2coXG4gICAgICAgICAgYFRlbXBsYXRlIGZvbGRlciBhbHJlYWR5IGV4aXN0cyBvciBjcmVhdGVkOiAke2Z1bGxUZW1wbGF0ZVBhdGh9YFxuICAgICAgICApXG4gICAgICB9XG5cbiAgICAgIC8vIENyZWF0ZSBzdWJkaXJlY3Rvcmllc1xuICAgICAgY29uc3Qgc3ViZGlycyA9IFtcbiAgICAgICAgXCJDb3Vyc2VzXCIsXG4gICAgICAgIFwiTW9kdWxlc1wiLFxuICAgICAgICBcIkNoYXB0ZXJzXCIsXG4gICAgICAgIFwiQXNzaWdubWVudHNcIixcbiAgICAgICAgXCJEYWlseVwiLFxuICAgICAgICBcIlV0aWxpdGllc1wiXG4gICAgICBdXG4gICAgICBmb3IgKGNvbnN0IHN1YmRpciBvZiBzdWJkaXJzKSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgY29uc3Qgc3ViUGF0aCA9IGAke2Z1bGxUZW1wbGF0ZVBhdGh9LyR7c3ViZGlyfWBcbiAgICAgICAgICBhd2FpdCB0aGlzLmFwcC52YXVsdC5jcmVhdGVGb2xkZXIoc3ViUGF0aClcbiAgICAgICAgICBjb25zb2xlLmxvZyhgQ3JlYXRlZCBzdWJkaXJlY3Rvcnk6ICR7c3ViUGF0aH1gKVxuICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgLy8gRm9sZGVyIG1pZ2h0IGFscmVhZHkgZXhpc3QsIHdoaWNoIGlzIGZpbmVcbiAgICAgICAgICBjb25zb2xlLmxvZyhcbiAgICAgICAgICAgIGBTdWJkaXJlY3RvcnkgYWxyZWFkeSBleGlzdHM6ICR7ZnVsbFRlbXBsYXRlUGF0aH0vJHtzdWJkaXJ9YFxuICAgICAgICAgIClcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICAvLyBJbnN0YWxsIHRlbXBsYXRlc1xuICAgICAgYXdhaXQgdGhpcy5pbnN0YWxsQ291cnNlVGVtcGxhdGVzKGZ1bGxUZW1wbGF0ZVBhdGgpXG4gICAgICBhd2FpdCB0aGlzLmluc3RhbGxNb2R1bGVUZW1wbGF0ZXMoZnVsbFRlbXBsYXRlUGF0aClcbiAgICAgIGF3YWl0IHRoaXMuaW5zdGFsbENoYXB0ZXJUZW1wbGF0ZXMoZnVsbFRlbXBsYXRlUGF0aClcbiAgICAgIGF3YWl0IHRoaXMuaW5zdGFsbEFzc2lnbm1lbnRUZW1wbGF0ZXMoZnVsbFRlbXBsYXRlUGF0aClcbiAgICAgIGF3YWl0IHRoaXMuaW5zdGFsbERhaWx5VGVtcGxhdGVzKGZ1bGxUZW1wbGF0ZVBhdGgpXG4gICAgICBhd2FpdCB0aGlzLmluc3RhbGxVdGlsaXR5VGVtcGxhdGVzKGZ1bGxUZW1wbGF0ZVBhdGgpXG5cbiAgICAgIC8vIENyZWF0ZSBSRUFETUVcbiAgICAgIGF3YWl0IHRoaXMuY3JlYXRlUkVBRE1FKGZ1bGxUZW1wbGF0ZVBhdGgpXG5cbiAgICAgIC8vIENyZWF0ZSB0ZW1wbGF0ZSBtYW5pZmVzdFxuICAgICAgYXdhaXQgdGhpcy5jcmVhdGVUZW1wbGF0ZU1hbmlmZXN0KGZ1bGxUZW1wbGF0ZVBhdGgpXG5cbiAgICAgIG5ldyBOb3RpY2UoXCJUdWNrZXJzIFRvb2xzIHRlbXBsYXRlcyBpbnN0YWxsZWQgc3VjY2Vzc2Z1bGx5IVwiKVxuICAgICAgY29uc29sZS5sb2coXCJUdWNrZXJzIFRvb2xzIHRlbXBsYXRlcyBpbnN0YWxsZWQgc3VjY2Vzc2Z1bGx5XCIpXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBpbnN0YWxsaW5nIHRlbXBsYXRlczpcIiwgZXJyb3IpXG4gICAgICBuZXcgTm90aWNlKFwiRXJyb3IgaW5zdGFsbGluZyB0ZW1wbGF0ZXMuIENoZWNrIGNvbnNvbGUgZm9yIGRldGFpbHMuXCIpXG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSBnZXRUZW1wbGF0ZXJQbHVnaW4oKTogYW55IHtcbiAgICAvLyBUcnkgbXVsdGlwbGUgd2F5cyB0byBhY2Nlc3MgdGhlIFRlbXBsYXRlciBwbHVnaW5cbiAgICBjb25zdCBwb3NzaWJsZVBhdGhzID0gW1xuICAgICAgKHRoaXMuYXBwIGFzIGFueSkucGx1Z2lucy5wbHVnaW5zW1widGVtcGxhdGVyLW9ic2lkaWFuXCJdLFxuICAgICAgKHRoaXMuYXBwIGFzIGFueSkucGx1Z2lucy5wbHVnaW5zW1widGVtcGxhdGVyXCJdLFxuICAgICAgKHRoaXMuYXBwIGFzIGFueSkucGx1Z2lucy5nZXRQbHVnaW4oXCJ0ZW1wbGF0ZXItb2JzaWRpYW5cIiksXG4gICAgICAodGhpcy5hcHAgYXMgYW55KS5wbHVnaW5zLmdldFBsdWdpbihcInRlbXBsYXRlclwiKVxuICAgIF1cblxuICAgIGZvciAoY29uc3QgcGF0aCBvZiBwb3NzaWJsZVBhdGhzKSB7XG4gICAgICBpZiAocGF0aCkge1xuICAgICAgICByZXR1cm4gcGF0aFxuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBudWxsXG4gIH1cblxuICBwcml2YXRlIGdldFRlbXBsYXRlRm9sZGVyUGF0aCh0ZW1wbGF0ZXJQbHVnaW46IGFueSk6IHN0cmluZyB8IG51bGwge1xuICAgIGNvbnN0IHNldHRpbmdzID0gdGVtcGxhdGVyUGx1Z2luLnNldHRpbmdzXG5cbiAgICBpZiAoIXNldHRpbmdzKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiVGVtcGxhdGVyIHBsdWdpbiBoYXMgbm8gc2V0dGluZ3NcIilcbiAgICAgIHJldHVybiBudWxsXG4gICAgfVxuXG4gICAgLy8gVHJ5IGRpZmZlcmVudCBwb3NzaWJsZSBwcm9wZXJ0eSBuYW1lcyBmb3IgdGVtcGxhdGUgZm9sZGVyXG4gICAgY29uc3QgcG9zc2libGVQYXRocyA9IFtcbiAgICAgIHNldHRpbmdzLnRlbXBsYXRlc19mb2xkZXIsICAvLyBDaGFuZ2VkIGZyb20gdGVtcGxhdGVfZm9sZGVyIHRvIG1hdGNoIGFjdHVhbCBzZXR0aW5nXG4gICAgICBzZXR0aW5ncy50ZW1wbGF0ZV9mb2xkZXIsXG4gICAgICBzZXR0aW5ncy50ZW1wbGF0ZUZvbGRlcixcbiAgICAgIHNldHRpbmdzLnRlbXBsYXRlRm9sZGVyUGF0aCxcbiAgICAgIHNldHRpbmdzLmZvbGRlclxuICAgIF1cblxuICAgIGZvciAoY29uc3QgcGF0aCBvZiBwb3NzaWJsZVBhdGhzKSB7XG4gICAgICBpZiAocGF0aCAmJiB0eXBlb2YgcGF0aCA9PT0gXCJzdHJpbmdcIikge1xuICAgICAgICByZXR1cm4gcGF0aFxuICAgICAgfVxuICAgIH1cblxuICAgIGNvbnNvbGUuZXJyb3IoXG4gICAgICBcIlRlbXBsYXRlIGZvbGRlciBub3QgZm91bmQgaW4gVGVtcGxhdGVyIHNldHRpbmdzLiBBdmFpbGFibGUgc2V0dGluZ3M6XCIsXG4gICAgICBPYmplY3Qua2V5cyhzZXR0aW5ncylcbiAgICApXG4gICAgcmV0dXJuIG51bGxcbiAgfVxuXG4gIGFzeW5jIGNyZWF0ZVRlbXBsYXRlTWFuaWZlc3QoYmFzZVBhdGg6IHN0cmluZykge1xuICAgIGNvbnN0IG1hbmlmZXN0UGF0aCA9IGAke2Jhc2VQYXRofS90ZW1wbGF0ZS1tYW5pZmVzdC5qc29uYFxuICAgIGNvbnN0IG1hbmlmZXN0Q29udGVudCA9IEpTT04uc3RyaW5naWZ5KHRoaXMubWFuaWZlc3QsIG51bGwsIDIpXG5cbiAgICB0cnkge1xuICAgICAgLy8gQ2hlY2sgaWYgbWFuaWZlc3QgYWxyZWFkeSBleGlzdHNcbiAgICAgIGNvbnN0IGV4aXN0aW5nTWFuaWZlc3QgPVxuICAgICAgICB0aGlzLmFwcC52YXVsdC5nZXRBYnN0cmFjdEZpbGVCeVBhdGgobWFuaWZlc3RQYXRoKVxuICAgICAgaWYgKGV4aXN0aW5nTWFuaWZlc3QpIHtcbiAgICAgICAgLy8gVXBkYXRlIHRoZSBleGlzdGluZyBtYW5pZmVzdFxuICAgICAgICBjb25zdCBmaWxlID0gZXhpc3RpbmdNYW5pZmVzdCBhcyBpbXBvcnQoXCJvYnNpZGlhblwiKS5URmlsZVxuICAgICAgICBhd2FpdCB0aGlzLmFwcC52YXVsdC5tb2RpZnkoZmlsZSwgbWFuaWZlc3RDb250ZW50KVxuICAgICAgICBjb25zb2xlLmxvZyhgVXBkYXRlZCB0ZW1wbGF0ZSBtYW5pZmVzdDogJHttYW5pZmVzdFBhdGh9YClcbiAgICAgICAgcmV0dXJuXG4gICAgICB9XG5cbiAgICAgIC8vIENyZWF0ZSB0aGUgbWFuaWZlc3QgZmlsZVxuICAgICAgYXdhaXQgdGhpcy5hcHAudmF1bHQuY3JlYXRlKG1hbmlmZXN0UGF0aCwgbWFuaWZlc3RDb250ZW50KVxuICAgICAgY29uc29sZS5sb2coYENyZWF0ZWQgdGVtcGxhdGUgbWFuaWZlc3Q6ICR7bWFuaWZlc3RQYXRofWApXG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgbmV3IE5vdGljZShgRXJyb3IgY3JlYXRpbmcgdGVtcGxhdGUgbWFuaWZlc3QgJHttYW5pZmVzdFBhdGh9YClcbiAgICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIGNyZWF0aW5nIHRlbXBsYXRlIG1hbmlmZXN0ICR7bWFuaWZlc3RQYXRofTpgLCBlKVxuICAgIH1cbiAgfVxuXG4gIGFzeW5jIGNoZWNrRm9yVGVtcGxhdGVVcGRhdGVzKCk6IFByb21pc2U8Ym9vbGVhbj4ge1xuICAgIC8vIFRoaXMgd291bGQgY2hlY2sgaWYgdGVtcGxhdGVzIG5lZWQgdG8gYmUgdXBkYXRlZFxuICAgIC8vIEZvciBub3csIHdlJ2xsIGp1c3QgcmV0dXJuIGZhbHNlXG4gICAgY29uc29sZS5sb2coXCJDaGVja2luZyBmb3IgdGVtcGxhdGUgdXBkYXRlc1wiKVxuICAgIHJldHVybiBmYWxzZVxuICB9XG5cbiAgYXN5bmMgdXBkYXRlVGVtcGxhdGVzKCkge1xuICAgIHRyeSB7XG4gICAgICAvLyBUaGlzIHdvdWxkIHVwZGF0ZSBleGlzdGluZyB0ZW1wbGF0ZXNcbiAgICAgIGNvbnNvbGUubG9nKFwiVXBkYXRpbmcgdGVtcGxhdGVzXCIpXG5cbiAgICAgIC8vIEdldCBUZW1wbGF0ZXIgcGx1Z2luIHNldHRpbmdzIHRvIGZpbmQgdGVtcGxhdGUgZm9sZGVyXG4gICAgICBjb25zdCB0ZW1wbGF0ZXJQbHVnaW4gPSB0aGlzLmdldFRlbXBsYXRlclBsdWdpbigpXG4gICAgICBpZiAoIXRlbXBsYXRlclBsdWdpbikge1xuICAgICAgICBuZXcgTm90aWNlKFxuICAgICAgICAgIFwiVGVtcGxhdGVyIHBsdWdpbiBub3QgZm91bmQuIFBsZWFzZSBpbnN0YWxsIGFuZCBlbmFibGUgdGhlIFRlbXBsYXRlciBwbHVnaW4gZmlyc3QuXCJcbiAgICAgICAgKVxuICAgICAgICBjb25zb2xlLmVycm9yKFxuICAgICAgICAgIFwiVGVtcGxhdGVyIHBsdWdpbiBub3QgZm91bmQuIFBsZWFzZSBpbnN0YWxsIGFuZCBlbmFibGUgdGhlIFRlbXBsYXRlciBwbHVnaW4gZmlyc3QuXCJcbiAgICAgICAgKVxuICAgICAgICByZXR1cm5cbiAgICAgIH1cblxuICAgICAgY29uc3QgdGVtcGxhdGVGb2xkZXJQYXRoID0gdGhpcy5nZXRUZW1wbGF0ZUZvbGRlclBhdGgodGVtcGxhdGVyUGx1Z2luKVxuICAgICAgaWYgKCF0ZW1wbGF0ZUZvbGRlclBhdGgpIHtcbiAgICAgICAgbmV3IE5vdGljZShcbiAgICAgICAgICBcIlRlbXBsYXRlIGZvbGRlciBub3QgY29uZmlndXJlZCBpbiBUZW1wbGF0ZXIgc2V0dGluZ3MuIFBsZWFzZSBjb25maWd1cmUgaXQgaW4gVGVtcGxhdGVyIHNldHRpbmdzIGZpcnN0LlwiXG4gICAgICAgIClcbiAgICAgICAgY29uc29sZS5lcnJvcihcbiAgICAgICAgICBcIlRlbXBsYXRlIGZvbGRlciBub3QgY29uZmlndXJlZCBpbiBUZW1wbGF0ZXIgc2V0dGluZ3MuIFBsZWFzZSBjb25maWd1cmUgaXQgaW4gVGVtcGxhdGVyIHNldHRpbmdzIGZpcnN0LlwiXG4gICAgICAgIClcbiAgICAgICAgcmV0dXJuXG4gICAgICB9XG5cbiAgICAgIGNvbnN0IGZ1bGxUZW1wbGF0ZVBhdGggPSBgJHt0ZW1wbGF0ZUZvbGRlclBhdGh9LyR7dGhpcy5zZXR0aW5ncy50ZW1wbGF0ZUZvbGRlcn1gXG5cbiAgICAgIC8vIFVwZGF0ZSB0ZW1wbGF0ZXMgKHRoaXMgd2lsbCBvdmVyd3JpdGUgZXhpc3Rpbmcgb25lcylcbiAgICAgIGF3YWl0IHRoaXMuaW5zdGFsbENvdXJzZVRlbXBsYXRlcyhmdWxsVGVtcGxhdGVQYXRoKVxuICAgICAgYXdhaXQgdGhpcy5pbnN0YWxsTW9kdWxlVGVtcGxhdGVzKGZ1bGxUZW1wbGF0ZVBhdGgpXG4gICAgICBhd2FpdCB0aGlzLmluc3RhbGxDaGFwdGVyVGVtcGxhdGVzKGZ1bGxUZW1wbGF0ZVBhdGgpXG4gICAgICBhd2FpdCB0aGlzLmluc3RhbGxBc3NpZ25tZW50VGVtcGxhdGVzKGZ1bGxUZW1wbGF0ZVBhdGgpXG4gICAgICBhd2FpdCB0aGlzLmluc3RhbGxEYWlseVRlbXBsYXRlcyhmdWxsVGVtcGxhdGVQYXRoKVxuICAgICAgYXdhaXQgdGhpcy5pbnN0YWxsVXRpbGl0eVRlbXBsYXRlcyhmdWxsVGVtcGxhdGVQYXRoKVxuXG4gICAgICAvLyBVcGRhdGUgUkVBRE1FXG4gICAgICBhd2FpdCB0aGlzLmNyZWF0ZVJFQURNRShmdWxsVGVtcGxhdGVQYXRoKVxuXG4gICAgICAvLyBVcGRhdGUgdGVtcGxhdGUgbWFuaWZlc3RcbiAgICAgIGF3YWl0IHRoaXMuY3JlYXRlVGVtcGxhdGVNYW5pZmVzdChmdWxsVGVtcGxhdGVQYXRoKVxuXG4gICAgICBuZXcgTm90aWNlKFwiVHVja2VycyBUb29scyB0ZW1wbGF0ZXMgdXBkYXRlZCBzdWNjZXNzZnVsbHkhXCIpXG4gICAgICBjb25zb2xlLmxvZyhcIlR1Y2tlcnMgVG9vbHMgdGVtcGxhdGVzIHVwZGF0ZWQgc3VjY2Vzc2Z1bGx5XCIpXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciB1cGRhdGluZyB0ZW1wbGF0ZXM6XCIsIGVycm9yKVxuICAgICAgbmV3IE5vdGljZShcIkVycm9yIHVwZGF0aW5nIHRlbXBsYXRlcy4gQ2hlY2sgY29uc29sZSBmb3IgZGV0YWlscy5cIilcbiAgICB9XG4gIH1cblxuICBhc3luYyBpbnN0YWxsQ291cnNlVGVtcGxhdGVzKGJhc2VQYXRoOiBzdHJpbmcpIHtcbiAgICBjb25zdCBjb3Vyc2VQYXRoID0gYCR7YmFzZVBhdGh9L0NvdXJzZXNgXG5cbiAgICAvLyBDcmVhdGUgQ291cnNlIEhvbWVwYWdlIHRlbXBsYXRlXG4gICAgY29uc3QgY291cnNlSG9tZXBhZ2VUZW1wbGF0ZSA9IHRoaXMuZ2VuZXJhdGVDb3Vyc2VIb21lcGFnZVRlbXBsYXRlKClcbiAgICBhd2FpdCB0aGlzLndyaXRlVGVtcGxhdGVGaWxlKFxuICAgICAgYCR7Y291cnNlUGF0aH0vQ3JlYXRlIENvdXJzZSBIb21lcGFnZS5tZGAsXG4gICAgICBjb3Vyc2VIb21lcGFnZVRlbXBsYXRlXG4gICAgKVxuXG4gICAgLy8gQ3JlYXRlIENvdXJzZSBJbmRleCB0ZW1wbGF0ZVxuICAgIGNvbnN0IGNvdXJzZUluZGV4VGVtcGxhdGUgPSB0aGlzLmdlbmVyYXRlQ291cnNlSW5kZXhUZW1wbGF0ZSgpXG4gICAgYXdhaXQgdGhpcy53cml0ZVRlbXBsYXRlRmlsZShcbiAgICAgIGAke2NvdXJzZVBhdGh9L0NvdXJzZSBJbmRleC5tZGAsXG4gICAgICBjb3Vyc2VJbmRleFRlbXBsYXRlXG4gICAgKVxuICB9XG5cbiAgYXN5bmMgaW5zdGFsbE1vZHVsZVRlbXBsYXRlcyhiYXNlUGF0aDogc3RyaW5nKSB7XG4gICAgY29uc3QgbW9kdWxlUGF0aCA9IGAke2Jhc2VQYXRofS9Nb2R1bGVzYFxuXG4gICAgLy8gQ3JlYXRlIE1vZHVsZSB0ZW1wbGF0ZVxuICAgIGNvbnN0IG1vZHVsZVRlbXBsYXRlID0gdGhpcy5nZW5lcmF0ZU1vZHVsZVRlbXBsYXRlKClcbiAgICBhd2FpdCB0aGlzLndyaXRlVGVtcGxhdGVGaWxlKFxuICAgICAgYCR7bW9kdWxlUGF0aH0vQ3JlYXRlIE1vZHVsZS5tZGAsXG4gICAgICBtb2R1bGVUZW1wbGF0ZVxuICAgIClcbiAgfVxuXG4gIGFzeW5jIGluc3RhbGxDaGFwdGVyVGVtcGxhdGVzKGJhc2VQYXRoOiBzdHJpbmcpIHtcbiAgICBjb25zdCBjaGFwdGVyUGF0aCA9IGAke2Jhc2VQYXRofS9DaGFwdGVyc2BcblxuICAgIC8vIENyZWF0ZSBDaGFwdGVyIHRlbXBsYXRlXG4gICAgY29uc3QgY2hhcHRlclRlbXBsYXRlID0gdGhpcy5nZW5lcmF0ZUNoYXB0ZXJUZW1wbGF0ZSgpXG4gICAgYXdhaXQgdGhpcy53cml0ZVRlbXBsYXRlRmlsZShcbiAgICAgIGAke2NoYXB0ZXJQYXRofS9DcmVhdGUgQ2hhcHRlci5tZGAsXG4gICAgICBjaGFwdGVyVGVtcGxhdGVcbiAgICApXG4gIH1cblxuICBhc3luYyBpbnN0YWxsQXNzaWdubWVudFRlbXBsYXRlcyhiYXNlUGF0aDogc3RyaW5nKSB7XG4gICAgY29uc3QgYXNzaWdubWVudFBhdGggPSBgJHtiYXNlUGF0aH0vQXNzaWdubWVudHNgXG5cbiAgICAvLyBDcmVhdGUgQXNzaWdubWVudCB0ZW1wbGF0ZVxuICAgIGNvbnN0IGFzc2lnbm1lbnRUZW1wbGF0ZSA9IHRoaXMuZ2VuZXJhdGVBc3NpZ25tZW50VGVtcGxhdGUoKVxuICAgIGF3YWl0IHRoaXMud3JpdGVUZW1wbGF0ZUZpbGUoXG4gICAgICBgJHthc3NpZ25tZW50UGF0aH0vQ3JlYXRlIEFzc2lnbm1lbnQubWRgLFxuICAgICAgYXNzaWdubWVudFRlbXBsYXRlXG4gICAgKVxuICB9XG5cbiAgYXN5bmMgaW5zdGFsbERhaWx5VGVtcGxhdGVzKGJhc2VQYXRoOiBzdHJpbmcpIHtcbiAgICBjb25zdCBkYWlseVBhdGggPSBgJHtiYXNlUGF0aH0vRGFpbHlgXG5cbiAgICAvLyBDcmVhdGUgRGFpbHkgTm90ZSB0ZW1wbGF0ZVxuICAgIGNvbnN0IGRhaWx5Tm90ZVRlbXBsYXRlID0gdGhpcy5nZW5lcmF0ZURhaWx5Tm90ZVRlbXBsYXRlKClcbiAgICBhd2FpdCB0aGlzLndyaXRlVGVtcGxhdGVGaWxlKFxuICAgICAgYCR7ZGFpbHlQYXRofS9EYWlseSBOb3RlLm1kYCxcbiAgICAgIGRhaWx5Tm90ZVRlbXBsYXRlXG4gICAgKVxuICB9XG5cbiAgYXN5bmMgaW5zdGFsbFV0aWxpdHlUZW1wbGF0ZXMoYmFzZVBhdGg6IHN0cmluZykge1xuICAgIGNvbnN0IHV0aWxpdHlQYXRoID0gYCR7YmFzZVBhdGh9L1V0aWxpdGllc2BcblxuICAgIC8vIENyZWF0ZSBWb2NhYnVsYXJ5IEVudHJ5IHRlbXBsYXRlXG4gICAgY29uc3Qgdm9jYWJUZW1wbGF0ZSA9IHRoaXMuZ2VuZXJhdGVWb2NhYnVsYXJ5VGVtcGxhdGUoKVxuICAgIGF3YWl0IHRoaXMud3JpdGVUZW1wbGF0ZUZpbGUoXG4gICAgICBgJHt1dGlsaXR5UGF0aH0vVm9jYWJ1bGFyeSBFbnRyeS5tZGAsXG4gICAgICB2b2NhYlRlbXBsYXRlXG4gICAgKVxuXG4gICAgLy8gQ3JlYXRlIER1ZSBEYXRlIEVudHJ5IHRlbXBsYXRlXG4gICAgY29uc3QgZHVlRGF0ZVRlbXBsYXRlID0gdGhpcy5nZW5lcmF0ZUR1ZURhdGVUZW1wbGF0ZSgpXG4gICAgYXdhaXQgdGhpcy53cml0ZVRlbXBsYXRlRmlsZShcbiAgICAgIGAke3V0aWxpdHlQYXRofS9EdWUgRGF0ZSBFbnRyeS5tZGAsXG4gICAgICBkdWVEYXRlVGVtcGxhdGVcbiAgICApXG4gIH1cblxuICBhc3luYyB3cml0ZVRlbXBsYXRlRmlsZShwYXRoOiBzdHJpbmcsIGNvbnRlbnQ6IHN0cmluZykge1xuICAgIHRyeSB7XG4gICAgICAvLyBDaGVjayBpZiBmaWxlIGFscmVhZHkgZXhpc3RzXG4gICAgICBjb25zdCBleGlzdGluZ0ZpbGUgPSB0aGlzLmFwcC52YXVsdC5nZXRBYnN0cmFjdEZpbGVCeVBhdGgocGF0aClcbiAgICAgIGlmIChleGlzdGluZ0ZpbGUpIHtcbiAgICAgICAgLy8gRm9yIG5vdywgd2UnbGwgdXBkYXRlIGV4aXN0aW5nIHRlbXBsYXRlc1xuICAgICAgICAvLyBJbiBhIHJlYWwgaW1wbGVtZW50YXRpb24sIHdlJ2QgY2hlY2sgdmVyc2lvbnMgYW5kIG9mZmVyIHRvIHVwZGF0ZVxuICAgICAgICBjb25zb2xlLmxvZyhgVXBkYXRpbmcgZXhpc3RpbmcgdGVtcGxhdGUgZmlsZTogJHtwYXRofWApXG4gICAgICAgIGNvbnN0IGZpbGUgPSBleGlzdGluZ0ZpbGUgYXMgaW1wb3J0KFwib2JzaWRpYW5cIikuVEZpbGVcbiAgICAgICAgYXdhaXQgdGhpcy5hcHAudmF1bHQubW9kaWZ5KGZpbGUsIGNvbnRlbnQpXG4gICAgICAgIHJldHVyblxuICAgICAgfVxuXG4gICAgICAvLyBDcmVhdGUgdGhlIGZpbGVcbiAgICAgIGF3YWl0IHRoaXMuYXBwLnZhdWx0LmNyZWF0ZShwYXRoLCBjb250ZW50KVxuICAgICAgY29uc29sZS5sb2coYENyZWF0ZWQgdGVtcGxhdGUgZmlsZTogJHtwYXRofWApXG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgbmV3IE5vdGljZShgRXJyb3IgY3JlYXRpbmcgdGVtcGxhdGUgZmlsZSAke3BhdGh9YClcbiAgICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIGNyZWF0aW5nIHRlbXBsYXRlIGZpbGUgJHtwYXRofTpgLCBlKVxuICAgIH1cbiAgfVxuXG4gIGdlbmVyYXRlQ291cnNlSG9tZXBhZ2VUZW1wbGF0ZSgpOiBzdHJpbmcge1xuICAgIGNvbnN0IGVuaGFuY2VkTWV0YWRhdGEgPSB0aGlzLnNldHRpbmdzLnVzZUVuaGFuY2VkTWV0YWRhdGE7XG4gICAgXG4gICAgaWYgKGVuaGFuY2VkTWV0YWRhdGEpIHtcbiAgICAgIHJldHVybiBgLS0tXG5jb3Vyc2VfaWQ6IDwlIGNvdXJzZUlkICU+XG5jb3Vyc2Vfc2Vhc29uOiA8JSBjb3Vyc2VTZWFzb24gJT5cbmNvdXJzZV95ZWFyOiA8JSBjb3Vyc2VZZWFyICU+XG5jcmVhdGVkOiA8JSB0cC5kYXRlLm5vdyhcIllZWVktTU0tRERbVF1ISDptbTpzc1pcIikgJT5cbnRhZ3M6IFxuICAtIDwlIGNvdXJzZUlkICU+XG4gIC0gJHt0aGlzLnNldHRpbmdzLnNjaG9vbEFiYnJldmlhdGlvbn0vPCUgY291cnNlWWVhciAlPi88JSBjb3Vyc2VTZWFzb24gJT4vPCUgY291cnNlSWQgJT4vXG4gIC0gY291cnNlX2hvbWVcbiAgLSBlZHVjYXRpb25cbiAgLSAke3RoaXMuc2V0dGluZ3Muc2Nob29sTmFtZS5yZXBsYWNlKC9cXHMrL2csICdfJyl9XG5iYW5uZXI6XG5jc3NjbGFzc2VzOlxuICAtIHdoaXRlYm9hcmQtY291cnNlXG4tLS1cblxuPCUqXG4vLyBUdWNrZXJzIFRvb2xzIENvdXJzZSBDcmVhdGlvblxuLy8gRm9yIGJlc3QgZXhwZXJpZW5jZSwgdXNlIHRoZSBwbHVnaW4gY29tbWFuZDogQ29tbWFuZCBQYWxldHRlIFx1MjE5MiAnQ3JlYXRlIE5ldyBDb3Vyc2UnXG5cbmxldCBjb3Vyc2VOYW1lID0gXCJOZXcgQ291cnNlXCI7XG5sZXQgY291cnNlU2Vhc29uID0gXCJGYWxsXCI7IFxubGV0IGNvdXJzZVllYXIgPSBuZXcgRGF0ZSgpLmdldEZ1bGxZZWFyKCkudG9TdHJpbmcoKTtcbmxldCBjb3Vyc2VJZCA9IFwiQ09VUlNFX0lEXCI7XG5cbi8vIFRyeSB0byB1c2Ugc3lzdGVtIHByb21wdHMsIHdpdGggZ3JhY2VmdWwgZmFsbGJhY2tcbnRyeSB7XG4gIGlmICh0cCAmJiB0cC5zeXN0ZW0gJiYgdHAuc3lzdGVtLnByb21wdCkge1xuICAgIGNvdXJzZU5hbWUgPSBhd2FpdCB0cC5zeXN0ZW0ucHJvbXB0KFwiQ291cnNlIE5hbWUgKGUuZy4gU1dPLTI1MCAtIENvdXJzZSBUaXRsZSlcIikgfHwgY291cnNlTmFtZTtcbiAgICBjb3Vyc2VJZCA9IGNvdXJzZU5hbWUuc3BsaXQoJyAtICcpWzBdIHx8IGNvdXJzZU5hbWUucmVwbGFjZSgvW15hLXpBLVowLTldL2csIFwiX1wiKTtcbiAgICBjb3Vyc2VTZWFzb24gPSBhd2FpdCB0cC5zeXN0ZW0uc3VnZ2VzdGVyKFtcIkZhbGxcIixcIldpbnRlclwiLFwiU3ByaW5nXCIsXCJTdW1tZXJcIl0sW1wiRmFsbFwiLFwiV2ludGVyXCIsXCJTcHJpbmdcIixcIlN1bW1lclwiXSwgXCJTZWFzb25cIikgfHwgY291cnNlU2Vhc29uO1xuICAgIGNvdXJzZVllYXIgPSBhd2FpdCB0cC5zeXN0ZW0ucHJvbXB0KFwiWWVhclwiKSB8fCBjb3Vyc2VZZWFyO1xuICB9IGVsc2Uge1xuICAgIGNvbnNvbGUubG9nKFwiU3lzdGVtIHByb21wdHMgbm90IGF2YWlsYWJsZSwgdXNlIHRoZSBwbHVnaW4gY29tbWFuZCBpbnN0ZWFkXCIpO1xuICB9XG59IGNhdGNoIChlKSB7XG4gIGNvbnNvbGUuZXJyb3IoXCJFcnJvciB3aXRoIHN5c3RlbSBwcm9tcHRzOlwiLCBlLm1lc3NhZ2UpO1xuICBjb25zb2xlLmxvZyhcIlVzZSB0aGUgcGx1Z2luIGNvbW1hbmQ6IENvbW1hbmQgUGFsZXR0ZSBcdTIxOTIgJ0NyZWF0ZSBOZXcgQ291cnNlJ1wiKTtcbn1cblxuLy8gTW92ZSBmaWxlIHRvIGFwcHJvcHJpYXRlIGxvY2F0aW9uXG5hd2FpdCB0cC5maWxlLm1vdmUoXFxgL1xcJHtjb3Vyc2VZZWFyfS9cXCR7Y291cnNlU2Vhc29ufS9cXCR7Y291cnNlTmFtZX0vXFwke2NvdXJzZU5hbWV9XFxgKTtcblxuLy8gQ3JlYXRlIGF0dGFjaG1lbnRzIGZvbGRlclxudHJ5IHtcbiAgYXdhaXQgYXBwLnZhdWx0LmNyZWF0ZUZvbGRlcihcXGAvXFwke2NvdXJzZVllYXJ9L1xcJHtjb3Vyc2VTZWFzb259L1xcJHtjb3Vyc2VOYW1lfS9BdHRhY2htZW50c1xcYCk7XG59IGNhdGNoIChlKSB7XG4gIC8vIEZvbGRlciBtaWdodCBhbHJlYWR5IGV4aXN0XG59XG4lPlxuXG4jIDwlIGNvdXJzZU5hbWUgJT5cblxuIyMgQ291cnNlIEluZm9ybWF0aW9uXG4qKkNvdXJzZSoqOiA8JSBjb3Vyc2VOYW1lICU+XG4qKkNvdXJzZSBJRCoqOiA8JSBjb3Vyc2VJZCAlPlxuKipUZXJtKio6IDwlIGNvdXJzZVNlYXNvbiAlPiA8JSBjb3Vyc2VZZWFyICU+XG4qKlNjaG9vbCoqOiAke3RoaXMuc2V0dGluZ3Muc2Nob29sTmFtZX1cblxuIyMgSW5zdHJ1Y3RvclxuKipOYW1lKio6IFxcYElOUFVUW3RleHQoaW5zdHJ1Y3Rvcl9uYW1lKV1cXGBcbioqRW1haWwqKjogXFxgSU5QVVRbdGV4dChpbnN0cnVjdG9yX2VtYWlsKV1cXGBcbioqT2ZmaWNlIEhvdXJzKio6IFxcYElOUFVUW3RleHQoaW5zdHJ1Y3Rvcl9vZmZpY2VfaG91cnMpXVxcYFxuKipPZmZpY2UgTG9jYXRpb24qKjogXFxgSU5QVVRbdGV4dChpbnN0cnVjdG9yX29mZmljZV9sb2NhdGlvbildXFxgXG5cbiMjIENvdXJzZSBEZXNjcmlwdGlvblxuXFxgSU5QVVRbbXVsdGlsaW5lKDEweDUwKShjb3Vyc2VfZGVzY3JpcHRpb24pXVxcYFxuXG4jIyBMZWFybmluZyBPYmplY3RpdmVzXG5cXGBJTlBVVFttdWx0aWxpbmUoMTB4NTApKGxlYXJuaW5nX29iamVjdGl2ZXMpXVxcYFxuXG4jIyBSZXF1aXJlZCBUZXh0c1xuXFxgXFxgXFxgbWV0YS1iaW5kLWpzLXZpZXdcbnt0ZXh0c30gYXMgdGV4dHNcbi0tLVxuY29uc3QgYXZhaWxhYmxlVGV4dHMgPSBhcHAudmF1bHQuZ2V0RmlsZXMoKS5maWx0ZXIoZmlsZSA9PiBmaWxlLmV4dGVuc2lvbiA9PSAncGRmJykubWFwKGYgPT4gZj8ubmFtZSlcbmNvbnN0IGVzY2FwZVJlZ2V4ID0gL1ssXFxgJygpXS9nO1xub3B0aW9ucyA9IGF2YWlsYWJsZVRleHRzLm1hcCh0ID0+IFxcYG9wdGlvbihbW1xcJHt0LnJlcGxhY2UoZXNjYXBlUmVnZXgsXFwkMSl9XV0sIFxcJHt0LnJlcGxhY2UoZXNjYXBlUmVnZXgsXFwkMSl9KVxcYCApXG5jb25zdCBzdHIgPSBcXFxcXFxgSU5QVVRbaW5saW5lTGlzdFN1Z2dlc3RlcihcXCR7b3B0aW9ucy5qb2luKFwiLCBcIil9KTp0ZXh0c11cXFxcXFxgXG5yZXR1cm4gZW5naW5lLm1hcmtkb3duLmNyZWF0ZShzdHIpXG5cXGBcXGBcXGBcblxuIyMgQ291cnNlIFNjaGVkdWxlXG5cXGBJTlBVVFttdWx0aWxpbmUoMjB4NTApKGNvdXJzZV9zY2hlZHVsZSldXFxgXG5cbiMjIEFzc2lnbm1lbnRzXG5cXGBJTlBVVFttdWx0aWxpbmUoMTV4NTApKGFzc2lnbm1lbnRzKV1cXGBcblxuIyMgUmVzb3VyY2VzXG5cXGBJTlBVVFttdWx0aWxpbmUoMTB4NTApKHJlc291cmNlcyldXFxgXG5cbiMjIFZvY2FidWxhcnlcblxcYFxcYFxcYGRhdGF2aWV3anNcbmNvbnN0IHtwcm9jZXNzQ291cnNlVm9jYWJ1bGFyeX0gPSByZXF1aXJlKFwiL1N1cHBvcnRpbmcvZGF0YXZpZXctZnVuY3Rpb25zXCIpO1xucHJvY2Vzc0NvdXJzZVZvY2FidWxhcnkoZHYsICc8JSBjb3Vyc2VJZCAlPicpO1xuXFxgXFxgXFxgXG5cbiMjIER1ZSBEYXRlc1xuXFxgXFxgXFxgZGF0YXZpZXdqc1xuZnVuY3Rpb24gcHJvY2Vzc0R1ZURhdGVzKGR2LCB0YWcpIHtcbiAgLy8gRmluZCBhbGwgcGFnZXMgd2l0aCB0aGUgc3BlY2lmaWVkIHRhZ1xuICBjb25zdCBwYWdlcyA9IGR2LnBhZ2VzKHRhZykuZmlsZTtcblxuICAvLyBBcnJheSB0byBzdG9yZSBhbGwgcm93c1xuICBjb25zdCBhbGxSb3dzID0gW107XG5cbiAgLy8gRm9yIGVhY2ggcGFnZSwgZXh0cmFjdCB0aGUgXCJEdWUgRGF0ZXNcIiBzZWN0aW9uXG4gIGZvciAoY29uc3QgcGFnZSBvZiBwYWdlcy52YWx1ZXMoKSkge1xuICAgIGNvbnN0IGNvbnRlbnQgPSBhcHAudmF1bHQuY2FjaGVkUmVhZChhcHAudmF1bHQuZ2V0QWJzdHJhY3RGaWxlQnlQYXRoKHBhZ2UucGF0aCkpO1xuICAgIGNvbnN0IHJlZ2V4ID0gLyMgRHVlIERhdGVzXFxcXHMqXG4oKD86LnxcbikqPykoPz1cbiN8XFxcXFxcJCkvO1xuICAgIGNvbnN0IG1hdGNoID0gY29udGVudC5tYXRjaChyZWdleCk7XG4gICAgXG4gICAgaWYgKG1hdGNoICYmIG1hdGNoWzFdKSB7XG4gICAgICBjb25zdCB0YWJsZUNvbnRlbnQgPSBtYXRjaFsxXTtcbiAgICAgIC8vIFNwbGl0IGNvbnRlbnQgaW50byBsaW5lcyBhbmQgcHJvY2VzcyB0YWJsZSByb3dzXG4gICAgICBjb25zdCBsaW5lcyA9IHRhYmxlQ29udGVudC5zcGxpdCgnXG4nKTtcbiAgICAgIFxuICAgICAgZm9yIChjb25zdCBsaW5lIG9mIGxpbmVzKSB7XG4gICAgICAgIC8vIENoZWNrIGlmIHRoZSBsaW5lIGxvb2tzIGxpa2UgYSB0YWJsZSByb3cgKGNvbnRhaW5zIHwgY2hhcmFjdGVycylcbiAgICAgICAgaWYgKGxpbmUuaW5jbHVkZXMoJ3wnKSkge1xuICAgICAgICAgIGNvbnN0IGNvbHVtbnMgPSBsaW5lLnNwbGl0KCd8JykubWFwKGNvbCA9PiBjb2wudHJpbSgpKS5maWx0ZXIoY29sID0+IGNvbCAhPT0gJycpO1xuICAgICAgICAgIFxuICAgICAgICAgIGlmIChjb2x1bW5zLmxlbmd0aCA+PSAyKSB7IC8vIEVuc3VyZSB0aGVyZSBhcmUgYXQgbGVhc3QgMiBjb2x1bW5zIChkdWUgZGF0ZSwgdGFzaylcbiAgICAgICAgICAgIC8vIFBhcnNlIHRoZSBkYXRlIHRvIGNoZWNrIGlmIGl0J3MgdmFsaWRcbiAgICAgICAgICAgIGNvbnN0IGR1ZURhdGUgPSBjb2x1bW5zWzBdO1xuICAgICAgICAgICAgaWYgKCFEYXRlLnBhcnNlKGR1ZURhdGUpKSBjb250aW51ZTsgLy8gU2tpcCBpZiBub3QgYSB2YWxpZCBkYXRlXG4gICAgICAgICAgICBcbiAgICAgICAgICAgIC8vIEFkZCB0aGUgcm93IGRhdGEgdG8gdGhlIGNvbGxlY3Rpb25cbiAgICAgICAgICAgIGFsbFJvd3MucHVzaChbY29sdW1uc1swXSwgY29sdW1uc1sxXSwgXFxgW1tcXCR7cGFnZS5wYXRofXxcXCR7cGFnZS5uYW1lfV1dXFxgXSk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgLy8gRnVuY3Rpb24gdG8gcmVtb3ZlIGR1cGxpY2F0ZSByb3dzIGJhc2VkIG9uIHRoZSBmaXJzdCB0d28gY29sdW1uc1xuICBjb25zdCBkZWR1cGxpY2F0ZUZpcnN0VHdvQ29sdW1ucyA9IChyb3dzKSA9PiB7XG4gICAgY29uc3Qgc2VlbiA9IG5ldyBTZXQoKTtcbiAgICByZXR1cm4gcm93cy5maWx0ZXIocm93ID0+IHtcbiAgICAgIGNvbnN0IGtleSA9IEpTT04uc3RyaW5naWZ5KFtyb3dbMF0sIHJvd1sxXV0pOyAvLyBDb21iaW5lIGZpcnN0IHR3byBjb2x1bW5zIGFzIGEga2V5XG4gICAgICBpZiAoc2Vlbi5oYXMoa2V5KSkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG4gICAgICBzZWVuLmFkZChrZXkpO1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfSk7XG4gIH07XG4gIFxuICAvLyBSZW1vdmUgZHVwbGljYXRlcyBiYXNlZCBvbiBmaXJzdCB0d28gY29sdW1uc1xuICBjb25zdCBhbGxVbmlxdWVSb3dzID0gZGVkdXBsaWNhdGVGaXJzdFR3b0NvbHVtbnMoYWxsUm93cyk7XG5cbiAgLy8gU29ydCByb3dzIGJ5IGRhdGUgKHBhcnNlIHRoZSBkYXRlIHN0cmluZyBmb3IgY29tcGFyaXNvbilcbiAgY29uc3Qgc29ydGVkUm93cyA9IGFsbFVuaXF1ZVJvd3Muc29ydCgoYSwgYikgPT4gbmV3IERhdGUoYVswXSkgLSBuZXcgRGF0ZShiWzBdKSk7XG5cbiAgLy8gQ3JlYXRlIHRoZSB0YWJsZSB3aXRoIHRoZSBjb2xsZWN0ZWQgZGF0YVxuICBjb25zdCB0YWJsZSA9IGR2Lm1hcmtkb3duVGFibGUoXG4gICAgW1wiRHVlIERhdGVcIiwgXCJUYXNrIERlc2NyaXB0aW9uXCIsIFwiRmlsZVwiXSwgXG4gICAgc29ydGVkUm93c1xuICApO1xuXG4gIHJldHVybiB0YWJsZTtcbn1cblxucHJvY2Vzc0R1ZURhdGVzKGR2LCcjPCUgY291cnNlSWQgJT4nKTtcblxcYFxcYFxcYFxuXG4jIyBDbGFzcyBNYXRlcmlhbHNcblxcYElOUFVUW211bHRpbGluZSgxMHg1MCkoY2xhc3NfbWF0ZXJpYWxzKV1cXGBcblxuIyMgQ2xhc3NtYXRlc1xuXFxgSU5QVVRbbXVsdGlsaW5lKDE1eDUwKShjbGFzc21hdGVzKV1cXGBgO1xuICAgIH0gZWxzZSB7XG4gICAgICByZXR1cm4gYC0tLVxuY291cnNlX2lkOiA8JSBjb3Vyc2VJZCAlPlxuY291cnNlX25hbWU6IDwlIGNvdXJzZU5hbWUgJT5cbmNvdXJzZV9zZWFzb246IDwlIGNvdXJzZVNlYXNvbiAlPlxuY291cnNlX3llYXI6IDwlIGNvdXJzZVllYXIgJT5cbmNyZWF0ZWQ6IDwlIHRwLmRhdGUubm93KFwiWVlZWS1NTS1ERFtUXUhIOm1tOnNzWlwiKSAlPlxudGFnczpcbiAgLSA8JSBjb3Vyc2VJZCAlPlxuICAtIGNvdXJzZV9ob21lXG4gIC0gZWR1Y2F0aW9uXG4tLS1cblxuPCUqXG4vLyBUdWNrZXJzIFRvb2xzIENvdXJzZSBDcmVhdGlvblxuLy8gRm9yIGJlc3QgZXhwZXJpZW5jZSwgdXNlIHRoZSBwbHVnaW4gY29tbWFuZDogQ29tbWFuZCBQYWxldHRlIFx1MjE5MiAnQ3JlYXRlIE5ldyBDb3Vyc2UnXG5cbmxldCBjb3Vyc2VOYW1lID0gXCJOZXcgQ291cnNlXCI7XG5sZXQgY291cnNlU2Vhc29uID0gXCJGYWxsXCI7IFxubGV0IGNvdXJzZVllYXIgPSBuZXcgRGF0ZSgpLmdldEZ1bGxZZWFyKCkudG9TdHJpbmcoKTtcbmxldCBjb3Vyc2VJZCA9IFwiQ09VUlNFX0lEXCI7XG5cbi8vIFRyeSB0byB1c2Ugc3lzdGVtIHByb21wdHMsIHdpdGggZ3JhY2VmdWwgZmFsbGJhY2tcbnRyeSB7XG4gIGlmICh0cCAmJiB0cC5zeXN0ZW0gJiYgdHAuc3lzdGVtLnByb21wdCkge1xuICAgIGNvdXJzZU5hbWUgPSBhd2FpdCB0cC5zeXN0ZW0ucHJvbXB0KFwiQ291cnNlIE5hbWUgKGUuZy4gU1dPLTI1MCAtIENvdXJzZSBUaXRsZSlcIikgfHwgY291cnNlTmFtZTtcbiAgICBjb3Vyc2VJZCA9IGNvdXJzZU5hbWUuc3BsaXQoJyAtICcpWzBdIHx8IGNvdXJzZU5hbWUucmVwbGFjZSgvW15hLXpBLVowLTldL2csIFwiX1wiKTtcbiAgICBjb3Vyc2VTZWFzb24gPSBhd2FpdCB0cC5zeXN0ZW0uc3VnZ2VzdGVyKFtcIkZhbGxcIixcIldpbnRlclwiLFwiU3ByaW5nXCIsXCJTdW1tZXJcIl0sW1wiRmFsbFwiLFwiV2ludGVyXCIsXCJTcHJpbmdcIixcIlN1bW1lclwiXSwgXCJTZWFzb25cIikgfHwgY291cnNlU2Vhc29uO1xuICAgIGNvdXJzZVllYXIgPSBhd2FpdCB0cC5zeXN0ZW0ucHJvbXB0KFwiWWVhclwiKSB8fCBjb3Vyc2VZZWFyO1xuICB9IGVsc2Uge1xuICAgIGNvbnNvbGUubG9nKFwiU3lzdGVtIHByb21wdHMgbm90IGF2YWlsYWJsZSwgdXNlIHRoZSBwbHVnaW4gY29tbWFuZCBpbnN0ZWFkXCIpO1xuICB9XG59IGNhdGNoIChlKSB7XG4gIGNvbnNvbGUuZXJyb3IoXCJFcnJvciB3aXRoIHN5c3RlbSBwcm9tcHRzOlwiLCBlLm1lc3NhZ2UpO1xuICBjb25zb2xlLmxvZyhcIlVzZSB0aGUgcGx1Z2luIGNvbW1hbmQ6IENvbW1hbmQgUGFsZXR0ZSBcdTIxOTIgJ0NyZWF0ZSBOZXcgQ291cnNlJ1wiKTtcbn1cblxuLy8gTW92ZSBmaWxlIHRvIGFwcHJvcHJpYXRlIGxvY2F0aW9uXG5hd2FpdCB0cC5maWxlLm1vdmUoXFxgL1xcJHtjb3Vyc2VZZWFyfS9cXCR7Y291cnNlU2Vhc29ufS9cXCR7Y291cnNlTmFtZX0vXFwke2NvdXJzZU5hbWV9XFxgKTtcblxuLy8gQ3JlYXRlIGF0dGFjaG1lbnRzIGZvbGRlclxudHJ5IHtcbiAgYXdhaXQgYXBwLnZhdWx0LmNyZWF0ZUZvbGRlcihcXGAvXFwke2NvdXJzZVllYXJ9L1xcJHtjb3Vyc2VTZWFzb259L1xcJHtjb3Vyc2VOYW1lfS9BdHRhY2htZW50c1xcYCk7XG59IGNhdGNoIChlKSB7XG4gIC8vIEZvbGRlciBtaWdodCBhbHJlYWR5IGV4aXN0XG59XG4lPlxuXG4jIDwlIGNvdXJzZU5hbWUgJT5cblxuIyMgQ291cnNlIEluZm9ybWF0aW9uXG4qKkNvdXJzZSBJRCoqOiA8JSBjb3Vyc2VJZCAlPlxuKipUZXJtKio6IDwlIGNvdXJzZVNlYXNvbiAlPiA8JSBjb3Vyc2VZZWFyICU+XG4qKlNjaG9vbCoqOiAke3RoaXMuc2V0dGluZ3Muc2Nob29sTmFtZX1cblxuIyMgSW5zdHJ1Y3RvclxuKipOYW1lKio6IFxcYElOUFVUW3RleHQoaW5zdHJ1Y3Rvcl9uYW1lKV1cXGBcbioqRW1haWwqKjogXFxgSU5QVVRbdGV4dChpbnN0cnVjdG9yX2VtYWlsKV1cXGBcbioqT2ZmaWNlIEhvdXJzKio6IFxcYElOUFVUW3RleHQoaW5zdHJ1Y3Rvcl9vZmZpY2VfaG91cnMpXVxcYFxuKipPZmZpY2UgTG9jYXRpb24qKjogXFxgSU5QVVRbdGV4dChpbnN0cnVjdG9yX29mZmljZV9sb2NhdGlvbildXFxgXG5cbiMjIENvdXJzZSBEZXNjcmlwdGlvblxuXFxgSU5QVVRbbXVsdGlsaW5lKDEweDUwKShjb3Vyc2VfZGVzY3JpcHRpb24pXVxcYFxuXG4jIyBMZWFybmluZyBPYmplY3RpdmVzXG5cXGBJTlBVVFttdWx0aWxpbmUoMTB4NTApKGxlYXJuaW5nX29iamVjdGl2ZXMpXVxcYFxuXG4jIyBSZXF1aXJlZCBUZXh0c1xuXFxgXFxgXFxgbWV0YS1iaW5kLWpzLXZpZXdcbnt0ZXh0c30gYXMgdGV4dHNcbi0tLVxuY29uc3QgYXZhaWxhYmxlVGV4dHMgPSBhcHAudmF1bHQuZ2V0RmlsZXMoKS5maWx0ZXIoZmlsZSA9PiBmaWxlLmV4dGVuc2lvbiA9PSAncGRmJykubWFwKGYgPT4gZj8ubmFtZSlcbmNvbnN0IGVzY2FwZVJlZ2V4ID0gL1ssXFxgJygpXS9nO1xub3B0aW9ucyA9IGF2YWlsYWJsZVRleHRzLm1hcCh0ID0+IFxcYG9wdGlvbihbW1xcJHt0LnJlcGxhY2UoZXNjYXBlUmVnZXgsXFwkMSl9XV0sIFxcJHt0LnJlcGxhY2UoZXNjYXBlUmVnZXgsXFwkMSl9KVxcYCApXG5jb25zdCBzdHIgPSBcXFxcXFxgSU5QVVRbaW5saW5lTGlzdFN1Z2dlc3RlcihcXCR7b3B0aW9ucy5qb2luKFwiLCBcIil9KTp0ZXh0c11cXFxcXFxgXG5yZXR1cm4gZW5naW5lLm1hcmtkb3duLmNyZWF0ZShzdHIpXG5cXGBcXGBcXGBcblxuIyMgU2NoZWR1bGVcblxcYElOUFVUW211bHRpbGluZSgxNXg1MCkoY291cnNlX3NjaGVkdWxlKV1cXGBcblxuIyMgQXNzaWdubWVudHNcblxcYElOUFVUW211bHRpbGluZSgxMHg1MCkoYXNzaWdubWVudHMpXVxcYFxuXG4jIyBSZXNvdXJjZXNcblxcYElOUFVUW211bHRpbGluZSgxMHg1MCkocmVzb3VyY2VzKV1cXGBcblxuIyMgVm9jYWJ1bGFyeVxuXFxgXFxgXFxgZGF0YXZpZXdqc1xuY29uc3Qge3Byb2Nlc3NDb3Vyc2VWb2NhYnVsYXJ5fSA9IHJlcXVpcmUoXCIvU3VwcG9ydGluZy9kYXRhdmlldy1mdW5jdGlvbnNcIik7XG5wcm9jZXNzQ291cnNlVm9jYWJ1bGFyeShkdiwgJzwlIGNvdXJzZUlkICU+Jyk7XG5cXGBcXGBcXGBcblxuIyMgRHVlIERhdGVzXG5cXGBcXGBcXGBkYXRhdmlld2pzXG5mdW5jdGlvbiBwcm9jZXNzRHVlRGF0ZXMoZHYsIHRhZykge1xuICAvLyBGaW5kIGFsbCBwYWdlcyB3aXRoIHRoZSBzcGVjaWZpZWQgdGFnXG4gIGNvbnN0IHBhZ2VzID0gZHYucGFnZXModGFnKS5maWxlO1xuXG4gIC8vIEFycmF5IHRvIHN0b3JlIGFsbCByb3dzXG4gIGNvbnN0IGFsbFJvd3MgPSBbXTtcblxuICAvLyBGb3IgZWFjaCBwYWdlLCBleHRyYWN0IHRoZSBcIkR1ZSBEYXRlc1wiIHNlY3Rpb25cbiAgZm9yIChjb25zdCBwYWdlIG9mIHBhZ2VzLnZhbHVlcygpKSB7XG4gICAgY29uc3QgY29udGVudCA9IGFwcC52YXVsdC5jYWNoZWRSZWFkKGFwcC52YXVsdC5nZXRBYnN0cmFjdEZpbGVCeVBhdGgocGFnZS5wYXRoKSk7XG4gICAgY29uc3QgcmVnZXggPSAvIyBEdWUgRGF0ZXNcXFxccypcbigoPzoufFxuKSo/KSg/PVxuI3xcXFxcXFwkKS87XG4gICAgY29uc3QgbWF0Y2ggPSBjb250ZW50Lm1hdGNoKHJlZ2V4KTtcbiAgICBcbiAgICBpZiAobWF0Y2ggJiYgbWF0Y2hbMV0pIHtcbiAgICAgIGNvbnN0IHRhYmxlQ29udGVudCA9IG1hdGNoWzFdO1xuICAgICAgLy8gU3BsaXQgY29udGVudCBpbnRvIGxpbmVzIGFuZCBwcm9jZXNzIHRhYmxlIHJvd3NcbiAgICAgIGNvbnN0IGxpbmVzID0gdGFibGVDb250ZW50LnNwbGl0KCdcbicpO1xuICAgICAgXG4gICAgICBmb3IgKGNvbnN0IGxpbmUgb2YgbGluZXMpIHtcbiAgICAgICAgLy8gQ2hlY2sgaWYgdGhlIGxpbmUgbG9va3MgbGlrZSBhIHRhYmxlIHJvdyAoY29udGFpbnMgfCBjaGFyYWN0ZXJzKVxuICAgICAgICBpZiAobGluZS5pbmNsdWRlcygnfCcpKSB7XG4gICAgICAgICAgY29uc3QgY29sdW1ucyA9IGxpbmUuc3BsaXQoJ3wnKS5tYXAoY29sID0+IGNvbC50cmltKCkpLmZpbHRlcihjb2wgPT4gY29sICE9PSAnJyk7XG4gICAgICAgICAgXG4gICAgICAgICAgaWYgKGNvbHVtbnMubGVuZ3RoID49IDIpIHsgLy8gRW5zdXJlIHRoZXJlIGFyZSBhdCBsZWFzdCAyIGNvbHVtbnMgKGR1ZSBkYXRlLCB0YXNrKVxuICAgICAgICAgICAgLy8gUGFyc2UgdGhlIGRhdGUgdG8gY2hlY2sgaWYgaXQncyB2YWxpZFxuICAgICAgICAgICAgY29uc3QgZHVlRGF0ZSA9IGNvbHVtbnNbMF07XG4gICAgICAgICAgICBpZiAoIURhdGUucGFyc2UoZHVlRGF0ZSkpIGNvbnRpbnVlOyAvLyBTa2lwIGlmIG5vdCBhIHZhbGlkIGRhdGVcbiAgICAgICAgICAgIFxuICAgICAgICAgICAgLy8gQWRkIHRoZSByb3cgZGF0YSB0byB0aGUgY29sbGVjdGlvblxuICAgICAgICAgICAgYWxsUm93cy5wdXNoKFtjb2x1bW5zWzBdLCBjb2x1bW5zWzFdLCBcXGBbW1xcJHtwYWdlLnBhdGh9fFxcJHtwYWdlLm5hbWV9XV1cXGBdKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICAvLyBGdW5jdGlvbiB0byByZW1vdmUgZHVwbGljYXRlIHJvd3MgYmFzZWQgb24gdGhlIGZpcnN0IHR3byBjb2x1bW5zXG4gIGNvbnN0IGRlZHVwbGljYXRlRmlyc3RUd29Db2x1bW5zID0gKHJvd3MpID0+IHtcbiAgICBjb25zdCBzZWVuID0gbmV3IFNldCgpO1xuICAgIHJldHVybiByb3dzLmZpbHRlcihyb3cgPT4ge1xuICAgICAgY29uc3Qga2V5ID0gSlNPTi5zdHJpbmdpZnkoW3Jvd1swXSwgcm93WzFdXSk7IC8vIENvbWJpbmUgZmlyc3QgdHdvIGNvbHVtbnMgYXMgYSBrZXlcbiAgICAgIGlmIChzZWVuLmhhcyhrZXkpKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH1cbiAgICAgIHNlZW4uYWRkKGtleSk7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9KTtcbiAgfTtcbiAgXG4gIC8vIFJlbW92ZSBkdXBsaWNhdGVzIGJhc2VkIG9uIGZpcnN0IHR3byBjb2x1bW5zXG4gIGNvbnN0IGFsbFVuaXF1ZVJvd3MgPSBkZWR1cGxpY2F0ZUZpcnN0VHdvQ29sdW1ucyhhbGxSb3dzKTtcblxuICAvLyBTb3J0IHJvd3MgYnkgZGF0ZSAocGFyc2UgdGhlIGRhdGUgc3RyaW5nIGZvciBjb21wYXJpc29uKVxuICBjb25zdCBzb3J0ZWRSb3dzID0gYWxsVW5pcXVlUm93cy5zb3J0KChhLCBiKSA9PiBuZXcgRGF0ZShhWzBdKSAtIG5ldyBEYXRlKGJbMF0pKTtcblxuICAvLyBDcmVhdGUgdGhlIHRhYmxlIHdpdGggdGhlIGNvbGxlY3RlZCBkYXRhXG4gIGNvbnN0IHRhYmxlID0gZHYubWFya2Rvd25UYWJsZShcbiAgICBbXCJEdWUgRGF0ZVwiLCBcIlRhc2sgRGVzY3JpcHRpb25cIiwgXCJGaWxlXCJdLCBcbiAgICBzb3J0ZWRSb3dzXG4gICk7XG5cbiAgcmV0dXJuIHRhYmxlO1xufVxuXG5wcm9jZXNzRHVlRGF0ZXMoZHYsJyM8JSBjb3Vyc2VJZCAlPicpO1xuXFxgXFxgXFxgYDtcbiAgICB9XG4gIH1cblxuICBnZW5lcmF0ZUNvdXJzZUluZGV4VGVtcGxhdGUoKTogc3RyaW5nIHtcbiAgICByZXR1cm4gYC0tLVxuY29udGVudF90eXBlOiBjb3Vyc2VfaW5kZXhcbnRhZ3M6XG4gIC0gaW5kZXhcbi0tLVxuXG4jIENvdXJzZSBJbmRleFxuXG4jIyBNb2R1bGVzXG5cbiMjIENoYXB0ZXJzXG5cbiMjIEFzc2lnbm1lbnRzXG5cbiMjIFJlc291cmNlc1xuXG4jIyBWb2NhYnVsYXJ5XG5cbiMjIER1ZSBEYXRlc2BcbiAgfVxuXG4gIGdlbmVyYXRlTW9kdWxlVGVtcGxhdGUoKTogc3RyaW5nIHtcbiAgICByZXR1cm4gYC0tLVxuJHtcbiAgdGhpcy5zZXR0aW5ncy51c2VFbmhhbmNlZE1ldGFkYXRhXG4gICAgPyBgY291cnNlX2lkOiA8JSBjb3Vyc2VJZCAlPlxubW9kdWxlX251bWJlcjogPCUgbW9kdWxlTnVtYmVyICU+XG53ZWVrX251bWJlcjogPCUgd2Vla051bWJlciAlPlxuY2xhc3NfZGF5OiA8JSBkYXlPZldlZWsgJT5cbmNvbnRlbnRfdHlwZTogbW9kdWxlXG5wYXJlbnRfY291cnNlOiBcIltbPCUgY291cnNlICU+XV1cImBcbiAgICA6IGBjb3Vyc2VfaWQ6IDwlIGNvdXJzZUlkICU+XG5tb2R1bGVfbnVtYmVyOiA8JSBtb2R1bGVOdW1iZXIgJT5cbndlZWtfbnVtYmVyOiA8JSB3ZWVrTnVtYmVyICU+XG5jbGFzc19kYXk6IDwlIGRheU9mV2VlayAlPmBcbn1cbmNyZWF0ZWQ6IDwlIHRwLmRhdGUubm93KFwiWVlZWS1NTS1ERFtUXUhIOm1tOnNzWlwiKSAlPlxudGFnczpcbiAgLSBlZHVjYXRpb25cbiAgLSA8JSBjb3Vyc2VJZCAlPlxuICAtIG1vZHVsZVxuLS0tXG5cbjwlKlxuY29uc3QgeyBzZWFzb24sIG1vZHVsZU51bWJlciwgd2Vla051bWJlciwgY291cnNlLCBjb3Vyc2VJZCwgZGlzY2lwbGluZSwgZGF5T2ZXZWVrIH0gPSBhd2FpdCB0cC51c2VyLm5ld19tb2R1bGUoYXBwLCB0cCwgXCIyMDI1XCIpO1xubGV0IHRpdGxlID0gY291cnNlSWRcbmlmIChtb2R1bGVOdW1iZXIgJiYgd2Vla051bWJlcikgeyB0aXRsZSA9IFxcYE1cXCR7bW9kdWxlTnVtYmVyfS9XXFwke3dlZWtOdW1iZXJ9XFxgfVxuZWxzZSBpZiAobW9kdWxlTnVtYmVyKSB7IHRpdGxlID0gXFxgTVxcJHttb2R1bGVOdW1iZXJ9XFxgIH0gXG5lbHNlIGlmICh3ZWVrTnVtYmVyKSB7IHRpdGxlID0gXFxgV1xcJHt3ZWVrTnVtYmVyfVxcYH1cbiU+XG5cbiMgW1s8JSBjb3Vyc2UgJT5dXSAtIDwlIHRpdGxlICU+IC0gPCUgZGF5T2ZXZWVrICU+XG5cbiMjIExlYXJuaW5nIE9iamVjdGl2ZXNcblxuIyMgUmVhZGluZyBBc3NpZ25tZW50XG5cbiMjIExlY3R1cmUgTm90ZXNcblxuIyMgRGlzY3Vzc2lvbiBRdWVzdGlvbnNcblxuIyMgQXNzaWdubWVudHNcbnwgRGF0ZSB8IEFzc2lnbm1lbnQgfCBTdGF0dXMgfFxufCAtLS0tIHwgLS0tLS0tLS0tLSB8IC0tLS0tLSB8XG58ICAgICAgfCAgICAgICAgICAgIHwgICAgICAgIHxcblxuIyMgVm9jYWJ1bGFyeVxuXG4jIyBBZGRpdGlvbmFsIFJlc291cmNlc2BcbiAgfVxuXG4gIGdlbmVyYXRlQ2hhcHRlclRlbXBsYXRlKCk6IHN0cmluZyB7XG4gICAgcmV0dXJuIGAtLS1cbiR7XG4gIHRoaXMuc2V0dGluZ3MudXNlRW5oYW5jZWRNZXRhZGF0YVxuICAgID8gYGNvdXJzZV9pZDogPCUgY291cnNlSWQgJT5cbmNoYXB0ZXJfbnVtYmVyOiA8JSBjaGFwdGVyTnVtYmVyICU+XG5jb250ZW50X3R5cGU6IGNoYXB0ZXJcbnBhcmVudF9jb3Vyc2U6IFwiW1s8JSBjb3Vyc2UgJT5dXVwiXG50ZXh0X3JlZmVyZW5jZTogXCJbWzwlIHRleHQgJT5dXVwiYFxuICAgIDogYGNvdXJzZV9pZDogPCUgY291cnNlSWQgJT5cbmNoYXB0ZXJfbnVtYmVyOiA8JSBjaGFwdGVyTnVtYmVyICU+YFxufVxuY3JlYXRlZDogPCUgdHAuZGF0ZS5ub3coXCJZWVlZLU1NLUREW1RdSEg6bW06c3NaXCIpICU+XG50YWdzOlxuICAtIGVkdWNhdGlvblxuICAtIDwlIGNvdXJzZUlkICU+XG4gIC0gY2hhcHRlclxuLS0tXG5cbjwlKlxuY29uc3QgeyBjaGFwdGVyTnVtYmVyLCBjb3Vyc2UsIGNvdXJzZUlkLCBkaXNjaXBsaW5lLCB0ZXh0fSA9IGF3YWl0IHRwLnVzZXIubmV3X2NoYXB0ZXIodHApO1xuJT5cblxuIyBbWzwlIHRleHQgJT5dXSAtIENoYXB0ZXIgPCUgY2hhcHRlck51bWJlciAlPlxuXG4jIyBTdW1tYXJ5XG5cbiMjIEtleSBDb25jZXB0c1xuXG4jIyBWb2NhYnVsYXJ5XG4tIFxuXG4jIyBOb3Rlc1xuXG4jIyBEaXNjdXNzaW9uIFF1ZXN0aW9uc1xuXG4jIyBGdXJ0aGVyIFJlYWRpbmdgXG4gIH1cblxuICBnZW5lcmF0ZUFzc2lnbm1lbnRUZW1wbGF0ZSgpOiBzdHJpbmcge1xuICAgIHJldHVybiBgLS0tXG4ke1xuICB0aGlzLnNldHRpbmdzLnVzZUVuaGFuY2VkTWV0YWRhdGFcbiAgICA/IGBjb3Vyc2VfaWQ6IDwlIGNvdXJzZUlkICU+XG5hc3NpZ25tZW50X3R5cGU6IDwlIGFzc2lnbm1lbnRUeXBlICU+XG5kdWVfZGF0ZTogPCUgZHVlRGF0ZSAlPlxucG9pbnRzOiA8JSBwb2ludHMgJT5cbmNvbnRlbnRfdHlwZTogYXNzaWdubWVudFxucGFyZW50X2NvdXJzZTogXCJbWzwlIGNvdXJzZSAlPl1dXCJgXG4gICAgOiBgY291cnNlX2lkOiA8JSBjb3Vyc2VJZCAlPlxuYXNzaWdubWVudF90eXBlOiA8JSBhc3NpZ25tZW50VHlwZSAlPlxuZHVlX2RhdGU6IDwlIGR1ZURhdGUgJT5gXG59XG5jcmVhdGVkOiA8JSB0cC5kYXRlLm5vdyhcIllZWVktTU0tRERbVF1ISDptbTpzc1pcIikgJT5cbnN0YXR1czogcGVuZGluZ1xudGFnczpcbiAgLSBlZHVjYXRpb25cbiAgLSA8JSBjb3Vyc2VJZCAlPlxuICAtIGFzc2lnbm1lbnRcbi0tLVxuXG4jIDwlIGFzc2lnbm1lbnROYW1lICU+IC0gPCUgY291cnNlSWQgJT5cblxuIyMgRGVzY3JpcHRpb25cblxuIyMgSW5zdHJ1Y3Rpb25zXG5cbiMjIER1ZSBEYXRlXG4qKkFzc2lnbmVkKio6IDwlIHRwLmRhdGUubm93KFwiWVlZWS1NTS1ERFwiKSAlPlxuKipEdWUqKjogPCUgZHVlRGF0ZSAlPlxuXG4jIyBTdWJtaXNzaW9uXG5cbiMjIEdyYWRpbmcgQ3JpdGVyaWFcblxuIyMgUmVzb3VyY2VzYFxuICB9XG5cbiAgZ2VuZXJhdGVEYWlseU5vdGVUZW1wbGF0ZSgpOiBzdHJpbmcge1xuICAgIHJldHVybiBgLS0tXG5jb250ZW50X3R5cGU6IGRhaWx5X25vdGVcbmRhdGU6IDwlIHRwLmRhdGUubm93KFwiWVlZWS1NTS1ERFwiKSAlPlxudGFnczpcbiAgLSBkYWlseVxuICAtIDwlIHRwLmRhdGUubm93KFwiWVlZWVwiKSAlPlxuICAtIDwlIHRwLmRhdGUubm93KFwiTU1cIikgJT5cbiAgLSA8JSB0cC5kYXRlLm5vdyhcIkREXCIpICU+XG4tLS1cblxuIyA8JSB0cC5kYXRlLm5vdyhcIllZWVktTU0tREQgLSBkZGRkXCIpICU+XG5cbjw8IFtbPCUgdHAuZGF0ZS55ZXN0ZXJkYXkoXCJZWVlZLU1NLUREXCIpICU+XV0gfCBbWzwlIHRwLmRhdGUudG9tb3Jyb3coXCJZWVlZLU1NLUREXCIpICU+XV0gPj5cblxuIyMgVG9kYXkncyBGb2N1c1xuXG4jIyBDb3Vyc2VzIFdvcmtlZCBPblxuLSBcblxuIyMgVGFza3MgQ29tcGxldGVkXG4tIFsgXSBcblxuIyMgVm9jYWJ1bGFyeSBSZXZpZXdlZFxuLSBcblxuIyMgQXNzaWdubWVudHMgRHVlXG4tIFxuXG4jIyBMZWFybmluZyBBY2hpZXZlbWVudHNcblxuIyMgQ2hhbGxlbmdlc1xuXG4jIyBUb21vcnJvdydzIFBsYW5cblxuIyMgUmVmbGVjdGlvbmBcbiAgfVxuXG4gIGdlbmVyYXRlVm9jYWJ1bGFyeVRlbXBsYXRlKCk6IHN0cmluZyB7XG4gICAgcmV0dXJuIGAjIyA8JSB0ZXJtICU+XG4qKlRlcm0qKjogPCUgdGVybSAlPlxuKipQYXJ0IG9mIFNwZWVjaCoqOiBcbioqRGVmaW5pdGlvbioqOiBcbioqQ29udGV4dCoqOiBcbioqRXhhbXBsZXMqKjogXG4qKlJlbGF0ZWQgVGVybXMqKjogXG4qKlNlZSBBbHNvKio6YFxuICB9XG5cbiAgZ2VuZXJhdGVEdWVEYXRlVGVtcGxhdGUoKTogc3RyaW5nIHtcbiAgICByZXR1cm4gYHwgPCUgZHVlRGF0ZSAlPiB8IDwlIGFzc2lnbm1lbnQgJT4gfCA8JSBzdGF0dXMgJT4gfGBcbiAgfVxuXG4gIGFzeW5jIGNyZWF0ZVJFQURNRShiYXNlUGF0aDogc3RyaW5nKSB7XG4gICAgY29uc3QgcmVhZG1lQ29udGVudCA9IGAjIFR1Y2tlcnMgVG9vbHMgVGVtcGxhdGVzXG5cblRoaXMgZGlyZWN0b3J5IGNvbnRhaW5zIHRlbXBsYXRlcyBmb3IgdGhlIFR1Y2tlcnMgVG9vbHMgT2JzaWRpYW4gcGx1Z2luLlxuXG4jIyBUZW1wbGF0ZSBDYXRlZ29yaWVzXG5cbi0gKipDb3Vyc2VzKio6IFRlbXBsYXRlcyBmb3IgY3JlYXRpbmcgYW5kIG9yZ2FuaXppbmcgY291cnNlc1xuLSAqKk1vZHVsZXMqKjogVGVtcGxhdGVzIGZvciBjb3Vyc2UgbW9kdWxlc1xuLSAqKkNoYXB0ZXJzKio6IFRlbXBsYXRlcyBmb3IgY2hhcHRlciBub3Rlc1xuLSAqKkFzc2lnbm1lbnRzKio6IFRlbXBsYXRlcyBmb3IgYXNzaWdubWVudHNcbi0gKipEYWlseSoqOiBUZW1wbGF0ZXMgZm9yIGRhaWx5IG5vdGVzXG4tICoqVXRpbGl0aWVzKio6IEhlbHBlciB0ZW1wbGF0ZXNcblxuIyMgVXNhZ2VcblxuVGhlc2UgdGVtcGxhdGVzIGFyZSBkZXNpZ25lZCB0byB3b3JrIHdpdGggdGhlIFR1Y2tlcnMgVG9vbHMgcGx1Z2luLiBUbyB1c2UgdGhlbTpcblxuMS4gSW5zdGFsbCB0aGUgVHVja2VycyBUb29scyBwbHVnaW5cbjIuIENvbmZpZ3VyZSB5b3VyIHNldHRpbmdzIGluIHRoZSBwbHVnaW4gc2V0dGluZ3MgdGFiXG4zLiBVc2UgdGhlIFwiSW5zZXJ0IFRlbXBsYXRlXCIgY29tbWFuZCB0byBhcHBseSB0aGVzZSB0ZW1wbGF0ZXMgdG8gbmV3IG5vdGVzXG5cbiMjIEN1c3RvbWl6YXRpb25cblxuRmVlbCBmcmVlIHRvIGN1c3RvbWl6ZSB0aGVzZSB0ZW1wbGF0ZXMgdG8gc3VpdCB5b3VyIG5lZWRzLiBUaGUgcGx1Z2luIHdpbGwgbm90IG92ZXJ3cml0ZSB5b3VyIGNoYW5nZXMgd2hlbiB1cGRhdGluZyB0ZW1wbGF0ZXMuYFxuXG4gICAgYXdhaXQgdGhpcy53cml0ZVRlbXBsYXRlRmlsZShgJHtiYXNlUGF0aH0vUkVBRE1FLm1kYCwgcmVhZG1lQ29udGVudClcbiAgfVxufVxuIiwgIi8vIENvdXJzZSBjcmVhdGlvbiB3aXphcmQgZm9yIFR1Y2tlcnMgVG9vbHMgcGx1Z2luXG5cbmltcG9ydCB7IEFwcCwgTm90aWNlLCBURmlsZSB9IGZyb20gXCJvYnNpZGlhblwiXG5pbXBvcnQgeyBUdWNrZXJzVG9vbHNTZXR0aW5ncyB9IGZyb20gXCIuL3NldHRpbmdzXCJcbmltcG9ydCB7IHNsdWdpZnkgfSBmcm9tIFwiLi91dGlsc1wiXG5pbXBvcnQgeyBJbnB1dE1vZGFsLCBTdWdnZXN0ZXJNb2RhbCB9IGZyb20gXCIuL2lucHV0TW9kYWxcIlxuXG5leHBvcnQgY2xhc3MgQ291cnNlQ3JlYXRpb25XaXphcmQge1xuICBhcHA6IEFwcFxuICBzZXR0aW5nczogVHVja2Vyc1Rvb2xzU2V0dGluZ3NcblxuICBjb25zdHJ1Y3RvcihhcHA6IEFwcCwgc2V0dGluZ3M6IFR1Y2tlcnNUb29sc1NldHRpbmdzKSB7XG4gICAgdGhpcy5hcHAgPSBhcHBcbiAgICB0aGlzLnNldHRpbmdzID0gc2V0dGluZ3NcbiAgfVxuXG4gIGFzeW5jIGNyZWF0ZUNvdXJzZUhvbWVwYWdlKCkge1xuICAgIHRyeSB7XG4gICAgICAvLyBQcm9tcHQgdXNlciBmb3IgY291cnNlIGRldGFpbHNcbiAgICAgIGNvbnN0IGNvdXJzZURldGFpbHMgPSBhd2FpdCB0aGlzLnByb21wdENvdXJzZURldGFpbHMoKVxuXG4gICAgICBpZiAoIWNvdXJzZURldGFpbHMpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlIC8vIFVzZXIgY2FuY2VsbGVkXG4gICAgICB9XG5cbiAgICAgIC8vIENyZWF0ZSBmb2xkZXIgc3RydWN0dXJlXG4gICAgICBjb25zdCBmb2xkZXJQYXRoID0gYXdhaXQgdGhpcy5jcmVhdGVDb3Vyc2VGb2xkZXJTdHJ1Y3R1cmUoY291cnNlRGV0YWlscylcblxuICAgICAgLy8gR2VuZXJhdGUgY291cnNlIGhvbWVwYWdlIG5vdGVcbiAgICAgIGF3YWl0IHRoaXMuY3JlYXRlQ291cnNlSG9tZXBhZ2VOb3RlKGNvdXJzZURldGFpbHMsIGZvbGRlclBhdGgpXG5cbiAgICAgIC8vIENyZWF0ZSBhdHRhY2htZW50cyBmb2xkZXJcbiAgICAgIGF3YWl0IHRoaXMuY3JlYXRlQXR0YWNobWVudHNGb2xkZXIoZm9sZGVyUGF0aClcblxuICAgICAgbmV3IE5vdGljZShgQ291cnNlIFwiJHtjb3Vyc2VEZXRhaWxzLmNvdXJzZU5hbWV9XCIgY3JlYXRlZCBzdWNjZXNzZnVsbHkhYClcbiAgICAgIGNvbnNvbGUubG9nKFxuICAgICAgICBgQ291cnNlIGNyZWF0ZWQ6ICR7Y291cnNlRGV0YWlscy5jb3Vyc2VOYW1lfSBhdCAke2ZvbGRlclBhdGh9YFxuICAgICAgKVxuXG4gICAgICByZXR1cm4gdHJ1ZVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgY3JlYXRpbmcgY291cnNlOlwiLCBlcnJvcilcbiAgICAgIG5ldyBOb3RpY2UoYEVycm9yIGNyZWF0aW5nIGNvdXJzZTogJHtlcnJvci5tZXNzYWdlfWApXG4gICAgICByZXR1cm4gZmFsc2VcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIHByb21wdENvdXJzZURldGFpbHMoKTogUHJvbWlzZTx7XG4gICAgY291cnNlTmFtZTogc3RyaW5nXG4gICAgY291cnNlU2Vhc29uOiBzdHJpbmdcbiAgICBjb3Vyc2VZZWFyOiBzdHJpbmdcbiAgICBjb3Vyc2VJZDogc3RyaW5nXG4gIH0gfCBudWxsPiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGNvdXJzZU5hbWUgPSBhd2FpdCB0aGlzLnByb21wdFdpdGhWYWxpZGF0aW9uKFxuICAgICAgICBcIkNvdXJzZSBOYW1lXCIsXG4gICAgICAgIFwiRW50ZXIgY291cnNlIG5hbWUgKGUuZy4sIFBTSS0xMDEgLSBJbnRybyB0byBQc3ljaG9sb2d5KVwiLFxuICAgICAgICAodmFsdWUpID0+IHZhbHVlLnRyaW0oKS5sZW5ndGggPiAwLFxuICAgICAgICBcIkNvdXJzZSBuYW1lIGlzIHJlcXVpcmVkXCJcbiAgICAgIClcblxuICAgICAgaWYgKCFjb3Vyc2VOYW1lKSByZXR1cm4gbnVsbFxuXG4gICAgICBjb25zdCBjb3Vyc2VTZWFzb24gPSBhd2FpdCB0aGlzLnByb21wdFdpdGhPcHRpb25zKFxuICAgICAgICBcIlNlYXNvblwiLFxuICAgICAgICBcIlNlbGVjdCBzZW1lc3Rlci9zZWFzb25cIixcbiAgICAgICAgW1wiRmFsbFwiLCBcIldpbnRlclwiLCBcIlNwcmluZ1wiLCBcIlN1bW1lclwiXVxuICAgICAgKVxuXG4gICAgICBpZiAoIWNvdXJzZVNlYXNvbikgcmV0dXJuIG51bGxcblxuICAgICAgY29uc3QgY291cnNlWWVhciA9IGF3YWl0IHRoaXMucHJvbXB0V2l0aFZhbGlkYXRpb24oXG4gICAgICAgIFwiWWVhclwiLFxuICAgICAgICBcIkVudGVyIGFjYWRlbWljIHllYXIgKGUuZy4sIDIwMjUpXCIsXG4gICAgICAgICh2YWx1ZSkgPT4gL15cXGR7NH0kLy50ZXN0KHZhbHVlLnRyaW0oKSksXG4gICAgICAgIFwiUGxlYXNlIGVudGVyIGEgdmFsaWQgNC1kaWdpdCB5ZWFyXCJcbiAgICAgIClcblxuICAgICAgaWYgKCFjb3Vyc2VZZWFyKSByZXR1cm4gbnVsbFxuXG4gICAgICBjb25zdCBjb3Vyc2VJZCA9IGNvdXJzZU5hbWUuc3BsaXQoXCIgLSBcIilbMF0/LnRyaW0oKSB8fCBzbHVnaWZ5KGNvdXJzZU5hbWUpXG5cbiAgICAgIHJldHVybiB7XG4gICAgICAgIGNvdXJzZU5hbWUsXG4gICAgICAgIGNvdXJzZVNlYXNvbixcbiAgICAgICAgY291cnNlWWVhcixcbiAgICAgICAgY291cnNlSWRcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHByb21wdGluZyBmb3IgY291cnNlIGRldGFpbHM6XCIsIGVycm9yKVxuICAgICAgcmV0dXJuIG51bGxcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIHByb21wdFdpdGhWYWxpZGF0aW9uKFxuICAgIHRpdGxlOiBzdHJpbmcsXG4gICAgbWVzc2FnZTogc3RyaW5nLFxuICAgIHZhbGlkYXRvcjogKHZhbHVlOiBzdHJpbmcpID0+IGJvb2xlYW4sXG4gICAgZXJyb3JNZXNzYWdlOiBzdHJpbmdcbiAgKTogUHJvbWlzZTxzdHJpbmcgfCBudWxsPiB7XG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG4gICAgICBjb25zdCBtb2RhbCA9IG5ldyBJbnB1dE1vZGFsKHRoaXMuYXBwLCAocmVzdWx0KSA9PiB7XG4gICAgICAgIGlmIChyZXN1bHQgPT09IG51bGwpIHtcbiAgICAgICAgICAvLyBVc2VyIGNhbmNlbGxlZFxuICAgICAgICAgIHJlc29sdmUobnVsbCk7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKCF2YWxpZGF0b3IocmVzdWx0KSkge1xuICAgICAgICAgIG5ldyBOb3RpY2UoZXJyb3JNZXNzYWdlKTtcbiAgICAgICAgICAvLyBSZWN1cnNpdmVseSBjYWxsIGFnYWluIGlmIHZhbGlkYXRpb24gZmFpbHNcbiAgICAgICAgICB0aGlzLnByb21wdFdpdGhWYWxpZGF0aW9uKHRpdGxlLCBtZXNzYWdlLCB2YWxpZGF0b3IsIGVycm9yTWVzc2FnZSlcbiAgICAgICAgICAgIC50aGVuKHJlc29sdmUpO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIHJlc29sdmUocmVzdWx0LnRyaW0oKSk7XG4gICAgICB9KTtcblxuICAgICAgLy8gU2V0IHRoZSB0aXRsZSBhbmQgbWVzc2FnZSBkaWZmZXJlbnRseSBzaW5jZSBvdXIgbW9kYWwgaXMgc2ltcGxlXG4gICAgICBtb2RhbC50aXRsZUVsLnNldFRleHQodGl0bGUpO1xuICAgICAgY29uc3QgbWVzc2FnZUVsID0gbW9kYWwuY29udGVudEVsLmNyZWF0ZURpdigpO1xuICAgICAgbWVzc2FnZUVsLnNldFRleHQobWVzc2FnZSk7XG5cbiAgICAgIG1vZGFsLm9wZW4oKTtcbiAgICB9KTtcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgcHJvbXB0V2l0aE9wdGlvbnMoXG4gICAgdGl0bGU6IHN0cmluZyxcbiAgICBtZXNzYWdlOiBzdHJpbmcsXG4gICAgb3B0aW9uczogc3RyaW5nW11cbiAgKTogUHJvbWlzZTxzdHJpbmcgfCBudWxsPiB7XG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG4gICAgICBjb25zdCBtb2RhbCA9IG5ldyBTdWdnZXN0ZXJNb2RhbCh0aGlzLmFwcCwgb3B0aW9ucywgKHJlc3VsdCkgPT4ge1xuICAgICAgICBpZiAocmVzdWx0ID09PSBudWxsKSB7XG4gICAgICAgICAgLy8gVXNlciBjYW5jZWxsZWRcbiAgICAgICAgICByZXNvbHZlKG51bGwpO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChvcHRpb25zLmluY2x1ZGVzKHJlc3VsdCkpIHtcbiAgICAgICAgICByZXNvbHZlKHJlc3VsdCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgbmV3IE5vdGljZShgUGxlYXNlIHNlbGVjdCBvbmUgb2Y6ICR7b3B0aW9ucy5qb2luKFwiLCBcIil9YCk7XG4gICAgICAgICAgLy8gUmVjdXJzaXZlbHkgY2FsbCBhZ2FpbiBpZiBjaG9pY2UgaXMgaW52YWxpZFxuICAgICAgICAgIHRoaXMucHJvbXB0V2l0aE9wdGlvbnModGl0bGUsIG1lc3NhZ2UsIG9wdGlvbnMpXG4gICAgICAgICAgICAudGhlbihyZXNvbHZlKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG5cbiAgICAgIC8vIFNldCB0aGUgdGl0bGVcbiAgICAgIG1vZGFsLnRpdGxlRWwuc2V0VGV4dCh0aXRsZSk7XG4gICAgICBjb25zdCBtZXNzYWdlRWwgPSBtb2RhbC5jb250ZW50RWwuY3JlYXRlRGl2KCk7XG4gICAgICBtZXNzYWdlRWwuc2V0VGV4dChtZXNzYWdlKTtcblxuICAgICAgbW9kYWwub3BlbigpO1xuICAgIH0pO1xuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBjcmVhdGVDb3Vyc2VGb2xkZXJTdHJ1Y3R1cmUoY291cnNlRGV0YWlsczoge1xuICAgIGNvdXJzZU5hbWU6IHN0cmluZ1xuICAgIGNvdXJzZVNlYXNvbjogc3RyaW5nXG4gICAgY291cnNlWWVhcjogc3RyaW5nXG4gICAgY291cnNlSWQ6IHN0cmluZ1xuICB9KTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgICBjb25zdCBmb2xkZXJQYXRoID0gYCR7Y291cnNlRGV0YWlscy5jb3Vyc2VZZWFyfS8ke2NvdXJzZURldGFpbHMuY291cnNlU2Vhc29ufS8ke2NvdXJzZURldGFpbHMuY291cnNlTmFtZX1gXG5cbiAgICB0cnkge1xuICAgICAgYXdhaXQgdGhpcy5hcHAudmF1bHQuY3JlYXRlRm9sZGVyKGZvbGRlclBhdGgpXG4gICAgICBjb25zb2xlLmxvZyhgQ3JlYXRlZCBjb3Vyc2UgZm9sZGVyOiAke2ZvbGRlclBhdGh9YClcbiAgICAgIHJldHVybiBmb2xkZXJQYXRoXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIC8vIEZvbGRlciBtaWdodCBhbHJlYWR5IGV4aXN0LCB3aGljaCBpcyBmaW5lIGZvciBub3dcbiAgICAgIGNvbnNvbGUubG9nKGBDb3Vyc2UgZm9sZGVyIGFscmVhZHkgZXhpc3RzIG9yIGNyZWF0ZWQ6ICR7Zm9sZGVyUGF0aH1gKVxuICAgICAgcmV0dXJuIGZvbGRlclBhdGhcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIGNyZWF0ZUNvdXJzZUhvbWVwYWdlTm90ZShcbiAgICBjb3Vyc2VEZXRhaWxzOiB7XG4gICAgICBjb3Vyc2VOYW1lOiBzdHJpbmdcbiAgICAgIGNvdXJzZVNlYXNvbjogc3RyaW5nXG4gICAgICBjb3Vyc2VZZWFyOiBzdHJpbmdcbiAgICAgIGNvdXJzZUlkOiBzdHJpbmdcbiAgICB9LFxuICAgIGZvbGRlclBhdGg6IHN0cmluZ1xuICApOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBjb25zdCBub3RlUGF0aCA9IGAke2ZvbGRlclBhdGh9LyR7Y291cnNlRGV0YWlscy5jb3Vyc2VOYW1lfS5tZGBcbiAgICBjb25zdCBjb250ZW50ID0gdGhpcy5nZW5lcmF0ZUNvdXJzZUhvbWVwYWdlQ29udGVudChjb3Vyc2VEZXRhaWxzKVxuXG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IHRoaXMuYXBwLnZhdWx0LmNyZWF0ZShub3RlUGF0aCwgY29udGVudClcbiAgICAgIGNvbnNvbGUubG9nKGBDcmVhdGVkIGNvdXJzZSBob21lcGFnZTogJHtub3RlUGF0aH1gKVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKGBFcnJvciBjcmVhdGluZyBjb3Vyc2UgaG9tZXBhZ2U6ICR7ZXJyb3J9YClcbiAgICAgIHRocm93IGVycm9yXG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBjcmVhdGVBdHRhY2htZW50c0ZvbGRlcihmb2xkZXJQYXRoOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBjb25zdCBhdHRhY2htZW50c1BhdGggPSBgJHtmb2xkZXJQYXRofS9BdHRhY2htZW50c2BcblxuICAgIHRyeSB7XG4gICAgICBhd2FpdCB0aGlzLmFwcC52YXVsdC5jcmVhdGVGb2xkZXIoYXR0YWNobWVudHNQYXRoKVxuICAgICAgY29uc29sZS5sb2coYENyZWF0ZWQgYXR0YWNobWVudHMgZm9sZGVyOiAke2F0dGFjaG1lbnRzUGF0aH1gKVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAvLyBGb2xkZXIgbWlnaHQgYWxyZWFkeSBleGlzdCwgd2hpY2ggaXMgZmluZVxuICAgICAgY29uc29sZS5sb2coYEF0dGFjaG1lbnRzIGZvbGRlciBhbHJlYWR5IGV4aXN0czogJHthdHRhY2htZW50c1BhdGh9YClcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGdlbmVyYXRlQ291cnNlSG9tZXBhZ2VDb250ZW50KGNvdXJzZURldGFpbHM6IHtcbiAgICBjb3Vyc2VOYW1lOiBzdHJpbmdcbiAgICBjb3Vyc2VTZWFzb246IHN0cmluZ1xuICAgIGNvdXJzZVllYXI6IHN0cmluZ1xuICAgIGNvdXJzZUlkOiBzdHJpbmdcbiAgfSk6IHN0cmluZyB7XG4gICAgY29uc3QgZW5oYW5jZWRNZXRhZGF0YSA9IHRoaXMuc2V0dGluZ3MudXNlRW5oYW5jZWRNZXRhZGF0YVxuXG4gICAgcmV0dXJuIGAtLS1cbiR7XG4gIGVuaGFuY2VkTWV0YWRhdGFcbiAgICA/IGBjb3Vyc2VfaWQ6ICR7Y291cnNlRGV0YWlscy5jb3Vyc2VJZH1cbmNvdXJzZV9uYW1lOiAke2NvdXJzZURldGFpbHMuY291cnNlTmFtZX1cbmNvdXJzZV90ZXJtOiAke2NvdXJzZURldGFpbHMuY291cnNlU2Vhc29ufSAke2NvdXJzZURldGFpbHMuY291cnNlWWVhcn1cbmNvdXJzZV95ZWFyOiAke2NvdXJzZURldGFpbHMuY291cnNlWWVhcn1cbmNvdXJzZV9zZW1lc3RlcjogJHtjb3Vyc2VEZXRhaWxzLmNvdXJzZVNlYXNvbn1cbmNvbnRlbnRfdHlwZTogY291cnNlX2hvbWVwYWdlXG5zY2hvb2w6ICR7dGhpcy5zZXR0aW5ncy5zY2hvb2xOYW1lfVxuc2Nob29sX2FiYnJldmlhdGlvbjogJHt0aGlzLnNldHRpbmdzLnNjaG9vbEFiYnJldmlhdGlvbn1gXG4gICAgOiBgY291cnNlX2lkOiAke2NvdXJzZURldGFpbHMuY291cnNlSWR9XG50aXRsZTogJHtjb3Vyc2VEZXRhaWxzLmNvdXJzZU5hbWV9YFxufVxuY3JlYXRlZDogJHtuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCl9XG50YWdzOlxuIC0gY291cnNlX2hvbWVcbiAtIGVkdWNhdGlvblxuIC0gJHtjb3Vyc2VEZXRhaWxzLmNvdXJzZUlkfVxuIC0gJHt0aGlzLnNldHRpbmdzLnNjaG9vbEFiYnJldmlhdGlvbn0vJHtjb3Vyc2VEZXRhaWxzLmNvdXJzZVllYXJ9LyR7XG4gICAgICBjb3Vyc2VEZXRhaWxzLmNvdXJzZVNlYXNvblxuICAgIH0vJHtjb3Vyc2VEZXRhaWxzLmNvdXJzZUlkfVxuLS0tXG5cblxuIyAke2NvdXJzZURldGFpbHMuY291cnNlTmFtZX1cblxuIyMgQ291cnNlIEluZm9ybWF0aW9uXG4qKkNvdXJzZSBJRCoqOiAke2NvdXJzZURldGFpbHMuY291cnNlSWR9XG4qKlRlcm0qKjogJHtjb3Vyc2VEZXRhaWxzLmNvdXJzZVNlYXNvbn0gJHtjb3Vyc2VEZXRhaWxzLmNvdXJzZVllYXJ9XG4qKlNjaG9vbCoqOiAke3RoaXMuc2V0dGluZ3Muc2Nob29sTmFtZX1cblxuIyMgSW5zdHJ1Y3RvclxuKipOYW1lKio6XG4qKkVtYWlsKio6XG4qKk9mZmljZSBIb3VycyoqOlxuXG4jIyBDb3Vyc2UgRGVzY3JpcHRpb25cblxuIyMgTGVhcm5pbmcgT2JqZWN0aXZlc1xuXG4jIyBSZXF1aXJlZCBUZXh0c1xuXG4jIyBTY2hlZHVsZVxuXG4jIyBBc3NpZ25tZW50c1xuXG4jIyBSZXNvdXJjZXNcblxuIyMgVm9jYWJ1bGFyeVxuXG4jIyBEdWUgRGF0ZXNgXG4gIH1cbn1cbiIsICJpbXBvcnQgeyBBcHAsIE1vZGFsLCBTZXR0aW5nIH0gZnJvbSBcIm9ic2lkaWFuXCI7XG5cbmV4cG9ydCBjbGFzcyBJbnB1dE1vZGFsIGV4dGVuZHMgTW9kYWwge1xuICByZXN1bHQ6IHN0cmluZyB8IG51bGw7XG4gIG9uU3VibWl0OiAocmVzdWx0OiBzdHJpbmcgfCBudWxsKSA9PiB2b2lkO1xuXG4gIGNvbnN0cnVjdG9yKGFwcDogQXBwLCBvblN1Ym1pdDogKHJlc3VsdDogc3RyaW5nIHwgbnVsbCkgPT4gdm9pZCkge1xuICAgIHN1cGVyKGFwcCk7XG4gICAgdGhpcy5vblN1Ym1pdCA9IG9uU3VibWl0O1xuICB9XG5cbiAgb25PcGVuKCkge1xuICAgIGNvbnN0IHsgY29udGVudEVsIH0gPSB0aGlzO1xuXG4gICAgY29udGVudEVsLmNyZWF0ZUVsKFwiaDJcIiwgeyB0ZXh0OiBcIkVudGVyIFZhbHVlXCIgfSk7XG5cbiAgICBuZXcgU2V0dGluZyhjb250ZW50RWwpXG4gICAgICAuc2V0TmFtZShcIlZhbHVlXCIpXG4gICAgICAuYWRkVGV4dCgodGV4dCkgPT4gXG4gICAgICAgIHRleHRcbiAgICAgICAgICAub25DaGFuZ2UoKHZhbHVlKSA9PiB7XG4gICAgICAgICAgICB0aGlzLnJlc3VsdCA9IHZhbHVlO1xuICAgICAgICAgIH0pXG4gICAgICAgICAgLmlucHV0RWwuZm9jdXMoKVxuICAgICAgKTtcblxuICAgIG5ldyBTZXR0aW5nKGNvbnRlbnRFbClcbiAgICAgIC5hZGRCdXR0b24oKGJ0bikgPT5cbiAgICAgICAgYnRuXG4gICAgICAgICAgLnNldEJ1dHRvblRleHQoXCJTdWJtaXRcIilcbiAgICAgICAgICAuc2V0Q3RhKClcbiAgICAgICAgICAub25DbGljaygoKSA9PiB7XG4gICAgICAgICAgICB0aGlzLmNsb3NlKCk7XG4gICAgICAgICAgICB0aGlzLm9uU3VibWl0KHRoaXMucmVzdWx0IHx8IFwiXCIpO1xuICAgICAgICAgIH0pXG4gICAgICApXG4gICAgICAuYWRkQnV0dG9uKChidG4pID0+XG4gICAgICAgIGJ0bi5zZXRCdXR0b25UZXh0KFwiQ2FuY2VsXCIpLm9uQ2xpY2soKCkgPT4ge1xuICAgICAgICAgIHRoaXMuY2xvc2UoKTtcbiAgICAgICAgICB0aGlzLm9uU3VibWl0KG51bGwpO1xuICAgICAgICB9KVxuICAgICAgKTtcbiAgfVxuXG4gIG9uQ2xvc2UoKSB7XG4gICAgY29uc3QgeyBjb250ZW50RWwgfSA9IHRoaXM7XG4gICAgY29udGVudEVsLmVtcHR5KCk7XG4gIH1cbn1cblxuZXhwb3J0IGNsYXNzIFN1Z2dlc3Rlck1vZGFsIGV4dGVuZHMgTW9kYWwge1xuICByZXN1bHQ6IHN0cmluZyB8IG51bGw7XG4gIG9uU3VibWl0OiAocmVzdWx0OiBzdHJpbmcgfCBudWxsKSA9PiB2b2lkO1xuXG4gIGNvbnN0cnVjdG9yKGFwcDogQXBwLCBvcHRpb25zOiBzdHJpbmdbXSwgb25TdWJtaXQ6IChyZXN1bHQ6IHN0cmluZyB8IG51bGwpID0+IHZvaWQpIHtcbiAgICBzdXBlcihhcHApO1xuICAgIHRoaXMub25TdWJtaXQgPSBvblN1Ym1pdDtcblxuICAgIC8vIENyZWF0ZSBhIGRyb3Bkb3duIHdpdGggdGhlIHByb3ZpZGVkIG9wdGlvbnNcbiAgICBjb25zdCBkcm9wZG93bk9wdGlvbnM6IHsgW2tleTogc3RyaW5nXTogc3RyaW5nIH0gPSB7fTtcbiAgICBvcHRpb25zLmZvckVhY2gob3B0aW9uID0+IHtcbiAgICAgIGRyb3Bkb3duT3B0aW9uc1tvcHRpb25dID0gb3B0aW9uO1xuICAgIH0pO1xuICAgIFxuICAgIHRoaXMuY3JlYXRlRHJvcGRvd24oZHJvcGRvd25PcHRpb25zKTtcbiAgfVxuXG4gIGNyZWF0ZURyb3Bkb3duKG9wdGlvbnM6IHsgW2tleTogc3RyaW5nXTogc3RyaW5nIH0pIHtcbiAgICBjb25zdCB7IGNvbnRlbnRFbCB9ID0gdGhpcztcblxuICAgIGNvbnRlbnRFbC5jcmVhdGVFbChcImgyXCIsIHsgdGV4dDogXCJTZWxlY3QgT3B0aW9uXCIgfSk7XG5cbiAgICBsZXQgc2VsZWN0ZWRWYWx1ZSA9IE9iamVjdC5rZXlzKG9wdGlvbnMpWzBdIHx8IG51bGw7IC8vIERlZmF1bHQgdG8gZmlyc3Qgb3B0aW9uIG9yIG51bGxcblxuICAgIGNvbnN0IGRyb3Bkb3duID0gY29udGVudEVsLmNyZWF0ZUVsKFwic2VsZWN0XCIpO1xuICAgIE9iamVjdC5lbnRyaWVzKG9wdGlvbnMpLmZvckVhY2goKFtrZXksIHZhbHVlXSkgPT4ge1xuICAgICAgY29uc3Qgb3B0aW9uID0gZHJvcGRvd24uY3JlYXRlRWwoXCJvcHRpb25cIiwge1xuICAgICAgICB2YWx1ZToga2V5LFxuICAgICAgICB0ZXh0OiB2YWx1ZVxuICAgICAgfSk7XG4gICAgICBpZiAoa2V5ID09PSBzZWxlY3RlZFZhbHVlKSB7XG4gICAgICAgIG9wdGlvbi5zZWxlY3RlZCA9IHRydWU7XG4gICAgICB9XG4gICAgfSk7XG5cbiAgICBkcm9wZG93bi5hZGRFdmVudExpc3RlbmVyKFwiY2hhbmdlXCIsIChldmVudCkgPT4ge1xuICAgICAgc2VsZWN0ZWRWYWx1ZSA9IChldmVudC50YXJnZXQgYXMgSFRNTFNlbGVjdEVsZW1lbnQpLnZhbHVlO1xuICAgICAgdGhpcy5yZXN1bHQgPSBzZWxlY3RlZFZhbHVlO1xuICAgIH0pO1xuXG4gICAgbmV3IFNldHRpbmcoY29udGVudEVsKVxuICAgICAgLmFkZEJ1dHRvbigoYnRuKSA9PlxuICAgICAgICBidG5cbiAgICAgICAgICAuc2V0QnV0dG9uVGV4dChcIlN1Ym1pdFwiKVxuICAgICAgICAgIC5zZXRDdGEoKVxuICAgICAgICAgIC5vbkNsaWNrKCgpID0+IHtcbiAgICAgICAgICAgIHRoaXMuY2xvc2UoKTtcbiAgICAgICAgICAgIHRoaXMub25TdWJtaXQoc2VsZWN0ZWRWYWx1ZSk7XG4gICAgICAgICAgfSlcbiAgICAgIClcbiAgICAgIC5hZGRCdXR0b24oKGJ0bikgPT5cbiAgICAgICAgYnRuLnNldEJ1dHRvblRleHQoXCJDYW5jZWxcIikub25DbGljaygoKSA9PiB7XG4gICAgICAgICAgdGhpcy5jbG9zZSgpO1xuICAgICAgICAgIHRoaXMub25TdWJtaXQobnVsbCk7XG4gICAgICAgIH0pXG4gICAgICApO1xuICB9XG5cbiAgb25PcGVuKCkge1xuICAgIC8vIFRoZSBkcm9wZG93biBpcyBhbHJlYWR5IGNyZWF0ZWQgaW4gY29uc3RydWN0b3JcbiAgfVxuXG4gIG9uQ2xvc2UoKSB7XG4gICAgY29uc3QgeyBjb250ZW50RWwgfSA9IHRoaXM7XG4gICAgY29udGVudEVsLmVtcHR5KCk7XG4gIH1cbn0iLCAiLy8gVm9jYWJ1bGFyeSBleHRyYWN0aW9uIGZvciBUdWNrZXJzIFRvb2xzIHBsdWdpblxuXG5pbXBvcnQgeyBBcHAsIFRGaWxlIH0gZnJvbSBcIm9ic2lkaWFuXCJcbmltcG9ydCB7IGdldENvdXJzZUlkRnJvbVBhdGggfSBmcm9tIFwiLi91dGlsc1wiXG5cbmV4cG9ydCBjbGFzcyBWb2NhYnVsYXJ5RXh0cmFjdG9yIHtcbiAgYXBwOiBBcHBcblxuICBjb25zdHJ1Y3RvcihhcHA6IEFwcCkge1xuICAgIHRoaXMuYXBwID0gYXBwXG4gIH1cblxuICBleHRyYWN0Vm9jYWJ1bGFyeUZyb21Ob3RlKGNvbnRlbnQ6IHN0cmluZyk6IHN0cmluZ1tdIHtcbiAgICAvLyBFeHRyYWN0IHZvY2FidWxhcnkgc2VjdGlvbiBmcm9tIG5vdGUgY29udGVudFxuICAgIGNvbnN0IHZvY2FiUmVnZXggPSAvXiMrIFZvY2FidWxhcnkuKlxcbigoPzouKj9cXG4pKj8pKD89XlxccyojXFxzfCQpL21cbiAgICBjb25zdCB2b2NhYk1hdGNoZXMgPSBjb250ZW50Py5tYXRjaCh2b2NhYlJlZ2V4KVxuXG4gICAgaWYgKHZvY2FiTWF0Y2hlcykge1xuICAgICAgY29uc3Qgdm9jYWJEYXRhID0gdm9jYWJNYXRjaGVzWzFdLnRyaW0oKVxuICAgICAgY29uc3QgY2xlYW5lZFZvY2FiID0gdm9jYWJEYXRhXG4gICAgICAgIC5yZXBsYWNlKC9cXFtcXFsuKj9cXF1cXF0vZywgXCJcIikgLy8gUmVtb3ZlIHdpa2lsaW5rc1xuICAgICAgICAucmVwbGFjZSgvXlxccyotXFxzKi9nbSwgXCJcIikgLy8gUmVtb3ZlIGJ1bGxldCBwb2ludHNcbiAgICAgICAgLnNwbGl0KFwiXFxuXCIpXG4gICAgICAgIC5tYXAoKHRlcm0pID0+IHRlcm0udHJpbSgpKVxuICAgICAgICAuZmlsdGVyKCh0ZXJtKSA9PiB0ZXJtLmxlbmd0aCA+IDApXG5cbiAgICAgIHJldHVybiBjbGVhbmVkVm9jYWJcbiAgICB9XG5cbiAgICByZXR1cm4gW11cbiAgfVxuXG4gIGFzeW5jIGV4dHJhY3RWb2NhYnVsYXJ5RnJvbUNvdXJzZShcbiAgICBjb3Vyc2VJZDogc3RyaW5nXG4gICk6IFByb21pc2U8UmVjb3JkPHN0cmluZywgc3RyaW5nW10+PiB7XG4gICAgY29uc29sZS5sb2coYEV4dHJhY3Rpbmcgdm9jYWJ1bGFyeSBmb3IgY291cnNlOiAke2NvdXJzZUlkfWApXG5cbiAgICB0cnkge1xuICAgICAgLy8gRmluZCBhbGwgbm90ZXMgcmVsYXRlZCB0byB0aGUgY291cnNlXG4gICAgICBjb25zdCBjb3Vyc2VOb3RlcyA9IGF3YWl0IHRoaXMuZmluZENvdXJzZU5vdGVzKGNvdXJzZUlkKVxuXG4gICAgICBpZiAoY291cnNlTm90ZXMubGVuZ3RoID09PSAwKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKGBObyBub3RlcyBmb3VuZCBmb3IgY291cnNlOiAke2NvdXJzZUlkfWApXG4gICAgICAgIHJldHVybiB7fVxuICAgICAgfVxuXG4gICAgICAvLyBFeHRyYWN0IHZvY2FidWxhcnkgZnJvbSBlYWNoIG5vdGVcbiAgICAgIGNvbnN0IHZvY2FidWxhcnlEYXRhOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT4gPSB7fVxuXG4gICAgICBmb3IgKGNvbnN0IG5vdGUgb2YgY291cnNlTm90ZXMpIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBjb25zdCBjb250ZW50ID0gYXdhaXQgdGhpcy5hcHAudmF1bHQucmVhZChub3RlKVxuICAgICAgICAgIGNvbnN0IHZvY2FidWxhcnkgPSB0aGlzLmV4dHJhY3RWb2NhYnVsYXJ5RnJvbU5vdGUoY29udGVudClcblxuICAgICAgICAgIGlmICh2b2NhYnVsYXJ5Lmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgIHZvY2FidWxhcnlEYXRhW25vdGUuYmFzZW5hbWVdID0gdm9jYWJ1bGFyeVxuICAgICAgICAgIH1cbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICBjb25zb2xlLmVycm9yKGBFcnJvciByZWFkaW5nIG5vdGUgJHtub3RlLnBhdGh9OmAsIGVycm9yKVxuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIGNvbnNvbGUubG9nKFxuICAgICAgICBgRXh0cmFjdGVkIHZvY2FidWxhcnkgZnJvbSAke1xuICAgICAgICAgIE9iamVjdC5rZXlzKHZvY2FidWxhcnlEYXRhKS5sZW5ndGhcbiAgICAgICAgfSBub3RlcyBmb3IgY291cnNlOiAke2NvdXJzZUlkfWBcbiAgICAgIClcbiAgICAgIHJldHVybiB2b2NhYnVsYXJ5RGF0YVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFxuICAgICAgICBgRXJyb3IgZXh0cmFjdGluZyB2b2NhYnVsYXJ5IGZvciBjb3Vyc2UgJHtjb3Vyc2VJZH06YCxcbiAgICAgICAgZXJyb3JcbiAgICAgIClcbiAgICAgIHJldHVybiB7fVxuICAgIH1cbiAgfVxuXG4gIGFzeW5jIGZpbmRDb3Vyc2VOb3Rlcyhjb3Vyc2VJZDogc3RyaW5nKTogUHJvbWlzZTxURmlsZVtdPiB7XG4gICAgY29uc3Qgbm90ZXM6IFRGaWxlW10gPSBbXVxuXG4gICAgLy8gR2V0IGFsbCBtYXJrZG93biBmaWxlcyBpbiB0aGUgdmF1bHRcbiAgICBjb25zdCBmaWxlcyA9IHRoaXMuYXBwLnZhdWx0LmdldE1hcmtkb3duRmlsZXMoKVxuXG4gICAgZm9yIChjb25zdCBmaWxlIG9mIGZpbGVzKSB7XG4gICAgICAvLyBDaGVjayBpZiB0aGUgZmlsZSBwYXRoIGNvbnRhaW5zIHRoZSBjb3Vyc2UgSURcbiAgICAgIGlmIChcbiAgICAgICAgZmlsZS5wYXRoLmluY2x1ZGVzKGNvdXJzZUlkKSB8fFxuICAgICAgICAoYXdhaXQgdGhpcy5ub3RlQmVsb25nc1RvQ291cnNlKGZpbGUsIGNvdXJzZUlkKSlcbiAgICAgICkge1xuICAgICAgICBub3Rlcy5wdXNoKGZpbGUpXG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIG5vdGVzXG4gIH1cblxuICBwcml2YXRlIGFzeW5jIG5vdGVCZWxvbmdzVG9Db3Vyc2UoXG4gICAgZmlsZTogVEZpbGUsXG4gICAgY291cnNlSWQ6IHN0cmluZ1xuICApOiBQcm9taXNlPGJvb2xlYW4+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgY29udGVudCA9IGF3YWl0IHRoaXMuYXBwLnZhdWx0LnJlYWQoZmlsZSlcbiAgICAgIGNvbnN0IGZyb250bWF0dGVyTWF0Y2ggPSBjb250ZW50Lm1hdGNoKC9eLS0tXFxuKFtcXHNcXFNdKj8pXFxuLS0tLylcblxuICAgICAgaWYgKGZyb250bWF0dGVyTWF0Y2gpIHtcbiAgICAgICAgY29uc3QgZnJvbnRtYXR0ZXIgPSBmcm9udG1hdHRlck1hdGNoWzFdXG4gICAgICAgIC8vIENoZWNrIGlmIGNvdXJzZV9pZCBpcyBpbiB0aGUgZnJvbnRtYXR0ZXJcbiAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICBmcm9udG1hdHRlci5pbmNsdWRlcyhgY291cnNlX2lkOiAke2NvdXJzZUlkfWApIHx8XG4gICAgICAgICAgZnJvbnRtYXR0ZXIuaW5jbHVkZXMoYGNvdXJzZV9pZDoke2NvdXJzZUlkfWApXG4gICAgICAgIClcbiAgICAgIH1cblxuICAgICAgcmV0dXJuIGZhbHNlXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXG4gICAgICAgIGBFcnJvciBjaGVja2luZyBpZiBub3RlICR7ZmlsZS5wYXRofSBiZWxvbmdzIHRvIGNvdXJzZSAke2NvdXJzZUlkfTpgLFxuICAgICAgICBlcnJvclxuICAgICAgKVxuICAgICAgcmV0dXJuIGZhbHNlXG4gICAgfVxuICB9XG5cbiAgYXN5bmMgZ2VuZXJhdGVWb2NhYnVsYXJ5SW5kZXgoXG4gICAgY291cnNlSWQ6IHN0cmluZyxcbiAgICB2b2NhYnVsYXJ5RGF0YTogUmVjb3JkPHN0cmluZywgc3RyaW5nW10+XG4gICk6IFByb21pc2U8c3RyaW5nPiB7XG4gICAgY29uc3QgYWxsVGVybXM6IHN0cmluZ1tdID0gW11cbiAgICBjb25zdCB0ZXJtU291cmNlczogUmVjb3JkPHN0cmluZywgc3RyaW5nW10+ID0ge31cblxuICAgIC8vIENvbGxlY3QgYWxsIHVuaXF1ZSB0ZXJtcyBhbmQgdGhlaXIgc291cmNlc1xuICAgIGZvciAoY29uc3QgW25vdGVOYW1lLCB0ZXJtc10gb2YgT2JqZWN0LmVudHJpZXModm9jYWJ1bGFyeURhdGEpKSB7XG4gICAgICBmb3IgKGNvbnN0IHRlcm0gb2YgdGVybXMpIHtcbiAgICAgICAgaWYgKCFhbGxUZXJtcy5pbmNsdWRlcyh0ZXJtKSkge1xuICAgICAgICAgIGFsbFRlcm1zLnB1c2godGVybSlcbiAgICAgICAgICB0ZXJtU291cmNlc1t0ZXJtXSA9IFtdXG4gICAgICAgIH1cbiAgICAgICAgdGVybVNvdXJjZXNbdGVybV0ucHVzaChub3RlTmFtZSlcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBTb3J0IHRlcm1zIGFscGhhYmV0aWNhbGx5XG4gICAgYWxsVGVybXMuc29ydCgpXG5cbiAgICAvLyBHZW5lcmF0ZSBtYXJrZG93biBjb250ZW50XG4gICAgbGV0IGNvbnRlbnQgPSBgIyBWb2NhYnVsYXJ5IEluZGV4IC0gJHtjb3Vyc2VJZH1cXG5cXG5gXG4gICAgY29udGVudCArPSBgVG90YWwgdW5pcXVlIHRlcm1zOiAke2FsbFRlcm1zLmxlbmd0aH1cXG5cXG5gXG5cbiAgICBmb3IgKGNvbnN0IHRlcm0gb2YgYWxsVGVybXMpIHtcbiAgICAgIGNvbnRlbnQgKz0gYCMjICR7dGVybX1cXG5gXG4gICAgICBjb250ZW50ICs9IGAqKlNvdXJjZXM6KiogJHt0ZXJtU291cmNlc1t0ZXJtXS5qb2luKFwiLCBcIil9XFxuXFxuYFxuICAgICAgY29udGVudCArPSBgKipEZWZpbml0aW9uOioqXFxuXFxuYFxuICAgICAgY29udGVudCArPSBgKipDb250ZXh0OioqXFxuXFxuYFxuICAgICAgY29udGVudCArPSBgKipFeGFtcGxlczoqKlxcblxcbmBcbiAgICAgIGNvbnRlbnQgKz0gYC0tLVxcblxcbmBcbiAgICB9XG5cbiAgICByZXR1cm4gY29udGVudFxuICB9XG5cbiAgYXN5bmMgY3JlYXRlVm9jYWJ1bGFyeUluZGV4RmlsZShjb3Vyc2VJZDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHZvY2FidWxhcnlEYXRhID0gYXdhaXQgdGhpcy5leHRyYWN0Vm9jYWJ1bGFyeUZyb21Db3Vyc2UoY291cnNlSWQpXG5cbiAgICAgIGlmIChPYmplY3Qua2V5cyh2b2NhYnVsYXJ5RGF0YSkubGVuZ3RoID09PSAwKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKGBObyB2b2NhYnVsYXJ5IGZvdW5kIGZvciBjb3Vyc2U6ICR7Y291cnNlSWR9YClcbiAgICAgICAgcmV0dXJuXG4gICAgICB9XG5cbiAgICAgIGNvbnN0IGluZGV4Q29udGVudCA9IGF3YWl0IHRoaXMuZ2VuZXJhdGVWb2NhYnVsYXJ5SW5kZXgoXG4gICAgICAgIGNvdXJzZUlkLFxuICAgICAgICB2b2NhYnVsYXJ5RGF0YVxuICAgICAgKVxuXG4gICAgICAvLyBDcmVhdGUgdGhlIGluZGV4IGZpbGVcbiAgICAgIGNvbnN0IGZpbGVOYW1lID0gYCR7Y291cnNlSWR9IC0gVm9jYWJ1bGFyeSBJbmRleC5tZGBcbiAgICAgIGNvbnN0IGZpbGVQYXRoID0gYENvdXJzZXMvJHtjb3Vyc2VJZH0vJHtmaWxlTmFtZX1gXG5cbiAgICAgIHRyeSB7XG4gICAgICAgIGF3YWl0IHRoaXMuYXBwLnZhdWx0LmNyZWF0ZShmaWxlUGF0aCwgaW5kZXhDb250ZW50KVxuICAgICAgICBjb25zb2xlLmxvZyhgQ3JlYXRlZCB2b2NhYnVsYXJ5IGluZGV4IGZpbGU6ICR7ZmlsZVBhdGh9YClcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIC8vIEZpbGUgbWlnaHQgYWxyZWFkeSBleGlzdCwgdHJ5IHRvIHVwZGF0ZSBpdFxuICAgICAgICBjb25zdCBleGlzdGluZ0ZpbGUgPSB0aGlzLmFwcC52YXVsdC5nZXRBYnN0cmFjdEZpbGVCeVBhdGgoZmlsZVBhdGgpXG4gICAgICAgIGlmIChleGlzdGluZ0ZpbGUgJiYgZXhpc3RpbmdGaWxlIGluc3RhbmNlb2YgVEZpbGUpIHtcbiAgICAgICAgICBhd2FpdCB0aGlzLmFwcC52YXVsdC5tb2RpZnkoZXhpc3RpbmdGaWxlLCBpbmRleENvbnRlbnQpXG4gICAgICAgICAgY29uc29sZS5sb2coYFVwZGF0ZWQgdm9jYWJ1bGFyeSBpbmRleCBmaWxlOiAke2ZpbGVQYXRofWApXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihcbiAgICAgICAgYEVycm9yIGNyZWF0aW5nIHZvY2FidWxhcnkgaW5kZXggZm9yIGNvdXJzZSAke2NvdXJzZUlkfTpgLFxuICAgICAgICBlcnJvclxuICAgICAgKVxuICAgICAgdGhyb3cgZXJyb3JcbiAgICB9XG4gIH1cbn1cbiIsICJpbXBvcnQgeyBBcHAsIFRGaWxlIH0gZnJvbSBcIm9ic2lkaWFuXCJcbmltcG9ydCB7IGlzQmV0d2VlbiB9IGZyb20gXCIuL3V0aWxzXCJcblxuZXhwb3J0IGNsYXNzIER1ZURhdGVzUGFyc2VyIHtcbiAgYXBwOiBBcHBcblxuICBjb25zdHJ1Y3RvcihhcHA6IEFwcCkge1xuICAgIHRoaXMuYXBwID0gYXBwXG4gIH1cblxuICBwYXJzZUR1ZURhdGVzRnJvbU5vdGUoXG4gICAgY29udGVudDogc3RyaW5nXG4gICk6IEFycmF5PHsgZGF0ZTogc3RyaW5nOyBhc3NpZ25tZW50OiBzdHJpbmc7IHN0YXR1czogc3RyaW5nIH0+IHtcbiAgICAvLyBFeHRyYWN0IGR1ZSBkYXRlcyBzZWN0aW9uIGZyb20gbm90ZSBjb250ZW50XG4gICAgY29uc3QgZHVlRGF0ZXNSZWdleCA9IC8jIER1ZSBEYXRlc1tcXHNcXFNdKj8oPz1cXG4jfCQpL1xuICAgIGNvbnN0IG1hdGNoZXMgPSBjb250ZW50Py5tYXRjaChkdWVEYXRlc1JlZ2V4KVxuXG4gICAgaWYgKCFtYXRjaGVzKSB7XG4gICAgICByZXR1cm4gW11cbiAgICB9XG5cbiAgICBjb25zdCBkdWVEYXRlc1NlY3Rpb24gPSBtYXRjaGVzWzBdXG4gICAgY29uc3QgZHVlRGF0ZXMgPSBbXVxuXG4gICAgLy8gTG9vayBmb3IgbWFya2Rvd24gdGFibGVzIGluIHRoZSBkdWUgZGF0ZXMgc2VjdGlvblxuICAgIGNvbnN0IHRhYmxlUmVnZXggPSAvXFx8W1xcc1xcU10qP1xcbi9nXG4gICAgY29uc3QgdGFibGVNYXRjaGVzID0gZHVlRGF0ZXNTZWN0aW9uLm1hdGNoKHRhYmxlUmVnZXgpXG5cbiAgICBpZiAodGFibGVNYXRjaGVzKSB7XG4gICAgICBmb3IgKGNvbnN0IHRhYmxlIG9mIHRhYmxlTWF0Y2hlcykge1xuICAgICAgICBjb25zdCByb3dzID0gdGFibGVcbiAgICAgICAgICAudHJpbSgpXG4gICAgICAgICAgLnNwbGl0KFwiXFxuXCIpXG4gICAgICAgICAgLmZpbHRlcigocm93KSA9PiByb3cuc3RhcnRzV2l0aChcInxcIikpXG4gICAgICAgIGNvbnN0IHBhcnNlZFJvd3MgPSB0aGlzLnBhcnNlVGFibGVSb3dzKHJvd3MpXG4gICAgICAgIGR1ZURhdGVzLnB1c2goLi4ucGFyc2VkUm93cylcbiAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gZHVlRGF0ZXNcbiAgfVxuXG4gIHByaXZhdGUgcGFyc2VUYWJsZVJvd3MoXG4gICAgcm93czogc3RyaW5nW11cbiAgKTogQXJyYXk8eyBkYXRlOiBzdHJpbmc7IGFzc2lnbm1lbnQ6IHN0cmluZzsgc3RhdHVzOiBzdHJpbmcgfT4ge1xuICAgIGlmIChyb3dzLmxlbmd0aCA8IDIpIHJldHVybiBbXSAvLyBOZWVkIGF0IGxlYXN0IGhlYWRlciArIDEgZGF0YSByb3dcblxuICAgIGNvbnN0IGR1ZURhdGVzID0gW11cblxuICAgIGZvciAobGV0IGkgPSAxOyBpIDwgcm93cy5sZW5ndGg7IGkrKykge1xuICAgICAgLy8gU2tpcCBoZWFkZXIgcm93XG4gICAgICBjb25zdCByb3cgPSByb3dzW2ldXG4gICAgICBjb25zdCBjb2x1bW5zID0gcm93XG4gICAgICAgIC5zcGxpdChcInxcIilcbiAgICAgICAgLm1hcCgoY29sKSA9PiBjb2wudHJpbSgpKVxuICAgICAgICAuZmlsdGVyKChjb2wpID0+IGNvbClcblxuICAgICAgaWYgKGNvbHVtbnMubGVuZ3RoID49IDIpIHtcbiAgICAgICAgY29uc3QgW2RhdGUsIGFzc2lnbm1lbnQsIHN0YXR1cyA9IFwicGVuZGluZ1wiXSA9IGNvbHVtbnNcbiAgICAgICAgaWYgKGRhdGUgJiYgYXNzaWdubWVudCAmJiB0aGlzLmlzVmFsaWREYXRlKGRhdGUpKSB7XG4gICAgICAgICAgZHVlRGF0ZXMucHVzaCh7IGRhdGUsIGFzc2lnbm1lbnQsIHN0YXR1cyB9KVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIGR1ZURhdGVzXG4gIH1cblxuICBwcml2YXRlIGlzVmFsaWREYXRlKGRhdGVTdHJpbmc6IHN0cmluZyk6IGJvb2xlYW4ge1xuICAgIGNvbnN0IGRhdGVSZWdleCA9IC9eXFxkezR9LVxcZHsyfS1cXGR7Mn0kL1xuICAgIHJldHVybiBkYXRlUmVnZXgudGVzdChkYXRlU3RyaW5nKSAmJiAhaXNOYU4oRGF0ZS5wYXJzZShkYXRlU3RyaW5nKSlcbiAgfVxuXG4gIGFzeW5jIHBhcnNlRHVlRGF0ZXNGcm9tQ291cnNlKFxuICAgIGNvdXJzZUlkOiBzdHJpbmcsXG4gICAgc3RhcnREYXRlPzogc3RyaW5nLFxuICAgIGVuZERhdGU/OiBzdHJpbmdcbiAgKTogUHJvbWlzZTxcbiAgICBBcnJheTx7IGRhdGU6IHN0cmluZzsgYXNzaWdubWVudDogc3RyaW5nOyBzdGF0dXM6IHN0cmluZzsgc291cmNlOiBzdHJpbmcgfT5cbiAgPiB7XG4gICAgY29uc29sZS5sb2coYFBhcnNpbmcgZHVlIGRhdGVzIGZvciBjb3Vyc2U6ICR7Y291cnNlSWR9YClcblxuICAgIHRyeSB7XG4gICAgICAvLyBGaW5kIGFsbCBub3RlcyByZWxhdGVkIHRvIHRoZSBjb3Vyc2VcbiAgICAgIGNvbnN0IGNvdXJzZU5vdGVzID0gYXdhaXQgdGhpcy5maW5kQ291cnNlTm90ZXMoY291cnNlSWQpXG5cbiAgICAgIGlmIChjb3Vyc2VOb3Rlcy5sZW5ndGggPT09IDApIHtcbiAgICAgICAgY29uc29sZS5sb2coYE5vIG5vdGVzIGZvdW5kIGZvciBjb3Vyc2U6ICR7Y291cnNlSWR9YClcbiAgICAgICAgcmV0dXJuIFtdXG4gICAgICB9XG5cbiAgICAgIC8vIFBhcnNlIGR1ZSBkYXRlcyBmcm9tIGVhY2ggbm90ZVxuICAgICAgY29uc3QgYWxsRHVlRGF0ZXM6IEFycmF5PHtcbiAgICAgICAgZGF0ZTogc3RyaW5nXG4gICAgICAgIGFzc2lnbm1lbnQ6IHN0cmluZ1xuICAgICAgICBzdGF0dXM6IHN0cmluZ1xuICAgICAgICBzb3VyY2U6IHN0cmluZ1xuICAgICAgfT4gPSBbXVxuXG4gICAgICBmb3IgKGNvbnN0IG5vdGUgb2YgY291cnNlTm90ZXMpIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBjb25zdCBjb250ZW50ID0gYXdhaXQgdGhpcy5hcHAudmF1bHQucmVhZChub3RlKVxuICAgICAgICAgIGNvbnN0IGR1ZURhdGVzID0gdGhpcy5wYXJzZUR1ZURhdGVzRnJvbU5vdGUoY29udGVudClcblxuICAgICAgICAgIC8vIEFkZCBzb3VyY2UgaW5mb3JtYXRpb25cbiAgICAgICAgICBjb25zdCBkdWVEYXRlc1dpdGhTb3VyY2UgPSBkdWVEYXRlcy5tYXAoKGR1ZURhdGUpID0+ICh7XG4gICAgICAgICAgICAuLi5kdWVEYXRlLFxuICAgICAgICAgICAgc291cmNlOiBub3RlLmJhc2VuYW1lXG4gICAgICAgICAgfSkpXG5cbiAgICAgICAgICBhbGxEdWVEYXRlcy5wdXNoKC4uLmR1ZURhdGVzV2l0aFNvdXJjZSlcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICBjb25zb2xlLmVycm9yKGBFcnJvciByZWFkaW5nIG5vdGUgJHtub3RlLnBhdGh9OmAsIGVycm9yKVxuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIC8vIEZpbHRlciBieSBkYXRlIHJhbmdlIGlmIHByb3ZpZGVkXG4gICAgICBsZXQgZmlsdGVyZWREdWVEYXRlcyA9IGFsbER1ZURhdGVzXG4gICAgICBpZiAoc3RhcnREYXRlIHx8IGVuZERhdGUpIHtcbiAgICAgICAgZmlsdGVyZWREdWVEYXRlcyA9IHRoaXMuZmlsdGVyQnlEYXRlUmFuZ2UoXG4gICAgICAgICAgYWxsRHVlRGF0ZXMsXG4gICAgICAgICAgc3RhcnREYXRlLFxuICAgICAgICAgIGVuZERhdGVcbiAgICAgICAgKVxuICAgICAgfVxuXG4gICAgICAvLyBTb3J0IGJ5IGRhdGVcbiAgICAgIGZpbHRlcmVkRHVlRGF0ZXMuc29ydChcbiAgICAgICAgKGEsIGIpID0+IG5ldyBEYXRlKGEuZGF0ZSkuZ2V0VGltZSgpIC0gbmV3IERhdGUoYi5kYXRlKS5nZXRUaW1lKClcbiAgICAgIClcblxuICAgICAgY29uc29sZS5sb2coXG4gICAgICAgIGBGb3VuZCAke2ZpbHRlcmVkRHVlRGF0ZXMubGVuZ3RofSBkdWUgZGF0ZXMgZm9yIGNvdXJzZTogJHtjb3Vyc2VJZH1gXG4gICAgICApXG4gICAgICByZXR1cm4gZmlsdGVyZWREdWVEYXRlc1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKGBFcnJvciBwYXJzaW5nIGR1ZSBkYXRlcyBmb3IgY291cnNlICR7Y291cnNlSWR9OmAsIGVycm9yKVxuICAgICAgcmV0dXJuIFtdXG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBmaW5kQ291cnNlTm90ZXMoY291cnNlSWQ6IHN0cmluZyk6IFByb21pc2U8VEZpbGVbXT4ge1xuICAgIGNvbnN0IG5vdGVzOiBURmlsZVtdID0gW11cblxuICAgIC8vIEdldCBhbGwgbWFya2Rvd24gZmlsZXMgaW4gdGhlIHZhdWx0XG4gICAgY29uc3QgZmlsZXMgPSB0aGlzLmFwcC52YXVsdC5nZXRNYXJrZG93bkZpbGVzKClcblxuICAgIGZvciAoY29uc3QgZmlsZSBvZiBmaWxlcykge1xuICAgICAgLy8gQ2hlY2sgaWYgdGhlIGZpbGUgcGF0aCBjb250YWlucyB0aGUgY291cnNlIElEIG9yIGJlbG9uZ3MgdG8gdGhlIGNvdXJzZVxuICAgICAgaWYgKFxuICAgICAgICBmaWxlLnBhdGguaW5jbHVkZXMoY291cnNlSWQpIHx8XG4gICAgICAgIChhd2FpdCB0aGlzLm5vdGVCZWxvbmdzVG9Db3Vyc2UoZmlsZSwgY291cnNlSWQpKVxuICAgICAgKSB7XG4gICAgICAgIG5vdGVzLnB1c2goZmlsZSlcbiAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gbm90ZXNcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgbm90ZUJlbG9uZ3NUb0NvdXJzZShcbiAgICBmaWxlOiBURmlsZSxcbiAgICBjb3Vyc2VJZDogc3RyaW5nXG4gICk6IFByb21pc2U8Ym9vbGVhbj4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBjb250ZW50ID0gYXdhaXQgdGhpcy5hcHAudmF1bHQucmVhZChmaWxlKVxuICAgICAgY29uc3QgZnJvbnRtYXR0ZXJNYXRjaCA9IGNvbnRlbnQubWF0Y2goL14tLS1cXG4oW1xcc1xcU10qPylcXG4tLS0vKVxuXG4gICAgICBpZiAoZnJvbnRtYXR0ZXJNYXRjaCkge1xuICAgICAgICBjb25zdCBmcm9udG1hdHRlciA9IGZyb250bWF0dGVyTWF0Y2hbMV1cbiAgICAgICAgLy8gQ2hlY2sgaWYgY291cnNlX2lkIGlzIGluIHRoZSBmcm9udG1hdHRlclxuICAgICAgICByZXR1cm4gKFxuICAgICAgICAgIGZyb250bWF0dGVyLmluY2x1ZGVzKGBjb3Vyc2VfaWQ6ICR7Y291cnNlSWR9YCkgfHxcbiAgICAgICAgICBmcm9udG1hdHRlci5pbmNsdWRlcyhgY291cnNlX2lkOiR7Y291cnNlSWR9YClcbiAgICAgICAgKVxuICAgICAgfVxuXG4gICAgICByZXR1cm4gZmFsc2VcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihcbiAgICAgICAgYEVycm9yIGNoZWNraW5nIGlmIG5vdGUgJHtmaWxlLnBhdGh9IGJlbG9uZ3MgdG8gY291cnNlICR7Y291cnNlSWR9OmAsXG4gICAgICAgIGVycm9yXG4gICAgICApXG4gICAgICByZXR1cm4gZmFsc2VcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGZpbHRlckJ5RGF0ZVJhbmdlKFxuICAgIGR1ZURhdGVzOiBBcnJheTx7XG4gICAgICBkYXRlOiBzdHJpbmdcbiAgICAgIGFzc2lnbm1lbnQ6IHN0cmluZ1xuICAgICAgc3RhdHVzOiBzdHJpbmdcbiAgICAgIHNvdXJjZTogc3RyaW5nXG4gICAgfT4sXG4gICAgc3RhcnREYXRlPzogc3RyaW5nLFxuICAgIGVuZERhdGU/OiBzdHJpbmdcbiAgKTogQXJyYXk8e1xuICAgIGRhdGU6IHN0cmluZ1xuICAgIGFzc2lnbm1lbnQ6IHN0cmluZ1xuICAgIHN0YXR1czogc3RyaW5nXG4gICAgc291cmNlOiBzdHJpbmdcbiAgfT4ge1xuICAgIHJldHVybiBkdWVEYXRlcy5maWx0ZXIoKGR1ZURhdGUpID0+IHtcbiAgICAgIGNvbnN0IGR1ZURhdGVUaW1lID0gbmV3IERhdGUoZHVlRGF0ZS5kYXRlKS5nZXRUaW1lKClcblxuICAgICAgaWYgKHN0YXJ0RGF0ZSAmJiBkdWVEYXRlVGltZSA8IG5ldyBEYXRlKHN0YXJ0RGF0ZSkuZ2V0VGltZSgpKSB7XG4gICAgICAgIHJldHVybiBmYWxzZVxuICAgICAgfVxuXG4gICAgICBpZiAoZW5kRGF0ZSAmJiBkdWVEYXRlVGltZSA+IG5ldyBEYXRlKGVuZERhdGUpLmdldFRpbWUoKSkge1xuICAgICAgICByZXR1cm4gZmFsc2VcbiAgICAgIH1cblxuICAgICAgcmV0dXJuIHRydWVcbiAgICB9KVxuICB9XG5cbiAgYXN5bmMgZ2VuZXJhdGVEdWVEYXRlc1N1bW1hcnkoXG4gICAgY291cnNlSWQ6IHN0cmluZyxcbiAgICBkdWVEYXRlczogQXJyYXk8e1xuICAgICAgZGF0ZTogc3RyaW5nXG4gICAgICBhc3NpZ25tZW50OiBzdHJpbmdcbiAgICAgIHN0YXR1czogc3RyaW5nXG4gICAgICBzb3VyY2U6IHN0cmluZ1xuICAgIH0+XG4gICk6IFByb21pc2U8c3RyaW5nPiB7XG4gICAgaWYgKGR1ZURhdGVzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgcmV0dXJuIGAjIER1ZSBEYXRlcyBTdW1tYXJ5IC0gJHtjb3Vyc2VJZH1cXG5cXG5ObyBkdWUgZGF0ZXMgZm91bmQuXFxuYFxuICAgIH1cblxuICAgIC8vIEdyb3VwIGJ5IHN0YXR1c1xuICAgIGNvbnN0IGJ5U3RhdHVzID0gZHVlRGF0ZXMucmVkdWNlKChhY2MsIGR1ZURhdGUpID0+IHtcbiAgICAgIGlmICghYWNjW2R1ZURhdGUuc3RhdHVzXSkge1xuICAgICAgICBhY2NbZHVlRGF0ZS5zdGF0dXNdID0gW11cbiAgICAgIH1cbiAgICAgIGFjY1tkdWVEYXRlLnN0YXR1c10ucHVzaChkdWVEYXRlKVxuICAgICAgcmV0dXJuIGFjY1xuICAgIH0sIHt9IGFzIFJlY29yZDxzdHJpbmcsIHR5cGVvZiBkdWVEYXRlcz4pXG5cbiAgICBsZXQgY29udGVudCA9IGAjIER1ZSBEYXRlcyBTdW1tYXJ5IC0gJHtjb3Vyc2VJZH1cXG5cXG5gXG4gICAgY29udGVudCArPSBgVG90YWwgYXNzaWdubWVudHM6ICR7ZHVlRGF0ZXMubGVuZ3RofVxcblxcbmBcblxuICAgIC8vIEFkZCBzdW1tYXJ5IGJ5IHN0YXR1c1xuICAgIGZvciAoY29uc3QgW3N0YXR1cywgaXRlbXNdIG9mIE9iamVjdC5lbnRyaWVzKGJ5U3RhdHVzKSkge1xuICAgICAgY29udGVudCArPSBgIyMgJHtzdGF0dXMuY2hhckF0KDApLnRvVXBwZXJDYXNlKCkgKyBzdGF0dXMuc2xpY2UoMSl9ICgke1xuICAgICAgICBpdGVtcy5sZW5ndGhcbiAgICAgIH0pXFxuXFxuYFxuICAgICAgY29udGVudCArPSBgfCBEYXRlIHwgQXNzaWdubWVudCB8IFNvdXJjZSB8XFxuYFxuICAgICAgY29udGVudCArPSBgfCAtLS0tIHwgLS0tLS0tLS0tLSB8IC0tLS0tLSB8XFxuYFxuXG4gICAgICBmb3IgKGNvbnN0IGl0ZW0gb2YgaXRlbXMpIHtcbiAgICAgICAgY29udGVudCArPSBgfCAke2l0ZW0uZGF0ZX0gfCAke2l0ZW0uYXNzaWdubWVudH0gfCAke2l0ZW0uc291cmNlfSB8XFxuYFxuICAgICAgfVxuICAgICAgY29udGVudCArPSBgXFxuYFxuICAgIH1cblxuICAgIHJldHVybiBjb250ZW50XG4gIH1cblxuICBhc3luYyBjcmVhdGVEdWVEYXRlc1N1bW1hcnlGaWxlKFxuICAgIGNvdXJzZUlkOiBzdHJpbmcsXG4gICAgc3RhcnREYXRlPzogc3RyaW5nLFxuICAgIGVuZERhdGU/OiBzdHJpbmdcbiAgKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGR1ZURhdGVzID0gYXdhaXQgdGhpcy5wYXJzZUR1ZURhdGVzRnJvbUNvdXJzZShcbiAgICAgICAgY291cnNlSWQsXG4gICAgICAgIHN0YXJ0RGF0ZSxcbiAgICAgICAgZW5kRGF0ZVxuICAgICAgKVxuXG4gICAgICBjb25zdCBzdW1tYXJ5Q29udGVudCA9IGF3YWl0IHRoaXMuZ2VuZXJhdGVEdWVEYXRlc1N1bW1hcnkoXG4gICAgICAgIGNvdXJzZUlkLFxuICAgICAgICBkdWVEYXRlc1xuICAgICAgKVxuXG4gICAgICAvLyBDcmVhdGUgdGhlIHN1bW1hcnkgZmlsZVxuICAgICAgY29uc3QgZmlsZU5hbWUgPSBgJHtjb3Vyc2VJZH0gLSBEdWUgRGF0ZXMgU3VtbWFyeS5tZGBcbiAgICAgIGNvbnN0IGZpbGVQYXRoID0gYENvdXJzZXMvJHtjb3Vyc2VJZH0vJHtmaWxlTmFtZX1gXG5cbiAgICAgIHRyeSB7XG4gICAgICAgIGF3YWl0IHRoaXMuYXBwLnZhdWx0LmNyZWF0ZShmaWxlUGF0aCwgc3VtbWFyeUNvbnRlbnQpXG4gICAgICAgIGNvbnNvbGUubG9nKGBDcmVhdGVkIGR1ZSBkYXRlcyBzdW1tYXJ5IGZpbGU6ICR7ZmlsZVBhdGh9YClcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIC8vIEZpbGUgbWlnaHQgYWxyZWFkeSBleGlzdCwgdHJ5IHRvIHVwZGF0ZSBpdFxuICAgICAgICBjb25zdCBleGlzdGluZ0ZpbGUgPSB0aGlzLmFwcC52YXVsdC5nZXRBYnN0cmFjdEZpbGVCeVBhdGgoZmlsZVBhdGgpXG4gICAgICAgIGlmIChleGlzdGluZ0ZpbGUgJiYgZXhpc3RpbmdGaWxlIGluc3RhbmNlb2YgVEZpbGUpIHtcbiAgICAgICAgICBhd2FpdCB0aGlzLmFwcC52YXVsdC5tb2RpZnkoZXhpc3RpbmdGaWxlLCBzdW1tYXJ5Q29udGVudClcbiAgICAgICAgICBjb25zb2xlLmxvZyhgVXBkYXRlZCBkdWUgZGF0ZXMgc3VtbWFyeSBmaWxlOiAke2ZpbGVQYXRofWApXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihcbiAgICAgICAgYEVycm9yIGNyZWF0aW5nIGR1ZSBkYXRlcyBzdW1tYXJ5IGZvciBjb3Vyc2UgJHtjb3Vyc2VJZH06YCxcbiAgICAgICAgZXJyb3JcbiAgICAgIClcbiAgICAgIHRocm93IGVycm9yXG4gICAgfVxuICB9XG59XG4iLCAiLy8gRGFpbHkgbm90ZXMgaW50ZWdyYXRpb24gZm9yIFR1Y2tlcnMgVG9vbHMgcGx1Z2luXG5cbmltcG9ydCB7IEFwcCwgVEZpbGUgfSBmcm9tIFwib2JzaWRpYW5cIlxuXG5leHBvcnQgY2xhc3MgRGFpbHlOb3Rlc0ludGVncmF0aW9uIHtcbiAgYXBwOiBBcHBcblxuICBjb25zdHJ1Y3RvcihhcHA6IEFwcCkge1xuICAgIHRoaXMuYXBwID0gYXBwXG4gIH1cblxuICBhc3luYyBnZXRUb2RheXNBY3Rpdml0aWVzKCk6IFByb21pc2U8XG4gICAgQXJyYXk8eyBmaWxlOiBzdHJpbmc7IHR5cGU6IHN0cmluZzsgY291cnNlPzogc3RyaW5nIH0+XG4gID4ge1xuICAgIGNvbnNvbGUubG9nKFwiR2V0dGluZyB0b2RheSdzIGFjYWRlbWljIGFjdGl2aXRpZXNcIilcblxuICAgIHRyeSB7XG4gICAgICBjb25zdCB0b2RheSA9IG5ldyBEYXRlKClcbiAgICAgIGNvbnN0IHRvZGF5U3RyaW5nID0gdG9kYXkudG9JU09TdHJpbmcoKS5zcGxpdChcIlRcIilbMF1cblxuICAgICAgLy8gRmluZCBmaWxlcyBjcmVhdGVkIG9yIG1vZGlmaWVkIHRvZGF5XG4gICAgICBjb25zdCBmaWxlcyA9IHRoaXMuYXBwLnZhdWx0LmdldE1hcmtkb3duRmlsZXMoKVxuICAgICAgY29uc3QgdG9kYXlzRmlsZXM6IFRGaWxlW10gPSBbXVxuXG4gICAgICBmb3IgKGNvbnN0IGZpbGUgb2YgZmlsZXMpIHtcbiAgICAgICAgY29uc3QgZmlsZURhdGUgPSB0aGlzLmV4dHJhY3REYXRlRnJvbVBhdGgoZmlsZS5wYXRoKVxuICAgICAgICBpZiAoZmlsZURhdGUgPT09IHRvZGF5U3RyaW5nKSB7XG4gICAgICAgICAgdG9kYXlzRmlsZXMucHVzaChmaWxlKVxuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIC8vIEFuYWx5emUgYWN0aXZpdGllc1xuICAgICAgY29uc3QgYWN0aXZpdGllczogQXJyYXk8eyBmaWxlOiBzdHJpbmc7IHR5cGU6IHN0cmluZzsgY291cnNlPzogc3RyaW5nIH0+ID1cbiAgICAgICAgW11cblxuICAgICAgZm9yIChjb25zdCBmaWxlIG9mIHRvZGF5c0ZpbGVzKSB7XG4gICAgICAgIGNvbnN0IGFjdGl2aXR5ID0gYXdhaXQgdGhpcy5hbmFseXplRmlsZUFjdGl2aXR5KGZpbGUpXG4gICAgICAgIGlmIChhY3Rpdml0eSkge1xuICAgICAgICAgIGFjdGl2aXRpZXMucHVzaChhY3Rpdml0eSlcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICBjb25zb2xlLmxvZyhgRm91bmQgJHthY3Rpdml0aWVzLmxlbmd0aH0gYWNhZGVtaWMgYWN0aXZpdGllcyBmb3IgdG9kYXlgKVxuICAgICAgcmV0dXJuIGFjdGl2aXRpZXNcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGdldHRpbmcgdG9kYXkncyBhY3Rpdml0aWVzOlwiLCBlcnJvcilcbiAgICAgIHJldHVybiBbXVxuICAgIH1cbiAgfVxuXG4gIGFzeW5jIGdldENvdXJzZUFjdGl2aXR5Rm9yRGF0ZShcbiAgICBjb3Vyc2VJZDogc3RyaW5nLFxuICAgIGRhdGU6IHN0cmluZ1xuICApOiBQcm9taXNlPEFycmF5PHsgZmlsZTogc3RyaW5nOyB0eXBlOiBzdHJpbmcgfT4+IHtcbiAgICBjb25zb2xlLmxvZyhgR2V0dGluZyBhY3Rpdml0eSBmb3IgY291cnNlICR7Y291cnNlSWR9IG9uIGRhdGUgJHtkYXRlfWApXG5cbiAgICB0cnkge1xuICAgICAgLy8gRmluZCBmaWxlcyByZWxhdGVkIHRvIHRoZSBjb3Vyc2UgbW9kaWZpZWQgb24gdGhlIGRhdGVcbiAgICAgIGNvbnN0IGNvdXJzZUZpbGVzID0gYXdhaXQgdGhpcy5maW5kQ291cnNlRmlsZXNGb3JEYXRlKGNvdXJzZUlkLCBkYXRlKVxuXG4gICAgICBjb25zdCBhY3Rpdml0aWVzOiBBcnJheTx7IGZpbGU6IHN0cmluZzsgdHlwZTogc3RyaW5nIH0+ID0gW11cblxuICAgICAgZm9yIChjb25zdCBmaWxlIG9mIGNvdXJzZUZpbGVzKSB7XG4gICAgICAgIGNvbnN0IGNvbnRlbnQgPSBhd2FpdCB0aGlzLmFwcC52YXVsdC5yZWFkKGZpbGUpXG4gICAgICAgIGNvbnN0IGZpbGVUeXBlID0gdGhpcy5kZXRlcm1pbmVGaWxlVHlwZShmaWxlLCBjb250ZW50KVxuXG4gICAgICAgIGFjdGl2aXRpZXMucHVzaCh7XG4gICAgICAgICAgZmlsZTogZmlsZS5iYXNlbmFtZSxcbiAgICAgICAgICB0eXBlOiBmaWxlVHlwZVxuICAgICAgICB9KVxuICAgICAgfVxuXG4gICAgICBjb25zb2xlLmxvZyhcbiAgICAgICAgYEZvdW5kICR7YWN0aXZpdGllcy5sZW5ndGh9IGFjdGl2aXRpZXMgZm9yIGNvdXJzZSAke2NvdXJzZUlkfSBvbiAke2RhdGV9YFxuICAgICAgKVxuICAgICAgcmV0dXJuIGFjdGl2aXRpZXNcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihcbiAgICAgICAgYEVycm9yIGdldHRpbmcgY291cnNlIGFjdGl2aXR5IGZvciAke2NvdXJzZUlkfSBvbiAke2RhdGV9OmAsXG4gICAgICAgIGVycm9yXG4gICAgICApXG4gICAgICByZXR1cm4gW11cbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGV4dHJhY3REYXRlRnJvbVBhdGgoZmlsZVBhdGg6IHN0cmluZyk6IHN0cmluZyB8IG51bGwge1xuICAgIC8vIFRyeSB0byBleHRyYWN0IGRhdGUgZnJvbSBmaWxlIHBhdGggKGUuZy4sIFwiRGFpbHkvMjAyNS0wMS0xNS5tZFwiIC0+IFwiMjAyNS0wMS0xNVwiKVxuICAgIGNvbnN0IGRhdGVSZWdleCA9IC8oXFxkezR9LVxcZHsyfS1cXGR7Mn0pL2dcbiAgICBjb25zdCBtYXRjaGVzID0gZmlsZVBhdGgubWF0Y2goZGF0ZVJlZ2V4KVxuICAgIHJldHVybiBtYXRjaGVzID8gbWF0Y2hlc1ttYXRjaGVzLmxlbmd0aCAtIDFdIDogbnVsbFxuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBhbmFseXplRmlsZUFjdGl2aXR5KFxuICAgIGZpbGU6IFRGaWxlXG4gICk6IFByb21pc2U8eyBmaWxlOiBzdHJpbmc7IHR5cGU6IHN0cmluZzsgY291cnNlPzogc3RyaW5nIH0gfCBudWxsPiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGNvbnRlbnQgPSBhd2FpdCB0aGlzLmFwcC52YXVsdC5yZWFkKGZpbGUpXG5cbiAgICAgIC8vIERldGVybWluZSBmaWxlIHR5cGUgYmFzZWQgb24gY29udGVudCBhbmQgcGF0aFxuICAgICAgY29uc3QgZmlsZVR5cGUgPSB0aGlzLmRldGVybWluZUZpbGVUeXBlKGZpbGUsIGNvbnRlbnQpXG5cbiAgICAgIC8vIEV4dHJhY3QgY291cnNlIElEIGlmIGFwcGxpY2FibGVcbiAgICAgIGNvbnN0IGNvdXJzZUlkID1cbiAgICAgICAgdGhpcy5leHRyYWN0Q291cnNlSWRGcm9tQ29udGVudChjb250ZW50KSB8fFxuICAgICAgICB0aGlzLmV4dHJhY3RDb3Vyc2VJZEZyb21QYXRoKGZpbGUucGF0aClcblxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgZmlsZTogZmlsZS5iYXNlbmFtZSxcbiAgICAgICAgdHlwZTogZmlsZVR5cGUsXG4gICAgICAgIGNvdXJzZTogY291cnNlSWQgfHwgdW5kZWZpbmVkXG4gICAgICB9XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIGFuYWx5emluZyBmaWxlICR7ZmlsZS5wYXRofTpgLCBlcnJvcilcbiAgICAgIHJldHVybiBudWxsXG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSBkZXRlcm1pbmVGaWxlVHlwZShmaWxlOiBURmlsZSwgY29udGVudDogc3RyaW5nKTogc3RyaW5nIHtcbiAgICBjb25zdCBwYXRoID0gZmlsZS5wYXRoLnRvTG93ZXJDYXNlKClcblxuICAgIC8vIENoZWNrIGZvciBkYWlseSBub3Rlc1xuICAgIGlmIChcbiAgICAgIHBhdGguaW5jbHVkZXMoXCJkYWlseVwiKSB8fFxuICAgICAgY29udGVudC5pbmNsdWRlcyhcImNvbnRlbnRfdHlwZTogZGFpbHlfbm90ZVwiKVxuICAgICkge1xuICAgICAgcmV0dXJuIFwiZGFpbHlfbm90ZVwiXG4gICAgfVxuXG4gICAgLy8gQ2hlY2sgZm9yIGNvdXJzZS1yZWxhdGVkIGZpbGVzXG4gICAgaWYgKHBhdGguaW5jbHVkZXMoXCJjb3Vyc2VzXCIpIHx8IGNvbnRlbnQuaW5jbHVkZXMoXCJjb3Vyc2VfaWQ6XCIpKSB7XG4gICAgICBpZiAoY29udGVudC5pbmNsdWRlcyhcImNvbnRlbnRfdHlwZTogY291cnNlX2hvbWVwYWdlXCIpKSB7XG4gICAgICAgIHJldHVybiBcImNvdXJzZV9ob21lcGFnZVwiXG4gICAgICB9XG4gICAgICBpZiAoY29udGVudC5pbmNsdWRlcyhcImNvbnRlbnRfdHlwZTogbW9kdWxlXCIpKSB7XG4gICAgICAgIHJldHVybiBcIm1vZHVsZVwiXG4gICAgICB9XG4gICAgICBpZiAoY29udGVudC5pbmNsdWRlcyhcImNvbnRlbnRfdHlwZTogY2hhcHRlclwiKSkge1xuICAgICAgICByZXR1cm4gXCJjaGFwdGVyXCJcbiAgICAgIH1cbiAgICAgIGlmIChjb250ZW50LmluY2x1ZGVzKFwiY29udGVudF90eXBlOiBhc3NpZ25tZW50XCIpKSB7XG4gICAgICAgIHJldHVybiBcImFzc2lnbm1lbnRcIlxuICAgICAgfVxuICAgICAgcmV0dXJuIFwiY291cnNlX25vdGVcIlxuICAgIH1cblxuICAgIC8vIENoZWNrIGZvciB2b2NhYnVsYXJ5IGVudHJpZXNcbiAgICBpZiAoY29udGVudC5pbmNsdWRlcyhcIiMjIFwiKSAmJiBjb250ZW50Lm1hdGNoKC9eXFwqXFwqVGVybVxcKlxcKjovbSkpIHtcbiAgICAgIHJldHVybiBcInZvY2FidWxhcnlfZW50cnlcIlxuICAgIH1cblxuICAgIHJldHVybiBcIm90aGVyXCJcbiAgfVxuXG4gIHByaXZhdGUgZXh0cmFjdENvdXJzZUlkRnJvbUNvbnRlbnQoY29udGVudDogc3RyaW5nKTogc3RyaW5nIHwgbnVsbCB7XG4gICAgY29uc3QgY291cnNlSWRSZWdleCA9IC9jb3Vyc2VfaWQ6XFxzKihbQS1aXXsyLDR9LVxcZHszfSkvXG4gICAgY29uc3QgbWF0Y2ggPSBjb250ZW50Lm1hdGNoKGNvdXJzZUlkUmVnZXgpXG4gICAgcmV0dXJuIG1hdGNoID8gbWF0Y2hbMV0gOiBudWxsXG4gIH1cblxuICBwcml2YXRlIGV4dHJhY3RDb3Vyc2VJZEZyb21QYXRoKGZpbGVQYXRoOiBzdHJpbmcpOiBzdHJpbmcgfCBudWxsIHtcbiAgICBjb25zdCBjb3Vyc2VJZFJlZ2V4ID0gLyhbQS1aXXsyLDR9LVxcZHszfSkvZ1xuICAgIGNvbnN0IG1hdGNoZXMgPSBmaWxlUGF0aC5tYXRjaChjb3Vyc2VJZFJlZ2V4KVxuICAgIHJldHVybiBtYXRjaGVzID8gbWF0Y2hlc1ttYXRjaGVzLmxlbmd0aCAtIDFdIDogbnVsbFxuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBmaW5kQ291cnNlRmlsZXNGb3JEYXRlKFxuICAgIGNvdXJzZUlkOiBzdHJpbmcsXG4gICAgZGF0ZTogc3RyaW5nXG4gICk6IFByb21pc2U8VEZpbGVbXT4ge1xuICAgIGNvbnN0IGZpbGVzOiBURmlsZVtdID0gW11cblxuICAgIC8vIEdldCBhbGwgZmlsZXMgYW5kIGZpbHRlciBieSBjb3Vyc2UgSUQgYW5kIGRhdGVcbiAgICBjb25zdCBhbGxGaWxlcyA9IHRoaXMuYXBwLnZhdWx0LmdldE1hcmtkb3duRmlsZXMoKVxuXG4gICAgZm9yIChjb25zdCBmaWxlIG9mIGFsbEZpbGVzKSB7XG4gICAgICAvLyBDaGVjayBpZiBmaWxlIGJlbG9uZ3MgdG8gdGhlIGNvdXJzZVxuICAgICAgaWYgKFxuICAgICAgICBmaWxlLnBhdGguaW5jbHVkZXMoY291cnNlSWQpIHx8XG4gICAgICAgIChhd2FpdCB0aGlzLmZpbGVCZWxvbmdzVG9Db3Vyc2UoZmlsZSwgY291cnNlSWQpKVxuICAgICAgKSB7XG4gICAgICAgIC8vIENoZWNrIGlmIGZpbGUgd2FzIG1vZGlmaWVkIG9uIHRoZSBzcGVjaWZpZWQgZGF0ZVxuICAgICAgICBjb25zdCBmaWxlRGF0ZSA9IHRoaXMuZXh0cmFjdERhdGVGcm9tUGF0aChmaWxlLnBhdGgpXG4gICAgICAgIGlmIChmaWxlRGF0ZSA9PT0gZGF0ZSkge1xuICAgICAgICAgIGZpbGVzLnB1c2goZmlsZSlcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBmaWxlc1xuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBmaWxlQmVsb25nc1RvQ291cnNlKFxuICAgIGZpbGU6IFRGaWxlLFxuICAgIGNvdXJzZUlkOiBzdHJpbmdcbiAgKTogUHJvbWlzZTxib29sZWFuPiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGNvbnRlbnQgPSBhd2FpdCB0aGlzLmFwcC52YXVsdC5yZWFkKGZpbGUpXG4gICAgICByZXR1cm4gdGhpcy5leHRyYWN0Q291cnNlSWRGcm9tQ29udGVudChjb250ZW50KSA9PT0gY291cnNlSWRcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihcbiAgICAgICAgYEVycm9yIGNoZWNraW5nIGlmIGZpbGUgJHtmaWxlLnBhdGh9IGJlbG9uZ3MgdG8gY291cnNlICR7Y291cnNlSWR9OmAsXG4gICAgICAgIGVycm9yXG4gICAgICApXG4gICAgICByZXR1cm4gZmFsc2VcbiAgICB9XG4gIH1cblxuICBhc3luYyBnZW5lcmF0ZURhaWx5U3VtbWFyeShkYXRlPzogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgICBjb25zdCB0YXJnZXREYXRlID0gZGF0ZSB8fCBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc3BsaXQoXCJUXCIpWzBdXG4gICAgY29uc3QgYWN0aXZpdGllcyA9IGF3YWl0IHRoaXMuZ2V0Q291cnNlQWN0aXZpdHlGb3JEYXRlKFwiXCIsIHRhcmdldERhdGUpXG5cbiAgICBpZiAoYWN0aXZpdGllcy5sZW5ndGggPT09IDApIHtcbiAgICAgIHJldHVybiBgIyBBY2FkZW1pYyBBY3Rpdml0aWVzIC0gJHt0YXJnZXREYXRlfVxcblxcbk5vIGFjYWRlbWljIGFjdGl2aXRpZXMgcmVjb3JkZWQgZm9yIHRoaXMgZGF0ZS5cXG5gXG4gICAgfVxuXG4gICAgLy8gR3JvdXAgYWN0aXZpdGllcyBieSBjb3Vyc2VcbiAgICBjb25zdCBieUNvdXJzZTogUmVjb3JkPHN0cmluZywgdHlwZW9mIGFjdGl2aXRpZXM+ID0ge31cbiAgICBjb25zdCBub0NvdXJzZTogdHlwZW9mIGFjdGl2aXRpZXMgPSBbXVxuXG4gICAgZm9yIChjb25zdCBhY3Rpdml0eSBvZiBhY3Rpdml0aWVzKSB7XG4gICAgICBpZiAoYWN0aXZpdHkuZmlsZS5pbmNsdWRlcyhcIkNvdXJzZXMvXCIpKSB7XG4gICAgICAgIC8vIEV4dHJhY3QgY291cnNlIElEIGZyb20gcGF0aFxuICAgICAgICBjb25zdCBwYXRoUGFydHMgPSBhY3Rpdml0eS5maWxlLnNwbGl0KFwiL1wiKVxuICAgICAgICBjb25zdCBjb3Vyc2VJbmRleCA9IHBhdGhQYXJ0cy5maW5kSW5kZXgoKHBhcnQpID0+IHBhcnQuaW5jbHVkZXMoXCItXCIpKVxuICAgICAgICBpZiAoY291cnNlSW5kZXggPj0gMCkge1xuICAgICAgICAgIGNvbnN0IGNvdXJzZUlkID0gcGF0aFBhcnRzW2NvdXJzZUluZGV4XVxuICAgICAgICAgIGlmICghYnlDb3Vyc2VbY291cnNlSWRdKSB7XG4gICAgICAgICAgICBieUNvdXJzZVtjb3Vyc2VJZF0gPSBbXVxuICAgICAgICAgIH1cbiAgICAgICAgICBieUNvdXJzZVtjb3Vyc2VJZF0ucHVzaChhY3Rpdml0eSlcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBub0NvdXJzZS5wdXNoKGFjdGl2aXR5KVxuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBub0NvdXJzZS5wdXNoKGFjdGl2aXR5KVxuICAgICAgfVxuICAgIH1cblxuICAgIGxldCBjb250ZW50ID0gYCMgQWNhZGVtaWMgQWN0aXZpdGllcyAtICR7dGFyZ2V0RGF0ZX1cXG5cXG5gXG4gICAgY29udGVudCArPSBgVG90YWwgYWN0aXZpdGllczogJHthY3Rpdml0aWVzLmxlbmd0aH1cXG5cXG5gXG5cbiAgICAvLyBBZGQgYWN0aXZpdGllcyBieSBjb3Vyc2VcbiAgICBmb3IgKGNvbnN0IFtjb3Vyc2VJZCwgY291cnNlQWN0aXZpdGllc10gb2YgT2JqZWN0LmVudHJpZXMoYnlDb3Vyc2UpKSB7XG4gICAgICBjb250ZW50ICs9IGAjIyAke2NvdXJzZUlkfVxcblxcbmBcbiAgICAgIGNvbnRlbnQgKz0gYHwgRmlsZSB8IFR5cGUgfFxcbmBcbiAgICAgIGNvbnRlbnQgKz0gYHwgLS0tLSB8IC0tLS0gfFxcbmBcblxuICAgICAgZm9yIChjb25zdCBhY3Rpdml0eSBvZiBjb3Vyc2VBY3Rpdml0aWVzKSB7XG4gICAgICAgIGNvbnRlbnQgKz0gYHwgJHthY3Rpdml0eS5maWxlfSB8ICR7YWN0aXZpdHkudHlwZX0gfFxcbmBcbiAgICAgIH1cbiAgICAgIGNvbnRlbnQgKz0gYFxcbmBcbiAgICB9XG5cbiAgICAvLyBBZGQgYWN0aXZpdGllcyB3aXRob3V0IHNwZWNpZmljIGNvdXJzZVxuICAgIGlmIChub0NvdXJzZS5sZW5ndGggPiAwKSB7XG4gICAgICBjb250ZW50ICs9IGAjIyBPdGhlciBBY3Rpdml0aWVzXFxuXFxuYFxuICAgICAgY29udGVudCArPSBgfCBGaWxlIHwgVHlwZSB8XFxuYFxuICAgICAgY29udGVudCArPSBgfCAtLS0tIHwgLS0tLSB8XFxuYFxuXG4gICAgICBmb3IgKGNvbnN0IGFjdGl2aXR5IG9mIG5vQ291cnNlKSB7XG4gICAgICAgIGNvbnRlbnQgKz0gYHwgJHthY3Rpdml0eS5maWxlfSB8ICR7YWN0aXZpdHkudHlwZX0gfFxcbmBcbiAgICAgIH1cbiAgICAgIGNvbnRlbnQgKz0gYFxcbmBcbiAgICB9XG5cbiAgICByZXR1cm4gY29udGVudFxuICB9XG5cbiAgYXN5bmMgY3JlYXRlRGFpbHlTdW1tYXJ5RmlsZShkYXRlPzogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHRhcmdldERhdGUgPSBkYXRlIHx8IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zcGxpdChcIlRcIilbMF1cbiAgICAgIGNvbnN0IHN1bW1hcnlDb250ZW50ID0gYXdhaXQgdGhpcy5nZW5lcmF0ZURhaWx5U3VtbWFyeSh0YXJnZXREYXRlKVxuXG4gICAgICAvLyBDcmVhdGUgdGhlIHN1bW1hcnkgZmlsZVxuICAgICAgY29uc3QgZmlsZU5hbWUgPSBgJHt0YXJnZXREYXRlfSAtIEFjYWRlbWljIFN1bW1hcnkubWRgXG4gICAgICBjb25zdCBmaWxlUGF0aCA9IGBEYWlseS8ke2ZpbGVOYW1lfWBcblxuICAgICAgdHJ5IHtcbiAgICAgICAgYXdhaXQgdGhpcy5hcHAudmF1bHQuY3JlYXRlKGZpbGVQYXRoLCBzdW1tYXJ5Q29udGVudClcbiAgICAgICAgY29uc29sZS5sb2coYENyZWF0ZWQgZGFpbHkgc3VtbWFyeSBmaWxlOiAke2ZpbGVQYXRofWApXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAvLyBGaWxlIG1pZ2h0IGFscmVhZHkgZXhpc3QsIHRyeSB0byB1cGRhdGUgaXRcbiAgICAgICAgY29uc3QgZXhpc3RpbmdGaWxlID0gdGhpcy5hcHAudmF1bHQuZ2V0QWJzdHJhY3RGaWxlQnlQYXRoKGZpbGVQYXRoKVxuICAgICAgICBpZiAoZXhpc3RpbmdGaWxlICYmIGV4aXN0aW5nRmlsZSBpbnN0YW5jZW9mIFRGaWxlKSB7XG4gICAgICAgICAgYXdhaXQgdGhpcy5hcHAudmF1bHQubW9kaWZ5KGV4aXN0aW5nRmlsZSwgc3VtbWFyeUNvbnRlbnQpXG4gICAgICAgICAgY29uc29sZS5sb2coYFVwZGF0ZWQgZGFpbHkgc3VtbWFyeSBmaWxlOiAke2ZpbGVQYXRofWApXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihgRXJyb3IgY3JlYXRpbmcgZGFpbHkgc3VtbWFyeSBmb3IgJHtkYXRlfTpgLCBlcnJvcilcbiAgICAgIHRocm93IGVycm9yXG4gICAgfVxuICB9XG59XG4iXSwKICAibWFwcGluZ3MiOiAiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUFBQSxtQkFBdUI7OztBQ0F2QixzQkFBK0M7OztBQ2dCeEMsU0FBUyxRQUFRLE1BQXNCO0FBQzVDLFNBQU8sS0FDSixZQUFZLEVBQ1osS0FBSyxFQUNMLFVBQVUsS0FBSyxFQUNmLFFBQVEsb0JBQW9CLEVBQUUsRUFDOUIsUUFBUSxpQkFBaUIsRUFBRSxFQUMzQixRQUFRLFdBQVcsR0FBRyxFQUN0QixRQUFRLFlBQVksRUFBRTtBQUMzQjtBQWVPLFNBQVMsYUFBYSxZQUE2QjtBQUN4RCxRQUFNLFFBQVE7QUFDZCxNQUFJLENBQUMsV0FBVyxNQUFNLEtBQUs7QUFBRyxXQUFPO0FBRXJDLFFBQU0sT0FBTyxJQUFJLEtBQUssVUFBVTtBQUNoQyxRQUFNLFlBQVksS0FBSyxRQUFRO0FBRS9CLE1BQUksT0FBTyxjQUFjLFlBQVksTUFBTSxTQUFTO0FBQUcsV0FBTztBQUU5RCxTQUFPLGVBQWUsS0FBSyxZQUFZLEVBQUUsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUN2RDs7O0FEcENPLElBQU0sbUJBQXlDO0FBQUEsRUFDcEQsZUFBZTtBQUFBLEVBQ2YsbUJBQW1CLElBQUksS0FBSyxFQUFFLFlBQVksRUFBRSxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsRUFDeEQsaUJBQWlCLElBQUksS0FBSyxJQUFJLEtBQUssRUFBRSxTQUFTLElBQUksS0FBSyxFQUFFLFNBQVMsSUFBSSxDQUFDLENBQUMsRUFBRSxZQUFZLEVBQUUsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLEVBQ3BHLFlBQVk7QUFBQSxFQUNaLG9CQUFvQjtBQUFBLEVBQ3BCLGdCQUFnQjtBQUFBLEVBQ2hCLHFCQUFxQjtBQUN2QjtBQUVPLElBQU0seUJBQU4sY0FBcUMsaUNBQWlCO0FBQUEsRUFHM0QsWUFBWSxLQUFVLFFBQTRCO0FBQ2hELFVBQU0sS0FBSyxNQUFNO0FBQ2pCLFNBQUssU0FBUztBQUFBLEVBQ2hCO0FBQUEsRUFFQSxVQUFnQjtBQUNkLFVBQU0sRUFBRSxZQUFZLElBQUk7QUFFeEIsZ0JBQVksTUFBTTtBQUVsQixnQkFBWSxTQUFTLE1BQU0sRUFBRSxNQUFNLHlCQUF5QixDQUFDO0FBRTdELFFBQUksd0JBQVEsV0FBVyxFQUNwQixRQUFRLGdCQUFnQixFQUN4QixRQUFRLGdEQUFnRCxFQUN4RCxRQUFRLFVBQVEsS0FDZCxlQUFlLEdBQUcsRUFDbEIsU0FBUyxLQUFLLE9BQU8sU0FBUyxhQUFhLEVBQzNDLFNBQVMsQ0FBTyxVQUFVO0FBQ3pCLFdBQUssT0FBTyxTQUFTLGdCQUFnQjtBQUNyQyxZQUFNLEtBQUssT0FBTyxhQUFhO0FBQUEsSUFDakMsRUFBQyxDQUFDO0FBRU4sVUFBTSxtQkFBbUIsSUFBSSx3QkFBUSxXQUFXLEVBQzdDLFFBQVEscUJBQXFCLEVBQzdCLFFBQVEscUNBQXFDLEVBQzdDLFFBQVEsVUFBUSxLQUNkLGVBQWUsWUFBWSxFQUMzQixTQUFTLEtBQUssT0FBTyxTQUFTLGlCQUFpQixFQUMvQyxTQUFTLENBQU8sVUFBVTtBQUN6QixVQUFJLFNBQVMsQ0FBQyxhQUFhLEtBQUssR0FBRztBQUNqQyx5QkFBaUIsUUFBUSwyREFBMkQ7QUFBQSxNQUN0RixPQUFPO0FBQ0wseUJBQWlCLFFBQVEscUNBQXFDO0FBQUEsTUFDaEU7QUFDQSxXQUFLLE9BQU8sU0FBUyxvQkFBb0I7QUFDekMsWUFBTSxLQUFLLE9BQU8sYUFBYTtBQUFBLElBQ2pDLEVBQUMsQ0FBQztBQUVOLFVBQU0saUJBQWlCLElBQUksd0JBQVEsV0FBVyxFQUMzQyxRQUFRLG1CQUFtQixFQUMzQixRQUFRLG1DQUFtQyxFQUMzQyxRQUFRLFVBQVEsS0FDZCxlQUFlLFlBQVksRUFDM0IsU0FBUyxLQUFLLE9BQU8sU0FBUyxlQUFlLEVBQzdDLFNBQVMsQ0FBTyxVQUFVO0FBQ3pCLFVBQUksU0FBUyxDQUFDLGFBQWEsS0FBSyxHQUFHO0FBQ2pDLHVCQUFlLFFBQVEseURBQXlEO0FBQUEsTUFDbEYsT0FBTztBQUNMLHVCQUFlLFFBQVEsbUNBQW1DO0FBQUEsTUFDNUQ7QUFDQSxXQUFLLE9BQU8sU0FBUyxrQkFBa0I7QUFDdkMsWUFBTSxLQUFLLE9BQU8sYUFBYTtBQUFBLElBQ2pDLEVBQUMsQ0FBQztBQUVOLFFBQUksd0JBQVEsV0FBVyxFQUNwQixRQUFRLGFBQWEsRUFDckIsUUFBUSwwQkFBMEIsRUFDbEMsUUFBUSxVQUFRLEtBQ2QsZUFBZSxZQUFZLEVBQzNCLFNBQVMsS0FBSyxPQUFPLFNBQVMsVUFBVSxFQUN4QyxTQUFTLENBQU8sVUFBVTtBQUN6QixXQUFLLE9BQU8sU0FBUyxhQUFhO0FBQ2xDLFlBQU0sS0FBSyxPQUFPLGFBQWE7QUFBQSxJQUNqQyxFQUFDLENBQUM7QUFFTixRQUFJLHdCQUFRLFdBQVcsRUFDcEIsUUFBUSxxQkFBcUIsRUFDN0IsUUFBUSxtQ0FBbUMsRUFDM0MsUUFBUSxVQUFRLEtBQ2QsZUFBZSxHQUFHLEVBQ2xCLFNBQVMsS0FBSyxPQUFPLFNBQVMsa0JBQWtCLEVBQ2hELFNBQVMsQ0FBTyxVQUFVO0FBQ3pCLFdBQUssT0FBTyxTQUFTLHFCQUFxQjtBQUMxQyxZQUFNLEtBQUssT0FBTyxhQUFhO0FBQUEsSUFDakMsRUFBQyxDQUFDO0FBRU4sUUFBSSx3QkFBUSxXQUFXLEVBQ3BCLFFBQVEsaUJBQWlCLEVBQ3pCLFFBQVEsNkVBQTZFLEVBQ3JGLFFBQVEsVUFBUSxLQUNkLGVBQWUsZUFBZSxFQUM5QixTQUFTLEtBQUssT0FBTyxTQUFTLGNBQWMsRUFDNUMsU0FBUyxDQUFPLFVBQVU7QUFDekIsV0FBSyxPQUFPLFNBQVMsaUJBQWlCO0FBQ3RDLFlBQU0sS0FBSyxPQUFPLGFBQWE7QUFBQSxJQUNqQyxFQUFDLENBQUM7QUFFTixRQUFJLHdCQUFRLFdBQVcsRUFDcEIsUUFBUSx1QkFBdUIsRUFDL0IsUUFBUSxpRkFBaUYsRUFDekYsVUFBVSxZQUFVLE9BQ2xCLFNBQVMsS0FBSyxPQUFPLFNBQVMsbUJBQW1CLEVBQ2pELFNBQVMsQ0FBTyxVQUFVO0FBQ3pCLFdBQUssT0FBTyxTQUFTLHNCQUFzQjtBQUMzQyxZQUFNLEtBQUssT0FBTyxhQUFhO0FBQUEsSUFDakMsRUFBQyxDQUFDO0FBQUEsRUFDUjtBQUNGOzs7QUU3SEEsSUFBQUMsbUJBQTRCO0FBVXJCLElBQU0sa0JBQU4sTUFBc0I7QUFBQSxFQUszQixZQUFZLEtBQVUsVUFBZ0M7QUFDcEQsU0FBSyxNQUFNO0FBQ1gsU0FBSyxXQUFXO0FBQ2hCLFNBQUssV0FBVztBQUFBLE1BQ2QsU0FBUztBQUFBLE1BQ1QsV0FBVztBQUFBLFFBQ1QscUNBQXFDO0FBQUEsUUFDckMsMkJBQTJCO0FBQUEsUUFDM0IsNEJBQTRCO0FBQUEsUUFDNUIsOEJBQThCO0FBQUEsUUFDOUIsb0NBQW9DO0FBQUEsUUFDcEMsdUJBQXVCO0FBQUEsUUFDdkIsaUNBQWlDO0FBQUEsUUFDakMsK0JBQStCO0FBQUEsTUFDakM7QUFBQSxNQUNBLGdCQUFnQjtBQUFBLE1BQ2hCLGVBQWU7QUFBQSxJQUNqQjtBQUFBLEVBQ0Y7QUFBQSxFQUVNLG1CQUFtQjtBQUFBO0FBQ3ZCLFVBQUk7QUFFRixjQUFNLGtCQUFrQixLQUFLLG1CQUFtQjtBQUNoRCxZQUFJLENBQUMsaUJBQWlCO0FBQ3BCLGNBQUk7QUFBQSxZQUNGO0FBQUEsVUFDRjtBQUNBLGtCQUFRO0FBQUEsWUFDTjtBQUFBLFVBQ0Y7QUFDQTtBQUFBLFFBQ0Y7QUFFQSxjQUFNLHFCQUFxQixLQUFLLHNCQUFzQixlQUFlO0FBQ3JFLFlBQUksQ0FBQyxvQkFBb0I7QUFDdkIsY0FBSTtBQUFBLFlBQ0Y7QUFBQSxVQUNGO0FBQ0Esa0JBQVE7QUFBQSxZQUNOO0FBQUEsVUFDRjtBQUNBO0FBQUEsUUFDRjtBQUVBLGNBQU0sbUJBQW1CLEdBQUcsc0JBQXNCLEtBQUssU0FBUztBQUdoRSxZQUFJO0FBQ0YsZ0JBQU0sS0FBSyxJQUFJLE1BQU0sYUFBYSxnQkFBZ0I7QUFDbEQsa0JBQVEsSUFBSSw0QkFBNEIsa0JBQWtCO0FBQUEsUUFDNUQsU0FBUyxHQUFQO0FBRUEsa0JBQVE7QUFBQSxZQUNOLDhDQUE4QztBQUFBLFVBQ2hEO0FBQUEsUUFDRjtBQUdBLGNBQU0sVUFBVTtBQUFBLFVBQ2Q7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFFBQ0Y7QUFDQSxtQkFBVyxVQUFVLFNBQVM7QUFDNUIsY0FBSTtBQUNGLGtCQUFNLFVBQVUsR0FBRyxvQkFBb0I7QUFDdkMsa0JBQU0sS0FBSyxJQUFJLE1BQU0sYUFBYSxPQUFPO0FBQ3pDLG9CQUFRLElBQUkseUJBQXlCLFNBQVM7QUFBQSxVQUNoRCxTQUFTLEdBQVA7QUFFQSxvQkFBUTtBQUFBLGNBQ04sZ0NBQWdDLG9CQUFvQjtBQUFBLFlBQ3REO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFHQSxjQUFNLEtBQUssdUJBQXVCLGdCQUFnQjtBQUNsRCxjQUFNLEtBQUssdUJBQXVCLGdCQUFnQjtBQUNsRCxjQUFNLEtBQUssd0JBQXdCLGdCQUFnQjtBQUNuRCxjQUFNLEtBQUssMkJBQTJCLGdCQUFnQjtBQUN0RCxjQUFNLEtBQUssc0JBQXNCLGdCQUFnQjtBQUNqRCxjQUFNLEtBQUssd0JBQXdCLGdCQUFnQjtBQUduRCxjQUFNLEtBQUssYUFBYSxnQkFBZ0I7QUFHeEMsY0FBTSxLQUFLLHVCQUF1QixnQkFBZ0I7QUFFbEQsWUFBSSx3QkFBTyxpREFBaUQ7QUFDNUQsZ0JBQVEsSUFBSSxnREFBZ0Q7QUFBQSxNQUM5RCxTQUFTLE9BQVA7QUFDQSxnQkFBUSxNQUFNLCtCQUErQixLQUFLO0FBQ2xELFlBQUksd0JBQU8sd0RBQXdEO0FBQUEsTUFDckU7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVRLHFCQUEwQjtBQUVoQyxVQUFNLGdCQUFnQjtBQUFBLE1BQ25CLEtBQUssSUFBWSxRQUFRLFFBQVEsb0JBQW9CO0FBQUEsTUFDckQsS0FBSyxJQUFZLFFBQVEsUUFBUSxXQUFXO0FBQUEsTUFDNUMsS0FBSyxJQUFZLFFBQVEsVUFBVSxvQkFBb0I7QUFBQSxNQUN2RCxLQUFLLElBQVksUUFBUSxVQUFVLFdBQVc7QUFBQSxJQUNqRDtBQUVBLGVBQVcsUUFBUSxlQUFlO0FBQ2hDLFVBQUksTUFBTTtBQUNSLGVBQU87QUFBQSxNQUNUO0FBQUEsSUFDRjtBQUVBLFdBQU87QUFBQSxFQUNUO0FBQUEsRUFFUSxzQkFBc0IsaUJBQXFDO0FBQ2pFLFVBQU0sV0FBVyxnQkFBZ0I7QUFFakMsUUFBSSxDQUFDLFVBQVU7QUFDYixjQUFRLE1BQU0sa0NBQWtDO0FBQ2hELGFBQU87QUFBQSxJQUNUO0FBR0EsVUFBTSxnQkFBZ0I7QUFBQSxNQUNwQixTQUFTO0FBQUE7QUFBQSxNQUNULFNBQVM7QUFBQSxNQUNULFNBQVM7QUFBQSxNQUNULFNBQVM7QUFBQSxNQUNULFNBQVM7QUFBQSxJQUNYO0FBRUEsZUFBVyxRQUFRLGVBQWU7QUFDaEMsVUFBSSxRQUFRLE9BQU8sU0FBUyxVQUFVO0FBQ3BDLGVBQU87QUFBQSxNQUNUO0FBQUEsSUFDRjtBQUVBLFlBQVE7QUFBQSxNQUNOO0FBQUEsTUFDQSxPQUFPLEtBQUssUUFBUTtBQUFBLElBQ3RCO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUVNLHVCQUF1QixVQUFrQjtBQUFBO0FBQzdDLFlBQU0sZUFBZSxHQUFHO0FBQ3hCLFlBQU0sa0JBQWtCLEtBQUssVUFBVSxLQUFLLFVBQVUsTUFBTSxDQUFDO0FBRTdELFVBQUk7QUFFRixjQUFNLG1CQUNKLEtBQUssSUFBSSxNQUFNLHNCQUFzQixZQUFZO0FBQ25ELFlBQUksa0JBQWtCO0FBRXBCLGdCQUFNLE9BQU87QUFDYixnQkFBTSxLQUFLLElBQUksTUFBTSxPQUFPLE1BQU0sZUFBZTtBQUNqRCxrQkFBUSxJQUFJLDhCQUE4QixjQUFjO0FBQ3hEO0FBQUEsUUFDRjtBQUdBLGNBQU0sS0FBSyxJQUFJLE1BQU0sT0FBTyxjQUFjLGVBQWU7QUFDekQsZ0JBQVEsSUFBSSw4QkFBOEIsY0FBYztBQUFBLE1BQzFELFNBQVMsR0FBUDtBQUNBLFlBQUksd0JBQU8sb0NBQW9DLGNBQWM7QUFDN0QsZ0JBQVEsTUFBTSxvQ0FBb0MsaUJBQWlCLENBQUM7QUFBQSxNQUN0RTtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRU0sMEJBQTRDO0FBQUE7QUFHaEQsY0FBUSxJQUFJLCtCQUErQjtBQUMzQyxhQUFPO0FBQUEsSUFDVDtBQUFBO0FBQUEsRUFFTSxrQkFBa0I7QUFBQTtBQUN0QixVQUFJO0FBRUYsZ0JBQVEsSUFBSSxvQkFBb0I7QUFHaEMsY0FBTSxrQkFBa0IsS0FBSyxtQkFBbUI7QUFDaEQsWUFBSSxDQUFDLGlCQUFpQjtBQUNwQixjQUFJO0FBQUEsWUFDRjtBQUFBLFVBQ0Y7QUFDQSxrQkFBUTtBQUFBLFlBQ047QUFBQSxVQUNGO0FBQ0E7QUFBQSxRQUNGO0FBRUEsY0FBTSxxQkFBcUIsS0FBSyxzQkFBc0IsZUFBZTtBQUNyRSxZQUFJLENBQUMsb0JBQW9CO0FBQ3ZCLGNBQUk7QUFBQSxZQUNGO0FBQUEsVUFDRjtBQUNBLGtCQUFRO0FBQUEsWUFDTjtBQUFBLFVBQ0Y7QUFDQTtBQUFBLFFBQ0Y7QUFFQSxjQUFNLG1CQUFtQixHQUFHLHNCQUFzQixLQUFLLFNBQVM7QUFHaEUsY0FBTSxLQUFLLHVCQUF1QixnQkFBZ0I7QUFDbEQsY0FBTSxLQUFLLHVCQUF1QixnQkFBZ0I7QUFDbEQsY0FBTSxLQUFLLHdCQUF3QixnQkFBZ0I7QUFDbkQsY0FBTSxLQUFLLDJCQUEyQixnQkFBZ0I7QUFDdEQsY0FBTSxLQUFLLHNCQUFzQixnQkFBZ0I7QUFDakQsY0FBTSxLQUFLLHdCQUF3QixnQkFBZ0I7QUFHbkQsY0FBTSxLQUFLLGFBQWEsZ0JBQWdCO0FBR3hDLGNBQU0sS0FBSyx1QkFBdUIsZ0JBQWdCO0FBRWxELFlBQUksd0JBQU8sK0NBQStDO0FBQzFELGdCQUFRLElBQUksOENBQThDO0FBQUEsTUFDNUQsU0FBUyxPQUFQO0FBQ0EsZ0JBQVEsTUFBTSw2QkFBNkIsS0FBSztBQUNoRCxZQUFJLHdCQUFPLHNEQUFzRDtBQUFBLE1BQ25FO0FBQUEsSUFDRjtBQUFBO0FBQUEsRUFFTSx1QkFBdUIsVUFBa0I7QUFBQTtBQUM3QyxZQUFNLGFBQWEsR0FBRztBQUd0QixZQUFNLHlCQUF5QixLQUFLLCtCQUErQjtBQUNuRSxZQUFNLEtBQUs7QUFBQSxRQUNULEdBQUc7QUFBQSxRQUNIO0FBQUEsTUFDRjtBQUdBLFlBQU0sc0JBQXNCLEtBQUssNEJBQTRCO0FBQzdELFlBQU0sS0FBSztBQUFBLFFBQ1QsR0FBRztBQUFBLFFBQ0g7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBO0FBQUEsRUFFTSx1QkFBdUIsVUFBa0I7QUFBQTtBQUM3QyxZQUFNLGFBQWEsR0FBRztBQUd0QixZQUFNLGlCQUFpQixLQUFLLHVCQUF1QjtBQUNuRCxZQUFNLEtBQUs7QUFBQSxRQUNULEdBQUc7QUFBQSxRQUNIO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRU0sd0JBQXdCLFVBQWtCO0FBQUE7QUFDOUMsWUFBTSxjQUFjLEdBQUc7QUFHdkIsWUFBTSxrQkFBa0IsS0FBSyx3QkFBd0I7QUFDckQsWUFBTSxLQUFLO0FBQUEsUUFDVCxHQUFHO0FBQUEsUUFDSDtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVNLDJCQUEyQixVQUFrQjtBQUFBO0FBQ2pELFlBQU0saUJBQWlCLEdBQUc7QUFHMUIsWUFBTSxxQkFBcUIsS0FBSywyQkFBMkI7QUFDM0QsWUFBTSxLQUFLO0FBQUEsUUFDVCxHQUFHO0FBQUEsUUFDSDtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVNLHNCQUFzQixVQUFrQjtBQUFBO0FBQzVDLFlBQU0sWUFBWSxHQUFHO0FBR3JCLFlBQU0sb0JBQW9CLEtBQUssMEJBQTBCO0FBQ3pELFlBQU0sS0FBSztBQUFBLFFBQ1QsR0FBRztBQUFBLFFBQ0g7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBO0FBQUEsRUFFTSx3QkFBd0IsVUFBa0I7QUFBQTtBQUM5QyxZQUFNLGNBQWMsR0FBRztBQUd2QixZQUFNLGdCQUFnQixLQUFLLDJCQUEyQjtBQUN0RCxZQUFNLEtBQUs7QUFBQSxRQUNULEdBQUc7QUFBQSxRQUNIO0FBQUEsTUFDRjtBQUdBLFlBQU0sa0JBQWtCLEtBQUssd0JBQXdCO0FBQ3JELFlBQU0sS0FBSztBQUFBLFFBQ1QsR0FBRztBQUFBLFFBQ0g7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBO0FBQUEsRUFFTSxrQkFBa0IsTUFBYyxTQUFpQjtBQUFBO0FBQ3JELFVBQUk7QUFFRixjQUFNLGVBQWUsS0FBSyxJQUFJLE1BQU0sc0JBQXNCLElBQUk7QUFDOUQsWUFBSSxjQUFjO0FBR2hCLGtCQUFRLElBQUksb0NBQW9DLE1BQU07QUFDdEQsZ0JBQU0sT0FBTztBQUNiLGdCQUFNLEtBQUssSUFBSSxNQUFNLE9BQU8sTUFBTSxPQUFPO0FBQ3pDO0FBQUEsUUFDRjtBQUdBLGNBQU0sS0FBSyxJQUFJLE1BQU0sT0FBTyxNQUFNLE9BQU87QUFDekMsZ0JBQVEsSUFBSSwwQkFBMEIsTUFBTTtBQUFBLE1BQzlDLFNBQVMsR0FBUDtBQUNBLFlBQUksd0JBQU8sZ0NBQWdDLE1BQU07QUFDakQsZ0JBQVEsTUFBTSxnQ0FBZ0MsU0FBUyxDQUFDO0FBQUEsTUFDMUQ7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVBLGlDQUF5QztBQUN2QyxVQUFNLG1CQUFtQixLQUFLLFNBQVM7QUFFdkMsUUFBSSxrQkFBa0I7QUFDcEIsYUFBTztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BT1AsS0FBSyxTQUFTO0FBQUE7QUFBQTtBQUFBLE1BR2QsS0FBSyxTQUFTLFdBQVcsUUFBUSxRQUFRLEdBQUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBK0NwQyxLQUFLLFNBQVM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQXNIeEIsT0FBTztBQUNMLGFBQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQW9EQyxLQUFLLFNBQVM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQWdIeEI7QUFBQSxFQUNGO0FBQUEsRUFFQSw4QkFBc0M7QUFDcEMsV0FBTztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBbUJUO0FBQUEsRUFFQSx5QkFBaUM7QUFDL0IsV0FBTztBQUFBLEVBRVQsS0FBSyxTQUFTLHNCQUNWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQ0FNQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBc0NKO0FBQUEsRUFFQSwwQkFBa0M7QUFDaEMsV0FBTztBQUFBLEVBRVQsS0FBSyxTQUFTLHNCQUNWO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0NBS0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUE0Qko7QUFBQSxFQUVBLDZCQUFxQztBQUNuQyxXQUFPO0FBQUEsRUFFVCxLQUFLLFNBQVMsc0JBQ1Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFDQU1BO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQTJCSjtBQUFBLEVBRUEsNEJBQW9DO0FBQ2xDLFdBQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBbUNUO0FBQUEsRUFFQSw2QkFBcUM7QUFDbkMsV0FBTztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFRVDtBQUFBLEVBRUEsMEJBQWtDO0FBQ2hDLFdBQU87QUFBQSxFQUNUO0FBQUEsRUFFTSxhQUFhLFVBQWtCO0FBQUE7QUFDbkMsWUFBTSxnQkFBZ0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBeUJ0QixZQUFNLEtBQUssa0JBQWtCLEdBQUcsc0JBQXNCLGFBQWE7QUFBQSxJQUNyRTtBQUFBO0FBQ0Y7OztBQy81QkEsSUFBQUMsbUJBQW1DOzs7QUNGbkMsSUFBQUMsbUJBQW9DO0FBRTdCLElBQU0sYUFBTixjQUF5Qix1QkFBTTtBQUFBLEVBSXBDLFlBQVksS0FBVSxVQUEyQztBQUMvRCxVQUFNLEdBQUc7QUFDVCxTQUFLLFdBQVc7QUFBQSxFQUNsQjtBQUFBLEVBRUEsU0FBUztBQUNQLFVBQU0sRUFBRSxVQUFVLElBQUk7QUFFdEIsY0FBVSxTQUFTLE1BQU0sRUFBRSxNQUFNLGNBQWMsQ0FBQztBQUVoRCxRQUFJLHlCQUFRLFNBQVMsRUFDbEIsUUFBUSxPQUFPLEVBQ2Y7QUFBQSxNQUFRLENBQUMsU0FDUixLQUNHLFNBQVMsQ0FBQyxVQUFVO0FBQ25CLGFBQUssU0FBUztBQUFBLE1BQ2hCLENBQUMsRUFDQSxRQUFRLE1BQU07QUFBQSxJQUNuQjtBQUVGLFFBQUkseUJBQVEsU0FBUyxFQUNsQjtBQUFBLE1BQVUsQ0FBQyxRQUNWLElBQ0csY0FBYyxRQUFRLEVBQ3RCLE9BQU8sRUFDUCxRQUFRLE1BQU07QUFDYixhQUFLLE1BQU07QUFDWCxhQUFLLFNBQVMsS0FBSyxVQUFVLEVBQUU7QUFBQSxNQUNqQyxDQUFDO0FBQUEsSUFDTCxFQUNDO0FBQUEsTUFBVSxDQUFDLFFBQ1YsSUFBSSxjQUFjLFFBQVEsRUFBRSxRQUFRLE1BQU07QUFDeEMsYUFBSyxNQUFNO0FBQ1gsYUFBSyxTQUFTLElBQUk7QUFBQSxNQUNwQixDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0o7QUFBQSxFQUVBLFVBQVU7QUFDUixVQUFNLEVBQUUsVUFBVSxJQUFJO0FBQ3RCLGNBQVUsTUFBTTtBQUFBLEVBQ2xCO0FBQ0Y7QUFFTyxJQUFNLGlCQUFOLGNBQTZCLHVCQUFNO0FBQUEsRUFJeEMsWUFBWSxLQUFVLFNBQW1CLFVBQTJDO0FBQ2xGLFVBQU0sR0FBRztBQUNULFNBQUssV0FBVztBQUdoQixVQUFNLGtCQUE2QyxDQUFDO0FBQ3BELFlBQVEsUUFBUSxZQUFVO0FBQ3hCLHNCQUFnQixNQUFNLElBQUk7QUFBQSxJQUM1QixDQUFDO0FBRUQsU0FBSyxlQUFlLGVBQWU7QUFBQSxFQUNyQztBQUFBLEVBRUEsZUFBZSxTQUFvQztBQUNqRCxVQUFNLEVBQUUsVUFBVSxJQUFJO0FBRXRCLGNBQVUsU0FBUyxNQUFNLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQztBQUVsRCxRQUFJLGdCQUFnQixPQUFPLEtBQUssT0FBTyxFQUFFLENBQUMsS0FBSztBQUUvQyxVQUFNLFdBQVcsVUFBVSxTQUFTLFFBQVE7QUFDNUMsV0FBTyxRQUFRLE9BQU8sRUFBRSxRQUFRLENBQUMsQ0FBQyxLQUFLLEtBQUssTUFBTTtBQUNoRCxZQUFNLFNBQVMsU0FBUyxTQUFTLFVBQVU7QUFBQSxRQUN6QyxPQUFPO0FBQUEsUUFDUCxNQUFNO0FBQUEsTUFDUixDQUFDO0FBQ0QsVUFBSSxRQUFRLGVBQWU7QUFDekIsZUFBTyxXQUFXO0FBQUEsTUFDcEI7QUFBQSxJQUNGLENBQUM7QUFFRCxhQUFTLGlCQUFpQixVQUFVLENBQUMsVUFBVTtBQUM3QyxzQkFBaUIsTUFBTSxPQUE2QjtBQUNwRCxXQUFLLFNBQVM7QUFBQSxJQUNoQixDQUFDO0FBRUQsUUFBSSx5QkFBUSxTQUFTLEVBQ2xCO0FBQUEsTUFBVSxDQUFDLFFBQ1YsSUFDRyxjQUFjLFFBQVEsRUFDdEIsT0FBTyxFQUNQLFFBQVEsTUFBTTtBQUNiLGFBQUssTUFBTTtBQUNYLGFBQUssU0FBUyxhQUFhO0FBQUEsTUFDN0IsQ0FBQztBQUFBLElBQ0wsRUFDQztBQUFBLE1BQVUsQ0FBQyxRQUNWLElBQUksY0FBYyxRQUFRLEVBQUUsUUFBUSxNQUFNO0FBQ3hDLGFBQUssTUFBTTtBQUNYLGFBQUssU0FBUyxJQUFJO0FBQUEsTUFDcEIsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNKO0FBQUEsRUFFQSxTQUFTO0FBQUEsRUFFVDtBQUFBLEVBRUEsVUFBVTtBQUNSLFVBQU0sRUFBRSxVQUFVLElBQUk7QUFDdEIsY0FBVSxNQUFNO0FBQUEsRUFDbEI7QUFDRjs7O0FEN0dPLElBQU0sdUJBQU4sTUFBMkI7QUFBQSxFQUloQyxZQUFZLEtBQVUsVUFBZ0M7QUFDcEQsU0FBSyxNQUFNO0FBQ1gsU0FBSyxXQUFXO0FBQUEsRUFDbEI7QUFBQSxFQUVNLHVCQUF1QjtBQUFBO0FBQzNCLFVBQUk7QUFFRixjQUFNLGdCQUFnQixNQUFNLEtBQUssb0JBQW9CO0FBRXJELFlBQUksQ0FBQyxlQUFlO0FBQ2xCLGlCQUFPO0FBQUEsUUFDVDtBQUdBLGNBQU0sYUFBYSxNQUFNLEtBQUssNEJBQTRCLGFBQWE7QUFHdkUsY0FBTSxLQUFLLHlCQUF5QixlQUFlLFVBQVU7QUFHN0QsY0FBTSxLQUFLLHdCQUF3QixVQUFVO0FBRTdDLFlBQUksd0JBQU8sV0FBVyxjQUFjLG1DQUFtQztBQUN2RSxnQkFBUTtBQUFBLFVBQ04sbUJBQW1CLGNBQWMsaUJBQWlCO0FBQUEsUUFDcEQ7QUFFQSxlQUFPO0FBQUEsTUFDVCxTQUFTLE9BQVA7QUFDQSxnQkFBUSxNQUFNLDBCQUEwQixLQUFLO0FBQzdDLFlBQUksd0JBQU8sMEJBQTBCLE1BQU0sU0FBUztBQUNwRCxlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRWMsc0JBS0o7QUFBQTtBQXBEWjtBQXFESSxVQUFJO0FBQ0YsY0FBTSxhQUFhLE1BQU0sS0FBSztBQUFBLFVBQzVCO0FBQUEsVUFDQTtBQUFBLFVBQ0EsQ0FBQyxVQUFVLE1BQU0sS0FBSyxFQUFFLFNBQVM7QUFBQSxVQUNqQztBQUFBLFFBQ0Y7QUFFQSxZQUFJLENBQUM7QUFBWSxpQkFBTztBQUV4QixjQUFNLGVBQWUsTUFBTSxLQUFLO0FBQUEsVUFDOUI7QUFBQSxVQUNBO0FBQUEsVUFDQSxDQUFDLFFBQVEsVUFBVSxVQUFVLFFBQVE7QUFBQSxRQUN2QztBQUVBLFlBQUksQ0FBQztBQUFjLGlCQUFPO0FBRTFCLGNBQU0sYUFBYSxNQUFNLEtBQUs7QUFBQSxVQUM1QjtBQUFBLFVBQ0E7QUFBQSxVQUNBLENBQUMsVUFBVSxVQUFVLEtBQUssTUFBTSxLQUFLLENBQUM7QUFBQSxVQUN0QztBQUFBLFFBQ0Y7QUFFQSxZQUFJLENBQUM7QUFBWSxpQkFBTztBQUV4QixjQUFNLGFBQVcsZ0JBQVcsTUFBTSxLQUFLLEVBQUUsQ0FBQyxNQUF6QixtQkFBNEIsV0FBVSxRQUFRLFVBQVU7QUFFekUsZUFBTztBQUFBLFVBQ0w7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxRQUNGO0FBQUEsTUFDRixTQUFTLE9BQVA7QUFDQSxnQkFBUSxNQUFNLHVDQUF1QyxLQUFLO0FBQzFELGVBQU87QUFBQSxNQUNUO0FBQUEsSUFDRjtBQUFBO0FBQUEsRUFFYyxxQkFDWixPQUNBLFNBQ0EsV0FDQSxjQUN3QjtBQUFBO0FBQ3hCLGFBQU8sSUFBSSxRQUFRLENBQUMsWUFBWTtBQUM5QixjQUFNLFFBQVEsSUFBSSxXQUFXLEtBQUssS0FBSyxDQUFDLFdBQVc7QUFDakQsY0FBSSxXQUFXLE1BQU07QUFFbkIsb0JBQVEsSUFBSTtBQUNaO0FBQUEsVUFDRjtBQUVBLGNBQUksQ0FBQyxVQUFVLE1BQU0sR0FBRztBQUN0QixnQkFBSSx3QkFBTyxZQUFZO0FBRXZCLGlCQUFLLHFCQUFxQixPQUFPLFNBQVMsV0FBVyxZQUFZLEVBQzlELEtBQUssT0FBTztBQUNmO0FBQUEsVUFDRjtBQUVBLGtCQUFRLE9BQU8sS0FBSyxDQUFDO0FBQUEsUUFDdkIsQ0FBQztBQUdELGNBQU0sUUFBUSxRQUFRLEtBQUs7QUFDM0IsY0FBTSxZQUFZLE1BQU0sVUFBVSxVQUFVO0FBQzVDLGtCQUFVLFFBQVEsT0FBTztBQUV6QixjQUFNLEtBQUs7QUFBQSxNQUNiLENBQUM7QUFBQSxJQUNIO0FBQUE7QUFBQSxFQUVjLGtCQUNaLE9BQ0EsU0FDQSxTQUN3QjtBQUFBO0FBQ3hCLGFBQU8sSUFBSSxRQUFRLENBQUMsWUFBWTtBQUM5QixjQUFNLFFBQVEsSUFBSSxlQUFlLEtBQUssS0FBSyxTQUFTLENBQUMsV0FBVztBQUM5RCxjQUFJLFdBQVcsTUFBTTtBQUVuQixvQkFBUSxJQUFJO0FBQ1o7QUFBQSxVQUNGO0FBRUEsY0FBSSxRQUFRLFNBQVMsTUFBTSxHQUFHO0FBQzVCLG9CQUFRLE1BQU07QUFBQSxVQUNoQixPQUFPO0FBQ0wsZ0JBQUksd0JBQU8seUJBQXlCLFFBQVEsS0FBSyxJQUFJLEdBQUc7QUFFeEQsaUJBQUssa0JBQWtCLE9BQU8sU0FBUyxPQUFPLEVBQzNDLEtBQUssT0FBTztBQUFBLFVBQ2pCO0FBQUEsUUFDRixDQUFDO0FBR0QsY0FBTSxRQUFRLFFBQVEsS0FBSztBQUMzQixjQUFNLFlBQVksTUFBTSxVQUFVLFVBQVU7QUFDNUMsa0JBQVUsUUFBUSxPQUFPO0FBRXpCLGNBQU0sS0FBSztBQUFBLE1BQ2IsQ0FBQztBQUFBLElBQ0g7QUFBQTtBQUFBLEVBRWMsNEJBQTRCLGVBS3RCO0FBQUE7QUFDbEIsWUFBTSxhQUFhLEdBQUcsY0FBYyxjQUFjLGNBQWMsZ0JBQWdCLGNBQWM7QUFFOUYsVUFBSTtBQUNGLGNBQU0sS0FBSyxJQUFJLE1BQU0sYUFBYSxVQUFVO0FBQzVDLGdCQUFRLElBQUksMEJBQTBCLFlBQVk7QUFDbEQsZUFBTztBQUFBLE1BQ1QsU0FBUyxPQUFQO0FBRUEsZ0JBQVEsSUFBSSw0Q0FBNEMsWUFBWTtBQUNwRSxlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRWMseUJBQ1osZUFNQSxZQUNlO0FBQUE7QUFDZixZQUFNLFdBQVcsR0FBRyxjQUFjLGNBQWM7QUFDaEQsWUFBTSxVQUFVLEtBQUssOEJBQThCLGFBQWE7QUFFaEUsVUFBSTtBQUNGLGNBQU0sS0FBSyxJQUFJLE1BQU0sT0FBTyxVQUFVLE9BQU87QUFDN0MsZ0JBQVEsSUFBSSw0QkFBNEIsVUFBVTtBQUFBLE1BQ3BELFNBQVMsT0FBUDtBQUNBLGdCQUFRLE1BQU0sbUNBQW1DLE9BQU87QUFDeEQsY0FBTTtBQUFBLE1BQ1I7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVjLHdCQUF3QixZQUFtQztBQUFBO0FBQ3ZFLFlBQU0sa0JBQWtCLEdBQUc7QUFFM0IsVUFBSTtBQUNGLGNBQU0sS0FBSyxJQUFJLE1BQU0sYUFBYSxlQUFlO0FBQ2pELGdCQUFRLElBQUksK0JBQStCLGlCQUFpQjtBQUFBLE1BQzlELFNBQVMsT0FBUDtBQUVBLGdCQUFRLElBQUksc0NBQXNDLGlCQUFpQjtBQUFBLE1BQ3JFO0FBQUEsSUFDRjtBQUFBO0FBQUEsRUFFUSw4QkFBOEIsZUFLM0I7QUFDVCxVQUFNLG1CQUFtQixLQUFLLFNBQVM7QUFFdkMsV0FBTztBQUFBLEVBRVQsbUJBQ0ksY0FBYyxjQUFjO0FBQUEsZUFDbkIsY0FBYztBQUFBLGVBQ2QsY0FBYyxnQkFBZ0IsY0FBYztBQUFBLGVBQzVDLGNBQWM7QUFBQSxtQkFDVixjQUFjO0FBQUE7QUFBQSxVQUV2QixLQUFLLFNBQVM7QUFBQSx1QkFDRCxLQUFLLFNBQVMsdUJBQy9CLGNBQWMsY0FBYztBQUFBLFNBQ3pCLGNBQWM7QUFBQSxXQUVaLElBQUksS0FBSyxFQUFFLFlBQVk7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQUk3QixjQUFjO0FBQUEsS0FDZCxLQUFLLFNBQVMsc0JBQXNCLGNBQWMsY0FDakQsY0FBYyxnQkFDWixjQUFjO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFJbEIsY0FBYztBQUFBO0FBQUE7QUFBQSxpQkFHRCxjQUFjO0FBQUEsWUFDbkIsY0FBYyxnQkFBZ0IsY0FBYztBQUFBLGNBQzFDLEtBQUssU0FBUztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBc0IxQjtBQUNGOzs7QUUvUUEsSUFBQUMsbUJBQTJCO0FBR3BCLElBQU0sc0JBQU4sTUFBMEI7QUFBQSxFQUcvQixZQUFZLEtBQVU7QUFDcEIsU0FBSyxNQUFNO0FBQUEsRUFDYjtBQUFBLEVBRUEsMEJBQTBCLFNBQTJCO0FBRW5ELFVBQU0sYUFBYTtBQUNuQixVQUFNLGVBQWUsbUNBQVMsTUFBTTtBQUVwQyxRQUFJLGNBQWM7QUFDaEIsWUFBTSxZQUFZLGFBQWEsQ0FBQyxFQUFFLEtBQUs7QUFDdkMsWUFBTSxlQUFlLFVBQ2xCLFFBQVEsZ0JBQWdCLEVBQUUsRUFDMUIsUUFBUSxjQUFjLEVBQUUsRUFDeEIsTUFBTSxJQUFJLEVBQ1YsSUFBSSxDQUFDLFNBQVMsS0FBSyxLQUFLLENBQUMsRUFDekIsT0FBTyxDQUFDLFNBQVMsS0FBSyxTQUFTLENBQUM7QUFFbkMsYUFBTztBQUFBLElBQ1Q7QUFFQSxXQUFPLENBQUM7QUFBQSxFQUNWO0FBQUEsRUFFTSw0QkFDSixVQUNtQztBQUFBO0FBQ25DLGNBQVEsSUFBSSxxQ0FBcUMsVUFBVTtBQUUzRCxVQUFJO0FBRUYsY0FBTSxjQUFjLE1BQU0sS0FBSyxnQkFBZ0IsUUFBUTtBQUV2RCxZQUFJLFlBQVksV0FBVyxHQUFHO0FBQzVCLGtCQUFRLElBQUksOEJBQThCLFVBQVU7QUFDcEQsaUJBQU8sQ0FBQztBQUFBLFFBQ1Y7QUFHQSxjQUFNLGlCQUEyQyxDQUFDO0FBRWxELG1CQUFXLFFBQVEsYUFBYTtBQUM5QixjQUFJO0FBQ0Ysa0JBQU0sVUFBVSxNQUFNLEtBQUssSUFBSSxNQUFNLEtBQUssSUFBSTtBQUM5QyxrQkFBTSxhQUFhLEtBQUssMEJBQTBCLE9BQU87QUFFekQsZ0JBQUksV0FBVyxTQUFTLEdBQUc7QUFDekIsNkJBQWUsS0FBSyxRQUFRLElBQUk7QUFBQSxZQUNsQztBQUFBLFVBQ0YsU0FBUyxPQUFQO0FBQ0Esb0JBQVEsTUFBTSxzQkFBc0IsS0FBSyxTQUFTLEtBQUs7QUFBQSxVQUN6RDtBQUFBLFFBQ0Y7QUFFQSxnQkFBUTtBQUFBLFVBQ04sNkJBQ0UsT0FBTyxLQUFLLGNBQWMsRUFBRSw0QkFDUjtBQUFBLFFBQ3hCO0FBQ0EsZUFBTztBQUFBLE1BQ1QsU0FBUyxPQUFQO0FBQ0EsZ0JBQVE7QUFBQSxVQUNOLDBDQUEwQztBQUFBLFVBQzFDO0FBQUEsUUFDRjtBQUNBLGVBQU8sQ0FBQztBQUFBLE1BQ1Y7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVNLGdCQUFnQixVQUFvQztBQUFBO0FBQ3hELFlBQU0sUUFBaUIsQ0FBQztBQUd4QixZQUFNLFFBQVEsS0FBSyxJQUFJLE1BQU0saUJBQWlCO0FBRTlDLGlCQUFXLFFBQVEsT0FBTztBQUV4QixZQUNFLEtBQUssS0FBSyxTQUFTLFFBQVEsTUFDMUIsTUFBTSxLQUFLLG9CQUFvQixNQUFNLFFBQVEsSUFDOUM7QUFDQSxnQkFBTSxLQUFLLElBQUk7QUFBQSxRQUNqQjtBQUFBLE1BQ0Y7QUFFQSxhQUFPO0FBQUEsSUFDVDtBQUFBO0FBQUEsRUFFYyxvQkFDWixNQUNBLFVBQ2tCO0FBQUE7QUFDbEIsVUFBSTtBQUNGLGNBQU0sVUFBVSxNQUFNLEtBQUssSUFBSSxNQUFNLEtBQUssSUFBSTtBQUM5QyxjQUFNLG1CQUFtQixRQUFRLE1BQU0sdUJBQXVCO0FBRTlELFlBQUksa0JBQWtCO0FBQ3BCLGdCQUFNLGNBQWMsaUJBQWlCLENBQUM7QUFFdEMsaUJBQ0UsWUFBWSxTQUFTLGNBQWMsVUFBVSxLQUM3QyxZQUFZLFNBQVMsYUFBYSxVQUFVO0FBQUEsUUFFaEQ7QUFFQSxlQUFPO0FBQUEsTUFDVCxTQUFTLE9BQVA7QUFDQSxnQkFBUTtBQUFBLFVBQ04sMEJBQTBCLEtBQUssMEJBQTBCO0FBQUEsVUFDekQ7QUFBQSxRQUNGO0FBQ0EsZUFBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVNLHdCQUNKLFVBQ0EsZ0JBQ2lCO0FBQUE7QUFDakIsWUFBTSxXQUFxQixDQUFDO0FBQzVCLFlBQU0sY0FBd0MsQ0FBQztBQUcvQyxpQkFBVyxDQUFDLFVBQVUsS0FBSyxLQUFLLE9BQU8sUUFBUSxjQUFjLEdBQUc7QUFDOUQsbUJBQVcsUUFBUSxPQUFPO0FBQ3hCLGNBQUksQ0FBQyxTQUFTLFNBQVMsSUFBSSxHQUFHO0FBQzVCLHFCQUFTLEtBQUssSUFBSTtBQUNsQix3QkFBWSxJQUFJLElBQUksQ0FBQztBQUFBLFVBQ3ZCO0FBQ0Esc0JBQVksSUFBSSxFQUFFLEtBQUssUUFBUTtBQUFBLFFBQ2pDO0FBQUEsTUFDRjtBQUdBLGVBQVMsS0FBSztBQUdkLFVBQUksVUFBVSx3QkFBd0I7QUFBQTtBQUFBO0FBQ3RDLGlCQUFXLHVCQUF1QixTQUFTO0FBQUE7QUFBQTtBQUUzQyxpQkFBVyxRQUFRLFVBQVU7QUFDM0IsbUJBQVcsTUFBTTtBQUFBO0FBQ2pCLG1CQUFXLGdCQUFnQixZQUFZLElBQUksRUFBRSxLQUFLLElBQUk7QUFBQTtBQUFBO0FBQ3RELG1CQUFXO0FBQUE7QUFBQTtBQUNYLG1CQUFXO0FBQUE7QUFBQTtBQUNYLG1CQUFXO0FBQUE7QUFBQTtBQUNYLG1CQUFXO0FBQUE7QUFBQTtBQUFBLE1BQ2I7QUFFQSxhQUFPO0FBQUEsSUFDVDtBQUFBO0FBQUEsRUFFTSwwQkFBMEIsVUFBaUM7QUFBQTtBQUMvRCxVQUFJO0FBQ0YsY0FBTSxpQkFBaUIsTUFBTSxLQUFLLDRCQUE0QixRQUFRO0FBRXRFLFlBQUksT0FBTyxLQUFLLGNBQWMsRUFBRSxXQUFXLEdBQUc7QUFDNUMsa0JBQVEsSUFBSSxtQ0FBbUMsVUFBVTtBQUN6RDtBQUFBLFFBQ0Y7QUFFQSxjQUFNLGVBQWUsTUFBTSxLQUFLO0FBQUEsVUFDOUI7QUFBQSxVQUNBO0FBQUEsUUFDRjtBQUdBLGNBQU0sV0FBVyxHQUFHO0FBQ3BCLGNBQU0sV0FBVyxXQUFXLFlBQVk7QUFFeEMsWUFBSTtBQUNGLGdCQUFNLEtBQUssSUFBSSxNQUFNLE9BQU8sVUFBVSxZQUFZO0FBQ2xELGtCQUFRLElBQUksa0NBQWtDLFVBQVU7QUFBQSxRQUMxRCxTQUFTLE9BQVA7QUFFQSxnQkFBTSxlQUFlLEtBQUssSUFBSSxNQUFNLHNCQUFzQixRQUFRO0FBQ2xFLGNBQUksZ0JBQWdCLHdCQUF3Qix3QkFBTztBQUNqRCxrQkFBTSxLQUFLLElBQUksTUFBTSxPQUFPLGNBQWMsWUFBWTtBQUN0RCxvQkFBUSxJQUFJLGtDQUFrQyxVQUFVO0FBQUEsVUFDMUQ7QUFBQSxRQUNGO0FBQUEsTUFDRixTQUFTLE9BQVA7QUFDQSxnQkFBUTtBQUFBLFVBQ04sOENBQThDO0FBQUEsVUFDOUM7QUFBQSxRQUNGO0FBQ0EsY0FBTTtBQUFBLE1BQ1I7QUFBQSxJQUNGO0FBQUE7QUFDRjs7O0FDck1BLElBQUFDLG1CQUEyQjtBQUdwQixJQUFNLGlCQUFOLE1BQXFCO0FBQUEsRUFHMUIsWUFBWSxLQUFVO0FBQ3BCLFNBQUssTUFBTTtBQUFBLEVBQ2I7QUFBQSxFQUVBLHNCQUNFLFNBQzZEO0FBRTdELFVBQU0sZ0JBQWdCO0FBQ3RCLFVBQU0sVUFBVSxtQ0FBUyxNQUFNO0FBRS9CLFFBQUksQ0FBQyxTQUFTO0FBQ1osYUFBTyxDQUFDO0FBQUEsSUFDVjtBQUVBLFVBQU0sa0JBQWtCLFFBQVEsQ0FBQztBQUNqQyxVQUFNLFdBQVcsQ0FBQztBQUdsQixVQUFNLGFBQWE7QUFDbkIsVUFBTSxlQUFlLGdCQUFnQixNQUFNLFVBQVU7QUFFckQsUUFBSSxjQUFjO0FBQ2hCLGlCQUFXLFNBQVMsY0FBYztBQUNoQyxjQUFNLE9BQU8sTUFDVixLQUFLLEVBQ0wsTUFBTSxJQUFJLEVBQ1YsT0FBTyxDQUFDLFFBQVEsSUFBSSxXQUFXLEdBQUcsQ0FBQztBQUN0QyxjQUFNLGFBQWEsS0FBSyxlQUFlLElBQUk7QUFDM0MsaUJBQVMsS0FBSyxHQUFHLFVBQVU7QUFBQSxNQUM3QjtBQUFBLElBQ0Y7QUFFQSxXQUFPO0FBQUEsRUFDVDtBQUFBLEVBRVEsZUFDTixNQUM2RDtBQUM3RCxRQUFJLEtBQUssU0FBUztBQUFHLGFBQU8sQ0FBQztBQUU3QixVQUFNLFdBQVcsQ0FBQztBQUVsQixhQUFTLElBQUksR0FBRyxJQUFJLEtBQUssUUFBUSxLQUFLO0FBRXBDLFlBQU0sTUFBTSxLQUFLLENBQUM7QUFDbEIsWUFBTSxVQUFVLElBQ2IsTUFBTSxHQUFHLEVBQ1QsSUFBSSxDQUFDLFFBQVEsSUFBSSxLQUFLLENBQUMsRUFDdkIsT0FBTyxDQUFDLFFBQVEsR0FBRztBQUV0QixVQUFJLFFBQVEsVUFBVSxHQUFHO0FBQ3ZCLGNBQU0sQ0FBQyxNQUFNLFlBQVksU0FBUyxTQUFTLElBQUk7QUFDL0MsWUFBSSxRQUFRLGNBQWMsS0FBSyxZQUFZLElBQUksR0FBRztBQUNoRCxtQkFBUyxLQUFLLEVBQUUsTUFBTSxZQUFZLE9BQU8sQ0FBQztBQUFBLFFBQzVDO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFFQSxXQUFPO0FBQUEsRUFDVDtBQUFBLEVBRVEsWUFBWSxZQUE2QjtBQUMvQyxVQUFNLFlBQVk7QUFDbEIsV0FBTyxVQUFVLEtBQUssVUFBVSxLQUFLLENBQUMsTUFBTSxLQUFLLE1BQU0sVUFBVSxDQUFDO0FBQUEsRUFDcEU7QUFBQSxFQUVNLHdCQUNKLFVBQ0EsV0FDQSxTQUdBO0FBQUE7QUFDQSxjQUFRLElBQUksaUNBQWlDLFVBQVU7QUFFdkQsVUFBSTtBQUVGLGNBQU0sY0FBYyxNQUFNLEtBQUssZ0JBQWdCLFFBQVE7QUFFdkQsWUFBSSxZQUFZLFdBQVcsR0FBRztBQUM1QixrQkFBUSxJQUFJLDhCQUE4QixVQUFVO0FBQ3BELGlCQUFPLENBQUM7QUFBQSxRQUNWO0FBR0EsY0FBTSxjQUtELENBQUM7QUFFTixtQkFBVyxRQUFRLGFBQWE7QUFDOUIsY0FBSTtBQUNGLGtCQUFNLFVBQVUsTUFBTSxLQUFLLElBQUksTUFBTSxLQUFLLElBQUk7QUFDOUMsa0JBQU0sV0FBVyxLQUFLLHNCQUFzQixPQUFPO0FBR25ELGtCQUFNLHFCQUFxQixTQUFTLElBQUksQ0FBQyxZQUFhLGlDQUNqRCxVQURpRDtBQUFBLGNBRXBELFFBQVEsS0FBSztBQUFBLFlBQ2YsRUFBRTtBQUVGLHdCQUFZLEtBQUssR0FBRyxrQkFBa0I7QUFBQSxVQUN4QyxTQUFTLE9BQVA7QUFDQSxvQkFBUSxNQUFNLHNCQUFzQixLQUFLLFNBQVMsS0FBSztBQUFBLFVBQ3pEO0FBQUEsUUFDRjtBQUdBLFlBQUksbUJBQW1CO0FBQ3ZCLFlBQUksYUFBYSxTQUFTO0FBQ3hCLDZCQUFtQixLQUFLO0FBQUEsWUFDdEI7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBR0EseUJBQWlCO0FBQUEsVUFDZixDQUFDLEdBQUcsTUFBTSxJQUFJLEtBQUssRUFBRSxJQUFJLEVBQUUsUUFBUSxJQUFJLElBQUksS0FBSyxFQUFFLElBQUksRUFBRSxRQUFRO0FBQUEsUUFDbEU7QUFFQSxnQkFBUTtBQUFBLFVBQ04sU0FBUyxpQkFBaUIsZ0NBQWdDO0FBQUEsUUFDNUQ7QUFDQSxlQUFPO0FBQUEsTUFDVCxTQUFTLE9BQVA7QUFDQSxnQkFBUSxNQUFNLHNDQUFzQyxhQUFhLEtBQUs7QUFDdEUsZUFBTyxDQUFDO0FBQUEsTUFDVjtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRWMsZ0JBQWdCLFVBQW9DO0FBQUE7QUFDaEUsWUFBTSxRQUFpQixDQUFDO0FBR3hCLFlBQU0sUUFBUSxLQUFLLElBQUksTUFBTSxpQkFBaUI7QUFFOUMsaUJBQVcsUUFBUSxPQUFPO0FBRXhCLFlBQ0UsS0FBSyxLQUFLLFNBQVMsUUFBUSxNQUMxQixNQUFNLEtBQUssb0JBQW9CLE1BQU0sUUFBUSxJQUM5QztBQUNBLGdCQUFNLEtBQUssSUFBSTtBQUFBLFFBQ2pCO0FBQUEsTUFDRjtBQUVBLGFBQU87QUFBQSxJQUNUO0FBQUE7QUFBQSxFQUVjLG9CQUNaLE1BQ0EsVUFDa0I7QUFBQTtBQUNsQixVQUFJO0FBQ0YsY0FBTSxVQUFVLE1BQU0sS0FBSyxJQUFJLE1BQU0sS0FBSyxJQUFJO0FBQzlDLGNBQU0sbUJBQW1CLFFBQVEsTUFBTSx1QkFBdUI7QUFFOUQsWUFBSSxrQkFBa0I7QUFDcEIsZ0JBQU0sY0FBYyxpQkFBaUIsQ0FBQztBQUV0QyxpQkFDRSxZQUFZLFNBQVMsY0FBYyxVQUFVLEtBQzdDLFlBQVksU0FBUyxhQUFhLFVBQVU7QUFBQSxRQUVoRDtBQUVBLGVBQU87QUFBQSxNQUNULFNBQVMsT0FBUDtBQUNBLGdCQUFRO0FBQUEsVUFDTiwwQkFBMEIsS0FBSywwQkFBMEI7QUFBQSxVQUN6RDtBQUFBLFFBQ0Y7QUFDQSxlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRVEsa0JBQ04sVUFNQSxXQUNBLFNBTUM7QUFDRCxXQUFPLFNBQVMsT0FBTyxDQUFDLFlBQVk7QUFDbEMsWUFBTSxjQUFjLElBQUksS0FBSyxRQUFRLElBQUksRUFBRSxRQUFRO0FBRW5ELFVBQUksYUFBYSxjQUFjLElBQUksS0FBSyxTQUFTLEVBQUUsUUFBUSxHQUFHO0FBQzVELGVBQU87QUFBQSxNQUNUO0FBRUEsVUFBSSxXQUFXLGNBQWMsSUFBSSxLQUFLLE9BQU8sRUFBRSxRQUFRLEdBQUc7QUFDeEQsZUFBTztBQUFBLE1BQ1Q7QUFFQSxhQUFPO0FBQUEsSUFDVCxDQUFDO0FBQUEsRUFDSDtBQUFBLEVBRU0sd0JBQ0osVUFDQSxVQU1pQjtBQUFBO0FBQ2pCLFVBQUksU0FBUyxXQUFXLEdBQUc7QUFDekIsZUFBTyx5QkFBeUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUNsQztBQUdBLFlBQU0sV0FBVyxTQUFTLE9BQU8sQ0FBQyxLQUFLLFlBQVk7QUFDakQsWUFBSSxDQUFDLElBQUksUUFBUSxNQUFNLEdBQUc7QUFDeEIsY0FBSSxRQUFRLE1BQU0sSUFBSSxDQUFDO0FBQUEsUUFDekI7QUFDQSxZQUFJLFFBQVEsTUFBTSxFQUFFLEtBQUssT0FBTztBQUNoQyxlQUFPO0FBQUEsTUFDVCxHQUFHLENBQUMsQ0FBb0M7QUFFeEMsVUFBSSxVQUFVLHlCQUF5QjtBQUFBO0FBQUE7QUFDdkMsaUJBQVcsc0JBQXNCLFNBQVM7QUFBQTtBQUFBO0FBRzFDLGlCQUFXLENBQUMsUUFBUSxLQUFLLEtBQUssT0FBTyxRQUFRLFFBQVEsR0FBRztBQUN0RCxtQkFBVyxNQUFNLE9BQU8sT0FBTyxDQUFDLEVBQUUsWUFBWSxJQUFJLE9BQU8sTUFBTSxDQUFDLE1BQzlELE1BQU07QUFBQTtBQUFBO0FBRVIsbUJBQVc7QUFBQTtBQUNYLG1CQUFXO0FBQUE7QUFFWCxtQkFBVyxRQUFRLE9BQU87QUFDeEIscUJBQVcsS0FBSyxLQUFLLFVBQVUsS0FBSyxnQkFBZ0IsS0FBSztBQUFBO0FBQUEsUUFDM0Q7QUFDQSxtQkFBVztBQUFBO0FBQUEsTUFDYjtBQUVBLGFBQU87QUFBQSxJQUNUO0FBQUE7QUFBQSxFQUVNLDBCQUNKLFVBQ0EsV0FDQSxTQUNlO0FBQUE7QUFDZixVQUFJO0FBQ0YsY0FBTSxXQUFXLE1BQU0sS0FBSztBQUFBLFVBQzFCO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxRQUNGO0FBRUEsY0FBTSxpQkFBaUIsTUFBTSxLQUFLO0FBQUEsVUFDaEM7QUFBQSxVQUNBO0FBQUEsUUFDRjtBQUdBLGNBQU0sV0FBVyxHQUFHO0FBQ3BCLGNBQU0sV0FBVyxXQUFXLFlBQVk7QUFFeEMsWUFBSTtBQUNGLGdCQUFNLEtBQUssSUFBSSxNQUFNLE9BQU8sVUFBVSxjQUFjO0FBQ3BELGtCQUFRLElBQUksbUNBQW1DLFVBQVU7QUFBQSxRQUMzRCxTQUFTLE9BQVA7QUFFQSxnQkFBTSxlQUFlLEtBQUssSUFBSSxNQUFNLHNCQUFzQixRQUFRO0FBQ2xFLGNBQUksZ0JBQWdCLHdCQUF3Qix3QkFBTztBQUNqRCxrQkFBTSxLQUFLLElBQUksTUFBTSxPQUFPLGNBQWMsY0FBYztBQUN4RCxvQkFBUSxJQUFJLG1DQUFtQyxVQUFVO0FBQUEsVUFDM0Q7QUFBQSxRQUNGO0FBQUEsTUFDRixTQUFTLE9BQVA7QUFDQSxnQkFBUTtBQUFBLFVBQ04sK0NBQStDO0FBQUEsVUFDL0M7QUFBQSxRQUNGO0FBQ0EsY0FBTTtBQUFBLE1BQ1I7QUFBQSxJQUNGO0FBQUE7QUFDRjs7O0FDelNBLElBQUFDLG1CQUEyQjtBQUVwQixJQUFNLHdCQUFOLE1BQTRCO0FBQUEsRUFHakMsWUFBWSxLQUFVO0FBQ3BCLFNBQUssTUFBTTtBQUFBLEVBQ2I7QUFBQSxFQUVNLHNCQUVKO0FBQUE7QUFDQSxjQUFRLElBQUkscUNBQXFDO0FBRWpELFVBQUk7QUFDRixjQUFNLFFBQVEsSUFBSSxLQUFLO0FBQ3ZCLGNBQU0sY0FBYyxNQUFNLFlBQVksRUFBRSxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBR3BELGNBQU0sUUFBUSxLQUFLLElBQUksTUFBTSxpQkFBaUI7QUFDOUMsY0FBTSxjQUF1QixDQUFDO0FBRTlCLG1CQUFXLFFBQVEsT0FBTztBQUN4QixnQkFBTSxXQUFXLEtBQUssb0JBQW9CLEtBQUssSUFBSTtBQUNuRCxjQUFJLGFBQWEsYUFBYTtBQUM1Qix3QkFBWSxLQUFLLElBQUk7QUFBQSxVQUN2QjtBQUFBLFFBQ0Y7QUFHQSxjQUFNLGFBQ0osQ0FBQztBQUVILG1CQUFXLFFBQVEsYUFBYTtBQUM5QixnQkFBTSxXQUFXLE1BQU0sS0FBSyxvQkFBb0IsSUFBSTtBQUNwRCxjQUFJLFVBQVU7QUFDWix1QkFBVyxLQUFLLFFBQVE7QUFBQSxVQUMxQjtBQUFBLFFBQ0Y7QUFFQSxnQkFBUSxJQUFJLFNBQVMsV0FBVyxzQ0FBc0M7QUFDdEUsZUFBTztBQUFBLE1BQ1QsU0FBUyxPQUFQO0FBQ0EsZ0JBQVEsTUFBTSxxQ0FBcUMsS0FBSztBQUN4RCxlQUFPLENBQUM7QUFBQSxNQUNWO0FBQUEsSUFDRjtBQUFBO0FBQUEsRUFFTSx5QkFDSixVQUNBLE1BQ2dEO0FBQUE7QUFDaEQsY0FBUSxJQUFJLCtCQUErQixvQkFBb0IsTUFBTTtBQUVyRSxVQUFJO0FBRUYsY0FBTSxjQUFjLE1BQU0sS0FBSyx1QkFBdUIsVUFBVSxJQUFJO0FBRXBFLGNBQU0sYUFBb0QsQ0FBQztBQUUzRCxtQkFBVyxRQUFRLGFBQWE7QUFDOUIsZ0JBQU0sVUFBVSxNQUFNLEtBQUssSUFBSSxNQUFNLEtBQUssSUFBSTtBQUM5QyxnQkFBTSxXQUFXLEtBQUssa0JBQWtCLE1BQU0sT0FBTztBQUVyRCxxQkFBVyxLQUFLO0FBQUEsWUFDZCxNQUFNLEtBQUs7QUFBQSxZQUNYLE1BQU07QUFBQSxVQUNSLENBQUM7QUFBQSxRQUNIO0FBRUEsZ0JBQVE7QUFBQSxVQUNOLFNBQVMsV0FBVyxnQ0FBZ0MsZUFBZTtBQUFBLFFBQ3JFO0FBQ0EsZUFBTztBQUFBLE1BQ1QsU0FBUyxPQUFQO0FBQ0EsZ0JBQVE7QUFBQSxVQUNOLHFDQUFxQyxlQUFlO0FBQUEsVUFDcEQ7QUFBQSxRQUNGO0FBQ0EsZUFBTyxDQUFDO0FBQUEsTUFDVjtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRVEsb0JBQW9CLFVBQWlDO0FBRTNELFVBQU0sWUFBWTtBQUNsQixVQUFNLFVBQVUsU0FBUyxNQUFNLFNBQVM7QUFDeEMsV0FBTyxVQUFVLFFBQVEsUUFBUSxTQUFTLENBQUMsSUFBSTtBQUFBLEVBQ2pEO0FBQUEsRUFFYyxvQkFDWixNQUNpRTtBQUFBO0FBQ2pFLFVBQUk7QUFDRixjQUFNLFVBQVUsTUFBTSxLQUFLLElBQUksTUFBTSxLQUFLLElBQUk7QUFHOUMsY0FBTSxXQUFXLEtBQUssa0JBQWtCLE1BQU0sT0FBTztBQUdyRCxjQUFNLFdBQ0osS0FBSywyQkFBMkIsT0FBTyxLQUN2QyxLQUFLLHdCQUF3QixLQUFLLElBQUk7QUFFeEMsZUFBTztBQUFBLFVBQ0wsTUFBTSxLQUFLO0FBQUEsVUFDWCxNQUFNO0FBQUEsVUFDTixRQUFRLFlBQVk7QUFBQSxRQUN0QjtBQUFBLE1BQ0YsU0FBUyxPQUFQO0FBQ0EsZ0JBQVEsTUFBTSx3QkFBd0IsS0FBSyxTQUFTLEtBQUs7QUFDekQsZUFBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVRLGtCQUFrQixNQUFhLFNBQXlCO0FBQzlELFVBQU0sT0FBTyxLQUFLLEtBQUssWUFBWTtBQUduQyxRQUNFLEtBQUssU0FBUyxPQUFPLEtBQ3JCLFFBQVEsU0FBUywwQkFBMEIsR0FDM0M7QUFDQSxhQUFPO0FBQUEsSUFDVDtBQUdBLFFBQUksS0FBSyxTQUFTLFNBQVMsS0FBSyxRQUFRLFNBQVMsWUFBWSxHQUFHO0FBQzlELFVBQUksUUFBUSxTQUFTLCtCQUErQixHQUFHO0FBQ3JELGVBQU87QUFBQSxNQUNUO0FBQ0EsVUFBSSxRQUFRLFNBQVMsc0JBQXNCLEdBQUc7QUFDNUMsZUFBTztBQUFBLE1BQ1Q7QUFDQSxVQUFJLFFBQVEsU0FBUyx1QkFBdUIsR0FBRztBQUM3QyxlQUFPO0FBQUEsTUFDVDtBQUNBLFVBQUksUUFBUSxTQUFTLDBCQUEwQixHQUFHO0FBQ2hELGVBQU87QUFBQSxNQUNUO0FBQ0EsYUFBTztBQUFBLElBQ1Q7QUFHQSxRQUFJLFFBQVEsU0FBUyxLQUFLLEtBQUssUUFBUSxNQUFNLGlCQUFpQixHQUFHO0FBQy9ELGFBQU87QUFBQSxJQUNUO0FBRUEsV0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUVRLDJCQUEyQixTQUFnQztBQUNqRSxVQUFNLGdCQUFnQjtBQUN0QixVQUFNLFFBQVEsUUFBUSxNQUFNLGFBQWE7QUFDekMsV0FBTyxRQUFRLE1BQU0sQ0FBQyxJQUFJO0FBQUEsRUFDNUI7QUFBQSxFQUVRLHdCQUF3QixVQUFpQztBQUMvRCxVQUFNLGdCQUFnQjtBQUN0QixVQUFNLFVBQVUsU0FBUyxNQUFNLGFBQWE7QUFDNUMsV0FBTyxVQUFVLFFBQVEsUUFBUSxTQUFTLENBQUMsSUFBSTtBQUFBLEVBQ2pEO0FBQUEsRUFFYyx1QkFDWixVQUNBLE1BQ2tCO0FBQUE7QUFDbEIsWUFBTSxRQUFpQixDQUFDO0FBR3hCLFlBQU0sV0FBVyxLQUFLLElBQUksTUFBTSxpQkFBaUI7QUFFakQsaUJBQVcsUUFBUSxVQUFVO0FBRTNCLFlBQ0UsS0FBSyxLQUFLLFNBQVMsUUFBUSxNQUMxQixNQUFNLEtBQUssb0JBQW9CLE1BQU0sUUFBUSxJQUM5QztBQUVBLGdCQUFNLFdBQVcsS0FBSyxvQkFBb0IsS0FBSyxJQUFJO0FBQ25ELGNBQUksYUFBYSxNQUFNO0FBQ3JCLGtCQUFNLEtBQUssSUFBSTtBQUFBLFVBQ2pCO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFFQSxhQUFPO0FBQUEsSUFDVDtBQUFBO0FBQUEsRUFFYyxvQkFDWixNQUNBLFVBQ2tCO0FBQUE7QUFDbEIsVUFBSTtBQUNGLGNBQU0sVUFBVSxNQUFNLEtBQUssSUFBSSxNQUFNLEtBQUssSUFBSTtBQUM5QyxlQUFPLEtBQUssMkJBQTJCLE9BQU8sTUFBTTtBQUFBLE1BQ3RELFNBQVMsT0FBUDtBQUNBLGdCQUFRO0FBQUEsVUFDTiwwQkFBMEIsS0FBSywwQkFBMEI7QUFBQSxVQUN6RDtBQUFBLFFBQ0Y7QUFDQSxlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFBQTtBQUFBLEVBRU0scUJBQXFCLE1BQWdDO0FBQUE7QUFDekQsWUFBTSxhQUFhLFFBQVEsSUFBSSxLQUFLLEVBQUUsWUFBWSxFQUFFLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFDaEUsWUFBTSxhQUFhLE1BQU0sS0FBSyx5QkFBeUIsSUFBSSxVQUFVO0FBRXJFLFVBQUksV0FBVyxXQUFXLEdBQUc7QUFDM0IsZUFBTywyQkFBMkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUNwQztBQUdBLFlBQU0sV0FBOEMsQ0FBQztBQUNyRCxZQUFNLFdBQThCLENBQUM7QUFFckMsaUJBQVcsWUFBWSxZQUFZO0FBQ2pDLFlBQUksU0FBUyxLQUFLLFNBQVMsVUFBVSxHQUFHO0FBRXRDLGdCQUFNLFlBQVksU0FBUyxLQUFLLE1BQU0sR0FBRztBQUN6QyxnQkFBTSxjQUFjLFVBQVUsVUFBVSxDQUFDLFNBQVMsS0FBSyxTQUFTLEdBQUcsQ0FBQztBQUNwRSxjQUFJLGVBQWUsR0FBRztBQUNwQixrQkFBTSxXQUFXLFVBQVUsV0FBVztBQUN0QyxnQkFBSSxDQUFDLFNBQVMsUUFBUSxHQUFHO0FBQ3ZCLHVCQUFTLFFBQVEsSUFBSSxDQUFDO0FBQUEsWUFDeEI7QUFDQSxxQkFBUyxRQUFRLEVBQUUsS0FBSyxRQUFRO0FBQUEsVUFDbEMsT0FBTztBQUNMLHFCQUFTLEtBQUssUUFBUTtBQUFBLFVBQ3hCO0FBQUEsUUFDRixPQUFPO0FBQ0wsbUJBQVMsS0FBSyxRQUFRO0FBQUEsUUFDeEI7QUFBQSxNQUNGO0FBRUEsVUFBSSxVQUFVLDJCQUEyQjtBQUFBO0FBQUE7QUFDekMsaUJBQVcscUJBQXFCLFdBQVc7QUFBQTtBQUFBO0FBRzNDLGlCQUFXLENBQUMsVUFBVSxnQkFBZ0IsS0FBSyxPQUFPLFFBQVEsUUFBUSxHQUFHO0FBQ25FLG1CQUFXLE1BQU07QUFBQTtBQUFBO0FBQ2pCLG1CQUFXO0FBQUE7QUFDWCxtQkFBVztBQUFBO0FBRVgsbUJBQVcsWUFBWSxrQkFBa0I7QUFDdkMscUJBQVcsS0FBSyxTQUFTLFVBQVUsU0FBUztBQUFBO0FBQUEsUUFDOUM7QUFDQSxtQkFBVztBQUFBO0FBQUEsTUFDYjtBQUdBLFVBQUksU0FBUyxTQUFTLEdBQUc7QUFDdkIsbUJBQVc7QUFBQTtBQUFBO0FBQ1gsbUJBQVc7QUFBQTtBQUNYLG1CQUFXO0FBQUE7QUFFWCxtQkFBVyxZQUFZLFVBQVU7QUFDL0IscUJBQVcsS0FBSyxTQUFTLFVBQVUsU0FBUztBQUFBO0FBQUEsUUFDOUM7QUFDQSxtQkFBVztBQUFBO0FBQUEsTUFDYjtBQUVBLGFBQU87QUFBQSxJQUNUO0FBQUE7QUFBQSxFQUVNLHVCQUF1QixNQUE4QjtBQUFBO0FBQ3pELFVBQUk7QUFDRixjQUFNLGFBQWEsUUFBUSxJQUFJLEtBQUssRUFBRSxZQUFZLEVBQUUsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUNoRSxjQUFNLGlCQUFpQixNQUFNLEtBQUsscUJBQXFCLFVBQVU7QUFHakUsY0FBTSxXQUFXLEdBQUc7QUFDcEIsY0FBTSxXQUFXLFNBQVM7QUFFMUIsWUFBSTtBQUNGLGdCQUFNLEtBQUssSUFBSSxNQUFNLE9BQU8sVUFBVSxjQUFjO0FBQ3BELGtCQUFRLElBQUksK0JBQStCLFVBQVU7QUFBQSxRQUN2RCxTQUFTLE9BQVA7QUFFQSxnQkFBTSxlQUFlLEtBQUssSUFBSSxNQUFNLHNCQUFzQixRQUFRO0FBQ2xFLGNBQUksZ0JBQWdCLHdCQUF3Qix3QkFBTztBQUNqRCxrQkFBTSxLQUFLLElBQUksTUFBTSxPQUFPLGNBQWMsY0FBYztBQUN4RCxvQkFBUSxJQUFJLCtCQUErQixVQUFVO0FBQUEsVUFDdkQ7QUFBQSxRQUNGO0FBQUEsTUFDRixTQUFTLE9BQVA7QUFDQSxnQkFBUSxNQUFNLG9DQUFvQyxTQUFTLEtBQUs7QUFDaEUsY0FBTTtBQUFBLE1BQ1I7QUFBQSxJQUNGO0FBQUE7QUFDRjs7O0FSelJBLElBQXFCLHFCQUFyQixjQUFnRCx3QkFBTztBQUFBLEVBUS9DLFNBQVM7QUFBQTtBQUNiLGNBQVEsSUFBSSw4QkFBOEI7QUFHMUMsWUFBTSxLQUFLLGFBQWE7QUFHeEIsV0FBSyxrQkFBa0IsSUFBSSxnQkFBZ0IsS0FBSyxLQUFLLEtBQUssUUFBUTtBQUNsRSxXQUFLLGVBQWUsSUFBSSxxQkFBcUIsS0FBSyxLQUFLLEtBQUssUUFBUTtBQUNwRSxXQUFLLHNCQUFzQixJQUFJLG9CQUFvQixLQUFLLEdBQUc7QUFDM0QsV0FBSyxpQkFBaUIsSUFBSSxlQUFlLEtBQUssR0FBRztBQUNqRCxXQUFLLHdCQUF3QixJQUFJLHNCQUFzQixLQUFLLEdBQUc7QUFHL0QsV0FBSyxjQUFjLElBQUksdUJBQXVCLEtBQUssS0FBSyxJQUFJLENBQUM7QUFHN0QsV0FBSyw2QkFBNkI7QUFHbEMsV0FBSyxXQUFXO0FBQUEsUUFDZCxJQUFJO0FBQUEsUUFDSixNQUFNO0FBQUEsUUFDTixVQUFVLE1BQU07QUFDZCxlQUFLLGdCQUFnQixpQkFBaUI7QUFBQSxRQUN4QztBQUFBLE1BQ0YsQ0FBQztBQUVELFdBQUssV0FBVztBQUFBLFFBQ2QsSUFBSTtBQUFBLFFBQ0osTUFBTTtBQUFBLFFBQ04sVUFBVSxNQUFNO0FBQ2QsZUFBSyxnQkFBZ0IsZ0JBQWdCO0FBQUEsUUFDdkM7QUFBQSxNQUNGLENBQUM7QUFFRCxXQUFLLFdBQVc7QUFBQSxRQUNkLElBQUk7QUFBQSxRQUNKLE1BQU07QUFBQSxRQUNOLFVBQVUsTUFBTTtBQUNkLGVBQUssYUFBYSxxQkFBcUI7QUFBQSxRQUN6QztBQUFBLE1BQ0YsQ0FBQztBQUVELFdBQUssV0FBVztBQUFBLFFBQ2QsSUFBSTtBQUFBLFFBQ0osTUFBTTtBQUFBLFFBQ04sVUFBVSxNQUFZO0FBQ3BCLGdCQUFNLFdBQVcsTUFBTSxLQUFLO0FBQUEsWUFDMUI7QUFBQSxVQUNGO0FBQ0EsY0FBSSxVQUFVO0FBQ1osa0JBQU0sS0FBSyxvQkFBb0IsMEJBQTBCLFFBQVE7QUFBQSxVQUNuRTtBQUFBLFFBQ0Y7QUFBQSxNQUNGLENBQUM7QUFFRCxXQUFLLFdBQVc7QUFBQSxRQUNkLElBQUk7QUFBQSxRQUNKLE1BQU07QUFBQSxRQUNOLFVBQVUsTUFBWTtBQUNwQixnQkFBTSxXQUFXLE1BQU0sS0FBSztBQUFBLFlBQzFCO0FBQUEsVUFDRjtBQUNBLGNBQUksVUFBVTtBQUNaLGtCQUFNLEtBQUssZUFBZSwwQkFBMEIsUUFBUTtBQUFBLFVBQzlEO0FBQUEsUUFDRjtBQUFBLE1BQ0YsQ0FBQztBQUVELFdBQUssV0FBVztBQUFBLFFBQ2QsSUFBSTtBQUFBLFFBQ0osTUFBTTtBQUFBLFFBQ04sVUFBVSxNQUFZO0FBQ3BCLGdCQUFNLE9BQU8sTUFBTSxLQUFLO0FBQUEsWUFDdEI7QUFBQSxVQUNGO0FBQ0EsZ0JBQU0sS0FBSyxzQkFBc0I7QUFBQSxZQUMvQixRQUFRO0FBQUEsVUFDVjtBQUFBLFFBQ0Y7QUFBQSxNQUNGLENBQUM7QUFHRCxXQUFLLGlCQUFpQixFQUFFLFFBQVEsZUFBZTtBQUFBLElBQ2pEO0FBQUE7QUFBQSxFQUVjLGtCQUFrQixTQUF5QztBQUFBO0FBQ3ZFLFlBQU0sV0FBVyxPQUFPLFVBQVUsc0JBQXNCO0FBQ3hELGFBQU8sV0FBVyxTQUFTLEtBQUssSUFBSTtBQUFBLElBQ3RDO0FBQUE7QUFBQSxFQUVjLGNBQWMsU0FBeUM7QUFBQTtBQUNuRSxZQUFNLE9BQU87QUFBQSxRQUNYLFVBQVU7QUFBQSxNQUNaO0FBQ0EsYUFBTyxPQUFPLEtBQUssS0FBSyxJQUFJO0FBQUEsSUFDOUI7QUFBQTtBQUFBLEVBRUEsV0FBVztBQUNULFlBQVEsSUFBSSxnQ0FBZ0M7QUFBQSxFQUM5QztBQUFBLEVBRU0sK0JBQStCO0FBQUE7QUFFbkMsWUFBTSxrQkFBbUIsS0FBSyxJQUFZLFFBQVEsVUFBVSxvQkFBb0I7QUFDaEYsVUFBSSxDQUFDLGlCQUFpQjtBQUNwQixnQkFBUSxJQUFJLHNFQUFzRTtBQUNsRjtBQUFBLE1BQ0Y7QUFHQSxVQUFJO0FBRUYsWUFBSSxtQkFBbUIsZ0JBQWdCLFdBQVc7QUFFaEQsY0FBSSxDQUFDLGdCQUFnQixVQUFVLFdBQVc7QUFDeEMsNEJBQWdCLFVBQVUsWUFBWSxDQUFDO0FBQUEsVUFDekM7QUFHQSwwQkFBZ0IsVUFBVSxVQUFVLFlBQVksSUFBSSxDQUFPLEtBQVUsSUFBUyxTQUFjO0FBQzFGLG1CQUFPLEtBQUssa0JBQWtCLEtBQUssSUFBSSxJQUFJO0FBQUEsVUFDN0M7QUFFQSwwQkFBZ0IsVUFBVSxVQUFVLGFBQWEsSUFBSSxDQUFPLE9BQVk7QUFDdEUsbUJBQU8sS0FBSyxtQkFBbUIsRUFBRTtBQUFBLFVBQ25DO0FBRUEsa0JBQVEsSUFBSSwyREFBMkQ7QUFBQSxRQUN6RSxPQUFPO0FBQ0wsa0JBQVEsTUFBTSxxRUFBcUU7QUFBQSxRQUNyRjtBQUFBLE1BQ0YsU0FBUyxHQUFQO0FBQ0EsZ0JBQVEsTUFBTSwwQ0FBMEMsQ0FBQztBQUFBLE1BQzNEO0FBQUEsSUFDRjtBQUFBO0FBQUEsRUFFTSxrQkFBa0IsS0FBVSxJQUFTLE1BQWM7QUFBQTtBQTlKM0Q7QUFnS0ksVUFBSSxlQUE4QjtBQUNsQyxVQUFJLGFBQTRCO0FBQ2hDLFVBQUksU0FBUztBQUNiLFVBQUksV0FBVztBQUNmLFVBQUksYUFBYTtBQUNqQixVQUFJLFlBQVk7QUFFaEIsVUFBSTtBQUVGLFlBQUksTUFBTSxHQUFHLFVBQVUsR0FBRyxPQUFPLFFBQVE7QUFDdkMsZ0JBQU0sbUJBQW1CLE1BQU0sR0FBRyxPQUFPLE9BQU8sNEJBQTRCLEVBQUU7QUFDOUUseUJBQWUsbUJBQW1CLG1CQUFtQjtBQUVyRCxnQkFBTSxpQkFBaUIsTUFBTSxHQUFHLE9BQU8sT0FBTywwQkFBMEIsRUFBRTtBQUMxRSx1QkFBYSxpQkFBaUIsaUJBQWlCO0FBRS9DLG1CQUFTLE1BQU0sR0FBRyxPQUFPO0FBQUEsWUFDdkIsTUFBTSxJQUFJLE1BQU0saUJBQWlCLEVBQUUsT0FBTyxDQUFDLE1BQVcsRUFBRSxLQUFLLFNBQVMsU0FBUyxDQUFDLEVBQUUsSUFBSSxDQUFDLE1BQVcsRUFBRSxRQUFRO0FBQUEsWUFDNUcsSUFBSSxNQUFNLGlCQUFpQixFQUFFLE9BQU8sQ0FBQyxNQUFXLEVBQUUsS0FBSyxTQUFTLFNBQVMsQ0FBQztBQUFBLFVBQzVFO0FBRUEsc0JBQVksTUFBTSxHQUFHLE9BQU87QUFBQSxZQUMxQixDQUFDLFVBQVUsV0FBVyxhQUFhLFlBQVksVUFBVSxZQUFZLFFBQVE7QUFBQSxZQUM3RSxDQUFDLFVBQVUsV0FBVyxhQUFhLFlBQVksVUFBVSxZQUFZLFFBQVE7QUFBQSxZQUM3RTtBQUFBLFVBQ0Y7QUFBQSxRQUNGLE9BQU87QUFFTCx5QkFBZTtBQUNmLHVCQUFhO0FBQ2IsbUJBQVM7QUFDVCxzQkFBWTtBQUFBLFFBQ2Q7QUFBQSxNQUNGLFNBQVMsR0FBUDtBQUNBLGdCQUFRLE1BQU0sZ0NBQWdDLENBQUM7QUFFL0MsdUJBQWU7QUFDZixxQkFBYTtBQUNiLGlCQUFTO0FBQ1Qsb0JBQVk7QUFBQSxNQUNkO0FBR0EsaUJBQVcsU0FBUyxPQUFPLE1BQU0sS0FBSyxFQUFFLENBQUMsS0FBSyxTQUFTO0FBQ3ZELG1CQUFhLFdBQVUsWUFBTyxNQUFNLEtBQUssRUFBRSxDQUFDLE1BQXJCLG1CQUF3QixVQUFVLEdBQUcsT0FBTSxRQUFTO0FBRTNFLGFBQU87QUFBQSxRQUNMLFFBQVE7QUFBQTtBQUFBLFFBQ1I7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVNLG1CQUFtQixJQUFTO0FBQUE7QUF6TnBDO0FBME5JLFVBQUksZ0JBQWdCO0FBQ3BCLFVBQUksU0FBUztBQUNiLFVBQUksV0FBVztBQUNmLFVBQUksYUFBYTtBQUNqQixVQUFJLE9BQU87QUFFWCxVQUFJO0FBQ0YsWUFBSSxNQUFNLEdBQUcsVUFBVSxHQUFHLE9BQU8sUUFBUTtBQUN2QywyQkFBZ0IsTUFBTSxHQUFHLE9BQU8sT0FBTyxrQkFBa0IsRUFBRSxNQUFLO0FBQ2hFLG1CQUFTLE1BQU0sR0FBRyxPQUFPO0FBQUEsWUFDdkIsTUFBTSxHQUFHLElBQUksTUFBTSxpQkFBaUIsRUFBRSxPQUFPLENBQUMsTUFBVyxFQUFFLEtBQUssU0FBUyxTQUFTLENBQUMsRUFBRSxJQUFJLENBQUMsTUFBVyxFQUFFLFFBQVE7QUFBQSxZQUMvRyxHQUFHLElBQUksTUFBTSxpQkFBaUIsRUFBRSxPQUFPLENBQUMsTUFBVyxFQUFFLEtBQUssU0FBUyxTQUFTLENBQUM7QUFBQSxVQUMvRTtBQUNBLGdCQUFNLGNBQWMsR0FBRyxJQUFJLE1BQU0sU0FBUyxFQUFFLE9BQU8sQ0FBQyxNQUFXLEVBQUUsY0FBYyxLQUFLLEVBQUUsSUFBSSxDQUFDLE1BQVcsRUFBRSxRQUFRO0FBQ2hILGlCQUFPLE1BQU0sR0FBRyxPQUFPLFVBQVUsYUFBYSxhQUFhLFVBQVU7QUFBQSxRQUN2RSxPQUFPO0FBRUwsMEJBQWdCO0FBQ2hCLG1CQUFTO0FBQ1QsaUJBQU87QUFBQSxRQUNUO0FBQUEsTUFDRixTQUFTLEdBQVA7QUFDQSxnQkFBUSxNQUFNLGlDQUFpQyxDQUFDO0FBRWhELHdCQUFnQjtBQUNoQixpQkFBUztBQUNULGVBQU87QUFBQSxNQUNUO0FBR0EsaUJBQVcsU0FBUyxPQUFPLE1BQU0sS0FBSyxFQUFFLENBQUMsS0FBSyxTQUFTO0FBQ3ZELG1CQUFhLFdBQVUsWUFBTyxNQUFNLEtBQUssRUFBRSxDQUFDLE1BQXJCLG1CQUF3QixVQUFVLEdBQUcsT0FBTSxRQUFTO0FBRTNFLGFBQU87QUFBQSxRQUNMO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUE7QUFBQSxFQUVNLGVBQWU7QUFBQTtBQUNuQixXQUFLLFdBQVcsT0FBTyxPQUFPLENBQUMsR0FBRyxrQkFBa0IsTUFBTSxLQUFLLFNBQVMsQ0FBQztBQUFBLElBQzNFO0FBQUE7QUFBQSxFQUVNLGVBQWU7QUFBQTtBQUNuQixZQUFNLEtBQUssU0FBUyxLQUFLLFFBQVE7QUFBQSxJQUNuQztBQUFBO0FBQ0Y7IiwKICAibmFtZXMiOiBbImltcG9ydF9vYnNpZGlhbiIsICJpbXBvcnRfb2JzaWRpYW4iLCAiaW1wb3J0X29ic2lkaWFuIiwgImltcG9ydF9vYnNpZGlhbiIsICJpbXBvcnRfb2JzaWRpYW4iLCAiaW1wb3J0X29ic2lkaWFuIiwgImltcG9ydF9vYnNpZGlhbiJdCn0K
